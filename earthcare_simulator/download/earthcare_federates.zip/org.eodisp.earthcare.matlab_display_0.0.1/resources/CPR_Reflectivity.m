% This file open the file Reflectivity: output from radar

%Read header
header = fscanf (fid,'%s',3);

%Read values of axis
Counter1 = fscanf (fid,'%d',1);
Scale_Xaxis = fscanf (fid,'%d',1);
Scale_Yaxis =  Scale_Xaxis;
Scale_Zaxis = fscanf (fid,'%d',1);

X_axis = fscanf (fid,'%f',Scale_Xaxis);
XStep = X_axis(Scale_Xaxis) - X_axis(Scale_Xaxis - 1);

Y_axis = fscanf (fid,'%f',Scale_Yaxis);
YStep = Y_axis(Scale_Yaxis) - Y_axis(Scale_Yaxis - 1);

Z_axis = fscanf (fid,'%f',Scale_Zaxis);
ZStep = Z_axis(Scale_Zaxis) - Z_axis(Scale_Zaxis - 1);

%Create plotting matrix
for i =1: Scale_Xaxis Separator = fscanf (fid,'%s',1); Xposition = fscanf(fid,'%d',1); PlotMatrix (:,i)  = fscanf (fid,'%f',Scale_Zaxis);end 


%Plot Mass
contourf(X_axis, Z_axis,PlotMatrix,10);
colormap('jet');
grid on;
colorbar;
title(['\fontsize{13}', 'CPR Reflectivity  at  Y = ',num2str(Y_axis(Scale_Yaxis)),' km']);
xlabel(['\fontsize{11}','X distance [km]']);
ylabel(['\fontsize{11}','Z distance [km]']);