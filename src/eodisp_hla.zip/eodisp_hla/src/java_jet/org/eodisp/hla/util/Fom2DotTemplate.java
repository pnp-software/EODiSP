package org.eodisp.hla.util;

import org.eodisp.hla.crc.omt.*;

public class Fom2DotTemplate
{
  protected static String nl;
  public static synchronized Fom2DotTemplate create(String lineSeparator)
  {
    nl = lineSeparator;
    Fom2DotTemplate result = new Fom2DotTemplate();
    nl = null;
    return result;
  }

  protected final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "digraph G {" + NL + "    // Dot configurations" + NL + "    edge [fontname=\"Helvetica\",fontsize=10,labelfontname=\"Helvetica\",labelfontsize=10];" + NL + "    node [fontname=\"Helvetica\",fontsize=10,shape=plaintext];" + NL + "    " + NL + "    // Object Classes";
  protected final String TEXT_2 = NL + "\t";
  protected final String TEXT_3 = NL + "\tc";
  protected final String TEXT_4 = " [label=<" + NL + "\t<table border=\"0\" cellborder=\"1\" cellspacing=\"0\" cellpadding=\"2\" port=\"p\" bgcolor=\"gold\">" + NL + "\t<tr><td>" + NL + "\t\t<table border=\"0\" cellspacing=\"0\" cellpadding=\"1\">" + NL + "\t\t\t<tr><td> ";
  protected final String TEXT_5 = " (";
  protected final String TEXT_6 = ") </td></tr>" + NL + "\t\t</table>" + NL + "\t</td></tr>";
  protected final String TEXT_7 = NL + "\t<tr><td>" + NL + "\t\t<table border=\"0\" cellspacing=\"0\" cellpadding=\"1\">" + NL + "\t\t\t<tr><td align=\"left\"></td></tr>";
  protected final String TEXT_8 = NL + "\t\t\t<tr><td align=\"left\">  ";
  protected final String TEXT_9 = " (";
  protected final String TEXT_10 = ")  </td></tr>";
  protected final String TEXT_11 = NL + "\t\t</table>" + NL + "\t</td></tr>";
  protected final String TEXT_12 = NL + "\t</table>>," + NL + "\tfontname=\"Helvetica\", fontcolor=\"black\", fontsize=10.0];";
  protected final String TEXT_13 = NL + "\t// Object class relationships";
  protected final String TEXT_14 = NL + "\tc";
  protected final String TEXT_15 = ":p -> c";
  protected final String TEXT_16 = ":p [dir=back,arrowtail=empty];";
  protected final String TEXT_17 = NL + NL + "\t// Interaction Classes";
  protected final String TEXT_18 = NL + "\t{" + NL + "\ti";
  protected final String TEXT_19 = " [label=<" + NL + "\t<table border=\"0\" cellborder=\"1\" cellspacing=\"0\" cellpadding=\"2\" port=\"p\" bgcolor=\"gold\">" + NL + "\t<tr><td>" + NL + "\t\t<table border=\"0\" cellspacing=\"0\" cellpadding=\"1\">" + NL + "\t\t\t<tr><td> ";
  protected final String TEXT_20 = " (";
  protected final String TEXT_21 = ") </td></tr>" + NL + "\t\t</table>" + NL + "\t</td></tr>";
  protected final String TEXT_22 = NL + "\t<tr><td>" + NL + "\t\t<table border=\"0\" cellspacing=\"0\" cellpadding=\"1\">" + NL + "\t\t\t<tr><td align=\"left\"></td></tr>";
  protected final String TEXT_23 = NL + "\t\t\t<tr><td align=\"left\">  ";
  protected final String TEXT_24 = " </td></tr>";
  protected final String TEXT_25 = NL + "\t\t</table>" + NL + "\t</td></tr>";
  protected final String TEXT_26 = NL + "\t</table>>," + NL + "\tfontname=\"Helvetica\", fontcolor=\"black\", fontsize=10.0, rank=\"";
  protected final String TEXT_27 = "\"];" + NL + "\t}";
  protected final String TEXT_28 = NL + "\t// Interaction class relationships";
  protected final String TEXT_29 = NL + "\ti";
  protected final String TEXT_30 = ":p -> i";
  protected final String TEXT_31 = ":p [dir=back,arrowtail=empty];";
  protected final String TEXT_32 = NL + NL + "}" + NL + NL + NL;
  protected final String TEXT_33 = NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(TEXT_1);
    OmtModel omtModel = (OmtModel)argument;
    for( ObjectClass objectClass : omtModel.getAllObjectClasses() ) {   
    stringBuffer.append(TEXT_2);
    int index = omtModel.getIndex(objectClass); 
    stringBuffer.append(TEXT_3);
    stringBuffer.append(index);
    stringBuffer.append(TEXT_4);
    stringBuffer.append(objectClass.getName());
    stringBuffer.append(TEXT_5);
    stringBuffer.append( OmtModel.getSharingString(objectClass) );
    stringBuffer.append(TEXT_6);
    	if (!objectClass.getAttributes().isEmpty()) {
    stringBuffer.append(TEXT_7);
    		for( Object attrObject : objectClass.getAttributes() ) {
    			Attribute attribute = (Attribute) attrObject; 
    stringBuffer.append(TEXT_8);
    stringBuffer.append( attribute.getName() );
    stringBuffer.append(TEXT_9);
    stringBuffer.append( OmtModel.getSharingString(attribute) );
    stringBuffer.append(TEXT_10);
    		}
    stringBuffer.append(TEXT_11);
    	}
    stringBuffer.append(TEXT_12);
    }
    stringBuffer.append(TEXT_13);
    for( ObjectClass objectClass : omtModel.getAllObjectClasses() ) {   
    	if( objectClass.getSuperClass() != null ) { 
    stringBuffer.append(TEXT_14);
    stringBuffer.append( omtModel.getIndex(objectClass.getSuperClass()) );
    stringBuffer.append(TEXT_15);
    stringBuffer.append(omtModel.getIndex(objectClass));
    stringBuffer.append(TEXT_16);
    	}
    }
    stringBuffer.append(TEXT_17);
    for( InteractionClass interaction : omtModel.getAllInteractionClasses() ) {   
    stringBuffer.append(TEXT_18);
    stringBuffer.append(omtModel.getIndex(interaction));
    stringBuffer.append(TEXT_19);
    stringBuffer.append(interaction.getName());
    stringBuffer.append(TEXT_20);
    stringBuffer.append( OmtModel.getSharingString(interaction) );
    stringBuffer.append(TEXT_21);
    	if (!interaction.getParameters().isEmpty()) {
    stringBuffer.append(TEXT_22);
    		for( Object paramObject : interaction.getParameters() ) {
    			Parameter parameter = (Parameter) paramObject; 
    stringBuffer.append(TEXT_23);
    stringBuffer.append( parameter.getName() );
    stringBuffer.append(TEXT_24);
    		}
    stringBuffer.append(TEXT_25);
    	}
    stringBuffer.append(TEXT_26);
    stringBuffer.append(omtModel.getIndex(interaction));
    stringBuffer.append(TEXT_27);
    }
    stringBuffer.append(TEXT_28);
    for( InteractionClass interaction : omtModel.getAllInteractionClasses() ) {   
    	if( interaction.getSuperClass() != null ) { 
    stringBuffer.append(TEXT_29);
    stringBuffer.append( omtModel.getIndex(interaction.getSuperClass()) );
    stringBuffer.append(TEXT_30);
    stringBuffer.append(omtModel.getIndex(interaction));
    stringBuffer.append(TEXT_31);
    	}
    }
    stringBuffer.append(TEXT_32);
    stringBuffer.append(TEXT_33);
    return stringBuffer.toString();
  }
}
