package hla.rti1516;

/**
 * Public exception class InvalidTransportationName
 */
public final class InvalidTransportationName extends RTIexception {
	public InvalidTransportationName(String msg) {
		super(msg);
	}
}
