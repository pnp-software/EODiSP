package hla.rti1516;

/**
 * Public exception class InvalidRegion
 */
public final class InvalidRegion extends RTIexception {
	public InvalidRegion(String msg) {
		super(msg);
	}
}
