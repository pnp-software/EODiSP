package hla.rti1516;

/**
 * Public exception class FederationExecutionDoesNotExist
 */
public final class FederationExecutionDoesNotExist extends RTIexception {
	public FederationExecutionDoesNotExist(String msg) {
		super(msg);
	}
}
