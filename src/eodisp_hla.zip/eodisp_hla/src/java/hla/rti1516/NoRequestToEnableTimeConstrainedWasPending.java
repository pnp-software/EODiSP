package hla.rti1516;

/**
 * 
 * Public exception class NoRequestToEnableTimeConstrainedWasPending
 * 
 */

public final class NoRequestToEnableTimeConstrainedWasPending extends RTIexception {
	public NoRequestToEnableTimeConstrainedWasPending(String msg) {
		super(msg);
	}
}
