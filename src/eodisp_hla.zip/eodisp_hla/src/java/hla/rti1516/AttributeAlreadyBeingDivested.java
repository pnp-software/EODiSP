package hla.rti1516;

/**
 * 
 * Public exception class AttributeAlreadyBeingDivested
 * 
 */

public final class AttributeAlreadyBeingDivested extends RTIexception {
	public AttributeAlreadyBeingDivested(String msg) {
		super(msg);
	}
}
