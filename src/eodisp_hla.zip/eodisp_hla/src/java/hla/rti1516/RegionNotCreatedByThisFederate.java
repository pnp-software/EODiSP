package hla.rti1516;

/**
 * 
 * Public exception class RegionNotCreatedByThisFederate
 * 
 */

public final class RegionNotCreatedByThisFederate extends RTIexception {
	public RegionNotCreatedByThisFederate(String msg) {
		super(msg);
	}
}
