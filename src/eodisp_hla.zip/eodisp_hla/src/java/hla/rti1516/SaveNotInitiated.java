package hla.rti1516;

/**
 * 
 * Public exception class SaveNotInitiated
 * 
 */

public final class SaveNotInitiated extends RTIexception {
	public SaveNotInitiated(String msg) {
		super(msg);
	}
}
