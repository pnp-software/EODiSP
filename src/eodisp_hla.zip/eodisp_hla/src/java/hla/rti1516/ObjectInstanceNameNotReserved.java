package hla.rti1516;

/**
 * 
 * Public exception class ObjectInstanceNameNotReserved
 * 
 */

public final class ObjectInstanceNameNotReserved extends RTIexception {
	public ObjectInstanceNameNotReserved(String msg) {
		super(msg);
	}
}
