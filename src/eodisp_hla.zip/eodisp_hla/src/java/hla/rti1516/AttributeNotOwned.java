package hla.rti1516;

/**
 * 
 * Public exception class AttributeNotOwned
 * 
 */

public final class AttributeNotOwned extends RTIexception {
	public AttributeNotOwned(String msg) {
		super(msg);
	}

	public AttributeNotOwned(InvalidAttributeHandle e) {
		// TODO Auto-generated constructor stub
	}
}
