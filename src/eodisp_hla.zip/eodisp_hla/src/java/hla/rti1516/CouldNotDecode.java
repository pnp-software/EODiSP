package hla.rti1516;

public final class CouldNotDecode extends RTIexception {
	public CouldNotDecode(String msg) {
		super(msg);
	}

	public CouldNotDecode(String msg, IllegalArgumentException e) {
		super(msg, e);
	}
}
