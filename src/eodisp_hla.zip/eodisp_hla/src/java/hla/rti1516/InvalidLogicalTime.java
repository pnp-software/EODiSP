package hla.rti1516;

/**
 * 
 * Public exception class InvalidLogicalTime
 * 
 */

public final class InvalidLogicalTime extends RTIexception {
	public InvalidLogicalTime(String msg) {
		super(msg);
	}
}
