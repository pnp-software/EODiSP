//File: AttributeRelevanceAdvisorySwitchIsOn.java
package hla.rti1516;

public final class AttributeRelevanceAdvisorySwitchIsOn extends RTIexception {
	public AttributeRelevanceAdvisorySwitchIsOn(String msg) {
		super(msg);
	}
}
// end AttributeRelevanceAdvisorySwitchIsOn

