package hla.rti1516;

/**
 * 
 * Public exception class AttributeAlreadyBeingAcquired
 * 
 */

public final class AttributeAlreadyBeingAcquired extends RTIexception {
	public AttributeAlreadyBeingAcquired(String msg) {
		super(msg);
	}
}
