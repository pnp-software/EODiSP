package hla.rti1516;

/**
 * 
 * Public exception class CouldNotInitiateRestore
 * 
 */

public final class CouldNotInitiateRestore extends RTIexception {
	public CouldNotInitiateRestore(String msg) {
		super(msg);
	}
}
