package hla.rti1516;

/**
 * 
 * Public exception class RequestForTimeRegulationPending
 * 
 */

public final class RequestForTimeRegulationPending extends RTIexception {
	public RequestForTimeRegulationPending(String msg) {
		super(msg);
	}
}
