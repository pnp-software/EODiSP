package hla.rti1516;

/**
 * 
 * Public exception class NoRequestToEnableTimeRequestWasPending
 * 
 */

public final class NoRequestToEnableTimeRegulationWasPending extends RTIexception {
	public NoRequestToEnableTimeRegulationWasPending(String msg) {
		super(msg);
	}
}
