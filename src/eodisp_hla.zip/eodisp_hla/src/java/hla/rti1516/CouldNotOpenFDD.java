package hla.rti1516;


/**
 * Public exception class CouldNotOpenFDD
 */
public final class CouldNotOpenFDD extends RTIexception {
	public CouldNotOpenFDD(String msg) {
		super(msg);
	}

	/**
	 * 
	 */
	public CouldNotOpenFDD() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 */
	public CouldNotOpenFDD(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cause
	 */
	public CouldNotOpenFDD(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	
}
