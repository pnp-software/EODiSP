//File: AttributeScopeAdvisorySwitchIsOff.java
package hla.rti1516;

public final class AttributeScopeAdvisorySwitchIsOff extends RTIexception {
	public AttributeScopeAdvisorySwitchIsOff(String msg) {
		super(msg);
	}
}
// end AttributeScopeAdvisorySwitchIsOff

