//File: ObjectClassRelevanceAdvisorySwitchIsOff.java
package hla.rti1516;

public final class ObjectClassRelevanceAdvisorySwitchIsOff extends RTIexception {
	public ObjectClassRelevanceAdvisorySwitchIsOff(String msg) {
		super(msg);
	}
}
// end ObjectClassRelevanceAdvisorySwitchIsOff

