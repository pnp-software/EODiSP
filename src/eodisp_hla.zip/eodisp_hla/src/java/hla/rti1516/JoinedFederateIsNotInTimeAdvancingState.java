package hla.rti1516;

/**
 * 
 * Public exception class JoinedFederateIsNotInTimeAdvancingState
 * 
 */

public final class JoinedFederateIsNotInTimeAdvancingState extends RTIexception {
	public JoinedFederateIsNotInTimeAdvancingState(String msg) {
		super(msg);
	}
}
