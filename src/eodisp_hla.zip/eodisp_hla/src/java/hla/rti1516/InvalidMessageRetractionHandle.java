package hla.rti1516;

/**
 * 
 * Public exception class InvalidMessageRetractionHandle
 * 
 */

public final class InvalidMessageRetractionHandle extends RTIexception {
	public InvalidMessageRetractionHandle(String msg) {
		super(msg);
	}
}
