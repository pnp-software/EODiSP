package hla.rti1516;

/**
 * Public exception class InvalidRangeBound
 */
public final class InvalidRangeBound extends RTIexception {
	public InvalidRangeBound(String msg) {
		super(msg);
	}
}
