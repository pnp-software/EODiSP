package hla.rti1516;

/**
 * 
 * Public exception class InteractionClassNotSubscribed
 * 
 */

public final class InteractionClassNotSubscribed extends RTIexception {
	public InteractionClassNotSubscribed(String msg) {
		super(msg);
	}
}
