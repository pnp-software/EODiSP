package hla.rti1516;

/**
 * Public exception class FederateOwnsAttributes
 */
public final class FederateOwnsAttributes extends RTIexception {
	public FederateOwnsAttributes(String msg) {
		super(msg);
	}
}
