//File: UnknownName.java
package hla.rti1516;

public final class UnknownName extends RTIexception {
	public UnknownName(String msg) {
		super(msg);
	}
}
// end UnknownName

