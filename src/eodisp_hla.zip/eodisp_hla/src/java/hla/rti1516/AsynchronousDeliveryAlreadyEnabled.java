package hla.rti1516;

/**
 * Public exception class AsynchronousDeliveryAlreadyEnabled
 */
public final class AsynchronousDeliveryAlreadyEnabled extends RTIexception {
	public AsynchronousDeliveryAlreadyEnabled(String msg) {
		super(msg);
	}
}
