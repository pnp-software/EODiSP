package hla.rti1516;

/**
 * 
 * Public exception class InvalidAttributeHandle
 * 
 */

public final class InvalidAttributeHandle extends RTIexception {
	public InvalidAttributeHandle(String msg) {
		super(msg);
	}
}
