package hla.rti1516;

/**
 * 
 * Public exception class IllegalName
 * 
 */

public final class IllegalName extends RTIexception {
	public IllegalName(String msg) {
		super(msg);
	}
}
