package hla.rti1516;

/**
 * Public exception class FederateNotExecutionMember
 */
public final class FederateNotExecutionMember extends RTIexception {
	public FederateNotExecutionMember(String msg) {
		super(msg);
	}
}
