package hla.rti1516;

/**
 * Public exception class SaveInProgress
 */
public final class SaveInProgress extends RTIexception {
	public SaveInProgress(String msg) {
		super(msg);
	}
}
