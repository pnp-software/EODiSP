//File: FederateHasNotBegunSave.java
package hla.rti1516;

public final class FederateHasNotBegunSave extends RTIexception {
	public FederateHasNotBegunSave(String msg) {
		super(msg);
	}
}
// end FederateHasNotBegunSave

