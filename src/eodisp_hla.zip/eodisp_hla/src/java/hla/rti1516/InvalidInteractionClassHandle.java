package hla.rti1516;

/**
 * 
 * Public exception class InvalidInteractionClassHandle
 * 
 */

public final class InvalidInteractionClassHandle extends RTIexception {
	public InvalidInteractionClassHandle(String msg) {
		super(msg);
	}
}
