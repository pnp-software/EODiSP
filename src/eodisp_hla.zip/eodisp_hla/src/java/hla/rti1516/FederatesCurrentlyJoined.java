package hla.rti1516;

/**
 * 
 * Public exception class FederatesCurrentlyJoined
 * 
 */

public final class FederatesCurrentlyJoined extends RTIexception {
	public FederatesCurrentlyJoined(String msg) {
		super(msg);
	}
}
