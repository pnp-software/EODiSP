//File: InteractionRelevanceAdvisorySwitchIsOn.java
package hla.rti1516;

public final class InteractionRelevanceAdvisorySwitchIsOn extends RTIexception {
	public InteractionRelevanceAdvisorySwitchIsOn(String msg) {
		super(msg);
	}
}
// end InteractionRelevanceAdvisorySwitchIsOn

