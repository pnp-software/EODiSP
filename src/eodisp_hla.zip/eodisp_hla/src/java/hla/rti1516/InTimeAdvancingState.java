package hla.rti1516;

/**
 * Public exception class InTimeAdvancingState
 */
public final class InTimeAdvancingState extends RTIexception {
	public InTimeAdvancingState(String msg) {
		super(msg);
	}
}
