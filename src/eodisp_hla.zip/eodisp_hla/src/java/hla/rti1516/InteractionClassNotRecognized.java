package hla.rti1516;

/**
 * 
 * Public exception class InteractionClassNotRecognized
 * 
 */

public final class InteractionClassNotRecognized extends RTIexception {
	public InteractionClassNotRecognized(String msg) {
		super(msg);
	}
}
