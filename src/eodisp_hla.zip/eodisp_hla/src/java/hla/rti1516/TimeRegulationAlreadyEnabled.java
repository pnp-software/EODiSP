package hla.rti1516;

/**
 * 
 * Public exception class TimeRegulationAlreadyEnabled
 * 
 */

public final class TimeRegulationAlreadyEnabled extends RTIexception {
	public TimeRegulationAlreadyEnabled(String msg) {
		super(msg);
	}
}
