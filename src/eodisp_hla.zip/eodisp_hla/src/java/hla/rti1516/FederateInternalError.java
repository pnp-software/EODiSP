package hla.rti1516;

/**
 * Public exception class FederateInternalError
 */
public final class FederateInternalError extends RTIexception {
	public FederateInternalError(String msg) {
		super(msg);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public FederateInternalError(String message, Throwable cause) {
		super(message, cause);
	}
}
