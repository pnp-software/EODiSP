package hla.rti1516;

/**
 * Public exception class FederateAlreadyExecutionMember
 */
public final class FederateAlreadyExecutionMember extends RTIexception {
	public FederateAlreadyExecutionMember(String msg) {
		super(msg);
	}
}
