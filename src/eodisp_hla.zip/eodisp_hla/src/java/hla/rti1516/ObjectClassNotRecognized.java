package hla.rti1516;

/**
 * Public exception class ObjectClassNotRecognized
 */
public final class ObjectClassNotRecognized extends RTIexception {
	public ObjectClassNotRecognized(String msg) {
		super(msg);
	}
}
