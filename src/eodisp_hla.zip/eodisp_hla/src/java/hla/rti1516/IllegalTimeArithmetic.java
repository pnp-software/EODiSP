package hla.rti1516;

public final class IllegalTimeArithmetic extends RTIexception {
	public IllegalTimeArithmetic(String msg) {
		super(msg);
	}
}
