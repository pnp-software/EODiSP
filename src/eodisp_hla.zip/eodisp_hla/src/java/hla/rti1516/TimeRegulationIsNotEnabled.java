package hla.rti1516;

/**
 * 
 * Public exception class TimeRegulationIsNotEnabled
 * 
 */

public final class TimeRegulationIsNotEnabled extends RTIexception {
	public TimeRegulationIsNotEnabled(String msg) {
		super(msg);
	}
}
