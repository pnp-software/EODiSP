package hla.rti1516;

/**
 * 
 * Public exception class ObjectInstanceNameInUse
 * 
 */

public final class ObjectInstanceNameInUse extends RTIexception {
	public ObjectInstanceNameInUse(String msg) {
		super(msg);
	}
}
