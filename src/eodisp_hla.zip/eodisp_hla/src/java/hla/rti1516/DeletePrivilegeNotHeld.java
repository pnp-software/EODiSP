package hla.rti1516;

/**
 * 
 * Public exception class DeletePrivilegeNotHeld
 * 
 */

public final class DeletePrivilegeNotHeld extends RTIexception {
	public DeletePrivilegeNotHeld(String msg) {
		super(msg);
	}
}
