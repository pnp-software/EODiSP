package hla.rti1516;

/**
 * 
 * Public exception class InteractionClassNotDefined
 * 
 */

public final class InteractionClassNotDefined extends RTIexception {
	public InteractionClassNotDefined(String msg) {
		super(msg);
	}
}
