package hla.rti1516;

/**
 * Public exception class RestoreInProgress
 */
public final class RestoreInProgress extends RTIexception {
	public RestoreInProgress(String msg) {
		super(msg);
	}
}
