package hla.rti1516;

/**
 * 
 * Public exception class AttributeAlreadyOwned
 * 
 */

public final class AttributeAlreadyOwned extends RTIexception {
	public AttributeAlreadyOwned(String msg) {
		super(msg);
	}
}
