package hla.rti1516;


/**
 * Public exception class RTIinternalError. This is deliberately not a final
 * class.
 */
public class RTIinternalError extends RTIexception {

	public RTIinternalError() {
		super();
	}

	public RTIinternalError(String message, Throwable cause) {
		super(message, cause);
	}

	public RTIinternalError(String message) {
		super(message);
	}

	public RTIinternalError(Throwable cause) {
		super(cause);
	}
	
	
}
