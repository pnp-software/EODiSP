package hla.rti1516;

/**
 * 
 * Public exception class InvalidParameterHandle
 * 
 */

public final class InvalidParameterHandle extends RTIexception {
	public InvalidParameterHandle(String msg) {
		super(msg);
	}
}
