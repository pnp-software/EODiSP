package hla.rti1516;

/**
 * 
 * Public exception class InvalidOrderType
 * 
 */

public final class InvalidOrderType extends RTIexception {
	public InvalidOrderType(String msg) {
		super(msg);
	}
}
