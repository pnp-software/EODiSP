package hla.rti1516;

/**
 * 
 * Public exception class TimeConstrainedIsNotEnabled
 * 
 */

public final class TimeConstrainedIsNotEnabled extends RTIexception {
	public TimeConstrainedIsNotEnabled(String msg) {
		super(msg);
	}
}
