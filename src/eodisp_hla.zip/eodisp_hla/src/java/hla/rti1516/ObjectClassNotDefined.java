package hla.rti1516;

/**
 * 
 * Public exception class ObjectClassNotDefined
 * 
 */

public final class ObjectClassNotDefined extends RTIexception {
	public ObjectClassNotDefined(String msg) {
		super(msg);
	}

	public ObjectClassNotDefined(InvalidObjectClassHandle e) {
		super(e);
	}
}
