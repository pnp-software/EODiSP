package hla.rti1516;

/**
 * 
 * Public exception class InvalidRegionContext
 * 
 */

public final class InvalidRegionContext extends RTIexception {
	public InvalidRegionContext(String msg) {
		super(msg);
	}
}
