package hla.rti1516;

/**
 * 
 * Public exception class InvalidFederateHandle
 * 
 */

public final class InvalidFederateHandle extends RTIexception {
	public InvalidFederateHandle(String msg) {
		super(msg);
	}
}
