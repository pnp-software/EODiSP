//File: ObjectClassRelevanceAdvisorySwitchIsOn.java
package hla.rti1516;

public final class ObjectClassRelevanceAdvisorySwitchIsOn extends RTIexception {
	public ObjectClassRelevanceAdvisorySwitchIsOn(String msg) {
		super(msg);
	}
}
// end ObjectClassRelevanceAdvisorySwitchIsOn

