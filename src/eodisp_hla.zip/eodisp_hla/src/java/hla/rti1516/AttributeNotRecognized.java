package hla.rti1516;

/**
 * 
 * Public exception class AttributeNotRecognized
 * 
 */

public final class AttributeNotRecognized extends RTIexception {
	public AttributeNotRecognized(String msg) {
		super(msg);
	}
}
