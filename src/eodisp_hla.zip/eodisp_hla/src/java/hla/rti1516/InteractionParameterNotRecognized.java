package hla.rti1516;

/**
 * 
 * Public exception class InteractionParameterNotRecognized
 * 
 */

public final class InteractionParameterNotRecognized extends RTIexception {
	public InteractionParameterNotRecognized(String msg) {
		super(msg);
	}
}
