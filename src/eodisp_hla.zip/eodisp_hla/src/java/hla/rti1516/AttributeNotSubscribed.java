package hla.rti1516;

/**
 * 
 * Public exception class AttributeNotSubscribed
 * 
 */

public final class AttributeNotSubscribed extends RTIexception {
	public AttributeNotSubscribed(String msg) {
		super(msg);
	}
}
