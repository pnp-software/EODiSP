package hla.rti1516;

/**
 * 
 * Public exception class InteractionClassNotPublished
 * 
 */

public final class InteractionClassNotPublished extends RTIexception {
	public InteractionClassNotPublished(String msg) {
		super(msg);
	}
}
