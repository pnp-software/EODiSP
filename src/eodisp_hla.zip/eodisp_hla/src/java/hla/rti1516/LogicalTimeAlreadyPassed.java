package hla.rti1516;

/**
 * 
 * Public exception class LogicalTimeAlreadyPassed
 * 
 */

public final class LogicalTimeAlreadyPassed extends RTIexception {
	public LogicalTimeAlreadyPassed(String msg) {
		super(msg);
	}
}
