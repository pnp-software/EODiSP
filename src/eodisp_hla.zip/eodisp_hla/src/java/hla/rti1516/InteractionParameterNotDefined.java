package hla.rti1516;

/**
 * 
 * Public exception class InteractionParameterNotDefined
 * 
 */

public final class InteractionParameterNotDefined extends RTIexception {
	public InteractionParameterNotDefined(String msg) {
		super(msg);
	}
}
