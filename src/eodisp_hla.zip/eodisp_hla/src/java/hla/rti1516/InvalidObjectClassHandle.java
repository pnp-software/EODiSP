package hla.rti1516;

/**
 * 
 * Public exception class InvalidObjectClassHandle
 * 
 */

public final class InvalidObjectClassHandle extends RTIexception {
	public InvalidObjectClassHandle(String msg) {
		super(msg);
	}
}
