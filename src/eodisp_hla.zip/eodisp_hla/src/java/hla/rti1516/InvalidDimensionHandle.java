package hla.rti1516;

/**
 * 
 * Public exception class InvalidDimensionHandle
 * 
 */

public final class InvalidDimensionHandle extends RTIexception {
	public InvalidDimensionHandle(String msg) {
		super(msg);
	}
}
