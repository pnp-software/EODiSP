package hla.rti1516;

/**
 * 
 * Public exception class InvalidLookahead
 * 
 */

public final class InvalidLookahead extends RTIexception {
	public InvalidLookahead(String msg) {
		super(msg);
	}
}
