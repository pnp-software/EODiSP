package hla.rti1516;

/**
 * 
 * Public exception class ObjectInstanceNotKnown
 * 
 */

public final class ObjectInstanceNotKnown extends RTIexception {
	public ObjectInstanceNotKnown(String msg) {
		super(msg);
	}
}
