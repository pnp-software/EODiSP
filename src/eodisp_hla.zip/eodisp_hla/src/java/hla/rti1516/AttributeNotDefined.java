package hla.rti1516;

public final class AttributeNotDefined extends RTIexception {
	public AttributeNotDefined(String msg) {
		super(msg);
	}

	public AttributeNotDefined(InvalidAttributeHandle e) {
		super(e);
	}
}
