package hla.rti1516;

/**
 * 
 * Public exception class CouldNotDiscover
 * 
 */

public final class CouldNotDiscover extends RTIexception {
	public CouldNotDiscover(String msg) {
		super(msg);
	}
}
