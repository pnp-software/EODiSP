//File: InteractionRelevanceAdvisorySwitchIsOff.java
package hla.rti1516;

public final class InteractionRelevanceAdvisorySwitchIsOff extends RTIexception {
	public InteractionRelevanceAdvisorySwitchIsOff(String msg) {
		super(msg);
	}
}
// end InteractionRelevanceAdvisorySwitchIsOff

