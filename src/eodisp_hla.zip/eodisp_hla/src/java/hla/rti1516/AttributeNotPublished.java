package hla.rti1516;

/**
 * 
 * Public exception class AttributeNotPublished
 * 
 */

public final class AttributeNotPublished extends RTIexception {
	public AttributeNotPublished(String msg) {
		super(msg);
	}
}
