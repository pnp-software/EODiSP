package hla.rti1516;

/**
 * 
 * Public exception class FederateUnableToUseTime
 * 
 */

public final class FederateUnableToUseTime extends RTIexception {
	public FederateUnableToUseTime(String msg) {
		super(msg);
	}
}
