package hla.rti1516;

/**
 * 
 * Public exception class SynchronizationPointLabelNotAnnounced
 * 
 */

public final class SynchronizationPointLabelNotAnnounced extends RTIexception {
	public SynchronizationPointLabelNotAnnounced(String msg) {
		super(msg);
	}
}
