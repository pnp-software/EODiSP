package hla.rti1516;

/**
 * 
 * Public exception class InvalidTransportationType
 * 
 */

public final class InvalidTransportationType extends RTIexception {
	public InvalidTransportationType(String msg) {
		super(msg);
	}
}
