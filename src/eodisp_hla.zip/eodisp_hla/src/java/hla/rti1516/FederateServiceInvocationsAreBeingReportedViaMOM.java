package hla.rti1516;

/**
 * 
 * Public exception class FederateServiceInvocationsAreBeingReportedViaMOM
 * 
 */

public final class FederateServiceInvocationsAreBeingReportedViaMOM extends RTIexception {
	public FederateServiceInvocationsAreBeingReportedViaMOM(String msg) {
		super(msg);
	}
}
