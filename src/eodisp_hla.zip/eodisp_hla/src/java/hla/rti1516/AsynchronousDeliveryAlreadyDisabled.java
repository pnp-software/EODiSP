package hla.rti1516;

/**
 * Public exception class AsynchronousDeliveryAlreadyDisabled
 */
public final class AsynchronousDeliveryAlreadyDisabled extends RTIexception {
	public AsynchronousDeliveryAlreadyDisabled(String msg) {
		super(msg);
	}
}
