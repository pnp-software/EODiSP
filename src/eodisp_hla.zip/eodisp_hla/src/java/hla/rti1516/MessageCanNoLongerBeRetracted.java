package hla.rti1516;

/**
 * 
 * Public exception class MessageCanNoLongerBeRetracted
 * 
 */

public final class MessageCanNoLongerBeRetracted extends RTIexception {
	public MessageCanNoLongerBeRetracted(String msg) {
		super(msg);
	}
}
