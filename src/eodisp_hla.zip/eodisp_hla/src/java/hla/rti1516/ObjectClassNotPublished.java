package hla.rti1516;

/**
 * 
 * Public exception class ObjectClassNotPublished
 * 
 */

public final class ObjectClassNotPublished extends RTIexception {
	public ObjectClassNotPublished(String msg) {
		super(msg);
	}
}
