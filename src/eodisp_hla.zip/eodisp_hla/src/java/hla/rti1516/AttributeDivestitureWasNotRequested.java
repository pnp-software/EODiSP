package hla.rti1516;

/**
 * 
 * Public exception class AttributeDivestitureWasNotRequested
 * 
 */

public final class AttributeDivestitureWasNotRequested extends RTIexception {
	public AttributeDivestitureWasNotRequested(String msg) {
		super(msg);
	}
}
