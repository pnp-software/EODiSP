package hla.rti1516;

import java.io.IOException;

/**
 * Public exception class ErrorReadingFDD
 */
public final class ErrorReadingFDD extends RTIexception {
	public ErrorReadingFDD(String msg) {
		super(msg);
	}

	public ErrorReadingFDD() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ErrorReadingFDD(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ErrorReadingFDD(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	
}
