package hla.rti1516;

/**
 * 
 * Public exception class InvalidFederateHandle
 * 
 */

public final class InvalidServiceGroup extends RTIexception {
	public InvalidServiceGroup(String msg) {
		super(msg);
	}
}
