//File: AttributeRelevanceAdvisorySwitchIsOff.java
package hla.rti1516;

public final class AttributeRelevanceAdvisorySwitchIsOff extends RTIexception {
	public AttributeRelevanceAdvisorySwitchIsOff(String msg) {
		super(msg);
	}
}
// end AttributeRelevanceAdvisorySwitchIsOff

