package hla.rti1516;

/**
 * 
 * Public exception class RegionDoesNotContainSpecifiedDimension
 * 
 */

public final class RegionDoesNotContainSpecifiedDimension extends RTIexception {
	public RegionDoesNotContainSpecifiedDimension(String msg) {
		super(msg);
	}
}
