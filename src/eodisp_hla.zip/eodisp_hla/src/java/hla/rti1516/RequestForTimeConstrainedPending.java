package hla.rti1516;

/**
 * 
 * Public exception class RequestForTimeConstrainedPending
 * 
 */

public final class RequestForTimeConstrainedPending extends RTIexception {
	public RequestForTimeConstrainedPending(String msg) {
		super(msg);
	}
}
