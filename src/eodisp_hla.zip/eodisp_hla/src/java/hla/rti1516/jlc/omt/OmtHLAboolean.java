package hla.rti1516.jlc.omt;

import hla.rti1516.jlc.ByteWrapper;
import hla.rti1516.jlc.HLAboolean;

public class OmtHLAboolean extends AbstractDataElement implements HLAboolean {
	private final OmtHLAinteger32BE value;

	public OmtHLAboolean() {
		value = new OmtHLAinteger32BE(0);
	}

	public OmtHLAboolean(boolean value) {
		this.value = new OmtHLAinteger32BE(value ? 1 : 0);
	}

	public int getOctetBoundary() {
		return value.getOctetBoundary();
	}

	public void encode(ByteWrapper byteWrapper) {
		value.encode(byteWrapper);
	}

	public int getEncodedLength() {
		return value.getEncodedLength();
	}

	public final void decode(ByteWrapper byteWrapper) {
		value.decode(byteWrapper);
	}

	public boolean getValue() {
		return value.getValue() != 0;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		final OmtHLAboolean other = (OmtHLAboolean) obj;
		if (value == null) {
			if (other.value != null)
				return false;
		} else if (!value.equals(other.value))
			return false;
		return true;
	}

}
