package hla.rti1516.jlc.omt;

import hla.rti1516.jlc.ByteWrapper;
import hla.rti1516.jlc.HLAASCIIstring;

import java.io.UnsupportedEncodingException;

public class OmtHLAASCIIstring extends AbstractDataElement implements HLAASCIIstring {
	private String value;

	private static final String CHARSET_NAME = "ISO-8859-1";

	public OmtHLAASCIIstring() {
		value = "";
	}

	public OmtHLAASCIIstring(String s) {
		value = (s != null) ? s : "";
	}

	public void encode(ByteWrapper byteWrapper) {
		byteWrapper.align(getOctetBoundary());
		byte[] bytes;
		try {
			bytes = value.getBytes(CHARSET_NAME);
		} catch (UnsupportedEncodingException e) {
			bytes = value.getBytes();
		}
		byteWrapper.putInt(value.length());
		byteWrapper.put(bytes);
	}

	public final void decode(ByteWrapper byteWrapper) {
		byteWrapper.align(getOctetBoundary());
		int length = byteWrapper.getInt();
		byte[] bytes = new byte[length];
		byteWrapper.get(bytes);
		try {
			value = new String(bytes, CHARSET_NAME);
		} catch (UnsupportedEncodingException e) {
			value = "<INVALID>";
			throw new IllegalArgumentException("Cannot decode ASCII string");
		}
	}

	public int getEncodedLength() {
		return 4 + value.length();
	}

	public int getOctetBoundary() {
		return 4;
	}

	@Override
	public String toString() {
		return value;
	}

	public String getValue() {
		return value;
	}

	/** 
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}

	/** 
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final OmtHLAASCIIstring other = (OmtHLAASCIIstring) obj;
		if (value == null) {
			if (other.value != null)
				return false;
		} else if (!value.equals(other.value))
			return false;
		return true;
	}

	
}
