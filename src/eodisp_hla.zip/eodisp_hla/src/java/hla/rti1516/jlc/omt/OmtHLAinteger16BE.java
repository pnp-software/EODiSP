package hla.rti1516.jlc.omt;

import hla.rti1516.jlc.ByteWrapper;
import hla.rti1516.jlc.HLAinteger16BE;

public class OmtHLAinteger16BE extends AbstractDataElement implements HLAinteger16BE {
	private volatile short value;

	public OmtHLAinteger16BE(short value) {
		this.value = value;
	}

	public OmtHLAinteger16BE() {
		this.value = 0;
	}

	public int getOctetBoundary() {
		return 2;
	}

	public void encode(ByteWrapper byteWrapper) {
		byteWrapper.align(getOctetBoundary());
		byteWrapper.put((value >>> 8) & 0xFF);
		byteWrapper.put((value >>> 0) & 0xFF);
	}

	public int getEncodedLength() {
		return 2;
	}

	public final void decode(ByteWrapper byteWrapper) {
		byteWrapper.align(getOctetBoundary());
		short decoded = 0;
		decoded += (short) (byteWrapper.get() << 8);
		decoded += (short) (byteWrapper.get() << 0);
		this.value = decoded;
	}

	public short getValue() {
		return value;
	}

	/** 
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + value;
		return result;
	}

	/** 
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final OmtHLAinteger16BE other = (OmtHLAinteger16BE) obj;
		if (value != other.value)
			return false;
		return true;
	}
	
	
}
