package hla.rti1516.jlc.omt;

import hla.rti1516.jlc.*;

public class OmtHLAfloat64BE extends AbstractDataElement implements HLAfloat64BE {
	private volatile double value;

	public OmtHLAfloat64BE() {
		value = 0.0;
	}

	public OmtHLAfloat64BE(double value) {
		this.value = value;
	}

	public int getOctetBoundary() {
		return 4;
	}

	public void encode(ByteWrapper byteWrapper) {
		byteWrapper.align(getOctetBoundary());
		final long longBits = Double.doubleToLongBits(value);
		byteWrapper.put((int) (longBits >>> 56) & 0xFF);
		byteWrapper.put((int) (longBits >>> 48) & 0xFF);
		byteWrapper.put((int) (longBits >>> 40) & 0xFF);
		byteWrapper.put((int) (longBits >>> 32) & 0xFF);
		byteWrapper.put((int) (longBits >>> 24) & 0xFF);
		byteWrapper.put((int) (longBits >>> 16) & 0xFF);
		byteWrapper.put((int) (longBits >>> 8) & 0xFF);
		byteWrapper.put((int) (longBits >>> 0) & 0xFF);
	}

	public int getEncodedLength() {
		return 8;
	}

	public void decode(ByteWrapper byteWrapper) {
		byteWrapper.align(getOctetBoundary());
		long longBits = 0L;
		longBits += (long) byteWrapper.get() << 56;
		longBits += (long) byteWrapper.get() << 48;
		longBits += (long) byteWrapper.get() << 40;
		longBits += (long) byteWrapper.get() << 32;
		longBits += (long) byteWrapper.get() << 24;
		longBits += (long) byteWrapper.get() << 16;
		longBits += (long) byteWrapper.get() << 8;
		longBits += (long) byteWrapper.get() << 0;
		value = Double.longBitsToDouble(longBits);
	}

	public double getValue() {
		return value;
	}

	/** 
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(value);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	/** 
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final OmtHLAfloat64BE other = (OmtHLAfloat64BE) obj;
		if (Double.doubleToLongBits(value) != Double.doubleToLongBits(other.value))
			return false;
		return true;
	}

	
}
