package hla.rti1516.jlc.omt;

import hla.rti1516.jlc.*;

import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public class OmtHLAvariableArray extends AbstractDataElement implements HLAvariableArray {
	private final List<DataElement> elements = new ArrayList<DataElement>();

	private final DataElementFactory _elementFactory;

	public OmtHLAvariableArray() {
		_elementFactory = null;
	}

	public OmtHLAvariableArray(DataElementFactory elementFactory) {
		_elementFactory = elementFactory;
	}

	public OmtHLAvariableArray(DataElement[] momElements) {
		_elementFactory = null;
		elements.addAll(Arrays.asList(momElements));
	}

	public void addElement(DataElement dataElement) {
		elements.add(dataElement);
	}

	public int size() {
		return elements.size();
	}

	public DataElement get(int index) {
		return elements.get(index);
	}

	public Iterator iterator() {
		return elements.iterator();
	}

	public void encode(ByteWrapper byteWrapper) {
		byteWrapper.align(4);
		byteWrapper.putInt(elements.size());
		for (Iterator iterator = elements.iterator(); iterator.hasNext();) {
			DataElement dataElement = (DataElement) iterator.next();
			dataElement.encode(byteWrapper);
		}
	}

	public void decode(ByteWrapper byteWrapper) {
		byteWrapper.align(4);
		int decoded = byteWrapper.getInt();
		if (elements.size() != 0) {
			for (Iterator i = elements.iterator(); i.hasNext();) {
				DataElement dataElement = (DataElement) i.next();
				dataElement.decode(byteWrapper);
			}
		} else {
			for (int i = 0; i < decoded; i++) {
				elements.add(_elementFactory.createElement(i));
			}
		}
	}

	public int getEncodedLength() {
		int size = 4;
		for (Iterator iterator = elements.iterator(); iterator.hasNext();) {
			DataElement dataElement = (DataElement) iterator.next();
			while ((size % dataElement.getOctetBoundary()) != 0) {
				size += 1;
			}
			size += dataElement.getEncodedLength();
		}
		return size;
	}

	public int getOctetBoundary() {
		int boundary = 4; // Minimum is 4 for the count-element
		for (Iterator iterator = elements.iterator(); iterator.hasNext();) {
			DataElement dataElement = (DataElement) iterator.next();
			boundary = Math.max(boundary, dataElement.getOctetBoundary());
		}
		return boundary;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((_elementFactory == null) ? 0 : _elementFactory.hashCode());
		result = PRIME * result + ((elements == null) ? 0 : elements.hashCode());
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final OmtHLAvariableArray other = (OmtHLAvariableArray) obj;
		if (_elementFactory == null) {
			if (other._elementFactory != null)
				return false;
		} else if (!_elementFactory.equals(other._elementFactory))
			return false;
		if (elements == null) {
			if (other.elements != null)
				return false;
		} else if (!elements.equals(other.elements))
			return false;
		return true;
	}

}
