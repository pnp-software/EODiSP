package hla.rti1516.jlc.omt;

import hla.rti1516.jlc.ByteWrapper;
import hla.rti1516.jlc.HLAopaqueData;

import java.util.Arrays;
import java.util.Iterator;

public class OmtHLAopaqueData extends AbstractDataElement implements HLAopaqueData {
	private volatile byte[] bytes;

	public OmtHLAopaqueData() {
		this.bytes = new byte[0];
	}

	public OmtHLAopaqueData(byte[] bytes) {
		this.bytes = bytes;
	}

	/**
	 * Returns the number of components in this array.
	 * 
	 * @return the number of components in this array.
	 */
	public int size() {
		return bytes.length;
	}

	/**
	 * Returns the DataElement at the specified position in this array.
	 * 
	 * @param index
	 *            index of DataElement to return.
	 * @return DataElement at the specified index
	 */
	public byte get(int index) {
		return bytes[index];
	}

	/**
	 * Returns an iterator over the elements in this array in proper sequence.
	 * 
	 * @return an iterator over the elements in this array in proper sequence.
	 */
	public Iterator iterator() {
		return new Iterator() {
			private int _index = 0;

			public void remove() {
				throw new UnsupportedOperationException();
			}

			public boolean hasNext() {
				return _index < bytes.length;
			}

			public Object next() {
				return new Byte(bytes[_index++]);
			}
		};
	}

	public void encode(ByteWrapper byteWrapper) {
		byteWrapper.align(4);
		byteWrapper.putInt(bytes.length);
		byteWrapper.put(bytes);
	}

	public void decode(ByteWrapper byteWrapper) {
		byteWrapper.align(4);
		int encodedLength = byteWrapper.getInt();
		bytes = new byte[encodedLength];
		byteWrapper.get(bytes);
	}

	public int getEncodedLength() {
		return 4 + bytes.length;
	}

	public int getOctetBoundary() {
		return 4;
	}

	public byte[] getValue() {
		return bytes;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + Arrays.hashCode(bytes);
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final OmtHLAopaqueData other = (OmtHLAopaqueData) obj;
		if (!Arrays.equals(bytes, other.bytes))
			return false;
		return true;
	}
}
