package hla.rti1516.jlc;

import hla.rti1516.RTIambassador;
import hla.rti1516.RTIinternalError;

/**
 * Responsible to create an instance implementing the RTIambassador interface.
 */
public interface RtiFactory {
	/**
	 * Returns an object instance that implements the RTIambassador interface.
	 * 
	 * @return an object instance that implements the RTIambassador interface.
	 * @throws RTIinternalError
	 *             if, for any reason, the RTIambassador instance could not be
	 *             received.
	 */
	RTIambassador getRtiAmbassador() throws RTIinternalError;

	/**
	 * Returns the name of the RTI.
	 * 
	 * @return the name of the RTI.
	 */
	String RtiName();

	/**
	 * Returns the version of the RTI.
	 * 
	 * @return the version of the RTI.
	 */
	String RtiVersion();
}
