package hla.rti1516.jlc.omt;

import hla.rti1516.jlc.ByteWrapper;
import hla.rti1516.jlc.HLAunicodeString;

public class OmtHLAunicodeString extends AbstractDataElement implements HLAunicodeString {
	private volatile String value;

	public OmtHLAunicodeString() {
		value = "";
	}

	public OmtHLAunicodeString(String s) {
		value = (s != null) ? s : "";
	}

	public void encode(ByteWrapper byteWrapper) {
		byteWrapper.align(getOctetBoundary());
		byteWrapper.putInt(value.length());
		int len = value.length();
		for (int i = 0; i < len; i++) {
			int v = (int) value.charAt(i);
			byteWrapper.put((v >>> 8) & 0xFF);
			byteWrapper.put((v >>> 0) & 0xFF);
		}
	}

	public final void decode(ByteWrapper byteWrapper) {
		byteWrapper.align(getOctetBoundary());
		int length = byteWrapper.getInt();
		char[] chars = new char[length];
		for (int i = 0; i < length; i++) {
			int hi = byteWrapper.get();
			int lo = byteWrapper.get();
			chars[i] = (char) ((hi << 8) + (lo << 0));
		}
		value = new String(chars);
	}

	public int getEncodedLength() {
		return 4 + value.length() * 2;
	}

	public int getOctetBoundary() {
		return 4;
	}

	@Override
	public String toString() {
		return value;
	}

	public String getValue() {
		return value;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final OmtHLAunicodeString other = (OmtHLAunicodeString) obj;
		if (value == null) {
			if (other.value != null)
				return false;
		} else if (!value.equals(other.value))
			return false;
		return true;
	}

}
