package hla.rti1516.jlc.omt;

import hla.rti1516.jlc.ByteWrapper;
import hla.rti1516.jlc.HLAinteger32LE;

public class OmtHLAinteger32LE extends AbstractDataElement implements HLAinteger32LE {
	private volatile int value;

	public OmtHLAinteger32LE() {
		this.value = 0;
	}

	public OmtHLAinteger32LE(int value) {
		this.value = value;
	}

	public int getOctetBoundary() {
		return 4;
	}

	public void encode(ByteWrapper byteWrapper) {
		byteWrapper.align(getOctetBoundary());
		final int encoded = value;
		byteWrapper.put((encoded >>> 0) & 0xFF);
		byteWrapper.put((encoded >>> 8) & 0xFF);
		byteWrapper.put((encoded >>> 16) & 0xFF);
		byteWrapper.put((encoded >>> 24) & 0xFF);
	}

	public int getEncodedLength() {
		return 4;
	}

	public void decode(ByteWrapper byteWrapper) {
		byteWrapper.align(getOctetBoundary());
		int decoded = 0;
		decoded += (short) byteWrapper.get() << 0;
		decoded += (short) byteWrapper.get() << 8;
		decoded += (short) byteWrapper.get() << 16;
		decoded += (short) byteWrapper.get() << 24;
		value = decoded;
	}

	public int getValue() {
		return value;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + value;
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final OmtHLAinteger32LE other = (OmtHLAinteger32LE) obj;
		if (value != other.value)
			return false;
		return true;
	}

}
