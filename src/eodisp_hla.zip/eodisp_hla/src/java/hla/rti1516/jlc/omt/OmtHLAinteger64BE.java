package hla.rti1516.jlc.omt;

import hla.rti1516.jlc.ByteWrapper;
import hla.rti1516.jlc.HLAinteger64BE;

public class OmtHLAinteger64BE extends AbstractDataElement implements HLAinteger64BE {
	private volatile long value;

	public OmtHLAinteger64BE() {
		this.value = 0L;
	}

	public OmtHLAinteger64BE(long value) {
		this.value = value;
	}

	public int getOctetBoundary() {
		return 4;
	}

	public void encode(ByteWrapper byteWrapper) {
		byteWrapper.align(getOctetBoundary());
		long encoded = value;
		byteWrapper.put((int) (encoded >>> 56) & 0xFF);
		byteWrapper.put((int) (encoded >>> 48) & 0xFF);
		byteWrapper.put((int) (encoded >>> 40) & 0xFF);
		byteWrapper.put((int) (encoded >>> 32) & 0xFF);
		byteWrapper.put((int) (encoded >>> 24) & 0xFF);
		byteWrapper.put((int) (encoded >>> 16) & 0xFF);
		byteWrapper.put((int) (encoded >>> 8) & 0xFF);
		byteWrapper.put((int) (encoded >>> 0) & 0xFF);
	}

	public int getEncodedLength() {
		return 8;
	}

	public void decode(ByteWrapper byteWrapper) {
		byteWrapper.align(getOctetBoundary());
		long decoded = 0L;
		decoded += (long) byteWrapper.get() << 56;
		decoded += (long) byteWrapper.get() << 48;
		decoded += (long) byteWrapper.get() << 40;
		decoded += (long) byteWrapper.get() << 32;
		decoded += (long) byteWrapper.get() << 24;
		decoded += (long) byteWrapper.get() << 16;
		decoded += (long) byteWrapper.get() << 8;
		decoded += (long) byteWrapper.get() << 0;
		value = decoded;
	}

	public long getValue() {
		return value;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + (int) (value ^ (value >>> 32));
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final OmtHLAinteger64BE other = (OmtHLAinteger64BE) obj;
		if (value != other.value)
			return false;
		return true;
	}

}
