package hla.rti1516.jlc.omt;

import hla.rti1516.jlc.ByteWrapper;
import hla.rti1516.jlc.HLAhandle;

import java.util.Arrays;
import java.util.Iterator;

public class OmtHLAhandle extends AbstractDataElement implements HLAhandle {
	private volatile byte[] bytes;

	public OmtHLAhandle() {
		bytes = new byte[0];
	}

	public OmtHLAhandle(byte[] bytes) {
		this.bytes = bytes;
	}

	public int size() {
		return bytes.length;
	}

	public byte get(int index) {
		return bytes[index];
	}

	public Iterator iterator() {
		return new Iterator() {
			private int _index = 0;

			public void remove() {
				throw new UnsupportedOperationException();
			}

			public boolean hasNext() {
				return _index < bytes.length;
			}

			public Object next() {
				return new Byte(bytes[_index++]);
			}
		};
	}

	public void encode(ByteWrapper byteWrapper) {
		byteWrapper.align(4);
		byteWrapper.putInt(bytes.length);
		byteWrapper.put(bytes);
	}

	public void decode(ByteWrapper byteWrapper) {
		byteWrapper.align(4);
		int encodedLength = byteWrapper.getInt();
		bytes = new byte[encodedLength];
		byteWrapper.get(bytes);
	}

	public int getEncodedLength() {
		return 4 + bytes.length;
	}

	public int getOctetBoundary() {
		return 4;
	}

	public byte[] getValue() {
		return bytes;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + Arrays.hashCode(bytes);
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final OmtHLAhandle other = (OmtHLAhandle) obj;
		if (!Arrays.equals(bytes, other.bytes))
			return false;
		return true;
	}

}
