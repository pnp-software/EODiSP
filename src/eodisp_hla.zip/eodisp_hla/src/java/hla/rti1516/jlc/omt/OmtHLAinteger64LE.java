package hla.rti1516.jlc.omt;

import hla.rti1516.jlc.ByteWrapper;
import hla.rti1516.jlc.HLAinteger64LE;

public class OmtHLAinteger64LE extends AbstractDataElement implements HLAinteger64LE {
	private volatile long value;

	public OmtHLAinteger64LE() {
		this.value = 0L;
	}

	public OmtHLAinteger64LE(long value) {
		this.value = value;
	}

	public int getOctetBoundary() {
		return 4;
	}

	public void encode(ByteWrapper byteWrapper) {
		byteWrapper.align(getOctetBoundary());
		long encoded = value;
		byteWrapper.put((int) (encoded >>> 0) & 0xFF);
		byteWrapper.put((int) (encoded >>> 8) & 0xFF);
		byteWrapper.put((int) (encoded >>> 16) & 0xFF);
		byteWrapper.put((int) (encoded >>> 24) & 0xFF);
		byteWrapper.put((int) (encoded >>> 32) & 0xFF);
		byteWrapper.put((int) (encoded >>> 40) & 0xFF);
		byteWrapper.put((int) (encoded >>> 48) & 0xFF);
		byteWrapper.put((int) (encoded >>> 56) & 0xFF);
	}

	public int getEncodedLength() {
		return 8;
	}

	public void decode(ByteWrapper byteWrapper) {
		byteWrapper.align(getOctetBoundary());
		long decoded = 0L;
		decoded += (long) byteWrapper.get() << 0;
		decoded += (long) byteWrapper.get() << 8;
		decoded += (long) byteWrapper.get() << 16;
		decoded += (long) byteWrapper.get() << 24;
		decoded += (long) byteWrapper.get() << 32;
		decoded += (long) byteWrapper.get() << 40;
		decoded += (long) byteWrapper.get() << 48;
		decoded += (long) byteWrapper.get() << 56;
		value = decoded;
	}

	public long getValue() {
		return value;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + (int) (value ^ (value >>> 32));
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final OmtHLAinteger64LE other = (OmtHLAinteger64LE) obj;
		if (value != other.value)
			return false;
		return true;
	}

}
