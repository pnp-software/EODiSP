package hla.rti1516.jlc.omt;

import hla.rti1516.jlc.ByteWrapper;
import hla.rti1516.jlc.HLAoctet;

public class OmtHLAoctet extends AbstractDataElement implements HLAoctet {
	private volatile byte value;

	public OmtHLAoctet(byte value) {
		this.value = value;
	}

	public OmtHLAoctet() {
		value = 0;
	}

	public int getOctetBoundary() {
		return 1;
	}

	public void encode(ByteWrapper byteWrapper) {
		byteWrapper.align(getOctetBoundary());
		byteWrapper.put((value >>> 0) & 0xFF);
	}

	public int getEncodedLength() {
		return 1;
	}

	public final void decode(ByteWrapper byteWrapper) {
		byteWrapper.align(getOctetBoundary());
		value = (byte) byteWrapper.get();
	}

	public byte getValue() {
		return value;
	}

	/** 
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode() {
		return value;
	}

	/** 
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final OmtHLAoctet other = (OmtHLAoctet) obj;
		if (value != other.value)
			return false;
		return true;
	}
}
