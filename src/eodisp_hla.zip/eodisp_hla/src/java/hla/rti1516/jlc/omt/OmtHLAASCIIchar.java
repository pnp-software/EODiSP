package hla.rti1516.jlc.omt;

import hla.rti1516.jlc.ByteWrapper;
import hla.rti1516.jlc.HLAASCIIchar;

public class OmtHLAASCIIchar extends AbstractDataElement implements HLAASCIIchar {
	private final OmtHLAoctet value;

	public OmtHLAASCIIchar(byte value) {
		this.value = new OmtHLAoctet(value);
	}

	public OmtHLAASCIIchar() {
		value = new OmtHLAoctet();
	}

	public int getOctetBoundary() {
		return value.getOctetBoundary();
	}

	public void encode(ByteWrapper byteWrapper) {
		value.encode(byteWrapper);
	}

	public int getEncodedLength() {
		return value.getEncodedLength();
	}

	public void decode(ByteWrapper byteWrapper) {
		value.decode(byteWrapper);
	}

	public byte getValue() {
		return value.getValue();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final OmtHLAASCIIchar other = (OmtHLAASCIIchar) obj;
		if (value == null) {
			if (other.value != null)
				return false;
		} else if (!value.equals(other.value))
			return false;
		return true;
	}

}
