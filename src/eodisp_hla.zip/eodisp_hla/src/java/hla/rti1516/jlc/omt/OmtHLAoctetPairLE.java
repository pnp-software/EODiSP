package hla.rti1516.jlc.omt;

import hla.rti1516.jlc.ByteWrapper;
import hla.rti1516.jlc.HLAoctetPairLE;

public class OmtHLAoctetPairLE extends AbstractDataElement implements HLAoctetPairLE {
	private volatile short value;

	public OmtHLAoctetPairLE(short value) {
		this.value = value;
	}

	public OmtHLAoctetPairLE() {
		this.value = 0;
	}

	public int getOctetBoundary() {
		return 2;
	}

	public void encode(ByteWrapper byteWrapper) {
		byteWrapper.align(getOctetBoundary());
		byteWrapper.put((value >>> 0) & 0xFF);
		byteWrapper.put((value >>> 8) & 0xFF);
	}

	public int getEncodedLength() {
		return 2;
	}

	public final void decode(ByteWrapper byteWrapper) {
		byteWrapper.align(getOctetBoundary());
		short decoded = 0;
		decoded += (short) byteWrapper.get() << 0;
		decoded += (short) byteWrapper.get() << 8;
		value = decoded;
	}

	public short getValue() {
		return value;
	}

	/** 
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode() {
		return value;
	}

	/** 
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final OmtHLAoctetPairLE other = (OmtHLAoctetPairLE) obj;
		if (value != other.value)
			return false;
		return true;
	}
	
	
}
