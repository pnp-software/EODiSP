package hla.rti1516.jlc.omt;

import hla.rti1516.jlc.ByteWrapper;
import hla.rti1516.jlc.HLAfloat32BE;

public class OmtHLAfloat32BE extends AbstractDataElement implements HLAfloat32BE {
	private volatile float value;

	public OmtHLAfloat32BE() {
		value = 0.0f;
	}

	public OmtHLAfloat32BE(float value) {
		this.value = value;
	}

	public int getOctetBoundary() {
		return 4;
	}

	public void encode(ByteWrapper byteWrapper) {
		byteWrapper.align(getOctetBoundary());
		int intBits = Float.floatToIntBits(value);
		byteWrapper.putInt(intBits);
	}

	public int getEncodedLength() {
		return 4;
	}

	public void decode(ByteWrapper byteWrapper) {
		byteWrapper.align(getOctetBoundary());
		int intBits = byteWrapper.getInt();
		value = Float.intBitsToFloat(intBits);
	}

	public float getValue() {
		return value;
	}

	/** 
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + Float.floatToIntBits(value);
		return result;
	}

	/** 
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final OmtHLAfloat32BE other = (OmtHLAfloat32BE) obj;
		if (Float.floatToIntBits(value) != Float.floatToIntBits(other.value))
			return false;
		return true;
	}

	
}
