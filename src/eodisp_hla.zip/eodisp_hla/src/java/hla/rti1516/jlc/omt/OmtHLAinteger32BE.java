package hla.rti1516.jlc.omt;

import hla.rti1516.jlc.ByteWrapper;
import hla.rti1516.jlc.HLAinteger32BE;

public class OmtHLAinteger32BE extends AbstractDataElement implements HLAinteger32BE {
	private volatile int value;

	public OmtHLAinteger32BE() {
		this.value = 0;
	}

	public OmtHLAinteger32BE(int value) {
		this.value = value;
	}

	public int getOctetBoundary() {
		return 4;
	}

	public void encode(ByteWrapper byteWrapper) {
		byteWrapper.align(getOctetBoundary());
		byteWrapper.putInt(value);
	}

	public int getEncodedLength() {
		return 4;
	}

	public void decode(ByteWrapper byteWrapper) {
		byteWrapper.align(getOctetBoundary());
		value = byteWrapper.getInt();
	}

	public int getValue() {
		return value;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + value;
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final OmtHLAinteger32BE other = (OmtHLAinteger32BE) obj;
		if (value != other.value)
			return false;
		return true;
	}

}
