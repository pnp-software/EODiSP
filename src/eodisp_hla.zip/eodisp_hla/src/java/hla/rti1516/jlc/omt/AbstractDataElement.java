package hla.rti1516.jlc.omt;

import hla.rti1516.jlc.DataElement;
import hla.rti1516.jlc.ByteWrapper;

public abstract class AbstractDataElement implements DataElement {
	public byte[] toByteArray() {
		ByteWrapper byteWrapper = new ByteWrapper(getEncodedLength());
		encode(byteWrapper);
		return byteWrapper.array();
	}	
}
