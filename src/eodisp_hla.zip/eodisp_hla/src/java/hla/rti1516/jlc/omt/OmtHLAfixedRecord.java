package hla.rti1516.jlc.omt;

import hla.rti1516.jlc.ByteWrapper;
import hla.rti1516.jlc.DataElement;
import hla.rti1516.jlc.HLAfixedRecord;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class OmtHLAfixedRecord extends AbstractDataElement implements HLAfixedRecord {
	private final List<DataElement> fields = new ArrayList<DataElement>();

	public OmtHLAfixedRecord() {
	}

	public OmtHLAfixedRecord(DataElement dataElement) {
		add(dataElement);
	}

	public OmtHLAfixedRecord(DataElement dataElement1, DataElement dataElement2) {
		add(dataElement1);
		add(dataElement2);
	}

	public final void add(DataElement dataElement) {
		fields.add(dataElement);
	}

	public int size() {
		return fields.size();
	}

	public DataElement get(int index) {
		return fields.get(index);
	}

	public Iterator iterator() {
		return fields.iterator();
	}

	public int getOctetBoundary() {
		int boundary = 4; // Default to 4
		for (Iterator iterator = fields.iterator(); iterator.hasNext();) {
			DataElement dataElement = (DataElement) iterator.next();
			boundary = Math.max(boundary, dataElement.getOctetBoundary());
		}
		return boundary;
	}

	public void encode(ByteWrapper byteWrapper) {
		byteWrapper.align(getOctetBoundary());
		for (Iterator iterator = fields.iterator(); iterator.hasNext();) {
			DataElement dataElement = (DataElement) iterator.next();
			dataElement.encode(byteWrapper);
		}
	}

	public int getEncodedLength() {
		int size = 0;
		for (Iterator iterator = fields.iterator(); iterator.hasNext();) {
			DataElement dataElement = (DataElement) iterator.next();
			while ((size % dataElement.getOctetBoundary()) != 0) {
				size += 1;
			}
			size += dataElement.getEncodedLength();
		}
		return size;
	}

	public void decode(ByteWrapper byteWrapper) {
		for (Iterator iterator = fields.iterator(); iterator.hasNext();) {
			DataElement dataElement = (DataElement) iterator.next();
			dataElement.decode(byteWrapper);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((fields == null) ? 0 : fields.hashCode());
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final OmtHLAfixedRecord other = (OmtHLAfixedRecord) obj;
		if (fields == null) {
			if (other.fields != null)
				return false;
		} else if (!fields.equals(other.fields))
			return false;
		return true;
	}

}
