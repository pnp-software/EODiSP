package hla.rti1516.jlc;

import hla.rti1516.RTIinternalError;

import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.eodisp.hla.lrc.jlc.RtiFactoryImpl;

/**
 * Implementation of the RtiFactoryFactory class as defined in the SISO Standard
 * <i>SISO-STD-004.1-2004</i>.
 * 
 * @see <a
 *      href="http://www.sisostds.org/index.php?tg=fileman&idx=get&id=5&gr=Y&path=SISO+Products%2FSISO+Standards&file=SISO-STD-004.1-2004-Final.pdf">SISO-STD-004.1-2004.pdf</a>
 * 
 * 
 * @author ibirrer
 * @version $Id:$
 */
public class RtiFactoryFactory {
	private static final String SETTINGS_FILE = "RTI1516-list.properties";

	/**
	 * Returns an RtiFactory instance of the specified factory class. If no
	 * RtiFactory is associated with the specified name, the RTIinternalError
	 * exception shall be thrown.
	 * 
	 * @param factoryClassName
	 *            the fully qualified name of the factory class
	 * @return an instance of the RtiFactory class
	 * @throws RTIinternalError
	 *             If the given RtiFactory class could not be found,
	 *             instantiated or accessed.
	 */
	public static RtiFactory getRtiFactory(String factoryClassName) throws RTIinternalError {
		try {
			Class cls = Class.forName(factoryClassName);
			return (RtiFactory) cls.newInstance();
		} catch (ClassNotFoundException e) {
			throw new RTIinternalError("Cannot find class " + factoryClassName);
		} catch (InstantiationException e) {
			throw new RTIinternalError("Cannot instantiate class " + factoryClassName);
		} catch (IllegalAccessException e) {
			throw new RTIinternalError("Cannot access class " + factoryClassName);
		}
	}

	/**
	 * Returns an RtiFactory instance for the default RTI as specified in the
	 * stored settings. If no stored settings are available, or if no default
	 * RTI is specified in the stored settings then the RtiFactoryFactory may
	 * choose an RTI freely.
	 * 
	 * @return an RtiFactory. The default factory returned is:
	 *         <code>org.eodisp.erti.client.rti1516.jlc.ERTIFactory</code>.
	 * @throws RTIinternalError
	 *             If the Link compatibility settings file could not be read or
	 *             if the factory class setting could not be find for the
	 *             default RTI
	 */
	public static RtiFactory getRtiFactory() throws RTIinternalError {
		String userHomeDir = System.getProperty("user.home");
		File propertiesFile = new File(userHomeDir, SETTINGS_FILE);

		if (propertiesFile.exists()) {
			Properties properties = new Properties();
			try {
				InputStream is = new FileInputStream(propertiesFile);
				properties.load(is);
				is.close();
			} catch (IOException e) {
				throw new RTIinternalError("Error reading Link Compatibility settings file");
			}

			String defaultRTI = properties.getProperty("Default");
			if (defaultRTI != null) {
				String factoryClassName = properties.getProperty(defaultRTI + ".factory");
				if (factoryClassName == null) {
					throw new RTIinternalError("Cannot find factory class setting for default RTI");
				}

				return getRtiFactory(factoryClassName);
			}
		}

		// Provide a reasonable default if no setting found
		return getRtiFactory(RtiFactoryImpl.class.getName());
	}

	/**
	 * Returns a java.util.Map with RTI names as keys and factory class names as
	 * mapped values. The names and values are read from the stored settings.
	 * 
	 * @return A map of available RTIs
	 * @throws RTIinternalError
	 *             If the Link compatibility settings file could not be read
	 */
	public static Map getAvailableRtis() throws RTIinternalError {
		String userHomeDir = System.getProperty("user.home");
		File propertiesFile = new File(userHomeDir, SETTINGS_FILE);

		if (!propertiesFile.exists()) {
			throw new RTIinternalError("Cannot find file " + propertiesFile);
		}

		Properties properties = new Properties();
		try {
			InputStream is = new FileInputStream(propertiesFile);
			properties.load(is);
			is.close();
		} catch (IOException e) {
			throw new RTIinternalError("Error reading Link Compatibility settings file");
		}

		Map<String, String> map = new HashMap<String, String>();
		int index = 1;
		while (true) {
			String rtiName = properties.getProperty(index + ".name");
			String rtiFactory = properties.getProperty(index + ".factory");
			if (rtiName == null || rtiFactory == null) {
				break;
			}
			map.put(rtiName, rtiFactory);
			index++;
		}

		return map;
	}
}
