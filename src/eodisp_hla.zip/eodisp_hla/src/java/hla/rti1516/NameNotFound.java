package hla.rti1516;

/**
 * 
 * Public exception class NameNotFound
 * 
 */

public final class NameNotFound extends RTIexception {
	public NameNotFound(String msg) {
		super(msg);
	}
}
