package hla.rti1516;

/**
 * 
 * Public exception class TimeConstrainedAlreadyEnabled
 * 
 */

public final class TimeConstrainedAlreadyEnabled extends RTIexception {
	public TimeConstrainedAlreadyEnabled(String msg) {
		super(msg);
	}
}
