//File: AttributeScopeAdvisorySwitchIsOn.java
package hla.rti1516;

public final class AttributeScopeAdvisorySwitchIsOn extends RTIexception {
	public AttributeScopeAdvisorySwitchIsOn(String msg) {
		super(msg);
	}
}
// end AttributeScopeAdvisorySwitchIsOn

