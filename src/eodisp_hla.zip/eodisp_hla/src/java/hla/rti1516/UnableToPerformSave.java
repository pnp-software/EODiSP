package hla.rti1516;

/**
 * 
 * Public exception class UnableToPerformSave
 * 
 */

public final class UnableToPerformSave extends RTIexception {
	public UnableToPerformSave(String msg) {
		super(msg);
	}
}
