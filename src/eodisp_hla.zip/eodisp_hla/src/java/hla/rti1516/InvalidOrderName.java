package hla.rti1516;

/**
 * 
 * Public exception class InvalidOrderName
 * 
 */

public final class InvalidOrderName extends RTIexception {
	public InvalidOrderName(String msg) {
		super(msg);
	}
}
