package hla.rti1516;

/**
 * 
 * Public exception class SpecifiedSaveLabelDoesNotExist
 * 
 */

public final class SpecifiedSaveLabelDoesNotExist extends RTIexception {
	public SpecifiedSaveLabelDoesNotExist(String msg) {
		super(msg);
	}
}
