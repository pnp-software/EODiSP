package hla.rti1516;

/**
 * 
 * Public exception class RestoreNotRequested
 * 
 */

public final class RestoreNotRequested extends RTIexception {
	public RestoreNotRequested(String msg) {
		super(msg);
	}
}
