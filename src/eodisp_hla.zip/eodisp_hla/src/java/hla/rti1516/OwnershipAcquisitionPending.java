package hla.rti1516;

public final class OwnershipAcquisitionPending extends RTIexception {
	public OwnershipAcquisitionPending(String msg) {
		super(msg);
	}
}
