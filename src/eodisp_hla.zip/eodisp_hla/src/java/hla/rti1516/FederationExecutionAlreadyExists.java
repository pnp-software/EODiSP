package hla.rti1516;

/**
 * Public exception class FederationExecutionAlreadyExists
 */
public final class FederationExecutionAlreadyExists extends RTIexception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FederationExecutionAlreadyExists(String msg) {
		super(msg);
	}

	/**
	 * 
	 */
	public FederationExecutionAlreadyExists() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 */
	public FederationExecutionAlreadyExists(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cause
	 */
	public FederationExecutionAlreadyExists(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	
}
