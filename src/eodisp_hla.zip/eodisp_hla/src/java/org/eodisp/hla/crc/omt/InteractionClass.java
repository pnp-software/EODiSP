/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt;

import hla.rti1516.InteractionClassHandle;
import hla.rti1516.ObjectClassHandle;

import java.util.List;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

import org.eodisp.hla.crc.data.Federate;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Interaction Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.InteractionClass#getParameters <em>Parameters</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.InteractionClass#getSubClasses <em>Sub Classes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.InteractionClass#getDimensions <em>Dimensions</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.InteractionClass#getDimensionsNotes <em>Dimensions Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.InteractionClass#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.InteractionClass#getNameNotes <em>Name Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.InteractionClass#getOrder <em>Order</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.InteractionClass#getOrderNotes <em>Order Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.InteractionClass#getSemantics <em>Semantics</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.InteractionClass#getSemanticsNotes <em>Semantics Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.InteractionClass#getSharing <em>Sharing</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.InteractionClass#getSharingNotes <em>Sharing Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.InteractionClass#getTransportation <em>Transportation</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.InteractionClass#getTransportationNotes <em>Transportation Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.InteractionClass#getSubscribingFederates <em>Subscribing Federates</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.InteractionClass#getPublishingFederates <em>Publishing Federates</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eodisp.hla.crc.omt.OmtPackage#getInteractionClass()
 * @model extendedMetaData="name='InteractionClass' kind='elementOnly'"
 * @generated
 */
public interface InteractionClass extends EObject {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * Returns all parameters including parameters of all super classes.
	 * 
	 * @return all parameter of this and all super classes
	 */
	List getAllParameters();

	/**
	 * Returns the value of the '<em><b>Parameters</b></em>' containment reference list.
	 * The list contents are of type {@link org.eodisp.hla.crc.omt.Parameter}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Parameters</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Parameters</em>' containment reference list.
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getInteractionClass_Parameters()
	 * @model type="org.eodisp.hla.crc.omt.Parameter" containment="true"
	 *        extendedMetaData="kind='element' name='parameter' namespace='##targetNamespace'"
	 * @generated
	 */
	EList getParameters();

	/**
	 * Returns the value of the '<em><b>Sub Classes</b></em>' containment reference list.
	 * The list contents are of type {@link org.eodisp.hla.crc.omt.InteractionClass}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sub Classes</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sub Classes</em>' containment reference list.
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getInteractionClass_SubClasses()
	 * @model type="org.eodisp.hla.crc.omt.InteractionClass" containment="true"
	 *        extendedMetaData="kind='element' name='interactionClass' namespace='##targetNamespace'"
	 * @generated
	 */
	EList getSubClasses();

	/**
	 * The name of the HLA interaction root. See section 4.3.1 in IEEE 1516.2-2000,
	 * Page 25, first paragraph.
	 */
	public static final String HLA_INTERACTION_ROOT_NAME = "HLAinteractionRoot";

	/**
	 * Returns the handle of this interaction class.
	 * 
	 * @return the handle of this interaction class.
	 */
	InteractionClassHandle getHandle();

	/**
	 * Sets the handle of this interaction class. TODO: Should be set when
	 * constructing
	 * 
	 * @param interactionClassHandle
	 */
	void setHandle(InteractionClassHandle interactionClassHandle);

	/**
	 * Returns the super class of this interaction class.
	 * 
	 * @return the super class of this interaction class or null if this
	 *         interaction class does not have a super class
	 */
	InteractionClass getSuperClass();

	/**
	 * Returns all super classes in an ordered list. The first element in the
	 * list is the immediate super class, the last the top most class, which is
	 * always the HLAobjectRoot
	 * 
	 * @return all super classes of this interaction class
	 */
	List<InteractionClass> getAllSuperClasses();

	/**
	 * Returns the value of the '<em><b>Dimensions</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Dimensions</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dimensions</em>' attribute.
	 * @see #setDimensions(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getInteractionClass_Dimensions()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='dimensions' namespace='##targetNamespace'"
	 * @generated
	 */
	List getDimensions();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.InteractionClass#getDimensions <em>Dimensions</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Dimensions</em>' attribute.
	 * @see #getDimensions()
	 * @generated
	 */
	void setDimensions(List value);

	/**
	 * Returns the value of the '<em><b>Dimensions Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Dimensions Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dimensions Notes</em>' attribute.
	 * @see #setDimensionsNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getInteractionClass_DimensionsNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='dimensionsNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getDimensionsNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.InteractionClass#getDimensionsNotes <em>Dimensions Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Dimensions Notes</em>' attribute.
	 * @see #getDimensionsNotes()
	 * @generated
	 */
	void setDimensionsNotes(List value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getInteractionClass_Name()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKEN"
	 *        required="true" extendedMetaData="kind='attribute' name='name'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	String getName();

	/**
	 * Returns the fully qualified name of this interaction class. See section 10.1.1
	 * in IEEE 1516.1-2000.
	 * 
	 * @param omitInteractionRoot
	 *            if <code>true</code> omits the topmost super class
	 *            <code>HLAinteractionRoot</code>.
	 * @return the fully qualified name of this interaction class. Delimiter is a
	 *         dot(.).
	 */
	String getQualifiedName(boolean omitInteractionRoot);

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.InteractionClass#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Name Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name Notes</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name Notes</em>' attribute.
	 * @see #setNameNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getInteractionClass_NameNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='nameNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getNameNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.InteractionClass#getNameNotes <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name Notes</em>' attribute.
	 * @see #getNameNotes()
	 * @generated
	 */
	void setNameNotes(List value);

	/**
	 * Returns the value of the '<em><b>Order</b></em>' attribute. The
	 * default value is <code>"Receive"</code>. The literals are from the
	 * enumeration {@link org.eodisp.hla.crc.omt.OrderEnum}. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Order</em>' attribute isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Order</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.OrderEnum
	 * @see #isSetOrder()
	 * @see #unsetOrder()
	 * @see #setOrder(OrderEnum)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getInteractionClass_Order()
	 * @model default="Receive" unique="false" unsettable="true"
	 *        extendedMetaData="kind='attribute' name='order'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	OrderEnum getOrder();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.InteractionClass#getOrder <em>Order</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Order</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.OrderEnum
	 * @see #isSetOrder()
	 * @see #unsetOrder()
	 * @see #getOrder()
	 * @generated
	 */
	void setOrder(OrderEnum value);

	/**
	 * Unsets the value of the '{@link org.eodisp.hla.crc.omt.InteractionClass#getOrder <em>Order</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #isSetOrder()
	 * @see #getOrder()
	 * @see #setOrder(OrderEnum)
	 * @generated
	 */
	void unsetOrder();

	/**
	 * Returns whether the value of the '{@link org.eodisp.hla.crc.omt.InteractionClass#getOrder <em>Order</em>}' attribute is set.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return whether the value of the '<em>Order</em>' attribute is set.
	 * @see #unsetOrder()
	 * @see #getOrder()
	 * @see #setOrder(OrderEnum)
	 * @generated
	 */
	boolean isSetOrder();

	/**
	 * Returns the value of the '<em><b>Order Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Order Notes</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Order Notes</em>' attribute.
	 * @see #setOrderNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getInteractionClass_OrderNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='orderNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getOrderNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.InteractionClass#getOrderNotes <em>Order Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Order Notes</em>' attribute.
	 * @see #getOrderNotes()
	 * @generated
	 */
	void setOrderNotes(List value);

	/**
	 * Returns the value of the '<em><b>Semantics</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Semantics</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Semantics</em>' attribute.
	 * @see #setSemantics(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getInteractionClass_Semantics()
	 * @model unique="false"
	 *        dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='semantics'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	Object getSemantics();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.InteractionClass#getSemantics <em>Semantics</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Semantics</em>' attribute.
	 * @see #getSemantics()
	 * @generated
	 */
	void setSemantics(Object value);

	/**
	 * Returns the value of the '<em><b>Semantics Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Semantics Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Semantics Notes</em>' attribute.
	 * @see #setSemanticsNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getInteractionClass_SemanticsNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='semanticsNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSemanticsNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.InteractionClass#getSemanticsNotes <em>Semantics Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Semantics Notes</em>' attribute.
	 * @see #getSemanticsNotes()
	 * @generated
	 */
	void setSemanticsNotes(List value);

	/**
	 * Returns the value of the '<em><b>Sharing</b></em>' attribute. The
	 * default value is <code>"Publish"</code>. The literals are from the
	 * enumeration {@link org.eodisp.hla.crc.omt.SharingEnum}. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sharing</em>' attribute isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Sharing</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.SharingEnum
	 * @see #isSetSharing()
	 * @see #unsetSharing()
	 * @see #setSharing(SharingEnum)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getInteractionClass_Sharing()
	 * @model default="Publish" unique="false" unsettable="true"
	 *        extendedMetaData="kind='attribute' name='sharing'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	SharingEnum getSharing();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.InteractionClass#getSharing <em>Sharing</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sharing</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.SharingEnum
	 * @see #isSetSharing()
	 * @see #unsetSharing()
	 * @see #getSharing()
	 * @generated
	 */
	void setSharing(SharingEnum value);

	/**
	 * Unsets the value of the '{@link org.eodisp.hla.crc.omt.InteractionClass#getSharing <em>Sharing</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #isSetSharing()
	 * @see #getSharing()
	 * @see #setSharing(SharingEnum)
	 * @generated
	 */
	void unsetSharing();

	/**
	 * Returns whether the value of the '{@link org.eodisp.hla.crc.omt.InteractionClass#getSharing <em>Sharing</em>}' attribute is set.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return whether the value of the '<em>Sharing</em>' attribute is set.
	 * @see #unsetSharing()
	 * @see #getSharing()
	 * @see #setSharing(SharingEnum)
	 * @generated
	 */
	boolean isSetSharing();

	/**
	 * Returns the value of the '<em><b>Sharing Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sharing Notes</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sharing Notes</em>' attribute.
	 * @see #setSharingNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getInteractionClass_SharingNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='sharingNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSharingNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.InteractionClass#getSharingNotes <em>Sharing Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sharing Notes</em>' attribute.
	 * @see #getSharingNotes()
	 * @generated
	 */
	void setSharingNotes(List value);

	/**
	 * Returns the value of the '<em><b>Transportation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Transportation</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transportation</em>' attribute.
	 * @see #setTransportation(String)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getInteractionClass_Transportation()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKEN"
	 *        extendedMetaData="kind='attribute' name='transportation' namespace='##targetNamespace'"
	 * @generated
	 */
	String getTransportation();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.InteractionClass#getTransportation <em>Transportation</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Transportation</em>' attribute.
	 * @see #getTransportation()
	 * @generated
	 */
	void setTransportation(String value);

	/**
	 * Returns the value of the '<em><b>Transportation Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Transportation Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transportation Notes</em>' attribute.
	 * @see #setTransportationNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getInteractionClass_TransportationNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='transportationNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getTransportationNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.InteractionClass#getTransportationNotes <em>Transportation Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Transportation Notes</em>' attribute.
	 * @see #getTransportationNotes()
	 * @generated
	 */
	void setTransportationNotes(List value);

	/**
	 * Returns the value of the '<em><b>Subscribing Federates</b></em>' reference list.
	 * The list contents are of type {@link org.eodisp.hla.crc.data.Federate}.
	 * It is bidirectional and its opposite is '{@link org.eodisp.hla.crc.data.Federate#getSubscribedInteractions <em>Subscribed Interactions</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Subscribing Federates</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Subscribing Federates</em>' reference list.
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getInteractionClass_SubscribingFederates()
	 * @see org.eodisp.hla.crc.data.Federate#getSubscribedInteractions
	 * @model type="org.eodisp.hla.crc.data.Federate" opposite="subscribedInteractions" transient="true"
	 * @generated
	 */
	EList getSubscribingFederates();

	/**
	 * Returns the value of the '<em><b>Publishing Federates</b></em>' reference list.
	 * The list contents are of type {@link org.eodisp.hla.crc.data.Federate}.
	 * It is bidirectional and its opposite is '{@link org.eodisp.hla.crc.data.Federate#getPublishedInteractions <em>Published Interactions</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Publishing Federates</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Publishing Federates</em>' reference list.
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getInteractionClass_PublishingFederates()
	 * @see org.eodisp.hla.crc.data.Federate#getPublishedInteractions
	 * @model type="org.eodisp.hla.crc.data.Federate" opposite="publishedInteractions" transient="true"
	 * @generated
	 */
	EList getPublishingFederates();

} // InteractionClass
