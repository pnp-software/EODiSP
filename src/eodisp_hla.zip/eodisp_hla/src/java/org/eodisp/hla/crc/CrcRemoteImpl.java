/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.hla.crc;

import hla.rti1516.*;

import java.rmi.RemoteException;
import java.rmi.server.ExportException;

import org.apache.log4j.Logger;
import org.eodisp.hla.common.crc.CrcRemote;
import org.eodisp.hla.common.crc.FederationExecutionRemote;
import org.eodisp.hla.common.lrc.LrcHandle;
import org.eodisp.hla.common.lrc.LrcRemote;
import org.eodisp.hla.crc.application.CrcApplication;
import org.eodisp.util.AppRegistry;

/**
 * Implements the remote interface of the Central RTI Component (CRC). Delegates
 * to {@link Crc}. Methods are not synchronized because this class does not
 * change its state. Methods in {@link Crc} are synchronized though.
 * 
 * @author ibirrer
 * @version $Id:$
 * 
 * @UML -------------------------------------------------------------------
 * 
 * @navassoc 1 crc - Crc
 * 
 */
public class CrcRemoteImpl implements CrcRemote {

	private final Crc crc;

	/**
	 * 
	 * @param crc
	 *            the Crc to which this remote implementation class delegats to.
	 */
	public CrcRemoteImpl(Crc crc) {
		this.crc = crc;
	}

	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	static Logger logger = Logger.getLogger(CrcRemoteImpl.class);

	/**
	 * {@inheritDoc}
	 */
	public FederationExecutionRemote createFederationExecution(String federationExecutionName, byte[] fdd)
			throws FederationExecutionAlreadyExists, ErrorReadingFDD {
		
		FederationExecution federationExecution = crc.createFederationExecution(federationExecutionName, fdd);
		return federationExecution.getRemoteInterface();
	}

	/**
	 * {@inheritDoc}
	 */
	public void destroyFederationExecution(String federationExecutionName) throws FederatesCurrentlyJoined,
			FederationExecutionDoesNotExist {
		
		crc.destroyFederationExecution(federationExecutionName);
	}

	public FederateHandle joinFederationExecution(String federationExecutionName, String federateType,
			LrcHandle lrcHandle, MobileFederateServices serviceReferences) throws FederationExecutionDoesNotExist {
		
		return crc.joinFederationExecution(federationExecutionName, federateType, lrcHandle, serviceReferences);
	}

	/**
	 * {@inheritDoc}
	 */
	public FederationExecutionRemote getFederationExecution(String federationExecutionName) throws ExportException {
		
		FederationExecution federationExecution = crc.getFederationExecution(federationExecutionName);
		if (federationExecution == null) {
			return null;
		}
		return federationExecution.getRemoteInterface();
	}

	/**
	 * {@inheritDoc}
	 */
	public LrcHandle registerLrc(LrcRemote lrcRemote) {
		
		logger.debug(String.format("Register LRC [%s] ...", lrcRemote));
		return crc.registerLrc(lrcRemote);
	}

	/**
	 * {@inheritDoc}
	 */
	public void unregisterLrc(LrcHandle lrcHandle) {
		
		crc.unregisterLrc(lrcHandle);
	}

	/**
	 * {@inheritDoc}
	 */
	public void reset() {
		crc.reset();
	}

	/**
	 * {@inheritDoc}
	 */
	public synchronized void shutdownAndExit() {
		Thread t = new Thread() {
			@Override
			public void run() {
				try {
					logger.info("CRC shutdown and exit invoked from remote");
					CrcApplication crcApplication = (CrcApplication) AppRegistry.getRootApp();
					crcApplication.shutdown();
				} finally {
					
					System.exit(0);
				}
			}
		};
		t.start();
	}
}
