/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.hla.crc.omt.util;

import java.io.File;
import java.io.IOException;

import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.util.Diagnostician;
import org.eodisp.hla.crc.omt.*;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class OmtLoader {
	// Avoids subclassing and instantiation
	private OmtLoader() {
	}

	/**
	 * Loads the given file into an EMF resource. If any error occurs during the
	 * load, <code>System.exit(-1)</code> is called. Warnings are printed to
	 * {@link System#err}.
	 * 
	 * @param file
	 * @return
	 */
	public static Resource loadOmtFromFile(File file) {
		OmtResourceFactoryImpl fact = new OmtResourceFactoryImpl();
		Resource resource = fact.createResource(URI.createFileURI(file.getAbsolutePath()));
		try {
			resource.load(null);
			if (!resource.getErrors().isEmpty()) {
				String newline = String.format("%n");
				StringBuilder msg = new StringBuilder();
				for (Object diagnostic : resource.getErrors()) {
					msg.append(((Diagnostic) diagnostic).getMessage());
					msg.append(newline);
				}
				System.err.printf("Error while loading OMT file: %n%s%n", msg);
				System.exit(-1);
			}

			if (!resource.getWarnings().isEmpty()) {
				String newline = String.format("%n");
				StringBuilder msg = new StringBuilder();
				for (Object diagnostic : resource.getWarnings()) {
					msg.append(((Diagnostic) diagnostic).getMessage());
					msg.append(newline);
				}
				System.err.printf("Warnings while loading OMT file: %n%s%n", msg);
			}

		} catch (IOException e) {
			System.err.printf("Could not read OMT file: %s %n", e.getMessage());
			System.exit(-1);
		}

		DocumentRoot documentRoot = (DocumentRoot) resource.getContents().get(0);
		String validateResult = validateObject(documentRoot);
		if (validateResult != null) {
			System.err.printf("The OMT file is not valid:  %n%s%n", validateResult);
			System.exit(-1);
		}

		ObjectModel objectModel = documentRoot.getObjectModel();

		/*
		 * The root object class must always be HLAobjectRoot, (See section
		 * 4.2.1 in IEEE 1516.2-2000, Page 21, first paragraph)
		 */
		final Objects objects = objectModel.getObjects();
		if (objects != null) {
			ObjectClass hlaObjectRoot = (ObjectClass) objects.getObjectClass().get(0);
			if (hlaObjectRoot == null || !hlaObjectRoot.getName().equals(ObjectClass.HLA_OBJECT_ROOT_NAME)) {
				System.err.printf(
						"The OMT file is not valid:  The root object class must be: %s",
						ObjectClass.HLA_OBJECT_ROOT_NAME);
				System.exit(-1);
			}
		}
		/*
		 * The root object class must always be HLAobjectRoot, (See section
		 * 4.3.1 in IEEE 1516.2-2000, Page 25, first paragraph)
		 */
		final Interactions interactions = objectModel.getInteractions();
		if (interactions != null) {
			InteractionClass interactionClass = (InteractionClass) interactions.getInteractionClass().get(0);
			if (interactionClass == null
					|| !interactionClass.getName().equals(InteractionClass.HLA_INTERACTION_ROOT_NAME)) {
				System.err.printf(
						"The OMT file is not valid:  The root interaction class must be: %s",
						InteractionClass.HLA_INTERACTION_ROOT_NAME);
				System.exit(-1);
			}
		}

		return resource;
	}

	/**
	 * @param eObject
	 *            the object to be validated
	 * @return null if validation is OK, otherwise the message of each
	 *         validation object separated by newlines
	 */
	private static String validateObject(EObject eObject) {
		String msg = null;
		Diagnostic diagnostic = Diagnostician.INSTANCE.validate(eObject);

		if (diagnostic.getSeverity() == Diagnostic.ERROR || diagnostic.getSeverity() == Diagnostic.WARNING) {
			String newline = String.format("%n");
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(diagnostic.getMessage());
			for (Object childDiagnostic : diagnostic.getChildren()) {
				stringBuilder.append(((Diagnostic) childDiagnostic).getMessage());
				stringBuilder.append(newline);
			}
			msg = stringBuilder.toString();
		}
		return msg;
	}
}
