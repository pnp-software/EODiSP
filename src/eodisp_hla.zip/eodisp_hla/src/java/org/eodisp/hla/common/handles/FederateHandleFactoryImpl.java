package org.eodisp.hla.common.handles;

import hla.rti1516.*;
import hla.rti1516.jlc.ByteWrapper;
import hla.rti1516.jlc.HLAinteger32BE;
import hla.rti1516.jlc.omt.OmtEncoderFactory;

/**
 * Use {@link hla.rti.RTIambassador#getFederateHandleFactory()} to retrieve an
 * instance of this class.
 * 
 * @author ibirrer
 */
public class FederateHandleFactoryImpl implements FederateHandleFactory {

	public FederateHandleFactoryImpl() {
		super();
	}

	public FederateHandle decode(byte[] buffer, int offset) throws CouldNotDecode, FederateNotExecutionMember {
		ByteWrapper byteWrapper = new ByteWrapper(buffer, offset);
		HLAinteger32BE decoded = OmtEncoderFactory.getInstance().createHLAinteger32BE();
		decoded.decode(byteWrapper);
		return new FederateHandleImpl(decoded.getValue());
	}
}
