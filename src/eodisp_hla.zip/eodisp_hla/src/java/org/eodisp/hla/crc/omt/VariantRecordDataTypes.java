/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Variant Record Data Types</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.VariantRecordDataTypes#getVariantRecordData <em>Variant Record Data</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eodisp.hla.crc.omt.OmtPackage#getVariantRecordDataTypes()
 * @model extendedMetaData="name='VariantRecordDataTypes' kind='elementOnly'"
 * @generated
 */
public interface VariantRecordDataTypes extends EObject {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * Returns the value of the '<em><b>Variant Record Data</b></em>' containment reference list.
	 * The list contents are of type {@link org.eodisp.hla.crc.omt.VariantRecordData}.
	 * <!-- begin-user-doc
	 * -->
	 * <p>
	 * If the meaning of the '<em>Variant Record Data</em>' containment
	 * reference list isn't clear, there really should be more of a description
	 * here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Variant Record Data</em>' containment reference list.
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getVariantRecordDataTypes_VariantRecordData()
	 * @model type="org.eodisp.hla.crc.omt.VariantRecordData" containment="true" required="true"
	 *        extendedMetaData="kind='element' name='variantRecordData' namespace='##targetNamespace'"
	 * @generated
	 */
	EList getVariantRecordData();

} // VariantRecordDataTypes
