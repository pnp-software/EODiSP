package org.eodisp.hla.common.handles;

import hla.rti1516.DimensionHandleSet;
import hla.rti1516.DimensionHandleSetFactory;

public class DimensionHandleSetFactoryImpl implements DimensionHandleSetFactory {
	public DimensionHandleSet create() {
		return new DimensionHandleSetImpl();
	}
}
