/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.hla.crc.omt.util;

import java.io.File;
import java.io.IOException;
import java.util.*;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eodisp.hla.crc.omt.*;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class SomMerger {
	private DocumentRoot fom = null;

	private List<String> errors = new ArrayList<String>();

	public SomMerger() {
	}

	public List<String> getErrors() {
		return errors;
	}

	public synchronized void merge(final DocumentRoot som) {
		if (fom == null) {
			fom = (DocumentRoot) EcoreUtil.copy(som);
			return;
		}
		// Create indexes
		final ObjectModelIndexer fomIndex = new ObjectModelIndexer(fom.getObjectModel());
		OmtSwitch omtSwitch = new OmtSwitch() {

			/**
			 * {@inheritDoc}
			 */
			
			public Object caseObjectClass(ObjectClass somClass) {
				ObjectClass fomClass = fomIndex.getObjectClass(somClass.getQualifiedName(false));
				if (fomClass != null) {
					List<Attribute> somAttributes = somClass.getAttributes();
					List<Attribute> fomAttributes = fomClass.getAttributes();
					if (somAttributes.isEmpty()) {
						/* Empty classes from the SOM are not merged at all */
						return null;
					} else if (fomAttributes.isEmpty()) {
						/*
						 * If the FOM object class does not contain any
						 * attributes, just copy all attributes from the SOM to
						 * the FOM
						 */
						fomClass.getAttributes().addAll(EcoreUtil.copyAll(somAttributes));
					} else if (somAttributes.size() != fomAttributes.size() && !somAttributes.isEmpty()
							&& !fomAttributes.isEmpty()) {
						/*
						 * If number of attributes is not equal in the SOM and
						 * the FOM, merge nothing and add an error
						 */
						errors.add(String.format(
								"The number of attributes of the equal object "
										+ "classes %s are not equal in the SOMs to be merged. (%d and %d) ",
								somClass,
								fomAttributes.size(),
								somAttributes.size()));
					} else {
						Map<String, Attribute> fomAttributeMap = getAttributeMap(fomAttributes);

						for (Attribute somAttribute : somAttributes) {
							Attribute fomAttribute = fomAttributeMap.get(somAttribute.getName());
							if (fomAttribute == null) {
								/*
								 * The attribute names of the SOM and FOM are
								 * not all equal
								 */
								errors
										.add(String
												.format(
														"The attribute %s is only available in SOM %s. The attribute will not be merged.",
														somAttribute.getQualifiedName(true),
														som.getObjectModel().getName()));
								continue;
							}
							/* Merge attribute sharing */
							fomAttribute.setSharing(getMergedSharingEnum(fomAttribute.getSharing(), somAttribute
									.getSharing()));
						}

						/* Merge Object class sharing */
						fomClass.setSharing(getMergedSharingEnum(fomClass.getSharing(), somClass.getSharing()));
					}
				} else {
					ObjectClass originalSuperClass = fomIndex.getObjectClass(somClass.getSuperClass().getQualifiedName(
							false));
					if (originalSuperClass != null) {
						originalSuperClass.getSubClasses().add(EcoreUtil.copy(somClass));
					}
				}
				return null;
			}

			/**
			 * {@inheritDoc}
			 */
			@Override
			public Object caseInteractionClass(InteractionClass somClass) {
				InteractionClass fomClass = fomIndex.getInteractionClass(somClass.getQualifiedName(false));
				if (fomClass != null) {
					List<Parameter> somParameters = somClass.getParameters();
					List<Parameter> fomParameters = fomClass.getParameters();
					if (somParameters.isEmpty()) {
						/* Empty classes from the SOM are not merged at all */
						return null;
					} else if (fomParameters.isEmpty()) {
						/*
						 * If the FOM interaction class does not contain any
						 * parameters, just copy all paramters from the SOM
						 */
						Collection newParameters = EcoreUtil.copyAll(somParameters);
						fomClass.getParameters().addAll(newParameters);
					} else if (somParameters.size() != fomParameters.size() && !somParameters.isEmpty()
							&& !fomParameters.isEmpty()) {
						/*
						 * If number of parameters is not equal in the SOM and
						 * the FOM, merge nothing and add an error
						 */
						errors.add(String.format(
								"The number of parameters of the equal interaction "
										+ "class %s are not equal in the SOMs to be merged. (%d and %d) ",
								somClass,
								fomParameters.size(),
								somParameters.size()));
					} else {
						/* Same number of parameters in SOM and FOM: merge! */
						// Map<String, Parameter> somParameterMap =
						// getParameterMap(somParameters);
						Map<String, Parameter> fomParameterMap = getParameterMap(fomParameters);

						for (Parameter somParameter : somParameters) {
							Parameter fomParameter = fomParameterMap.get(somParameter.getName());
							if (fomParameter == null) {
								/*
								 * The parameter names of the SOM and FOM are
								 * not all equal
								 */
								errors
										.add(String
												.format(
														"The parameter %s.%s is only available in SOM %s. The parameter will not be merged.",
														somClass.getQualifiedName(true),
														somParameter.getName(),
														som.getObjectModel().getName()));
								continue;
							}
							// TODO check data types and other features
						}
					}

				} else {
					InteractionClass originalSuperInteraction = fomIndex.getInteractionClass(somClass
							.getSuperClass()
							.getQualifiedName(false));
					if (originalSuperInteraction != null) {
						originalSuperInteraction.getSubClasses().add(EcoreUtil.copy(somClass));
					}
				}
				return null;
			}

			@Override
			public Object caseDataTypes(DataTypes object) {
				if (fom.getObjectModel().getDataTypes() == null) {
					fom.getObjectModel().setDataTypes((DataTypes) EcoreUtil.copy(object));
				}
				return null;
			}

			@Override
			public Object caseBasicDataRepresentations(BasicDataRepresentations basicDataRepresentations) {
				if (fom.getObjectModel().getDataTypes().getBasicDataRepresentations() == null) {
					fom.getObjectModel().getDataTypes().setBasicDataRepresentations(
							(BasicDataRepresentations) EcoreUtil.copy(basicDataRepresentations));
				}
				return null;
			}

			@Override
			public Object caseBasicData(BasicData somBasicData) {
				List<BasicData> fomBasicDataList = fom
						.getObjectModel()
						.getDataTypes()
						.getBasicDataRepresentations()
						.getBasicData();
				for (BasicData fomBasicData : fomBasicDataList) {
					if (fomBasicData.getName().equals(somBasicData.getName())) {
						/* basic data is already defined in FOM */
						return null;
					}
				}
				fomBasicDataList.add((BasicData) EcoreUtil.copy(somBasicData));
				return null;
			}

			@Override
			public Object caseSimpleDataTypes(SimpleDataTypes somSimpleDataTypes) {
				if (fom.getObjectModel().getDataTypes().getSimpleDataTypes() == null) {
					fom.getObjectModel().getDataTypes().setSimpleDataTypes(
							(SimpleDataTypes) EcoreUtil.copy(somSimpleDataTypes));
				}
				return null;
			}

			@Override
			public Object caseSimpleData(SimpleData somSimpleData) {
				List<SimpleData> fomSimpleDataList = fom
						.getObjectModel()
						.getDataTypes()
						.getSimpleDataTypes()
						.getSimpleData();
				for (SimpleData fomSimpleData : fomSimpleDataList) {
					if (fomSimpleData.getName().equals(somSimpleData.getName())) {
						/* simple data is already defined in FOM */
						return null;
					}
				}

				fomSimpleDataList.add((SimpleData) EcoreUtil.copy(somSimpleData));
				return null;
			}
			
			@Override
			public Object caseEnumeratedDataTypes(EnumeratedDataTypes somEnumeratedDataType) {
				if (fom.getObjectModel().getDataTypes().getEnumeratedDataTypes() == null) {
					fom.getObjectModel().getDataTypes().setEnumeratedDataTypes(
							(EnumeratedDataTypes) EcoreUtil.copy(somEnumeratedDataType));
				}
				return null;
			}

			@Override
			public Object caseEnumeratedData(EnumeratedData somEnumeratedData) {
				List<EnumeratedData> fomEnumeratedDataList = fom.getObjectModel().getDataTypes().getEnumeratedDataTypes().getEnumeratedData();
				for (EnumeratedData fomEnumeratedData : fomEnumeratedDataList) {
					if( fomEnumeratedData.getName().equals(somEnumeratedData.getName()) ) {
						/* enumerated data is already defined in FOM */
						return null;
					}	
				}
				fomEnumeratedDataList.add((EnumeratedData) EcoreUtil.copy(somEnumeratedData));
				return null;
			}
			
			
			@Override
			public Object caseArrayDataTypes(ArrayDataTypes object) {
				if (fom.getObjectModel().getDataTypes().getArrayDataTypes() == null) {
					fom.getObjectModel().getDataTypes().setArrayDataTypes((ArrayDataTypes) EcoreUtil.copy(object));
				}
				return null;
			}
			
			@Override
			public Object caseArrayData(ArrayData somArrayData) {
				List<ArrayData> fomArrayDataList = fom.getObjectModel().getDataTypes().getArrayDataTypes().getArrayData();
				for (ArrayData fomArrayData : fomArrayDataList) {
					if( fomArrayData.getName().equals(somArrayData.getName())) {
						/* array data is already defined in FOM */
						return null;
					}
				}
				fomArrayDataList.add((ArrayData) EcoreUtil.copy(somArrayData));
				return null;
			}

			@Override
			public Object caseFixedRecordDataTypes(FixedRecordDataTypes object) {
				if (fom.getObjectModel().getDataTypes().getFixedRecordDataTypes() == null) {
					fom.getObjectModel().getDataTypes().setFixedRecordDataTypes(
							(FixedRecordDataTypes) EcoreUtil.copy(object));
				}
				return null;
			}
			
			@Override
			public Object caseFixedRecordData(FixedRecordData somFixedRecordData) {
				List<FixedRecordData> fomFixedRecordDataList= fom.getObjectModel().getDataTypes().getFixedRecordDataTypes().getFixedRecordData();
				for (FixedRecordData fomFixedRecordData : fomFixedRecordDataList) {
					if( fomFixedRecordData.getName().equals(somFixedRecordData.getName()) ) {
						/* fixed record data is already defined in FOM */
						return null;
					}
				}
				fomFixedRecordDataList.add((FixedRecordData) EcoreUtil.copy(somFixedRecordData));
				return null;
			}

			@Override
			public Object caseVariantRecordDataTypes(VariantRecordDataTypes object) {
				if (fom.getObjectModel().getDataTypes().getVariantRecordDataTypes() == null) {
					fom.getObjectModel().getDataTypes().setVariantRecordDataTypes(
							(VariantRecordDataTypes) EcoreUtil.copy(object));
				}
				return null;
			}
			
			@Override
			public Object caseVariantRecordData(VariantRecordData somVariantRecordData) {
				List<VariantRecordData> fomVariantRecordDataList = fom.getObjectModel().getDataTypes().getVariantRecordDataTypes().getVariantRecordData();
				for (VariantRecordData fomVariantRecordData : fomVariantRecordDataList) {
					if( fomVariantRecordData.getName().equals(somVariantRecordData.getName()) ) {
						/* variant record data is already defined in FOM */
						return null;
					}
				}
				fomVariantRecordDataList.add((VariantRecordData) EcoreUtil.copy(somVariantRecordData));
				return null;
			}

		};

		// Iterate over all model elements
		Iterator it = som.eAllContents();
		while (it.hasNext()) {
			final EObject nextObject = (EObject) it.next();
			omtSwitch.doSwitch(nextObject);
		}
	}

	public DocumentRoot getFom() {
		return fom;
	}

	/**
	 * @param originalParameters
	 */
	private static String[] getParameterNames(List<Parameter> parameters) {
		String[] result = new String[parameters.size()];
		int i = 0;
		for (Parameter param : parameters) {
			result[i++] = param.getName();
		}
		return result;
	}

	private static Map<String, Parameter> getParameterMap(List<Parameter> parameters) {
		Map<String, Parameter> result = new HashMap<String, Parameter>(parameters.size());
		for (Parameter param : parameters) {
			result.put(param.getName(), param);
		}
		return result;
	}

	/**
	 * @param originalParameters
	 */
	private static String[] getAttributeNames(List<Attribute> attributes) {
		String[] result = new String[attributes.size()];
		int i = 0;
		for (Attribute attribute : attributes) {
			result[i++] = attribute.getName();
		}
		return result;
	}

	private static Map<String, Attribute> getAttributeMap(List<Attribute> attributes) {
		Map<String, Attribute> result = new HashMap<String, Attribute>(attributes.size());
		for (Attribute attr : attributes) {
			result.put(attr.getName(), attr);
		}
		return result;
	}

	public static void main(String[] args) {
		SomMerger merger = new SomMerger();
		if (args.length < 2) {
			System.err.printf("Usage: java %s <somfile> [<somfile> ...] <fomfile>%n", SomMerger.class.getName());
			System.exit(-1);
		}

		File resultingFom = null;

		for (int i = 0; i < args.length; i++) {
			String arg = args[i];
			if ((i + 1) < args.length) {
				File somFile = new File(arg);
				Resource resource = OmtLoader.loadOmtFromFile(somFile);
				DocumentRoot documentRoot = (DocumentRoot) resource.getContents().get(0);
				merger.merge(documentRoot);
			} else {
				resultingFom = new File(arg);
			}
		}

		if (!merger.getErrors().isEmpty()) {
			System.err.printf("Errors during merge: %s%n", merger.getErrors());
		}
		System.out.println(Util.toString(merger.getFom().getObjectModel()));

		OmtResourceFactoryImpl fact = new OmtResourceFactoryImpl();

		Resource resource = fact.createResource(URI.createFileURI(resultingFom.getAbsolutePath()));
		resource.getContents().add(merger.getFom());
		try {
			resource.save(null);
			System.out.printf("Saved FOM at: %s%n", resource.getURI());
		} catch (IOException e) {
			System.err.printf("Error saving FOM: %s%n", e);
		}
	}

	/**
	 * Returns the bit flags of a sharing attributes:
	 * 
	 * <table border="1">
	 * <tr>
	 * <th>&nbsp;</th>
	 * <th>P</th>
	 * <th>S</th>
	 * <th>Integer Value</th>
	 * </tr>
	 * <tr>
	 * <td>Neither</td>
	 * <td>0</td>
	 * <td>0</td>
	 * <td align="right">0</td>
	 * </tr>
	 * <tr>
	 * <td>Subscribe</td>
	 * <td>0</td>
	 * <td>1</td>
	 * <td align="right">1</td>
	 * </tr>
	 * <tr>
	 * <td>Publish</td>
	 * <td>1</td>
	 * <td>0</td>
	 * <td align="right">2</td>
	 * </tr>
	 * <tr>
	 * <td>PublisSubscribe</td>
	 * <td>1</td>
	 * <td>1</td>
	 * <td align="right">3</td>
	 * </tr>
	 * </table>
	 * 
	 * @param sharingEnum
	 * @return
	 */
	private static int getBitFlag(SharingEnum sharingEnum) {
		switch (sharingEnum.getValue()) {
		case SharingEnum.NEITHER:
			return 0;
		case SharingEnum.SUBSCRIBE:
			return 1;
		case SharingEnum.PUBLISH:
			return 2;
		case SharingEnum.PUBLISH_SUBSCRIBE:
			return 3;

		default:
			throw new IllegalArgumentException("Illegar SharingEnum: " + sharingEnum);
		}
	}

	private static SharingEnum toSharingEnum(int bitFlags) {
		switch (bitFlags) {
		case 0:
			return SharingEnum.NEITHER_LITERAL;
		case 1:
			return SharingEnum.SUBSCRIBE_LITERAL;
		case 2:
			return SharingEnum.PUBLISH_LITERAL;
		case 3:
			return SharingEnum.PUBLISH_SUBSCRIBE_LITERAL;

		default:
			throw new IllegalArgumentException("Illegar SharingEnum bit flags: " + bitFlags);
		}
	}

	private static SharingEnum getMergedSharingEnum(SharingEnum sharingEnum1, SharingEnum sharingEnum2) {
		return toSharingEnum(getBitFlag(sharingEnum1) | getBitFlag(sharingEnum2));
	}

}
