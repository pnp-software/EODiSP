/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.data.impl;

import hla.rti1516.AttributeNotPublished;
import hla.rti1516.FederateHandle;
import java.util.Collection;

import hla.rti1516.ObjectClassNotPublished;

import java.util.*;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.UniqueEList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentWithInverseEList;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;
import org.eodisp.hla.common.lrc.LrcHandle;

import org.eodisp.hla.common.lrc.LrcRemote;
import org.eodisp.hla.crc.FederationExecution;
import org.eodisp.hla.crc.data.DataPackage;
import org.eodisp.hla.crc.data.Federate;
import org.eodisp.hla.crc.data.ObjectInstance;
import org.eodisp.hla.crc.omt.Attribute;
import org.eodisp.hla.crc.omt.InteractionClass;
import org.eodisp.hla.crc.omt.OmtPackage;

import org.eodisp.hla.crc.omt.*;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Federate</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.data.impl.FederateImpl#getRegisteredObjectInstances <em>Registered Object Instances</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.data.impl.FederateImpl#getSubscribedAttributes <em>Subscribed Attributes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.data.impl.FederateImpl#getSubscribedInteractions <em>Subscribed Interactions</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.data.impl.FederateImpl#getPublishedAttributes <em>Published Attributes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.data.impl.FederateImpl#getPublishedInteractions <em>Published Interactions</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.data.impl.FederateImpl#getLrcHandle <em>Lrc Handle</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.data.impl.FederateImpl#getHandle <em>Handle</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.data.impl.FederateImpl#getFederationExecution <em>Federation Execution</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.data.impl.FederateImpl#getPublishedObjectClasses <em>Published Object Classes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.data.impl.FederateImpl#getSubscribedObjectClasses <em>Subscribed Object Classes</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class FederateImpl extends EObjectImpl implements Federate {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The cached value of the '{@link #getRegisteredObjectInstances() <em>Registered Object Instances</em>}' containment reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getRegisteredObjectInstances()
	 * @generated
	 * @ordered
	 */
	protected EList registeredObjectInstances = null;

	/**
	 * The cached value of the '{@link #getSubscribedAttributes() <em>Subscribed Attributes</em>}' reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSubscribedAttributes()
	 * @generated
	 * @ordered
	 */
	protected EList subscribedAttributes = null;

	/**
	 * The cached value of the '{@link #getSubscribedInteractions() <em>Subscribed Interactions</em>}' reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSubscribedInteractions()
	 * @generated
	 * @ordered
	 */
	protected EList subscribedInteractions = null;

	/**
	 * The cached value of the '{@link #getPublishedAttributes() <em>Published Attributes</em>}' reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getPublishedAttributes()
	 * @generated
	 * @ordered
	 */
	protected EList publishedAttributes = null;

	/**
	 * The cached value of the '{@link #getPublishedInteractions() <em>Published Interactions</em>}' reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getPublishedInteractions()
	 * @generated
	 * @ordered
	 */
	protected EList publishedInteractions = null;

	/**
	 * The default value of the '{@link #getLrcHandle() <em>Lrc Handle</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLrcHandle()
	 * @generated
	 * @ordered
	 */
	protected static final LrcHandle LRC_HANDLE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLrcHandle() <em>Lrc Handle</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLrcHandle()
	 * @generated
	 * @ordered
	 */
	protected LrcHandle lrcHandle = LRC_HANDLE_EDEFAULT;

	/**
	 * The default value of the '{@link #getHandle() <em>Handle</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getHandle()
	 * @generated
	 * @ordered
	 */
	protected static final FederateHandle HANDLE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getHandle() <em>Handle</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getHandle()
	 * @generated
	 * @ordered
	 */
	protected FederateHandle handle = HANDLE_EDEFAULT;

	/**
	 * The default value of the '{@link #getFederationExecution() <em>Federation Execution</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getFederationExecution()
	 * @generated
	 * @ordered
	 */
	protected static final FederationExecution FEDERATION_EXECUTION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getFederationExecution() <em>Federation Execution</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getFederationExecution()
	 * @generated
	 * @ordered
	 */
	protected FederationExecution federationExecution = FEDERATION_EXECUTION_EDEFAULT;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected FederateImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return DataPackage.Literals.FEDERATE;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EList getRegisteredObjectInstances() {
		if (registeredObjectInstances == null) {
			registeredObjectInstances = new EObjectContainmentWithInverseEList(
					ObjectInstance.class,
					this,
					DataPackage.FEDERATE__REGISTERED_OBJECT_INSTANCES,
					DataPackage.OBJECT_INSTANCE__REGISTERING_FEDERATE);
		}
		return registeredObjectInstances;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EList getSubscribedAttributes() {
		if (subscribedAttributes == null) {
			subscribedAttributes = new EObjectWithInverseResolvingEList.ManyInverse(
					Attribute.class,
					this,
					DataPackage.FEDERATE__SUBSCRIBED_ATTRIBUTES,
					OmtPackage.ATTRIBUTE__SUBSCRIBING_FEDERATES);
		}
		return subscribedAttributes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EList getSubscribedInteractions() {
		if (subscribedInteractions == null) {
			subscribedInteractions = new EObjectWithInverseResolvingEList.ManyInverse(
					InteractionClass.class,
					this,
					DataPackage.FEDERATE__SUBSCRIBED_INTERACTIONS,
					OmtPackage.INTERACTION_CLASS__SUBSCRIBING_FEDERATES);
		}
		return subscribedInteractions;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EList getPublishedAttributes() {
		if (publishedAttributes == null) {
			publishedAttributes = new EObjectWithInverseResolvingEList.ManyInverse(
					Attribute.class,
					this,
					DataPackage.FEDERATE__PUBLISHED_ATTRIBUTES,
					OmtPackage.ATTRIBUTE__PUBLISHING_FEDERATES);
		}
		return publishedAttributes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EList getPublishedInteractions() {
		if (publishedInteractions == null) {
			publishedInteractions = new EObjectWithInverseResolvingEList.ManyInverse(
					InteractionClass.class,
					this,
					DataPackage.FEDERATE__PUBLISHED_INTERACTIONS,
					OmtPackage.INTERACTION_CLASS__PUBLISHING_FEDERATES);
		}
		return publishedInteractions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LrcHandle getLrcHandle() {
		return lrcHandle;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLrcHandle(LrcHandle newLrcHandle) {
		LrcHandle oldLrcHandle = lrcHandle;
		lrcHandle = newLrcHandle;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					DataPackage.FEDERATE__LRC_HANDLE,
					oldLrcHandle,
					lrcHandle));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public FederateHandle getHandle() {
		return handle;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setHandle(FederateHandle newHandle) {
		FederateHandle oldHandle = handle;
		handle = newHandle;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DataPackage.FEDERATE__HANDLE, oldHandle, handle));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public FederationExecution getFederationExecution() {
		return federationExecution;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setFederationExecution(FederationExecution newFederationExecution) {
		FederationExecution oldFederationExecution = federationExecution;
		federationExecution = newFederationExecution;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					DataPackage.FEDERATE__FEDERATION_EXECUTION,
					oldFederationExecution,
					federationExecution));
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated not
	 */
	public EList getPublishedObjectClasses() {
		// Replaced UniqueEList with Set. Set is much faster
		Set<ObjectClass> publishedObjectClasses = new HashSet<ObjectClass>();
		for (Iterator iter = getPublishedAttributes().iterator(); iter.hasNext();) {
			Attribute attribute = (Attribute) iter.next();
			publishedObjectClasses.add(attribute.getObjectClass());
		}
		return new BasicEList.UnmodifiableEList(publishedObjectClasses.size(), publishedObjectClasses.toArray());
	}

	/**
	 *  {@inheritDoc}
	 * 
	 * @generated not
	 */
	public EList getSubscribedObjectClasses() {
		// Replaced UniqueEList with Set. Set is much faster
		Set<ObjectClass> subscribedObjectClasses = new HashSet<ObjectClass>();
		for (Iterator iter = getSubscribedAttributes().iterator(); iter.hasNext();) {
			Attribute attribute = (Attribute) iter.next();
			subscribedObjectClasses.add(attribute.getObjectClass());
		}
		return new BasicEList.UnmodifiableEList(subscribedObjectClasses.size(), subscribedObjectClasses.toArray());
	}

	/**
	 * <!-- begin-user-doc --> // * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case DataPackage.FEDERATE__REGISTERED_OBJECT_INSTANCES:
			return ((InternalEList) getRegisteredObjectInstances()).basicAdd(otherEnd, msgs);
		case DataPackage.FEDERATE__SUBSCRIBED_ATTRIBUTES:
			return ((InternalEList) getSubscribedAttributes()).basicAdd(otherEnd, msgs);
		case DataPackage.FEDERATE__SUBSCRIBED_INTERACTIONS:
			return ((InternalEList) getSubscribedInteractions()).basicAdd(otherEnd, msgs);
		case DataPackage.FEDERATE__PUBLISHED_ATTRIBUTES:
			return ((InternalEList) getPublishedAttributes()).basicAdd(otherEnd, msgs);
		case DataPackage.FEDERATE__PUBLISHED_INTERACTIONS:
			return ((InternalEList) getPublishedInteractions()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case DataPackage.FEDERATE__REGISTERED_OBJECT_INSTANCES:
			return ((InternalEList) getRegisteredObjectInstances()).basicRemove(otherEnd, msgs);
		case DataPackage.FEDERATE__SUBSCRIBED_ATTRIBUTES:
			return ((InternalEList) getSubscribedAttributes()).basicRemove(otherEnd, msgs);
		case DataPackage.FEDERATE__SUBSCRIBED_INTERACTIONS:
			return ((InternalEList) getSubscribedInteractions()).basicRemove(otherEnd, msgs);
		case DataPackage.FEDERATE__PUBLISHED_ATTRIBUTES:
			return ((InternalEList) getPublishedAttributes()).basicRemove(otherEnd, msgs);
		case DataPackage.FEDERATE__PUBLISHED_INTERACTIONS:
			return ((InternalEList) getPublishedInteractions()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case DataPackage.FEDERATE__REGISTERED_OBJECT_INSTANCES:
			return getRegisteredObjectInstances();
		case DataPackage.FEDERATE__SUBSCRIBED_ATTRIBUTES:
			return getSubscribedAttributes();
		case DataPackage.FEDERATE__SUBSCRIBED_INTERACTIONS:
			return getSubscribedInteractions();
		case DataPackage.FEDERATE__PUBLISHED_ATTRIBUTES:
			return getPublishedAttributes();
		case DataPackage.FEDERATE__PUBLISHED_INTERACTIONS:
			return getPublishedInteractions();
		case DataPackage.FEDERATE__LRC_HANDLE:
			return getLrcHandle();
		case DataPackage.FEDERATE__HANDLE:
			return getHandle();
		case DataPackage.FEDERATE__FEDERATION_EXECUTION:
			return getFederationExecution();
		case DataPackage.FEDERATE__PUBLISHED_OBJECT_CLASSES:
			return getPublishedObjectClasses();
		case DataPackage.FEDERATE__SUBSCRIBED_OBJECT_CLASSES:
			return getSubscribedObjectClasses();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case DataPackage.FEDERATE__REGISTERED_OBJECT_INSTANCES:
			getRegisteredObjectInstances().clear();
			getRegisteredObjectInstances().addAll((Collection) newValue);
			return;
		case DataPackage.FEDERATE__SUBSCRIBED_ATTRIBUTES:
			getSubscribedAttributes().clear();
			getSubscribedAttributes().addAll((Collection) newValue);
			return;
		case DataPackage.FEDERATE__SUBSCRIBED_INTERACTIONS:
			getSubscribedInteractions().clear();
			getSubscribedInteractions().addAll((Collection) newValue);
			return;
		case DataPackage.FEDERATE__PUBLISHED_ATTRIBUTES:
			getPublishedAttributes().clear();
			getPublishedAttributes().addAll((Collection) newValue);
			return;
		case DataPackage.FEDERATE__PUBLISHED_INTERACTIONS:
			getPublishedInteractions().clear();
			getPublishedInteractions().addAll((Collection) newValue);
			return;
		case DataPackage.FEDERATE__LRC_HANDLE:
			setLrcHandle((LrcHandle) newValue);
			return;
		case DataPackage.FEDERATE__HANDLE:
			setHandle((FederateHandle) newValue);
			return;
		case DataPackage.FEDERATE__FEDERATION_EXECUTION:
			setFederationExecution((FederationExecution) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
		case DataPackage.FEDERATE__REGISTERED_OBJECT_INSTANCES:
			getRegisteredObjectInstances().clear();
			return;
		case DataPackage.FEDERATE__SUBSCRIBED_ATTRIBUTES:
			getSubscribedAttributes().clear();
			return;
		case DataPackage.FEDERATE__SUBSCRIBED_INTERACTIONS:
			getSubscribedInteractions().clear();
			return;
		case DataPackage.FEDERATE__PUBLISHED_ATTRIBUTES:
			getPublishedAttributes().clear();
			return;
		case DataPackage.FEDERATE__PUBLISHED_INTERACTIONS:
			getPublishedInteractions().clear();
			return;
		case DataPackage.FEDERATE__LRC_HANDLE:
			setLrcHandle(LRC_HANDLE_EDEFAULT);
			return;
		case DataPackage.FEDERATE__HANDLE:
			setHandle(HANDLE_EDEFAULT);
			return;
		case DataPackage.FEDERATE__FEDERATION_EXECUTION:
			setFederationExecution(FEDERATION_EXECUTION_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case DataPackage.FEDERATE__REGISTERED_OBJECT_INSTANCES:
			return registeredObjectInstances != null && !registeredObjectInstances.isEmpty();
		case DataPackage.FEDERATE__SUBSCRIBED_ATTRIBUTES:
			return subscribedAttributes != null && !subscribedAttributes.isEmpty();
		case DataPackage.FEDERATE__SUBSCRIBED_INTERACTIONS:
			return subscribedInteractions != null && !subscribedInteractions.isEmpty();
		case DataPackage.FEDERATE__PUBLISHED_ATTRIBUTES:
			return publishedAttributes != null && !publishedAttributes.isEmpty();
		case DataPackage.FEDERATE__PUBLISHED_INTERACTIONS:
			return publishedInteractions != null && !publishedInteractions.isEmpty();
		case DataPackage.FEDERATE__LRC_HANDLE:
			return LRC_HANDLE_EDEFAULT == null ? lrcHandle != null : !LRC_HANDLE_EDEFAULT.equals(lrcHandle);
		case DataPackage.FEDERATE__HANDLE:
			return HANDLE_EDEFAULT == null ? handle != null : !HANDLE_EDEFAULT.equals(handle);
		case DataPackage.FEDERATE__FEDERATION_EXECUTION:
			return FEDERATION_EXECUTION_EDEFAULT == null ? federationExecution != null : !FEDERATION_EXECUTION_EDEFAULT
					.equals(federationExecution);
		case DataPackage.FEDERATE__PUBLISHED_OBJECT_CLASSES:
			return !getPublishedObjectClasses().isEmpty();
		case DataPackage.FEDERATE__SUBSCRIBED_OBJECT_CLASSES:
			return !getSubscribedObjectClasses().isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated not
	 */
	public String toString() {
		if (eIsProxy())
			return super.toString();
		return String.format("Federate [handle=%s, execution=%s]", getHandle(), getFederationExecution().getName());
	}

	public void checkPublication(ObjectClass objectClass) throws ObjectClassNotPublished {
		if (!getPublishedObjectClasses().contains(objectClass)) {
			throw new ObjectClassNotPublished(
					String
							.format(
									"The object class '%s' has not been published by the federate '%s' and can therefore not be registered by this federate.",
									objectClass.getQualifiedName(false),
									this.toString()));
		}
	}

	public void checkPublication(Set<Attribute> attributes) throws AttributeNotPublished {
		if (!getPublishedAttributes().containsAll(attributes)) {
			Set<Attribute> notPublishedAttributes = new HashSet<Attribute>(attributes);
			notPublishedAttributes.removeAll(publishedAttributes);

			throw new AttributeNotPublished(
					String
							.format(
									"The object attributes '%s' have not been published by the federate '%s' and can therefore not be registered by this federate.",
									Arrays.toString(notPublishedAttributes.toArray()),
									this.toString()));
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean ownsAttributes(ObjectInstance objectInstance, Set<Attribute> attributes) {
		return getRegisteredObjectInstances().contains(objectInstance);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean ownsAttributes() {
		return !getRegisteredObjectInstances().isEmpty();
	}

} // FederateImpl
