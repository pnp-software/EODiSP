package org.eodisp.hla.common.handles;

import hla.rti1516.AttributeHandleSet;
import hla.rti1516.AttributeHandleSetFactory;

public class AttributeHandleSetFactoryImpl implements AttributeHandleSetFactory {
	public AttributeHandleSet create() {
		return new AttributeHandleSetImpl();
	}
}
