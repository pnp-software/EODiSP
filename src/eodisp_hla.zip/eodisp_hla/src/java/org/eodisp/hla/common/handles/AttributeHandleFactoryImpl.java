package org.eodisp.hla.common.handles;

import hla.rti1516.*;

/**
 * Use {@link hla.rti.RTIambassador#getFederateHandleFactory()} to retrieve an
 * instance of this class.
 * 
 * @author ibirrer
 */
public class AttributeHandleFactoryImpl implements AttributeHandleFactory {

	public AttributeHandleFactoryImpl() {
		super();
	}

	public AttributeHandle decode(byte[] buffer, int offset)
			throws CouldNotDecode, FederateNotExecutionMember {
		// TODO
		// return new AttributeHandleImpl(buffer, offset);
		return null;

	}
}
