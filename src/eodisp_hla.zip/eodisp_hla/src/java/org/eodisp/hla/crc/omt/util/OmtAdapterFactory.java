/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt.util;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

import org.eodisp.hla.crc.omt.*;

/**
 * <!-- begin-user-doc --> The <b>Adapter Factory</b> for the model. It
 * provides an adapter <code>createXXX</code> method for each class of the
 * model. <!-- end-user-doc -->
 * @see org.eodisp.hla.crc.omt.OmtPackage
 * @generated
 */
public class OmtAdapterFactory extends AdapterFactoryImpl {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The cached model package.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected static OmtPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * @generated
	 */
	public OmtAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = OmtPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc --> This implementation returns <code>true</code>
	 * if the object is either the model's package or is an instance object of
	 * the model. <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch the delegates to the <code>createXXX</code> methods. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected OmtSwitch modelSwitch = new OmtSwitch() {
		public Object caseAcquisitionRequestTag(AcquisitionRequestTag object) {
			return createAcquisitionRequestTagAdapter();
		}

		public Object caseAlternative(Alternative object) {
			return createAlternativeAdapter();
		}

		public Object caseArrayData(ArrayData object) {
			return createArrayDataAdapter();
		}

		public Object caseArrayDataTypes(ArrayDataTypes object) {
			return createArrayDataTypesAdapter();
		}

		public Object caseAttribute(Attribute object) {
			return createAttributeAdapter();
		}

		public Object caseBasicData(BasicData object) {
			return createBasicDataAdapter();
		}

		public Object caseBasicDataRepresentations(BasicDataRepresentations object) {
			return createBasicDataRepresentationsAdapter();
		}

		public Object caseDataTypes(DataTypes object) {
			return createDataTypesAdapter();
		}

		public Object caseDeleteRemoveTag(DeleteRemoveTag object) {
			return createDeleteRemoveTagAdapter();
		}

		public Object caseDimension(Dimension object) {
			return createDimensionAdapter();
		}

		public Object caseDimensions(Dimensions object) {
			return createDimensionsAdapter();
		}

		public Object caseDivestitureCompletionTag(DivestitureCompletionTag object) {
			return createDivestitureCompletionTagAdapter();
		}

		public Object caseDivestitureRequestTag(DivestitureRequestTag object) {
			return createDivestitureRequestTagAdapter();
		}

		public Object caseDocumentRoot(DocumentRoot object) {
			return createDocumentRootAdapter();
		}

		public Object caseEnumeratedData(EnumeratedData object) {
			return createEnumeratedDataAdapter();
		}

		public Object caseEnumeratedDataTypes(EnumeratedDataTypes object) {
			return createEnumeratedDataTypesAdapter();
		}

		public Object caseEnumerator(Enumerator object) {
			return createEnumeratorAdapter();
		}

		public Object caseField(Field object) {
			return createFieldAdapter();
		}

		public Object caseFixedRecordData(FixedRecordData object) {
			return createFixedRecordDataAdapter();
		}

		public Object caseFixedRecordDataTypes(FixedRecordDataTypes object) {
			return createFixedRecordDataTypesAdapter();
		}

		public Object caseInteractionClass(InteractionClass object) {
			return createInteractionClassAdapter();
		}

		public Object caseInteractions(Interactions object) {
			return createInteractionsAdapter();
		}

		public Object caseLookahead(Lookahead object) {
			return createLookaheadAdapter();
		}

		public Object caseNote(Note object) {
			return createNoteAdapter();
		}

		public Object caseNotes(Notes object) {
			return createNotesAdapter();
		}

		public Object caseObjectClass(ObjectClass object) {
			return createObjectClassAdapter();
		}

		public Object caseObjectModel(ObjectModel object) {
			return createObjectModelAdapter();
		}

		public Object caseObjects(Objects object) {
			return createObjectsAdapter();
		}

		public Object caseParameter(Parameter object) {
			return createParameterAdapter();
		}

		public Object caseRequestUpdateTag(RequestUpdateTag object) {
			return createRequestUpdateTagAdapter();
		}

		public Object caseSendReceiveTag(SendReceiveTag object) {
			return createSendReceiveTagAdapter();
		}

		public Object caseSimpleData(SimpleData object) {
			return createSimpleDataAdapter();
		}

		public Object caseSimpleDataTypes(SimpleDataTypes object) {
			return createSimpleDataTypesAdapter();
		}

		public Object caseSwitches(Switches object) {
			return createSwitchesAdapter();
		}

		public Object caseSynchronization(Synchronization object) {
			return createSynchronizationAdapter();
		}

		public Object caseSynchronizations(Synchronizations object) {
			return createSynchronizationsAdapter();
		}

		public Object caseTags(Tags object) {
			return createTagsAdapter();
		}

		public Object caseTime(Time object) {
			return createTimeAdapter();
		}

		public Object caseTimeStamp(TimeStamp object) {
			return createTimeStampAdapter();
		}

		public Object caseTransportation(Transportation object) {
			return createTransportationAdapter();
		}

		public Object caseTransportations(Transportations object) {
			return createTransportationsAdapter();
		}

		public Object caseUpdateReflectTag(UpdateReflectTag object) {
			return createUpdateReflectTagAdapter();
		}

		public Object caseVariantRecordData(VariantRecordData object) {
			return createVariantRecordDataAdapter();
		}

		public Object caseVariantRecordDataTypes(VariantRecordDataTypes object) {
			return createVariantRecordDataTypesAdapter();
		}

		public Object defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	public Adapter createAdapter(Notifier target) {
		return (Adapter) modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.AcquisitionRequestTag <em>Acquisition Request Tag</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.AcquisitionRequestTag
	 * @generated
	 */
	public Adapter createAcquisitionRequestTagAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.Alternative <em>Alternative</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.Alternative
	 * @generated
	 */
	public Adapter createAlternativeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.ArrayData <em>Array Data</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.ArrayData
	 * @generated
	 */
	public Adapter createArrayDataAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.ArrayDataTypes <em>Array Data Types</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.ArrayDataTypes
	 * @generated
	 */
	public Adapter createArrayDataTypesAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.Attribute <em>Attribute</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.Attribute
	 * @generated
	 */
	public Adapter createAttributeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.BasicData <em>Basic Data</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.BasicData
	 * @generated
	 */
	public Adapter createBasicDataAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.BasicDataRepresentations <em>Basic Data Representations</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.BasicDataRepresentations
	 * @generated
	 */
	public Adapter createBasicDataRepresentationsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.DataTypes <em>Data Types</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.DataTypes
	 * @generated
	 */
	public Adapter createDataTypesAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.DeleteRemoveTag <em>Delete Remove Tag</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.DeleteRemoveTag
	 * @generated
	 */
	public Adapter createDeleteRemoveTagAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.Dimension <em>Dimension</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.Dimension
	 * @generated
	 */
	public Adapter createDimensionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.Dimensions <em>Dimensions</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.Dimensions
	 * @generated
	 */
	public Adapter createDimensionsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.DivestitureCompletionTag <em>Divestiture Completion Tag</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.DivestitureCompletionTag
	 * @generated
	 */
	public Adapter createDivestitureCompletionTagAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.DivestitureRequestTag <em>Divestiture Request Tag</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.DivestitureRequestTag
	 * @generated
	 */
	public Adapter createDivestitureRequestTagAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.DocumentRoot <em>Document Root</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.DocumentRoot
	 * @generated
	 */
	public Adapter createDocumentRootAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.EnumeratedData <em>Enumerated Data</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.EnumeratedData
	 * @generated
	 */
	public Adapter createEnumeratedDataAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.EnumeratedDataTypes <em>Enumerated Data Types</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.EnumeratedDataTypes
	 * @generated
	 */
	public Adapter createEnumeratedDataTypesAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.Enumerator <em>Enumerator</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.Enumerator
	 * @generated
	 */
	public Adapter createEnumeratorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.Field <em>Field</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.Field
	 * @generated
	 */
	public Adapter createFieldAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.FixedRecordData <em>Fixed Record Data</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.FixedRecordData
	 * @generated
	 */
	public Adapter createFixedRecordDataAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.FixedRecordDataTypes <em>Fixed Record Data Types</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.FixedRecordDataTypes
	 * @generated
	 */
	public Adapter createFixedRecordDataTypesAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.InteractionClass <em>Interaction Class</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.InteractionClass
	 * @generated
	 */
	public Adapter createInteractionClassAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.Interactions <em>Interactions</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.Interactions
	 * @generated
	 */
	public Adapter createInteractionsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.Lookahead <em>Lookahead</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.Lookahead
	 * @generated
	 */
	public Adapter createLookaheadAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.Note <em>Note</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.Note
	 * @generated
	 */
	public Adapter createNoteAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.Notes <em>Notes</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.Notes
	 * @generated
	 */
	public Adapter createNotesAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.ObjectClass <em>Object Class</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.ObjectClass
	 * @generated
	 */
	public Adapter createObjectClassAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.ObjectModel <em>Object Model</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.ObjectModel
	 * @generated
	 */
	public Adapter createObjectModelAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.Objects <em>Objects</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.Objects
	 * @generated
	 */
	public Adapter createObjectsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.Parameter <em>Parameter</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.Parameter
	 * @generated
	 */
	public Adapter createParameterAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.RequestUpdateTag <em>Request Update Tag</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.RequestUpdateTag
	 * @generated
	 */
	public Adapter createRequestUpdateTagAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.SendReceiveTag <em>Send Receive Tag</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.SendReceiveTag
	 * @generated
	 */
	public Adapter createSendReceiveTagAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.SimpleData <em>Simple Data</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.SimpleData
	 * @generated
	 */
	public Adapter createSimpleDataAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.SimpleDataTypes <em>Simple Data Types</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.SimpleDataTypes
	 * @generated
	 */
	public Adapter createSimpleDataTypesAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.Switches <em>Switches</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.Switches
	 * @generated
	 */
	public Adapter createSwitchesAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.Synchronization <em>Synchronization</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.Synchronization
	 * @generated
	 */
	public Adapter createSynchronizationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.Synchronizations <em>Synchronizations</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.Synchronizations
	 * @generated
	 */
	public Adapter createSynchronizationsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.Tags <em>Tags</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.Tags
	 * @generated
	 */
	public Adapter createTagsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.Time <em>Time</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.Time
	 * @generated
	 */
	public Adapter createTimeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.TimeStamp <em>Time Stamp</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.TimeStamp
	 * @generated
	 */
	public Adapter createTimeStampAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.Transportation <em>Transportation</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.Transportation
	 * @generated
	 */
	public Adapter createTransportationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.Transportations <em>Transportations</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.Transportations
	 * @generated
	 */
	public Adapter createTransportationsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.UpdateReflectTag <em>Update Reflect Tag</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.UpdateReflectTag
	 * @generated
	 */
	public Adapter createUpdateReflectTagAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.VariantRecordData <em>Variant Record Data</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.VariantRecordData
	 * @generated
	 */
	public Adapter createVariantRecordDataAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eodisp.hla.crc.omt.VariantRecordDataTypes <em>Variant Record Data Types</em>}'.
	 * <!-- begin-user-doc --> This default implementation returns null so that
	 * we can easily ignore cases; it's useful to ignore a case when inheritance
	 * will catch all the cases anyway. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eodisp.hla.crc.omt.VariantRecordDataTypes
	 * @generated
	 */
	public Adapter createVariantRecordDataTypesAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc --> This
	 * default implementation returns null. <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} // OmtAdapterFactory
