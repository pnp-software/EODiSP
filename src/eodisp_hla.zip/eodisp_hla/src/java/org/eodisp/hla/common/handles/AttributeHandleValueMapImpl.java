package org.eodisp.hla.common.handles;

import hla.rti1516.AttributeHandle;
import hla.rti1516.AttributeHandleValueMap;

import java.util.HashMap;
import java.util.Map;

/**
 * Keys are <code>AttributeHandle</code>s; values are <code>byte[]</code>.
 * All operations are required, none optional. Null mappings are not allowed.
 * Methods <code>put</code>, <code>putAll</code>, and <code>remove</code>
 * should throw <code>IllegalArgumentException</code> to enforce types of keys
 * and mappings.
 * 
 * @author Andrzej Kapolka
 */

public class AttributeHandleValueMapImpl extends HashMap implements
		AttributeHandleValueMap {
	
	
	/**
	 * Constructor
	 */
	public AttributeHandleValueMapImpl() {}
	
	/**
	 * Constructor.
	 * 
	 * @param capacity
	 *            the initial map capacity
	 */
	protected AttributeHandleValueMapImpl(int capacity) {
		super(capacity);
	}

	/**
	 * Associates the specified value with the specified key.
	 * 
	 * @param key
	 *            the key object
	 * @param value
	 *            the value object
	 * @return the previous value associated with the specified key, or
	 *         <code>null</code> for none
	 * @exception IllegalArgumentException
	 *                if the key is not a <code>AttributeHandle</code> or the
	 *                value is not a <code>byte[]</code>
	 */
	public Object put(Object key, Object value) {
		if (!(key instanceof AttributeHandle)) {
			throw new IllegalArgumentException("key must be AttributeHandle");
		} else if (!(value instanceof byte[])) {
			throw new IllegalArgumentException("value must be byte[]");
		}

		return super.put(key, value);
	}

	/**
	 * Adds all of the mappings contained in the specified map to this map.
	 * 
	 * @param t
	 *            the map whose mappings are to be added
	 * @exception IllegalArgumentException
	 *                if the map is not an <code>AttributeHandleValueMap</code>
	 */
	public void putAll(Map t) {
		if (!(t instanceof AttributeHandleValueMap)) {
			throw new IllegalArgumentException(
					"map must be AttributeHandleValueMap");
		}

		super.putAll(t);
	}

	/**
	 * Removes the mapping associated with the specified key.
	 * 
	 * @param key
	 *            the key whose mapping is to be removed
	 * @return the value that was mapped to the specified key, or
	 *         <code>null</code> for none
	 * @exception IllegalArgumentException
	 *                if the key is not an <code>AttributeHandle</code>
	 */
	public Object remove(Object key) {
		if (!(key instanceof AttributeHandle)) {
			throw new IllegalArgumentException("key must be AttributeHandle");
		}

		return super.remove(key);
	}
}
