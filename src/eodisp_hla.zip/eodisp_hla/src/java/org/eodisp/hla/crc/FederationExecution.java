/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com/
 *  mail: info@pnp-software.com
 */
package org.eodisp.hla.crc;

import hla.rti1516.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.URL;
import java.rmi.RemoteException;
import java.rmi.server.ExportException;
import java.util.*;
import java.util.Map.Entry;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import net.jcip.annotations.GuardedBy;

import org.apache.log4j.Logger;
import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.util.Diagnostician;
import org.eodisp.hla.common.crc.FederationExecutionRemote;
import org.eodisp.hla.common.handles.*;
import org.eodisp.hla.common.lrc.LrcHandle;
import org.eodisp.hla.common.lrc.LrcRemote;
import org.eodisp.hla.crc.application.CrcApplication;
import org.eodisp.hla.crc.application.CrcConfiguration;
import org.eodisp.hla.crc.data.DataFactory;
import org.eodisp.hla.crc.data.Federate;
import org.eodisp.hla.crc.data.ObjectInstance;
import org.eodisp.hla.crc.omt.*;
import org.eodisp.hla.crc.omt.util.ObjectModelIndexer;
import org.eodisp.hla.crc.omt.util.OmtResourceFactoryImpl;
import org.eodisp.hla.crc.omt.util.OmtSwitch;
import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.util.AppRegistry;

/**
 * Represents a federation execution on the CRC.
 * 
 * Most methods in this class are declared package private. It is crucial that
 * other classes in this package using these methods care for synchronization of
 * returned instances from these methods, because they make the non-thread-safe
 * ecore model available to the outside. The reason these methods are not
 * private is because it makes testing easier (Testing classes reside in the
 * same package and therefore have access to the package private methods).
 * 
 * @author ibirrer
 * @version $Id: FederationExecution.java 4125 2006-10-24 14:40:56Z ibirrer $
 * 
 * @UML -------------------------------------------------------------------
 * 
 * @composed - joinedFederates 0..* Federate
 * @navassoc - strongReference 0..1 FederationExecutionRemoteImpl
 * @has - connectedLrcs 0..* LrcRemote
 */
public class FederationExecution {

	private synchronized Map<LrcRemote, Set<FederateHandle>> assignFederatesToLrcs(Set<Federate> federates) {
		Map<LrcRemote, Set<FederateHandle>> result = new HashMap<LrcRemote, Set<FederateHandle>>();
		for (Federate federate : federates) {
			LrcHandle lrcHandle = federate.getLrcHandle();
			LrcRemote lrcRemote = getCrc().getLrcRemote(lrcHandle);
			if (lrcRemote == null) {
				logger.error(String.format("The LRC with handle [%s] never registered with the CRC"
						+ " or was unregistered before the LRC was shut down. Skip processing LRC", lrcHandle));
				continue;
			}
			Set<FederateHandle> federateHandles = result.get(lrcRemote);
			if (federateHandles == null) {
				federateHandles = new HashSet<FederateHandle>();
				result.put(lrcRemote, federateHandles);
			}
			federateHandles.add(federate.getHandle());
		}

		return result;
	}

	private abstract class LrcCallback implements Runnable {
		protected LrcRemote lrcRemote;

		protected Set<FederateHandle> federateHandles;

		public LrcCallback(LrcRemote lrcRemote, Set<FederateHandle> federateHandles) {
			this.lrcRemote = lrcRemote;
			this.federateHandles = federateHandles;
		}

		public void run() {
			try {
				callback();
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logCallbackExceptions(lrcRemote, e);
			} catch (Throwable e) {
				// TODO
				e.printStackTrace();
				logCallbackExceptions(lrcRemote, e);
			}
		}

		protected abstract void callback() throws RemoteException;
	}

	private void logCallbackExceptions(LrcRemote lrcRemote, Throwable throwable) {
		logger.error(String.format("Exception during callback on LRC [%s]", lrcRemote), throwable);
		// TODO: Register exceptions and check whenever a service is called.
	}

	private synchronized void doStartRegistrationForObjectClassCallback(final ObjectClassHandle objectClassHandle,
			Set<Federate> federates) {
		Map<LrcRemote, Set<FederateHandle>> lrcRemoteFederateHandleMap = assignFederatesToLrcs(federates);
		for (Entry<LrcRemote, Set<FederateHandle>> entry : lrcRemoteFederateHandleMap.entrySet()) {
			Runnable lrcCallback = new LrcCallback(entry.getKey(), entry.getValue()) {
				@Override
				public void callback() throws RemoteException {
					try {
						lrcRemote.startRegistrationForObjectClass(name, objectClassHandle, federateHandles
								.toArray(new FederateHandle[federateHandles.size()]));
					} catch (ObjectClassNotPublished e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						logCallbackExceptions(lrcRemote, e);
					} catch (FederateInternalError e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						logCallbackExceptions(lrcRemote, e);
					}
				}
			};
			callbackTasks.execute(lrcCallback);
		}
	}

	private synchronized void doDiscoverObjectInstanceCallback(final ObjectClassHandle objectClassHandle,
			final ObjectInstanceHandle objectInstanceHandle, final String objectInstanceName, Set<Federate> federates) {
		Map<LrcRemote, Set<FederateHandle>> lrcRemoteFederateHandleMap = assignFederatesToLrcs(federates);
		for (Entry<LrcRemote, Set<FederateHandle>> entry : lrcRemoteFederateHandleMap.entrySet()) {
			Runnable lrcCallback = new LrcCallback(entry.getKey(), entry.getValue()) {
				@Override
				public void callback() throws RemoteException {
					try {
						lrcRemote.discoverObjectInstance(objectInstanceHandle, objectClassHandle, objectInstanceName,
								federateHandles.toArray(new FederateHandle[federateHandles.size()]), name);
					} catch (CouldNotDiscover e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (ObjectClassNotRecognized e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (FederateInternalError e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			};
			callbackTasks.execute(lrcCallback);
		}
	}

	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	private static final Logger logger = Logger.getLogger(FederationExecution.class);

	/**
	 * It is mandatory to specify a resource URI when creating an ecore resource
	 * even if the resource is never saved or loaded from this resource. It
	 * needs to have the ending <code>.fdd</code> because this is the ending
	 * register
	 */
	private static final URI IN_MEMORY_RESOURCE_URI = URI.createURI("mem://resource.fdd");

	/**
	 * The unique name of this federation execution.
	 */
	private final String name;

	/**
	 * The id of the next federate handle.
	 * 
	 * @see #nextFederateHandle()
	 */
	private final AtomicInteger nextFederateHandleId = new AtomicInteger(0);

	/**
	 * The id of the next attribute handle.
	 * 
	 * @see #nextAttributeHandle()
	 */
	private final AtomicInteger nextAttributeHandleId = new AtomicInteger(0);

	/**
	 * The id of the next object class handle.
	 * 
	 * @see #nextObjectClassHandle()()
	 */
	private final AtomicInteger nextObjectClassHandleId = new AtomicInteger(0);

	/**
	 * The id of the next interaction class handle.
	 * 
	 * @see #nextInteractionClassHandle()
	 */
	private final AtomicInteger nextInteractionClassHandleId = new AtomicInteger(0);

	/**
	 * The id of the next parameter handle.
	 * 
	 * @see #nextParameterHandle()
	 */
	private final AtomicInteger nextParameterHandleId = new AtomicInteger(0);

	/**
	 * The id of the next object instance handle
	 * 
	 * @see #nextObjectInstanceHandle()
	 */
	private final AtomicInteger nextObjectInstanceHandleId = new AtomicInteger(0);

	@GuardedBy("this")
	private final Map<AttributeHandle, Attribute> attributeHandleIndex = new HashMap<AttributeHandle, Attribute>();

	@GuardedBy("this")
	private final Map<ParameterHandle, Parameter> parameterHandleIndex = new HashMap<ParameterHandle, Parameter>();

	@GuardedBy("this")
	private final Map<ObjectClassHandle, ObjectClass> objectClassHandleIndex = new HashMap<ObjectClassHandle, ObjectClass>();

	@GuardedBy("this")
	private final Map<InteractionClassHandle, InteractionClass> interactionClassHandleIndex = new HashMap<InteractionClassHandle, InteractionClass>();

	@GuardedBy("this")
	private final Map<FederateHandle, Federate> joinedFederates = new HashMap<FederateHandle, Federate>();

	@GuardedBy("this")
	private final Resource resource;

	@GuardedBy("this")
	private final Map<LrcHandle, Set<FederateHandle>> connectedLrcs = new HashMap<LrcHandle, Set<FederateHandle>>();

	@GuardedBy("this")
	private final CopyOnWriteArrayList<FederationExecutionEventListener> federationExecutionEventListeners = new CopyOnWriteArrayList<FederationExecutionEventListener>();

	@GuardedBy("this")
	private final Map<String, SynchronizationPoint> synchronizationPoints = new HashMap<String, SynchronizationPoint>();

	@GuardedBy("this")
	private final ObjectModelIndexer objectModelIndexer;

	/**
	 * Because we don't use distributed garbage collection, we need a strong
	 * reference to the federationExecutionRemoteImpl. Defining it as a member
	 * variable of the federation execution makes sure that it only has no
	 * references when the federation execution itself is not referenced
	 * anymore.
	 * 
	 * <p>
	 * This federationExecutionRemoteImpl instance is never return by a method
	 * in this class and therefore this is the only reference to this
	 * federationExecutionRemoteImpl. Only a RMI proxy is returned to the
	 * outside using {@link #getRemoteInterface()} that has a weak reference to
	 * this federationExecutionRemoteImpl only.
	 * 
	 */
	private final FederationExecutionRemoteImpl federationExecutionRemoteImpl;

	/**
	 * The proxy that is returned to a client for the
	 * federationExecutionRemoteImpl. Note that the proxy only contains a weak
	 * reference to the federationExecutionRemoteImpl because no distributed
	 * garbage collector is used.
	 */
	private final FederationExecutionRemote federationExecutionRemote;

	/**
	 * Completion service managing all callback tasks.
	 */
	private final ExecutorService callbackTasks;

	/**
	 * Convenience link to the crcConfiguration
	 */
	private final CrcConfiguration crcConfiguration = (CrcConfiguration) AppRegistry.getRootApp().getConfiguration(
			CrcConfiguration.ID);

	/**
	 * @param name
	 *            The name of the new federation execution
	 * @param fdd
	 *            The Federation Object Model (FOM) Document Data
	 * @throws CouldNotOpenFDD
	 * @throws ErrorReadingFDD
	 * @throws ExportException
	 */
	FederationExecution(String name, byte[] fdd) throws ErrorReadingFDD {
		this.name = name;

		ByteArrayInputStream fddInputStream = new ByteArrayInputStream(fdd);
		OmtResourceFactoryImpl fact = new OmtResourceFactoryImpl();
		resource = fact.createResource(IN_MEMORY_RESOURCE_URI);
		try {

			resource.load(fddInputStream, null);
			if (!resource.getErrors().isEmpty()) {
				String newline = String.format("%n");
				StringBuilder msg = new StringBuilder();
				for (Object diagnostic : resource.getErrors()) {
					msg.append(((Diagnostic) diagnostic).getMessage());
					msg.append(newline);
				}
				throw new ErrorReadingFDD(msg.toString());
			}

			if (!resource.getWarnings().isEmpty()) {
				String newline = String.format("%n");
				StringBuilder msg = new StringBuilder();
				for (Object diagnostic : resource.getWarnings()) {
					msg.append(((Diagnostic) diagnostic).getMessage());
					msg.append(newline);
				}
				logger.warn("Warnings while reading fdd:" + msg.toString());
			}

		} catch (IOException e) {
			throw new ErrorReadingFDD("IOException occurred while reading fdd", e);
		}

		DocumentRoot documentRoot = (DocumentRoot) resource.getContents().get(0);
		String validateResult = validateObject(documentRoot);
		if (validateResult != null) {
			throw new ErrorReadingFDD("The fdd is does not validate: " + validateResult);
		}

		ObjectModel objectModel = documentRoot.getObjectModel();
		objectModelIndexer = new ObjectModelIndexer(objectModel);
		// The root object class must always be HLAobjectRoot, throw exception
		// otherwise. (See section 4.2.1 in IEEE 1516.2-2000, Page 21, first
		// paragraph)
		ObjectClass hlaObjectRoot = (ObjectClass) objectModel.getObjects().getObjectClass().get(0);
		if (hlaObjectRoot == null || !hlaObjectRoot.getName().equals(ObjectClass.HLA_OBJECT_ROOT_NAME)) {
			throw new ErrorReadingFDD("Root object class is not " + ObjectClass.HLA_OBJECT_ROOT_NAME);
		}

		initIndices();

		// exporting this new instance with Jeri
		RemoteAppModule remoteAppModule = (RemoteAppModule) AppRegistry.getRootApp().getAppModule(RemoteAppModule.ID);
		federationExecutionRemoteImpl = new FederationExecutionRemoteImpl(this);
		federationExecutionRemote = (FederationExecutionRemote) remoteAppModule.export(federationExecutionRemoteImpl);

		// Create executor
		callbackTasks = Executors.newFixedThreadPool(crcConfiguration.getMaxCallbackThreads());
	}

	void unexport() {
		RemoteAppModule remoteAppModule = (RemoteAppModule) AppRegistry.getRootApp().getAppModule(RemoteAppModule.ID);
		remoteAppModule.unexportAll(federationExecutionRemoteImpl, true);
	}

	/**
	 * @param eObject
	 *            the object to be validated
	 * @return null if validation is OK, otherwise the message of each
	 *         validation object separated by newlines
	 */
	private static String validateObject(EObject eObject) {
		String msg = null;
		Diagnostic diagnostic = Diagnostician.INSTANCE.validate(eObject);

		if (diagnostic.getSeverity() == Diagnostic.ERROR || diagnostic.getSeverity() == Diagnostic.WARNING) {
			String newline = String.format("%n");
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(diagnostic.getMessage());
			for (Object childDiagnostic : diagnostic.getChildren()) {
				stringBuilder.append(((Diagnostic) childDiagnostic).getMessage());
				stringBuilder.append(newline);
			}
			msg = stringBuilder.toString();
		}
		return msg;
	}

	synchronized void addFederationExecutionEventListener(FederationExecutionEventListener listener) {
		federationExecutionEventListeners.add(listener);
	}

	synchronized void removeFederationExecutionEventListener(FederationExecutionEventListener listener) {
		federationExecutionEventListeners.remove(listener);
	}

	private synchronized void fireFederationExecutionJoined(FederateHandle federateHandle) {
		for (FederationExecutionEventListener listener : federationExecutionEventListeners) {
			listener.joined(federateHandle);
		}
	}

	private synchronized void fireFederationExecutionResigned(FederateHandle federateHandle) {
		/*
		 * Note that during resigned it is possible that a listener is removed
		 * from the federationExecutionEventListeners list. This works because
		 * the type of the list is CopyOnWrtiteArrayList.
		 */
		for (FederationExecutionEventListener listener : federationExecutionEventListeners) {
			listener.resigned(federateHandle);
		}
	}

	/**
	 * Returns the attribute bound to the given attribute handle. It is tested
	 * if the given attribute is available from the given object class.
	 * 
	 * @param objectClassHandle
	 *            the object class this attribute is defined in
	 * @param attributeHandle
	 *            the attribute handle
	 * @return the attribute that is bound to the given attribute handle.
	 * @throws InvalidAttributeHandle
	 *             If the given handle does not exist within this federation
	 *             execution.
	 * @throws InvalidObjectClassHandle
	 *             If the given handle does not exist within this federation
	 *             execution.
	 * @throws AttributeNotDefined
	 *             If the attribute specified with the attribute handle is not
	 *             available within the specified object class.
	 * 
	 * @see Attribute#isAvailableFrom(ObjectClass)
	 */
	synchronized Attribute getAttribute(ObjectClassHandle objectClassHandle, AttributeHandle attributeHandle)
			throws InvalidAttributeHandle, ObjectClassNotDefined, AttributeNotDefined {
		Attribute attribute = attributeHandleIndex.get(attributeHandle);
		if (attribute == null) {
			throw new InvalidAttributeHandle("This handle is not bound to an attribute: " + attributeHandle);
		}
		ObjectClass objectClass = getObjectClass(objectClassHandle);

		if (!attribute.isAvailableFrom(objectClass)) {
			throw new AttributeNotDefined("The attribute " + attribute.getName() + " is not defined in object class "
					+ objectClass.getQualifiedName(false) + " or in one of its super classes.");
		}
		return attribute;
	}

	synchronized Set<Attribute> getAttributes(ObjectClassHandle objectClassHandle, AttributeHandle[] attributeHandles)
			throws InvalidAttributeHandle, ObjectClassNotDefined, AttributeNotDefined {
		Set<Attribute> result = new HashSet<Attribute>(attributeHandles.length);
		for (AttributeHandle attributeHandle : attributeHandles) {
			result.add(getAttribute(objectClassHandle, attributeHandle));
		}
		return result;
	}

	synchronized AttributeHandle[] getAttributeHandles(Set<Attribute> attributes) {
		AttributeHandle[] result = new AttributeHandle[attributes.size()];
		int i = 0;
		for (Attribute attribute : attributes) {
			result[i++] = attribute.getHandle();
		}
		return result;
	}

	synchronized ObjectInstance getObjectInstance(ObjectInstanceHandle objectInstanceHandle)
			throws ObjectInstanceNotKnown {
		for (Federate federate : joinedFederates.values()) {
			for (Iterator iter = federate.getRegisteredObjectInstances().iterator(); iter.hasNext();) {
				ObjectInstance objectInstance = (ObjectInstance) iter.next();
				if (objectInstance.getHandle().equals(objectInstanceHandle)) {
					return objectInstance;
				}
			}
		}
		throw new ObjectInstanceNotKnown(String.format(
				"No object instance registered with handle '%s' in federation execution '%s'", objectInstanceHandle
						.toString(), name));
	}

	synchronized Parameter getParameter(InteractionClassHandle interactionClassHandle, ParameterHandle parameterHandle)
			throws InvalidParameterHandle, InteractionParameterNotDefined, InteractionClassNotDefined {
		Parameter parameter = getParameter(parameterHandle);
		InteractionClass interactionClass = getInteractionClass(interactionClassHandle);

		if (!parameter.isAvailableFrom(interactionClass)) {
			throw new InteractionParameterNotDefined(String.format(
					"The handle '%s' is not defined in the interaction class '%s'", parameterHandle.toString(),
					interactionClass.getQualifiedName(false)));
		}
		return parameter;
	}

	synchronized Parameter getParameter(ParameterHandle parameterHandle) throws InvalidParameterHandle {
		Parameter parameter = parameterHandleIndex.get(parameterHandle);
		if (parameter == null) {
			throw new InvalidParameterHandle(String.format("The handle is not bound to a parameter: '%d'",
					parameterHandle));
		}
		return parameter;
	}

	/**
	 * Returns the object class associated with the given handle.
	 * 
	 * @param objectClassHandle
	 *            the handle of the object class to be returned.
	 * @return the object class of that is associated with the given handle.
	 * @throws ObjectClassNotDefined
	 *             if the given handle is not associated with an object class
	 */
	synchronized ObjectClass getObjectClass(ObjectClassHandle objectClassHandle) throws ObjectClassNotDefined {
		ObjectClass objectClass = getObjectClassNoException(objectClassHandle);
		if (objectClass == null) {
			throw new ObjectClassNotDefined("This handle is not bound to an object class: " + objectClassHandle);
		}
		return objectClass;
	}

	private ObjectClass getObjectClassNoException(ObjectClassHandle objectClassHandle) {
		return objectClassHandleIndex.get(objectClassHandle);
	}

	/**
	 * Returns the interaction class associated with the given handle.
	 * 
	 * @param interactionClassHandle
	 *            the handle of the interaction class to be returned
	 * @return the interaction class that is associated with the given handle.
	 * @throws InteractionClassNotDefined
	 *             if the given handle is not associated with an interaction
	 *             class.
	 */
	synchronized InteractionClass getInteractionClass(InteractionClassHandle interactionClassHandle)
			throws InteractionClassNotDefined {
		InteractionClass interactionClass = interactionClassHandleIndex.get(interactionClassHandle);
		if (interactionClass == null) {
			throw new InteractionClassNotDefined("This handle is not bound to an interaction class: "
					+ interactionClassHandle);
		}
		return interactionClass;
	}

	/**
	 * Returns the federate associated with the given handle.
	 * 
	 * @param federateHandle
	 *            the handle of the federate to be returned.
	 * @return the federate that is associated with the given handle
	 * @throws FederateNotExecutionMember
	 *             if the federate is not an execution member of this federation
	 *             execution.
	 */
	synchronized Federate getFederate(FederateHandle federateHandle) throws FederateNotExecutionMember {
		Federate federate = joinedFederates.get(federateHandle);
		if (federate == null) {
			throw new FederateNotExecutionMember(String.format(
					"The federate handle '%s' is not bound to a joined federate of this federation execution ('%s')",
					federateHandle, name));
		}
		return federate;
	}

	/**
	 * @param federateHandles
	 * @return
	 * @throws FederateNotExecutionMember
	 */
	private Set<Federate> getFederates(Set<FederateHandle> federateHandles) throws FederateNotExecutionMember {
		Set<Federate> federates = new HashSet<Federate>();
		for (FederateHandle handle : federateHandles) {
			federates.add(getFederate(handle));
		}
		return federates;
	}

	/**
	 * @return
	 */
	private Set<FederateHandle> getFederateHandles(Collection<Federate> federates) {
		Set<FederateHandle> federateHandles = new HashSet<FederateHandle>();
		for (Federate federate : federates) {
			federateHandles.add(federate.getHandle());
		}
		return federateHandles;
	}

	/**
	 * Returns the name of this federation execution as it was initialized in
	 * {@link Crc#createFederationExecution(String, URL)}
	 * 
	 * @return the name of this federation execution.
	 */
	public String getName() {
		/*
		 * no synchronization needed. The name is initialized in the constructor
		 * and never changed later and the name field is final.
		 */
		return name;
	}

	/**
	 * Returns a different Federate handle each time it is called.
	 * 
	 * @return A new federate handle unique to this federation execution
	 */
	private FederateHandle nextFederateHandle() {
		return new FederateHandleImpl(nextFederateHandleId.incrementAndGet());
	}

	/**
	 * Returns a different attribute handle each time it is called.
	 * 
	 * @return A new attribute handle unique to this federation execution
	 */
	private AttributeHandle nextAttributeHandle() {
		return new AttributeHandleImpl(nextAttributeHandleId.incrementAndGet());
	}

	/**
	 * Returns a different object class handle each time it is called.
	 * 
	 * @return A new object class handle unique to this federation execution
	 */
	private ObjectClassHandle nextObjectClassHandle() {
		return new ObjectClassHandleImpl(nextObjectClassHandleId.incrementAndGet());
	}

	/**
	 * Returns a different interaction class handle each time it is called.
	 * 
	 * @return A new interaction class handle unique to this federation
	 *         execution
	 */
	private InteractionClassHandle nextInteractionClassHandle() {
		return new InteractionClassHandleImpl(nextInteractionClassHandleId.incrementAndGet());
	}

	/**
	 * Returns a different parameter handle each time it is called.
	 * 
	 * @return A new parameter handle unique to this federation execution
	 */
	private ParameterHandle nextParameterHandle() {
		return new ParameterHandleImpl(nextParameterHandleId.incrementAndGet());
	}

	/**
	 * Returns a different object class handle each time it is called.
	 * 
	 * @return A new object class handle unique to this federation execution
	 */
	private ObjectInstanceHandle nextObjectInstanceHandle() {
		return new ObjectInstanceHandleImpl(nextObjectInstanceHandleId.incrementAndGet());
	}

	/**
	 * Implements HLA service 4.4 (See IEEE Std 1516.1-2000). Joins this
	 * federation execution.
	 * 
	 * @prio 1
	 * 
	 * @param federateType
	 *            unused
	 * @param lrcHandle
	 *            reference to the remote federate that wants to join
	 * @param serviceReferences
	 *            unused
	 * @return a new and unique federate handle
	 * 
	 * @throws AssertionError
	 *             if the
	 */
	synchronized FederateHandle join(String federateType, LrcHandle lrcHandle, MobileFederateServices serviceReferences) {
		FederateHandle federateHandle = nextFederateHandle();
		Federate federate = DataFactory.eINSTANCE.createFederate(lrcHandle, federateHandle, this);
		joinedFederates.put(federateHandle, federate);
		Set<FederateHandle> lrcFederates = connectedLrcs.get(lrcHandle);
		if (lrcFederates == null) {
			lrcFederates = new HashSet<FederateHandle>();
			connectedLrcs.put(lrcHandle, lrcFederates);
			logger.info(String.format("New Federate joined from new LRC [%s]", getCrc().getLrcRemote(lrcHandle)));
		} else {
			logger.info(String.format("New Federate joined from already connected LRC [%s]", getCrc().getLrcRemote(
					lrcHandle)));
		}
		lrcFederates.add(federateHandle);
		fireFederationExecutionJoined(federateHandle);
		return federateHandle;
	}

	/**
	 * Implements HLA service 4.5 (See IEEE Std 1516.1-2000).
	 * 
	 * @prio 1
	 */
	synchronized void resign(ResignAction resignAction, FederateHandle federateHandle)
			throws OwnershipAcquisitionPending, FederateOwnsAttributes, FederateNotExecutionMember {
		Federate federate = joinedFederates.get(federateHandle);
		if (federate == null) {
			throw new FederateNotExecutionMember(String.format(
					"The federate with handle '%s' is not joined to the federation execution '%s'", federateHandle,
					name));
		}
		if (federate.ownsAttributes() && !resignAction.equals(ResignAction.UNCONDITIONALLY_DIVEST_ATTRIBUTES)) {
			throw new FederateOwnsAttributes(
					String
							.format(
									"The federate '%s' is still owning more than one attribute and can therefore not be resigned from the federation execution",
									federate));
		}
		logger.debug(String.format("Federate %s resigned from federation execution", federate));
		joinedFederates.remove(federateHandle);
		fireFederationExecutionResigned(federateHandle);
	}

	/**
	 * Implements HLA service 4.6 (See IEEE Std 1516.1-2000).
	 * 
	 * @throws FederateNotExecutionMember
	 * 
	 * @prio 1
	 */
	synchronized void registerFederationSynchronizationPoint(final String synchronizationPointLabel,
			byte[] userSuppliedTag, final FederateHandle askingFederate) throws SaveInProgress, RestoreInProgress,
			FederateNotExecutionMember {

		registerFederationSynchronizationPoint(synchronizationPointLabel, userSuppliedTag, null, askingFederate);

		// if (synchronizationPoints.containsKey(synchronizationPointLabel)) {
		// doSynchronizationPointRegistrationFailedCallback(
		// synchronizationPointLabel,
		// SynchronizationPointFailureReason.SYNCHRONIZATION_POINT_LABEL_NOT_UNIQUE,
		// askingFederate);
		// return;
		// }
		//
		// SynchronizationPoint synchronizationPoint = new SynchronizationPoint(
		// synchronizationPointLabel,
		// this,
		// false,
		// userSuppliedTag);
		// Set<FederateHandle> initialSet = new HashSet<FederateHandle>();
		// initialSet.addAll(getFederateHandles(joinedFederates.values()));
		// synchronizationPoints.put(synchronizationPointLabel,
		// synchronizationPoint);
		// synchronizationPoint.start(initialSet);
	}

	/**
	 * Implements HLA service 4.6 (See IEEE Std 1516.1-2000).
	 * 
	 * @throws FederateNotExecutionMember
	 * 
	 * @prio 1
	 */
	synchronized void registerFederationSynchronizationPoint(final String synchronizationPointLabel,
			final byte[] userSuppliedTag, FederateHandle[] synchronizationSet, final FederateHandle askingFederate)
			throws SaveInProgress, RestoreInProgress, FederateNotExecutionMember {
		boolean fixedSet = true;
		if (synchronizationSet == null || synchronizationSet.length == 0) {
			synchronizationSet = getFederateHandles(joinedFederates.values()).toArray(new FederateHandle[0]);
			fixedSet = false;
		}

		if (synchronizationPoints.containsKey(synchronizationPointLabel)) {
			doSynchronizationPointRegistrationFailedCallback(synchronizationPointLabel,
					SynchronizationPointFailureReason.SYNCHRONIZATION_POINT_LABEL_NOT_UNIQUE, askingFederate);
			return;
		}

		SynchronizationPoint synchronizationPoint = new SynchronizationPoint(synchronizationPointLabel, this, fixedSet,
				userSuppliedTag);
		synchronizationPoints.put(synchronizationPointLabel, synchronizationPoint);

		for (FederateHandle handle : synchronizationSet) {
			try {
				getFederate(handle);
			} catch (FederateNotExecutionMember e) {
				logger.warn(String.format(
						"Federate %s used federate %s in synchronization set, but federate %s is not joined",
						askingFederate, handle, handle));
				doSynchronizationPointRegistrationFailedCallback(synchronizationPointLabel,
						SynchronizationPointFailureReason.SYNCHRONIZATION_SET_MEMBER_NOT_JOINED, askingFederate);
				synchronizationPoints.remove(synchronizationPointLabel);
				return;
			}
		}

		doSynchronizationPointRegistrationSucceededCallback(synchronizationPointLabel, askingFederate);

		synchronizationPoint.start(new HashSet<FederateHandle>(Arrays.asList(synchronizationSet)));
	}

	/**
	 * @param synchronizationPointLabel
	 * @param askingFederate
	 * @throws FederateNotExecutionMember
	 */
	private synchronized void doSynchronizationPointRegistrationFailedCallback(final String synchronizationPointLabel,
			final SynchronizationPointFailureReason failureReason, final FederateHandle askingFederate)
			throws FederateNotExecutionMember {
		LrcRemote lrcRemote = getCrc().getLrcRemote(getFederate(askingFederate).getLrcHandle());
		Runnable lrcCallback = new LrcCallback(lrcRemote, null) {

			@Override
			protected void callback() throws RemoteException {
				try {
					lrcRemote.synchronizationPointRegistrationFailed(synchronizationPointLabel, failureReason,
							askingFederate, name);
				} catch (FederateInternalError e) {
					logCallbackExceptions(lrcRemote, e);
				}
			}
		};
		callbackTasks.execute(lrcCallback);
	}

	/**
	 * @param synchronizationPointLabel
	 * @param askingFederate
	 * @throws FederateNotExecutionMember
	 */
	private synchronized void doSynchronizationPointRegistrationSucceededCallback(
			final String synchronizationPointLabel, final FederateHandle askingFederate)
			throws FederateNotExecutionMember {
		LrcRemote lrcRemote = getCrc().getLrcRemote(getFederate(askingFederate).getLrcHandle());
		Runnable lrcCallback = new LrcCallback(lrcRemote, null) {

			@Override
			protected void callback() throws RemoteException {
				try {
					lrcRemote
							.synchronizationPointRegistrationSucceeded(synchronizationPointLabel, askingFederate, name);
				} catch (FederateInternalError e) {
					logCallbackExceptions(lrcRemote, e);
				}
			}
		};
		callbackTasks.execute(lrcCallback);
	}

	synchronized void doAnnounceSynchronizationPointCallback(final String synchronizationPointLabel,
			Set<FederateHandle> callbackFederates, final byte[] userSuppliedTag) {
		Map<LrcRemote, Set<FederateHandle>> lrcs;
		try {
			lrcs = assignFederatesToLrcs(getFederates(callbackFederates));

			for (Entry<LrcRemote, Set<FederateHandle>> entry : lrcs.entrySet()) {
				Runnable lrcCallback = new LrcCallback(entry.getKey(), entry.getValue()) {

					@Override
					protected void callback() throws RemoteException {
						try {
							logger.debug(String.format(
									"Announce Synchronization Point %s to federate(s) %s at LRC %s ...",
									synchronizationPointLabel, federateHandles, lrcRemote));
							lrcRemote.announceSynchronizationPoint(synchronizationPointLabel, userSuppliedTag,
									federateHandles.toArray(new FederateHandle[0]), name);
							logger.debug(String.format(
									"Successfully announced Synchronization Point %s to federate(s) %s at LRC %s",
									synchronizationPointLabel, federateHandles, lrcRemote));
						} catch (FederateInternalError e) {
							logCallbackExceptions(lrcRemote, e);
						}
					}
				};
				callbackTasks.execute(lrcCallback);
			}
		} catch (FederateNotExecutionMember e1) {
			logger
					.fatal("Cannot fire synchronization announce on federate that is not joined to the federation execution");
		}
	}

	synchronized void doFederatesSynchronizedCallback(final String syncPointName,
			Set<FederateHandle> synchronizedFederates, final byte[] userSuppliedTag) {

		try {
			Map<LrcRemote, Set<FederateHandle>> lrcs = assignFederatesToLrcs(getFederates(synchronizedFederates));
			for (Entry<LrcRemote, Set<FederateHandle>> entry : lrcs.entrySet()) {
				Runnable lrcCallback = new LrcCallback(entry.getKey(), entry.getValue()) {
					@Override
					public void callback() throws RemoteException {
						try {
							lrcRemote.federationSynchronized(syncPointName, federateHandles
									.toArray(new FederateHandle[0]), name, userSuppliedTag);
						} catch (FederateInternalError e) {
							logCallbackExceptions(lrcRemote, e);
						}
					}
				};
				callbackTasks.execute(lrcCallback);
			}
		} catch (FederateNotExecutionMember e) {
			logger
					.fatal("Cannot fire synchronization achieved on federate that is not joined to the federation execution");
		} finally {
			synchronizationPoints.remove(syncPointName);
		}
	}

	/**
	 * Implements HLA service 4.9 (See IEEE Std 1516.1-2000).
	 * 
	 * @param askingFederate
	 * 
	 * @prio 1
	 */
	synchronized void synchronizationPointAchieved(String synchronizationPointLabel, FederateHandle askingFederate)
			throws SynchronizationPointLabelNotAnnounced, SaveInProgress, RestoreInProgress {
		SynchronizationPoint synchronizationPoint = synchronizationPoints.get(synchronizationPointLabel);
		if (synchronizationPoint == null) {
			throw new SynchronizationPointLabelNotAnnounced(String.format(
					"The synchronization point '%s' has not been announced to the federation execution '%s'",
					synchronizationPointLabel, name));
		}

		synchronizationPoint.syncFederate(askingFederate);
	}

	/**
	 * Implements HLA service 10.2 (See IEEE Std 1516.1-2000).
	 * 
	 * @prio 1
	 */
	synchronized ObjectClassHandle getObjectClassHandle(String theName) throws NameNotFound {
		ObjectClass objectClass = objectModelIndexer.getObjectClass(theName);
		if (objectClass == null) {
			throw new NameNotFound(String.format("No object class found with name '%s'", theName));
		}
		return objectClass.getHandle();
	}

	/**
	 * Implements HLA service 10.3 (See IEEE Std 1516.1-2000).
	 * 
	 * @throws ObjectClassNotDefined
	 * 
	 * @prio 1
	 */
	synchronized String getObjectClassName(ObjectClassHandle theHandle) throws ObjectClassNotDefined {
		ObjectClass objectClass = getObjectClass(theHandle);
		return objectClass.getQualifiedName(false);
	}

	/**
	 * Implements HLA service 10.4 (See IEEE Std 1516.1-2000).
	 * 
	 * @prio 1
	 */
	synchronized AttributeHandle getAttributeHandle(ObjectClassHandle objectClassHandle, String theName)
			throws ObjectClassNotDefined, NameNotFound {

		ObjectClass objectClass = getObjectClass(objectClassHandle);

		for (Object obj : objectClass.getAllAttributes()) {
			Attribute attribute = (Attribute) obj;
			if (attribute.getName().equals(theName)) {
				return attribute.getHandle();
			}
		}
		throw new NameNotFound("Attribute with name " + theName + " not found in object class "
				+ objectClass.getQualifiedName(false));
	}

	/**
	 * Implements HLA service 10.5 (See IEEE Std 1516.1-2000).
	 * 
	 * @prio 1
	 */
	synchronized String getAttributeName(ObjectClassHandle whichClass, AttributeHandle theHandle)
			throws ObjectClassNotDefined, InvalidAttributeHandle, AttributeNotDefined {
		return getAttribute(whichClass, theHandle).getName();
	}

	/**
	 * Implements HLA service 10.6 (See IEEE Std 1516.1-2000).
	 * 
	 * @prio 1
	 */
	synchronized InteractionClassHandle getInteractionClassHandle(String theName) throws NameNotFound {
		InteractionClass interactionClass = objectModelIndexer.getInteractionClass(theName);
		if (interactionClass == null) {
			throw new NameNotFound(String.format("No interaction class found with name '%s'", theName));
		}
		return interactionClass.getHandle();
	}

	/**
	 * Implements HLA service 10.7 (See IEEE Std 1516.1-2000).
	 * 
	 * @throws InteractionClassNotDefined
	 * 
	 * @prio 1
	 */
	synchronized String getInteractionClassName(InteractionClassHandle theHandle) throws InteractionClassNotDefined {
		return getInteractionClass(theHandle).getQualifiedName(false);
	}

	/**
	 * Implements HLA service 10.8 (See IEEE Std 1516.1-2000).
	 * 
	 * @throws InteractionClassNotDefined
	 * 
	 * @prio 1
	 */
	synchronized ParameterHandle getParameterHandle(InteractionClassHandle interactionClassHandle, String theName)
			throws NameNotFound, InteractionClassNotDefined {
		InteractionClass interactionClass = getInteractionClass(interactionClassHandle);

		for (Object obj : interactionClass.getParameters()) {
			Parameter parameter = (Parameter) obj;
			if (parameter.getName().equals(theName)) {
				return parameter.getHandle();
			}
		}
		throw new NameNotFound("Parameter with name " + theName + " not found in interaction class "
				+ interactionClass.getQualifiedName(false));
	}

	/**
	 * Implements HLA service 10.9 (See IEEE Std 1516.1-2000).
	 * 
	 * @throws InteractionClassNotDefined
	 * 
	 * @prio 1
	 */
	synchronized String getParameterName(InteractionClassHandle interactionClassHandle, ParameterHandle parameterHandle)
			throws InvalidParameterHandle, InteractionParameterNotDefined, InteractionClassNotDefined {
		return getParameter(interactionClassHandle, parameterHandle).getName();
	}

	void publishObjectClassAttributes(ObjectClassHandle objectClassHandle, AttributeHandle[] attributeHandles,
			FederateHandle federateHandle) throws ObjectClassNotDefined, AttributeNotDefined,
			FederateNotExecutionMember, InvalidAttributeHandle {
		Federate federate = getFederate(federateHandle);
		federate.getPublishedAttributes().addAll(getAttributes(objectClassHandle, attributeHandles));
	}

	/**
	 * {@inheritDoc} fallback hafd
	 */
	synchronized public void unpublishObjectClassAttributes(ObjectClassHandle objectClassHandle,
			AttributeHandle[] attributeHandles, FederateHandle federateHandle) throws ObjectClassNotDefined,
			AttributeNotDefined, FederateNotExecutionMember, InvalidAttributeHandle {
		Federate federate = getFederate(federateHandle);
		ObjectClass objectClass = getObjectClass(objectClassHandle);
		federate.getPublishedAttributes().removeAll(getAttributes(objectClassHandle, attributeHandles));
	}

	synchronized void unpublishObjectClass(ObjectClassHandle objectClassHandle, FederateHandle federateHandle)
			throws ObjectClassNotDefined, FederateNotExecutionMember {
		Federate federate = getFederate(federateHandle);
		ObjectClass objectClass = getObjectClass(objectClassHandle);
		// TODO: Read up in spec if getAllAttributes() or getAttributes() shall
		// be used below. In the worst
		// case we need to keep track of published object classes separately...
		federate.getPublishedAttributes().removeAll(objectClass.getAttributes());
	}

	synchronized void subscribeObjectClassAttributes(final ObjectClassHandle objectClassHandle,
			AttributeHandle[] attributeHandles, FederateHandle federateHandle) throws ObjectClassNotDefined,
			AttributeNotDefined, FederateNotExecutionMember, InvalidAttributeHandle {
		Federate askingFederate = getFederate(federateHandle);
		Set<Attribute> attributes = getAttributes(objectClassHandle, attributeHandles);
		askingFederate.getSubscribedAttributes().addAll(attributes);
		Set<Federate> federates = getPublishingFederates(attributes);

		// do not advise the subscribing federate
		federates.remove(askingFederate);
		doStartRegistrationForObjectClassCallback(objectClassHandle, federates);
	}

	synchronized public void unsubscribeObjectClass(ObjectClassHandle objectClassHandle, FederateHandle federateHandle)
			throws ObjectClassNotDefined, FederateNotExecutionMember {
		Federate federate = getFederate(federateHandle);
		ObjectClass objectClass = getObjectClass(objectClassHandle);
		// TODO: Read up in spec if getAllAttributes() or getAttributes() shall
		// be used below. In the worst
		// case we need to keep track of published object classes separately...
		federate.getSubscribedAttributes().removeAll(objectClass.getAttributes());
	}

	synchronized void unsubscribeObjectClassAttributes(ObjectClassHandle objectClassHandle,
			AttributeHandle[] attributeHandles, FederateHandle federateHandle) throws ObjectClassNotDefined,
			AttributeNotDefined, FederateNotExecutionMember, InvalidAttributeHandle {
		Federate federate = getFederate(federateHandle);
		federate.getSubscribedAttributes().removeAll(getAttributes(objectClassHandle, attributeHandles));
	}

	synchronized void publishInteractionClass(InteractionClassHandle interactionClassHandle,
			FederateHandle federateHandle) throws InteractionClassNotDefined, FederateNotExecutionMember,
			SaveInProgress, RestoreInProgress {
		Federate federate = getFederate(federateHandle);
		federate.getPublishedInteractions().add(getInteractionClass(interactionClassHandle));
	}

	synchronized void unpusblishInteractionClass(InteractionClassHandle interactionClassHandle,
			FederateHandle federateHandle) throws FederateNotExecutionMember, InteractionClassNotDefined {
		Federate federate = getFederate(federateHandle);
		// to make sure the InteractionClassNotDefined exception is thrown
		getInteractionClass(interactionClassHandle);
		federate.getPublishedInteractions().remove(interactionClassHandle);
	}

	synchronized void subscribeInteractionClass(InteractionClassHandle interactionClassHandle,
			FederateHandle federateHandle) throws InteractionClassNotDefined, FederateNotExecutionMember {
		Federate federate = getFederate(federateHandle);
		federate.getSubscribedInteractions().add(getInteractionClass(interactionClassHandle));
	}

	synchronized void unsubscribeInteractionClass(InteractionClassHandle interactionClassHandle,
			FederateHandle federateHandle) throws InteractionClassNotDefined, FederateNotExecutionMember,
			SaveInProgress, RestoreInProgress {
		Federate federate = getFederate(federateHandle);
		federate.getSubscribedInteractions().remove(getInteractionClass(interactionClassHandle));
	}

	synchronized ObjectInstanceHandle registerObjectInstance(ObjectClassHandle objectClassHandle,
			FederateHandle federateHandle) throws ObjectClassNotDefined, ObjectClassNotPublished,
			FederateNotExecutionMember {

		Federate federate = getFederate(federateHandle);

		ObjectClass objectClass = getObjectClass(objectClassHandle);
		federate.checkPublication(objectClass);

		ObjectInstance objectInstance = DataFactory.eINSTANCE.createObjectInstance(objectClass,
				nextObjectInstanceHandle());
		federate.getRegisteredObjectInstances().add(objectInstance);

		doDiscoverObjectInstanceCallback(objectClassHandle, objectInstance.getHandle(), objectInstance.getName(),
				getSubscribingFederates(objectClass));
		return objectInstance.getHandle();
	}

	/**
	 * Implements HLA service 10.10 (See IEEE Std 1516.1-2000).
	 * 
	 * @prio 1
	 */
	synchronized ObjectInstanceHandle getObjectInstanceHandle(String theName) throws ObjectInstanceNotKnown {

		for (Federate federate : joinedFederates.values()) {
			for (Iterator iter = federate.getRegisteredObjectInstances().iterator(); iter.hasNext();) {
				ObjectInstance objectInstance = (ObjectInstance) iter.next();
				if (objectInstance.getName().equals(theName)) {
					return objectInstance.getHandle();
				}
			}
		}

		throw new ObjectInstanceNotKnown(String.format(
				"No object instance registered with name '%s' in federation execution '%s'", theName, name));
	}

	/**
	 * Implements HLA service 10.11 (See IEEE Std 1516.1-2000).
	 * 
	 * @prio 1
	 */
	synchronized String getObjectInstanceName(ObjectInstanceHandle objectInstanceHandle) throws ObjectInstanceNotKnown {
		return getObjectInstance(objectInstanceHandle).getName();
	}

	/**
	 * @see FederationExecutionRemote#getSubscriptions(ObjectInstanceHandle,
	 *      AttributeHandle[], FederateHandle)
	 */
	synchronized Map<LrcRemote, Map<FederateHandle, AttributeHandle[]>> getSubscriptions(
			ObjectInstanceHandle objectInstanceHandle, AttributeHandle[] attributeHandles,
			FederateHandle askingFederateHandle) throws AttributeNotDefined, AttributeNotOwned,
			FederateNotExecutionMember, InvalidAttributeHandle, ObjectInstanceNotKnown {
		try {
			Federate askingFederate = getFederate(askingFederateHandle);

			ObjectInstance objectInstance = getObjectInstance(objectInstanceHandle);
			Set<Attribute> providedAttributes = getAttributes(objectInstance.getObjectClass().getHandle(),
					attributeHandles);

			if (!askingFederate.ownsAttributes(objectInstance, providedAttributes)) {
				throw new AttributeNotOwned(String.format(
						"The federate '%s' is not owning all of the given attributes.", askingFederate));
			}

			Map<LrcRemote, Map<FederateHandle, AttributeHandle[]>> result = new HashMap<LrcRemote, Map<FederateHandle, AttributeHandle[]>>();

			// Iterate through each attribute and find the federates which
			// subscribe to at least one of them
			Set<Federate> subscribingFederates = new HashSet<Federate>();

			for (Attribute attribute : providedAttributes) {
				subscribingFederates.addAll(attribute.getSubscribingFederates());
			}

			// Now iterate through theses federates and build the result with an
			// attribute handle array for each federate
			for (Federate federate : subscribingFederates) {
				if (federate.getHandle().equals(askingFederateHandle)) {
					continue;
				}

				LrcRemote lrcRemote = getCrc().getLrcRemote(federate.getLrcHandle());
				if (lrcRemote == null) {
					logger.error(String.format("The LRC with handle [%s] never registered with the CRC"
							+ " or was unregistered before the LRC was shut down. Skip processing LRC", federate
							.getLrcHandle()));
					continue;
				}
				Map<FederateHandle, AttributeHandle[]> federates = result.get(lrcRemote);
				if (federates == null) {
					federates = new HashMap<FederateHandle, AttributeHandle[]>();
					result.put(lrcRemote, federates);
				}

				// The attributes this federate is subscribed to
				Set<Attribute> resultAttributes = new HashSet<Attribute>(federate.getSubscribedAttributes());

				resultAttributes.retainAll(providedAttributes);
				federates.put(federate.getHandle(), getAttributeHandles(resultAttributes));
			}
			return result;
		} catch (ObjectClassNotDefined e) {
			logger
					.fatal("Unexpected ObjectClassNotDefined. Object class of a valid object instance must always be defined, but this seems not the case. This error should never happen");
			throw new RuntimeException(
					"Fatal error: Unexpected ObjectClassNotDefined in FederationExecution#getSubscribedFederates()");
		}
	}

	synchronized private Set<Federate> getSubscribingFederates(Set<Attribute> attributes) {
		Set<Federate> result = new HashSet<Federate>();
		for (Attribute attribute : attributes) {
			for (Iterator iter = attribute.getSubscribingFederates().iterator(); iter.hasNext();) {
				Federate federate = (Federate) iter.next();
				result.add(federate);
			}
		}
		return result;
	}

	/**
	 * Returns all federate which are subscribed to at least one of the
	 * attributes of the given object class.
	 * 
	 * @param objectClass
	 * @return
	 */
	synchronized private Set<Federate> getSubscribingFederates(ObjectClass objectClass) {
		return getSubscribingFederates(new HashSet<Attribute>(objectClass.getAllAttributes()));
	}

	synchronized private Set<Federate> getPublishingFederates(Set<Attribute> attributes) {
		Set<Federate> result = new HashSet<Federate>();
		for (Attribute attribute : attributes) {
			for (Iterator iter = attribute.getPublishingFederates().iterator(); iter.hasNext();) {
				Federate federate = (Federate) iter.next();
				result.add(federate);
			}
		}
		return result;
	}

	synchronized Map<LrcRemote, Set<FederateHandle>> getSubscriptions(InteractionClassHandle interactionClassHandle,
			FederateHandle federateHandle) throws InteractionClassNotDefined, InteractionClassNotPublished,
			FederateNotExecutionMember {
		Federate askingFederate = getFederate(federateHandle);
		InteractionClass interactionClass = getInteractionClass(interactionClassHandle);
		if (!askingFederate.getPublishedInteractions().contains(interactionClass)) {
			throw new InteractionClassNotPublished(String.format(
					"The federate '%s' is not publishing the interaction class %s", askingFederate, interactionClass));
		}
		Set<Federate> federates = new HashSet<Federate>();
		List subscribingFederates = interactionClass.getSubscribingFederates();
		for (Iterator iter = subscribingFederates.iterator(); iter.hasNext();) {
			Federate federate = (Federate) iter.next();
			if (federate != askingFederate) {
				federates.add(federate);
			}
		}
		Map<LrcRemote, Set<FederateHandle>> result = assignFederatesToLrcs(federates);
		return result;
	}

	/**
	 * Implements HLA service 10.16 (See IEEE Std 1516.1-2000).
	 * 
	 * @prio 1
	 */
	synchronized ObjectClassHandle getKnownObjectClassHandle(ObjectInstanceHandle objectInstanceHandle)
			throws ObjectInstanceNotKnown {
		return getObjectInstance(objectInstanceHandle).getObjectClass().getHandle();
	}

	/**
	 * Indexes attributes and object classes using their corresponding handles
	 * as indices. These handles are created here.
	 */
	private void initIndices() {

		OmtSwitch omtSwitch = new OmtSwitch() {
			/**
			 * {@inheritDoc}
			 */
			@Override
			public Object caseAttribute(Attribute attribute) {
				AttributeHandle attributeHandle = nextAttributeHandle();
				attribute.setHandle(attributeHandle);
				attributeHandleIndex.put(attributeHandle, attribute);
				return super.caseAttribute(attribute);
			}

			@Override
			public Object caseParameter(Parameter parameter) {
				ParameterHandle parameterHandle = nextParameterHandle();
				parameter.setHandle(parameterHandle);
				parameterHandleIndex.put(parameterHandle, parameter);
				return super.caseParameter(parameter);
			}

			/**
			 * {@inheritDoc}
			 */
			@Override
			public Object caseObjectClass(ObjectClass objectClass) {
				ObjectClassHandle objectClassHandle = nextObjectClassHandle();
				objectClassHandleIndex.put(objectClassHandle, objectClass);
				objectClass.setHandle(objectClassHandle);
				logger.debug("Index " + objectClassHandle + "->" + objectClass.getQualifiedName(true));
				logger.debug("Index " + objectClassHandle + "->" + objectClass.getQualifiedName(false));
				return super.caseObjectClass(objectClass);
			}

			/**
			 * {@inheritDoc}
			 */
			@Override
			public Object caseInteractionClass(InteractionClass interactionClass) {
				InteractionClassHandle interactionClassHandle = nextInteractionClassHandle();
				interactionClassHandleIndex.put(interactionClassHandle, interactionClass);
				interactionClass.setHandle(interactionClassHandle);
				logger.debug("Index " + interactionClassHandle + "->" + interactionClass.getName());
				return super.caseInteractionClass(interactionClass);
			}
		};

		// Iterate over all model elements
		Iterator it = resource.getAllContents();
		while (it.hasNext()) {
			omtSwitch.doSwitch((EObject) it.next());
		}
	}

	/**
	 * Returns the (always the same) remote proxy of.
	 * 
	 * @return the remote proxy through which this federation execution can be
	 *         acessed from remote.
	 */
	public FederationExecutionRemote getRemoteInterface() {
		return federationExecutionRemote;
	}

	synchronized int getNrOfJoinedFederates() {
		return joinedFederates.size();
	}

	private static Crc getCrc() {
		CrcApplication crcApp = (CrcApplication) AppRegistry.getRootApp();
		return crcApp.getCrcAppModule().getCrc();
	}

	/**
	 * Used for testing only
	 */
	void reset() {
		callbackTasks.shutdownNow();
	}
}
