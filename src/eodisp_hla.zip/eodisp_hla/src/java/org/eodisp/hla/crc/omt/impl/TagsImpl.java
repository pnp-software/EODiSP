/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eodisp.hla.crc.omt.AcquisitionRequestTag;
import org.eodisp.hla.crc.omt.DeleteRemoveTag;
import org.eodisp.hla.crc.omt.DivestitureCompletionTag;
import org.eodisp.hla.crc.omt.DivestitureRequestTag;
import org.eodisp.hla.crc.omt.OmtPackage;
import org.eodisp.hla.crc.omt.RequestUpdateTag;
import org.eodisp.hla.crc.omt.SendReceiveTag;
import org.eodisp.hla.crc.omt.Tags;
import org.eodisp.hla.crc.omt.UpdateReflectTag;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Tags</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.TagsImpl#getUpdateReflectTag <em>Update Reflect Tag</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.TagsImpl#getSendReceiveTag <em>Send Receive Tag</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.TagsImpl#getDeleteRemoveTag <em>Delete Remove Tag</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.TagsImpl#getDivestitureRequestTag <em>Divestiture Request Tag</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.TagsImpl#getDivestitureCompletionTag <em>Divestiture Completion Tag</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.TagsImpl#getAcquisitionRequestTag <em>Acquisition Request Tag</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.TagsImpl#getRequestUpdateTag <em>Request Update Tag</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class TagsImpl extends EObjectImpl implements Tags {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The cached value of the '{@link #getUpdateReflectTag() <em>Update Reflect Tag</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getUpdateReflectTag()
	 * @generated
	 * @ordered
	 */
	protected UpdateReflectTag updateReflectTag = null;

	/**
	 * The cached value of the '{@link #getSendReceiveTag() <em>Send Receive Tag</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSendReceiveTag()
	 * @generated
	 * @ordered
	 */
	protected SendReceiveTag sendReceiveTag = null;

	/**
	 * The cached value of the '{@link #getDeleteRemoveTag() <em>Delete Remove Tag</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDeleteRemoveTag()
	 * @generated
	 * @ordered
	 */
	protected DeleteRemoveTag deleteRemoveTag = null;

	/**
	 * The cached value of the '{@link #getDivestitureRequestTag() <em>Divestiture Request Tag</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDivestitureRequestTag()
	 * @generated
	 * @ordered
	 */
	protected DivestitureRequestTag divestitureRequestTag = null;

	/**
	 * The cached value of the '{@link #getDivestitureCompletionTag() <em>Divestiture Completion Tag</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDivestitureCompletionTag()
	 * @generated
	 * @ordered
	 */
	protected DivestitureCompletionTag divestitureCompletionTag = null;

	/**
	 * The cached value of the '{@link #getAcquisitionRequestTag() <em>Acquisition Request Tag</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getAcquisitionRequestTag()
	 * @generated
	 * @ordered
	 */
	protected AcquisitionRequestTag acquisitionRequestTag = null;

	/**
	 * The cached value of the '{@link #getRequestUpdateTag() <em>Request Update Tag</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getRequestUpdateTag()
	 * @generated
	 * @ordered
	 */
	protected RequestUpdateTag requestUpdateTag = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected TagsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return OmtPackage.Literals.TAGS;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public UpdateReflectTag getUpdateReflectTag() {
		return updateReflectTag;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetUpdateReflectTag(UpdateReflectTag newUpdateReflectTag, NotificationChain msgs) {
		UpdateReflectTag oldUpdateReflectTag = updateReflectTag;
		updateReflectTag = newUpdateReflectTag;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.TAGS__UPDATE_REFLECT_TAG,
					oldUpdateReflectTag,
					newUpdateReflectTag);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setUpdateReflectTag(UpdateReflectTag newUpdateReflectTag) {
		if (newUpdateReflectTag != updateReflectTag) {
			NotificationChain msgs = null;
			if (updateReflectTag != null)
				msgs = ((InternalEObject) updateReflectTag).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.TAGS__UPDATE_REFLECT_TAG, null, msgs);
			if (newUpdateReflectTag != null)
				msgs = ((InternalEObject) newUpdateReflectTag).eInverseAdd(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.TAGS__UPDATE_REFLECT_TAG, null, msgs);
			msgs = basicSetUpdateReflectTag(newUpdateReflectTag, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.TAGS__UPDATE_REFLECT_TAG,
					newUpdateReflectTag,
					newUpdateReflectTag));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public SendReceiveTag getSendReceiveTag() {
		return sendReceiveTag;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetSendReceiveTag(SendReceiveTag newSendReceiveTag, NotificationChain msgs) {
		SendReceiveTag oldSendReceiveTag = sendReceiveTag;
		sendReceiveTag = newSendReceiveTag;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.TAGS__SEND_RECEIVE_TAG,
					oldSendReceiveTag,
					newSendReceiveTag);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setSendReceiveTag(SendReceiveTag newSendReceiveTag) {
		if (newSendReceiveTag != sendReceiveTag) {
			NotificationChain msgs = null;
			if (sendReceiveTag != null)
				msgs = ((InternalEObject) sendReceiveTag).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.TAGS__SEND_RECEIVE_TAG, null, msgs);
			if (newSendReceiveTag != null)
				msgs = ((InternalEObject) newSendReceiveTag).eInverseAdd(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.TAGS__SEND_RECEIVE_TAG, null, msgs);
			msgs = basicSetSendReceiveTag(newSendReceiveTag, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.TAGS__SEND_RECEIVE_TAG,
					newSendReceiveTag,
					newSendReceiveTag));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public DeleteRemoveTag getDeleteRemoveTag() {
		return deleteRemoveTag;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetDeleteRemoveTag(DeleteRemoveTag newDeleteRemoveTag, NotificationChain msgs) {
		DeleteRemoveTag oldDeleteRemoveTag = deleteRemoveTag;
		deleteRemoveTag = newDeleteRemoveTag;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.TAGS__DELETE_REMOVE_TAG,
					oldDeleteRemoveTag,
					newDeleteRemoveTag);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setDeleteRemoveTag(DeleteRemoveTag newDeleteRemoveTag) {
		if (newDeleteRemoveTag != deleteRemoveTag) {
			NotificationChain msgs = null;
			if (deleteRemoveTag != null)
				msgs = ((InternalEObject) deleteRemoveTag).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.TAGS__DELETE_REMOVE_TAG, null, msgs);
			if (newDeleteRemoveTag != null)
				msgs = ((InternalEObject) newDeleteRemoveTag).eInverseAdd(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.TAGS__DELETE_REMOVE_TAG, null, msgs);
			msgs = basicSetDeleteRemoveTag(newDeleteRemoveTag, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.TAGS__DELETE_REMOVE_TAG,
					newDeleteRemoveTag,
					newDeleteRemoveTag));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public DivestitureRequestTag getDivestitureRequestTag() {
		return divestitureRequestTag;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetDivestitureRequestTag(DivestitureRequestTag newDivestitureRequestTag,
			NotificationChain msgs) {
		DivestitureRequestTag oldDivestitureRequestTag = divestitureRequestTag;
		divestitureRequestTag = newDivestitureRequestTag;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.TAGS__DIVESTITURE_REQUEST_TAG,
					oldDivestitureRequestTag,
					newDivestitureRequestTag);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setDivestitureRequestTag(DivestitureRequestTag newDivestitureRequestTag) {
		if (newDivestitureRequestTag != divestitureRequestTag) {
			NotificationChain msgs = null;
			if (divestitureRequestTag != null)
				msgs = ((InternalEObject) divestitureRequestTag).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.TAGS__DIVESTITURE_REQUEST_TAG, null, msgs);
			if (newDivestitureRequestTag != null)
				msgs = ((InternalEObject) newDivestitureRequestTag).eInverseAdd(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.TAGS__DIVESTITURE_REQUEST_TAG, null, msgs);
			msgs = basicSetDivestitureRequestTag(newDivestitureRequestTag, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.TAGS__DIVESTITURE_REQUEST_TAG,
					newDivestitureRequestTag,
					newDivestitureRequestTag));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public DivestitureCompletionTag getDivestitureCompletionTag() {
		return divestitureCompletionTag;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetDivestitureCompletionTag(DivestitureCompletionTag newDivestitureCompletionTag,
			NotificationChain msgs) {
		DivestitureCompletionTag oldDivestitureCompletionTag = divestitureCompletionTag;
		divestitureCompletionTag = newDivestitureCompletionTag;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.TAGS__DIVESTITURE_COMPLETION_TAG,
					oldDivestitureCompletionTag,
					newDivestitureCompletionTag);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setDivestitureCompletionTag(DivestitureCompletionTag newDivestitureCompletionTag) {
		if (newDivestitureCompletionTag != divestitureCompletionTag) {
			NotificationChain msgs = null;
			if (divestitureCompletionTag != null)
				msgs = ((InternalEObject) divestitureCompletionTag).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.TAGS__DIVESTITURE_COMPLETION_TAG, null, msgs);
			if (newDivestitureCompletionTag != null)
				msgs = ((InternalEObject) newDivestitureCompletionTag).eInverseAdd(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.TAGS__DIVESTITURE_COMPLETION_TAG, null, msgs);
			msgs = basicSetDivestitureCompletionTag(newDivestitureCompletionTag, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.TAGS__DIVESTITURE_COMPLETION_TAG,
					newDivestitureCompletionTag,
					newDivestitureCompletionTag));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public AcquisitionRequestTag getAcquisitionRequestTag() {
		return acquisitionRequestTag;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetAcquisitionRequestTag(AcquisitionRequestTag newAcquisitionRequestTag,
			NotificationChain msgs) {
		AcquisitionRequestTag oldAcquisitionRequestTag = acquisitionRequestTag;
		acquisitionRequestTag = newAcquisitionRequestTag;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.TAGS__ACQUISITION_REQUEST_TAG,
					oldAcquisitionRequestTag,
					newAcquisitionRequestTag);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setAcquisitionRequestTag(AcquisitionRequestTag newAcquisitionRequestTag) {
		if (newAcquisitionRequestTag != acquisitionRequestTag) {
			NotificationChain msgs = null;
			if (acquisitionRequestTag != null)
				msgs = ((InternalEObject) acquisitionRequestTag).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.TAGS__ACQUISITION_REQUEST_TAG, null, msgs);
			if (newAcquisitionRequestTag != null)
				msgs = ((InternalEObject) newAcquisitionRequestTag).eInverseAdd(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.TAGS__ACQUISITION_REQUEST_TAG, null, msgs);
			msgs = basicSetAcquisitionRequestTag(newAcquisitionRequestTag, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.TAGS__ACQUISITION_REQUEST_TAG,
					newAcquisitionRequestTag,
					newAcquisitionRequestTag));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public RequestUpdateTag getRequestUpdateTag() {
		return requestUpdateTag;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetRequestUpdateTag(RequestUpdateTag newRequestUpdateTag, NotificationChain msgs) {
		RequestUpdateTag oldRequestUpdateTag = requestUpdateTag;
		requestUpdateTag = newRequestUpdateTag;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.TAGS__REQUEST_UPDATE_TAG,
					oldRequestUpdateTag,
					newRequestUpdateTag);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setRequestUpdateTag(RequestUpdateTag newRequestUpdateTag) {
		if (newRequestUpdateTag != requestUpdateTag) {
			NotificationChain msgs = null;
			if (requestUpdateTag != null)
				msgs = ((InternalEObject) requestUpdateTag).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.TAGS__REQUEST_UPDATE_TAG, null, msgs);
			if (newRequestUpdateTag != null)
				msgs = ((InternalEObject) newRequestUpdateTag).eInverseAdd(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.TAGS__REQUEST_UPDATE_TAG, null, msgs);
			msgs = basicSetRequestUpdateTag(newRequestUpdateTag, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.TAGS__REQUEST_UPDATE_TAG,
					newRequestUpdateTag,
					newRequestUpdateTag));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case OmtPackage.TAGS__UPDATE_REFLECT_TAG:
			return basicSetUpdateReflectTag(null, msgs);
		case OmtPackage.TAGS__SEND_RECEIVE_TAG:
			return basicSetSendReceiveTag(null, msgs);
		case OmtPackage.TAGS__DELETE_REMOVE_TAG:
			return basicSetDeleteRemoveTag(null, msgs);
		case OmtPackage.TAGS__DIVESTITURE_REQUEST_TAG:
			return basicSetDivestitureRequestTag(null, msgs);
		case OmtPackage.TAGS__DIVESTITURE_COMPLETION_TAG:
			return basicSetDivestitureCompletionTag(null, msgs);
		case OmtPackage.TAGS__ACQUISITION_REQUEST_TAG:
			return basicSetAcquisitionRequestTag(null, msgs);
		case OmtPackage.TAGS__REQUEST_UPDATE_TAG:
			return basicSetRequestUpdateTag(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case OmtPackage.TAGS__UPDATE_REFLECT_TAG:
			return getUpdateReflectTag();
		case OmtPackage.TAGS__SEND_RECEIVE_TAG:
			return getSendReceiveTag();
		case OmtPackage.TAGS__DELETE_REMOVE_TAG:
			return getDeleteRemoveTag();
		case OmtPackage.TAGS__DIVESTITURE_REQUEST_TAG:
			return getDivestitureRequestTag();
		case OmtPackage.TAGS__DIVESTITURE_COMPLETION_TAG:
			return getDivestitureCompletionTag();
		case OmtPackage.TAGS__ACQUISITION_REQUEST_TAG:
			return getAcquisitionRequestTag();
		case OmtPackage.TAGS__REQUEST_UPDATE_TAG:
			return getRequestUpdateTag();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case OmtPackage.TAGS__UPDATE_REFLECT_TAG:
			setUpdateReflectTag((UpdateReflectTag) newValue);
			return;
		case OmtPackage.TAGS__SEND_RECEIVE_TAG:
			setSendReceiveTag((SendReceiveTag) newValue);
			return;
		case OmtPackage.TAGS__DELETE_REMOVE_TAG:
			setDeleteRemoveTag((DeleteRemoveTag) newValue);
			return;
		case OmtPackage.TAGS__DIVESTITURE_REQUEST_TAG:
			setDivestitureRequestTag((DivestitureRequestTag) newValue);
			return;
		case OmtPackage.TAGS__DIVESTITURE_COMPLETION_TAG:
			setDivestitureCompletionTag((DivestitureCompletionTag) newValue);
			return;
		case OmtPackage.TAGS__ACQUISITION_REQUEST_TAG:
			setAcquisitionRequestTag((AcquisitionRequestTag) newValue);
			return;
		case OmtPackage.TAGS__REQUEST_UPDATE_TAG:
			setRequestUpdateTag((RequestUpdateTag) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
		case OmtPackage.TAGS__UPDATE_REFLECT_TAG:
			setUpdateReflectTag((UpdateReflectTag) null);
			return;
		case OmtPackage.TAGS__SEND_RECEIVE_TAG:
			setSendReceiveTag((SendReceiveTag) null);
			return;
		case OmtPackage.TAGS__DELETE_REMOVE_TAG:
			setDeleteRemoveTag((DeleteRemoveTag) null);
			return;
		case OmtPackage.TAGS__DIVESTITURE_REQUEST_TAG:
			setDivestitureRequestTag((DivestitureRequestTag) null);
			return;
		case OmtPackage.TAGS__DIVESTITURE_COMPLETION_TAG:
			setDivestitureCompletionTag((DivestitureCompletionTag) null);
			return;
		case OmtPackage.TAGS__ACQUISITION_REQUEST_TAG:
			setAcquisitionRequestTag((AcquisitionRequestTag) null);
			return;
		case OmtPackage.TAGS__REQUEST_UPDATE_TAG:
			setRequestUpdateTag((RequestUpdateTag) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case OmtPackage.TAGS__UPDATE_REFLECT_TAG:
			return updateReflectTag != null;
		case OmtPackage.TAGS__SEND_RECEIVE_TAG:
			return sendReceiveTag != null;
		case OmtPackage.TAGS__DELETE_REMOVE_TAG:
			return deleteRemoveTag != null;
		case OmtPackage.TAGS__DIVESTITURE_REQUEST_TAG:
			return divestitureRequestTag != null;
		case OmtPackage.TAGS__DIVESTITURE_COMPLETION_TAG:
			return divestitureCompletionTag != null;
		case OmtPackage.TAGS__ACQUISITION_REQUEST_TAG:
			return acquisitionRequestTag != null;
		case OmtPackage.TAGS__REQUEST_UPDATE_TAG:
			return requestUpdateTag != null;
		}
		return super.eIsSet(featureID);
	}

} // TagsImpl
