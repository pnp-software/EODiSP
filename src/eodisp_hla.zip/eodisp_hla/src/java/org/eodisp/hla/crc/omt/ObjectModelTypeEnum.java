/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.AbstractEnumerator;

/**
 * <!-- begin-user-doc --> A representation of the literals of the enumeration '<em><b>Object Model Type Enum</b></em>',
 * and utility methods for working with them. <!-- end-user-doc -->
 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModelTypeEnum()
 * @model
 * @generated
 */
public final class ObjectModelTypeEnum extends AbstractEnumerator {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The '<em><b>FOM</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>FOM</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #FOM_LITERAL
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int FOM = 0;

	/**
	 * The '<em><b>SOM</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>SOM</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #SOM_LITERAL
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int SOM = 1;

	/**
	 * The '<em><b>FOM</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #FOM
	 * @generated
	 * @ordered
	 */
	public static final ObjectModelTypeEnum FOM_LITERAL = new ObjectModelTypeEnum(FOM, "FOM", "FOM");

	/**
	 * The '<em><b>SOM</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SOM
	 * @generated
	 * @ordered
	 */
	public static final ObjectModelTypeEnum SOM_LITERAL = new ObjectModelTypeEnum(SOM, "SOM", "SOM");

	/**
	 * An array of all the '<em><b>Object Model Type Enum</b></em>' enumerators.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private static final ObjectModelTypeEnum[] VALUES_ARRAY = new ObjectModelTypeEnum[] { FOM_LITERAL, SOM_LITERAL, };

	/**
	 * A public read-only list of all the '<em><b>Object Model Type Enum</b></em>' enumerators.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public static final List VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Object Model Type Enum</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public static ObjectModelTypeEnum get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			ObjectModelTypeEnum result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Object Model Type Enum</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static ObjectModelTypeEnum getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			ObjectModelTypeEnum result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Object Model Type Enum</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public static ObjectModelTypeEnum get(int value) {
		switch (value) {
		case FOM:
			return FOM_LITERAL;
		case SOM:
			return SOM_LITERAL;
		}
		return null;
	}

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private ObjectModelTypeEnum(int value, String name, String literal) {
		super(value, name, literal);
	}

} // ObjectModelTypeEnum
