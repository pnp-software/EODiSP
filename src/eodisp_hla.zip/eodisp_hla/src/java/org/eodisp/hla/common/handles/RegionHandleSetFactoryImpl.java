package org.eodisp.hla.common.handles;

import hla.rti1516.RegionHandleSet;
import hla.rti1516.RegionHandleSetFactory;

public class RegionHandleSetFactoryImpl implements RegionHandleSetFactory {
	public RegionHandleSet create() {
		return new RegionHandleSetImpl();
	}
}
