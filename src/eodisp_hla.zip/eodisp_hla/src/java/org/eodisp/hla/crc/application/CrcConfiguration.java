/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.hla.crc.application;

import java.io.File;

import org.eodisp.util.configuration.ConfigurationImpl;

/**
 * Configuration Implementation of the Crc
 * 
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class CrcConfiguration extends ConfigurationImpl {

	/**
	 * The Id of this configuration.This id can be used to retrieve the
	 * configuration entries.
	 */
	public static final String ID = "org.eodisp.hla.lrc.application.CrcConfiguration";

	/**
	 * The name of the configuration. This will be shown on the command line.
	 */
	public static final String NAME = "Central RTI Component (CRC) Configuration";

	/**
	 * Describes the configuration. This will be shown on the command line.
	 */
	public static final String DESCRIPTION = "Configuration of the Central RTI component. The location of this configuration can be set through the java system property 'eodisp.crc.config-file'";

	private static final String MAX_CALLBACK_THREADS = "max-callback-threads";

	/**
	 * {@inheritDoc}
	 */
	public CrcConfiguration(File file) {
		super(ID, NAME, DESCRIPTION, file);
		createIntEntry(MAX_CALLBACK_THREADS, 20, "The maximal number of threads spawned for callbacks to LRCs.");
	}
	
	public int getMaxCallbackThreads() {
		 return getEntry(MAX_CALLBACK_THREADS).getInt(); 
	}

	public void setMaxCallbackThreads(int maxCallbackThreads) {
		 getEntry(MAX_CALLBACK_THREADS).setInt(maxCallbackThreads); 
	}

	public static void main(String[] args) {
		System.out.println(new CrcConfiguration(null).getCode());
	}
}
