/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.AbstractEnumerator;

/**
 * <!-- begin-user-doc --> A representation of the literals of the enumeration '<em><b>Endian Enum</b></em>',
 * and utility methods for working with them. <!-- end-user-doc -->
 * @see org.eodisp.hla.crc.omt.OmtPackage#getEndianEnum()
 * @model
 * @generated
 */
public final class EndianEnum extends AbstractEnumerator {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The '<em><b>Big</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Big</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #BIG_LITERAL
	 * @model name="Big"
	 * @generated
	 * @ordered
	 */
	public static final int BIG = 0;

	/**
	 * The '<em><b>Little</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Little</b></em>' literal object isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #LITTLE_LITERAL
	 * @model name="Little"
	 * @generated
	 * @ordered
	 */
	public static final int LITTLE = 1;

	/**
	 * The '<em><b>Big</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #BIG
	 * @generated
	 * @ordered
	 */
	public static final EndianEnum BIG_LITERAL = new EndianEnum(BIG, "Big", "Big");

	/**
	 * The '<em><b>Little</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #LITTLE
	 * @generated
	 * @ordered
	 */
	public static final EndianEnum LITTLE_LITERAL = new EndianEnum(LITTLE, "Little", "Little");

	/**
	 * An array of all the '<em><b>Endian Enum</b></em>' enumerators. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	private static final EndianEnum[] VALUES_ARRAY = new EndianEnum[] { BIG_LITERAL, LITTLE_LITERAL, };

	/**
	 * A public read-only list of all the '<em><b>Endian Enum</b></em>' enumerators.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public static final List VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Endian Enum</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public static EndianEnum get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			EndianEnum result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Endian Enum</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static EndianEnum getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			EndianEnum result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Endian Enum</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public static EndianEnum get(int value) {
		switch (value) {
		case BIG:
			return BIG_LITERAL;
		case LITTLE:
			return LITTLE_LITERAL;
		}
		return null;
	}

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EndianEnum(int value, String name, String literal) {
		super(value, name, literal);
	}

} // EndianEnum
