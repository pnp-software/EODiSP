/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt.util;

import java.util.List;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eodisp.hla.crc.omt.*;

/**
 * <!-- begin-user-doc --> The <b>Switch</b> for the model's inheritance
 * hierarchy. It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object and proceeding up the
 * inheritance hierarchy until a non-null result is returned, which is the
 * result of the switch. <!-- end-user-doc -->
 * @see org.eodisp.hla.crc.omt.OmtPackage
 * @generated
 */
public class OmtSwitch {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The cached model package
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected static OmtPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * @generated
	 */
	public OmtSwitch() {
		if (modelPackage == null) {
			modelPackage = OmtPackage.eINSTANCE;
		}
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	public Object doSwitch(EObject theEObject) {
		return doSwitch(theEObject.eClass(), theEObject);
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	protected Object doSwitch(EClass theEClass, EObject theEObject) {
		if (theEClass.eContainer() == modelPackage) {
			return doSwitch(theEClass.getClassifierID(), theEObject);
		} else {
			List eSuperTypes = theEClass.getESuperTypes();
			return eSuperTypes.isEmpty() ? defaultCase(theEObject) : doSwitch((EClass) eSuperTypes.get(0), theEObject);
		}
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	protected Object doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case OmtPackage.ACQUISITION_REQUEST_TAG: {
			AcquisitionRequestTag acquisitionRequestTag = (AcquisitionRequestTag) theEObject;
			Object result = caseAcquisitionRequestTag(acquisitionRequestTag);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.ALTERNATIVE: {
			Alternative alternative = (Alternative) theEObject;
			Object result = caseAlternative(alternative);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.ARRAY_DATA: {
			ArrayData arrayData = (ArrayData) theEObject;
			Object result = caseArrayData(arrayData);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.ARRAY_DATA_TYPES: {
			ArrayDataTypes arrayDataTypes = (ArrayDataTypes) theEObject;
			Object result = caseArrayDataTypes(arrayDataTypes);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.ATTRIBUTE: {
			Attribute attribute = (Attribute) theEObject;
			Object result = caseAttribute(attribute);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.BASIC_DATA: {
			BasicData basicData = (BasicData) theEObject;
			Object result = caseBasicData(basicData);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.BASIC_DATA_REPRESENTATIONS: {
			BasicDataRepresentations basicDataRepresentations = (BasicDataRepresentations) theEObject;
			Object result = caseBasicDataRepresentations(basicDataRepresentations);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.DATA_TYPES: {
			DataTypes dataTypes = (DataTypes) theEObject;
			Object result = caseDataTypes(dataTypes);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.DELETE_REMOVE_TAG: {
			DeleteRemoveTag deleteRemoveTag = (DeleteRemoveTag) theEObject;
			Object result = caseDeleteRemoveTag(deleteRemoveTag);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.DIMENSION: {
			Dimension dimension = (Dimension) theEObject;
			Object result = caseDimension(dimension);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.DIMENSIONS: {
			Dimensions dimensions = (Dimensions) theEObject;
			Object result = caseDimensions(dimensions);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.DIVESTITURE_COMPLETION_TAG: {
			DivestitureCompletionTag divestitureCompletionTag = (DivestitureCompletionTag) theEObject;
			Object result = caseDivestitureCompletionTag(divestitureCompletionTag);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.DIVESTITURE_REQUEST_TAG: {
			DivestitureRequestTag divestitureRequestTag = (DivestitureRequestTag) theEObject;
			Object result = caseDivestitureRequestTag(divestitureRequestTag);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.DOCUMENT_ROOT: {
			DocumentRoot documentRoot = (DocumentRoot) theEObject;
			Object result = caseDocumentRoot(documentRoot);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.ENUMERATED_DATA: {
			EnumeratedData enumeratedData = (EnumeratedData) theEObject;
			Object result = caseEnumeratedData(enumeratedData);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.ENUMERATED_DATA_TYPES: {
			EnumeratedDataTypes enumeratedDataTypes = (EnumeratedDataTypes) theEObject;
			Object result = caseEnumeratedDataTypes(enumeratedDataTypes);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.ENUMERATOR: {
			Enumerator enumerator = (Enumerator) theEObject;
			Object result = caseEnumerator(enumerator);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.FIELD: {
			Field field = (Field) theEObject;
			Object result = caseField(field);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.FIXED_RECORD_DATA: {
			FixedRecordData fixedRecordData = (FixedRecordData) theEObject;
			Object result = caseFixedRecordData(fixedRecordData);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.FIXED_RECORD_DATA_TYPES: {
			FixedRecordDataTypes fixedRecordDataTypes = (FixedRecordDataTypes) theEObject;
			Object result = caseFixedRecordDataTypes(fixedRecordDataTypes);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.INTERACTION_CLASS: {
			InteractionClass interactionClass = (InteractionClass) theEObject;
			Object result = caseInteractionClass(interactionClass);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.INTERACTIONS: {
			Interactions interactions = (Interactions) theEObject;
			Object result = caseInteractions(interactions);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.LOOKAHEAD: {
			Lookahead lookahead = (Lookahead) theEObject;
			Object result = caseLookahead(lookahead);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.NOTE: {
			Note note = (Note) theEObject;
			Object result = caseNote(note);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.NOTES: {
			Notes notes = (Notes) theEObject;
			Object result = caseNotes(notes);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.OBJECT_CLASS: {
			ObjectClass objectClass = (ObjectClass) theEObject;
			Object result = caseObjectClass(objectClass);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.OBJECT_MODEL: {
			ObjectModel objectModel = (ObjectModel) theEObject;
			Object result = caseObjectModel(objectModel);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.OBJECTS: {
			Objects objects = (Objects) theEObject;
			Object result = caseObjects(objects);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.PARAMETER: {
			Parameter parameter = (Parameter) theEObject;
			Object result = caseParameter(parameter);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.REQUEST_UPDATE_TAG: {
			RequestUpdateTag requestUpdateTag = (RequestUpdateTag) theEObject;
			Object result = caseRequestUpdateTag(requestUpdateTag);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.SEND_RECEIVE_TAG: {
			SendReceiveTag sendReceiveTag = (SendReceiveTag) theEObject;
			Object result = caseSendReceiveTag(sendReceiveTag);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.SIMPLE_DATA: {
			SimpleData simpleData = (SimpleData) theEObject;
			Object result = caseSimpleData(simpleData);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.SIMPLE_DATA_TYPES: {
			SimpleDataTypes simpleDataTypes = (SimpleDataTypes) theEObject;
			Object result = caseSimpleDataTypes(simpleDataTypes);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.SWITCHES: {
			Switches switches = (Switches) theEObject;
			Object result = caseSwitches(switches);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.SYNCHRONIZATION: {
			Synchronization synchronization = (Synchronization) theEObject;
			Object result = caseSynchronization(synchronization);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.SYNCHRONIZATIONS: {
			Synchronizations synchronizations = (Synchronizations) theEObject;
			Object result = caseSynchronizations(synchronizations);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.TAGS: {
			Tags tags = (Tags) theEObject;
			Object result = caseTags(tags);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.TIME: {
			Time time = (Time) theEObject;
			Object result = caseTime(time);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.TIME_STAMP: {
			TimeStamp timeStamp = (TimeStamp) theEObject;
			Object result = caseTimeStamp(timeStamp);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.TRANSPORTATION: {
			Transportation transportation = (Transportation) theEObject;
			Object result = caseTransportation(transportation);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.TRANSPORTATIONS: {
			Transportations transportations = (Transportations) theEObject;
			Object result = caseTransportations(transportations);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.UPDATE_REFLECT_TAG: {
			UpdateReflectTag updateReflectTag = (UpdateReflectTag) theEObject;
			Object result = caseUpdateReflectTag(updateReflectTag);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.VARIANT_RECORD_DATA: {
			VariantRecordData variantRecordData = (VariantRecordData) theEObject;
			Object result = caseVariantRecordData(variantRecordData);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case OmtPackage.VARIANT_RECORD_DATA_TYPES: {
			VariantRecordDataTypes variantRecordDataTypes = (VariantRecordDataTypes) theEObject;
			Object result = caseVariantRecordDataTypes(variantRecordDataTypes);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Acquisition Request Tag</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Acquisition Request Tag</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseAcquisitionRequestTag(AcquisitionRequestTag object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Alternative</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Alternative</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseAlternative(Alternative object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Array Data</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Array Data</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseArrayData(ArrayData object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Array Data Types</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Array Data Types</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseArrayDataTypes(ArrayDataTypes object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Attribute</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Attribute</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseAttribute(Attribute object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Basic Data</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Basic Data</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseBasicData(BasicData object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Basic Data Representations</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Basic Data Representations</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseBasicDataRepresentations(BasicDataRepresentations object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Data Types</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Data Types</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseDataTypes(DataTypes object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Delete Remove Tag</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Delete Remove Tag</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseDeleteRemoveTag(DeleteRemoveTag object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Dimension</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Dimension</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseDimension(Dimension object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Dimensions</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Dimensions</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseDimensions(Dimensions object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Divestiture Completion Tag</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Divestiture Completion Tag</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseDivestitureCompletionTag(DivestitureCompletionTag object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Divestiture Request Tag</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Divestiture Request Tag</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseDivestitureRequestTag(DivestitureRequestTag object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Document Root</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Document Root</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseDocumentRoot(DocumentRoot object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Enumerated Data</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Enumerated Data</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseEnumeratedData(EnumeratedData object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Enumerated Data Types</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Enumerated Data Types</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseEnumeratedDataTypes(EnumeratedDataTypes object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Enumerator</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Enumerator</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseEnumerator(Enumerator object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Field</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Field</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseField(Field object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Fixed Record Data</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Fixed Record Data</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseFixedRecordData(FixedRecordData object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Fixed Record Data Types</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Fixed Record Data Types</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseFixedRecordDataTypes(FixedRecordDataTypes object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Interaction Class</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Interaction Class</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseInteractionClass(InteractionClass object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Interactions</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Interactions</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseInteractions(Interactions object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Lookahead</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Lookahead</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseLookahead(Lookahead object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Note</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Note</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseNote(Note object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Notes</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Notes</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseNotes(Notes object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Object Class</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Object Class</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseObjectClass(ObjectClass object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Object Model</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Object Model</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseObjectModel(ObjectModel object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Objects</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Objects</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseObjects(Objects object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Parameter</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Parameter</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseParameter(Parameter object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Request Update Tag</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Request Update Tag</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseRequestUpdateTag(RequestUpdateTag object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Send Receive Tag</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Send Receive Tag</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseSendReceiveTag(SendReceiveTag object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Simple Data</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Simple Data</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseSimpleData(SimpleData object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Simple Data Types</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Simple Data Types</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseSimpleDataTypes(SimpleDataTypes object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Switches</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Switches</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseSwitches(Switches object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Synchronization</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Synchronization</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseSynchronization(Synchronization object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Synchronizations</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Synchronizations</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseSynchronizations(Synchronizations object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Tags</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Tags</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseTags(Tags object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Time</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Time</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseTime(Time object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Time Stamp</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Time Stamp</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseTimeStamp(TimeStamp object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Transportation</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Transportation</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseTransportation(Transportation object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Transportations</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Transportations</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseTransportations(Transportations object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Update Reflect Tag</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Update Reflect Tag</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseUpdateReflectTag(UpdateReflectTag object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Variant Record Data</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Variant Record Data</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseVariantRecordData(VariantRecordData object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Variant Record Data Types</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Variant Record Data Types</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseVariantRecordDataTypes(VariantRecordDataTypes object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch, but this is the last case
	 * anyway. <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	public Object defaultCase(EObject object) {
		return null;
	}

} // OmtSwitch
