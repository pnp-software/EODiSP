/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt;

import java.util.List;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Variant Record Data</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.VariantRecordData#getAlternative <em>Alternative</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.VariantRecordData#getDataType <em>Data Type</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.VariantRecordData#getDataTypeNotes <em>Data Type Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.VariantRecordData#getDiscriminant <em>Discriminant</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.VariantRecordData#getDiscriminantNotes <em>Discriminant Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.VariantRecordData#getEncoding <em>Encoding</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.VariantRecordData#getEncodingNotes <em>Encoding Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.VariantRecordData#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.VariantRecordData#getNameNotes <em>Name Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.VariantRecordData#getSemantics <em>Semantics</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.VariantRecordData#getSemanticsNotes <em>Semantics Notes</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eodisp.hla.crc.omt.OmtPackage#getVariantRecordData()
 * @model extendedMetaData="name='VariantRecordData' kind='elementOnly'"
 * @generated
 */
public interface VariantRecordData extends EObject {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * Returns the value of the '<em><b>Alternative</b></em>' containment reference list.
	 * The list contents are of type {@link org.eodisp.hla.crc.omt.Alternative}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Alternative</em>' containment reference
	 * list isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Alternative</em>' containment reference list.
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getVariantRecordData_Alternative()
	 * @model type="org.eodisp.hla.crc.omt.Alternative" containment="true" required="true"
	 *        extendedMetaData="kind='element' name='alternative' namespace='##targetNamespace'"
	 * @generated
	 */
	EList getAlternative();

	/**
	 * Returns the value of the '<em><b>Data Type</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Data Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Data Type</em>' attribute.
	 * @see #setDataType(String)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getVariantRecordData_DataType()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKEN"
	 *        extendedMetaData="kind='attribute' name='dataType'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	String getDataType();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.VariantRecordData#getDataType <em>Data Type</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Data Type</em>' attribute.
	 * @see #getDataType()
	 * @generated
	 */
	void setDataType(String value);

	/**
	 * Returns the value of the '<em><b>Data Type Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Data Type Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Data Type Notes</em>' attribute.
	 * @see #setDataTypeNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getVariantRecordData_DataTypeNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='dataTypeNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getDataTypeNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.VariantRecordData#getDataTypeNotes <em>Data Type Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Data Type Notes</em>' attribute.
	 * @see #getDataTypeNotes()
	 * @generated
	 */
	void setDataTypeNotes(List value);

	/**
	 * Returns the value of the '<em><b>Discriminant</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Discriminant</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Discriminant</em>' attribute.
	 * @see #setDiscriminant(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getVariantRecordData_Discriminant()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='discriminant' namespace='##targetNamespace'"
	 * @generated
	 */
	Object getDiscriminant();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.VariantRecordData#getDiscriminant <em>Discriminant</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Discriminant</em>' attribute.
	 * @see #getDiscriminant()
	 * @generated
	 */
	void setDiscriminant(Object value);

	/**
	 * Returns the value of the '<em><b>Discriminant Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Discriminant Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Discriminant Notes</em>' attribute.
	 * @see #setDiscriminantNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getVariantRecordData_DiscriminantNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='discriminantNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getDiscriminantNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.VariantRecordData#getDiscriminantNotes <em>Discriminant Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Discriminant Notes</em>' attribute.
	 * @see #getDiscriminantNotes()
	 * @generated
	 */
	void setDiscriminantNotes(List value);

	/**
	 * Returns the value of the '<em><b>Encoding</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Encoding</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Encoding</em>' attribute.
	 * @see #setEncoding(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getVariantRecordData_Encoding()
	 * @model unique="false"
	 *        dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='encoding'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	Object getEncoding();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.VariantRecordData#getEncoding <em>Encoding</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Encoding</em>' attribute.
	 * @see #getEncoding()
	 * @generated
	 */
	void setEncoding(Object value);

	/**
	 * Returns the value of the '<em><b>Encoding Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Encoding Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Encoding Notes</em>' attribute.
	 * @see #setEncodingNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getVariantRecordData_EncodingNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='encodingNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getEncodingNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.VariantRecordData#getEncodingNotes <em>Encoding Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Encoding Notes</em>' attribute.
	 * @see #getEncodingNotes()
	 * @generated
	 */
	void setEncodingNotes(List value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getVariantRecordData_Name()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKEN"
	 *        required="true" extendedMetaData="kind='attribute' name='name'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.VariantRecordData#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Name Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name Notes</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name Notes</em>' attribute.
	 * @see #setNameNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getVariantRecordData_NameNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='nameNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getNameNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.VariantRecordData#getNameNotes <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name Notes</em>' attribute.
	 * @see #getNameNotes()
	 * @generated
	 */
	void setNameNotes(List value);

	/**
	 * Returns the value of the '<em><b>Semantics</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Semantics</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Semantics</em>' attribute.
	 * @see #setSemantics(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getVariantRecordData_Semantics()
	 * @model unique="false"
	 *        dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='semantics'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	Object getSemantics();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.VariantRecordData#getSemantics <em>Semantics</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Semantics</em>' attribute.
	 * @see #getSemantics()
	 * @generated
	 */
	void setSemantics(Object value);

	/**
	 * Returns the value of the '<em><b>Semantics Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Semantics Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Semantics Notes</em>' attribute.
	 * @see #setSemanticsNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getVariantRecordData_SemanticsNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='semanticsNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSemanticsNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.VariantRecordData#getSemanticsNotes <em>Semantics Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Semantics Notes</em>' attribute.
	 * @see #getSemanticsNotes()
	 * @generated
	 */
	void setSemanticsNotes(List value);

} // VariantRecordData
