/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.hla.crc.application;

import java.io.File;

import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.remote.launcher.server.application.RootAppStartedCallbackAppModule;
import org.eodisp.util.RootApp;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class CrcApplication extends RootApp {
	private static final int DEFAULT_TCP_PORT = 14321;

	public static final String APP_NAME = "EODiSP CRC";
	
	public static final String APP_DESCRIPTION = "EODiSP Central RTI Component";

	/**
	 * The complete path of the default working directory of the central rti
	 * component (crc), this is: <code>{user.home}/.eodisp/crc</code>
	 */
	public static final File DEFAULT_WORKING_DIR = new File(new File(System.getProperty("user.home"), ".eodisp"), "crc");

	/**
	 * The main class of the central RTI component
	 */
	public static final Class MAIN_CLASS = CrcMain.class;

	private CrcAppModule crcAppModule;

	private RemoteAppModule remoteAppModule;

	public CrcApplication() {
		super(APP_NAME, APP_DESCRIPTION, DEFAULT_WORKING_DIR, MAIN_CLASS);

		remoteAppModule = new RemoteAppModule(DEFAULT_TCP_PORT);
		registerAppModule(remoteAppModule);

		crcAppModule = new CrcAppModule();
		registerAppModule(crcAppModule);

		registerAppModule(new RootAppStartedCallbackAppModule());
	}

	/**
	 * Returns the Central RTI Component application module
	 * 
	 * @return the CRC application module
	 */
	public CrcAppModule getCrcAppModule() {
		return crcAppModule;
	}

	/**
	 * Returns the remote application module
	 * 
	 * @return the remote application module
	 */
	public RemoteAppModule getRemoteAppModule() {
		return remoteAppModule;
	}
}
