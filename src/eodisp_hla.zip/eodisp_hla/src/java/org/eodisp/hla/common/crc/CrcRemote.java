/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.hla.common.crc;

import hla.rti1516.*;

import java.rmi.Remote;
import java.rmi.RemoteException;

import org.eodisp.hla.common.lrc.LrcHandle;
import org.eodisp.hla.common.lrc.LrcRemote;
import org.eodisp.hla.crc.application.CrcApplication;

/**
 * Remote interface of the central RTI component.
 * 
 * @author ibirrer
 * @version $Id:$
 */
public interface CrcRemote extends Remote {
	public static final String REGISTRY_NAME = "crcRemote";

	/**
	 * Implements HLA service 4.2 (See IEEE Std 1516.1-2000).
	 * 
	 * Creates a new federation execution.
	 * 
	 * @param federationExecutionName
	 *            the name of the federation execution
	 * @param fdd
	 *            the federation object model (FOM) as an XML file encoded in
	 *            <code>UTF-8</code>
	 * @throws FederationExecutionAlreadyExists
	 *             if a federation execution with the same name has been created
	 *             before
	 * @throws ErrorReadingFDD
	 *             if fdd could not be read. This is the case if the given fdd
	 *             is not a valid XML file or does not conform to the HLA XMl
	 *             Schema.
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 * @return the newly created federation execution
	 * @prio 1
	 */
	public FederationExecutionRemote createFederationExecution(String federationExecutionName, byte[] fdd)
			throws RemoteException, FederationExecutionAlreadyExists, ErrorReadingFDD;

	/**
	 * Implements HLA service 4.3 (See IEEE Std 1516.1-2000).
	 * 
	 * Destroys this federation execution.
	 * 
	 * @throws FederatesCurrentlyJoined
	 *             if there are still federates joined to this federation
	 *             execution
	 * @throws FederationExecutionDoesNotExist
	 *             if no federation execution exists with the given name
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 */
	void destroyFederationExecution(String federationExecutionName) throws FederatesCurrentlyJoined,
			FederationExecutionDoesNotExist, RemoteException;

	/**
	 * Returns the federation execution with the given name.
	 * 
	 * @param federationExecutionName
	 *            the name of the federation execution to be received
	 * @return the federation execution with the given name or null if no
	 *         federation execution exists with the given name.
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 * 
	 * @prio 1
	 */
	FederationExecutionRemote getFederationExecution(String federationExecutionName) throws RemoteException;

	/**
	 * Implements HLA service 4.4 (See IEEE Std 1516.1-2000).
	 * 
	 * @param federateType
	 *            the type of the federate that want to join this federation
	 *            execution
	 * @param lrcHandle
	 *            a reference to the LRC which runs the federated that wants tho
	 *            join
	 * 
	 * @param serviceReferences
	 *            unused
	 * @return a federation execution wide unique handle for the joined
	 *         federate.
	 * 
	 * @throws SaveInProgress
	 *             not implemented
	 * @throws RestoreInProgress
	 *             not implemented
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 * @throws FederationExecutionDoesNotExist 
	 */
	FederateHandle joinFederationExecution(String federationExecutionName, String federateType, LrcHandle lrcHandle,
			MobileFederateServices serviceReferences) throws FederationExecutionDoesNotExist, RemoteException;

	/**
	 * TODO
	 * 
	 * @param lrcRemote
	 * @return
	 */
	LrcHandle registerLrc(LrcRemote lrcRemote) throws RemoteException;

	void unregisterLrc(LrcHandle lrcHandle) throws RemoteException;

	/**
	 * Resets the CRC. This means that after this method returned the CRC is in
	 * a state as if no federate ever called any method on the CRC. Used for
	 * testing purposes only.
	 * 
	 * @throws RemoteException
	 */
	public void reset() throws RemoteException;

	/**
	 * Calls shutdown on the {@link CrcApplication} and then exits the JVM. Does
	 * not block
	 * 
	 * @throws RemoteException
	 */
	public void shutdownAndExit() throws RemoteException;
}
