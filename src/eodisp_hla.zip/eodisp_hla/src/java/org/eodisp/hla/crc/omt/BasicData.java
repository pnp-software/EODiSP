/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt;

import java.util.List;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Basic Data</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.BasicData#getEncoding <em>Encoding</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.BasicData#getEncodingNotes <em>Encoding Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.BasicData#getEndian <em>Endian</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.BasicData#getEndianNotes <em>Endian Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.BasicData#getInterpretation <em>Interpretation</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.BasicData#getInterpretationNotes <em>Interpretation Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.BasicData#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.BasicData#getNameNotes <em>Name Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.BasicData#getSize <em>Size</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.BasicData#getSizeNotes <em>Size Notes</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eodisp.hla.crc.omt.OmtPackage#getBasicData()
 * @model extendedMetaData="name='BasicData' kind='empty'"
 * @generated
 */
public interface BasicData extends EObject {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * Returns the value of the '<em><b>Encoding</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Encoding</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Encoding</em>' attribute.
	 * @see #setEncoding(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getBasicData_Encoding()
	 * @model unique="false"
	 *        dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='encoding'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	Object getEncoding();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.BasicData#getEncoding <em>Encoding</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Encoding</em>' attribute.
	 * @see #getEncoding()
	 * @generated
	 */
	void setEncoding(Object value);

	/**
	 * Returns the value of the '<em><b>Encoding Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Encoding Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Encoding Notes</em>' attribute.
	 * @see #setEncodingNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getBasicData_EncodingNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='encodingNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getEncodingNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.BasicData#getEncodingNotes <em>Encoding Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Encoding Notes</em>' attribute.
	 * @see #getEncodingNotes()
	 * @generated
	 */
	void setEncodingNotes(List value);

	/**
	 * Returns the value of the '<em><b>Endian</b></em>' attribute. The
	 * default value is <code>"Big"</code>. The literals are from the
	 * enumeration {@link org.eodisp.hla.crc.omt.EndianEnum}. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Endian</em>' attribute isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Endian</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.EndianEnum
	 * @see #isSetEndian()
	 * @see #unsetEndian()
	 * @see #setEndian(EndianEnum)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getBasicData_Endian()
	 * @model default="Big" unique="false" unsettable="true"
	 *        extendedMetaData="kind='attribute' name='endian'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	EndianEnum getEndian();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.BasicData#getEndian <em>Endian</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Endian</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.EndianEnum
	 * @see #isSetEndian()
	 * @see #unsetEndian()
	 * @see #getEndian()
	 * @generated
	 */
	void setEndian(EndianEnum value);

	/**
	 * Unsets the value of the '{@link org.eodisp.hla.crc.omt.BasicData#getEndian <em>Endian</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #isSetEndian()
	 * @see #getEndian()
	 * @see #setEndian(EndianEnum)
	 * @generated
	 */
	void unsetEndian();

	/**
	 * Returns whether the value of the '{@link org.eodisp.hla.crc.omt.BasicData#getEndian <em>Endian</em>}' attribute is set.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return whether the value of the '<em>Endian</em>' attribute is set.
	 * @see #unsetEndian()
	 * @see #getEndian()
	 * @see #setEndian(EndianEnum)
	 * @generated
	 */
	boolean isSetEndian();

	/**
	 * Returns the value of the '<em><b>Endian Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Endian Notes</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Endian Notes</em>' attribute.
	 * @see #setEndianNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getBasicData_EndianNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='endianNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getEndianNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.BasicData#getEndianNotes <em>Endian Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Endian Notes</em>' attribute.
	 * @see #getEndianNotes()
	 * @generated
	 */
	void setEndianNotes(List value);

	/**
	 * Returns the value of the '<em><b>Interpretation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Interpretation</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Interpretation</em>' attribute.
	 * @see #setInterpretation(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getBasicData_Interpretation()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='interpretation' namespace='##targetNamespace'"
	 * @generated
	 */
	Object getInterpretation();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.BasicData#getInterpretation <em>Interpretation</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Interpretation</em>' attribute.
	 * @see #getInterpretation()
	 * @generated
	 */
	void setInterpretation(Object value);

	/**
	 * Returns the value of the '<em><b>Interpretation Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Interpretation Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Interpretation Notes</em>' attribute.
	 * @see #setInterpretationNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getBasicData_InterpretationNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='interpretationNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getInterpretationNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.BasicData#getInterpretationNotes <em>Interpretation Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Interpretation Notes</em>' attribute.
	 * @see #getInterpretationNotes()
	 * @generated
	 */
	void setInterpretationNotes(List value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getBasicData_Name()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKEN"
	 *        required="true" extendedMetaData="kind='attribute' name='name'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.BasicData#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Name Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name Notes</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name Notes</em>' attribute.
	 * @see #setNameNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getBasicData_NameNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='nameNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getNameNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.BasicData#getNameNotes <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name Notes</em>' attribute.
	 * @see #getNameNotes()
	 * @generated
	 */
	void setNameNotes(List value);

	/**
	 * Returns the value of the '<em><b>Size</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Size</em>' attribute isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Size</em>' attribute.
	 * @see #setSize(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getBasicData_Size()
	 * @model unique="false"
	 *        dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='size'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	Object getSize();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.BasicData#getSize <em>Size</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Size</em>' attribute.
	 * @see #getSize()
	 * @generated
	 */
	void setSize(Object value);

	/**
	 * Returns the value of the '<em><b>Size Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Size Notes</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Size Notes</em>' attribute.
	 * @see #setSizeNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getBasicData_SizeNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='sizeNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSizeNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.BasicData#getSizeNotes <em>Size Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Size Notes</em>' attribute.
	 * @see #getSizeNotes()
	 * @generated
	 */
	void setSizeNotes(List value);

} // BasicData
