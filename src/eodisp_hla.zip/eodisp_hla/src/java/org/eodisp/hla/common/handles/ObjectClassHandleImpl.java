/**
 * 
 */
package org.eodisp.hla.common.handles;

import hla.rti1516.ObjectClassHandle;

/**
 * A federation execution wide object class handle.
 * @author ibirrer
 * @version $Id:$
 *
 */
public class ObjectClassHandleImpl extends HandleImpl implements ObjectClassHandle {
	private static final long serialVersionUID = 1L;
	
	/**
	 * {@inheritDoc}
	 */
	public ObjectClassHandleImpl(int id) {
		super(id);
	}
}
