/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt.impl;

import java.util.List;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eodisp.hla.crc.omt.OmtPackage;
import org.eodisp.hla.crc.omt.SimpleData;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Simple Data</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SimpleDataImpl#getAccuracy <em>Accuracy</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SimpleDataImpl#getAccuracyNotes <em>Accuracy Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SimpleDataImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SimpleDataImpl#getNameNotes <em>Name Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SimpleDataImpl#getRepresentation <em>Representation</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SimpleDataImpl#getRepresentationNotes <em>Representation Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SimpleDataImpl#getResolution <em>Resolution</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SimpleDataImpl#getResolutionNotes <em>Resolution Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SimpleDataImpl#getSemantics <em>Semantics</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SimpleDataImpl#getSemanticsNotes <em>Semantics Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SimpleDataImpl#getUnits <em>Units</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SimpleDataImpl#getUnitsNotes <em>Units Notes</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class SimpleDataImpl extends EObjectImpl implements SimpleData {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The default value of the '{@link #getAccuracy() <em>Accuracy</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getAccuracy()
	 * @generated
	 * @ordered
	 */
	protected static final Object ACCURACY_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getAccuracy() <em>Accuracy</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getAccuracy()
	 * @generated
	 * @ordered
	 */
	protected Object accuracy = ACCURACY_EDEFAULT;

	/**
	 * The default value of the '{@link #getAccuracyNotes() <em>Accuracy Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getAccuracyNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List ACCURACY_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getAccuracyNotes() <em>Accuracy Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getAccuracyNotes()
	 * @generated
	 * @ordered
	 */
	protected List accuracyNotes = ACCURACY_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getNameNotes() <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getNameNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List NAME_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNameNotes() <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getNameNotes()
	 * @generated
	 * @ordered
	 */
	protected List nameNotes = NAME_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getRepresentation() <em>Representation</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getRepresentation()
	 * @generated
	 * @ordered
	 */
	protected static final String REPRESENTATION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getRepresentation() <em>Representation</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getRepresentation()
	 * @generated
	 * @ordered
	 */
	protected String representation = REPRESENTATION_EDEFAULT;

	/**
	 * The default value of the '{@link #getRepresentationNotes() <em>Representation Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getRepresentationNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List REPRESENTATION_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getRepresentationNotes() <em>Representation Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getRepresentationNotes()
	 * @generated
	 * @ordered
	 */
	protected List representationNotes = REPRESENTATION_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getResolution() <em>Resolution</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getResolution()
	 * @generated
	 * @ordered
	 */
	protected static final Object RESOLUTION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getResolution() <em>Resolution</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getResolution()
	 * @generated
	 * @ordered
	 */
	protected Object resolution = RESOLUTION_EDEFAULT;

	/**
	 * The default value of the '{@link #getResolutionNotes() <em>Resolution Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getResolutionNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List RESOLUTION_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getResolutionNotes() <em>Resolution Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getResolutionNotes()
	 * @generated
	 * @ordered
	 */
	protected List resolutionNotes = RESOLUTION_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getSemantics() <em>Semantics</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSemantics()
	 * @generated
	 * @ordered
	 */
	protected static final Object SEMANTICS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSemantics() <em>Semantics</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSemantics()
	 * @generated
	 * @ordered
	 */
	protected Object semantics = SEMANTICS_EDEFAULT;

	/**
	 * The default value of the '{@link #getSemanticsNotes() <em>Semantics Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSemanticsNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List SEMANTICS_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSemanticsNotes() <em>Semantics Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSemanticsNotes()
	 * @generated
	 * @ordered
	 */
	protected List semanticsNotes = SEMANTICS_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getUnits() <em>Units</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getUnits()
	 * @generated
	 * @ordered
	 */
	protected static final Object UNITS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getUnits() <em>Units</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getUnits()
	 * @generated
	 * @ordered
	 */
	protected Object units = UNITS_EDEFAULT;

	/**
	 * The default value of the '{@link #getUnitsNotes() <em>Units Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getUnitsNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List UNITS_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getUnitsNotes() <em>Units Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getUnitsNotes()
	 * @generated
	 * @ordered
	 */
	protected List unitsNotes = UNITS_NOTES_EDEFAULT;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected SimpleDataImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return OmtPackage.Literals.SIMPLE_DATA;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getAccuracy() {
		return accuracy;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setAccuracy(Object newAccuracy) {
		Object oldAccuracy = accuracy;
		accuracy = newAccuracy;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SIMPLE_DATA__ACCURACY,
					oldAccuracy,
					accuracy));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getAccuracyNotes() {
		return accuracyNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setAccuracyNotes(List newAccuracyNotes) {
		List oldAccuracyNotes = accuracyNotes;
		accuracyNotes = newAccuracyNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SIMPLE_DATA__ACCURACY_NOTES,
					oldAccuracyNotes,
					accuracyNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OmtPackage.SIMPLE_DATA__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getNameNotes() {
		return nameNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setNameNotes(List newNameNotes) {
		List oldNameNotes = nameNotes;
		nameNotes = newNameNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SIMPLE_DATA__NAME_NOTES,
					oldNameNotes,
					nameNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String getRepresentation() {
		return representation;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setRepresentation(String newRepresentation) {
		String oldRepresentation = representation;
		representation = newRepresentation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SIMPLE_DATA__REPRESENTATION,
					oldRepresentation,
					representation));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getRepresentationNotes() {
		return representationNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setRepresentationNotes(List newRepresentationNotes) {
		List oldRepresentationNotes = representationNotes;
		representationNotes = newRepresentationNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SIMPLE_DATA__REPRESENTATION_NOTES,
					oldRepresentationNotes,
					representationNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getResolution() {
		return resolution;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setResolution(Object newResolution) {
		Object oldResolution = resolution;
		resolution = newResolution;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SIMPLE_DATA__RESOLUTION,
					oldResolution,
					resolution));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getResolutionNotes() {
		return resolutionNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setResolutionNotes(List newResolutionNotes) {
		List oldResolutionNotes = resolutionNotes;
		resolutionNotes = newResolutionNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SIMPLE_DATA__RESOLUTION_NOTES,
					oldResolutionNotes,
					resolutionNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getSemantics() {
		return semantics;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setSemantics(Object newSemantics) {
		Object oldSemantics = semantics;
		semantics = newSemantics;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SIMPLE_DATA__SEMANTICS,
					oldSemantics,
					semantics));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getSemanticsNotes() {
		return semanticsNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setSemanticsNotes(List newSemanticsNotes) {
		List oldSemanticsNotes = semanticsNotes;
		semanticsNotes = newSemanticsNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SIMPLE_DATA__SEMANTICS_NOTES,
					oldSemanticsNotes,
					semanticsNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getUnits() {
		return units;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setUnits(Object newUnits) {
		Object oldUnits = units;
		units = newUnits;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OmtPackage.SIMPLE_DATA__UNITS, oldUnits, units));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getUnitsNotes() {
		return unitsNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setUnitsNotes(List newUnitsNotes) {
		List oldUnitsNotes = unitsNotes;
		unitsNotes = newUnitsNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SIMPLE_DATA__UNITS_NOTES,
					oldUnitsNotes,
					unitsNotes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case OmtPackage.SIMPLE_DATA__ACCURACY:
			return getAccuracy();
		case OmtPackage.SIMPLE_DATA__ACCURACY_NOTES:
			return getAccuracyNotes();
		case OmtPackage.SIMPLE_DATA__NAME:
			return getName();
		case OmtPackage.SIMPLE_DATA__NAME_NOTES:
			return getNameNotes();
		case OmtPackage.SIMPLE_DATA__REPRESENTATION:
			return getRepresentation();
		case OmtPackage.SIMPLE_DATA__REPRESENTATION_NOTES:
			return getRepresentationNotes();
		case OmtPackage.SIMPLE_DATA__RESOLUTION:
			return getResolution();
		case OmtPackage.SIMPLE_DATA__RESOLUTION_NOTES:
			return getResolutionNotes();
		case OmtPackage.SIMPLE_DATA__SEMANTICS:
			return getSemantics();
		case OmtPackage.SIMPLE_DATA__SEMANTICS_NOTES:
			return getSemanticsNotes();
		case OmtPackage.SIMPLE_DATA__UNITS:
			return getUnits();
		case OmtPackage.SIMPLE_DATA__UNITS_NOTES:
			return getUnitsNotes();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case OmtPackage.SIMPLE_DATA__ACCURACY:
			setAccuracy((Object) newValue);
			return;
		case OmtPackage.SIMPLE_DATA__ACCURACY_NOTES:
			setAccuracyNotes((List) newValue);
			return;
		case OmtPackage.SIMPLE_DATA__NAME:
			setName((String) newValue);
			return;
		case OmtPackage.SIMPLE_DATA__NAME_NOTES:
			setNameNotes((List) newValue);
			return;
		case OmtPackage.SIMPLE_DATA__REPRESENTATION:
			setRepresentation((String) newValue);
			return;
		case OmtPackage.SIMPLE_DATA__REPRESENTATION_NOTES:
			setRepresentationNotes((List) newValue);
			return;
		case OmtPackage.SIMPLE_DATA__RESOLUTION:
			setResolution((Object) newValue);
			return;
		case OmtPackage.SIMPLE_DATA__RESOLUTION_NOTES:
			setResolutionNotes((List) newValue);
			return;
		case OmtPackage.SIMPLE_DATA__SEMANTICS:
			setSemantics((Object) newValue);
			return;
		case OmtPackage.SIMPLE_DATA__SEMANTICS_NOTES:
			setSemanticsNotes((List) newValue);
			return;
		case OmtPackage.SIMPLE_DATA__UNITS:
			setUnits((Object) newValue);
			return;
		case OmtPackage.SIMPLE_DATA__UNITS_NOTES:
			setUnitsNotes((List) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
		case OmtPackage.SIMPLE_DATA__ACCURACY:
			setAccuracy(ACCURACY_EDEFAULT);
			return;
		case OmtPackage.SIMPLE_DATA__ACCURACY_NOTES:
			setAccuracyNotes(ACCURACY_NOTES_EDEFAULT);
			return;
		case OmtPackage.SIMPLE_DATA__NAME:
			setName(NAME_EDEFAULT);
			return;
		case OmtPackage.SIMPLE_DATA__NAME_NOTES:
			setNameNotes(NAME_NOTES_EDEFAULT);
			return;
		case OmtPackage.SIMPLE_DATA__REPRESENTATION:
			setRepresentation(REPRESENTATION_EDEFAULT);
			return;
		case OmtPackage.SIMPLE_DATA__REPRESENTATION_NOTES:
			setRepresentationNotes(REPRESENTATION_NOTES_EDEFAULT);
			return;
		case OmtPackage.SIMPLE_DATA__RESOLUTION:
			setResolution(RESOLUTION_EDEFAULT);
			return;
		case OmtPackage.SIMPLE_DATA__RESOLUTION_NOTES:
			setResolutionNotes(RESOLUTION_NOTES_EDEFAULT);
			return;
		case OmtPackage.SIMPLE_DATA__SEMANTICS:
			setSemantics(SEMANTICS_EDEFAULT);
			return;
		case OmtPackage.SIMPLE_DATA__SEMANTICS_NOTES:
			setSemanticsNotes(SEMANTICS_NOTES_EDEFAULT);
			return;
		case OmtPackage.SIMPLE_DATA__UNITS:
			setUnits(UNITS_EDEFAULT);
			return;
		case OmtPackage.SIMPLE_DATA__UNITS_NOTES:
			setUnitsNotes(UNITS_NOTES_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case OmtPackage.SIMPLE_DATA__ACCURACY:
			return ACCURACY_EDEFAULT == null ? accuracy != null : !ACCURACY_EDEFAULT.equals(accuracy);
		case OmtPackage.SIMPLE_DATA__ACCURACY_NOTES:
			return ACCURACY_NOTES_EDEFAULT == null ? accuracyNotes != null : !ACCURACY_NOTES_EDEFAULT
					.equals(accuracyNotes);
		case OmtPackage.SIMPLE_DATA__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case OmtPackage.SIMPLE_DATA__NAME_NOTES:
			return NAME_NOTES_EDEFAULT == null ? nameNotes != null : !NAME_NOTES_EDEFAULT.equals(nameNotes);
		case OmtPackage.SIMPLE_DATA__REPRESENTATION:
			return REPRESENTATION_EDEFAULT == null ? representation != null : !REPRESENTATION_EDEFAULT
					.equals(representation);
		case OmtPackage.SIMPLE_DATA__REPRESENTATION_NOTES:
			return REPRESENTATION_NOTES_EDEFAULT == null ? representationNotes != null : !REPRESENTATION_NOTES_EDEFAULT
					.equals(representationNotes);
		case OmtPackage.SIMPLE_DATA__RESOLUTION:
			return RESOLUTION_EDEFAULT == null ? resolution != null : !RESOLUTION_EDEFAULT.equals(resolution);
		case OmtPackage.SIMPLE_DATA__RESOLUTION_NOTES:
			return RESOLUTION_NOTES_EDEFAULT == null ? resolutionNotes != null : !RESOLUTION_NOTES_EDEFAULT
					.equals(resolutionNotes);
		case OmtPackage.SIMPLE_DATA__SEMANTICS:
			return SEMANTICS_EDEFAULT == null ? semantics != null : !SEMANTICS_EDEFAULT.equals(semantics);
		case OmtPackage.SIMPLE_DATA__SEMANTICS_NOTES:
			return SEMANTICS_NOTES_EDEFAULT == null ? semanticsNotes != null : !SEMANTICS_NOTES_EDEFAULT
					.equals(semanticsNotes);
		case OmtPackage.SIMPLE_DATA__UNITS:
			return UNITS_EDEFAULT == null ? units != null : !UNITS_EDEFAULT.equals(units);
		case OmtPackage.SIMPLE_DATA__UNITS_NOTES:
			return UNITS_NOTES_EDEFAULT == null ? unitsNotes != null : !UNITS_NOTES_EDEFAULT.equals(unitsNotes);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (accuracy: ");
		result.append(accuracy);
		result.append(", accuracyNotes: ");
		result.append(accuracyNotes);
		result.append(", name: ");
		result.append(name);
		result.append(", nameNotes: ");
		result.append(nameNotes);
		result.append(", representation: ");
		result.append(representation);
		result.append(", representationNotes: ");
		result.append(representationNotes);
		result.append(", resolution: ");
		result.append(resolution);
		result.append(", resolutionNotes: ");
		result.append(resolutionNotes);
		result.append(", semantics: ");
		result.append(semantics);
		result.append(", semanticsNotes: ");
		result.append(semanticsNotes);
		result.append(", units: ");
		result.append(units);
		result.append(", unitsNotes: ");
		result.append(unitsNotes);
		result.append(')');
		return result.toString();
	}

} // SimpleDataImpl
