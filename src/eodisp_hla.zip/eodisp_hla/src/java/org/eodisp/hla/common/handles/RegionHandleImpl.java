/**
 * 
 */
package org.eodisp.hla.common.handles;


import hla.rti1516.CouldNotDecode;
import hla.rti1516.RegionHandle;

/**
 * @author ibirrer
 */
public class RegionHandleImpl extends UUIDHandle implements RegionHandle {

	public RegionHandleImpl() {
		super();
	}

	public RegionHandleImpl(String s) {
		super(s);
	}

	public RegionHandleImpl(byte[] buffer, int offset) throws CouldNotDecode {
		super(buffer, offset);
	}
}
