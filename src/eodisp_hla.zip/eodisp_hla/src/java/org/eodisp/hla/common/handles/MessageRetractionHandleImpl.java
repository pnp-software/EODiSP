/**
 * 
 */
package org.eodisp.hla.common.handles;


import hla.rti1516.CouldNotDecode;
import hla.rti1516.MessageRetractionHandle;

/**
 * @author ibirrer
 */
public class MessageRetractionHandleImpl extends UUIDHandle implements
		MessageRetractionHandle {

	public MessageRetractionHandleImpl() {
		super();
	}

	public MessageRetractionHandleImpl(String s) {
		super(s);
	}

	public MessageRetractionHandleImpl(byte[] buffer, int offset)
			throws CouldNotDecode {
		super(buffer, offset);
	}
}
