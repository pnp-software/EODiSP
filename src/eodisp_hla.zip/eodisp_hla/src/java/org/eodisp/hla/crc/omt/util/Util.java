/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.hla.crc.omt.util;

import java.io.*;
import java.util.*;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eodisp.hla.crc.omt.*;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class Util {
	public void printAllObjectClasses(ObjectClass parent) {
		for (Object obj : parent.getSubClasses()) {
			ObjectClass objectClass = (ObjectClass) obj;
			printAllObjectClasses(objectClass);
			System.out.print(objectClass.getName());
			ObjectClass superClass = (ObjectClass) objectClass.eContainer();
			System.out.println("->" + superClass.getName());
		}
	}

	public static String toString(ObjectModel objectModel) {
		final StringWriter stringWriter = new StringWriter();
		PrintWriter out = new PrintWriter(stringWriter);
		final Objects objects = objectModel.getObjects();
		if (objects != null) {
			List<ObjectClass> rootObjectClasses = objects.getObjectClass();

			for (ObjectClass oc : rootObjectClasses) {
				out.println(oc.getName());
				Util.printSubclasses(0, oc, out, new BitSet());
			}
		}

		out.println();

		final Interactions interactions = objectModel.getInteractions();
		if (interactions != null) {
			List<InteractionClass> rootInterationClasses = interactions.getInteractionClass();
			for (InteractionClass oc : rootInterationClasses) {
				out.println(oc.getName());
				Util.printSubclasses(0, oc, out, new BitSet());
			}
		}
		return stringWriter.toString();
	}

	private static void printSubclasses(int level, ObjectClass topClass, PrintWriter out, BitSet activeLevels) {
		int subclassPos = 0;
		List subClasses = topClass.getSubClasses();
		for (Object object : subClasses) {
			ObjectClass subClass = (ObjectClass) object;
			subclassPos++;
			activeLevels.set(level, true);

			String lines = getLines(level + 1, activeLevels, 3);
			out.println(lines);
			
			out.printf("%s---- %s %s%n", lines, subClass.getName(), subClass.getAttributes());
			if (hasSiblings(subClass)) {
				activeLevels.set(level);
			}

			if (subclassPos == subClasses.size()) {
				activeLevels.set(level, false);
			}
			printSubclasses(level + 1, subClass, out, activeLevels);
		}
	}

	private static void printSubclasses(int level, InteractionClass topClass, PrintWriter out, BitSet activeLevels) {
		int subclassPos = 0;
		List subClasses = topClass.getSubClasses();
		for (Object object : subClasses) {
			InteractionClass subClass = (InteractionClass) object;
			subclassPos++;
			activeLevels.set(level, true);

			String lines = getLines(level + 1, activeLevels, 3);
			out.println(lines);
			out.printf("%s---- %s %s%n", lines, subClass.getName(), subClass.getParameters());
			if (hasSiblings(subClass)) {
				activeLevels.set(level);
			}

			if (subclassPos == subClasses.size()) {
				activeLevels.set(level, false);
			}
			printSubclasses(level + 1, subClass, out, activeLevels);
		}
	}

	private static String getLines(int levels, BitSet activeLevels, int indent) {
		char[] indentChars = new char[indent];
		Arrays.fill(indentChars, ' ');
		String indentString = new String(indentChars);

		StringBuilder indentBuilder = new StringBuilder();
		for (int i = 0; i < levels; i++) {
			if (activeLevels.get(i)) {
				indentBuilder.append(indentString + "|");
			} else {
				indentBuilder.append(indentString + " ");
			}
		}
		return indentBuilder.toString();
	}

	private static boolean hasSiblings(ObjectClass objectClass) {
		ObjectClass superClass = objectClass.getSuperClass();
		return !(superClass == null || superClass.getSubClasses().isEmpty());
	}

	private static boolean hasSiblings(InteractionClass interaction) {
		InteractionClass superClass = interaction.getSuperClass();
		return !(superClass == null || superClass.getSubClasses().isEmpty());
	}

	public static void print(OutputStream out, DocumentRoot documentRoot) throws IOException {
		Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put("fdd", new OmtResourceFactoryImpl());
		URI fileURI = URI.createFileURI("test.fdd");
		ResourceSet resourceSet = new ResourceSetImpl();
		Resource resource = resourceSet.createResource(fileURI);
		resource.getContents().add(documentRoot);
		Map options = new HashMap();
		options.put(XMLResource.OPTION_ENCODING, "UTF-8");
		resource.save(out, options);
	}
}
