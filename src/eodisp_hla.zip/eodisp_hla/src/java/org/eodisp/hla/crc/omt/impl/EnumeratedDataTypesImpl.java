/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.eodisp.hla.crc.omt.EnumeratedData;
import org.eodisp.hla.crc.omt.EnumeratedDataTypes;
import org.eodisp.hla.crc.omt.OmtPackage;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Enumerated Data Types</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.EnumeratedDataTypesImpl#getEnumeratedData <em>Enumerated Data</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class EnumeratedDataTypesImpl extends EObjectImpl implements EnumeratedDataTypes {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The cached value of the '{@link #getEnumeratedData() <em>Enumerated Data</em>}' containment reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getEnumeratedData()
	 * @generated
	 * @ordered
	 */
	protected EList enumeratedData = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected EnumeratedDataTypesImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return OmtPackage.Literals.ENUMERATED_DATA_TYPES;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EList getEnumeratedData() {
		if (enumeratedData == null) {
			enumeratedData = new EObjectContainmentEList(
					EnumeratedData.class,
					this,
					OmtPackage.ENUMERATED_DATA_TYPES__ENUMERATED_DATA);
		}
		return enumeratedData;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case OmtPackage.ENUMERATED_DATA_TYPES__ENUMERATED_DATA:
			return ((InternalEList) getEnumeratedData()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case OmtPackage.ENUMERATED_DATA_TYPES__ENUMERATED_DATA:
			return getEnumeratedData();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case OmtPackage.ENUMERATED_DATA_TYPES__ENUMERATED_DATA:
			getEnumeratedData().clear();
			getEnumeratedData().addAll((Collection) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
		case OmtPackage.ENUMERATED_DATA_TYPES__ENUMERATED_DATA:
			getEnumeratedData().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case OmtPackage.ENUMERATED_DATA_TYPES__ENUMERATED_DATA:
			return enumeratedData != null && !enumeratedData.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} // EnumeratedDataTypesImpl
