/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc --> The <b>Factory</b> for the model. It provides a
 * create method for each non-abstract class of the model. <!-- end-user-doc -->
 * @see org.eodisp.hla.crc.omt.OmtPackage
 * @generated
 */
public interface OmtFactory extends EFactory {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * @generated
	 */
	OmtFactory eINSTANCE = org.eodisp.hla.crc.omt.impl.OmtFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Acquisition Request Tag</em>'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return a new object of class '<em>Acquisition Request Tag</em>'.
	 * @generated
	 */
	AcquisitionRequestTag createAcquisitionRequestTag();

	/**
	 * Returns a new object of class '<em>Alternative</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Alternative</em>'.
	 * @generated
	 */
	Alternative createAlternative();

	/**
	 * Returns a new object of class '<em>Array Data</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Array Data</em>'.
	 * @generated
	 */
	ArrayData createArrayData();

	/**
	 * Returns a new object of class '<em>Array Data Types</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Array Data Types</em>'.
	 * @generated
	 */
	ArrayDataTypes createArrayDataTypes();

	/**
	 * Returns a new object of class '<em>Attribute</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Attribute</em>'.
	 * @generated
	 */
	Attribute createAttribute();

	/**
	 * Returns a new object of class '<em>Basic Data</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Basic Data</em>'.
	 * @generated
	 */
	BasicData createBasicData();

	/**
	 * Returns a new object of class '<em>Basic Data Representations</em>'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return a new object of class '<em>Basic Data Representations</em>'.
	 * @generated
	 */
	BasicDataRepresentations createBasicDataRepresentations();

	/**
	 * Returns a new object of class '<em>Data Types</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Data Types</em>'.
	 * @generated
	 */
	DataTypes createDataTypes();

	/**
	 * Returns a new object of class '<em>Delete Remove Tag</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Delete Remove Tag</em>'.
	 * @generated
	 */
	DeleteRemoveTag createDeleteRemoveTag();

	/**
	 * Returns a new object of class '<em>Dimension</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Dimension</em>'.
	 * @generated
	 */
	Dimension createDimension();

	/**
	 * Returns a new object of class '<em>Dimensions</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Dimensions</em>'.
	 * @generated
	 */
	Dimensions createDimensions();

	/**
	 * Returns a new object of class '<em>Divestiture Completion Tag</em>'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return a new object of class '<em>Divestiture Completion Tag</em>'.
	 * @generated
	 */
	DivestitureCompletionTag createDivestitureCompletionTag();

	/**
	 * Returns a new object of class '<em>Divestiture Request Tag</em>'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return a new object of class '<em>Divestiture Request Tag</em>'.
	 * @generated
	 */
	DivestitureRequestTag createDivestitureRequestTag();

	/**
	 * Returns a new object of class '<em>Document Root</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Document Root</em>'.
	 * @generated
	 */
	DocumentRoot createDocumentRoot();

	/**
	 * Returns a new object of class '<em>Enumerated Data</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Enumerated Data</em>'.
	 * @generated
	 */
	EnumeratedData createEnumeratedData();

	/**
	 * Returns a new object of class '<em>Enumerated Data Types</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Enumerated Data Types</em>'.
	 * @generated
	 */
	EnumeratedDataTypes createEnumeratedDataTypes();

	/**
	 * Returns a new object of class '<em>Enumerator</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Enumerator</em>'.
	 * @generated
	 */
	Enumerator createEnumerator();

	/**
	 * Returns a new object of class '<em>Field</em>'.
	 * <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * @return a new object of class '<em>Field</em>'.
	 * @generated
	 */
	Field createField();

	/**
	 * Returns a new object of class '<em>Fixed Record Data</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Fixed Record Data</em>'.
	 * @generated
	 */
	FixedRecordData createFixedRecordData();

	/**
	 * Returns a new object of class '<em>Fixed Record Data Types</em>'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return a new object of class '<em>Fixed Record Data Types</em>'.
	 * @generated
	 */
	FixedRecordDataTypes createFixedRecordDataTypes();

	/**
	 * Returns a new object of class '<em>Interaction Class</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Interaction Class</em>'.
	 * @generated
	 */
	InteractionClass createInteractionClass();

	/**
	 * Returns a new object of class '<em>Interactions</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Interactions</em>'.
	 * @generated
	 */
	Interactions createInteractions();

	/**
	 * Returns a new object of class '<em>Lookahead</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Lookahead</em>'.
	 * @generated
	 */
	Lookahead createLookahead();

	/**
	 * Returns a new object of class '<em>Note</em>'.
	 * <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * @return a new object of class '<em>Note</em>'.
	 * @generated
	 */
	Note createNote();

	/**
	 * Returns a new object of class '<em>Notes</em>'.
	 * <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * @return a new object of class '<em>Notes</em>'.
	 * @generated
	 */
	Notes createNotes();

	/**
	 * Returns a new object of class '<em>Object Class</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Object Class</em>'.
	 * @generated
	 */
	ObjectClass createObjectClass();

	/**
	 * Returns a new object of class '<em>Object Model</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Object Model</em>'.
	 * @generated
	 */
	ObjectModel createObjectModel();

	/**
	 * Returns a new object of class '<em>Objects</em>'.
	 * <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * @return a new object of class '<em>Objects</em>'.
	 * @generated
	 */
	Objects createObjects();

	/**
	 * Returns a new object of class '<em>Parameter</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Parameter</em>'.
	 * @generated
	 */
	Parameter createParameter();

	/**
	 * Returns a new object of class '<em>Request Update Tag</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Request Update Tag</em>'.
	 * @generated
	 */
	RequestUpdateTag createRequestUpdateTag();

	/**
	 * Returns a new object of class '<em>Send Receive Tag</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Send Receive Tag</em>'.
	 * @generated
	 */
	SendReceiveTag createSendReceiveTag();

	/**
	 * Returns a new object of class '<em>Simple Data</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Simple Data</em>'.
	 * @generated
	 */
	SimpleData createSimpleData();

	/**
	 * Returns a new object of class '<em>Simple Data Types</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Simple Data Types</em>'.
	 * @generated
	 */
	SimpleDataTypes createSimpleDataTypes();

	/**
	 * Returns a new object of class '<em>Switches</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Switches</em>'.
	 * @generated
	 */
	Switches createSwitches();

	/**
	 * Returns a new object of class '<em>Synchronization</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Synchronization</em>'.
	 * @generated
	 */
	Synchronization createSynchronization();

	/**
	 * Returns a new object of class '<em>Synchronizations</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Synchronizations</em>'.
	 * @generated
	 */
	Synchronizations createSynchronizations();

	/**
	 * Returns a new object of class '<em>Tags</em>'.
	 * <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * @return a new object of class '<em>Tags</em>'.
	 * @generated
	 */
	Tags createTags();

	/**
	 * Returns a new object of class '<em>Time</em>'.
	 * <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * @return a new object of class '<em>Time</em>'.
	 * @generated
	 */
	Time createTime();

	/**
	 * Returns a new object of class '<em>Time Stamp</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Time Stamp</em>'.
	 * @generated
	 */
	TimeStamp createTimeStamp();

	/**
	 * Returns a new object of class '<em>Transportation</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Transportation</em>'.
	 * @generated
	 */
	Transportation createTransportation();

	/**
	 * Returns a new object of class '<em>Transportations</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Transportations</em>'.
	 * @generated
	 */
	Transportations createTransportations();

	/**
	 * Returns a new object of class '<em>Update Reflect Tag</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Update Reflect Tag</em>'.
	 * @generated
	 */
	UpdateReflectTag createUpdateReflectTag();

	/**
	 * Returns a new object of class '<em>Variant Record Data</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Variant Record Data</em>'.
	 * @generated
	 */
	VariantRecordData createVariantRecordData();

	/**
	 * Returns a new object of class '<em>Variant Record Data Types</em>'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return a new object of class '<em>Variant Record Data Types</em>'.
	 * @generated
	 */
	VariantRecordDataTypes createVariantRecordDataTypes();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	OmtPackage getOmtPackage();

} // OmtFactory
