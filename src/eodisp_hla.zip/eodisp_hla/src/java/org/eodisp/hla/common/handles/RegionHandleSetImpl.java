package org.eodisp.hla.common.handles;

import hla.rti1516.RegionHandle;
import hla.rti1516.RegionHandleSet;

import java.util.Collection;
import java.util.HashSet;

public class RegionHandleSetImpl extends HashSet implements RegionHandleSet {
	protected RegionHandleSetImpl() {
		super();
	}

	public boolean add(Object o) {
		if (!(o instanceof RegionHandle)) {
			throw new IllegalArgumentException("object must be RegionHandle");
		}

		return super.add(o);
	}

	public boolean remove(Object o) {
		if (!(o instanceof RegionHandle)) {
			throw new IllegalArgumentException("object must be RegionHandle");
		}

		return super.remove(o);
	}

	public boolean addAll(Collection c) {
		if (!(c instanceof RegionHandleSet)) {
			throw new IllegalArgumentException(
					"collection must be RegionHandleSet");
		}

		return super.addAll(c);
	}

	public boolean removeAll(Collection c) {
		if (!(c instanceof RegionHandleSet)) {
			throw new IllegalArgumentException(
					"collection must be RegionHandleSet");
		}

		return super.removeAll(c);
	}

	public boolean retainAll(Collection c) {
		if (!(c instanceof RegionHandleSet)) {
			throw new IllegalArgumentException(
					"collection must be RegionHandleSet");
		}

		return super.retainAll(c);
	}
}
