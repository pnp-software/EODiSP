/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.hla.crc.application;

import java.io.File;

import org.eodisp.hla.common.crc.CrcRemote;
import org.eodisp.hla.crc.Crc;
import org.eodisp.hla.crc.CrcRemoteImpl;
import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.util.AppModule;
import org.eodisp.util.RootApp;
import org.eodisp.util.configuration.BasicSystemPropertyMapper;
import org.eodisp.util.configuration.CommandlineMapper;

/**
 * Application module for the central RTI component.
 * 
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class CrcAppModule implements AppModule {

	/**
	 * The Id of this Application Module.
	 */
	public static final String ID = CrcAppModule.class.getName();

	private CrcRemoteImpl crcRemoteImpl;

	private RemoteAppModule remoteAppModule;

	private Crc crc;

	/**
	 * 
	 */
	public CrcAppModule() {

	}

	/**
	 * {@inheritDoc}
	 */
	public String getId() {
		return ID;
	}

	/**
	 * {@inheritDoc}
	 */
	public void registerConfiguration(RootApp rootApp) throws Exception {
		CrcConfiguration crcConfiguration = new CrcConfiguration(new File(rootApp.getConfigurationDir(), "crc.conf"));
		rootApp.registerConfiguration(
				crcConfiguration,
				CommandlineMapper.NULL_COMMAND_LINE_MAPPER,
				new BasicSystemPropertyMapper("org.eodisp.hla.crc."));
	}

	/**
	 * {@inheritDoc}
	 */
	public void preStartup(RootApp rootApp) throws Exception {
		remoteAppModule = (RemoteAppModule) rootApp.getAppModule(RemoteAppModule.ID);
	}

	/**
	 * {@inheritDoc}
	 */
	public void startup(RootApp rootApp) throws Exception {
		crc = new Crc();
		crcRemoteImpl = new CrcRemoteImpl(crc);
		remoteAppModule.exportAndRegister(crcRemoteImpl, CrcRemote.REGISTRY_NAME);
	}

	/**
	 * {@inheritDoc}
	 */
	public void shutdown(RootApp rootApp) throws Exception {
		remoteAppModule.getRegistry().unbind(CrcRemote.REGISTRY_NAME);
	}

	/**
	 * {@inheritDoc}
	 */
	public void postShutdown(RootApp rootApp) throws Exception {
		// TODO Auto-generated method stub

	}

	/**
	 * Return the singleton instance of the CRC.
	 * 
	 * @return the singleton instance of the CRC.
	 */
	public Crc getCrc() {
		return crc;
	}

	/**
	 * Returns the remote proxy of the CRC.
	 * 
	 * @return the remote proxy of the CRC.
	 */
	public CrcRemote getCrcRemote() {
		return crcRemoteImpl;
	}
}
