package org.eodisp.hla.common.handles;

import hla.rti1516.ParameterHandleValueMap;
import hla.rti1516.ParameterHandleValueMapFactory;

public class ParameterHandleValueMapFactoryImpl implements
		ParameterHandleValueMapFactory {
	public ParameterHandleValueMap create(int capacity) {
		return new ParameterHandleValueMapImpl(capacity);
	}
}
