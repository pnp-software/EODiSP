/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Basic Data Representations</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.BasicDataRepresentations#getBasicData <em>Basic Data</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eodisp.hla.crc.omt.OmtPackage#getBasicDataRepresentations()
 * @model extendedMetaData="name='BasicDataRepresentations' kind='elementOnly'"
 * @generated
 */
public interface BasicDataRepresentations extends EObject {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * Returns the value of the '<em><b>Basic Data</b></em>' containment reference list.
	 * The list contents are of type {@link org.eodisp.hla.crc.omt.BasicData}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Basic Data</em>' containment reference
	 * list isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Basic Data</em>' containment reference list.
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getBasicDataRepresentations_BasicData()
	 * @model type="org.eodisp.hla.crc.omt.BasicData" containment="true" required="true"
	 *        extendedMetaData="kind='element' name='basicData' namespace='##targetNamespace'"
	 * @generated
	 */
	EList getBasicData();

} // BasicDataRepresentations
