/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eodisp.hla.crc.omt.ArrayDataTypes;
import org.eodisp.hla.crc.omt.BasicDataRepresentations;
import org.eodisp.hla.crc.omt.DataTypes;
import org.eodisp.hla.crc.omt.EnumeratedDataTypes;
import org.eodisp.hla.crc.omt.FixedRecordDataTypes;
import org.eodisp.hla.crc.omt.OmtPackage;
import org.eodisp.hla.crc.omt.SimpleDataTypes;
import org.eodisp.hla.crc.omt.VariantRecordDataTypes;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Data Types</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.DataTypesImpl#getBasicDataRepresentations <em>Basic Data Representations</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.DataTypesImpl#getSimpleDataTypes <em>Simple Data Types</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.DataTypesImpl#getEnumeratedDataTypes <em>Enumerated Data Types</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.DataTypesImpl#getArrayDataTypes <em>Array Data Types</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.DataTypesImpl#getFixedRecordDataTypes <em>Fixed Record Data Types</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.DataTypesImpl#getVariantRecordDataTypes <em>Variant Record Data Types</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class DataTypesImpl extends EObjectImpl implements DataTypes {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The cached value of the '{@link #getBasicDataRepresentations() <em>Basic Data Representations</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getBasicDataRepresentations()
	 * @generated
	 * @ordered
	 */
	protected BasicDataRepresentations basicDataRepresentations = null;

	/**
	 * The cached value of the '{@link #getSimpleDataTypes() <em>Simple Data Types</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSimpleDataTypes()
	 * @generated
	 * @ordered
	 */
	protected SimpleDataTypes simpleDataTypes = null;

	/**
	 * The cached value of the '{@link #getEnumeratedDataTypes() <em>Enumerated Data Types</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getEnumeratedDataTypes()
	 * @generated
	 * @ordered
	 */
	protected EnumeratedDataTypes enumeratedDataTypes = null;

	/**
	 * The cached value of the '{@link #getArrayDataTypes() <em>Array Data Types</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getArrayDataTypes()
	 * @generated
	 * @ordered
	 */
	protected ArrayDataTypes arrayDataTypes = null;

	/**
	 * The cached value of the '{@link #getFixedRecordDataTypes() <em>Fixed Record Data Types</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getFixedRecordDataTypes()
	 * @generated
	 * @ordered
	 */
	protected FixedRecordDataTypes fixedRecordDataTypes = null;

	/**
	 * The cached value of the '{@link #getVariantRecordDataTypes() <em>Variant Record Data Types</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getVariantRecordDataTypes()
	 * @generated
	 * @ordered
	 */
	protected VariantRecordDataTypes variantRecordDataTypes = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected DataTypesImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return OmtPackage.Literals.DATA_TYPES;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public BasicDataRepresentations getBasicDataRepresentations() {
		return basicDataRepresentations;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetBasicDataRepresentations(BasicDataRepresentations newBasicDataRepresentations,
			NotificationChain msgs) {
		BasicDataRepresentations oldBasicDataRepresentations = basicDataRepresentations;
		basicDataRepresentations = newBasicDataRepresentations;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.DATA_TYPES__BASIC_DATA_REPRESENTATIONS,
					oldBasicDataRepresentations,
					newBasicDataRepresentations);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setBasicDataRepresentations(BasicDataRepresentations newBasicDataRepresentations) {
		if (newBasicDataRepresentations != basicDataRepresentations) {
			NotificationChain msgs = null;
			if (basicDataRepresentations != null)
				msgs = ((InternalEObject) basicDataRepresentations).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.DATA_TYPES__BASIC_DATA_REPRESENTATIONS, null, msgs);
			if (newBasicDataRepresentations != null)
				msgs = ((InternalEObject) newBasicDataRepresentations).eInverseAdd(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.DATA_TYPES__BASIC_DATA_REPRESENTATIONS, null, msgs);
			msgs = basicSetBasicDataRepresentations(newBasicDataRepresentations, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.DATA_TYPES__BASIC_DATA_REPRESENTATIONS,
					newBasicDataRepresentations,
					newBasicDataRepresentations));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public SimpleDataTypes getSimpleDataTypes() {
		return simpleDataTypes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetSimpleDataTypes(SimpleDataTypes newSimpleDataTypes, NotificationChain msgs) {
		SimpleDataTypes oldSimpleDataTypes = simpleDataTypes;
		simpleDataTypes = newSimpleDataTypes;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.DATA_TYPES__SIMPLE_DATA_TYPES,
					oldSimpleDataTypes,
					newSimpleDataTypes);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setSimpleDataTypes(SimpleDataTypes newSimpleDataTypes) {
		if (newSimpleDataTypes != simpleDataTypes) {
			NotificationChain msgs = null;
			if (simpleDataTypes != null)
				msgs = ((InternalEObject) simpleDataTypes).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.DATA_TYPES__SIMPLE_DATA_TYPES, null, msgs);
			if (newSimpleDataTypes != null)
				msgs = ((InternalEObject) newSimpleDataTypes).eInverseAdd(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.DATA_TYPES__SIMPLE_DATA_TYPES, null, msgs);
			msgs = basicSetSimpleDataTypes(newSimpleDataTypes, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.DATA_TYPES__SIMPLE_DATA_TYPES,
					newSimpleDataTypes,
					newSimpleDataTypes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EnumeratedDataTypes getEnumeratedDataTypes() {
		return enumeratedDataTypes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetEnumeratedDataTypes(EnumeratedDataTypes newEnumeratedDataTypes,
			NotificationChain msgs) {
		EnumeratedDataTypes oldEnumeratedDataTypes = enumeratedDataTypes;
		enumeratedDataTypes = newEnumeratedDataTypes;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.DATA_TYPES__ENUMERATED_DATA_TYPES,
					oldEnumeratedDataTypes,
					newEnumeratedDataTypes);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setEnumeratedDataTypes(EnumeratedDataTypes newEnumeratedDataTypes) {
		if (newEnumeratedDataTypes != enumeratedDataTypes) {
			NotificationChain msgs = null;
			if (enumeratedDataTypes != null)
				msgs = ((InternalEObject) enumeratedDataTypes).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.DATA_TYPES__ENUMERATED_DATA_TYPES, null, msgs);
			if (newEnumeratedDataTypes != null)
				msgs = ((InternalEObject) newEnumeratedDataTypes).eInverseAdd(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.DATA_TYPES__ENUMERATED_DATA_TYPES, null, msgs);
			msgs = basicSetEnumeratedDataTypes(newEnumeratedDataTypes, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.DATA_TYPES__ENUMERATED_DATA_TYPES,
					newEnumeratedDataTypes,
					newEnumeratedDataTypes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public ArrayDataTypes getArrayDataTypes() {
		return arrayDataTypes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetArrayDataTypes(ArrayDataTypes newArrayDataTypes, NotificationChain msgs) {
		ArrayDataTypes oldArrayDataTypes = arrayDataTypes;
		arrayDataTypes = newArrayDataTypes;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.DATA_TYPES__ARRAY_DATA_TYPES,
					oldArrayDataTypes,
					newArrayDataTypes);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setArrayDataTypes(ArrayDataTypes newArrayDataTypes) {
		if (newArrayDataTypes != arrayDataTypes) {
			NotificationChain msgs = null;
			if (arrayDataTypes != null)
				msgs = ((InternalEObject) arrayDataTypes).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.DATA_TYPES__ARRAY_DATA_TYPES, null, msgs);
			if (newArrayDataTypes != null)
				msgs = ((InternalEObject) newArrayDataTypes).eInverseAdd(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.DATA_TYPES__ARRAY_DATA_TYPES, null, msgs);
			msgs = basicSetArrayDataTypes(newArrayDataTypes, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.DATA_TYPES__ARRAY_DATA_TYPES,
					newArrayDataTypes,
					newArrayDataTypes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public FixedRecordDataTypes getFixedRecordDataTypes() {
		return fixedRecordDataTypes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetFixedRecordDataTypes(FixedRecordDataTypes newFixedRecordDataTypes,
			NotificationChain msgs) {
		FixedRecordDataTypes oldFixedRecordDataTypes = fixedRecordDataTypes;
		fixedRecordDataTypes = newFixedRecordDataTypes;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.DATA_TYPES__FIXED_RECORD_DATA_TYPES,
					oldFixedRecordDataTypes,
					newFixedRecordDataTypes);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setFixedRecordDataTypes(FixedRecordDataTypes newFixedRecordDataTypes) {
		if (newFixedRecordDataTypes != fixedRecordDataTypes) {
			NotificationChain msgs = null;
			if (fixedRecordDataTypes != null)
				msgs = ((InternalEObject) fixedRecordDataTypes).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.DATA_TYPES__FIXED_RECORD_DATA_TYPES, null, msgs);
			if (newFixedRecordDataTypes != null)
				msgs = ((InternalEObject) newFixedRecordDataTypes).eInverseAdd(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.DATA_TYPES__FIXED_RECORD_DATA_TYPES, null, msgs);
			msgs = basicSetFixedRecordDataTypes(newFixedRecordDataTypes, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.DATA_TYPES__FIXED_RECORD_DATA_TYPES,
					newFixedRecordDataTypes,
					newFixedRecordDataTypes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public VariantRecordDataTypes getVariantRecordDataTypes() {
		return variantRecordDataTypes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetVariantRecordDataTypes(VariantRecordDataTypes newVariantRecordDataTypes,
			NotificationChain msgs) {
		VariantRecordDataTypes oldVariantRecordDataTypes = variantRecordDataTypes;
		variantRecordDataTypes = newVariantRecordDataTypes;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.DATA_TYPES__VARIANT_RECORD_DATA_TYPES,
					oldVariantRecordDataTypes,
					newVariantRecordDataTypes);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setVariantRecordDataTypes(VariantRecordDataTypes newVariantRecordDataTypes) {
		if (newVariantRecordDataTypes != variantRecordDataTypes) {
			NotificationChain msgs = null;
			if (variantRecordDataTypes != null)
				msgs = ((InternalEObject) variantRecordDataTypes).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.DATA_TYPES__VARIANT_RECORD_DATA_TYPES, null, msgs);
			if (newVariantRecordDataTypes != null)
				msgs = ((InternalEObject) newVariantRecordDataTypes).eInverseAdd(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.DATA_TYPES__VARIANT_RECORD_DATA_TYPES, null, msgs);
			msgs = basicSetVariantRecordDataTypes(newVariantRecordDataTypes, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.DATA_TYPES__VARIANT_RECORD_DATA_TYPES,
					newVariantRecordDataTypes,
					newVariantRecordDataTypes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case OmtPackage.DATA_TYPES__BASIC_DATA_REPRESENTATIONS:
			return basicSetBasicDataRepresentations(null, msgs);
		case OmtPackage.DATA_TYPES__SIMPLE_DATA_TYPES:
			return basicSetSimpleDataTypes(null, msgs);
		case OmtPackage.DATA_TYPES__ENUMERATED_DATA_TYPES:
			return basicSetEnumeratedDataTypes(null, msgs);
		case OmtPackage.DATA_TYPES__ARRAY_DATA_TYPES:
			return basicSetArrayDataTypes(null, msgs);
		case OmtPackage.DATA_TYPES__FIXED_RECORD_DATA_TYPES:
			return basicSetFixedRecordDataTypes(null, msgs);
		case OmtPackage.DATA_TYPES__VARIANT_RECORD_DATA_TYPES:
			return basicSetVariantRecordDataTypes(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case OmtPackage.DATA_TYPES__BASIC_DATA_REPRESENTATIONS:
			return getBasicDataRepresentations();
		case OmtPackage.DATA_TYPES__SIMPLE_DATA_TYPES:
			return getSimpleDataTypes();
		case OmtPackage.DATA_TYPES__ENUMERATED_DATA_TYPES:
			return getEnumeratedDataTypes();
		case OmtPackage.DATA_TYPES__ARRAY_DATA_TYPES:
			return getArrayDataTypes();
		case OmtPackage.DATA_TYPES__FIXED_RECORD_DATA_TYPES:
			return getFixedRecordDataTypes();
		case OmtPackage.DATA_TYPES__VARIANT_RECORD_DATA_TYPES:
			return getVariantRecordDataTypes();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case OmtPackage.DATA_TYPES__BASIC_DATA_REPRESENTATIONS:
			setBasicDataRepresentations((BasicDataRepresentations) newValue);
			return;
		case OmtPackage.DATA_TYPES__SIMPLE_DATA_TYPES:
			setSimpleDataTypes((SimpleDataTypes) newValue);
			return;
		case OmtPackage.DATA_TYPES__ENUMERATED_DATA_TYPES:
			setEnumeratedDataTypes((EnumeratedDataTypes) newValue);
			return;
		case OmtPackage.DATA_TYPES__ARRAY_DATA_TYPES:
			setArrayDataTypes((ArrayDataTypes) newValue);
			return;
		case OmtPackage.DATA_TYPES__FIXED_RECORD_DATA_TYPES:
			setFixedRecordDataTypes((FixedRecordDataTypes) newValue);
			return;
		case OmtPackage.DATA_TYPES__VARIANT_RECORD_DATA_TYPES:
			setVariantRecordDataTypes((VariantRecordDataTypes) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
		case OmtPackage.DATA_TYPES__BASIC_DATA_REPRESENTATIONS:
			setBasicDataRepresentations((BasicDataRepresentations) null);
			return;
		case OmtPackage.DATA_TYPES__SIMPLE_DATA_TYPES:
			setSimpleDataTypes((SimpleDataTypes) null);
			return;
		case OmtPackage.DATA_TYPES__ENUMERATED_DATA_TYPES:
			setEnumeratedDataTypes((EnumeratedDataTypes) null);
			return;
		case OmtPackage.DATA_TYPES__ARRAY_DATA_TYPES:
			setArrayDataTypes((ArrayDataTypes) null);
			return;
		case OmtPackage.DATA_TYPES__FIXED_RECORD_DATA_TYPES:
			setFixedRecordDataTypes((FixedRecordDataTypes) null);
			return;
		case OmtPackage.DATA_TYPES__VARIANT_RECORD_DATA_TYPES:
			setVariantRecordDataTypes((VariantRecordDataTypes) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case OmtPackage.DATA_TYPES__BASIC_DATA_REPRESENTATIONS:
			return basicDataRepresentations != null;
		case OmtPackage.DATA_TYPES__SIMPLE_DATA_TYPES:
			return simpleDataTypes != null;
		case OmtPackage.DATA_TYPES__ENUMERATED_DATA_TYPES:
			return enumeratedDataTypes != null;
		case OmtPackage.DATA_TYPES__ARRAY_DATA_TYPES:
			return arrayDataTypes != null;
		case OmtPackage.DATA_TYPES__FIXED_RECORD_DATA_TYPES:
			return fixedRecordDataTypes != null;
		case OmtPackage.DATA_TYPES__VARIANT_RECORD_DATA_TYPES:
			return variantRecordDataTypes != null;
		}
		return super.eIsSet(featureID);
	}

} // DataTypesImpl
