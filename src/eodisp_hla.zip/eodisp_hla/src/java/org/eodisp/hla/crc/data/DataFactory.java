/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.data;

import hla.rti1516.FederateHandle;
import hla.rti1516.ObjectInstanceHandle;

import org.eclipse.emf.ecore.EFactory;
import org.eodisp.hla.common.lrc.LrcHandle;
import org.eodisp.hla.common.lrc.LrcRemote;
import org.eodisp.hla.crc.FederationExecution;
import org.eodisp.hla.crc.omt.ObjectClass;

/**
 * <!-- begin-user-doc --> The <b>Factory</b> for the model. It provides a
 * create method for each non-abstract class of the model. <!-- end-user-doc -->
 * @see org.eodisp.hla.crc.data.DataPackage
 * @generated
 */
public interface DataFactory extends EFactory {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * @generated
	 */
	DataFactory eINSTANCE = org.eodisp.hla.crc.data.impl.DataFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Federate</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Federate</em>'.
	 * @generated
	 */
	Federate createFederate();

	/**
	 * @param federateHandle
	 * @param lrcRemote
	 * @generated NOT
	 */
	Federate createFederate(LrcHandle lrcRemote, FederateHandle federateHandle, FederationExecution execution);

	/**
	 * Returns a new object of class '<em>Object Instance</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Object Instance</em>'.
	 * @generated
	 */
	ObjectInstance createObjectInstance();

	/**
	 * Creates an object instance with its name set to
	 * <code>"HLA_" + objectInstanceHandle.toString()</code>.
	 * 
	 * @param objectClass
	 *            the object class of the instance
	 * @param objectInstanceHandle
	 *            the federation wide unique handle of the new instance
	 * @return the newly created object instance
	 */
	ObjectInstance createObjectInstance(ObjectClass objectClass, ObjectInstanceHandle objectInstanceHandle);

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	DataPackage getDataPackage();

} // DataFactory
