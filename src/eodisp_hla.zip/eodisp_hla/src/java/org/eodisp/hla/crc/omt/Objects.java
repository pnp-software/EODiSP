/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Objects</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.Objects#getObjectClass <em>Object Class</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjects()
 * @model extendedMetaData="name='Objects' kind='elementOnly'"
 * @generated
 */
public interface Objects extends EObject {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * Returns the value of the '<em><b>Object Class</b></em>' containment reference list.
	 * The list contents are of type {@link org.eodisp.hla.crc.omt.ObjectClass}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Object Class</em>' containment reference
	 * list isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Object Class</em>' containment reference list.
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjects_ObjectClass()
	 * @model type="org.eodisp.hla.crc.omt.ObjectClass" containment="true" required="true"
	 *        extendedMetaData="kind='element' name='objectClass' namespace='##targetNamespace'"
	 * @generated
	 */
	EList getObjectClass();

	EList getAllObjectClasses();

} // Objects
