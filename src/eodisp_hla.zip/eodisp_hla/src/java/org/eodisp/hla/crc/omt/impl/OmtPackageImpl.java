/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt.impl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EValidator;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.eclipse.emf.ecore.xml.type.XMLTypePackage;

import org.eodisp.hla.crc.data.DataPackage;

import org.eodisp.hla.crc.data.impl.DataPackageImpl;

import org.eclipse.emf.ecore.xml.type.impl.XMLTypePackageImpl;

import org.eodisp.hla.crc.omt.AcquisitionRequestTag;
import org.eodisp.hla.crc.omt.Alternative;
import org.eodisp.hla.crc.omt.ArrayData;
import org.eodisp.hla.crc.omt.ArrayDataTypes;
import org.eodisp.hla.crc.omt.Attribute;
import org.eodisp.hla.crc.omt.BasicData;
import org.eodisp.hla.crc.omt.BasicDataRepresentations;
import org.eodisp.hla.crc.omt.DTDVersionEnum;
import org.eodisp.hla.crc.omt.DataTypes;
import org.eodisp.hla.crc.omt.DeleteRemoveTag;
import org.eodisp.hla.crc.omt.Dimension;
import org.eodisp.hla.crc.omt.Dimensions;
import org.eodisp.hla.crc.omt.DivestitureCompletionTag;
import org.eodisp.hla.crc.omt.DivestitureRequestTag;
import org.eodisp.hla.crc.omt.DocumentRoot;
import org.eodisp.hla.crc.omt.EndianEnum;
import org.eodisp.hla.crc.omt.EnumeratedData;
import org.eodisp.hla.crc.omt.EnumeratedDataTypes;
import org.eodisp.hla.crc.omt.Enumerator;
import org.eodisp.hla.crc.omt.Field;
import org.eodisp.hla.crc.omt.FixedRecordData;
import org.eodisp.hla.crc.omt.FixedRecordDataTypes;
import org.eodisp.hla.crc.omt.InteractionClass;
import org.eodisp.hla.crc.omt.Interactions;
import org.eodisp.hla.crc.omt.Lookahead;
import org.eodisp.hla.crc.omt.Note;
import org.eodisp.hla.crc.omt.Notes;
import org.eodisp.hla.crc.omt.ObjectClass;
import org.eodisp.hla.crc.omt.ObjectModel;
import org.eodisp.hla.crc.omt.ObjectModelTypeEnum;
import org.eodisp.hla.crc.omt.Objects;
import org.eodisp.hla.crc.omt.OmtFactory;
import org.eodisp.hla.crc.omt.OmtPackage;
import org.eodisp.hla.crc.omt.OrderEnum;
import org.eodisp.hla.crc.omt.OwnershipEnum;
import org.eodisp.hla.crc.omt.Parameter;
import org.eodisp.hla.crc.omt.RequestUpdateTag;
import org.eodisp.hla.crc.omt.SendReceiveTag;
import org.eodisp.hla.crc.omt.SharingEnum;
import org.eodisp.hla.crc.omt.SimpleData;
import org.eodisp.hla.crc.omt.SimpleDataTypes;
import org.eodisp.hla.crc.omt.StateEnum;
import org.eodisp.hla.crc.omt.Switches;
import org.eodisp.hla.crc.omt.SyncCapabilityEnum;
import org.eodisp.hla.crc.omt.Synchronization;
import org.eodisp.hla.crc.omt.Synchronizations;
import org.eodisp.hla.crc.omt.Tags;
import org.eodisp.hla.crc.omt.Time;
import org.eodisp.hla.crc.omt.TimeStamp;
import org.eodisp.hla.crc.omt.Transportation;
import org.eodisp.hla.crc.omt.Transportations;
import org.eodisp.hla.crc.omt.UpdateReflectTag;
import org.eodisp.hla.crc.omt.UpdateTypeEnum;
import org.eodisp.hla.crc.omt.VariantRecordData;
import org.eodisp.hla.crc.omt.VariantRecordDataTypes;

import org.eodisp.hla.crc.omt.util.OmtValidator;

/**
 * <!-- begin-user-doc --> An implementation of the model <b>Package</b>. <!--
 * end-user-doc -->
 * @generated
 */
public class OmtPackageImpl extends EPackageImpl implements OmtPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass acquisitionRequestTagEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass alternativeEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass arrayDataEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass arrayDataTypesEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass attributeEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass basicDataEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass basicDataRepresentationsEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass dataTypesEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass deleteRemoveTagEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass dimensionEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass dimensionsEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass divestitureCompletionTagEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass divestitureRequestTagEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass documentRootEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass enumeratedDataEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass enumeratedDataTypesEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass enumeratorEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass fieldEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass fixedRecordDataEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass fixedRecordDataTypesEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass interactionClassEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass interactionsEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass lookaheadEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass noteEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass notesEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass objectClassEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass objectModelEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass objectsEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass parameterEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass requestUpdateTagEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sendReceiveTagEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass simpleDataEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass simpleDataTypesEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass switchesEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass synchronizationEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass synchronizationsEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tagsEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass timeEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass timeStampEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass transportationEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass transportationsEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass updateReflectTagEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass variantRecordDataEClass = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EClass variantRecordDataTypesEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum dtdVersionEnumEEnum = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum endianEnumEEnum = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum objectModelTypeEnumEEnum = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum orderEnumEEnum = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum ownershipEnumEEnum = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum sharingEnumEEnum = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum stateEnumEEnum = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum syncCapabilityEnumEEnum = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum updateTypeEnumEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType dtdVersionEnumObjectEDataType = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType endianEnumObjectEDataType = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType objectModelTypeEnumObjectEDataType = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType orderEnumObjectEDataType = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType ownershipEnumObjectEDataType = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType sharingEnumObjectEDataType = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType stateEnumObjectEDataType = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType syncCapabilityEnumObjectEDataType = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType updateTypeEnumObjectEDataType = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the
	 * package package URI value.
	 * <p>
	 * Note: the correct way to create the package is via the static factory
	 * method {@link #init init()}, which also performs initialization of the
	 * package, or returns the registered package, if one already exists. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see org.eodisp.hla.crc.omt.OmtPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private OmtPackageImpl() {
		super(eNS_URI, OmtFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this
	 * model, and for any others upon which it depends.  Simple
	 * dependencies are satisfied by calling this method on all
	 * dependent packages before doing anything else.  This method drives
	 * initialization for interdependent packages directly, in parallel
	 * with this package, itself.
	 * <p>Of this package and its interdependencies, all packages which
	 * have not yet been registered by their URI values are first created
	 * and registered.  The packages are then initialized in two steps:
	 * meta-model objects for all of the packages are created before any
	 * are initialized, since one package's meta-model objects may refer to
	 * those of another.
	 * <p>Invocation of this method will not affect any packages that have
	 * already been initialized.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static OmtPackage init() {
		if (isInited)
			return (OmtPackage) EPackage.Registry.INSTANCE.getEPackage(OmtPackage.eNS_URI);

		// Obtain or create and register package
		OmtPackageImpl theOmtPackage = (OmtPackageImpl) (EPackage.Registry.INSTANCE.getEPackage(eNS_URI) instanceof OmtPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(eNS_URI)
				: new OmtPackageImpl());

		isInited = true;

		// Initialize simple dependencies
		XMLTypePackage.eINSTANCE.eClass();

		// Obtain or create and register interdependencies
		DataPackageImpl theDataPackage = (DataPackageImpl) (EPackage.Registry.INSTANCE.getEPackage(DataPackage.eNS_URI) instanceof DataPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(DataPackage.eNS_URI)
				: DataPackage.eINSTANCE);

		// Create package meta-data objects
		theOmtPackage.createPackageContents();
		theDataPackage.createPackageContents();

		// Initialize created meta-data
		theOmtPackage.initializePackageContents();
		theDataPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theOmtPackage.freeze();

		return theOmtPackage;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAcquisitionRequestTag() {
		return acquisitionRequestTagEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAcquisitionRequestTag_DataType() {
		return (EAttribute) acquisitionRequestTagEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAcquisitionRequestTag_DataTypeNotes() {
		return (EAttribute) acquisitionRequestTagEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAcquisitionRequestTag_Semantics() {
		return (EAttribute) acquisitionRequestTagEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAcquisitionRequestTag_SemanticsNotes() {
		return (EAttribute) acquisitionRequestTagEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAlternative() {
		return alternativeEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAlternative_DataType() {
		return (EAttribute) alternativeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAlternative_DataTypeNotes() {
		return (EAttribute) alternativeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAlternative_Enumerator() {
		return (EAttribute) alternativeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAlternative_EnumeratorNotes() {
		return (EAttribute) alternativeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAlternative_Name() {
		return (EAttribute) alternativeEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAlternative_NameNotes() {
		return (EAttribute) alternativeEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAlternative_Semantics() {
		return (EAttribute) alternativeEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAlternative_SemanticsNotes() {
		return (EAttribute) alternativeEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getArrayData() {
		return arrayDataEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getArrayData_Cardinality() {
		return (EAttribute) arrayDataEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getArrayData_CardinalityNotes() {
		return (EAttribute) arrayDataEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getArrayData_DataType() {
		return (EAttribute) arrayDataEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getArrayData_DataTypeNotes() {
		return (EAttribute) arrayDataEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getArrayData_Encoding() {
		return (EAttribute) arrayDataEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getArrayData_EncodingNotes() {
		return (EAttribute) arrayDataEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getArrayData_Name() {
		return (EAttribute) arrayDataEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getArrayData_NameNotes() {
		return (EAttribute) arrayDataEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getArrayData_Semantics() {
		return (EAttribute) arrayDataEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getArrayData_SemanticsNotes() {
		return (EAttribute) arrayDataEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getArrayDataTypes() {
		return arrayDataTypesEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getArrayDataTypes_ArrayData() {
		return (EReference) arrayDataTypesEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAttribute() {
		return attributeEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttribute_DataType() {
		return (EAttribute) attributeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttribute_DataTypeNotes() {
		return (EAttribute) attributeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttribute_Dimensions() {
		return (EAttribute) attributeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttribute_DimensionsNotes() {
		return (EAttribute) attributeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttribute_Name() {
		return (EAttribute) attributeEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttribute_NameNotes() {
		return (EAttribute) attributeEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttribute_Order() {
		return (EAttribute) attributeEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttribute_OrderNotes() {
		return (EAttribute) attributeEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttribute_Ownership() {
		return (EAttribute) attributeEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttribute_OwnershipNotes() {
		return (EAttribute) attributeEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttribute_Semantics() {
		return (EAttribute) attributeEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttribute_SemanticsNotes() {
		return (EAttribute) attributeEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttribute_Sharing() {
		return (EAttribute) attributeEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttribute_SharingNotes() {
		return (EAttribute) attributeEClass.getEStructuralFeatures().get(13);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttribute_Transportation() {
		return (EAttribute) attributeEClass.getEStructuralFeatures().get(14);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttribute_TransportationNotes() {
		return (EAttribute) attributeEClass.getEStructuralFeatures().get(15);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttribute_UpdateCondition() {
		return (EAttribute) attributeEClass.getEStructuralFeatures().get(16);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttribute_UpdateConditionNotes() {
		return (EAttribute) attributeEClass.getEStructuralFeatures().get(17);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttribute_UpdateType() {
		return (EAttribute) attributeEClass.getEStructuralFeatures().get(18);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttribute_UpdateTypeNotes() {
		return (EAttribute) attributeEClass.getEStructuralFeatures().get(19);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAttribute_SubscribingFederates() {
		return (EReference) attributeEClass.getEStructuralFeatures().get(20);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAttribute_PublishingFederates() {
		return (EReference) attributeEClass.getEStructuralFeatures().get(21);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBasicData() {
		return basicDataEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBasicData_Encoding() {
		return (EAttribute) basicDataEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBasicData_EncodingNotes() {
		return (EAttribute) basicDataEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBasicData_Endian() {
		return (EAttribute) basicDataEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBasicData_EndianNotes() {
		return (EAttribute) basicDataEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBasicData_Interpretation() {
		return (EAttribute) basicDataEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBasicData_InterpretationNotes() {
		return (EAttribute) basicDataEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBasicData_Name() {
		return (EAttribute) basicDataEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBasicData_NameNotes() {
		return (EAttribute) basicDataEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBasicData_Size() {
		return (EAttribute) basicDataEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBasicData_SizeNotes() {
		return (EAttribute) basicDataEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBasicDataRepresentations() {
		return basicDataRepresentationsEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getBasicDataRepresentations_BasicData() {
		return (EReference) basicDataRepresentationsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDataTypes() {
		return dataTypesEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDataTypes_BasicDataRepresentations() {
		return (EReference) dataTypesEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDataTypes_SimpleDataTypes() {
		return (EReference) dataTypesEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDataTypes_EnumeratedDataTypes() {
		return (EReference) dataTypesEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDataTypes_ArrayDataTypes() {
		return (EReference) dataTypesEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDataTypes_FixedRecordDataTypes() {
		return (EReference) dataTypesEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDataTypes_VariantRecordDataTypes() {
		return (EReference) dataTypesEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDeleteRemoveTag() {
		return deleteRemoveTagEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDeleteRemoveTag_DataType() {
		return (EAttribute) deleteRemoveTagEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDeleteRemoveTag_DataTypeNotes() {
		return (EAttribute) deleteRemoveTagEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDeleteRemoveTag_Semantics() {
		return (EAttribute) deleteRemoveTagEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDeleteRemoveTag_SemanticsNotes() {
		return (EAttribute) deleteRemoveTagEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDimension() {
		return dimensionEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDimension_DataType() {
		return (EAttribute) dimensionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDimension_DataTypeNotes() {
		return (EAttribute) dimensionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDimension_Name() {
		return (EAttribute) dimensionEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDimension_NameNotes() {
		return (EAttribute) dimensionEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDimension_Normalization() {
		return (EAttribute) dimensionEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDimension_NormalizationNotes() {
		return (EAttribute) dimensionEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDimension_UpperBound() {
		return (EAttribute) dimensionEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDimension_UpperBoundNotes() {
		return (EAttribute) dimensionEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDimension_Value() {
		return (EAttribute) dimensionEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDimension_ValueNotes() {
		return (EAttribute) dimensionEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDimensions() {
		return dimensionsEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDimensions_Dimension() {
		return (EReference) dimensionsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDivestitureCompletionTag() {
		return divestitureCompletionTagEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDivestitureCompletionTag_DataType() {
		return (EAttribute) divestitureCompletionTagEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDivestitureCompletionTag_DataTypeNotes() {
		return (EAttribute) divestitureCompletionTagEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDivestitureCompletionTag_Semantics() {
		return (EAttribute) divestitureCompletionTagEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDivestitureCompletionTag_SemanticsNotes() {
		return (EAttribute) divestitureCompletionTagEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDivestitureRequestTag() {
		return divestitureRequestTagEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDivestitureRequestTag_DataType() {
		return (EAttribute) divestitureRequestTagEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDivestitureRequestTag_DataTypeNotes() {
		return (EAttribute) divestitureRequestTagEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDivestitureRequestTag_Semantics() {
		return (EAttribute) divestitureRequestTagEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDivestitureRequestTag_SemanticsNotes() {
		return (EAttribute) divestitureRequestTagEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDocumentRoot() {
		return documentRootEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDocumentRoot_Mixed() {
		return (EAttribute) documentRootEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_XMLNSPrefixMap() {
		return (EReference) documentRootEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_XSISchemaLocation() {
		return (EReference) documentRootEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_ObjectModel() {
		return (EReference) documentRootEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEnumeratedData() {
		return enumeratedDataEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEnumeratedData_Enumerator() {
		return (EReference) enumeratedDataEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEnumeratedData_Name() {
		return (EAttribute) enumeratedDataEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEnumeratedData_NameNotes() {
		return (EAttribute) enumeratedDataEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEnumeratedData_Representation() {
		return (EAttribute) enumeratedDataEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEnumeratedData_RepresentationNotes() {
		return (EAttribute) enumeratedDataEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEnumeratedData_Semantics() {
		return (EAttribute) enumeratedDataEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEnumeratedData_SemanticsNotes() {
		return (EAttribute) enumeratedDataEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEnumeratedDataTypes() {
		return enumeratedDataTypesEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEnumeratedDataTypes_EnumeratedData() {
		return (EReference) enumeratedDataTypesEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEnumerator() {
		return enumeratorEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEnumerator_Name() {
		return (EAttribute) enumeratorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEnumerator_NameNotes() {
		return (EAttribute) enumeratorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEnumerator_Values() {
		return (EAttribute) enumeratorEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEnumerator_ValuesNotes() {
		return (EAttribute) enumeratorEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getField() {
		return fieldEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getField_DataType() {
		return (EAttribute) fieldEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getField_DataTypeNotes() {
		return (EAttribute) fieldEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getField_Name() {
		return (EAttribute) fieldEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getField_NameNotes() {
		return (EAttribute) fieldEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getField_Semantics() {
		return (EAttribute) fieldEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getField_SemanticsNotes() {
		return (EAttribute) fieldEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFixedRecordData() {
		return fixedRecordDataEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFixedRecordData_Field() {
		return (EReference) fixedRecordDataEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFixedRecordData_Encoding() {
		return (EAttribute) fixedRecordDataEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFixedRecordData_EncodingNotes() {
		return (EAttribute) fixedRecordDataEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFixedRecordData_Name() {
		return (EAttribute) fixedRecordDataEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFixedRecordData_NameNotes() {
		return (EAttribute) fixedRecordDataEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFixedRecordData_Semantics() {
		return (EAttribute) fixedRecordDataEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFixedRecordData_SemanticsNotes() {
		return (EAttribute) fixedRecordDataEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFixedRecordDataTypes() {
		return fixedRecordDataTypesEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFixedRecordDataTypes_FixedRecordData() {
		return (EReference) fixedRecordDataTypesEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getInteractionClass() {
		return interactionClassEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getInteractionClass_Parameters() {
		return (EReference) interactionClassEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getInteractionClass_SubClasses() {
		return (EReference) interactionClassEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getInteractionClass_Dimensions() {
		return (EAttribute) interactionClassEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getInteractionClass_DimensionsNotes() {
		return (EAttribute) interactionClassEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getInteractionClass_Name() {
		return (EAttribute) interactionClassEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getInteractionClass_NameNotes() {
		return (EAttribute) interactionClassEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getInteractionClass_Order() {
		return (EAttribute) interactionClassEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getInteractionClass_OrderNotes() {
		return (EAttribute) interactionClassEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getInteractionClass_Semantics() {
		return (EAttribute) interactionClassEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getInteractionClass_SemanticsNotes() {
		return (EAttribute) interactionClassEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getInteractionClass_Sharing() {
		return (EAttribute) interactionClassEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getInteractionClass_SharingNotes() {
		return (EAttribute) interactionClassEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getInteractionClass_Transportation() {
		return (EAttribute) interactionClassEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getInteractionClass_TransportationNotes() {
		return (EAttribute) interactionClassEClass.getEStructuralFeatures().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getInteractionClass_SubscribingFederates() {
		return (EReference) interactionClassEClass.getEStructuralFeatures().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getInteractionClass_PublishingFederates() {
		return (EReference) interactionClassEClass.getEStructuralFeatures().get(15);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getInteractions() {
		return interactionsEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getInteractions_InteractionClass() {
		return (EReference) interactionsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getLookahead() {
		return lookaheadEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getLookahead_DataType() {
		return (EAttribute) lookaheadEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getLookahead_DataTypeNotes() {
		return (EAttribute) lookaheadEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getLookahead_Semantics() {
		return (EAttribute) lookaheadEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getLookahead_SemanticsNotes() {
		return (EAttribute) lookaheadEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getNote() {
		return noteEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getNote_Name() {
		return (EAttribute) noteEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getNote_Semantics() {
		return (EAttribute) noteEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getNote_SemanticsNotes() {
		return (EAttribute) noteEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getNotes() {
		return notesEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getNotes_Note() {
		return (EReference) notesEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getObjectClass() {
		return objectClassEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getObjectClass_Attributes() {
		return (EReference) objectClassEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getObjectClass_SubClasses() {
		return (EReference) objectClassEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectClass_Name() {
		return (EAttribute) objectClassEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectClass_NameNotes() {
		return (EAttribute) objectClassEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectClass_Semantics() {
		return (EAttribute) objectClassEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectClass_SemanticsNotes() {
		return (EAttribute) objectClassEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectClass_Sharing() {
		return (EAttribute) objectClassEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectClass_SharingNotes() {
		return (EAttribute) objectClassEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getObjectModel() {
		return objectModelEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getObjectModel_Objects() {
		return (EReference) objectModelEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getObjectModel_Interactions() {
		return (EReference) objectModelEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getObjectModel_Dimensions() {
		return (EReference) objectModelEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getObjectModel_Time() {
		return (EReference) objectModelEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getObjectModel_Tags() {
		return (EReference) objectModelEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getObjectModel_Synchronizations() {
		return (EReference) objectModelEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getObjectModel_Transportations() {
		return (EReference) objectModelEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getObjectModel_Switches() {
		return (EReference) objectModelEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getObjectModel_DataTypes() {
		return (EReference) objectModelEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getObjectModel_Notes() {
		return (EReference) objectModelEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectModel_AppDomain() {
		return (EAttribute) objectModelEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectModel_AppDomainNotes() {
		return (EAttribute) objectModelEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectModel_Date() {
		return (EAttribute) objectModelEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectModel_DateNotes() {
		return (EAttribute) objectModelEClass.getEStructuralFeatures().get(13);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectModel_DTDversion() {
		return (EAttribute) objectModelEClass.getEStructuralFeatures().get(14);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectModel_Name() {
		return (EAttribute) objectModelEClass.getEStructuralFeatures().get(15);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectModel_NameNotes() {
		return (EAttribute) objectModelEClass.getEStructuralFeatures().get(16);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectModel_Other() {
		return (EAttribute) objectModelEClass.getEStructuralFeatures().get(17);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectModel_OtherNotes() {
		return (EAttribute) objectModelEClass.getEStructuralFeatures().get(18);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectModel_PocEmail() {
		return (EAttribute) objectModelEClass.getEStructuralFeatures().get(19);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectModel_PocEmailNotes() {
		return (EAttribute) objectModelEClass.getEStructuralFeatures().get(20);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectModel_PocName() {
		return (EAttribute) objectModelEClass.getEStructuralFeatures().get(21);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectModel_PocNameNotes() {
		return (EAttribute) objectModelEClass.getEStructuralFeatures().get(22);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectModel_PocOrg() {
		return (EAttribute) objectModelEClass.getEStructuralFeatures().get(23);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectModel_PocOrgNotes() {
		return (EAttribute) objectModelEClass.getEStructuralFeatures().get(24);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectModel_PocPhone() {
		return (EAttribute) objectModelEClass.getEStructuralFeatures().get(25);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectModel_PocPhoneNotes() {
		return (EAttribute) objectModelEClass.getEStructuralFeatures().get(26);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectModel_Purpose() {
		return (EAttribute) objectModelEClass.getEStructuralFeatures().get(27);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectModel_PurposeNotes() {
		return (EAttribute) objectModelEClass.getEStructuralFeatures().get(28);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectModel_References() {
		return (EAttribute) objectModelEClass.getEStructuralFeatures().get(29);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectModel_ReferencesNotes() {
		return (EAttribute) objectModelEClass.getEStructuralFeatures().get(30);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectModel_Sponsor() {
		return (EAttribute) objectModelEClass.getEStructuralFeatures().get(31);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectModel_SponsorNotes() {
		return (EAttribute) objectModelEClass.getEStructuralFeatures().get(32);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectModel_Type() {
		return (EAttribute) objectModelEClass.getEStructuralFeatures().get(33);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectModel_TypeNotes() {
		return (EAttribute) objectModelEClass.getEStructuralFeatures().get(34);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectModel_Version() {
		return (EAttribute) objectModelEClass.getEStructuralFeatures().get(35);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectModel_VersionNotes() {
		return (EAttribute) objectModelEClass.getEStructuralFeatures().get(36);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getObjects() {
		return objectsEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getObjects_ObjectClass() {
		return (EReference) objectsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getParameter() {
		return parameterEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getParameter_DataType() {
		return (EAttribute) parameterEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getParameter_DataTypeNotes() {
		return (EAttribute) parameterEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getParameter_Name() {
		return (EAttribute) parameterEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getParameter_NameNotes() {
		return (EAttribute) parameterEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getParameter_Semantics() {
		return (EAttribute) parameterEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getParameter_SemanticsNotes() {
		return (EAttribute) parameterEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRequestUpdateTag() {
		return requestUpdateTagEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRequestUpdateTag_DataType() {
		return (EAttribute) requestUpdateTagEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRequestUpdateTag_DataTypeNotes() {
		return (EAttribute) requestUpdateTagEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRequestUpdateTag_Semantics() {
		return (EAttribute) requestUpdateTagEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRequestUpdateTag_SemanticsNotes() {
		return (EAttribute) requestUpdateTagEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSendReceiveTag() {
		return sendReceiveTagEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSendReceiveTag_DataType() {
		return (EAttribute) sendReceiveTagEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSendReceiveTag_DataTypeNotes() {
		return (EAttribute) sendReceiveTagEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSendReceiveTag_Semantics() {
		return (EAttribute) sendReceiveTagEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSendReceiveTag_SemanticsNotes() {
		return (EAttribute) sendReceiveTagEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSimpleData() {
		return simpleDataEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSimpleData_Accuracy() {
		return (EAttribute) simpleDataEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSimpleData_AccuracyNotes() {
		return (EAttribute) simpleDataEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSimpleData_Name() {
		return (EAttribute) simpleDataEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSimpleData_NameNotes() {
		return (EAttribute) simpleDataEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSimpleData_Representation() {
		return (EAttribute) simpleDataEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSimpleData_RepresentationNotes() {
		return (EAttribute) simpleDataEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSimpleData_Resolution() {
		return (EAttribute) simpleDataEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSimpleData_ResolutionNotes() {
		return (EAttribute) simpleDataEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSimpleData_Semantics() {
		return (EAttribute) simpleDataEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSimpleData_SemanticsNotes() {
		return (EAttribute) simpleDataEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSimpleData_Units() {
		return (EAttribute) simpleDataEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSimpleData_UnitsNotes() {
		return (EAttribute) simpleDataEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSimpleDataTypes() {
		return simpleDataTypesEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSimpleDataTypes_SimpleData() {
		return (EReference) simpleDataTypesEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSwitches() {
		return switchesEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSwitches_AttributeRelevanceAdvisory() {
		return (EAttribute) switchesEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSwitches_AttributeRelevanceAdvisoryNotes() {
		return (EAttribute) switchesEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSwitches_AttributeScopeAdvisory() {
		return (EAttribute) switchesEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSwitches_AttributeScopeAdvisoryNotes() {
		return (EAttribute) switchesEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSwitches_AutoProvide() {
		return (EAttribute) switchesEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSwitches_AutoProvideNotes() {
		return (EAttribute) switchesEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSwitches_ConveyRegionDesignatorSets() {
		return (EAttribute) switchesEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSwitches_ConveyRegionDesignatorSetsNotes() {
		return (EAttribute) switchesEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSwitches_InteractionRelevanceAdvisory() {
		return (EAttribute) switchesEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSwitches_InteractionRelevanceAdvisoryNotes() {
		return (EAttribute) switchesEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSwitches_ObjectClassRelevanceAdvisory() {
		return (EAttribute) switchesEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSwitches_ObjectClassRelevanceAdvisoryNotes() {
		return (EAttribute) switchesEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSwitches_ServiceReporting() {
		return (EAttribute) switchesEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSwitches_ServiceReportingNotes() {
		return (EAttribute) switchesEClass.getEStructuralFeatures().get(13);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSynchronization() {
		return synchronizationEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSynchronization_Capability() {
		return (EAttribute) synchronizationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSynchronization_CapabilityNotes() {
		return (EAttribute) synchronizationEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSynchronization_DataType() {
		return (EAttribute) synchronizationEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSynchronization_DataTypeNotes() {
		return (EAttribute) synchronizationEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSynchronization_Label() {
		return (EAttribute) synchronizationEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSynchronization_LabelNotes() {
		return (EAttribute) synchronizationEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSynchronization_Semantics() {
		return (EAttribute) synchronizationEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSynchronization_SemanticsNotes() {
		return (EAttribute) synchronizationEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSynchronizations() {
		return synchronizationsEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSynchronizations_Synchronization() {
		return (EReference) synchronizationsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTags() {
		return tagsEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTags_UpdateReflectTag() {
		return (EReference) tagsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTags_SendReceiveTag() {
		return (EReference) tagsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTags_DeleteRemoveTag() {
		return (EReference) tagsEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTags_DivestitureRequestTag() {
		return (EReference) tagsEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTags_DivestitureCompletionTag() {
		return (EReference) tagsEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTags_AcquisitionRequestTag() {
		return (EReference) tagsEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTags_RequestUpdateTag() {
		return (EReference) tagsEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTime() {
		return timeEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTime_TimeStamp() {
		return (EReference) timeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTime_Lookahead() {
		return (EReference) timeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTimeStamp() {
		return timeStampEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTimeStamp_DataType() {
		return (EAttribute) timeStampEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTimeStamp_DataTypeNotes() {
		return (EAttribute) timeStampEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTimeStamp_Semantics() {
		return (EAttribute) timeStampEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTimeStamp_SemanticsNotes() {
		return (EAttribute) timeStampEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTransportation() {
		return transportationEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransportation_Description() {
		return (EAttribute) transportationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransportation_DescriptionNotes() {
		return (EAttribute) transportationEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransportation_Name() {
		return (EAttribute) transportationEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransportation_NameNotes() {
		return (EAttribute) transportationEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTransportations() {
		return transportationsEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTransportations_Transportation() {
		return (EReference) transportationsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getUpdateReflectTag() {
		return updateReflectTagEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getUpdateReflectTag_DataType() {
		return (EAttribute) updateReflectTagEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getUpdateReflectTag_DataTypeNotes() {
		return (EAttribute) updateReflectTagEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getUpdateReflectTag_Semantics() {
		return (EAttribute) updateReflectTagEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getUpdateReflectTag_SemanticsNotes() {
		return (EAttribute) updateReflectTagEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getVariantRecordData() {
		return variantRecordDataEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getVariantRecordData_Alternative() {
		return (EReference) variantRecordDataEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVariantRecordData_DataType() {
		return (EAttribute) variantRecordDataEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVariantRecordData_DataTypeNotes() {
		return (EAttribute) variantRecordDataEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVariantRecordData_Discriminant() {
		return (EAttribute) variantRecordDataEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVariantRecordData_DiscriminantNotes() {
		return (EAttribute) variantRecordDataEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVariantRecordData_Encoding() {
		return (EAttribute) variantRecordDataEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVariantRecordData_EncodingNotes() {
		return (EAttribute) variantRecordDataEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVariantRecordData_Name() {
		return (EAttribute) variantRecordDataEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVariantRecordData_NameNotes() {
		return (EAttribute) variantRecordDataEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVariantRecordData_Semantics() {
		return (EAttribute) variantRecordDataEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVariantRecordData_SemanticsNotes() {
		return (EAttribute) variantRecordDataEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getVariantRecordDataTypes() {
		return variantRecordDataTypesEClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getVariantRecordDataTypes_VariantRecordData() {
		return (EReference) variantRecordDataTypesEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getEndianEnum() {
		return endianEnumEEnum;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getObjectModelTypeEnum() {
		return objectModelTypeEnumEEnum;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getOrderEnum() {
		return orderEnumEEnum;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getOwnershipEnum() {
		return ownershipEnumEEnum;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getSharingEnum() {
		return sharingEnumEEnum;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getStateEnum() {
		return stateEnumEEnum;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getSyncCapabilityEnum() {
		return syncCapabilityEnumEEnum;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getUpdateTypeEnum() {
		return updateTypeEnumEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getDTDVersionEnumObject() {
		return dtdVersionEnumObjectEDataType;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getDTDVersionEnum() {
		return dtdVersionEnumEEnum;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getEndianEnumObject() {
		return endianEnumObjectEDataType;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getObjectModelTypeEnumObject() {
		return objectModelTypeEnumObjectEDataType;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getOrderEnumObject() {
		return orderEnumObjectEDataType;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getOwnershipEnumObject() {
		return ownershipEnumObjectEDataType;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getSharingEnumObject() {
		return sharingEnumObjectEDataType;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getStateEnumObject() {
		return stateEnumObjectEDataType;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getSyncCapabilityEnumObject() {
		return syncCapabilityEnumObjectEDataType;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getUpdateTypeEnumObject() {
		return updateTypeEnumObjectEDataType;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public OmtFactory getOmtFactory() {
		return (OmtFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		acquisitionRequestTagEClass = createEClass(ACQUISITION_REQUEST_TAG);
		createEAttribute(acquisitionRequestTagEClass, ACQUISITION_REQUEST_TAG__DATA_TYPE);
		createEAttribute(acquisitionRequestTagEClass, ACQUISITION_REQUEST_TAG__DATA_TYPE_NOTES);
		createEAttribute(acquisitionRequestTagEClass, ACQUISITION_REQUEST_TAG__SEMANTICS);
		createEAttribute(acquisitionRequestTagEClass, ACQUISITION_REQUEST_TAG__SEMANTICS_NOTES);

		alternativeEClass = createEClass(ALTERNATIVE);
		createEAttribute(alternativeEClass, ALTERNATIVE__DATA_TYPE);
		createEAttribute(alternativeEClass, ALTERNATIVE__DATA_TYPE_NOTES);
		createEAttribute(alternativeEClass, ALTERNATIVE__ENUMERATOR);
		createEAttribute(alternativeEClass, ALTERNATIVE__ENUMERATOR_NOTES);
		createEAttribute(alternativeEClass, ALTERNATIVE__NAME);
		createEAttribute(alternativeEClass, ALTERNATIVE__NAME_NOTES);
		createEAttribute(alternativeEClass, ALTERNATIVE__SEMANTICS);
		createEAttribute(alternativeEClass, ALTERNATIVE__SEMANTICS_NOTES);

		arrayDataEClass = createEClass(ARRAY_DATA);
		createEAttribute(arrayDataEClass, ARRAY_DATA__CARDINALITY);
		createEAttribute(arrayDataEClass, ARRAY_DATA__CARDINALITY_NOTES);
		createEAttribute(arrayDataEClass, ARRAY_DATA__DATA_TYPE);
		createEAttribute(arrayDataEClass, ARRAY_DATA__DATA_TYPE_NOTES);
		createEAttribute(arrayDataEClass, ARRAY_DATA__ENCODING);
		createEAttribute(arrayDataEClass, ARRAY_DATA__ENCODING_NOTES);
		createEAttribute(arrayDataEClass, ARRAY_DATA__NAME);
		createEAttribute(arrayDataEClass, ARRAY_DATA__NAME_NOTES);
		createEAttribute(arrayDataEClass, ARRAY_DATA__SEMANTICS);
		createEAttribute(arrayDataEClass, ARRAY_DATA__SEMANTICS_NOTES);

		arrayDataTypesEClass = createEClass(ARRAY_DATA_TYPES);
		createEReference(arrayDataTypesEClass, ARRAY_DATA_TYPES__ARRAY_DATA);

		attributeEClass = createEClass(ATTRIBUTE);
		createEAttribute(attributeEClass, ATTRIBUTE__DATA_TYPE);
		createEAttribute(attributeEClass, ATTRIBUTE__DATA_TYPE_NOTES);
		createEAttribute(attributeEClass, ATTRIBUTE__DIMENSIONS);
		createEAttribute(attributeEClass, ATTRIBUTE__DIMENSIONS_NOTES);
		createEAttribute(attributeEClass, ATTRIBUTE__NAME);
		createEAttribute(attributeEClass, ATTRIBUTE__NAME_NOTES);
		createEAttribute(attributeEClass, ATTRIBUTE__ORDER);
		createEAttribute(attributeEClass, ATTRIBUTE__ORDER_NOTES);
		createEAttribute(attributeEClass, ATTRIBUTE__OWNERSHIP);
		createEAttribute(attributeEClass, ATTRIBUTE__OWNERSHIP_NOTES);
		createEAttribute(attributeEClass, ATTRIBUTE__SEMANTICS);
		createEAttribute(attributeEClass, ATTRIBUTE__SEMANTICS_NOTES);
		createEAttribute(attributeEClass, ATTRIBUTE__SHARING);
		createEAttribute(attributeEClass, ATTRIBUTE__SHARING_NOTES);
		createEAttribute(attributeEClass, ATTRIBUTE__TRANSPORTATION);
		createEAttribute(attributeEClass, ATTRIBUTE__TRANSPORTATION_NOTES);
		createEAttribute(attributeEClass, ATTRIBUTE__UPDATE_CONDITION);
		createEAttribute(attributeEClass, ATTRIBUTE__UPDATE_CONDITION_NOTES);
		createEAttribute(attributeEClass, ATTRIBUTE__UPDATE_TYPE);
		createEAttribute(attributeEClass, ATTRIBUTE__UPDATE_TYPE_NOTES);
		createEReference(attributeEClass, ATTRIBUTE__SUBSCRIBING_FEDERATES);
		createEReference(attributeEClass, ATTRIBUTE__PUBLISHING_FEDERATES);

		basicDataEClass = createEClass(BASIC_DATA);
		createEAttribute(basicDataEClass, BASIC_DATA__ENCODING);
		createEAttribute(basicDataEClass, BASIC_DATA__ENCODING_NOTES);
		createEAttribute(basicDataEClass, BASIC_DATA__ENDIAN);
		createEAttribute(basicDataEClass, BASIC_DATA__ENDIAN_NOTES);
		createEAttribute(basicDataEClass, BASIC_DATA__INTERPRETATION);
		createEAttribute(basicDataEClass, BASIC_DATA__INTERPRETATION_NOTES);
		createEAttribute(basicDataEClass, BASIC_DATA__NAME);
		createEAttribute(basicDataEClass, BASIC_DATA__NAME_NOTES);
		createEAttribute(basicDataEClass, BASIC_DATA__SIZE);
		createEAttribute(basicDataEClass, BASIC_DATA__SIZE_NOTES);

		basicDataRepresentationsEClass = createEClass(BASIC_DATA_REPRESENTATIONS);
		createEReference(basicDataRepresentationsEClass, BASIC_DATA_REPRESENTATIONS__BASIC_DATA);

		dataTypesEClass = createEClass(DATA_TYPES);
		createEReference(dataTypesEClass, DATA_TYPES__BASIC_DATA_REPRESENTATIONS);
		createEReference(dataTypesEClass, DATA_TYPES__SIMPLE_DATA_TYPES);
		createEReference(dataTypesEClass, DATA_TYPES__ENUMERATED_DATA_TYPES);
		createEReference(dataTypesEClass, DATA_TYPES__ARRAY_DATA_TYPES);
		createEReference(dataTypesEClass, DATA_TYPES__FIXED_RECORD_DATA_TYPES);
		createEReference(dataTypesEClass, DATA_TYPES__VARIANT_RECORD_DATA_TYPES);

		deleteRemoveTagEClass = createEClass(DELETE_REMOVE_TAG);
		createEAttribute(deleteRemoveTagEClass, DELETE_REMOVE_TAG__DATA_TYPE);
		createEAttribute(deleteRemoveTagEClass, DELETE_REMOVE_TAG__DATA_TYPE_NOTES);
		createEAttribute(deleteRemoveTagEClass, DELETE_REMOVE_TAG__SEMANTICS);
		createEAttribute(deleteRemoveTagEClass, DELETE_REMOVE_TAG__SEMANTICS_NOTES);

		dimensionEClass = createEClass(DIMENSION);
		createEAttribute(dimensionEClass, DIMENSION__DATA_TYPE);
		createEAttribute(dimensionEClass, DIMENSION__DATA_TYPE_NOTES);
		createEAttribute(dimensionEClass, DIMENSION__NAME);
		createEAttribute(dimensionEClass, DIMENSION__NAME_NOTES);
		createEAttribute(dimensionEClass, DIMENSION__NORMALIZATION);
		createEAttribute(dimensionEClass, DIMENSION__NORMALIZATION_NOTES);
		createEAttribute(dimensionEClass, DIMENSION__UPPER_BOUND);
		createEAttribute(dimensionEClass, DIMENSION__UPPER_BOUND_NOTES);
		createEAttribute(dimensionEClass, DIMENSION__VALUE);
		createEAttribute(dimensionEClass, DIMENSION__VALUE_NOTES);

		dimensionsEClass = createEClass(DIMENSIONS);
		createEReference(dimensionsEClass, DIMENSIONS__DIMENSION);

		divestitureCompletionTagEClass = createEClass(DIVESTITURE_COMPLETION_TAG);
		createEAttribute(divestitureCompletionTagEClass, DIVESTITURE_COMPLETION_TAG__DATA_TYPE);
		createEAttribute(divestitureCompletionTagEClass, DIVESTITURE_COMPLETION_TAG__DATA_TYPE_NOTES);
		createEAttribute(divestitureCompletionTagEClass, DIVESTITURE_COMPLETION_TAG__SEMANTICS);
		createEAttribute(divestitureCompletionTagEClass, DIVESTITURE_COMPLETION_TAG__SEMANTICS_NOTES);

		divestitureRequestTagEClass = createEClass(DIVESTITURE_REQUEST_TAG);
		createEAttribute(divestitureRequestTagEClass, DIVESTITURE_REQUEST_TAG__DATA_TYPE);
		createEAttribute(divestitureRequestTagEClass, DIVESTITURE_REQUEST_TAG__DATA_TYPE_NOTES);
		createEAttribute(divestitureRequestTagEClass, DIVESTITURE_REQUEST_TAG__SEMANTICS);
		createEAttribute(divestitureRequestTagEClass, DIVESTITURE_REQUEST_TAG__SEMANTICS_NOTES);

		documentRootEClass = createEClass(DOCUMENT_ROOT);
		createEAttribute(documentRootEClass, DOCUMENT_ROOT__MIXED);
		createEReference(documentRootEClass, DOCUMENT_ROOT__XMLNS_PREFIX_MAP);
		createEReference(documentRootEClass, DOCUMENT_ROOT__XSI_SCHEMA_LOCATION);
		createEReference(documentRootEClass, DOCUMENT_ROOT__OBJECT_MODEL);

		enumeratedDataEClass = createEClass(ENUMERATED_DATA);
		createEReference(enumeratedDataEClass, ENUMERATED_DATA__ENUMERATOR);
		createEAttribute(enumeratedDataEClass, ENUMERATED_DATA__NAME);
		createEAttribute(enumeratedDataEClass, ENUMERATED_DATA__NAME_NOTES);
		createEAttribute(enumeratedDataEClass, ENUMERATED_DATA__REPRESENTATION);
		createEAttribute(enumeratedDataEClass, ENUMERATED_DATA__REPRESENTATION_NOTES);
		createEAttribute(enumeratedDataEClass, ENUMERATED_DATA__SEMANTICS);
		createEAttribute(enumeratedDataEClass, ENUMERATED_DATA__SEMANTICS_NOTES);

		enumeratedDataTypesEClass = createEClass(ENUMERATED_DATA_TYPES);
		createEReference(enumeratedDataTypesEClass, ENUMERATED_DATA_TYPES__ENUMERATED_DATA);

		enumeratorEClass = createEClass(ENUMERATOR);
		createEAttribute(enumeratorEClass, ENUMERATOR__NAME);
		createEAttribute(enumeratorEClass, ENUMERATOR__NAME_NOTES);
		createEAttribute(enumeratorEClass, ENUMERATOR__VALUES);
		createEAttribute(enumeratorEClass, ENUMERATOR__VALUES_NOTES);

		fieldEClass = createEClass(FIELD);
		createEAttribute(fieldEClass, FIELD__DATA_TYPE);
		createEAttribute(fieldEClass, FIELD__DATA_TYPE_NOTES);
		createEAttribute(fieldEClass, FIELD__NAME);
		createEAttribute(fieldEClass, FIELD__NAME_NOTES);
		createEAttribute(fieldEClass, FIELD__SEMANTICS);
		createEAttribute(fieldEClass, FIELD__SEMANTICS_NOTES);

		fixedRecordDataEClass = createEClass(FIXED_RECORD_DATA);
		createEReference(fixedRecordDataEClass, FIXED_RECORD_DATA__FIELD);
		createEAttribute(fixedRecordDataEClass, FIXED_RECORD_DATA__ENCODING);
		createEAttribute(fixedRecordDataEClass, FIXED_RECORD_DATA__ENCODING_NOTES);
		createEAttribute(fixedRecordDataEClass, FIXED_RECORD_DATA__NAME);
		createEAttribute(fixedRecordDataEClass, FIXED_RECORD_DATA__NAME_NOTES);
		createEAttribute(fixedRecordDataEClass, FIXED_RECORD_DATA__SEMANTICS);
		createEAttribute(fixedRecordDataEClass, FIXED_RECORD_DATA__SEMANTICS_NOTES);

		fixedRecordDataTypesEClass = createEClass(FIXED_RECORD_DATA_TYPES);
		createEReference(fixedRecordDataTypesEClass, FIXED_RECORD_DATA_TYPES__FIXED_RECORD_DATA);

		interactionClassEClass = createEClass(INTERACTION_CLASS);
		createEReference(interactionClassEClass, INTERACTION_CLASS__PARAMETERS);
		createEReference(interactionClassEClass, INTERACTION_CLASS__SUB_CLASSES);
		createEAttribute(interactionClassEClass, INTERACTION_CLASS__DIMENSIONS);
		createEAttribute(interactionClassEClass, INTERACTION_CLASS__DIMENSIONS_NOTES);
		createEAttribute(interactionClassEClass, INTERACTION_CLASS__NAME);
		createEAttribute(interactionClassEClass, INTERACTION_CLASS__NAME_NOTES);
		createEAttribute(interactionClassEClass, INTERACTION_CLASS__ORDER);
		createEAttribute(interactionClassEClass, INTERACTION_CLASS__ORDER_NOTES);
		createEAttribute(interactionClassEClass, INTERACTION_CLASS__SEMANTICS);
		createEAttribute(interactionClassEClass, INTERACTION_CLASS__SEMANTICS_NOTES);
		createEAttribute(interactionClassEClass, INTERACTION_CLASS__SHARING);
		createEAttribute(interactionClassEClass, INTERACTION_CLASS__SHARING_NOTES);
		createEAttribute(interactionClassEClass, INTERACTION_CLASS__TRANSPORTATION);
		createEAttribute(interactionClassEClass, INTERACTION_CLASS__TRANSPORTATION_NOTES);
		createEReference(interactionClassEClass, INTERACTION_CLASS__SUBSCRIBING_FEDERATES);
		createEReference(interactionClassEClass, INTERACTION_CLASS__PUBLISHING_FEDERATES);

		interactionsEClass = createEClass(INTERACTIONS);
		createEReference(interactionsEClass, INTERACTIONS__INTERACTION_CLASS);

		lookaheadEClass = createEClass(LOOKAHEAD);
		createEAttribute(lookaheadEClass, LOOKAHEAD__DATA_TYPE);
		createEAttribute(lookaheadEClass, LOOKAHEAD__DATA_TYPE_NOTES);
		createEAttribute(lookaheadEClass, LOOKAHEAD__SEMANTICS);
		createEAttribute(lookaheadEClass, LOOKAHEAD__SEMANTICS_NOTES);

		noteEClass = createEClass(NOTE);
		createEAttribute(noteEClass, NOTE__NAME);
		createEAttribute(noteEClass, NOTE__SEMANTICS);
		createEAttribute(noteEClass, NOTE__SEMANTICS_NOTES);

		notesEClass = createEClass(NOTES);
		createEReference(notesEClass, NOTES__NOTE);

		objectClassEClass = createEClass(OBJECT_CLASS);
		createEReference(objectClassEClass, OBJECT_CLASS__ATTRIBUTES);
		createEReference(objectClassEClass, OBJECT_CLASS__SUB_CLASSES);
		createEAttribute(objectClassEClass, OBJECT_CLASS__NAME);
		createEAttribute(objectClassEClass, OBJECT_CLASS__NAME_NOTES);
		createEAttribute(objectClassEClass, OBJECT_CLASS__SEMANTICS);
		createEAttribute(objectClassEClass, OBJECT_CLASS__SEMANTICS_NOTES);
		createEAttribute(objectClassEClass, OBJECT_CLASS__SHARING);
		createEAttribute(objectClassEClass, OBJECT_CLASS__SHARING_NOTES);

		objectModelEClass = createEClass(OBJECT_MODEL);
		createEReference(objectModelEClass, OBJECT_MODEL__OBJECTS);
		createEReference(objectModelEClass, OBJECT_MODEL__INTERACTIONS);
		createEReference(objectModelEClass, OBJECT_MODEL__DIMENSIONS);
		createEReference(objectModelEClass, OBJECT_MODEL__TIME);
		createEReference(objectModelEClass, OBJECT_MODEL__TAGS);
		createEReference(objectModelEClass, OBJECT_MODEL__SYNCHRONIZATIONS);
		createEReference(objectModelEClass, OBJECT_MODEL__TRANSPORTATIONS);
		createEReference(objectModelEClass, OBJECT_MODEL__SWITCHES);
		createEReference(objectModelEClass, OBJECT_MODEL__DATA_TYPES);
		createEReference(objectModelEClass, OBJECT_MODEL__NOTES);
		createEAttribute(objectModelEClass, OBJECT_MODEL__APP_DOMAIN);
		createEAttribute(objectModelEClass, OBJECT_MODEL__APP_DOMAIN_NOTES);
		createEAttribute(objectModelEClass, OBJECT_MODEL__DATE);
		createEAttribute(objectModelEClass, OBJECT_MODEL__DATE_NOTES);
		createEAttribute(objectModelEClass, OBJECT_MODEL__DT_DVERSION);
		createEAttribute(objectModelEClass, OBJECT_MODEL__NAME);
		createEAttribute(objectModelEClass, OBJECT_MODEL__NAME_NOTES);
		createEAttribute(objectModelEClass, OBJECT_MODEL__OTHER);
		createEAttribute(objectModelEClass, OBJECT_MODEL__OTHER_NOTES);
		createEAttribute(objectModelEClass, OBJECT_MODEL__POC_EMAIL);
		createEAttribute(objectModelEClass, OBJECT_MODEL__POC_EMAIL_NOTES);
		createEAttribute(objectModelEClass, OBJECT_MODEL__POC_NAME);
		createEAttribute(objectModelEClass, OBJECT_MODEL__POC_NAME_NOTES);
		createEAttribute(objectModelEClass, OBJECT_MODEL__POC_ORG);
		createEAttribute(objectModelEClass, OBJECT_MODEL__POC_ORG_NOTES);
		createEAttribute(objectModelEClass, OBJECT_MODEL__POC_PHONE);
		createEAttribute(objectModelEClass, OBJECT_MODEL__POC_PHONE_NOTES);
		createEAttribute(objectModelEClass, OBJECT_MODEL__PURPOSE);
		createEAttribute(objectModelEClass, OBJECT_MODEL__PURPOSE_NOTES);
		createEAttribute(objectModelEClass, OBJECT_MODEL__REFERENCES);
		createEAttribute(objectModelEClass, OBJECT_MODEL__REFERENCES_NOTES);
		createEAttribute(objectModelEClass, OBJECT_MODEL__SPONSOR);
		createEAttribute(objectModelEClass, OBJECT_MODEL__SPONSOR_NOTES);
		createEAttribute(objectModelEClass, OBJECT_MODEL__TYPE);
		createEAttribute(objectModelEClass, OBJECT_MODEL__TYPE_NOTES);
		createEAttribute(objectModelEClass, OBJECT_MODEL__VERSION);
		createEAttribute(objectModelEClass, OBJECT_MODEL__VERSION_NOTES);

		objectsEClass = createEClass(OBJECTS);
		createEReference(objectsEClass, OBJECTS__OBJECT_CLASS);

		parameterEClass = createEClass(PARAMETER);
		createEAttribute(parameterEClass, PARAMETER__DATA_TYPE);
		createEAttribute(parameterEClass, PARAMETER__DATA_TYPE_NOTES);
		createEAttribute(parameterEClass, PARAMETER__NAME);
		createEAttribute(parameterEClass, PARAMETER__NAME_NOTES);
		createEAttribute(parameterEClass, PARAMETER__SEMANTICS);
		createEAttribute(parameterEClass, PARAMETER__SEMANTICS_NOTES);

		requestUpdateTagEClass = createEClass(REQUEST_UPDATE_TAG);
		createEAttribute(requestUpdateTagEClass, REQUEST_UPDATE_TAG__DATA_TYPE);
		createEAttribute(requestUpdateTagEClass, REQUEST_UPDATE_TAG__DATA_TYPE_NOTES);
		createEAttribute(requestUpdateTagEClass, REQUEST_UPDATE_TAG__SEMANTICS);
		createEAttribute(requestUpdateTagEClass, REQUEST_UPDATE_TAG__SEMANTICS_NOTES);

		sendReceiveTagEClass = createEClass(SEND_RECEIVE_TAG);
		createEAttribute(sendReceiveTagEClass, SEND_RECEIVE_TAG__DATA_TYPE);
		createEAttribute(sendReceiveTagEClass, SEND_RECEIVE_TAG__DATA_TYPE_NOTES);
		createEAttribute(sendReceiveTagEClass, SEND_RECEIVE_TAG__SEMANTICS);
		createEAttribute(sendReceiveTagEClass, SEND_RECEIVE_TAG__SEMANTICS_NOTES);

		simpleDataEClass = createEClass(SIMPLE_DATA);
		createEAttribute(simpleDataEClass, SIMPLE_DATA__ACCURACY);
		createEAttribute(simpleDataEClass, SIMPLE_DATA__ACCURACY_NOTES);
		createEAttribute(simpleDataEClass, SIMPLE_DATA__NAME);
		createEAttribute(simpleDataEClass, SIMPLE_DATA__NAME_NOTES);
		createEAttribute(simpleDataEClass, SIMPLE_DATA__REPRESENTATION);
		createEAttribute(simpleDataEClass, SIMPLE_DATA__REPRESENTATION_NOTES);
		createEAttribute(simpleDataEClass, SIMPLE_DATA__RESOLUTION);
		createEAttribute(simpleDataEClass, SIMPLE_DATA__RESOLUTION_NOTES);
		createEAttribute(simpleDataEClass, SIMPLE_DATA__SEMANTICS);
		createEAttribute(simpleDataEClass, SIMPLE_DATA__SEMANTICS_NOTES);
		createEAttribute(simpleDataEClass, SIMPLE_DATA__UNITS);
		createEAttribute(simpleDataEClass, SIMPLE_DATA__UNITS_NOTES);

		simpleDataTypesEClass = createEClass(SIMPLE_DATA_TYPES);
		createEReference(simpleDataTypesEClass, SIMPLE_DATA_TYPES__SIMPLE_DATA);

		switchesEClass = createEClass(SWITCHES);
		createEAttribute(switchesEClass, SWITCHES__ATTRIBUTE_RELEVANCE_ADVISORY);
		createEAttribute(switchesEClass, SWITCHES__ATTRIBUTE_RELEVANCE_ADVISORY_NOTES);
		createEAttribute(switchesEClass, SWITCHES__ATTRIBUTE_SCOPE_ADVISORY);
		createEAttribute(switchesEClass, SWITCHES__ATTRIBUTE_SCOPE_ADVISORY_NOTES);
		createEAttribute(switchesEClass, SWITCHES__AUTO_PROVIDE);
		createEAttribute(switchesEClass, SWITCHES__AUTO_PROVIDE_NOTES);
		createEAttribute(switchesEClass, SWITCHES__CONVEY_REGION_DESIGNATOR_SETS);
		createEAttribute(switchesEClass, SWITCHES__CONVEY_REGION_DESIGNATOR_SETS_NOTES);
		createEAttribute(switchesEClass, SWITCHES__INTERACTION_RELEVANCE_ADVISORY);
		createEAttribute(switchesEClass, SWITCHES__INTERACTION_RELEVANCE_ADVISORY_NOTES);
		createEAttribute(switchesEClass, SWITCHES__OBJECT_CLASS_RELEVANCE_ADVISORY);
		createEAttribute(switchesEClass, SWITCHES__OBJECT_CLASS_RELEVANCE_ADVISORY_NOTES);
		createEAttribute(switchesEClass, SWITCHES__SERVICE_REPORTING);
		createEAttribute(switchesEClass, SWITCHES__SERVICE_REPORTING_NOTES);

		synchronizationEClass = createEClass(SYNCHRONIZATION);
		createEAttribute(synchronizationEClass, SYNCHRONIZATION__CAPABILITY);
		createEAttribute(synchronizationEClass, SYNCHRONIZATION__CAPABILITY_NOTES);
		createEAttribute(synchronizationEClass, SYNCHRONIZATION__DATA_TYPE);
		createEAttribute(synchronizationEClass, SYNCHRONIZATION__DATA_TYPE_NOTES);
		createEAttribute(synchronizationEClass, SYNCHRONIZATION__LABEL);
		createEAttribute(synchronizationEClass, SYNCHRONIZATION__LABEL_NOTES);
		createEAttribute(synchronizationEClass, SYNCHRONIZATION__SEMANTICS);
		createEAttribute(synchronizationEClass, SYNCHRONIZATION__SEMANTICS_NOTES);

		synchronizationsEClass = createEClass(SYNCHRONIZATIONS);
		createEReference(synchronizationsEClass, SYNCHRONIZATIONS__SYNCHRONIZATION);

		tagsEClass = createEClass(TAGS);
		createEReference(tagsEClass, TAGS__UPDATE_REFLECT_TAG);
		createEReference(tagsEClass, TAGS__SEND_RECEIVE_TAG);
		createEReference(tagsEClass, TAGS__DELETE_REMOVE_TAG);
		createEReference(tagsEClass, TAGS__DIVESTITURE_REQUEST_TAG);
		createEReference(tagsEClass, TAGS__DIVESTITURE_COMPLETION_TAG);
		createEReference(tagsEClass, TAGS__ACQUISITION_REQUEST_TAG);
		createEReference(tagsEClass, TAGS__REQUEST_UPDATE_TAG);

		timeEClass = createEClass(TIME);
		createEReference(timeEClass, TIME__TIME_STAMP);
		createEReference(timeEClass, TIME__LOOKAHEAD);

		timeStampEClass = createEClass(TIME_STAMP);
		createEAttribute(timeStampEClass, TIME_STAMP__DATA_TYPE);
		createEAttribute(timeStampEClass, TIME_STAMP__DATA_TYPE_NOTES);
		createEAttribute(timeStampEClass, TIME_STAMP__SEMANTICS);
		createEAttribute(timeStampEClass, TIME_STAMP__SEMANTICS_NOTES);

		transportationEClass = createEClass(TRANSPORTATION);
		createEAttribute(transportationEClass, TRANSPORTATION__DESCRIPTION);
		createEAttribute(transportationEClass, TRANSPORTATION__DESCRIPTION_NOTES);
		createEAttribute(transportationEClass, TRANSPORTATION__NAME);
		createEAttribute(transportationEClass, TRANSPORTATION__NAME_NOTES);

		transportationsEClass = createEClass(TRANSPORTATIONS);
		createEReference(transportationsEClass, TRANSPORTATIONS__TRANSPORTATION);

		updateReflectTagEClass = createEClass(UPDATE_REFLECT_TAG);
		createEAttribute(updateReflectTagEClass, UPDATE_REFLECT_TAG__DATA_TYPE);
		createEAttribute(updateReflectTagEClass, UPDATE_REFLECT_TAG__DATA_TYPE_NOTES);
		createEAttribute(updateReflectTagEClass, UPDATE_REFLECT_TAG__SEMANTICS);
		createEAttribute(updateReflectTagEClass, UPDATE_REFLECT_TAG__SEMANTICS_NOTES);

		variantRecordDataEClass = createEClass(VARIANT_RECORD_DATA);
		createEReference(variantRecordDataEClass, VARIANT_RECORD_DATA__ALTERNATIVE);
		createEAttribute(variantRecordDataEClass, VARIANT_RECORD_DATA__DATA_TYPE);
		createEAttribute(variantRecordDataEClass, VARIANT_RECORD_DATA__DATA_TYPE_NOTES);
		createEAttribute(variantRecordDataEClass, VARIANT_RECORD_DATA__DISCRIMINANT);
		createEAttribute(variantRecordDataEClass, VARIANT_RECORD_DATA__DISCRIMINANT_NOTES);
		createEAttribute(variantRecordDataEClass, VARIANT_RECORD_DATA__ENCODING);
		createEAttribute(variantRecordDataEClass, VARIANT_RECORD_DATA__ENCODING_NOTES);
		createEAttribute(variantRecordDataEClass, VARIANT_RECORD_DATA__NAME);
		createEAttribute(variantRecordDataEClass, VARIANT_RECORD_DATA__NAME_NOTES);
		createEAttribute(variantRecordDataEClass, VARIANT_RECORD_DATA__SEMANTICS);
		createEAttribute(variantRecordDataEClass, VARIANT_RECORD_DATA__SEMANTICS_NOTES);

		variantRecordDataTypesEClass = createEClass(VARIANT_RECORD_DATA_TYPES);
		createEReference(variantRecordDataTypesEClass, VARIANT_RECORD_DATA_TYPES__VARIANT_RECORD_DATA);

		// Create enums
		dtdVersionEnumEEnum = createEEnum(DTD_VERSION_ENUM);
		endianEnumEEnum = createEEnum(ENDIAN_ENUM);
		objectModelTypeEnumEEnum = createEEnum(OBJECT_MODEL_TYPE_ENUM);
		orderEnumEEnum = createEEnum(ORDER_ENUM);
		ownershipEnumEEnum = createEEnum(OWNERSHIP_ENUM);
		sharingEnumEEnum = createEEnum(SHARING_ENUM);
		stateEnumEEnum = createEEnum(STATE_ENUM);
		syncCapabilityEnumEEnum = createEEnum(SYNC_CAPABILITY_ENUM);
		updateTypeEnumEEnum = createEEnum(UPDATE_TYPE_ENUM);

		// Create data types
		dtdVersionEnumObjectEDataType = createEDataType(DTD_VERSION_ENUM_OBJECT);
		endianEnumObjectEDataType = createEDataType(ENDIAN_ENUM_OBJECT);
		objectModelTypeEnumObjectEDataType = createEDataType(OBJECT_MODEL_TYPE_ENUM_OBJECT);
		orderEnumObjectEDataType = createEDataType(ORDER_ENUM_OBJECT);
		ownershipEnumObjectEDataType = createEDataType(OWNERSHIP_ENUM_OBJECT);
		sharingEnumObjectEDataType = createEDataType(SHARING_ENUM_OBJECT);
		stateEnumObjectEDataType = createEDataType(STATE_ENUM_OBJECT);
		syncCapabilityEnumObjectEDataType = createEDataType(SYNC_CAPABILITY_ENUM_OBJECT);
		updateTypeEnumObjectEDataType = createEDataType(UPDATE_TYPE_ENUM_OBJECT);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model. This
	 * method is guarded to have no affect on any invocation but its first. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		XMLTypePackage theXMLTypePackage = (XMLTypePackage) EPackage.Registry.INSTANCE
				.getEPackage(XMLTypePackage.eNS_URI);
		DataPackage theDataPackage = (DataPackage) EPackage.Registry.INSTANCE.getEPackage(DataPackage.eNS_URI);

		// Add supertypes to classes

		// Initialize classes and features; add operations and parameters
		initEClass(
				acquisitionRequestTagEClass,
				AcquisitionRequestTag.class,
				"AcquisitionRequestTag",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(
				getAcquisitionRequestTag_DataType(),
				theXMLTypePackage.getNMTOKEN(),
				"dataType",
				null,
				1,
				1,
				AcquisitionRequestTag.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getAcquisitionRequestTag_DataTypeNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"dataTypeNotes",
				null,
				0,
				1,
				AcquisitionRequestTag.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getAcquisitionRequestTag_Semantics(),
				theXMLTypePackage.getAnySimpleType(),
				"semantics",
				null,
				0,
				1,
				AcquisitionRequestTag.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getAcquisitionRequestTag_SemanticsNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"semanticsNotes",
				null,
				0,
				1,
				AcquisitionRequestTag.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				alternativeEClass,
				Alternative.class,
				"Alternative",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(
				getAlternative_DataType(),
				theXMLTypePackage.getNMTOKEN(),
				"dataType",
				null,
				0,
				1,
				Alternative.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getAlternative_DataTypeNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"dataTypeNotes",
				null,
				0,
				1,
				Alternative.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getAlternative_Enumerator(),
				theXMLTypePackage.getAnySimpleType(),
				"enumerator",
				null,
				1,
				1,
				Alternative.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getAlternative_EnumeratorNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"enumeratorNotes",
				null,
				0,
				1,
				Alternative.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getAlternative_Name(),
				theXMLTypePackage.getNMTOKEN(),
				"name",
				null,
				0,
				1,
				Alternative.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getAlternative_NameNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"nameNotes",
				null,
				0,
				1,
				Alternative.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getAlternative_Semantics(),
				theXMLTypePackage.getAnySimpleType(),
				"semantics",
				null,
				0,
				1,
				Alternative.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getAlternative_SemanticsNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"semanticsNotes",
				null,
				0,
				1,
				Alternative.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				arrayDataEClass,
				ArrayData.class,
				"ArrayData",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(
				getArrayData_Cardinality(),
				theXMLTypePackage.getAnySimpleType(),
				"cardinality",
				null,
				0,
				1,
				ArrayData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getArrayData_CardinalityNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"cardinalityNotes",
				null,
				0,
				1,
				ArrayData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getArrayData_DataType(),
				theXMLTypePackage.getIDREF(),
				"dataType",
				null,
				0,
				1,
				ArrayData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getArrayData_DataTypeNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"dataTypeNotes",
				null,
				0,
				1,
				ArrayData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getArrayData_Encoding(),
				theXMLTypePackage.getAnySimpleType(),
				"encoding",
				null,
				0,
				1,
				ArrayData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getArrayData_EncodingNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"encodingNotes",
				null,
				0,
				1,
				ArrayData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getArrayData_Name(),
				theXMLTypePackage.getID(),
				"name",
				null,
				1,
				1,
				ArrayData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getArrayData_NameNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"nameNotes",
				null,
				0,
				1,
				ArrayData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getArrayData_Semantics(),
				theXMLTypePackage.getAnySimpleType(),
				"semantics",
				null,
				0,
				1,
				ArrayData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getArrayData_SemanticsNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"semanticsNotes",
				null,
				0,
				1,
				ArrayData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				arrayDataTypesEClass,
				ArrayDataTypes.class,
				"ArrayDataTypes",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(
				getArrayDataTypes_ArrayData(),
				this.getArrayData(),
				null,
				"arrayData",
				null,
				1,
				-1,
				ArrayDataTypes.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				attributeEClass,
				Attribute.class,
				"Attribute",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(
				getAttribute_DataType(),
				theXMLTypePackage.getNMTOKEN(),
				"dataType",
				null,
				0,
				1,
				Attribute.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getAttribute_DataTypeNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"dataTypeNotes",
				null,
				0,
				1,
				Attribute.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getAttribute_Dimensions(),
				theXMLTypePackage.getNMTOKENS(),
				"dimensions",
				null,
				0,
				1,
				Attribute.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getAttribute_DimensionsNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"dimensionsNotes",
				null,
				0,
				1,
				Attribute.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getAttribute_Name(),
				theXMLTypePackage.getNMTOKEN(),
				"name",
				null,
				1,
				1,
				Attribute.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getAttribute_NameNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"nameNotes",
				null,
				0,
				1,
				Attribute.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getAttribute_Order(),
				this.getOrderEnum(),
				"order",
				"Receive",
				0,
				1,
				Attribute.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getAttribute_OrderNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"orderNotes",
				null,
				0,
				1,
				Attribute.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getAttribute_Ownership(),
				this.getOwnershipEnum(),
				"ownership",
				"Divest",
				0,
				1,
				Attribute.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getAttribute_OwnershipNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"ownershipNotes",
				null,
				0,
				1,
				Attribute.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getAttribute_Semantics(),
				theXMLTypePackage.getAnySimpleType(),
				"semantics",
				null,
				0,
				1,
				Attribute.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getAttribute_SemanticsNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"semanticsNotes",
				null,
				0,
				1,
				Attribute.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getAttribute_Sharing(),
				this.getSharingEnum(),
				"sharing",
				"Publish",
				0,
				1,
				Attribute.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getAttribute_SharingNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"sharingNotes",
				null,
				0,
				1,
				Attribute.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getAttribute_Transportation(),
				theXMLTypePackage.getNMTOKEN(),
				"transportation",
				null,
				0,
				1,
				Attribute.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getAttribute_TransportationNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"transportationNotes",
				null,
				0,
				1,
				Attribute.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getAttribute_UpdateCondition(),
				theXMLTypePackage.getAnySimpleType(),
				"updateCondition",
				null,
				0,
				1,
				Attribute.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getAttribute_UpdateConditionNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"updateConditionNotes",
				null,
				0,
				1,
				Attribute.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getAttribute_UpdateType(),
				this.getUpdateTypeEnum(),
				"updateType",
				"Static",
				0,
				1,
				Attribute.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getAttribute_UpdateTypeNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"updateTypeNotes",
				null,
				0,
				1,
				Attribute.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getAttribute_SubscribingFederates(),
				theDataPackage.getFederate(),
				theDataPackage.getFederate_SubscribedAttributes(),
				"subscribingFederates",
				null,
				0,
				-1,
				Attribute.class,
				IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_COMPOSITE,
				IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getAttribute_PublishingFederates(),
				theDataPackage.getFederate(),
				theDataPackage.getFederate_PublishedAttributes(),
				"publishingFederates",
				null,
				0,
				-1,
				Attribute.class,
				IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_COMPOSITE,
				IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				basicDataEClass,
				BasicData.class,
				"BasicData",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(
				getBasicData_Encoding(),
				theXMLTypePackage.getAnySimpleType(),
				"encoding",
				null,
				0,
				1,
				BasicData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getBasicData_EncodingNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"encodingNotes",
				null,
				0,
				1,
				BasicData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getBasicData_Endian(),
				this.getEndianEnum(),
				"endian",
				"Big",
				0,
				1,
				BasicData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getBasicData_EndianNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"endianNotes",
				null,
				0,
				1,
				BasicData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getBasicData_Interpretation(),
				theXMLTypePackage.getAnySimpleType(),
				"interpretation",
				null,
				0,
				1,
				BasicData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getBasicData_InterpretationNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"interpretationNotes",
				null,
				0,
				1,
				BasicData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getBasicData_Name(),
				theXMLTypePackage.getID(),
				"name",
				null,
				1,
				1,
				BasicData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getBasicData_NameNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"nameNotes",
				null,
				0,
				1,
				BasicData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getBasicData_Size(),
				theXMLTypePackage.getAnySimpleType(),
				"size",
				null,
				0,
				1,
				BasicData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getBasicData_SizeNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"sizeNotes",
				null,
				0,
				1,
				BasicData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				basicDataRepresentationsEClass,
				BasicDataRepresentations.class,
				"BasicDataRepresentations",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(
				getBasicDataRepresentations_BasicData(),
				this.getBasicData(),
				null,
				"basicData",
				null,
				1,
				-1,
				BasicDataRepresentations.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				dataTypesEClass,
				DataTypes.class,
				"DataTypes",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(
				getDataTypes_BasicDataRepresentations(),
				this.getBasicDataRepresentations(),
				null,
				"basicDataRepresentations",
				null,
				1,
				1,
				DataTypes.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getDataTypes_SimpleDataTypes(),
				this.getSimpleDataTypes(),
				null,
				"simpleDataTypes",
				null,
				0,
				1,
				DataTypes.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getDataTypes_EnumeratedDataTypes(),
				this.getEnumeratedDataTypes(),
				null,
				"enumeratedDataTypes",
				null,
				0,
				1,
				DataTypes.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getDataTypes_ArrayDataTypes(),
				this.getArrayDataTypes(),
				null,
				"arrayDataTypes",
				null,
				0,
				1,
				DataTypes.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getDataTypes_FixedRecordDataTypes(),
				this.getFixedRecordDataTypes(),
				null,
				"fixedRecordDataTypes",
				null,
				0,
				1,
				DataTypes.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getDataTypes_VariantRecordDataTypes(),
				this.getVariantRecordDataTypes(),
				null,
				"variantRecordDataTypes",
				null,
				0,
				1,
				DataTypes.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				deleteRemoveTagEClass,
				DeleteRemoveTag.class,
				"DeleteRemoveTag",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(
				getDeleteRemoveTag_DataType(),
				theXMLTypePackage.getNMTOKEN(),
				"dataType",
				null,
				1,
				1,
				DeleteRemoveTag.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getDeleteRemoveTag_DataTypeNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"dataTypeNotes",
				null,
				0,
				1,
				DeleteRemoveTag.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getDeleteRemoveTag_Semantics(),
				theXMLTypePackage.getAnySimpleType(),
				"semantics",
				null,
				0,
				1,
				DeleteRemoveTag.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getDeleteRemoveTag_SemanticsNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"semanticsNotes",
				null,
				0,
				1,
				DeleteRemoveTag.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				dimensionEClass,
				Dimension.class,
				"Dimension",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(
				getDimension_DataType(),
				theXMLTypePackage.getNMTOKEN(),
				"dataType",
				null,
				0,
				1,
				Dimension.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getDimension_DataTypeNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"dataTypeNotes",
				null,
				0,
				1,
				Dimension.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getDimension_Name(),
				theXMLTypePackage.getNMTOKEN(),
				"name",
				null,
				1,
				1,
				Dimension.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getDimension_NameNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"nameNotes",
				null,
				0,
				1,
				Dimension.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getDimension_Normalization(),
				theXMLTypePackage.getAnySimpleType(),
				"normalization",
				null,
				0,
				1,
				Dimension.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getDimension_NormalizationNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"normalizationNotes",
				null,
				0,
				1,
				Dimension.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getDimension_UpperBound(),
				theXMLTypePackage.getAnySimpleType(),
				"upperBound",
				null,
				0,
				1,
				Dimension.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getDimension_UpperBoundNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"upperBoundNotes",
				null,
				0,
				1,
				Dimension.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getDimension_Value(),
				theXMLTypePackage.getAnySimpleType(),
				"value",
				null,
				0,
				1,
				Dimension.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getDimension_ValueNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"valueNotes",
				null,
				0,
				1,
				Dimension.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				dimensionsEClass,
				Dimensions.class,
				"Dimensions",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(
				getDimensions_Dimension(),
				this.getDimension(),
				null,
				"dimension",
				null,
				0,
				-1,
				Dimensions.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				divestitureCompletionTagEClass,
				DivestitureCompletionTag.class,
				"DivestitureCompletionTag",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(
				getDivestitureCompletionTag_DataType(),
				theXMLTypePackage.getNMTOKEN(),
				"dataType",
				null,
				1,
				1,
				DivestitureCompletionTag.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getDivestitureCompletionTag_DataTypeNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"dataTypeNotes",
				null,
				0,
				1,
				DivestitureCompletionTag.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getDivestitureCompletionTag_Semantics(),
				theXMLTypePackage.getAnySimpleType(),
				"semantics",
				null,
				0,
				1,
				DivestitureCompletionTag.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getDivestitureCompletionTag_SemanticsNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"semanticsNotes",
				null,
				0,
				1,
				DivestitureCompletionTag.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				divestitureRequestTagEClass,
				DivestitureRequestTag.class,
				"DivestitureRequestTag",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(
				getDivestitureRequestTag_DataType(),
				theXMLTypePackage.getNMTOKEN(),
				"dataType",
				null,
				1,
				1,
				DivestitureRequestTag.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getDivestitureRequestTag_DataTypeNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"dataTypeNotes",
				null,
				0,
				1,
				DivestitureRequestTag.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getDivestitureRequestTag_Semantics(),
				theXMLTypePackage.getAnySimpleType(),
				"semantics",
				null,
				0,
				1,
				DivestitureRequestTag.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getDivestitureRequestTag_SemanticsNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"semanticsNotes",
				null,
				0,
				1,
				DivestitureRequestTag.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				documentRootEClass,
				DocumentRoot.class,
				"DocumentRoot",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(
				getDocumentRoot_Mixed(),
				ecorePackage.getEFeatureMapEntry(),
				"mixed",
				null,
				0,
				-1,
				null,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getDocumentRoot_XMLNSPrefixMap(),
				ecorePackage.getEStringToStringMapEntry(),
				null,
				"xMLNSPrefixMap",
				null,
				0,
				-1,
				null,
				IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getDocumentRoot_XSISchemaLocation(),
				ecorePackage.getEStringToStringMapEntry(),
				null,
				"xSISchemaLocation",
				null,
				0,
				-1,
				null,
				IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getDocumentRoot_ObjectModel(),
				this.getObjectModel(),
				null,
				"objectModel",
				null,
				0,
				-2,
				null,
				IS_TRANSIENT,
				IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				IS_DERIVED,
				IS_ORDERED);

		initEClass(
				enumeratedDataEClass,
				EnumeratedData.class,
				"EnumeratedData",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(
				getEnumeratedData_Enumerator(),
				this.getEnumerator(),
				null,
				"enumerator",
				null,
				1,
				-1,
				EnumeratedData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getEnumeratedData_Name(),
				theXMLTypePackage.getID(),
				"name",
				null,
				1,
				1,
				EnumeratedData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getEnumeratedData_NameNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"nameNotes",
				null,
				0,
				1,
				EnumeratedData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getEnumeratedData_Representation(),
				theXMLTypePackage.getNMTOKEN(),
				"representation",
				null,
				0,
				1,
				EnumeratedData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getEnumeratedData_RepresentationNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"representationNotes",
				null,
				0,
				1,
				EnumeratedData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getEnumeratedData_Semantics(),
				theXMLTypePackage.getAnySimpleType(),
				"semantics",
				null,
				0,
				1,
				EnumeratedData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getEnumeratedData_SemanticsNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"semanticsNotes",
				null,
				0,
				1,
				EnumeratedData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				enumeratedDataTypesEClass,
				EnumeratedDataTypes.class,
				"EnumeratedDataTypes",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(
				getEnumeratedDataTypes_EnumeratedData(),
				this.getEnumeratedData(),
				null,
				"enumeratedData",
				null,
				1,
				-1,
				EnumeratedDataTypes.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				enumeratorEClass,
				Enumerator.class,
				"Enumerator",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(
				getEnumerator_Name(),
				theXMLTypePackage.getID(),
				"name",
				null,
				1,
				1,
				Enumerator.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getEnumerator_NameNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"nameNotes",
				null,
				0,
				1,
				Enumerator.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getEnumerator_Values(),
				theXMLTypePackage.getNMTOKENS(),
				"values",
				null,
				0,
				1,
				Enumerator.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getEnumerator_ValuesNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"valuesNotes",
				null,
				0,
				1,
				Enumerator.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(fieldEClass, Field.class, "Field", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(
				getField_DataType(),
				theXMLTypePackage.getIDREF(),
				"dataType",
				null,
				0,
				1,
				Field.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getField_DataTypeNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"dataTypeNotes",
				null,
				0,
				1,
				Field.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getField_Name(),
				theXMLTypePackage.getNMTOKEN(),
				"name",
				null,
				1,
				1,
				Field.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getField_NameNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"nameNotes",
				null,
				0,
				1,
				Field.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getField_Semantics(),
				theXMLTypePackage.getAnySimpleType(),
				"semantics",
				null,
				0,
				1,
				Field.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getField_SemanticsNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"semanticsNotes",
				null,
				0,
				1,
				Field.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				fixedRecordDataEClass,
				FixedRecordData.class,
				"FixedRecordData",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(
				getFixedRecordData_Field(),
				this.getField(),
				null,
				"field",
				null,
				1,
				-1,
				FixedRecordData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getFixedRecordData_Encoding(),
				theXMLTypePackage.getAnySimpleType(),
				"encoding",
				null,
				0,
				1,
				FixedRecordData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getFixedRecordData_EncodingNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"encodingNotes",
				null,
				0,
				1,
				FixedRecordData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getFixedRecordData_Name(),
				theXMLTypePackage.getNMTOKEN(),
				"name",
				null,
				1,
				1,
				FixedRecordData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getFixedRecordData_NameNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"nameNotes",
				null,
				0,
				1,
				FixedRecordData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getFixedRecordData_Semantics(),
				theXMLTypePackage.getAnySimpleType(),
				"semantics",
				null,
				0,
				1,
				FixedRecordData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getFixedRecordData_SemanticsNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"semanticsNotes",
				null,
				0,
				1,
				FixedRecordData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				fixedRecordDataTypesEClass,
				FixedRecordDataTypes.class,
				"FixedRecordDataTypes",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(
				getFixedRecordDataTypes_FixedRecordData(),
				this.getFixedRecordData(),
				null,
				"fixedRecordData",
				null,
				1,
				-1,
				FixedRecordDataTypes.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				interactionClassEClass,
				InteractionClass.class,
				"InteractionClass",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(
				getInteractionClass_Parameters(),
				this.getParameter(),
				null,
				"parameters",
				null,
				0,
				-1,
				InteractionClass.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getInteractionClass_SubClasses(),
				this.getInteractionClass(),
				null,
				"subClasses",
				null,
				0,
				-1,
				InteractionClass.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getInteractionClass_Dimensions(),
				theXMLTypePackage.getNMTOKENS(),
				"dimensions",
				null,
				0,
				1,
				InteractionClass.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getInteractionClass_DimensionsNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"dimensionsNotes",
				null,
				0,
				1,
				InteractionClass.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getInteractionClass_Name(),
				theXMLTypePackage.getNMTOKEN(),
				"name",
				null,
				1,
				1,
				InteractionClass.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getInteractionClass_NameNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"nameNotes",
				null,
				0,
				1,
				InteractionClass.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getInteractionClass_Order(),
				this.getOrderEnum(),
				"order",
				"Receive",
				0,
				1,
				InteractionClass.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getInteractionClass_OrderNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"orderNotes",
				null,
				0,
				1,
				InteractionClass.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getInteractionClass_Semantics(),
				theXMLTypePackage.getAnySimpleType(),
				"semantics",
				null,
				0,
				1,
				InteractionClass.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getInteractionClass_SemanticsNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"semanticsNotes",
				null,
				0,
				1,
				InteractionClass.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getInteractionClass_Sharing(),
				this.getSharingEnum(),
				"sharing",
				"Publish",
				0,
				1,
				InteractionClass.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getInteractionClass_SharingNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"sharingNotes",
				null,
				0,
				1,
				InteractionClass.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getInteractionClass_Transportation(),
				theXMLTypePackage.getNMTOKEN(),
				"transportation",
				null,
				0,
				1,
				InteractionClass.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getInteractionClass_TransportationNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"transportationNotes",
				null,
				0,
				1,
				InteractionClass.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getInteractionClass_SubscribingFederates(),
				theDataPackage.getFederate(),
				theDataPackage.getFederate_SubscribedInteractions(),
				"subscribingFederates",
				null,
				0,
				-1,
				InteractionClass.class,
				IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_COMPOSITE,
				IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getInteractionClass_PublishingFederates(),
				theDataPackage.getFederate(),
				theDataPackage.getFederate_PublishedInteractions(),
				"publishingFederates",
				null,
				0,
				-1,
				InteractionClass.class,
				IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_COMPOSITE,
				IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				interactionsEClass,
				Interactions.class,
				"Interactions",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(
				getInteractions_InteractionClass(),
				this.getInteractionClass(),
				null,
				"interactionClass",
				null,
				1,
				-1,
				Interactions.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				lookaheadEClass,
				Lookahead.class,
				"Lookahead",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(
				getLookahead_DataType(),
				theXMLTypePackage.getNMTOKEN(),
				"dataType",
				null,
				0,
				1,
				Lookahead.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getLookahead_DataTypeNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"dataTypeNotes",
				null,
				0,
				1,
				Lookahead.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getLookahead_Semantics(),
				theXMLTypePackage.getAnySimpleType(),
				"semantics",
				null,
				0,
				1,
				Lookahead.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getLookahead_SemanticsNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"semanticsNotes",
				null,
				0,
				1,
				Lookahead.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(noteEClass, Note.class, "Note", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(
				getNote_Name(),
				theXMLTypePackage.getNMTOKEN(),
				"name",
				null,
				1,
				1,
				Note.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getNote_Semantics(),
				theXMLTypePackage.getAnySimpleType(),
				"semantics",
				null,
				0,
				1,
				Note.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getNote_SemanticsNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"semanticsNotes",
				null,
				0,
				1,
				Note.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(notesEClass, Notes.class, "Notes", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(
				getNotes_Note(),
				this.getNote(),
				null,
				"note",
				null,
				1,
				-1,
				Notes.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				objectClassEClass,
				ObjectClass.class,
				"ObjectClass",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(
				getObjectClass_Attributes(),
				this.getAttribute(),
				null,
				"attributes",
				null,
				0,
				-1,
				ObjectClass.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getObjectClass_SubClasses(),
				this.getObjectClass(),
				null,
				"subClasses",
				null,
				0,
				-1,
				ObjectClass.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectClass_Name(),
				theXMLTypePackage.getNMTOKEN(),
				"name",
				null,
				1,
				1,
				ObjectClass.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectClass_NameNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"nameNotes",
				null,
				0,
				1,
				ObjectClass.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectClass_Semantics(),
				theXMLTypePackage.getAnySimpleType(),
				"semantics",
				null,
				0,
				1,
				ObjectClass.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectClass_SemanticsNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"semanticsNotes",
				null,
				0,
				1,
				ObjectClass.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectClass_Sharing(),
				this.getSharingEnum(),
				"sharing",
				"Publish",
				0,
				1,
				ObjectClass.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectClass_SharingNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"sharingNotes",
				null,
				0,
				1,
				ObjectClass.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				objectModelEClass,
				ObjectModel.class,
				"ObjectModel",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(
				getObjectModel_Objects(),
				this.getObjects(),
				null,
				"objects",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getObjectModel_Interactions(),
				this.getInteractions(),
				null,
				"interactions",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getObjectModel_Dimensions(),
				this.getDimensions(),
				null,
				"dimensions",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getObjectModel_Time(),
				this.getTime(),
				null,
				"time",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getObjectModel_Tags(),
				this.getTags(),
				null,
				"tags",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getObjectModel_Synchronizations(),
				this.getSynchronizations(),
				null,
				"synchronizations",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getObjectModel_Transportations(),
				this.getTransportations(),
				null,
				"transportations",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getObjectModel_Switches(),
				this.getSwitches(),
				null,
				"switches",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getObjectModel_DataTypes(),
				this.getDataTypes(),
				null,
				"dataTypes",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getObjectModel_Notes(),
				this.getNotes(),
				null,
				"notes",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectModel_AppDomain(),
				theXMLTypePackage.getAnySimpleType(),
				"appDomain",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectModel_AppDomainNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"appDomainNotes",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectModel_Date(),
				theXMLTypePackage.getAnySimpleType(),
				"date",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectModel_DateNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"dateNotes",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectModel_DTDversion(),
				this.getDTDVersionEnum(),
				"dTDversion",
				"1516.2",
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectModel_Name(),
				theXMLTypePackage.getAnySimpleType(),
				"name",
				null,
				1,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectModel_NameNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"nameNotes",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectModel_Other(),
				theXMLTypePackage.getAnySimpleType(),
				"other",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectModel_OtherNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"otherNotes",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectModel_PocEmail(),
				theXMLTypePackage.getAnySimpleType(),
				"pocEmail",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectModel_PocEmailNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"pocEmailNotes",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectModel_PocName(),
				theXMLTypePackage.getAnySimpleType(),
				"pocName",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectModel_PocNameNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"pocNameNotes",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectModel_PocOrg(),
				theXMLTypePackage.getAnySimpleType(),
				"pocOrg",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectModel_PocOrgNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"pocOrgNotes",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectModel_PocPhone(),
				theXMLTypePackage.getAnySimpleType(),
				"pocPhone",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectModel_PocPhoneNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"pocPhoneNotes",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectModel_Purpose(),
				theXMLTypePackage.getAnySimpleType(),
				"purpose",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectModel_PurposeNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"purposeNotes",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectModel_References(),
				theXMLTypePackage.getAnySimpleType(),
				"references",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectModel_ReferencesNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"referencesNotes",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectModel_Sponsor(),
				theXMLTypePackage.getAnySimpleType(),
				"sponsor",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectModel_SponsorNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"sponsorNotes",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectModel_Type(),
				this.getObjectModelTypeEnum(),
				"type",
				"FOM",
				1,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectModel_TypeNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"typeNotes",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectModel_Version(),
				theXMLTypePackage.getAnySimpleType(),
				"version",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectModel_VersionNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"versionNotes",
				null,
				0,
				1,
				ObjectModel.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(objectsEClass, Objects.class, "Objects", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(
				getObjects_ObjectClass(),
				this.getObjectClass(),
				null,
				"objectClass",
				null,
				1,
				-1,
				Objects.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				parameterEClass,
				Parameter.class,
				"Parameter",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(
				getParameter_DataType(),
				theXMLTypePackage.getNMTOKEN(),
				"dataType",
				null,
				0,
				1,
				Parameter.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getParameter_DataTypeNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"dataTypeNotes",
				null,
				0,
				1,
				Parameter.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getParameter_Name(),
				theXMLTypePackage.getNMTOKEN(),
				"name",
				null,
				1,
				1,
				Parameter.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getParameter_NameNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"nameNotes",
				null,
				0,
				1,
				Parameter.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getParameter_Semantics(),
				theXMLTypePackage.getAnySimpleType(),
				"semantics",
				null,
				0,
				1,
				Parameter.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getParameter_SemanticsNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"semanticsNotes",
				null,
				0,
				1,
				Parameter.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				requestUpdateTagEClass,
				RequestUpdateTag.class,
				"RequestUpdateTag",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(
				getRequestUpdateTag_DataType(),
				theXMLTypePackage.getNMTOKEN(),
				"dataType",
				null,
				1,
				1,
				RequestUpdateTag.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getRequestUpdateTag_DataTypeNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"dataTypeNotes",
				null,
				0,
				1,
				RequestUpdateTag.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getRequestUpdateTag_Semantics(),
				theXMLTypePackage.getAnySimpleType(),
				"semantics",
				null,
				0,
				1,
				RequestUpdateTag.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getRequestUpdateTag_SemanticsNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"semanticsNotes",
				null,
				0,
				1,
				RequestUpdateTag.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				sendReceiveTagEClass,
				SendReceiveTag.class,
				"SendReceiveTag",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(
				getSendReceiveTag_DataType(),
				theXMLTypePackage.getNMTOKEN(),
				"dataType",
				null,
				1,
				1,
				SendReceiveTag.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSendReceiveTag_DataTypeNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"dataTypeNotes",
				null,
				0,
				1,
				SendReceiveTag.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSendReceiveTag_Semantics(),
				theXMLTypePackage.getAnySimpleType(),
				"semantics",
				null,
				0,
				1,
				SendReceiveTag.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSendReceiveTag_SemanticsNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"semanticsNotes",
				null,
				0,
				1,
				SendReceiveTag.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				simpleDataEClass,
				SimpleData.class,
				"SimpleData",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(
				getSimpleData_Accuracy(),
				theXMLTypePackage.getAnySimpleType(),
				"accuracy",
				null,
				0,
				1,
				SimpleData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSimpleData_AccuracyNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"accuracyNotes",
				null,
				0,
				1,
				SimpleData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSimpleData_Name(),
				theXMLTypePackage.getID(),
				"name",
				null,
				1,
				1,
				SimpleData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSimpleData_NameNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"nameNotes",
				null,
				0,
				1,
				SimpleData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSimpleData_Representation(),
				theXMLTypePackage.getNMTOKEN(),
				"representation",
				null,
				0,
				1,
				SimpleData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSimpleData_RepresentationNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"representationNotes",
				null,
				0,
				1,
				SimpleData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSimpleData_Resolution(),
				theXMLTypePackage.getAnySimpleType(),
				"resolution",
				null,
				0,
				1,
				SimpleData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSimpleData_ResolutionNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"resolutionNotes",
				null,
				0,
				1,
				SimpleData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSimpleData_Semantics(),
				theXMLTypePackage.getAnySimpleType(),
				"semantics",
				null,
				0,
				1,
				SimpleData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSimpleData_SemanticsNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"semanticsNotes",
				null,
				0,
				1,
				SimpleData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSimpleData_Units(),
				theXMLTypePackage.getAnySimpleType(),
				"units",
				null,
				0,
				1,
				SimpleData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSimpleData_UnitsNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"unitsNotes",
				null,
				0,
				1,
				SimpleData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				simpleDataTypesEClass,
				SimpleDataTypes.class,
				"SimpleDataTypes",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(
				getSimpleDataTypes_SimpleData(),
				this.getSimpleData(),
				null,
				"simpleData",
				null,
				1,
				-1,
				SimpleDataTypes.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(switchesEClass, Switches.class, "Switches", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(
				getSwitches_AttributeRelevanceAdvisory(),
				this.getStateEnum(),
				"attributeRelevanceAdvisory",
				"Enabled",
				0,
				1,
				Switches.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSwitches_AttributeRelevanceAdvisoryNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"attributeRelevanceAdvisoryNotes",
				null,
				0,
				1,
				Switches.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSwitches_AttributeScopeAdvisory(),
				this.getStateEnum(),
				"attributeScopeAdvisory",
				"Enabled",
				0,
				1,
				Switches.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSwitches_AttributeScopeAdvisoryNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"attributeScopeAdvisoryNotes",
				null,
				0,
				1,
				Switches.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSwitches_AutoProvide(),
				this.getStateEnum(),
				"autoProvide",
				"Enabled",
				0,
				1,
				Switches.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSwitches_AutoProvideNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"autoProvideNotes",
				null,
				0,
				1,
				Switches.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSwitches_ConveyRegionDesignatorSets(),
				this.getStateEnum(),
				"conveyRegionDesignatorSets",
				"Enabled",
				0,
				1,
				Switches.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSwitches_ConveyRegionDesignatorSetsNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"conveyRegionDesignatorSetsNotes",
				null,
				0,
				1,
				Switches.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSwitches_InteractionRelevanceAdvisory(),
				this.getStateEnum(),
				"interactionRelevanceAdvisory",
				"Enabled",
				0,
				1,
				Switches.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSwitches_InteractionRelevanceAdvisoryNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"interactionRelevanceAdvisoryNotes",
				null,
				0,
				1,
				Switches.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSwitches_ObjectClassRelevanceAdvisory(),
				this.getStateEnum(),
				"objectClassRelevanceAdvisory",
				"Enabled",
				0,
				1,
				Switches.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSwitches_ObjectClassRelevanceAdvisoryNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"objectClassRelevanceAdvisoryNotes",
				null,
				0,
				1,
				Switches.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSwitches_ServiceReporting(),
				this.getStateEnum(),
				"serviceReporting",
				"Enabled",
				0,
				1,
				Switches.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSwitches_ServiceReportingNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"serviceReportingNotes",
				null,
				0,
				1,
				Switches.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				synchronizationEClass,
				Synchronization.class,
				"Synchronization",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(
				getSynchronization_Capability(),
				this.getSyncCapabilityEnum(),
				"capability",
				"Register",
				0,
				1,
				Synchronization.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSynchronization_CapabilityNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"capabilityNotes",
				null,
				0,
				1,
				Synchronization.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSynchronization_DataType(),
				theXMLTypePackage.getNMTOKEN(),
				"dataType",
				null,
				0,
				1,
				Synchronization.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSynchronization_DataTypeNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"dataTypeNotes",
				null,
				0,
				1,
				Synchronization.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSynchronization_Label(),
				theXMLTypePackage.getNMTOKEN(),
				"label",
				null,
				1,
				1,
				Synchronization.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSynchronization_LabelNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"labelNotes",
				null,
				0,
				1,
				Synchronization.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSynchronization_Semantics(),
				theXMLTypePackage.getAnySimpleType(),
				"semantics",
				null,
				0,
				1,
				Synchronization.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getSynchronization_SemanticsNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"semanticsNotes",
				null,
				0,
				1,
				Synchronization.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				synchronizationsEClass,
				Synchronizations.class,
				"Synchronizations",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(
				getSynchronizations_Synchronization(),
				this.getSynchronization(),
				null,
				"synchronization",
				null,
				1,
				-1,
				Synchronizations.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(tagsEClass, Tags.class, "Tags", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(
				getTags_UpdateReflectTag(),
				this.getUpdateReflectTag(),
				null,
				"updateReflectTag",
				null,
				0,
				1,
				Tags.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getTags_SendReceiveTag(),
				this.getSendReceiveTag(),
				null,
				"sendReceiveTag",
				null,
				0,
				1,
				Tags.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getTags_DeleteRemoveTag(),
				this.getDeleteRemoveTag(),
				null,
				"deleteRemoveTag",
				null,
				0,
				1,
				Tags.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getTags_DivestitureRequestTag(),
				this.getDivestitureRequestTag(),
				null,
				"divestitureRequestTag",
				null,
				0,
				1,
				Tags.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getTags_DivestitureCompletionTag(),
				this.getDivestitureCompletionTag(),
				null,
				"divestitureCompletionTag",
				null,
				0,
				1,
				Tags.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getTags_AcquisitionRequestTag(),
				this.getAcquisitionRequestTag(),
				null,
				"acquisitionRequestTag",
				null,
				0,
				1,
				Tags.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getTags_RequestUpdateTag(),
				this.getRequestUpdateTag(),
				null,
				"requestUpdateTag",
				null,
				0,
				1,
				Tags.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(timeEClass, Time.class, "Time", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(
				getTime_TimeStamp(),
				this.getTimeStamp(),
				null,
				"timeStamp",
				null,
				0,
				1,
				Time.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getTime_Lookahead(),
				this.getLookahead(),
				null,
				"lookahead",
				null,
				0,
				1,
				Time.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				timeStampEClass,
				TimeStamp.class,
				"TimeStamp",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(
				getTimeStamp_DataType(),
				theXMLTypePackage.getNMTOKEN(),
				"dataType",
				null,
				0,
				1,
				TimeStamp.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getTimeStamp_DataTypeNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"dataTypeNotes",
				null,
				0,
				1,
				TimeStamp.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getTimeStamp_Semantics(),
				theXMLTypePackage.getAnySimpleType(),
				"semantics",
				null,
				0,
				1,
				TimeStamp.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getTimeStamp_SemanticsNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"semanticsNotes",
				null,
				0,
				1,
				TimeStamp.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				transportationEClass,
				Transportation.class,
				"Transportation",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(
				getTransportation_Description(),
				theXMLTypePackage.getAnySimpleType(),
				"description",
				null,
				0,
				1,
				Transportation.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getTransportation_DescriptionNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"descriptionNotes",
				null,
				0,
				1,
				Transportation.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getTransportation_Name(),
				theXMLTypePackage.getNMTOKEN(),
				"name",
				null,
				1,
				1,
				Transportation.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getTransportation_NameNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"nameNotes",
				null,
				0,
				1,
				Transportation.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				transportationsEClass,
				Transportations.class,
				"Transportations",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(
				getTransportations_Transportation(),
				this.getTransportation(),
				null,
				"transportation",
				null,
				1,
				-1,
				Transportations.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				updateReflectTagEClass,
				UpdateReflectTag.class,
				"UpdateReflectTag",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(
				getUpdateReflectTag_DataType(),
				theXMLTypePackage.getNMTOKEN(),
				"dataType",
				null,
				1,
				1,
				UpdateReflectTag.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getUpdateReflectTag_DataTypeNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"dataTypeNotes",
				null,
				0,
				1,
				UpdateReflectTag.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getUpdateReflectTag_Semantics(),
				theXMLTypePackage.getAnySimpleType(),
				"semantics",
				null,
				0,
				1,
				UpdateReflectTag.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getUpdateReflectTag_SemanticsNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"semanticsNotes",
				null,
				0,
				1,
				UpdateReflectTag.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				variantRecordDataEClass,
				VariantRecordData.class,
				"VariantRecordData",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(
				getVariantRecordData_Alternative(),
				this.getAlternative(),
				null,
				"alternative",
				null,
				1,
				-1,
				VariantRecordData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getVariantRecordData_DataType(),
				theXMLTypePackage.getNMTOKEN(),
				"dataType",
				null,
				0,
				1,
				VariantRecordData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getVariantRecordData_DataTypeNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"dataTypeNotes",
				null,
				0,
				1,
				VariantRecordData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getVariantRecordData_Discriminant(),
				theXMLTypePackage.getAnySimpleType(),
				"discriminant",
				null,
				0,
				1,
				VariantRecordData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getVariantRecordData_DiscriminantNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"discriminantNotes",
				null,
				0,
				1,
				VariantRecordData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getVariantRecordData_Encoding(),
				theXMLTypePackage.getAnySimpleType(),
				"encoding",
				null,
				0,
				1,
				VariantRecordData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getVariantRecordData_EncodingNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"encodingNotes",
				null,
				0,
				1,
				VariantRecordData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getVariantRecordData_Name(),
				theXMLTypePackage.getNMTOKEN(),
				"name",
				null,
				1,
				1,
				VariantRecordData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getVariantRecordData_NameNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"nameNotes",
				null,
				0,
				1,
				VariantRecordData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getVariantRecordData_Semantics(),
				theXMLTypePackage.getAnySimpleType(),
				"semantics",
				null,
				0,
				1,
				VariantRecordData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getVariantRecordData_SemanticsNotes(),
				theXMLTypePackage.getNMTOKENS(),
				"semanticsNotes",
				null,
				0,
				1,
				VariantRecordData.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				!IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		initEClass(
				variantRecordDataTypesEClass,
				VariantRecordDataTypes.class,
				"VariantRecordDataTypes",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(
				getVariantRecordDataTypes_VariantRecordData(),
				this.getVariantRecordData(),
				null,
				"variantRecordData",
				null,
				1,
				-1,
				VariantRecordDataTypes.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(dtdVersionEnumEEnum, DTDVersionEnum.class, "DTDVersionEnum");
		addEEnumLiteral(dtdVersionEnumEEnum, DTDVersionEnum._15162_LITERAL);

		initEEnum(endianEnumEEnum, EndianEnum.class, "EndianEnum");
		addEEnumLiteral(endianEnumEEnum, EndianEnum.BIG_LITERAL);
		addEEnumLiteral(endianEnumEEnum, EndianEnum.LITTLE_LITERAL);

		initEEnum(objectModelTypeEnumEEnum, ObjectModelTypeEnum.class, "ObjectModelTypeEnum");
		addEEnumLiteral(objectModelTypeEnumEEnum, ObjectModelTypeEnum.FOM_LITERAL);
		addEEnumLiteral(objectModelTypeEnumEEnum, ObjectModelTypeEnum.SOM_LITERAL);

		initEEnum(orderEnumEEnum, OrderEnum.class, "OrderEnum");
		addEEnumLiteral(orderEnumEEnum, OrderEnum.RECEIVE_LITERAL);
		addEEnumLiteral(orderEnumEEnum, OrderEnum.TIME_STAMP_LITERAL);

		initEEnum(ownershipEnumEEnum, OwnershipEnum.class, "OwnershipEnum");
		addEEnumLiteral(ownershipEnumEEnum, OwnershipEnum.DIVEST_LITERAL);
		addEEnumLiteral(ownershipEnumEEnum, OwnershipEnum.ACQUIRE_LITERAL);
		addEEnumLiteral(ownershipEnumEEnum, OwnershipEnum.DIVEST_ACQUIRE_LITERAL);
		addEEnumLiteral(ownershipEnumEEnum, OwnershipEnum.NO_TRANSFER_LITERAL);

		initEEnum(sharingEnumEEnum, SharingEnum.class, "SharingEnum");
		addEEnumLiteral(sharingEnumEEnum, SharingEnum.PUBLISH_LITERAL);
		addEEnumLiteral(sharingEnumEEnum, SharingEnum.SUBSCRIBE_LITERAL);
		addEEnumLiteral(sharingEnumEEnum, SharingEnum.PUBLISH_SUBSCRIBE_LITERAL);
		addEEnumLiteral(sharingEnumEEnum, SharingEnum.NEITHER_LITERAL);

		initEEnum(stateEnumEEnum, StateEnum.class, "StateEnum");
		addEEnumLiteral(stateEnumEEnum, StateEnum.ENABLED_LITERAL);
		addEEnumLiteral(stateEnumEEnum, StateEnum.DISABLED_LITERAL);

		initEEnum(syncCapabilityEnumEEnum, SyncCapabilityEnum.class, "SyncCapabilityEnum");
		addEEnumLiteral(syncCapabilityEnumEEnum, SyncCapabilityEnum.REGISTER_LITERAL);
		addEEnumLiteral(syncCapabilityEnumEEnum, SyncCapabilityEnum.ACHIEVE_LITERAL);
		addEEnumLiteral(syncCapabilityEnumEEnum, SyncCapabilityEnum.REGISTER_ACHIEVE_LITERAL);
		addEEnumLiteral(syncCapabilityEnumEEnum, SyncCapabilityEnum.NO_SYNCH_LITERAL);

		initEEnum(updateTypeEnumEEnum, UpdateTypeEnum.class, "UpdateTypeEnum");
		addEEnumLiteral(updateTypeEnumEEnum, UpdateTypeEnum.STATIC_LITERAL);
		addEEnumLiteral(updateTypeEnumEEnum, UpdateTypeEnum.PERIODIC_LITERAL);
		addEEnumLiteral(updateTypeEnumEEnum, UpdateTypeEnum.CONDITIONAL_LITERAL);
		addEEnumLiteral(updateTypeEnumEEnum, UpdateTypeEnum.NA_LITERAL);

		// Initialize data types
		initEDataType(
				dtdVersionEnumObjectEDataType,
				DTDVersionEnum.class,
				"DTDVersionEnumObject",
				IS_SERIALIZABLE,
				IS_GENERATED_INSTANCE_CLASS);
		initEDataType(
				endianEnumObjectEDataType,
				EndianEnum.class,
				"EndianEnumObject",
				IS_SERIALIZABLE,
				IS_GENERATED_INSTANCE_CLASS);
		initEDataType(
				objectModelTypeEnumObjectEDataType,
				ObjectModelTypeEnum.class,
				"ObjectModelTypeEnumObject",
				IS_SERIALIZABLE,
				IS_GENERATED_INSTANCE_CLASS);
		initEDataType(
				orderEnumObjectEDataType,
				OrderEnum.class,
				"OrderEnumObject",
				IS_SERIALIZABLE,
				IS_GENERATED_INSTANCE_CLASS);
		initEDataType(
				ownershipEnumObjectEDataType,
				OwnershipEnum.class,
				"OwnershipEnumObject",
				IS_SERIALIZABLE,
				IS_GENERATED_INSTANCE_CLASS);
		initEDataType(
				sharingEnumObjectEDataType,
				SharingEnum.class,
				"SharingEnumObject",
				IS_SERIALIZABLE,
				IS_GENERATED_INSTANCE_CLASS);
		initEDataType(
				stateEnumObjectEDataType,
				StateEnum.class,
				"StateEnumObject",
				IS_SERIALIZABLE,
				IS_GENERATED_INSTANCE_CLASS);
		initEDataType(
				syncCapabilityEnumObjectEDataType,
				SyncCapabilityEnum.class,
				"SyncCapabilityEnumObject",
				IS_SERIALIZABLE,
				IS_GENERATED_INSTANCE_CLASS);
		initEDataType(
				updateTypeEnumObjectEDataType,
				UpdateTypeEnum.class,
				"UpdateTypeEnumObject",
				IS_SERIALIZABLE,
				IS_GENERATED_INSTANCE_CLASS);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http:///org/eclipse/emf/ecore/util/ExtendedMetaData
		createExtendedMetaDataAnnotations();
	}

	/**
	 * Initializes the annotations for
	 * <b>http:///org/eclipse/emf/ecore/util/ExtendedMetaData</b>. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected void createExtendedMetaDataAnnotations() {
		String source = "http:///org/eclipse/emf/ecore/util/ExtendedMetaData";
		addAnnotation(this, source, new String[] { "qualified", "false" });
		addAnnotation(acquisitionRequestTagEClass, source, new String[] { "name", "AcquisitionRequestTag", "kind",
				"empty" });
		addAnnotation(getAcquisitionRequestTag_DataType(), source, new String[] { "kind", "attribute", "name",
				"dataType", "namespace", "##targetNamespace" });
		addAnnotation(getAcquisitionRequestTag_DataTypeNotes(), source, new String[] { "kind", "attribute", "name",
				"dataTypeNotes", "namespace", "##targetNamespace" });
		addAnnotation(getAcquisitionRequestTag_Semantics(), source, new String[] { "kind", "attribute", "name",
				"semantics", "namespace", "##targetNamespace" });
		addAnnotation(getAcquisitionRequestTag_SemanticsNotes(), source, new String[] { "kind", "attribute", "name",
				"semanticsNotes", "namespace", "##targetNamespace" });
		addAnnotation(alternativeEClass, source, new String[] { "name", "Alternative", "kind", "empty" });
		addAnnotation(getAlternative_DataType(), source, new String[] { "kind", "attribute", "name", "dataType",
				"namespace", "##targetNamespace" });
		addAnnotation(getAlternative_DataTypeNotes(), source, new String[] { "kind", "attribute", "name",
				"dataTypeNotes", "namespace", "##targetNamespace" });
		addAnnotation(getAlternative_Enumerator(), source, new String[] { "kind", "attribute", "name", "enumerator",
				"namespace", "##targetNamespace" });
		addAnnotation(getAlternative_EnumeratorNotes(), source, new String[] { "kind", "attribute", "name",
				"enumeratorNotes", "namespace", "##targetNamespace" });
		addAnnotation(getAlternative_Name(), source, new String[] { "kind", "attribute", "name", "name", "namespace",
				"##targetNamespace" });
		addAnnotation(getAlternative_NameNotes(), source, new String[] { "kind", "attribute", "name", "nameNotes",
				"namespace", "##targetNamespace" });
		addAnnotation(getAlternative_Semantics(), source, new String[] { "kind", "attribute", "name", "semantics",
				"namespace", "##targetNamespace" });
		addAnnotation(getAlternative_SemanticsNotes(), source, new String[] { "kind", "attribute", "name",
				"semanticsNotes", "namespace", "##targetNamespace" });
		addAnnotation(arrayDataEClass, source, new String[] { "name", "ArrayData", "kind", "empty" });
		addAnnotation(getArrayData_Cardinality(), source, new String[] { "kind", "attribute", "name", "cardinality",
				"namespace", "##targetNamespace" });
		addAnnotation(getArrayData_CardinalityNotes(), source, new String[] { "kind", "attribute", "name",
				"cardinalityNotes", "namespace", "##targetNamespace" });
		addAnnotation(getArrayData_DataType(), source, new String[] { "kind", "attribute", "name", "dataType",
				"namespace", "##targetNamespace" });
		addAnnotation(getArrayData_DataTypeNotes(), source, new String[] { "kind", "attribute", "name",
				"dataTypeNotes", "namespace", "##targetNamespace" });
		addAnnotation(getArrayData_Encoding(), source, new String[] { "kind", "attribute", "name", "encoding",
				"namespace", "##targetNamespace" });
		addAnnotation(getArrayData_EncodingNotes(), source, new String[] { "kind", "attribute", "name",
				"encodingNotes", "namespace", "##targetNamespace" });
		addAnnotation(getArrayData_Name(), source, new String[] { "kind", "attribute", "name", "name", "namespace",
				"##targetNamespace" });
		addAnnotation(getArrayData_NameNotes(), source, new String[] { "kind", "attribute", "name", "nameNotes",
				"namespace", "##targetNamespace" });
		addAnnotation(getArrayData_Semantics(), source, new String[] { "kind", "attribute", "name", "semantics",
				"namespace", "##targetNamespace" });
		addAnnotation(getArrayData_SemanticsNotes(), source, new String[] { "kind", "attribute", "name",
				"semanticsNotes", "namespace", "##targetNamespace" });
		addAnnotation(arrayDataTypesEClass, source, new String[] { "name", "ArrayDataTypes", "kind", "elementOnly" });
		addAnnotation(getArrayDataTypes_ArrayData(), source, new String[] { "kind", "element", "name", "arrayData",
				"namespace", "##targetNamespace" });
		addAnnotation(attributeEClass, source, new String[] { "name", "Attribute", "kind", "empty" });
		addAnnotation(getAttribute_DataType(), source, new String[] { "kind", "attribute", "name", "dataType",
				"namespace", "##targetNamespace" });
		addAnnotation(getAttribute_DataTypeNotes(), source, new String[] { "kind", "attribute", "name",
				"dataTypeNotes", "namespace", "##targetNamespace" });
		addAnnotation(getAttribute_Dimensions(), source, new String[] { "kind", "attribute", "name", "dimensions",
				"namespace", "##targetNamespace" });
		addAnnotation(getAttribute_DimensionsNotes(), source, new String[] { "kind", "attribute", "name",
				"dimensionsNotes", "namespace", "##targetNamespace" });
		addAnnotation(getAttribute_Name(), source, new String[] { "kind", "attribute", "name", "name", "namespace",
				"##targetNamespace" });
		addAnnotation(getAttribute_NameNotes(), source, new String[] { "kind", "attribute", "name", "nameNotes",
				"namespace", "##targetNamespace" });
		addAnnotation(getAttribute_Order(), source, new String[] { "kind", "attribute", "name", "order", "namespace",
				"##targetNamespace" });
		addAnnotation(getAttribute_OrderNotes(), source, new String[] { "kind", "attribute", "name", "orderNotes",
				"namespace", "##targetNamespace" });
		addAnnotation(getAttribute_Ownership(), source, new String[] { "kind", "attribute", "name", "ownership",
				"namespace", "##targetNamespace" });
		addAnnotation(getAttribute_OwnershipNotes(), source, new String[] { "kind", "attribute", "name",
				"ownershipNotes", "namespace", "##targetNamespace" });
		addAnnotation(getAttribute_Semantics(), source, new String[] { "kind", "attribute", "name", "semantics",
				"namespace", "##targetNamespace" });
		addAnnotation(getAttribute_SemanticsNotes(), source, new String[] { "kind", "attribute", "name",
				"semanticsNotes", "namespace", "##targetNamespace" });
		addAnnotation(getAttribute_Sharing(), source, new String[] { "kind", "attribute", "name", "sharing",
				"namespace", "##targetNamespace" });
		addAnnotation(getAttribute_SharingNotes(), source, new String[] { "kind", "attribute", "name", "sharingNotes",
				"namespace", "##targetNamespace" });
		addAnnotation(getAttribute_Transportation(), source, new String[] { "kind", "attribute", "name",
				"transportation", "namespace", "##targetNamespace" });
		addAnnotation(getAttribute_TransportationNotes(), source, new String[] { "kind", "attribute", "name",
				"transportationNotes", "namespace", "##targetNamespace" });
		addAnnotation(getAttribute_UpdateCondition(), source, new String[] { "kind", "attribute", "name",
				"updateCondition", "namespace", "##targetNamespace" });
		addAnnotation(getAttribute_UpdateConditionNotes(), source, new String[] { "kind", "attribute", "name",
				"updateConditionNotes", "namespace", "##targetNamespace" });
		addAnnotation(getAttribute_UpdateType(), source, new String[] { "kind", "attribute", "name", "updateType",
				"namespace", "##targetNamespace" });
		addAnnotation(getAttribute_UpdateTypeNotes(), source, new String[] { "kind", "attribute", "name",
				"updateTypeNotes", "namespace", "##targetNamespace" });
		addAnnotation(basicDataEClass, source, new String[] { "name", "BasicData", "kind", "empty" });
		addAnnotation(getBasicData_Encoding(), source, new String[] { "kind", "attribute", "name", "encoding",
				"namespace", "##targetNamespace" });
		addAnnotation(getBasicData_EncodingNotes(), source, new String[] { "kind", "attribute", "name",
				"encodingNotes", "namespace", "##targetNamespace" });
		addAnnotation(getBasicData_Endian(), source, new String[] { "kind", "attribute", "name", "endian", "namespace",
				"##targetNamespace" });
		addAnnotation(getBasicData_EndianNotes(), source, new String[] { "kind", "attribute", "name", "endianNotes",
				"namespace", "##targetNamespace" });
		addAnnotation(getBasicData_Interpretation(), source, new String[] { "kind", "attribute", "name",
				"interpretation", "namespace", "##targetNamespace" });
		addAnnotation(getBasicData_InterpretationNotes(), source, new String[] { "kind", "attribute", "name",
				"interpretationNotes", "namespace", "##targetNamespace" });
		addAnnotation(getBasicData_Name(), source, new String[] { "kind", "attribute", "name", "name", "namespace",
				"##targetNamespace" });
		addAnnotation(getBasicData_NameNotes(), source, new String[] { "kind", "attribute", "name", "nameNotes",
				"namespace", "##targetNamespace" });
		addAnnotation(getBasicData_Size(), source, new String[] { "kind", "attribute", "name", "size", "namespace",
				"##targetNamespace" });
		addAnnotation(getBasicData_SizeNotes(), source, new String[] { "kind", "attribute", "name", "sizeNotes",
				"namespace", "##targetNamespace" });
		addAnnotation(basicDataRepresentationsEClass, source, new String[] { "name", "BasicDataRepresentations",
				"kind", "elementOnly" });
		addAnnotation(getBasicDataRepresentations_BasicData(), source, new String[] { "kind", "element", "name",
				"basicData", "namespace", "##targetNamespace" });
		addAnnotation(dataTypesEClass, source, new String[] { "name", "DataTypes", "kind", "elementOnly" });
		addAnnotation(getDataTypes_BasicDataRepresentations(), source, new String[] { "kind", "element", "name",
				"basicDataRepresentations", "namespace", "##targetNamespace" });
		addAnnotation(getDataTypes_SimpleDataTypes(), source, new String[] { "kind", "element", "name",
				"simpleDataTypes", "namespace", "##targetNamespace" });
		addAnnotation(getDataTypes_EnumeratedDataTypes(), source, new String[] { "kind", "element", "name",
				"enumeratedDataTypes", "namespace", "##targetNamespace" });
		addAnnotation(getDataTypes_ArrayDataTypes(), source, new String[] { "kind", "element", "name",
				"arrayDataTypes", "namespace", "##targetNamespace" });
		addAnnotation(getDataTypes_FixedRecordDataTypes(), source, new String[] { "kind", "element", "name",
				"fixedRecordDataTypes", "namespace", "##targetNamespace" });
		addAnnotation(getDataTypes_VariantRecordDataTypes(), source, new String[] { "kind", "element", "name",
				"variantRecordDataTypes", "namespace", "##targetNamespace" });
		addAnnotation(deleteRemoveTagEClass, source, new String[] { "name", "DeleteRemoveTag", "kind", "empty" });
		addAnnotation(getDeleteRemoveTag_DataType(), source, new String[] { "kind", "attribute", "name", "dataType",
				"namespace", "##targetNamespace" });
		addAnnotation(getDeleteRemoveTag_DataTypeNotes(), source, new String[] { "kind", "attribute", "name",
				"dataTypeNotes", "namespace", "##targetNamespace" });
		addAnnotation(getDeleteRemoveTag_Semantics(), source, new String[] { "kind", "attribute", "name", "semantics",
				"namespace", "##targetNamespace" });
		addAnnotation(getDeleteRemoveTag_SemanticsNotes(), source, new String[] { "kind", "attribute", "name",
				"semanticsNotes", "namespace", "##targetNamespace" });
		addAnnotation(dimensionEClass, source, new String[] { "name", "Dimension", "kind", "empty" });
		addAnnotation(getDimension_DataType(), source, new String[] { "kind", "attribute", "name", "dataType",
				"namespace", "##targetNamespace" });
		addAnnotation(getDimension_DataTypeNotes(), source, new String[] { "kind", "attribute", "name",
				"dataTypeNotes", "namespace", "##targetNamespace" });
		addAnnotation(getDimension_Name(), source, new String[] { "kind", "attribute", "name", "name", "namespace",
				"##targetNamespace" });
		addAnnotation(getDimension_NameNotes(), source, new String[] { "kind", "attribute", "name", "nameNotes",
				"namespace", "##targetNamespace" });
		addAnnotation(getDimension_Normalization(), source, new String[] { "kind", "attribute", "name",
				"normalization", "namespace", "##targetNamespace" });
		addAnnotation(getDimension_NormalizationNotes(), source, new String[] { "kind", "attribute", "name",
				"normalizationNotes", "namespace", "##targetNamespace" });
		addAnnotation(getDimension_UpperBound(), source, new String[] { "kind", "attribute", "name", "upperBound",
				"namespace", "##targetNamespace" });
		addAnnotation(getDimension_UpperBoundNotes(), source, new String[] { "kind", "attribute", "name",
				"upperBoundNotes", "namespace", "##targetNamespace" });
		addAnnotation(getDimension_Value(), source, new String[] { "kind", "attribute", "name", "value", "namespace",
				"##targetNamespace" });
		addAnnotation(getDimension_ValueNotes(), source, new String[] { "kind", "attribute", "name", "valueNotes",
				"namespace", "##targetNamespace" });
		addAnnotation(dimensionsEClass, source, new String[] { "name", "Dimensions", "kind", "elementOnly" });
		addAnnotation(getDimensions_Dimension(), source, new String[] { "kind", "element", "name", "dimension",
				"namespace", "##targetNamespace" });
		addAnnotation(divestitureCompletionTagEClass, source, new String[] { "name", "DivestitureCompletionTag",
				"kind", "empty" });
		addAnnotation(getDivestitureCompletionTag_DataType(), source, new String[] { "kind", "attribute", "name",
				"dataType", "namespace", "##targetNamespace" });
		addAnnotation(getDivestitureCompletionTag_DataTypeNotes(), source, new String[] { "kind", "attribute", "name",
				"dataTypeNotes", "namespace", "##targetNamespace" });
		addAnnotation(getDivestitureCompletionTag_Semantics(), source, new String[] { "kind", "attribute", "name",
				"semantics", "namespace", "##targetNamespace" });
		addAnnotation(getDivestitureCompletionTag_SemanticsNotes(), source, new String[] { "kind", "attribute", "name",
				"semanticsNotes", "namespace", "##targetNamespace" });
		addAnnotation(divestitureRequestTagEClass, source, new String[] { "name", "DivestitureRequestTag", "kind",
				"empty" });
		addAnnotation(getDivestitureRequestTag_DataType(), source, new String[] { "kind", "attribute", "name",
				"dataType", "namespace", "##targetNamespace" });
		addAnnotation(getDivestitureRequestTag_DataTypeNotes(), source, new String[] { "kind", "attribute", "name",
				"dataTypeNotes", "namespace", "##targetNamespace" });
		addAnnotation(getDivestitureRequestTag_Semantics(), source, new String[] { "kind", "attribute", "name",
				"semantics", "namespace", "##targetNamespace" });
		addAnnotation(getDivestitureRequestTag_SemanticsNotes(), source, new String[] { "kind", "attribute", "name",
				"semanticsNotes", "namespace", "##targetNamespace" });
		addAnnotation(documentRootEClass, source, new String[] { "name", "", "kind", "mixed" });
		addAnnotation(getDocumentRoot_Mixed(), source, new String[] { "kind", "elementWildcard", "name", ":mixed" });
		addAnnotation(getDocumentRoot_XMLNSPrefixMap(), source, new String[] { "kind", "attribute", "name",
				"xmlns:prefix" });
		addAnnotation(getDocumentRoot_XSISchemaLocation(), source, new String[] { "kind", "attribute", "name",
				"xsi:schemaLocation" });
		addAnnotation(getDocumentRoot_ObjectModel(), source, new String[] { "kind", "element", "name", "objectModel",
				"namespace", "##targetNamespace" });
		addAnnotation(dtdVersionEnumEEnum, source, new String[] { "name", "DTDVersionEnum" });
		addAnnotation(dtdVersionEnumObjectEDataType, source, new String[] { "name", "DTDVersionEnum:Object",
				"baseType", "DTDVersionEnum" });
		addAnnotation(endianEnumEEnum, source, new String[] { "name", "EndianEnum" });
		addAnnotation(endianEnumObjectEDataType, source, new String[] { "name", "EndianEnum:Object", "baseType",
				"EndianEnum" });
		addAnnotation(enumeratedDataEClass, source, new String[] { "name", "EnumeratedData", "kind", "elementOnly" });
		addAnnotation(getEnumeratedData_Enumerator(), source, new String[] { "kind", "element", "name", "enumerator",
				"namespace", "##targetNamespace" });
		addAnnotation(getEnumeratedData_Name(), source, new String[] { "kind", "attribute", "name", "name",
				"namespace", "##targetNamespace" });
		addAnnotation(getEnumeratedData_NameNotes(), source, new String[] { "kind", "attribute", "name", "nameNotes",
				"namespace", "##targetNamespace" });
		addAnnotation(getEnumeratedData_Representation(), source, new String[] { "kind", "attribute", "name",
				"representation", "namespace", "##targetNamespace" });
		addAnnotation(getEnumeratedData_RepresentationNotes(), source, new String[] { "kind", "attribute", "name",
				"representationNotes", "namespace", "##targetNamespace" });
		addAnnotation(getEnumeratedData_Semantics(), source, new String[] { "kind", "attribute", "name", "semantics",
				"namespace", "##targetNamespace" });
		addAnnotation(getEnumeratedData_SemanticsNotes(), source, new String[] { "kind", "attribute", "name",
				"semanticsNotes", "namespace", "##targetNamespace" });
		addAnnotation(enumeratedDataTypesEClass, source, new String[] { "name", "EnumeratedDataTypes", "kind",
				"elementOnly" });
		addAnnotation(getEnumeratedDataTypes_EnumeratedData(), source, new String[] { "kind", "element", "name",
				"enumeratedData", "namespace", "##targetNamespace" });
		addAnnotation(enumeratorEClass, source, new String[] { "name", "Enumerator", "kind", "empty" });
		addAnnotation(getEnumerator_Name(), source, new String[] { "kind", "attribute", "name", "name", "namespace",
				"##targetNamespace" });
		addAnnotation(getEnumerator_NameNotes(), source, new String[] { "kind", "attribute", "name", "nameNotes",
				"namespace", "##targetNamespace" });
		addAnnotation(getEnumerator_Values(), source, new String[] { "kind", "attribute", "name", "values",
				"namespace", "##targetNamespace" });
		addAnnotation(getEnumerator_ValuesNotes(), source, new String[] { "kind", "attribute", "name", "valuesNotes",
				"namespace", "##targetNamespace" });
		addAnnotation(fieldEClass, source, new String[] { "name", "Field", "kind", "empty" });
		addAnnotation(getField_DataType(), source, new String[] { "kind", "attribute", "name", "dataType", "namespace",
				"##targetNamespace" });
		addAnnotation(getField_DataTypeNotes(), source, new String[] { "kind", "attribute", "name", "dataTypeNotes",
				"namespace", "##targetNamespace" });
		addAnnotation(getField_Name(), source, new String[] { "kind", "attribute", "name", "name", "namespace",
				"##targetNamespace" });
		addAnnotation(getField_NameNotes(), source, new String[] { "kind", "attribute", "name", "nameNotes",
				"namespace", "##targetNamespace" });
		addAnnotation(getField_Semantics(), source, new String[] { "kind", "attribute", "name", "semantics",
				"namespace", "##targetNamespace" });
		addAnnotation(getField_SemanticsNotes(), source, new String[] { "kind", "attribute", "name", "semanticsNotes",
				"namespace", "##targetNamespace" });
		addAnnotation(fixedRecordDataEClass, source, new String[] { "name", "FixedRecordData", "kind", "elementOnly" });
		addAnnotation(getFixedRecordData_Field(), source, new String[] { "kind", "element", "name", "field",
				"namespace", "##targetNamespace" });
		addAnnotation(getFixedRecordData_Encoding(), source, new String[] { "kind", "attribute", "name", "encoding",
				"namespace", "##targetNamespace" });
		addAnnotation(getFixedRecordData_EncodingNotes(), source, new String[] { "kind", "attribute", "name",
				"encodingNotes", "namespace", "##targetNamespace" });
		addAnnotation(getFixedRecordData_Name(), source, new String[] { "kind", "attribute", "name", "name",
				"namespace", "##targetNamespace" });
		addAnnotation(getFixedRecordData_NameNotes(), source, new String[] { "kind", "attribute", "name", "nameNotes",
				"namespace", "##targetNamespace" });
		addAnnotation(getFixedRecordData_Semantics(), source, new String[] { "kind", "attribute", "name", "semantics",
				"namespace", "##targetNamespace" });
		addAnnotation(getFixedRecordData_SemanticsNotes(), source, new String[] { "kind", "attribute", "name",
				"semanticsNotes", "namespace", "##targetNamespace" });
		addAnnotation(fixedRecordDataTypesEClass, source, new String[] { "name", "FixedRecordDataTypes", "kind",
				"elementOnly" });
		addAnnotation(getFixedRecordDataTypes_FixedRecordData(), source, new String[] { "kind", "element", "name",
				"fixedRecordData", "namespace", "##targetNamespace" });
		addAnnotation(
				interactionClassEClass,
				source,
				new String[] { "name", "InteractionClass", "kind", "elementOnly" });
		addAnnotation(getInteractionClass_Parameters(), source, new String[] { "kind", "element", "name", "parameter",
				"namespace", "##targetNamespace" });
		addAnnotation(getInteractionClass_SubClasses(), source, new String[] { "kind", "element", "name",
				"interactionClass", "namespace", "##targetNamespace" });
		addAnnotation(getInteractionClass_Dimensions(), source, new String[] { "kind", "attribute", "name",
				"dimensions", "namespace", "##targetNamespace" });
		addAnnotation(getInteractionClass_DimensionsNotes(), source, new String[] { "kind", "attribute", "name",
				"dimensionsNotes", "namespace", "##targetNamespace" });
		addAnnotation(getInteractionClass_Name(), source, new String[] { "kind", "attribute", "name", "name",
				"namespace", "##targetNamespace" });
		addAnnotation(getInteractionClass_NameNotes(), source, new String[] { "kind", "attribute", "name", "nameNotes",
				"namespace", "##targetNamespace" });
		addAnnotation(getInteractionClass_Order(), source, new String[] { "kind", "attribute", "name", "order",
				"namespace", "##targetNamespace" });
		addAnnotation(getInteractionClass_OrderNotes(), source, new String[] { "kind", "attribute", "name",
				"orderNotes", "namespace", "##targetNamespace" });
		addAnnotation(getInteractionClass_Semantics(), source, new String[] { "kind", "attribute", "name", "semantics",
				"namespace", "##targetNamespace" });
		addAnnotation(getInteractionClass_SemanticsNotes(), source, new String[] { "kind", "attribute", "name",
				"semanticsNotes", "namespace", "##targetNamespace" });
		addAnnotation(getInteractionClass_Sharing(), source, new String[] { "kind", "attribute", "name", "sharing",
				"namespace", "##targetNamespace" });
		addAnnotation(getInteractionClass_SharingNotes(), source, new String[] { "kind", "attribute", "name",
				"sharingNotes", "namespace", "##targetNamespace" });
		addAnnotation(getInteractionClass_Transportation(), source, new String[] { "kind", "attribute", "name",
				"transportation", "namespace", "##targetNamespace" });
		addAnnotation(getInteractionClass_TransportationNotes(), source, new String[] { "kind", "attribute", "name",
				"transportationNotes", "namespace", "##targetNamespace" });
		addAnnotation(interactionsEClass, source, new String[] { "name", "Interactions", "kind", "elementOnly" });
		addAnnotation(getInteractions_InteractionClass(), source, new String[] { "kind", "element", "name",
				"interactionClass", "namespace", "##targetNamespace" });
		addAnnotation(lookaheadEClass, source, new String[] { "name", "Lookahead", "kind", "empty" });
		addAnnotation(getLookahead_DataType(), source, new String[] { "kind", "attribute", "name", "dataType",
				"namespace", "##targetNamespace" });
		addAnnotation(getLookahead_DataTypeNotes(), source, new String[] { "kind", "attribute", "name",
				"dataTypeNotes", "namespace", "##targetNamespace" });
		addAnnotation(getLookahead_Semantics(), source, new String[] { "kind", "attribute", "name", "semantics",
				"namespace", "##targetNamespace" });
		addAnnotation(getLookahead_SemanticsNotes(), source, new String[] { "kind", "attribute", "name",
				"semanticsNotes", "namespace", "##targetNamespace" });
		addAnnotation(noteEClass, source, new String[] { "name", "Note", "kind", "empty" });
		addAnnotation(getNote_Name(), source, new String[] { "kind", "attribute", "name", "name", "namespace",
				"##targetNamespace" });
		addAnnotation(getNote_Semantics(), source, new String[] { "kind", "attribute", "name", "semantics",
				"namespace", "##targetNamespace" });
		addAnnotation(getNote_SemanticsNotes(), source, new String[] { "kind", "attribute", "name", "semanticsNotes",
				"namespace", "##targetNamespace" });
		addAnnotation(notesEClass, source, new String[] { "name", "Notes", "kind", "elementOnly" });
		addAnnotation(getNotes_Note(), source, new String[] { "kind", "element", "name", "note", "namespace",
				"##targetNamespace" });
		addAnnotation(objectClassEClass, source, new String[] { "name", "ObjectClass", "kind", "elementOnly" });
		addAnnotation(getObjectClass_Attributes(), source, new String[] { "kind", "element", "name", "attribute",
				"namespace", "##targetNamespace" });
		addAnnotation(getObjectClass_SubClasses(), source, new String[] { "kind", "element", "name", "objectClass",
				"namespace", "##targetNamespace" });
		addAnnotation(getObjectClass_Name(), source, new String[] { "kind", "attribute", "name", "name", "namespace",
				"##targetNamespace" });
		addAnnotation(getObjectClass_NameNotes(), source, new String[] { "kind", "attribute", "name", "nameNotes",
				"namespace", "##targetNamespace" });
		addAnnotation(getObjectClass_Semantics(), source, new String[] { "kind", "attribute", "name", "semantics",
				"namespace", "##targetNamespace" });
		addAnnotation(getObjectClass_SemanticsNotes(), source, new String[] { "kind", "attribute", "name",
				"semanticsNotes", "namespace", "##targetNamespace" });
		addAnnotation(getObjectClass_Sharing(), source, new String[] { "kind", "attribute", "name", "sharing",
				"namespace", "##targetNamespace" });
		addAnnotation(getObjectClass_SharingNotes(), source, new String[] { "kind", "attribute", "name",
				"sharingNotes", "namespace", "##targetNamespace" });
		addAnnotation(objectModelEClass, source, new String[] { "name", "ObjectModel", "kind", "elementOnly" });
		addAnnotation(getObjectModel_Objects(), source, new String[] { "kind", "element", "name", "objects",
				"namespace", "##targetNamespace" });
		addAnnotation(getObjectModel_Interactions(), source, new String[] { "kind", "element", "name", "interactions",
				"namespace", "##targetNamespace" });
		addAnnotation(getObjectModel_Dimensions(), source, new String[] { "kind", "element", "name", "dimensions",
				"namespace", "##targetNamespace" });
		addAnnotation(getObjectModel_Time(), source, new String[] { "kind", "element", "name", "time", "namespace",
				"##targetNamespace" });
		addAnnotation(getObjectModel_Tags(), source, new String[] { "kind", "element", "name", "tags", "namespace",
				"##targetNamespace" });
		addAnnotation(getObjectModel_Synchronizations(), source, new String[] { "kind", "element", "name",
				"synchronizations", "namespace", "##targetNamespace" });
		addAnnotation(getObjectModel_Transportations(), source, new String[] { "kind", "element", "name",
				"transportations", "namespace", "##targetNamespace" });
		addAnnotation(getObjectModel_Switches(), source, new String[] { "kind", "element", "name", "switches",
				"namespace", "##targetNamespace" });
		addAnnotation(getObjectModel_DataTypes(), source, new String[] { "kind", "element", "name", "dataTypes",
				"namespace", "##targetNamespace" });
		addAnnotation(getObjectModel_Notes(), source, new String[] { "kind", "element", "name", "notes", "namespace",
				"##targetNamespace" });
		addAnnotation(getObjectModel_AppDomain(), source, new String[] { "kind", "attribute", "name", "appDomain",
				"namespace", "##targetNamespace" });
		addAnnotation(getObjectModel_AppDomainNotes(), source, new String[] { "kind", "attribute", "name",
				"appDomainNotes", "namespace", "##targetNamespace" });
		addAnnotation(getObjectModel_Date(), source, new String[] { "kind", "attribute", "name", "date", "namespace",
				"##targetNamespace" });
		addAnnotation(getObjectModel_DateNotes(), source, new String[] { "kind", "attribute", "name", "dateNotes",
				"namespace", "##targetNamespace" });
		addAnnotation(getObjectModel_DTDversion(), source, new String[] { "kind", "attribute", "name", "DTDversion",
				"namespace", "##targetNamespace" });
		addAnnotation(getObjectModel_Name(), source, new String[] { "kind", "attribute", "name", "name", "namespace",
				"##targetNamespace" });
		addAnnotation(getObjectModel_NameNotes(), source, new String[] { "kind", "attribute", "name", "nameNotes",
				"namespace", "##targetNamespace" });
		addAnnotation(getObjectModel_Other(), source, new String[] { "kind", "attribute", "name", "other", "namespace",
				"##targetNamespace" });
		addAnnotation(getObjectModel_OtherNotes(), source, new String[] { "kind", "attribute", "name", "otherNotes",
				"namespace", "##targetNamespace" });
		addAnnotation(getObjectModel_PocEmail(), source, new String[] { "kind", "attribute", "name", "pocEmail",
				"namespace", "##targetNamespace" });
		addAnnotation(getObjectModel_PocEmailNotes(), source, new String[] { "kind", "attribute", "name",
				"pocEmailNotes", "namespace", "##targetNamespace" });
		addAnnotation(getObjectModel_PocName(), source, new String[] { "kind", "attribute", "name", "pocName",
				"namespace", "##targetNamespace" });
		addAnnotation(getObjectModel_PocNameNotes(), source, new String[] { "kind", "attribute", "name",
				"pocNameNotes", "namespace", "##targetNamespace" });
		addAnnotation(getObjectModel_PocOrg(), source, new String[] { "kind", "attribute", "name", "pocOrg",
				"namespace", "##targetNamespace" });
		addAnnotation(getObjectModel_PocOrgNotes(), source, new String[] { "kind", "attribute", "name", "pocOrgNotes",
				"namespace", "##targetNamespace" });
		addAnnotation(getObjectModel_PocPhone(), source, new String[] { "kind", "attribute", "name", "pocPhone",
				"namespace", "##targetNamespace" });
		addAnnotation(getObjectModel_PocPhoneNotes(), source, new String[] { "kind", "attribute", "name",
				"pocPhoneNotes", "namespace", "##targetNamespace" });
		addAnnotation(getObjectModel_Purpose(), source, new String[] { "kind", "attribute", "name", "purpose",
				"namespace", "##targetNamespace" });
		addAnnotation(getObjectModel_PurposeNotes(), source, new String[] { "kind", "attribute", "name",
				"purposeNotes", "namespace", "##targetNamespace" });
		addAnnotation(getObjectModel_References(), source, new String[] { "kind", "attribute", "name", "references",
				"namespace", "##targetNamespace" });
		addAnnotation(getObjectModel_ReferencesNotes(), source, new String[] { "kind", "attribute", "name",
				"referencesNotes", "namespace", "##targetNamespace" });
		addAnnotation(getObjectModel_Sponsor(), source, new String[] { "kind", "attribute", "name", "sponsor",
				"namespace", "##targetNamespace" });
		addAnnotation(getObjectModel_SponsorNotes(), source, new String[] { "kind", "attribute", "name",
				"sponsorNotes", "namespace", "##targetNamespace" });
		addAnnotation(getObjectModel_Type(), source, new String[] { "kind", "attribute", "name", "type", "namespace",
				"##targetNamespace" });
		addAnnotation(getObjectModel_TypeNotes(), source, new String[] { "kind", "attribute", "name", "typeNotes",
				"namespace", "##targetNamespace" });
		addAnnotation(getObjectModel_Version(), source, new String[] { "kind", "attribute", "name", "version",
				"namespace", "##targetNamespace" });
		addAnnotation(getObjectModel_VersionNotes(), source, new String[] { "kind", "attribute", "name",
				"versionNotes", "namespace", "##targetNamespace" });
		addAnnotation(objectModelTypeEnumEEnum, source, new String[] { "name", "ObjectModelTypeEnum" });
		addAnnotation(objectModelTypeEnumObjectEDataType, source, new String[] { "name", "ObjectModelTypeEnum:Object",
				"baseType", "ObjectModelTypeEnum" });
		addAnnotation(objectsEClass, source, new String[] { "name", "Objects", "kind", "elementOnly" });
		addAnnotation(getObjects_ObjectClass(), source, new String[] { "kind", "element", "name", "objectClass",
				"namespace", "##targetNamespace" });
		addAnnotation(orderEnumEEnum, source, new String[] { "name", "OrderEnum" });
		addAnnotation(orderEnumObjectEDataType, source, new String[] { "name", "OrderEnum:Object", "baseType",
				"OrderEnum" });
		addAnnotation(ownershipEnumEEnum, source, new String[] { "name", "OwnershipEnum" });
		addAnnotation(ownershipEnumObjectEDataType, source, new String[] { "name", "OwnershipEnum:Object", "baseType",
				"OwnershipEnum" });
		addAnnotation(parameterEClass, source, new String[] { "name", "Parameter", "kind", "empty" });
		addAnnotation(getParameter_DataType(), source, new String[] { "kind", "attribute", "name", "dataType",
				"namespace", "##targetNamespace" });
		addAnnotation(getParameter_DataTypeNotes(), source, new String[] { "kind", "attribute", "name",
				"dataTypeNotes", "namespace", "##targetNamespace" });
		addAnnotation(getParameter_Name(), source, new String[] { "kind", "attribute", "name", "name", "namespace",
				"##targetNamespace" });
		addAnnotation(getParameter_NameNotes(), source, new String[] { "kind", "attribute", "name", "nameNotes",
				"namespace", "##targetNamespace" });
		addAnnotation(getParameter_Semantics(), source, new String[] { "kind", "attribute", "name", "semantics",
				"namespace", "##targetNamespace" });
		addAnnotation(getParameter_SemanticsNotes(), source, new String[] { "kind", "attribute", "name",
				"semanticsNotes", "namespace", "##targetNamespace" });
		addAnnotation(requestUpdateTagEClass, source, new String[] { "name", "RequestUpdateTag", "kind", "empty" });
		addAnnotation(getRequestUpdateTag_DataType(), source, new String[] { "kind", "attribute", "name", "dataType",
				"namespace", "##targetNamespace" });
		addAnnotation(getRequestUpdateTag_DataTypeNotes(), source, new String[] { "kind", "attribute", "name",
				"dataTypeNotes", "namespace", "##targetNamespace" });
		addAnnotation(getRequestUpdateTag_Semantics(), source, new String[] { "kind", "attribute", "name", "semantics",
				"namespace", "##targetNamespace" });
		addAnnotation(getRequestUpdateTag_SemanticsNotes(), source, new String[] { "kind", "attribute", "name",
				"semanticsNotes", "namespace", "##targetNamespace" });
		addAnnotation(sendReceiveTagEClass, source, new String[] { "name", "SendReceiveTag", "kind", "empty" });
		addAnnotation(getSendReceiveTag_DataType(), source, new String[] { "kind", "attribute", "name", "dataType",
				"namespace", "##targetNamespace" });
		addAnnotation(getSendReceiveTag_DataTypeNotes(), source, new String[] { "kind", "attribute", "name",
				"dataTypeNotes", "namespace", "##targetNamespace" });
		addAnnotation(getSendReceiveTag_Semantics(), source, new String[] { "kind", "attribute", "name", "semantics",
				"namespace", "##targetNamespace" });
		addAnnotation(getSendReceiveTag_SemanticsNotes(), source, new String[] { "kind", "attribute", "name",
				"semanticsNotes", "namespace", "##targetNamespace" });
		addAnnotation(sharingEnumEEnum, source, new String[] { "name", "SharingEnum" });
		addAnnotation(sharingEnumObjectEDataType, source, new String[] { "name", "SharingEnum:Object", "baseType",
				"SharingEnum" });
		addAnnotation(simpleDataEClass, source, new String[] { "name", "SimpleData", "kind", "empty" });
		addAnnotation(getSimpleData_Accuracy(), source, new String[] { "kind", "attribute", "name", "accuracy",
				"namespace", "##targetNamespace" });
		addAnnotation(getSimpleData_AccuracyNotes(), source, new String[] { "kind", "attribute", "name",
				"accuracyNotes", "namespace", "##targetNamespace" });
		addAnnotation(getSimpleData_Name(), source, new String[] { "kind", "attribute", "name", "name", "namespace",
				"##targetNamespace" });
		addAnnotation(getSimpleData_NameNotes(), source, new String[] { "kind", "attribute", "name", "nameNotes",
				"namespace", "##targetNamespace" });
		addAnnotation(getSimpleData_Representation(), source, new String[] { "kind", "attribute", "name",
				"representation", "namespace", "##targetNamespace" });
		addAnnotation(getSimpleData_RepresentationNotes(), source, new String[] { "kind", "attribute", "name",
				"representationNotes", "namespace", "##targetNamespace" });
		addAnnotation(getSimpleData_Resolution(), source, new String[] { "kind", "attribute", "name", "resolution",
				"namespace", "##targetNamespace" });
		addAnnotation(getSimpleData_ResolutionNotes(), source, new String[] { "kind", "attribute", "name",
				"resolutionNotes", "namespace", "##targetNamespace" });
		addAnnotation(getSimpleData_Semantics(), source, new String[] { "kind", "attribute", "name", "semantics",
				"namespace", "##targetNamespace" });
		addAnnotation(getSimpleData_SemanticsNotes(), source, new String[] { "kind", "attribute", "name",
				"semanticsNotes", "namespace", "##targetNamespace" });
		addAnnotation(getSimpleData_Units(), source, new String[] { "kind", "attribute", "name", "units", "namespace",
				"##targetNamespace" });
		addAnnotation(getSimpleData_UnitsNotes(), source, new String[] { "kind", "attribute", "name", "unitsNotes",
				"namespace", "##targetNamespace" });
		addAnnotation(simpleDataTypesEClass, source, new String[] { "name", "SimpleDataTypes", "kind", "elementOnly" });
		addAnnotation(getSimpleDataTypes_SimpleData(), source, new String[] { "kind", "element", "name", "simpleData",
				"namespace", "##targetNamespace" });
		addAnnotation(stateEnumEEnum, source, new String[] { "name", "StateEnum" });
		addAnnotation(stateEnumObjectEDataType, source, new String[] { "name", "StateEnum:Object", "baseType",
				"StateEnum" });
		addAnnotation(switchesEClass, source, new String[] { "name", "Switches", "kind", "empty" });
		addAnnotation(getSwitches_AttributeRelevanceAdvisory(), source, new String[] { "kind", "attribute", "name",
				"attributeRelevanceAdvisory", "namespace", "##targetNamespace" });
		addAnnotation(getSwitches_AttributeRelevanceAdvisoryNotes(), source, new String[] { "kind", "attribute",
				"name", "attributeRelevanceAdvisoryNotes", "namespace", "##targetNamespace" });
		addAnnotation(getSwitches_AttributeScopeAdvisory(), source, new String[] { "kind", "attribute", "name",
				"attributeScopeAdvisory", "namespace", "##targetNamespace" });
		addAnnotation(getSwitches_AttributeScopeAdvisoryNotes(), source, new String[] { "kind", "attribute", "name",
				"attributeScopeAdvisoryNotes", "namespace", "##targetNamespace" });
		addAnnotation(getSwitches_AutoProvide(), source, new String[] { "kind", "attribute", "name", "autoProvide",
				"namespace", "##targetNamespace" });
		addAnnotation(getSwitches_AutoProvideNotes(), source, new String[] { "kind", "attribute", "name",
				"autoProvideNotes", "namespace", "##targetNamespace" });
		addAnnotation(getSwitches_ConveyRegionDesignatorSets(), source, new String[] { "kind", "attribute", "name",
				"conveyRegionDesignatorSets", "namespace", "##targetNamespace" });
		addAnnotation(getSwitches_ConveyRegionDesignatorSetsNotes(), source, new String[] { "kind", "attribute",
				"name", "conveyRegionDesignatorSetsNotes", "namespace", "##targetNamespace" });
		addAnnotation(getSwitches_InteractionRelevanceAdvisory(), source, new String[] { "kind", "attribute", "name",
				"interactionRelevanceAdvisory", "namespace", "##targetNamespace" });
		addAnnotation(getSwitches_InteractionRelevanceAdvisoryNotes(), source, new String[] { "kind", "attribute",
				"name", "interactionRelevanceAdvisoryNotes", "namespace", "##targetNamespace" });
		addAnnotation(getSwitches_ObjectClassRelevanceAdvisory(), source, new String[] { "kind", "attribute", "name",
				"objectClassRelevanceAdvisory", "namespace", "##targetNamespace" });
		addAnnotation(getSwitches_ObjectClassRelevanceAdvisoryNotes(), source, new String[] { "kind", "attribute",
				"name", "objectClassRelevanceAdvisoryNotes", "namespace", "##targetNamespace" });
		addAnnotation(getSwitches_ServiceReporting(), source, new String[] { "kind", "attribute", "name",
				"serviceReporting", "namespace", "##targetNamespace" });
		addAnnotation(getSwitches_ServiceReportingNotes(), source, new String[] { "kind", "attribute", "name",
				"serviceReportingNotes", "namespace", "##targetNamespace" });
		addAnnotation(syncCapabilityEnumEEnum, source, new String[] { "name", "SyncCapabilityEnum" });
		addAnnotation(syncCapabilityEnumObjectEDataType, source, new String[] { "name", "SyncCapabilityEnum:Object",
				"baseType", "SyncCapabilityEnum" });
		addAnnotation(synchronizationEClass, source, new String[] { "name", "Synchronization", "kind", "empty" });
		addAnnotation(getSynchronization_Capability(), source, new String[] { "kind", "attribute", "name",
				"capability", "namespace", "##targetNamespace" });
		addAnnotation(getSynchronization_CapabilityNotes(), source, new String[] { "kind", "attribute", "name",
				"capabilityNotes", "namespace", "##targetNamespace" });
		addAnnotation(getSynchronization_DataType(), source, new String[] { "kind", "attribute", "name", "dataType",
				"namespace", "##targetNamespace" });
		addAnnotation(getSynchronization_DataTypeNotes(), source, new String[] { "kind", "attribute", "name",
				"dataTypeNotes", "namespace", "##targetNamespace" });
		addAnnotation(getSynchronization_Label(), source, new String[] { "kind", "attribute", "name", "label",
				"namespace", "##targetNamespace" });
		addAnnotation(getSynchronization_LabelNotes(), source, new String[] { "kind", "attribute", "name",
				"labelNotes", "namespace", "##targetNamespace" });
		addAnnotation(getSynchronization_Semantics(), source, new String[] { "kind", "attribute", "name", "semantics",
				"namespace", "##targetNamespace" });
		addAnnotation(getSynchronization_SemanticsNotes(), source, new String[] { "kind", "attribute", "name",
				"semanticsNotes", "namespace", "##targetNamespace" });
		addAnnotation(
				synchronizationsEClass,
				source,
				new String[] { "name", "Synchronizations", "kind", "elementOnly" });
		addAnnotation(getSynchronizations_Synchronization(), source, new String[] { "kind", "element", "name",
				"synchronization", "namespace", "##targetNamespace" });
		addAnnotation(tagsEClass, source, new String[] { "name", "Tags", "kind", "elementOnly" });
		addAnnotation(getTags_UpdateReflectTag(), source, new String[] { "kind", "element", "name", "updateReflectTag",
				"namespace", "##targetNamespace" });
		addAnnotation(getTags_SendReceiveTag(), source, new String[] { "kind", "element", "name", "sendReceiveTag",
				"namespace", "##targetNamespace" });
		addAnnotation(getTags_DeleteRemoveTag(), source, new String[] { "kind", "element", "name", "deleteRemoveTag",
				"namespace", "##targetNamespace" });
		addAnnotation(getTags_DivestitureRequestTag(), source, new String[] { "kind", "element", "name",
				"divestitureRequestTag", "namespace", "##targetNamespace" });
		addAnnotation(getTags_DivestitureCompletionTag(), source, new String[] { "kind", "element", "name",
				"divestitureCompletionTag", "namespace", "##targetNamespace" });
		addAnnotation(getTags_AcquisitionRequestTag(), source, new String[] { "kind", "element", "name",
				"acquisitionRequestTag", "namespace", "##targetNamespace" });
		addAnnotation(getTags_RequestUpdateTag(), source, new String[] { "kind", "element", "name", "requestUpdateTag",
				"namespace", "##targetNamespace" });
		addAnnotation(timeEClass, source, new String[] { "name", "Time", "kind", "elementOnly" });
		addAnnotation(getTime_TimeStamp(), source, new String[] { "kind", "element", "name", "timeStamp", "namespace",
				"##targetNamespace" });
		addAnnotation(getTime_Lookahead(), source, new String[] { "kind", "element", "name", "lookahead", "namespace",
				"##targetNamespace" });
		addAnnotation(timeStampEClass, source, new String[] { "name", "TimeStamp", "kind", "empty" });
		addAnnotation(getTimeStamp_DataType(), source, new String[] { "kind", "attribute", "name", "dataType",
				"namespace", "##targetNamespace" });
		addAnnotation(getTimeStamp_DataTypeNotes(), source, new String[] { "kind", "attribute", "name",
				"dataTypeNotes", "namespace", "##targetNamespace" });
		addAnnotation(getTimeStamp_Semantics(), source, new String[] { "kind", "attribute", "name", "semantics",
				"namespace", "##targetNamespace" });
		addAnnotation(getTimeStamp_SemanticsNotes(), source, new String[] { "kind", "attribute", "name",
				"semanticsNotes", "namespace", "##targetNamespace" });
		addAnnotation(transportationEClass, source, new String[] { "name", "Transportation", "kind", "empty" });
		addAnnotation(getTransportation_Description(), source, new String[] { "kind", "attribute", "name",
				"description", "namespace", "##targetNamespace" });
		addAnnotation(getTransportation_DescriptionNotes(), source, new String[] { "kind", "attribute", "name",
				"descriptionNotes", "namespace", "##targetNamespace" });
		addAnnotation(getTransportation_Name(), source, new String[] { "kind", "attribute", "name", "name",
				"namespace", "##targetNamespace" });
		addAnnotation(getTransportation_NameNotes(), source, new String[] { "kind", "attribute", "name", "nameNotes",
				"namespace", "##targetNamespace" });
		addAnnotation(transportationsEClass, source, new String[] { "name", "Transportations", "kind", "elementOnly" });
		addAnnotation(getTransportations_Transportation(), source, new String[] { "kind", "element", "name",
				"transportation", "namespace", "##targetNamespace" });
		addAnnotation(updateReflectTagEClass, source, new String[] { "name", "UpdateReflectTag", "kind", "empty" });
		addAnnotation(getUpdateReflectTag_DataType(), source, new String[] { "kind", "attribute", "name", "dataType",
				"namespace", "##targetNamespace" });
		addAnnotation(getUpdateReflectTag_DataTypeNotes(), source, new String[] { "kind", "attribute", "name",
				"dataTypeNotes", "namespace", "##targetNamespace" });
		addAnnotation(getUpdateReflectTag_Semantics(), source, new String[] { "kind", "attribute", "name", "semantics",
				"namespace", "##targetNamespace" });
		addAnnotation(getUpdateReflectTag_SemanticsNotes(), source, new String[] { "kind", "attribute", "name",
				"semanticsNotes", "namespace", "##targetNamespace" });
		addAnnotation(updateTypeEnumEEnum, source, new String[] { "name", "UpdateTypeEnum" });
		addAnnotation(updateTypeEnumObjectEDataType, source, new String[] { "name", "UpdateTypeEnum:Object",
				"baseType", "UpdateTypeEnum" });
		addAnnotation(variantRecordDataEClass, source, new String[] { "name", "VariantRecordData", "kind",
				"elementOnly" });
		addAnnotation(getVariantRecordData_Alternative(), source, new String[] { "kind", "element", "name",
				"alternative", "namespace", "##targetNamespace" });
		addAnnotation(getVariantRecordData_DataType(), source, new String[] { "kind", "attribute", "name", "dataType",
				"namespace", "##targetNamespace" });
		addAnnotation(getVariantRecordData_DataTypeNotes(), source, new String[] { "kind", "attribute", "name",
				"dataTypeNotes", "namespace", "##targetNamespace" });
		addAnnotation(getVariantRecordData_Discriminant(), source, new String[] { "kind", "attribute", "name",
				"discriminant", "namespace", "##targetNamespace" });
		addAnnotation(getVariantRecordData_DiscriminantNotes(), source, new String[] { "kind", "attribute", "name",
				"discriminantNotes", "namespace", "##targetNamespace" });
		addAnnotation(getVariantRecordData_Encoding(), source, new String[] { "kind", "attribute", "name", "encoding",
				"namespace", "##targetNamespace" });
		addAnnotation(getVariantRecordData_EncodingNotes(), source, new String[] { "kind", "attribute", "name",
				"encodingNotes", "namespace", "##targetNamespace" });
		addAnnotation(getVariantRecordData_Name(), source, new String[] { "kind", "attribute", "name", "name",
				"namespace", "##targetNamespace" });
		addAnnotation(getVariantRecordData_NameNotes(), source, new String[] { "kind", "attribute", "name",
				"nameNotes", "namespace", "##targetNamespace" });
		addAnnotation(getVariantRecordData_Semantics(), source, new String[] { "kind", "attribute", "name",
				"semantics", "namespace", "##targetNamespace" });
		addAnnotation(getVariantRecordData_SemanticsNotes(), source, new String[] { "kind", "attribute", "name",
				"semanticsNotes", "namespace", "##targetNamespace" });
		addAnnotation(variantRecordDataTypesEClass, source, new String[] { "name", "VariantRecordDataTypes", "kind",
				"elementOnly" });
		addAnnotation(getVariantRecordDataTypes_VariantRecordData(), source, new String[] { "kind", "element", "name",
				"variantRecordData", "namespace", "##targetNamespace" });
	}

} // OmtPackageImpl
