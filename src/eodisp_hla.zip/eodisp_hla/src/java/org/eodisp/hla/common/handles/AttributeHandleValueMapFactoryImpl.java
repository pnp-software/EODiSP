package org.eodisp.hla.common.handles;

import hla.rti1516.AttributeHandleValueMap;
import hla.rti1516.AttributeHandleValueMapFactory;

public class AttributeHandleValueMapFactoryImpl implements
		AttributeHandleValueMapFactory {
	public AttributeHandleValueMap create(int capacity) {
		return new AttributeHandleValueMapImpl(capacity);
	}
}
