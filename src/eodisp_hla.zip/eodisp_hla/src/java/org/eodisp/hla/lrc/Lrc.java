/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.hla.lrc;

import hla.rti1516.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.*;
import java.util.Map.Entry;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import net.jcip.annotations.GuardedBy;
import net.jcip.annotations.ThreadSafe;

import org.apache.log4j.Logger;
import org.eodisp.hla.common.crc.CrcRemote;
import org.eodisp.hla.common.handles.AttributeHandleValueMapImpl;
import org.eodisp.hla.common.lrc.LrcHandle;
import org.eodisp.hla.common.lrc.LrcRemote;
import org.eodisp.hla.lrc.application.LrcAppModule;
import org.eodisp.hla.lrc.application.LrcConfiguration;
import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.remote.registry.JeriRegistry;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.configuration.ConfigurationException;

/**
 * The main entry class to the local RTI component.
 * 
 * @author ibirrer
 * @version $Id:$
 * 
 * @UML -------------------------------------------------------------------
 * @has - federateAmbassadors 0..* FederateAmbassador
 * @navassoc - crcRemote 0..1 CrcRemote
 */
@ThreadSafe
public class Lrc {
	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	private final static Logger logger = Logger.getLogger(Lrc.class);

	private final Map<String, Map<FederateHandle, FederateAmbassador>> federateAmbassadors = new HashMap<String, Map<FederateHandle, FederateAmbassador>>();

	@GuardedBy("this")
	private CrcRemote crcRemote;

	private LrcHandle lrcHandle;

	/**
	 * TODO: make configurable
	 */
	private final ExecutorService reflectTasks = Executors.newFixedThreadPool(1);

	public Lrc() {
	}

	public synchronized RTIambassador createRtiAmbassador() throws RemoteException, ConfigurationException,
			NotBoundException {
		if (crcRemote == null) {
			try {
				LrcConfiguration lrcConfig = (LrcConfiguration) AppRegistry.getRootApp().getConfiguration(
						LrcConfiguration.ID);
				URI crcURI = lrcConfig.getCrcUri();
				logger.debug(String.format("Getting proxy of CRC registry at %s", crcURI));
				RemoteAppModule remoteAppModule = (RemoteAppModule) AppRegistry.getRootApp().getAppModule(
						RemoteAppModule.ID);
				JeriRegistry crcRegistry = remoteAppModule.getRegistry(crcURI);
				crcRemote = (CrcRemote) crcRegistry.lookup(CrcRemote.REGISTRY_NAME);
				final LrcRemote lrcRemote = (LrcRemote) remoteAppModule.getRegistry().lookup(LrcRemote.REGISTRY_NAME);
				lrcHandle = crcRemote.registerLrc(lrcRemote);
				logger.debug(String.format("Register LrcRemote [%s] on CRC with handle [%s]", lrcRemote, lrcHandle));
			} catch (URISyntaxException e) {
				throw new ConfigurationException("The URI in the LRC configuration is not valid", e);
			}
		}

		return new LrcRtiAmbassador(crcRemote);
	}

	/**
	 * Used for testing purposes only
	 * 
	 * @throws RemoteException
	 */
	synchronized void reset() {
		federateAmbassadors.clear();
		crcRemote = null;
	}

	/**
	 * Joins the federation execution and registers the the federate ambassador
	 * with the LRC. This method is specifically declared in the LRC to allow
	 * the join and the federate register method to be atomic.
	 * 
	 * @param federateType
	 * @param executionName
	 * @param federateAmbassador
	 * @param serviceReferences
	 * @return
	 * @throws FederationExecutionDoesNotExist
	 * @throws RemoteException
	 */
	synchronized FederateHandle joinFederationExecution(String federateType, String executionName,
			FederateAmbassador federateAmbassador, MobileFederateServices serviceReferences)
			throws FederationExecutionDoesNotExist, RemoteException {
		LrcAppModule lrcAppModule = (LrcAppModule) AppRegistry.getRootApp().getAppModule(LrcAppModule.ID);
		Lrc lrc = lrcAppModule.getLrc();

		FederateHandle federateHandle = crcRemote.joinFederationExecution(executionName, federateType, lrc.getHandle(),
				serviceReferences);

		registerFederateAmbassador(executionName, federateHandle, federateAmbassador);
		return federateHandle;
	}

	/**
	 * Registers a federate ambassador on this LRC. This registry is used to
	 * determine the target federate ambassador of a call coming form the CRC or
	 * another LRC.
	 * 
	 * @param federationExecutionName
	 *            the name of the federation execution the federate is joined to
	 * @param federateHandle
	 *            the handle of the federate to register
	 * @param federateAmbassador
	 *            reference to the federate ambassador
	 */
	synchronized void registerFederateAmbassador(String federationExecutionName, FederateHandle federateHandle,
			FederateAmbassador federateAmbassador) {
		Map<FederateHandle, FederateAmbassador> federationExecutionAmbassadors = federateAmbassadors
				.get(federationExecutionName);

		if (federationExecutionAmbassadors == null) {
			federationExecutionAmbassadors = new HashMap<FederateHandle, FederateAmbassador>();
			federateAmbassadors.put(federationExecutionName, federationExecutionAmbassadors);
		}

		assert (!federationExecutionAmbassadors.containsKey(federateHandle));
		federationExecutionAmbassadors.put(federateHandle, federateAmbassador);
	}

	synchronized FederateAmbassador getFederateAmbassador(String federationExecutionName, FederateHandle federateHandle) {
		Map<FederateHandle, FederateAmbassador> ambassadors = federateAmbassadors.get(federationExecutionName);
		if (ambassadors == null) {
			logger.fatal(String.format("Could not get federate ambassadors on lrc for federation execution: %s",
					federationExecutionName));
		}
		final FederateAmbassador federateAmbassador = ambassadors.get(federateHandle);
		if (federateAmbassador == null) {
			logger.fatal(String.format(
					"Could not get federate ambassador on lrc for federate: %s of federation execution %s",
					federateHandle, federationExecutionName));
		}
		return federateAmbassador;
	}

	synchronized LrcHandle getHandle() {
		return lrcHandle;
	}

	synchronized void reflectAttributeValues(final ObjectInstanceHandle objectInstanceHandle,
			final Map<AttributeHandle, byte[]> values, final byte[] userSuppliedTag,
			final Map<FederateHandle, AttributeHandle[]> federateSubscriptions, final String federationExecutionName) {

		reflectTasks.execute(new Runnable() {
			public void run() {
				for (final Entry<FederateHandle, AttributeHandle[]> federateAttributeHandleEntry : federateSubscriptions
						.entrySet()) {

					FederateHandle federateHandle = federateAttributeHandleEntry.getKey();
					FederateAmbassador federateAmbassador = getFederateAmbassador(federationExecutionName,
							federateHandle);
					AttributeHandleValueMap attributeHandleValueMap = new AttributeHandleValueMapImpl();
					for (AttributeHandle attributeHandle : federateAttributeHandleEntry.getValue()) {
						attributeHandleValueMap.put(attributeHandle, values.get(attributeHandle));
					}
					logger.debug(String.format("Call reflect on federateAmbassador '%s' with handles '%s'",
							federateAmbassador, attributeHandleValueMap.keySet()));
					try {
						federateAmbassador.reflectAttributeValues(objectInstanceHandle, attributeHandleValueMap,
								userSuppliedTag, null, null);
					} catch (RTIexception e) {
						logger.error("Error while calling reflectAttributeValues in local federate Ambassador", e);
					}
				}
			}
		});
	}

	// NOT USED
	private static long countBytes(AttributeHandleValueMap map) {
		long result = 0;
		Set<byte[]> values = new HashSet<byte[]>(map.values());

		for (byte[] bs : values) {
			result += bs.length;
		}
		return result;
	}

	// NOT USED
	private static HashMap<AttributeHandle, byte[]> deepCopy(AttributeHandleValueMap attributeHandleValueMap) {
		HashMap<AttributeHandle, byte[]> result = new HashMap<AttributeHandle, byte[]>(attributeHandleValueMap.size());
		Set<Map.Entry> entries = attributeHandleValueMap.entrySet();

		for (Entry entry : entries) {
			AttributeHandle attributeHandle = (AttributeHandle) entry.getKey();
			byte[] data = (byte[]) entry.getValue();
			byte[] dataCopy = new byte[data.length];
			System.arraycopy(data, 0, dataCopy, 0, data.length);
			result.put(attributeHandle, dataCopy);
		}
		return result;
	}
}
