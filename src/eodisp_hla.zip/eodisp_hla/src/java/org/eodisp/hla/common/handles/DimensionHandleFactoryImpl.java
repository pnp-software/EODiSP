package org.eodisp.hla.common.handles;

import hla.rti1516.*;

public class DimensionHandleFactoryImpl implements DimensionHandleFactory {

	public DimensionHandle decode(byte[] buffer, int offset)
			throws CouldNotDecode, FederateNotExecutionMember {
		return new DimensionHandleImpl(buffer, offset);
	}
}
