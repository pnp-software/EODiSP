/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt;

import hla.rti1516.AttributeHandle;

import java.util.List;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

import org.eodisp.hla.crc.data.Federate;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Attribute</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.Attribute#getDataType <em>Data Type</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Attribute#getDataTypeNotes <em>Data Type Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Attribute#getDimensions <em>Dimensions</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Attribute#getDimensionsNotes <em>Dimensions Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Attribute#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Attribute#getNameNotes <em>Name Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Attribute#getOrder <em>Order</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Attribute#getOrderNotes <em>Order Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Attribute#getOwnership <em>Ownership</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Attribute#getOwnershipNotes <em>Ownership Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Attribute#getSemantics <em>Semantics</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Attribute#getSemanticsNotes <em>Semantics Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Attribute#getSharing <em>Sharing</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Attribute#getSharingNotes <em>Sharing Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Attribute#getTransportation <em>Transportation</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Attribute#getTransportationNotes <em>Transportation Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Attribute#getUpdateCondition <em>Update Condition</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Attribute#getUpdateConditionNotes <em>Update Condition Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Attribute#getUpdateType <em>Update Type</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Attribute#getUpdateTypeNotes <em>Update Type Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Attribute#getSubscribingFederates <em>Subscribing Federates</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Attribute#getPublishingFederates <em>Publishing Federates</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eodisp.hla.crc.omt.OmtPackage#getAttribute()
 * @model extendedMetaData="name='Attribute' kind='empty'"
 * @generated
 */
public interface Attribute extends EObject {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * Returns the attribute handle of this attribute.
	 * 
	 * @return the attribute handle of this attribute.
	 */
	AttributeHandle getHandle();

	/**
	 * Sets the attribute handle of this attribute. TODO: Should be set when
	 * constructing
	 * 
	 * @param attributeHandle
	 */
	void setHandle(AttributeHandle attributeHandle);

	/**
	 * Returns the object class this attribute is defined in.
	 * 
	 * @return the object class of this attribute.
	 */
	ObjectClass getObjectClass();

	/**
	 * Tests if this attribute is available from the given object class. An
	 * available attribute is defined as follows: The set of declared attributes
	 * of an object class in union with the set of inherited attributes of that
	 * object class. (See section 3.1.5 in IEEE 1516.1-2000)
	 * 
	 * @param objectClass
	 *            the object class that shall be tested
	 * @return true if this attribute is available from the specified object
	 *         class
	 */
	boolean isAvailableFrom(ObjectClass objectClass);

	/**
	 * Returns the value of the '<em><b>Data Type</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Data Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Data Type</em>' attribute.
	 * @see #setDataType(String)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getAttribute_DataType()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKEN"
	 *        extendedMetaData="kind='attribute' name='dataType'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	String getDataType();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Attribute#getDataType <em>Data Type</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Data Type</em>' attribute.
	 * @see #getDataType()
	 * @generated
	 */
	void setDataType(String value);

	/**
	 * Returns the value of the '<em><b>Data Type Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Data Type Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Data Type Notes</em>' attribute.
	 * @see #setDataTypeNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getAttribute_DataTypeNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='dataTypeNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getDataTypeNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Attribute#getDataTypeNotes <em>Data Type Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Data Type Notes</em>' attribute.
	 * @see #getDataTypeNotes()
	 * @generated
	 */
	void setDataTypeNotes(List value);

	/**
	 * Returns the value of the '<em><b>Dimensions</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Dimensions</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dimensions</em>' attribute.
	 * @see #setDimensions(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getAttribute_Dimensions()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='dimensions' namespace='##targetNamespace'"
	 * @generated
	 */
	List getDimensions();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Attribute#getDimensions <em>Dimensions</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Dimensions</em>' attribute.
	 * @see #getDimensions()
	 * @generated
	 */
	void setDimensions(List value);

	/**
	 * Returns the value of the '<em><b>Dimensions Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Dimensions Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dimensions Notes</em>' attribute.
	 * @see #setDimensionsNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getAttribute_DimensionsNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='dimensionsNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getDimensionsNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Attribute#getDimensionsNotes <em>Dimensions Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Dimensions Notes</em>' attribute.
	 * @see #getDimensionsNotes()
	 * @generated
	 */
	void setDimensionsNotes(List value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getAttribute_Name()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKEN"
	 *        required="true" extendedMetaData="kind='attribute' name='name'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	String getName();

	/**
	 * Returns the fully qualified name of this attribute's object class with
	 * the attribute added after a dot (.). See section 10.1.1 in IEEE
	 * 1516.1-2000.
	 * 
	 * @param omitObjectRoot
	 *            if <code>true</code> omits the topmost super class
	 *            HLAobjectRoot.
	 * @return the fully qualified name of this attribute. Delimiter is a
	 *         dot(.).
	 */
	String getQualifiedName(boolean omitObjectRoot);

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Attribute#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Name Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name Notes</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name Notes</em>' attribute.
	 * @see #setNameNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getAttribute_NameNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='nameNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getNameNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Attribute#getNameNotes <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name Notes</em>' attribute.
	 * @see #getNameNotes()
	 * @generated
	 */
	void setNameNotes(List value);

	/**
	 * Returns the value of the '<em><b>Order</b></em>' attribute. The
	 * default value is <code>"Receive"</code>. The literals are from the
	 * enumeration {@link org.eodisp.hla.crc.omt.OrderEnum}. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Order</em>' attribute isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Order</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.OrderEnum
	 * @see #isSetOrder()
	 * @see #unsetOrder()
	 * @see #setOrder(OrderEnum)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getAttribute_Order()
	 * @model default="Receive" unique="false" unsettable="true"
	 *        extendedMetaData="kind='attribute' name='order'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	OrderEnum getOrder();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Attribute#getOrder <em>Order</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Order</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.OrderEnum
	 * @see #isSetOrder()
	 * @see #unsetOrder()
	 * @see #getOrder()
	 * @generated
	 */
	void setOrder(OrderEnum value);

	/**
	 * Unsets the value of the '{@link org.eodisp.hla.crc.omt.Attribute#getOrder <em>Order</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #isSetOrder()
	 * @see #getOrder()
	 * @see #setOrder(OrderEnum)
	 * @generated
	 */
	void unsetOrder();

	/**
	 * Returns whether the value of the '{@link org.eodisp.hla.crc.omt.Attribute#getOrder <em>Order</em>}' attribute is set.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return whether the value of the '<em>Order</em>' attribute is set.
	 * @see #unsetOrder()
	 * @see #getOrder()
	 * @see #setOrder(OrderEnum)
	 * @generated
	 */
	boolean isSetOrder();

	/**
	 * Returns the value of the '<em><b>Order Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Order Notes</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Order Notes</em>' attribute.
	 * @see #setOrderNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getAttribute_OrderNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='orderNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getOrderNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Attribute#getOrderNotes <em>Order Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Order Notes</em>' attribute.
	 * @see #getOrderNotes()
	 * @generated
	 */
	void setOrderNotes(List value);

	/**
	 * Returns the value of the '<em><b>Ownership</b></em>' attribute. The
	 * default value is <code>"Divest"</code>. The literals are from the
	 * enumeration {@link org.eodisp.hla.crc.omt.OwnershipEnum}. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Ownership</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Ownership</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.OwnershipEnum
	 * @see #isSetOwnership()
	 * @see #unsetOwnership()
	 * @see #setOwnership(OwnershipEnum)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getAttribute_Ownership()
	 * @model default="Divest" unique="false" unsettable="true"
	 *        extendedMetaData="kind='attribute' name='ownership'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	OwnershipEnum getOwnership();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Attribute#getOwnership <em>Ownership</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ownership</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.OwnershipEnum
	 * @see #isSetOwnership()
	 * @see #unsetOwnership()
	 * @see #getOwnership()
	 * @generated
	 */
	void setOwnership(OwnershipEnum value);

	/**
	 * Unsets the value of the '{@link org.eodisp.hla.crc.omt.Attribute#getOwnership <em>Ownership</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #isSetOwnership()
	 * @see #getOwnership()
	 * @see #setOwnership(OwnershipEnum)
	 * @generated
	 */
	void unsetOwnership();

	/**
	 * Returns whether the value of the '{@link org.eodisp.hla.crc.omt.Attribute#getOwnership <em>Ownership</em>}' attribute is set.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return whether the value of the '<em>Ownership</em>' attribute is set.
	 * @see #unsetOwnership()
	 * @see #getOwnership()
	 * @see #setOwnership(OwnershipEnum)
	 * @generated
	 */
	boolean isSetOwnership();

	/**
	 * Returns the value of the '<em><b>Ownership Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Ownership Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ownership Notes</em>' attribute.
	 * @see #setOwnershipNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getAttribute_OwnershipNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='ownershipNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getOwnershipNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Attribute#getOwnershipNotes <em>Ownership Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ownership Notes</em>' attribute.
	 * @see #getOwnershipNotes()
	 * @generated
	 */
	void setOwnershipNotes(List value);

	/**
	 * Returns the value of the '<em><b>Semantics</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Semantics</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Semantics</em>' attribute.
	 * @see #setSemantics(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getAttribute_Semantics()
	 * @model unique="false"
	 *        dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='semantics'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	Object getSemantics();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Attribute#getSemantics <em>Semantics</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Semantics</em>' attribute.
	 * @see #getSemantics()
	 * @generated
	 */
	void setSemantics(Object value);

	/**
	 * Returns the value of the '<em><b>Semantics Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Semantics Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Semantics Notes</em>' attribute.
	 * @see #setSemanticsNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getAttribute_SemanticsNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='semanticsNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSemanticsNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Attribute#getSemanticsNotes <em>Semantics Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Semantics Notes</em>' attribute.
	 * @see #getSemanticsNotes()
	 * @generated
	 */
	void setSemanticsNotes(List value);

	/**
	 * Returns the value of the '<em><b>Sharing</b></em>' attribute. The
	 * default value is <code>"Publish"</code>. The literals are from the
	 * enumeration {@link org.eodisp.hla.crc.omt.SharingEnum}. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sharing</em>' attribute isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Sharing</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.SharingEnum
	 * @see #isSetSharing()
	 * @see #unsetSharing()
	 * @see #setSharing(SharingEnum)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getAttribute_Sharing()
	 * @model default="Publish" unique="false" unsettable="true"
	 *        extendedMetaData="kind='attribute' name='sharing'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	SharingEnum getSharing();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Attribute#getSharing <em>Sharing</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sharing</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.SharingEnum
	 * @see #isSetSharing()
	 * @see #unsetSharing()
	 * @see #getSharing()
	 * @generated
	 */
	void setSharing(SharingEnum value);

	/**
	 * Unsets the value of the '{@link org.eodisp.hla.crc.omt.Attribute#getSharing <em>Sharing</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #isSetSharing()
	 * @see #getSharing()
	 * @see #setSharing(SharingEnum)
	 * @generated
	 */
	void unsetSharing();

	/**
	 * Returns whether the value of the '{@link org.eodisp.hla.crc.omt.Attribute#getSharing <em>Sharing</em>}' attribute is set.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return whether the value of the '<em>Sharing</em>' attribute is set.
	 * @see #unsetSharing()
	 * @see #getSharing()
	 * @see #setSharing(SharingEnum)
	 * @generated
	 */
	boolean isSetSharing();

	/**
	 * Returns the value of the '<em><b>Sharing Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sharing Notes</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sharing Notes</em>' attribute.
	 * @see #setSharingNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getAttribute_SharingNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='sharingNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSharingNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Attribute#getSharingNotes <em>Sharing Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sharing Notes</em>' attribute.
	 * @see #getSharingNotes()
	 * @generated
	 */
	void setSharingNotes(List value);

	/**
	 * Returns the value of the '<em><b>Transportation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Transportation</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transportation</em>' attribute.
	 * @see #setTransportation(String)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getAttribute_Transportation()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKEN"
	 *        extendedMetaData="kind='attribute' name='transportation' namespace='##targetNamespace'"
	 * @generated
	 */
	String getTransportation();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Attribute#getTransportation <em>Transportation</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Transportation</em>' attribute.
	 * @see #getTransportation()
	 * @generated
	 */
	void setTransportation(String value);

	/**
	 * Returns the value of the '<em><b>Transportation Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Transportation Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transportation Notes</em>' attribute.
	 * @see #setTransportationNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getAttribute_TransportationNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='transportationNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getTransportationNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Attribute#getTransportationNotes <em>Transportation Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Transportation Notes</em>' attribute.
	 * @see #getTransportationNotes()
	 * @generated
	 */
	void setTransportationNotes(List value);

	/**
	 * Returns the value of the '<em><b>Update Condition</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Update Condition</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Update Condition</em>' attribute.
	 * @see #setUpdateCondition(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getAttribute_UpdateCondition()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='updateCondition' namespace='##targetNamespace'"
	 * @generated
	 */
	Object getUpdateCondition();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Attribute#getUpdateCondition <em>Update Condition</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Update Condition</em>' attribute.
	 * @see #getUpdateCondition()
	 * @generated
	 */
	void setUpdateCondition(Object value);

	/**
	 * Returns the value of the '<em><b>Update Condition Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Update Condition Notes</em>' attribute
	 * isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Update Condition Notes</em>' attribute.
	 * @see #setUpdateConditionNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getAttribute_UpdateConditionNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='updateConditionNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getUpdateConditionNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Attribute#getUpdateConditionNotes <em>Update Condition Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Update Condition Notes</em>' attribute.
	 * @see #getUpdateConditionNotes()
	 * @generated
	 */
	void setUpdateConditionNotes(List value);

	/**
	 * Returns the value of the '<em><b>Update Type</b></em>' attribute.
	 * The default value is <code>"Static"</code>. The literals are from the
	 * enumeration {@link org.eodisp.hla.crc.omt.UpdateTypeEnum}. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Update Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Update Type</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.UpdateTypeEnum
	 * @see #isSetUpdateType()
	 * @see #unsetUpdateType()
	 * @see #setUpdateType(UpdateTypeEnum)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getAttribute_UpdateType()
	 * @model default="Static" unique="false" unsettable="true"
	 *        extendedMetaData="kind='attribute' name='updateType'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	UpdateTypeEnum getUpdateType();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Attribute#getUpdateType <em>Update Type</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Update Type</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.UpdateTypeEnum
	 * @see #isSetUpdateType()
	 * @see #unsetUpdateType()
	 * @see #getUpdateType()
	 * @generated
	 */
	void setUpdateType(UpdateTypeEnum value);

	/**
	 * Unsets the value of the '{@link org.eodisp.hla.crc.omt.Attribute#getUpdateType <em>Update Type</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #isSetUpdateType()
	 * @see #getUpdateType()
	 * @see #setUpdateType(UpdateTypeEnum)
	 * @generated
	 */
	void unsetUpdateType();

	/**
	 * Returns whether the value of the '{@link org.eodisp.hla.crc.omt.Attribute#getUpdateType <em>Update Type</em>}' attribute is set.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return whether the value of the '<em>Update Type</em>' attribute is set.
	 * @see #unsetUpdateType()
	 * @see #getUpdateType()
	 * @see #setUpdateType(UpdateTypeEnum)
	 * @generated
	 */
	boolean isSetUpdateType();

	/**
	 * Returns the value of the '<em><b>Update Type Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Update Type Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Update Type Notes</em>' attribute.
	 * @see #setUpdateTypeNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getAttribute_UpdateTypeNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='updateTypeNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getUpdateTypeNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Attribute#getUpdateTypeNotes <em>Update Type Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Update Type Notes</em>' attribute.
	 * @see #getUpdateTypeNotes()
	 * @generated
	 */
	void setUpdateTypeNotes(List value);

	/**
	 * Returns the value of the '<em><b>Subscribing Federates</b></em>' reference list.
	 * The list contents are of type {@link org.eodisp.hla.crc.data.Federate}.
	 * It is bidirectional and its opposite is '{@link org.eodisp.hla.crc.data.Federate#getSubscribedAttributes <em>Subscribed Attributes</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Subscribing Federates</em>' reference list
	 * isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Subscribing Federates</em>' reference list.
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getAttribute_SubscribingFederates()
	 * @see org.eodisp.hla.crc.data.Federate#getSubscribedAttributes
	 * @model type="org.eodisp.hla.crc.data.Federate" opposite="subscribedAttributes" transient="true"
	 * @generated
	 */
	EList getSubscribingFederates();

	/**
	 * Returns the value of the '<em><b>Publishing Federates</b></em>' reference list.
	 * The list contents are of type {@link org.eodisp.hla.crc.data.Federate}.
	 * It is bidirectional and its opposite is '{@link org.eodisp.hla.crc.data.Federate#getPublishedAttributes <em>Published Attributes</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Publishing Federates</em>' reference list
	 * isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Publishing Federates</em>' reference list.
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getAttribute_PublishingFederates()
	 * @see org.eodisp.hla.crc.data.Federate#getPublishedAttributes
	 * @model type="org.eodisp.hla.crc.data.Federate" opposite="publishedAttributes" transient="true"
	 * @generated
	 */
	EList getPublishingFederates();

} // Attribute
