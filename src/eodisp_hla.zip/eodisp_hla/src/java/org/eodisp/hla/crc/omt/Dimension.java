/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt;

import java.util.List;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Dimension</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.Dimension#getDataType <em>Data Type</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Dimension#getDataTypeNotes <em>Data Type Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Dimension#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Dimension#getNameNotes <em>Name Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Dimension#getNormalization <em>Normalization</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Dimension#getNormalizationNotes <em>Normalization Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Dimension#getUpperBound <em>Upper Bound</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Dimension#getUpperBoundNotes <em>Upper Bound Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Dimension#getValue <em>Value</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Dimension#getValueNotes <em>Value Notes</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eodisp.hla.crc.omt.OmtPackage#getDimension()
 * @model extendedMetaData="name='Dimension' kind='empty'"
 * @generated
 */
public interface Dimension extends EObject {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * Returns the value of the '<em><b>Data Type</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Data Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Data Type</em>' attribute.
	 * @see #setDataType(String)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getDimension_DataType()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKEN"
	 *        extendedMetaData="kind='attribute' name='dataType'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	String getDataType();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Dimension#getDataType <em>Data Type</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Data Type</em>' attribute.
	 * @see #getDataType()
	 * @generated
	 */
	void setDataType(String value);

	/**
	 * Returns the value of the '<em><b>Data Type Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Data Type Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Data Type Notes</em>' attribute.
	 * @see #setDataTypeNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getDimension_DataTypeNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='dataTypeNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getDataTypeNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Dimension#getDataTypeNotes <em>Data Type Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Data Type Notes</em>' attribute.
	 * @see #getDataTypeNotes()
	 * @generated
	 */
	void setDataTypeNotes(List value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getDimension_Name()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKEN"
	 *        required="true" extendedMetaData="kind='attribute' name='name'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Dimension#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Name Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name Notes</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name Notes</em>' attribute.
	 * @see #setNameNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getDimension_NameNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='nameNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getNameNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Dimension#getNameNotes <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name Notes</em>' attribute.
	 * @see #getNameNotes()
	 * @generated
	 */
	void setNameNotes(List value);

	/**
	 * Returns the value of the '<em><b>Normalization</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Normalization</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Normalization</em>' attribute.
	 * @see #setNormalization(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getDimension_Normalization()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='normalization' namespace='##targetNamespace'"
	 * @generated
	 */
	Object getNormalization();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Dimension#getNormalization <em>Normalization</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Normalization</em>' attribute.
	 * @see #getNormalization()
	 * @generated
	 */
	void setNormalization(Object value);

	/**
	 * Returns the value of the '<em><b>Normalization Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Normalization Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Normalization Notes</em>' attribute.
	 * @see #setNormalizationNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getDimension_NormalizationNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='normalizationNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getNormalizationNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Dimension#getNormalizationNotes <em>Normalization Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Normalization Notes</em>' attribute.
	 * @see #getNormalizationNotes()
	 * @generated
	 */
	void setNormalizationNotes(List value);

	/**
	 * Returns the value of the '<em><b>Upper Bound</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Upper Bound</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Upper Bound</em>' attribute.
	 * @see #setUpperBound(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getDimension_UpperBound()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='upperBound' namespace='##targetNamespace'"
	 * @generated
	 */
	Object getUpperBound();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Dimension#getUpperBound <em>Upper Bound</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Upper Bound</em>' attribute.
	 * @see #getUpperBound()
	 * @generated
	 */
	void setUpperBound(Object value);

	/**
	 * Returns the value of the '<em><b>Upper Bound Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Upper Bound Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Upper Bound Notes</em>' attribute.
	 * @see #setUpperBoundNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getDimension_UpperBoundNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='upperBoundNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getUpperBoundNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Dimension#getUpperBoundNotes <em>Upper Bound Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Upper Bound Notes</em>' attribute.
	 * @see #getUpperBoundNotes()
	 * @generated
	 */
	void setUpperBoundNotes(List value);

	/**
	 * Returns the value of the '<em><b>Value</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Value</em>' attribute isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Value</em>' attribute.
	 * @see #setValue(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getDimension_Value()
	 * @model unique="false"
	 *        dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='value'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	Object getValue();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Dimension#getValue <em>Value</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Value</em>' attribute.
	 * @see #getValue()
	 * @generated
	 */
	void setValue(Object value);

	/**
	 * Returns the value of the '<em><b>Value Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Value Notes</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Value Notes</em>' attribute.
	 * @see #setValueNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getDimension_ValueNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='valueNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getValueNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Dimension#getValueNotes <em>Value Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Value Notes</em>' attribute.
	 * @see #getValueNotes()
	 * @generated
	 */
	void setValueNotes(List value);

} // Dimension
