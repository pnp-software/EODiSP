package org.eodisp.hla.common.handles;

import hla.rti1516.AttributeSetRegionSetPairList;
import hla.rti1516.AttributeSetRegionSetPairListFactory;

public class AttributeSetRegionSetPairListFactoryImpl implements
		AttributeSetRegionSetPairListFactory {

	public AttributeSetRegionSetPairList create(int capacity) {
		return new AttributeSetRegionSetPairListImpl(capacity);
	}
}
