/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt;

import java.util.List;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Object Model</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getObjects <em>Objects</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getInteractions <em>Interactions</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getDimensions <em>Dimensions</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getTime <em>Time</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getTags <em>Tags</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getSynchronizations <em>Synchronizations</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getTransportations <em>Transportations</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getSwitches <em>Switches</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getDataTypes <em>Data Types</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getNotes <em>Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getAppDomain <em>App Domain</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getAppDomainNotes <em>App Domain Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getDate <em>Date</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getDateNotes <em>Date Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getDTDversion <em>DT Dversion</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getNameNotes <em>Name Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getOther <em>Other</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getOtherNotes <em>Other Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getPocEmail <em>Poc Email</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getPocEmailNotes <em>Poc Email Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getPocName <em>Poc Name</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getPocNameNotes <em>Poc Name Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getPocOrg <em>Poc Org</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getPocOrgNotes <em>Poc Org Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getPocPhone <em>Poc Phone</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getPocPhoneNotes <em>Poc Phone Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getPurpose <em>Purpose</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getPurposeNotes <em>Purpose Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getReferences <em>References</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getReferencesNotes <em>References Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getSponsor <em>Sponsor</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getSponsorNotes <em>Sponsor Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getType <em>Type</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getTypeNotes <em>Type Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getVersion <em>Version</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectModel#getVersionNotes <em>Version Notes</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel()
 * @model extendedMetaData="name='ObjectModel' kind='elementOnly'"
 * @generated
 */
public interface ObjectModel extends EObject {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * Returns the value of the '<em><b>Objects</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Objects</em>' containment reference isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Objects</em>' containment reference.
	 * @see #setObjects(Objects)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_Objects()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='objects' namespace='##targetNamespace'"
	 * @generated
	 */
	Objects getObjects();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getObjects <em>Objects</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Objects</em>' containment reference.
	 * @see #getObjects()
	 * @generated
	 */
	void setObjects(Objects value);

	/**
	 * Returns the value of the '<em><b>Interactions</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Interactions</em>' containment reference
	 * isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Interactions</em>' containment reference.
	 * @see #setInteractions(Interactions)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_Interactions()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='interactions' namespace='##targetNamespace'"
	 * @generated
	 */
	Interactions getInteractions();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getInteractions <em>Interactions</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Interactions</em>' containment reference.
	 * @see #getInteractions()
	 * @generated
	 */
	void setInteractions(Interactions value);

	/**
	 * Returns the value of the '<em><b>Dimensions</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Dimensions</em>' containment reference
	 * isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dimensions</em>' containment reference.
	 * @see #setDimensions(Dimensions)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_Dimensions()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='dimensions' namespace='##targetNamespace'"
	 * @generated
	 */
	Dimensions getDimensions();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getDimensions <em>Dimensions</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Dimensions</em>' containment reference.
	 * @see #getDimensions()
	 * @generated
	 */
	void setDimensions(Dimensions value);

	/**
	 * Returns the value of the '<em><b>Time</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Time</em>' containment reference isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Time</em>' containment reference.
	 * @see #setTime(Time)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_Time()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='time' namespace='##targetNamespace'"
	 * @generated
	 */
	Time getTime();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getTime <em>Time</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Time</em>' containment reference.
	 * @see #getTime()
	 * @generated
	 */
	void setTime(Time value);

	/**
	 * Returns the value of the '<em><b>Tags</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Tags</em>' containment reference isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Tags</em>' containment reference.
	 * @see #setTags(Tags)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_Tags()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='tags' namespace='##targetNamespace'"
	 * @generated
	 */
	Tags getTags();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getTags <em>Tags</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Tags</em>' containment reference.
	 * @see #getTags()
	 * @generated
	 */
	void setTags(Tags value);

	/**
	 * Returns the value of the '<em><b>Synchronizations</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Synchronizations</em>' containment
	 * reference isn't clear, there really should be more of a description
	 * here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Synchronizations</em>' containment reference.
	 * @see #setSynchronizations(Synchronizations)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_Synchronizations()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='synchronizations' namespace='##targetNamespace'"
	 * @generated
	 */
	Synchronizations getSynchronizations();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getSynchronizations <em>Synchronizations</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Synchronizations</em>' containment reference.
	 * @see #getSynchronizations()
	 * @generated
	 */
	void setSynchronizations(Synchronizations value);

	/**
	 * Returns the value of the '<em><b>Transportations</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Transportations</em>' containment
	 * reference isn't clear, there really should be more of a description
	 * here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transportations</em>' containment reference.
	 * @see #setTransportations(Transportations)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_Transportations()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='transportations' namespace='##targetNamespace'"
	 * @generated
	 */
	Transportations getTransportations();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getTransportations <em>Transportations</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Transportations</em>' containment reference.
	 * @see #getTransportations()
	 * @generated
	 */
	void setTransportations(Transportations value);

	/**
	 * Returns the value of the '<em><b>Switches</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Switches</em>' containment reference isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Switches</em>' containment reference.
	 * @see #setSwitches(Switches)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_Switches()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='switches' namespace='##targetNamespace'"
	 * @generated
	 */
	Switches getSwitches();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getSwitches <em>Switches</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Switches</em>' containment reference.
	 * @see #getSwitches()
	 * @generated
	 */
	void setSwitches(Switches value);

	/**
	 * Returns the value of the '<em><b>Data Types</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Data Types</em>' containment reference
	 * isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Data Types</em>' containment reference.
	 * @see #setDataTypes(DataTypes)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_DataTypes()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='dataTypes' namespace='##targetNamespace'"
	 * @generated
	 */
	DataTypes getDataTypes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getDataTypes <em>Data Types</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Data Types</em>' containment reference.
	 * @see #getDataTypes()
	 * @generated
	 */
	void setDataTypes(DataTypes value);

	/**
	 * Returns the value of the '<em><b>Notes</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Notes</em>' containment reference isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Notes</em>' containment reference.
	 * @see #setNotes(Notes)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_Notes()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='notes' namespace='##targetNamespace'"
	 * @generated
	 */
	Notes getNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getNotes <em>Notes</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Notes</em>' containment reference.
	 * @see #getNotes()
	 * @generated
	 */
	void setNotes(Notes value);

	/**
	 * Returns the value of the '<em><b>App Domain</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>App Domain</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>App Domain</em>' attribute.
	 * @see #setAppDomain(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_AppDomain()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='appDomain' namespace='##targetNamespace'"
	 * @generated
	 */
	Object getAppDomain();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getAppDomain <em>App Domain</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>App Domain</em>' attribute.
	 * @see #getAppDomain()
	 * @generated
	 */
	void setAppDomain(Object value);

	/**
	 * Returns the value of the '<em><b>App Domain Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>App Domain Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>App Domain Notes</em>' attribute.
	 * @see #setAppDomainNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_AppDomainNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='appDomainNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getAppDomainNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getAppDomainNotes <em>App Domain Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>App Domain Notes</em>' attribute.
	 * @see #getAppDomainNotes()
	 * @generated
	 */
	void setAppDomainNotes(List value);

	/**
	 * Returns the value of the '<em><b>Date</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Date</em>' attribute isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Date</em>' attribute.
	 * @see #setDate(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_Date()
	 * @model unique="false"
	 *        dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='date'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	Object getDate();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getDate <em>Date</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Date</em>' attribute.
	 * @see #getDate()
	 * @generated
	 */
	void setDate(Object value);

	/**
	 * Returns the value of the '<em><b>Date Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Date Notes</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Date Notes</em>' attribute.
	 * @see #setDateNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_DateNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='dateNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getDateNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getDateNotes <em>Date Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Date Notes</em>' attribute.
	 * @see #getDateNotes()
	 * @generated
	 */
	void setDateNotes(List value);

	/**
	 * Returns the value of the '<em><b>DT Dversion</b></em>' attribute.
	 * The default value is <code>"1516.2"</code>.
	 * The literals are from the enumeration {@link org.eodisp.hla.crc.omt.DTDVersionEnum}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>DT Dversion</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>DT Dversion</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.DTDVersionEnum
	 * @see #isSetDTDversion()
	 * @see #unsetDTDversion()
	 * @see #setDTDversion(DTDVersionEnum)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_DTDversion()
	 * @model default="1516.2" unique="false" unsettable="true"
	 *        extendedMetaData="kind='attribute' name='DTDversion' namespace='##targetNamespace'"
	 * @generated
	 */
	DTDVersionEnum getDTDversion();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getDTDversion <em>DT Dversion</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>DT Dversion</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.DTDVersionEnum
	 * @see #isSetDTDversion()
	 * @see #unsetDTDversion()
	 * @see #getDTDversion()
	 * @generated
	 */
	void setDTDversion(DTDVersionEnum value);

	/**
	 * Unsets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getDTDversion <em>DT Dversion</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #isSetDTDversion()
	 * @see #getDTDversion()
	 * @see #setDTDversion(DTDVersionEnum)
	 * @generated
	 */
	void unsetDTDversion();

	/**
	 * Returns whether the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getDTDversion <em>DT Dversion</em>}' attribute is set.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return whether the value of the '<em>DT Dversion</em>' attribute is set.
	 * @see #unsetDTDversion()
	 * @see #getDTDversion()
	 * @see #setDTDversion(DTDVersionEnum)
	 * @generated
	 */
	boolean isSetDTDversion();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_Name()
	 * @model unique="false"
	 *        dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        required="true" extendedMetaData="kind='attribute' name='name'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	Object getName();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(Object value);

	/**
	 * Returns the value of the '<em><b>Name Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name Notes</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name Notes</em>' attribute.
	 * @see #setNameNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_NameNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='nameNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getNameNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getNameNotes <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name Notes</em>' attribute.
	 * @see #getNameNotes()
	 * @generated
	 */
	void setNameNotes(List value);

	/**
	 * Returns the value of the '<em><b>Other</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Other</em>' attribute isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Other</em>' attribute.
	 * @see #setOther(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_Other()
	 * @model unique="false"
	 *        dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='other'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	Object getOther();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getOther <em>Other</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Other</em>' attribute.
	 * @see #getOther()
	 * @generated
	 */
	void setOther(Object value);

	/**
	 * Returns the value of the '<em><b>Other Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Other Notes</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Other Notes</em>' attribute.
	 * @see #setOtherNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_OtherNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='otherNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getOtherNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getOtherNotes <em>Other Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Other Notes</em>' attribute.
	 * @see #getOtherNotes()
	 * @generated
	 */
	void setOtherNotes(List value);

	/**
	 * Returns the value of the '<em><b>Poc Email</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Poc Email</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Poc Email</em>' attribute.
	 * @see #setPocEmail(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_PocEmail()
	 * @model unique="false"
	 *        dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='pocEmail'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	Object getPocEmail();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getPocEmail <em>Poc Email</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Poc Email</em>' attribute.
	 * @see #getPocEmail()
	 * @generated
	 */
	void setPocEmail(Object value);

	/**
	 * Returns the value of the '<em><b>Poc Email Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Poc Email Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Poc Email Notes</em>' attribute.
	 * @see #setPocEmailNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_PocEmailNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='pocEmailNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getPocEmailNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getPocEmailNotes <em>Poc Email Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Poc Email Notes</em>' attribute.
	 * @see #getPocEmailNotes()
	 * @generated
	 */
	void setPocEmailNotes(List value);

	/**
	 * Returns the value of the '<em><b>Poc Name</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Poc Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Poc Name</em>' attribute.
	 * @see #setPocName(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_PocName()
	 * @model unique="false"
	 *        dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='pocName'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	Object getPocName();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getPocName <em>Poc Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Poc Name</em>' attribute.
	 * @see #getPocName()
	 * @generated
	 */
	void setPocName(Object value);

	/**
	 * Returns the value of the '<em><b>Poc Name Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Poc Name Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Poc Name Notes</em>' attribute.
	 * @see #setPocNameNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_PocNameNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='pocNameNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getPocNameNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getPocNameNotes <em>Poc Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Poc Name Notes</em>' attribute.
	 * @see #getPocNameNotes()
	 * @generated
	 */
	void setPocNameNotes(List value);

	/**
	 * Returns the value of the '<em><b>Poc Org</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Poc Org</em>' attribute isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Poc Org</em>' attribute.
	 * @see #setPocOrg(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_PocOrg()
	 * @model unique="false"
	 *        dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='pocOrg'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	Object getPocOrg();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getPocOrg <em>Poc Org</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Poc Org</em>' attribute.
	 * @see #getPocOrg()
	 * @generated
	 */
	void setPocOrg(Object value);

	/**
	 * Returns the value of the '<em><b>Poc Org Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Poc Org Notes</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Poc Org Notes</em>' attribute.
	 * @see #setPocOrgNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_PocOrgNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='pocOrgNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getPocOrgNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getPocOrgNotes <em>Poc Org Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Poc Org Notes</em>' attribute.
	 * @see #getPocOrgNotes()
	 * @generated
	 */
	void setPocOrgNotes(List value);

	/**
	 * Returns the value of the '<em><b>Poc Phone</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Poc Phone</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Poc Phone</em>' attribute.
	 * @see #setPocPhone(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_PocPhone()
	 * @model unique="false"
	 *        dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='pocPhone'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	Object getPocPhone();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getPocPhone <em>Poc Phone</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Poc Phone</em>' attribute.
	 * @see #getPocPhone()
	 * @generated
	 */
	void setPocPhone(Object value);

	/**
	 * Returns the value of the '<em><b>Poc Phone Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Poc Phone Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Poc Phone Notes</em>' attribute.
	 * @see #setPocPhoneNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_PocPhoneNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='pocPhoneNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getPocPhoneNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getPocPhoneNotes <em>Poc Phone Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Poc Phone Notes</em>' attribute.
	 * @see #getPocPhoneNotes()
	 * @generated
	 */
	void setPocPhoneNotes(List value);

	/**
	 * Returns the value of the '<em><b>Purpose</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Purpose</em>' attribute isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Purpose</em>' attribute.
	 * @see #setPurpose(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_Purpose()
	 * @model unique="false"
	 *        dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='purpose'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	Object getPurpose();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getPurpose <em>Purpose</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Purpose</em>' attribute.
	 * @see #getPurpose()
	 * @generated
	 */
	void setPurpose(Object value);

	/**
	 * Returns the value of the '<em><b>Purpose Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Purpose Notes</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Purpose Notes</em>' attribute.
	 * @see #setPurposeNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_PurposeNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='purposeNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getPurposeNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getPurposeNotes <em>Purpose Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Purpose Notes</em>' attribute.
	 * @see #getPurposeNotes()
	 * @generated
	 */
	void setPurposeNotes(List value);

	/**
	 * Returns the value of the '<em><b>References</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>References</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>References</em>' attribute.
	 * @see #setReferences(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_References()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='references' namespace='##targetNamespace'"
	 * @generated
	 */
	Object getReferences();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getReferences <em>References</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>References</em>' attribute.
	 * @see #getReferences()
	 * @generated
	 */
	void setReferences(Object value);

	/**
	 * Returns the value of the '<em><b>References Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>References Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>References Notes</em>' attribute.
	 * @see #setReferencesNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_ReferencesNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='referencesNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getReferencesNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getReferencesNotes <em>References Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>References Notes</em>' attribute.
	 * @see #getReferencesNotes()
	 * @generated
	 */
	void setReferencesNotes(List value);

	/**
	 * Returns the value of the '<em><b>Sponsor</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sponsor</em>' attribute isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Sponsor</em>' attribute.
	 * @see #setSponsor(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_Sponsor()
	 * @model unique="false"
	 *        dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='sponsor'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	Object getSponsor();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getSponsor <em>Sponsor</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sponsor</em>' attribute.
	 * @see #getSponsor()
	 * @generated
	 */
	void setSponsor(Object value);

	/**
	 * Returns the value of the '<em><b>Sponsor Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sponsor Notes</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sponsor Notes</em>' attribute.
	 * @see #setSponsorNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_SponsorNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='sponsorNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSponsorNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getSponsorNotes <em>Sponsor Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sponsor Notes</em>' attribute.
	 * @see #getSponsorNotes()
	 * @generated
	 */
	void setSponsorNotes(List value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute. The
	 * default value is <code>"FOM"</code>. The literals are from the
	 * enumeration {@link org.eodisp.hla.crc.omt.ObjectModelTypeEnum}. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' attribute isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.ObjectModelTypeEnum
	 * @see #isSetType()
	 * @see #unsetType()
	 * @see #setType(ObjectModelTypeEnum)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_Type()
	 * @model default="FOM" unique="false" unsettable="true" required="true"
	 *        extendedMetaData="kind='attribute' name='type'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	ObjectModelTypeEnum getType();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.ObjectModelTypeEnum
	 * @see #isSetType()
	 * @see #unsetType()
	 * @see #getType()
	 * @generated
	 */
	void setType(ObjectModelTypeEnum value);

	/**
	 * Unsets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #isSetType()
	 * @see #getType()
	 * @see #setType(ObjectModelTypeEnum)
	 * @generated
	 */
	void unsetType();

	/**
	 * Returns whether the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getType <em>Type</em>}' attribute is set.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return whether the value of the '<em>Type</em>' attribute is set.
	 * @see #unsetType()
	 * @see #getType()
	 * @see #setType(ObjectModelTypeEnum)
	 * @generated
	 */
	boolean isSetType();

	/**
	 * Returns the value of the '<em><b>Type Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type Notes</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type Notes</em>' attribute.
	 * @see #setTypeNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_TypeNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='typeNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getTypeNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getTypeNotes <em>Type Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type Notes</em>' attribute.
	 * @see #getTypeNotes()
	 * @generated
	 */
	void setTypeNotes(List value);

	/**
	 * Returns the value of the '<em><b>Version</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Version</em>' attribute isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Version</em>' attribute.
	 * @see #setVersion(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_Version()
	 * @model unique="false"
	 *        dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='version'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	Object getVersion();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getVersion <em>Version</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Version</em>' attribute.
	 * @see #getVersion()
	 * @generated
	 */
	void setVersion(Object value);

	/**
	 * Returns the value of the '<em><b>Version Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Version Notes</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Version Notes</em>' attribute.
	 * @see #setVersionNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectModel_VersionNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='versionNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getVersionNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectModel#getVersionNotes <em>Version Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Version Notes</em>' attribute.
	 * @see #getVersionNotes()
	 * @generated
	 */
	void setVersionNotes(List value);

} // ObjectModel
