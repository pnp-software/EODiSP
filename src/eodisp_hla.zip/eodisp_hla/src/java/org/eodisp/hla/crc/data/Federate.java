/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.data;

import hla.rti1516.FederateHandle;

import java.util.Set;

import hla.rti1516.*;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

import org.eodisp.hla.common.lrc.LrcHandle;

import org.eodisp.hla.common.lrc.LrcRemote;

import org.eodisp.hla.crc.FederationExecution;
import org.eodisp.hla.crc.omt.Attribute;
import org.eodisp.hla.crc.omt.ObjectClass;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Federate</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.data.Federate#getRegisteredObjectInstances <em>Registered Object Instances</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.data.Federate#getSubscribedAttributes <em>Subscribed Attributes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.data.Federate#getSubscribedInteractions <em>Subscribed Interactions</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.data.Federate#getPublishedAttributes <em>Published Attributes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.data.Federate#getPublishedInteractions <em>Published Interactions</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.data.Federate#getLrcHandle <em>Lrc Handle</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.data.Federate#getHandle <em>Handle</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.data.Federate#getFederationExecution <em>Federation Execution</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.data.Federate#getPublishedObjectClasses <em>Published Object Classes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.data.Federate#getSubscribedObjectClasses <em>Subscribed Object Classes</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eodisp.hla.crc.data.DataPackage#getFederate()
 * @model
 * @generated
 */
public interface Federate extends EObject {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * Returns the value of the '<em><b>Registered Object Instances</b></em>' containment reference list.
	 * The list contents are of type {@link org.eodisp.hla.crc.data.ObjectInstance}.
	 * It is bidirectional and its opposite is '{@link org.eodisp.hla.crc.data.ObjectInstance#getRegisteringFederate <em>Registering Federate</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Registered Object Instances</em>'
	 * containment reference list isn't clear, there really should be more of a
	 * description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Registered Object Instances</em>' containment reference list.
	 * @see org.eodisp.hla.crc.data.DataPackage#getFederate_RegisteredObjectInstances()
	 * @see org.eodisp.hla.crc.data.ObjectInstance#getRegisteringFederate
	 * @model type="org.eodisp.hla.crc.data.ObjectInstance" opposite="registeringFederate" containment="true"
	 * @generated
	 */
	EList getRegisteredObjectInstances();

	/**
	 * Returns the value of the '<em><b>Subscribed Attributes</b></em>' reference list.
	 * The list contents are of type {@link org.eodisp.hla.crc.omt.Attribute}.
	 * It is bidirectional and its opposite is '{@link org.eodisp.hla.crc.omt.Attribute#getSubscribingFederates <em>Subscribing Federates</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Subscribed Attributes</em>' reference list
	 * isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Subscribed Attributes</em>' reference list.
	 * @see org.eodisp.hla.crc.data.DataPackage#getFederate_SubscribedAttributes()
	 * @see org.eodisp.hla.crc.omt.Attribute#getSubscribingFederates
	 * @model type="org.eodisp.hla.crc.omt.Attribute" opposite="subscribingFederates"
	 * @generated
	 */
	EList getSubscribedAttributes();

	/**
	 * Returns the value of the '<em><b>Subscribed Interactions</b></em>' reference list.
	 * The list contents are of type {@link org.eodisp.hla.crc.omt.InteractionClass}.
	 * It is bidirectional and its opposite is '{@link org.eodisp.hla.crc.omt.InteractionClass#getSubscribingFederates <em>Subscribing Federates</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Subscribed Interactions</em>' reference
	 * list isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Subscribed Interactions</em>' reference list.
	 * @see org.eodisp.hla.crc.data.DataPackage#getFederate_SubscribedInteractions()
	 * @see org.eodisp.hla.crc.omt.InteractionClass#getSubscribingFederates
	 * @model type="org.eodisp.hla.crc.omt.InteractionClass" opposite="subscribingFederates"
	 * @generated
	 */
	EList getSubscribedInteractions();

	/**
	 * Returns the value of the '<em><b>Published Attributes</b></em>' reference list.
	 * The list contents are of type {@link org.eodisp.hla.crc.omt.Attribute}.
	 * It is bidirectional and its opposite is '{@link org.eodisp.hla.crc.omt.Attribute#getPublishingFederates <em>Publishing Federates</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Published Attributes</em>' reference list
	 * isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Published Attributes</em>' reference list.
	 * @see org.eodisp.hla.crc.data.DataPackage#getFederate_PublishedAttributes()
	 * @see org.eodisp.hla.crc.omt.Attribute#getPublishingFederates
	 * @model type="org.eodisp.hla.crc.omt.Attribute" opposite="publishingFederates"
	 * @generated
	 */
	EList getPublishedAttributes();

	/**
	 * Returns the value of the '<em><b>Published Interactions</b></em>' reference list.
	 * The list contents are of type {@link org.eodisp.hla.crc.omt.InteractionClass}.
	 * It is bidirectional and its opposite is '{@link org.eodisp.hla.crc.omt.InteractionClass#getPublishingFederates <em>Publishing Federates</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Published Interactions</em>' reference
	 * list isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Published Interactions</em>' reference list.
	 * @see org.eodisp.hla.crc.data.DataPackage#getFederate_PublishedInteractions()
	 * @see org.eodisp.hla.crc.omt.InteractionClass#getPublishingFederates
	 * @model type="org.eodisp.hla.crc.omt.InteractionClass" opposite="publishingFederates"
	 * @generated
	 */
	EList getPublishedInteractions();

	/**
	 * Returns the value of the '<em><b>Lrc Handle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Lrc Handle</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Lrc Handle</em>' attribute.
	 * @see #setLrcHandle(LrcHandle)
	 * @see org.eodisp.hla.crc.data.DataPackage#getFederate_LrcHandle()
	 * @model dataType="org.eodisp.hla.crc.data.ELrcHandle" transient="true"
	 * @generated
	 */
	LrcHandle getLrcHandle();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.data.Federate#getLrcHandle <em>Lrc Handle</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Lrc Handle</em>' attribute.
	 * @see #getLrcHandle()
	 * @generated
	 */
	void setLrcHandle(LrcHandle value);

	/**
	 * Returns the value of the '<em><b>Handle</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Handle</em>' attribute isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Handle</em>' attribute.
	 * @see #setHandle(FederateHandle)
	 * @see org.eodisp.hla.crc.data.DataPackage#getFederate_Handle()
	 * @model dataType="org.eodisp.hla.crc.data.EFederateHandle"
	 * @generated
	 */
	FederateHandle getHandle();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.data.Federate#getHandle <em>Handle</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Handle</em>' attribute.
	 * @see #getHandle()
	 * @generated
	 */
	void setHandle(FederateHandle value);

	/**
	 * Returns the value of the '<em><b>Federation Execution</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Federation Execution</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Federation Execution</em>' attribute.
	 * @see #setFederationExecution(FederationExecution)
	 * @see org.eodisp.hla.crc.data.DataPackage#getFederate_FederationExecution()
	 * @model dataType="org.eodisp.hla.crc.data.EFederationExecution"
	 * @generated
	 */
	FederationExecution getFederationExecution();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.data.Federate#getFederationExecution <em>Federation Execution</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Federation Execution</em>' attribute.
	 * @see #getFederationExecution()
	 * @generated
	 */
	void setFederationExecution(FederationExecution value);

	/**
	 * Returns the value of the '<em><b>Published Object Classes</b></em>' reference list.
	 * The list contents are of type {@link org.eodisp.hla.crc.omt.ObjectClass}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Published Object Classes</em>' reference
	 * list isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Published Object Classes</em>' reference list.
	 * @see org.eodisp.hla.crc.data.DataPackage#getFederate_PublishedObjectClasses()
	 * @model type="org.eodisp.hla.crc.omt.ObjectClass" transient="true" changeable="false" volatile="true" ordered="false"
	 * @generated
	 */
	EList getPublishedObjectClasses();

	/**
	 * Returns the value of the '<em><b>Subscribed Object Classes</b></em>' reference list.
	 * The list contents are of type {@link org.eodisp.hla.crc.omt.ObjectClass}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Subscribed Object Classes</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Subscribed Object Classes</em>' reference list.
	 * @see org.eodisp.hla.crc.data.DataPackage#getFederate_SubscribedObjectClasses()
	 * @model type="org.eodisp.hla.crc.omt.ObjectClass" transient="true" changeable="false" volatile="true" ordered="false"
	 * @generated
	 */
	EList getSubscribedObjectClasses();

	/**
	 * Checks if the given object class is published by this federate, throws an
	 * <code>ObjectClassNotPublished</code> otherwise.
	 * 
	 * @param objectClass
	 *            the object class to be checked for publiscation on this
	 *            federate
	 * @throws ObjectClassNotPublished
	 *             if the given object class is not published by this federate
	 * 
	 * @generated not
	 */
	void checkPublication(ObjectClass objectClass) throws ObjectClassNotPublished;

	/**
	 * Checks if the given attributes are published by this federate, throws a
	 * <code>AttributeNotPublished</code> exception otherwise.
	 * 
	 * @param attributes
	 *            the attributes to be checked for publication on this federate
	 * @throws AttributeNotPublished
	 *             if this federate is not publishing the given attributes
	 */
	void checkPublication(Set<Attribute> attributes) throws AttributeNotPublished;

	/**
	 * Returns true if this federate owns all of the given attributes. Currently
	 * this method tests if the given object instance has been registered by
	 * this federate. This is enough because it is not possible to aquire
	 * ownership for another federate if one federate has registered an object
	 * instance. This may change in the future, when more HLA service are
	 * implemented, in particular
	 * {@link RTIambassador#attributeOwnershipAcquisition(ObjectInstanceHandle, AttributeHandleSet, byte[])}.
	 * Note that this method declaration does not need be changed for this.
	 * 
	 * @param objectInstance
	 *            the object instance of that is registered for the given
	 *            attributes
	 * @param attributes
	 *            the attributes of the given object instance that shall be
	 *            checked for ownership on this federate.
	 * @return true if this federate owns all of the given attributes of the
	 *         given object instance
	 */
	boolean ownsAttributes(ObjectInstance objectInstance, Set<Attribute> attributes);

	/**
	 * Returns true if this federate owns at least one attribute, otherwise
	 * returns false. Currently this method tests if any object instance has
	 * been registered by this federate. This is enough because it is not
	 * possible to aquire ownership for another federate if one federate has
	 * registered an object instance. This may change in the future, when more
	 * HLA service are implemented, in particular if the service
	 * {@link RTIambassador#attributeOwnershipAcquisition(ObjectInstanceHandle, AttributeHandleSet, byte[])}
	 * is implemented. Note that this method declaration does not need be
	 * changed for this.
	 * 
	 * @return true if this federate owns at least one attribute, otherwise
	 *         returns false.
	 */
	boolean ownsAttributes();

} // Federate
