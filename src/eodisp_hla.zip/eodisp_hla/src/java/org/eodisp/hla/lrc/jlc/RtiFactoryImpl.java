/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com
 *  mail: info@pnp-software.com
 */
package org.eodisp.hla.lrc.jlc;

import hla.rti1516.RTIambassador;
import hla.rti1516.RTIinternalError;
import hla.rti1516.jlc.RtiFactory;

import java.net.URISyntaxException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

import org.eodisp.hla.lrc.application.*;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.RootApp;
import org.eodisp.util.RootApp.RunState;
import org.eodisp.util.configuration.ConfigurationException;

/**
 * Implementation of the RtiFactory as it is defined in the 'Dynamic Link
 * Compatible HLA API'.
 * 
 * @see <a
 *      href="http://www.sisostds.org/index.php?tg=fileman&idx=get&id=5&gr=Y&path=SISO+Products%2FSISO+Standards&file=SISO-STD-004.1-2004-Final.pdf">SISO-STD-004.1-2004.pdf</a>
 * 
 * @author ibirrer
 * @version $Id: ERTIFactory.java 1631 2006-03-08 13:59:11Z ibirrer $
 * 
 */
public class RtiFactoryImpl implements RtiFactory {
	/**
	 * Creates and returns a new RtiAmbassador for each call of this method. An
	 * RtiAmbassador can only be used by one federate and one federate must
	 * always use the same RtiAmbassador instance.
	 * 
	 * 
	 * 
	 * @return A newly created RtiAmbassador
	 * @throws RTIinternalError
	 *             if the CRC URI (given by the {@link LrcConfiguration}) is
	 *             not a valid URI or if connecting to the CRC is not possible.
	 */
	public RTIambassador getRtiAmbassador() throws RTIinternalError {
		RootApp rootApp = AppRegistry.getRootApp();
		if (rootApp == null) {
			rootApp = new LrcApplication();
			rootApp.execute(new String[0]);
		} else if (rootApp.getAppModule(LrcAppModule.ID) == null) {
			/*
			 * The root application has already been created but does not yet
			 * contain the Lrc specific application modules, so we just add them
			 * and start the modules which are not yet initialized.
			 */
			LrcApplication.registerLrcModules(rootApp);
			rootApp.executeAdditionalAppModules();
		}

		try {
			LrcAppModule lrcAppModule = (LrcAppModule) rootApp.getAppModule(LrcAppModule.ID);
			return lrcAppModule.getLrc().createRtiAmbassador();
		} catch (RemoteException e) {
			try {
				LrcConfiguration lrcConfig = (LrcConfiguration) rootApp.getConfiguration(LrcConfiguration.ID);

				throw new RTIinternalError(String.format("Error while connecting to CRC with URI: %s", lrcConfig
						.getCrcUri()), e);
			} catch (URISyntaxException e1) {
				throw new RTIinternalError(String.format("Error while connecting to CRC", e));
			}
		} catch (ConfigurationException e) {
			throw new RTIinternalError("Configuration exception on startup", e);
		} catch (NotBoundException e) {
			throw new RTIinternalError("Connection Exception", e);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public String RtiName() {
		return "EODiSP RTI (Earth Observation Distributed Simulation Platform - Runtime Infrastructure)";
	}

	/**
	 * {@inheritDoc}
	 */
	public String RtiVersion() {
		// TODO check
		return "IEEE 1516";
	}

}
