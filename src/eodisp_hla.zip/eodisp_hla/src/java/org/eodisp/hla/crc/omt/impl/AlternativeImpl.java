/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt.impl;

import java.util.List;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eodisp.hla.crc.omt.Alternative;
import org.eodisp.hla.crc.omt.OmtPackage;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Alternative</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AlternativeImpl#getDataType <em>Data Type</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AlternativeImpl#getDataTypeNotes <em>Data Type Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AlternativeImpl#getEnumerator <em>Enumerator</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AlternativeImpl#getEnumeratorNotes <em>Enumerator Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AlternativeImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AlternativeImpl#getNameNotes <em>Name Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AlternativeImpl#getSemantics <em>Semantics</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AlternativeImpl#getSemanticsNotes <em>Semantics Notes</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class AlternativeImpl extends EObjectImpl implements Alternative {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The default value of the '{@link #getDataType() <em>Data Type</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDataType()
	 * @generated
	 * @ordered
	 */
	protected static final String DATA_TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDataType() <em>Data Type</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDataType()
	 * @generated
	 * @ordered
	 */
	protected String dataType = DATA_TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getDataTypeNotes() <em>Data Type Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDataTypeNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List DATA_TYPE_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDataTypeNotes() <em>Data Type Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDataTypeNotes()
	 * @generated
	 * @ordered
	 */
	protected List dataTypeNotes = DATA_TYPE_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getEnumerator() <em>Enumerator</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getEnumerator()
	 * @generated
	 * @ordered
	 */
	protected static final Object ENUMERATOR_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getEnumerator() <em>Enumerator</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getEnumerator()
	 * @generated
	 * @ordered
	 */
	protected Object enumerator = ENUMERATOR_EDEFAULT;

	/**
	 * The default value of the '{@link #getEnumeratorNotes() <em>Enumerator Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getEnumeratorNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List ENUMERATOR_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getEnumeratorNotes() <em>Enumerator Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getEnumeratorNotes()
	 * @generated
	 * @ordered
	 */
	protected List enumeratorNotes = ENUMERATOR_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getNameNotes() <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getNameNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List NAME_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNameNotes() <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getNameNotes()
	 * @generated
	 * @ordered
	 */
	protected List nameNotes = NAME_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getSemantics() <em>Semantics</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSemantics()
	 * @generated
	 * @ordered
	 */
	protected static final Object SEMANTICS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSemantics() <em>Semantics</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSemantics()
	 * @generated
	 * @ordered
	 */
	protected Object semantics = SEMANTICS_EDEFAULT;

	/**
	 * The default value of the '{@link #getSemanticsNotes() <em>Semantics Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSemanticsNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List SEMANTICS_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSemanticsNotes() <em>Semantics Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSemanticsNotes()
	 * @generated
	 * @ordered
	 */
	protected List semanticsNotes = SEMANTICS_NOTES_EDEFAULT;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected AlternativeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return OmtPackage.Literals.ALTERNATIVE;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String getDataType() {
		return dataType;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setDataType(String newDataType) {
		String oldDataType = dataType;
		dataType = newDataType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ALTERNATIVE__DATA_TYPE,
					oldDataType,
					dataType));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getDataTypeNotes() {
		return dataTypeNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setDataTypeNotes(List newDataTypeNotes) {
		List oldDataTypeNotes = dataTypeNotes;
		dataTypeNotes = newDataTypeNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ALTERNATIVE__DATA_TYPE_NOTES,
					oldDataTypeNotes,
					dataTypeNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getEnumerator() {
		return enumerator;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setEnumerator(Object newEnumerator) {
		Object oldEnumerator = enumerator;
		enumerator = newEnumerator;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ALTERNATIVE__ENUMERATOR,
					oldEnumerator,
					enumerator));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getEnumeratorNotes() {
		return enumeratorNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setEnumeratorNotes(List newEnumeratorNotes) {
		List oldEnumeratorNotes = enumeratorNotes;
		enumeratorNotes = newEnumeratorNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ALTERNATIVE__ENUMERATOR_NOTES,
					oldEnumeratorNotes,
					enumeratorNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OmtPackage.ALTERNATIVE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getNameNotes() {
		return nameNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setNameNotes(List newNameNotes) {
		List oldNameNotes = nameNotes;
		nameNotes = newNameNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ALTERNATIVE__NAME_NOTES,
					oldNameNotes,
					nameNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getSemantics() {
		return semantics;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setSemantics(Object newSemantics) {
		Object oldSemantics = semantics;
		semantics = newSemantics;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ALTERNATIVE__SEMANTICS,
					oldSemantics,
					semantics));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getSemanticsNotes() {
		return semanticsNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setSemanticsNotes(List newSemanticsNotes) {
		List oldSemanticsNotes = semanticsNotes;
		semanticsNotes = newSemanticsNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ALTERNATIVE__SEMANTICS_NOTES,
					oldSemanticsNotes,
					semanticsNotes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case OmtPackage.ALTERNATIVE__DATA_TYPE:
			return getDataType();
		case OmtPackage.ALTERNATIVE__DATA_TYPE_NOTES:
			return getDataTypeNotes();
		case OmtPackage.ALTERNATIVE__ENUMERATOR:
			return getEnumerator();
		case OmtPackage.ALTERNATIVE__ENUMERATOR_NOTES:
			return getEnumeratorNotes();
		case OmtPackage.ALTERNATIVE__NAME:
			return getName();
		case OmtPackage.ALTERNATIVE__NAME_NOTES:
			return getNameNotes();
		case OmtPackage.ALTERNATIVE__SEMANTICS:
			return getSemantics();
		case OmtPackage.ALTERNATIVE__SEMANTICS_NOTES:
			return getSemanticsNotes();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case OmtPackage.ALTERNATIVE__DATA_TYPE:
			setDataType((String) newValue);
			return;
		case OmtPackage.ALTERNATIVE__DATA_TYPE_NOTES:
			setDataTypeNotes((List) newValue);
			return;
		case OmtPackage.ALTERNATIVE__ENUMERATOR:
			setEnumerator((Object) newValue);
			return;
		case OmtPackage.ALTERNATIVE__ENUMERATOR_NOTES:
			setEnumeratorNotes((List) newValue);
			return;
		case OmtPackage.ALTERNATIVE__NAME:
			setName((String) newValue);
			return;
		case OmtPackage.ALTERNATIVE__NAME_NOTES:
			setNameNotes((List) newValue);
			return;
		case OmtPackage.ALTERNATIVE__SEMANTICS:
			setSemantics((Object) newValue);
			return;
		case OmtPackage.ALTERNATIVE__SEMANTICS_NOTES:
			setSemanticsNotes((List) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
		case OmtPackage.ALTERNATIVE__DATA_TYPE:
			setDataType(DATA_TYPE_EDEFAULT);
			return;
		case OmtPackage.ALTERNATIVE__DATA_TYPE_NOTES:
			setDataTypeNotes(DATA_TYPE_NOTES_EDEFAULT);
			return;
		case OmtPackage.ALTERNATIVE__ENUMERATOR:
			setEnumerator(ENUMERATOR_EDEFAULT);
			return;
		case OmtPackage.ALTERNATIVE__ENUMERATOR_NOTES:
			setEnumeratorNotes(ENUMERATOR_NOTES_EDEFAULT);
			return;
		case OmtPackage.ALTERNATIVE__NAME:
			setName(NAME_EDEFAULT);
			return;
		case OmtPackage.ALTERNATIVE__NAME_NOTES:
			setNameNotes(NAME_NOTES_EDEFAULT);
			return;
		case OmtPackage.ALTERNATIVE__SEMANTICS:
			setSemantics(SEMANTICS_EDEFAULT);
			return;
		case OmtPackage.ALTERNATIVE__SEMANTICS_NOTES:
			setSemanticsNotes(SEMANTICS_NOTES_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case OmtPackage.ALTERNATIVE__DATA_TYPE:
			return DATA_TYPE_EDEFAULT == null ? dataType != null : !DATA_TYPE_EDEFAULT.equals(dataType);
		case OmtPackage.ALTERNATIVE__DATA_TYPE_NOTES:
			return DATA_TYPE_NOTES_EDEFAULT == null ? dataTypeNotes != null : !DATA_TYPE_NOTES_EDEFAULT
					.equals(dataTypeNotes);
		case OmtPackage.ALTERNATIVE__ENUMERATOR:
			return ENUMERATOR_EDEFAULT == null ? enumerator != null : !ENUMERATOR_EDEFAULT.equals(enumerator);
		case OmtPackage.ALTERNATIVE__ENUMERATOR_NOTES:
			return ENUMERATOR_NOTES_EDEFAULT == null ? enumeratorNotes != null : !ENUMERATOR_NOTES_EDEFAULT
					.equals(enumeratorNotes);
		case OmtPackage.ALTERNATIVE__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case OmtPackage.ALTERNATIVE__NAME_NOTES:
			return NAME_NOTES_EDEFAULT == null ? nameNotes != null : !NAME_NOTES_EDEFAULT.equals(nameNotes);
		case OmtPackage.ALTERNATIVE__SEMANTICS:
			return SEMANTICS_EDEFAULT == null ? semantics != null : !SEMANTICS_EDEFAULT.equals(semantics);
		case OmtPackage.ALTERNATIVE__SEMANTICS_NOTES:
			return SEMANTICS_NOTES_EDEFAULT == null ? semanticsNotes != null : !SEMANTICS_NOTES_EDEFAULT
					.equals(semanticsNotes);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (dataType: ");
		result.append(dataType);
		result.append(", dataTypeNotes: ");
		result.append(dataTypeNotes);
		result.append(", enumerator: ");
		result.append(enumerator);
		result.append(", enumeratorNotes: ");
		result.append(enumeratorNotes);
		result.append(", name: ");
		result.append(name);
		result.append(", nameNotes: ");
		result.append(nameNotes);
		result.append(", semantics: ");
		result.append(semantics);
		result.append(", semanticsNotes: ");
		result.append(semanticsNotes);
		result.append(')');
		return result.toString();
	}

} // AlternativeImpl
