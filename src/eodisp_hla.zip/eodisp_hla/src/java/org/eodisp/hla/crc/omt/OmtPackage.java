/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc --> The <b>Package</b> for the model. It contains
 * accessors for the meta objects to represent
 * <ul>
 * <li>each class,</li>
 * <li>each feature of each class,</li>
 * <li>each enum,</li>
 * <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see org.eodisp.hla.crc.omt.OmtFactory
 * @model kind="package"
 *        extendedMetaData="qualified='false'"
 * @generated
 */
public interface OmtPackage extends EPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The package name.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "omt";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "platform:/resource/eodisp_hla/src/xsd/HLA.xsd";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "HLA";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * @generated
	 */
	OmtPackage eINSTANCE = org.eodisp.hla.crc.omt.impl.OmtPackageImpl.init();

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.AcquisitionRequestTagImpl <em>Acquisition Request Tag</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.AcquisitionRequestTagImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getAcquisitionRequestTag()
	 * @generated
	 */
	int ACQUISITION_REQUEST_TAG = 0;

	/**
	 * The feature id for the '<em><b>Data Type</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ACQUISITION_REQUEST_TAG__DATA_TYPE = 0;

	/**
	 * The feature id for the '<em><b>Data Type Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACQUISITION_REQUEST_TAG__DATA_TYPE_NOTES = 1;

	/**
	 * The feature id for the '<em><b>Semantics</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ACQUISITION_REQUEST_TAG__SEMANTICS = 2;

	/**
	 * The feature id for the '<em><b>Semantics Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACQUISITION_REQUEST_TAG__SEMANTICS_NOTES = 3;

	/**
	 * The number of structural features of the '<em>Acquisition Request Tag</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACQUISITION_REQUEST_TAG_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.AlternativeImpl <em>Alternative</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.AlternativeImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getAlternative()
	 * @generated
	 */
	int ALTERNATIVE = 1;

	/**
	 * The feature id for the '<em><b>Data Type</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ALTERNATIVE__DATA_TYPE = 0;

	/**
	 * The feature id for the '<em><b>Data Type Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALTERNATIVE__DATA_TYPE_NOTES = 1;

	/**
	 * The feature id for the '<em><b>Enumerator</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ALTERNATIVE__ENUMERATOR = 2;

	/**
	 * The feature id for the '<em><b>Enumerator Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALTERNATIVE__ENUMERATOR_NOTES = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ALTERNATIVE__NAME = 4;

	/**
	 * The feature id for the '<em><b>Name Notes</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ALTERNATIVE__NAME_NOTES = 5;

	/**
	 * The feature id for the '<em><b>Semantics</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ALTERNATIVE__SEMANTICS = 6;

	/**
	 * The feature id for the '<em><b>Semantics Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALTERNATIVE__SEMANTICS_NOTES = 7;

	/**
	 * The number of structural features of the '<em>Alternative</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALTERNATIVE_FEATURE_COUNT = 8;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.ArrayDataImpl <em>Array Data</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.ArrayDataImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getArrayData()
	 * @generated
	 */
	int ARRAY_DATA = 2;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ARRAY_DATA__CARDINALITY = 0;

	/**
	 * The feature id for the '<em><b>Cardinality Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARRAY_DATA__CARDINALITY_NOTES = 1;

	/**
	 * The feature id for the '<em><b>Data Type</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ARRAY_DATA__DATA_TYPE = 2;

	/**
	 * The feature id for the '<em><b>Data Type Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARRAY_DATA__DATA_TYPE_NOTES = 3;

	/**
	 * The feature id for the '<em><b>Encoding</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ARRAY_DATA__ENCODING = 4;

	/**
	 * The feature id for the '<em><b>Encoding Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARRAY_DATA__ENCODING_NOTES = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ARRAY_DATA__NAME = 6;

	/**
	 * The feature id for the '<em><b>Name Notes</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ARRAY_DATA__NAME_NOTES = 7;

	/**
	 * The feature id for the '<em><b>Semantics</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ARRAY_DATA__SEMANTICS = 8;

	/**
	 * The feature id for the '<em><b>Semantics Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARRAY_DATA__SEMANTICS_NOTES = 9;

	/**
	 * The number of structural features of the '<em>Array Data</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARRAY_DATA_FEATURE_COUNT = 10;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.ArrayDataTypesImpl <em>Array Data Types</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.ArrayDataTypesImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getArrayDataTypes()
	 * @generated
	 */
	int ARRAY_DATA_TYPES = 3;

	/**
	 * The feature id for the '<em><b>Array Data</b></em>' containment reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARRAY_DATA_TYPES__ARRAY_DATA = 0;

	/**
	 * The number of structural features of the '<em>Array Data Types</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARRAY_DATA_TYPES_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.AttributeImpl <em>Attribute</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.AttributeImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getAttribute()
	 * @generated
	 */
	int ATTRIBUTE = 4;

	/**
	 * The feature id for the '<em><b>Data Type</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__DATA_TYPE = 0;

	/**
	 * The feature id for the '<em><b>Data Type Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__DATA_TYPE_NOTES = 1;

	/**
	 * The feature id for the '<em><b>Dimensions</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__DIMENSIONS = 2;

	/**
	 * The feature id for the '<em><b>Dimensions Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__DIMENSIONS_NOTES = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__NAME = 4;

	/**
	 * The feature id for the '<em><b>Name Notes</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__NAME_NOTES = 5;

	/**
	 * The feature id for the '<em><b>Order</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__ORDER = 6;

	/**
	 * The feature id for the '<em><b>Order Notes</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__ORDER_NOTES = 7;

	/**
	 * The feature id for the '<em><b>Ownership</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__OWNERSHIP = 8;

	/**
	 * The feature id for the '<em><b>Ownership Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__OWNERSHIP_NOTES = 9;

	/**
	 * The feature id for the '<em><b>Semantics</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__SEMANTICS = 10;

	/**
	 * The feature id for the '<em><b>Semantics Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__SEMANTICS_NOTES = 11;

	/**
	 * The feature id for the '<em><b>Sharing</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__SHARING = 12;

	/**
	 * The feature id for the '<em><b>Sharing Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__SHARING_NOTES = 13;

	/**
	 * The feature id for the '<em><b>Transportation</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__TRANSPORTATION = 14;

	/**
	 * The feature id for the '<em><b>Transportation Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__TRANSPORTATION_NOTES = 15;

	/**
	 * The feature id for the '<em><b>Update Condition</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__UPDATE_CONDITION = 16;

	/**
	 * The feature id for the '<em><b>Update Condition Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__UPDATE_CONDITION_NOTES = 17;

	/**
	 * The feature id for the '<em><b>Update Type</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__UPDATE_TYPE = 18;

	/**
	 * The feature id for the '<em><b>Update Type Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__UPDATE_TYPE_NOTES = 19;

	/**
	 * The feature id for the '<em><b>Subscribing Federates</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__SUBSCRIBING_FEDERATES = 20;

	/**
	 * The feature id for the '<em><b>Publishing Federates</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__PUBLISHING_FEDERATES = 21;

	/**
	 * The number of structural features of the '<em>Attribute</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE_FEATURE_COUNT = 22;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.BasicDataImpl <em>Basic Data</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.BasicDataImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getBasicData()
	 * @generated
	 */
	int BASIC_DATA = 5;

	/**
	 * The feature id for the '<em><b>Encoding</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int BASIC_DATA__ENCODING = 0;

	/**
	 * The feature id for the '<em><b>Encoding Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASIC_DATA__ENCODING_NOTES = 1;

	/**
	 * The feature id for the '<em><b>Endian</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int BASIC_DATA__ENDIAN = 2;

	/**
	 * The feature id for the '<em><b>Endian Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASIC_DATA__ENDIAN_NOTES = 3;

	/**
	 * The feature id for the '<em><b>Interpretation</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASIC_DATA__INTERPRETATION = 4;

	/**
	 * The feature id for the '<em><b>Interpretation Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASIC_DATA__INTERPRETATION_NOTES = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int BASIC_DATA__NAME = 6;

	/**
	 * The feature id for the '<em><b>Name Notes</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int BASIC_DATA__NAME_NOTES = 7;

	/**
	 * The feature id for the '<em><b>Size</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int BASIC_DATA__SIZE = 8;

	/**
	 * The feature id for the '<em><b>Size Notes</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int BASIC_DATA__SIZE_NOTES = 9;

	/**
	 * The number of structural features of the '<em>Basic Data</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASIC_DATA_FEATURE_COUNT = 10;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.BasicDataRepresentationsImpl <em>Basic Data Representations</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.BasicDataRepresentationsImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getBasicDataRepresentations()
	 * @generated
	 */
	int BASIC_DATA_REPRESENTATIONS = 6;

	/**
	 * The feature id for the '<em><b>Basic Data</b></em>' containment reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASIC_DATA_REPRESENTATIONS__BASIC_DATA = 0;

	/**
	 * The number of structural features of the '<em>Basic Data Representations</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASIC_DATA_REPRESENTATIONS_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.DataTypesImpl <em>Data Types</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.DataTypesImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getDataTypes()
	 * @generated
	 */
	int DATA_TYPES = 7;

	/**
	 * The feature id for the '<em><b>Basic Data Representations</b></em>' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_TYPES__BASIC_DATA_REPRESENTATIONS = 0;

	/**
	 * The feature id for the '<em><b>Simple Data Types</b></em>' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_TYPES__SIMPLE_DATA_TYPES = 1;

	/**
	 * The feature id for the '<em><b>Enumerated Data Types</b></em>' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_TYPES__ENUMERATED_DATA_TYPES = 2;

	/**
	 * The feature id for the '<em><b>Array Data Types</b></em>' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_TYPES__ARRAY_DATA_TYPES = 3;

	/**
	 * The feature id for the '<em><b>Fixed Record Data Types</b></em>' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_TYPES__FIXED_RECORD_DATA_TYPES = 4;

	/**
	 * The feature id for the '<em><b>Variant Record Data Types</b></em>' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_TYPES__VARIANT_RECORD_DATA_TYPES = 5;

	/**
	 * The number of structural features of the '<em>Data Types</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_TYPES_FEATURE_COUNT = 6;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.DeleteRemoveTagImpl <em>Delete Remove Tag</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.DeleteRemoveTagImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getDeleteRemoveTag()
	 * @generated
	 */
	int DELETE_REMOVE_TAG = 8;

	/**
	 * The feature id for the '<em><b>Data Type</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int DELETE_REMOVE_TAG__DATA_TYPE = 0;

	/**
	 * The feature id for the '<em><b>Data Type Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELETE_REMOVE_TAG__DATA_TYPE_NOTES = 1;

	/**
	 * The feature id for the '<em><b>Semantics</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int DELETE_REMOVE_TAG__SEMANTICS = 2;

	/**
	 * The feature id for the '<em><b>Semantics Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELETE_REMOVE_TAG__SEMANTICS_NOTES = 3;

	/**
	 * The number of structural features of the '<em>Delete Remove Tag</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELETE_REMOVE_TAG_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.DimensionImpl <em>Dimension</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.DimensionImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getDimension()
	 * @generated
	 */
	int DIMENSION = 9;

	/**
	 * The feature id for the '<em><b>Data Type</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int DIMENSION__DATA_TYPE = 0;

	/**
	 * The feature id for the '<em><b>Data Type Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIMENSION__DATA_TYPE_NOTES = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int DIMENSION__NAME = 2;

	/**
	 * The feature id for the '<em><b>Name Notes</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int DIMENSION__NAME_NOTES = 3;

	/**
	 * The feature id for the '<em><b>Normalization</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIMENSION__NORMALIZATION = 4;

	/**
	 * The feature id for the '<em><b>Normalization Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIMENSION__NORMALIZATION_NOTES = 5;

	/**
	 * The feature id for the '<em><b>Upper Bound</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int DIMENSION__UPPER_BOUND = 6;

	/**
	 * The feature id for the '<em><b>Upper Bound Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIMENSION__UPPER_BOUND_NOTES = 7;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int DIMENSION__VALUE = 8;

	/**
	 * The feature id for the '<em><b>Value Notes</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int DIMENSION__VALUE_NOTES = 9;

	/**
	 * The number of structural features of the '<em>Dimension</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIMENSION_FEATURE_COUNT = 10;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.DimensionsImpl <em>Dimensions</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.DimensionsImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getDimensions()
	 * @generated
	 */
	int DIMENSIONS = 10;

	/**
	 * The feature id for the '<em><b>Dimension</b></em>' containment reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIMENSIONS__DIMENSION = 0;

	/**
	 * The number of structural features of the '<em>Dimensions</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIMENSIONS_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.DivestitureCompletionTagImpl <em>Divestiture Completion Tag</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.DivestitureCompletionTagImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getDivestitureCompletionTag()
	 * @generated
	 */
	int DIVESTITURE_COMPLETION_TAG = 11;

	/**
	 * The feature id for the '<em><b>Data Type</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int DIVESTITURE_COMPLETION_TAG__DATA_TYPE = 0;

	/**
	 * The feature id for the '<em><b>Data Type Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIVESTITURE_COMPLETION_TAG__DATA_TYPE_NOTES = 1;

	/**
	 * The feature id for the '<em><b>Semantics</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int DIVESTITURE_COMPLETION_TAG__SEMANTICS = 2;

	/**
	 * The feature id for the '<em><b>Semantics Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIVESTITURE_COMPLETION_TAG__SEMANTICS_NOTES = 3;

	/**
	 * The number of structural features of the '<em>Divestiture Completion Tag</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIVESTITURE_COMPLETION_TAG_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.DivestitureRequestTagImpl <em>Divestiture Request Tag</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.DivestitureRequestTagImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getDivestitureRequestTag()
	 * @generated
	 */
	int DIVESTITURE_REQUEST_TAG = 12;

	/**
	 * The feature id for the '<em><b>Data Type</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int DIVESTITURE_REQUEST_TAG__DATA_TYPE = 0;

	/**
	 * The feature id for the '<em><b>Data Type Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIVESTITURE_REQUEST_TAG__DATA_TYPE_NOTES = 1;

	/**
	 * The feature id for the '<em><b>Semantics</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int DIVESTITURE_REQUEST_TAG__SEMANTICS = 2;

	/**
	 * The feature id for the '<em><b>Semantics Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIVESTITURE_REQUEST_TAG__SEMANTICS_NOTES = 3;

	/**
	 * The number of structural features of the '<em>Divestiture Request Tag</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIVESTITURE_REQUEST_TAG_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.DocumentRootImpl <em>Document Root</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.DocumentRootImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getDocumentRoot()
	 * @generated
	 */
	int DOCUMENT_ROOT = 13;

	/**
	 * The feature id for the '<em><b>Mixed</b></em>' attribute list. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__MIXED = 0;

	/**
	 * The feature id for the '<em><b>XMLNS Prefix Map</b></em>' map. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__XMLNS_PREFIX_MAP = 1;

	/**
	 * The feature id for the '<em><b>XSI Schema Location</b></em>' map.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__XSI_SCHEMA_LOCATION = 2;

	/**
	 * The feature id for the '<em><b>Object Model</b></em>' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__OBJECT_MODEL = 3;

	/**
	 * The number of structural features of the '<em>Document Root</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.EnumeratedDataImpl <em>Enumerated Data</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.EnumeratedDataImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getEnumeratedData()
	 * @generated
	 */
	int ENUMERATED_DATA = 14;

	/**
	 * The feature id for the '<em><b>Enumerator</b></em>' containment reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENUMERATED_DATA__ENUMERATOR = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ENUMERATED_DATA__NAME = 1;

	/**
	 * The feature id for the '<em><b>Name Notes</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ENUMERATED_DATA__NAME_NOTES = 2;

	/**
	 * The feature id for the '<em><b>Representation</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENUMERATED_DATA__REPRESENTATION = 3;

	/**
	 * The feature id for the '<em><b>Representation Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENUMERATED_DATA__REPRESENTATION_NOTES = 4;

	/**
	 * The feature id for the '<em><b>Semantics</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ENUMERATED_DATA__SEMANTICS = 5;

	/**
	 * The feature id for the '<em><b>Semantics Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENUMERATED_DATA__SEMANTICS_NOTES = 6;

	/**
	 * The number of structural features of the '<em>Enumerated Data</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENUMERATED_DATA_FEATURE_COUNT = 7;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.EnumeratedDataTypesImpl <em>Enumerated Data Types</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.EnumeratedDataTypesImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getEnumeratedDataTypes()
	 * @generated
	 */
	int ENUMERATED_DATA_TYPES = 15;

	/**
	 * The feature id for the '<em><b>Enumerated Data</b></em>' containment reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENUMERATED_DATA_TYPES__ENUMERATED_DATA = 0;

	/**
	 * The number of structural features of the '<em>Enumerated Data Types</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENUMERATED_DATA_TYPES_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.EnumeratorImpl <em>Enumerator</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.EnumeratorImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getEnumerator()
	 * @generated
	 */
	int ENUMERATOR = 16;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ENUMERATOR__NAME = 0;

	/**
	 * The feature id for the '<em><b>Name Notes</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ENUMERATOR__NAME_NOTES = 1;

	/**
	 * The feature id for the '<em><b>Values</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ENUMERATOR__VALUES = 2;

	/**
	 * The feature id for the '<em><b>Values Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENUMERATOR__VALUES_NOTES = 3;

	/**
	 * The number of structural features of the '<em>Enumerator</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENUMERATOR_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.FieldImpl <em>Field</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.FieldImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getField()
	 * @generated
	 */
	int FIELD = 17;

	/**
	 * The feature id for the '<em><b>Data Type</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int FIELD__DATA_TYPE = 0;

	/**
	 * The feature id for the '<em><b>Data Type Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIELD__DATA_TYPE_NOTES = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int FIELD__NAME = 2;

	/**
	 * The feature id for the '<em><b>Name Notes</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int FIELD__NAME_NOTES = 3;

	/**
	 * The feature id for the '<em><b>Semantics</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int FIELD__SEMANTICS = 4;

	/**
	 * The feature id for the '<em><b>Semantics Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIELD__SEMANTICS_NOTES = 5;

	/**
	 * The number of structural features of the '<em>Field</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIELD_FEATURE_COUNT = 6;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.FixedRecordDataImpl <em>Fixed Record Data</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.FixedRecordDataImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getFixedRecordData()
	 * @generated
	 */
	int FIXED_RECORD_DATA = 18;

	/**
	 * The feature id for the '<em><b>Field</b></em>' containment reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIXED_RECORD_DATA__FIELD = 0;

	/**
	 * The feature id for the '<em><b>Encoding</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int FIXED_RECORD_DATA__ENCODING = 1;

	/**
	 * The feature id for the '<em><b>Encoding Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIXED_RECORD_DATA__ENCODING_NOTES = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int FIXED_RECORD_DATA__NAME = 3;

	/**
	 * The feature id for the '<em><b>Name Notes</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int FIXED_RECORD_DATA__NAME_NOTES = 4;

	/**
	 * The feature id for the '<em><b>Semantics</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int FIXED_RECORD_DATA__SEMANTICS = 5;

	/**
	 * The feature id for the '<em><b>Semantics Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIXED_RECORD_DATA__SEMANTICS_NOTES = 6;

	/**
	 * The number of structural features of the '<em>Fixed Record Data</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIXED_RECORD_DATA_FEATURE_COUNT = 7;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.FixedRecordDataTypesImpl <em>Fixed Record Data Types</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.FixedRecordDataTypesImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getFixedRecordDataTypes()
	 * @generated
	 */
	int FIXED_RECORD_DATA_TYPES = 19;

	/**
	 * The feature id for the '<em><b>Fixed Record Data</b></em>' containment reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIXED_RECORD_DATA_TYPES__FIXED_RECORD_DATA = 0;

	/**
	 * The number of structural features of the '<em>Fixed Record Data Types</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIXED_RECORD_DATA_TYPES_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.InteractionClassImpl <em>Interaction Class</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.InteractionClassImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getInteractionClass()
	 * @generated
	 */
	int INTERACTION_CLASS = 20;

	/**
	 * The feature id for the '<em><b>Parameters</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERACTION_CLASS__PARAMETERS = 0;

	/**
	 * The feature id for the '<em><b>Sub Classes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERACTION_CLASS__SUB_CLASSES = 1;

	/**
	 * The feature id for the '<em><b>Dimensions</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int INTERACTION_CLASS__DIMENSIONS = 2;

	/**
	 * The feature id for the '<em><b>Dimensions Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERACTION_CLASS__DIMENSIONS_NOTES = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int INTERACTION_CLASS__NAME = 4;

	/**
	 * The feature id for the '<em><b>Name Notes</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int INTERACTION_CLASS__NAME_NOTES = 5;

	/**
	 * The feature id for the '<em><b>Order</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int INTERACTION_CLASS__ORDER = 6;

	/**
	 * The feature id for the '<em><b>Order Notes</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int INTERACTION_CLASS__ORDER_NOTES = 7;

	/**
	 * The feature id for the '<em><b>Semantics</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int INTERACTION_CLASS__SEMANTICS = 8;

	/**
	 * The feature id for the '<em><b>Semantics Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERACTION_CLASS__SEMANTICS_NOTES = 9;

	/**
	 * The feature id for the '<em><b>Sharing</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int INTERACTION_CLASS__SHARING = 10;

	/**
	 * The feature id for the '<em><b>Sharing Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERACTION_CLASS__SHARING_NOTES = 11;

	/**
	 * The feature id for the '<em><b>Transportation</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERACTION_CLASS__TRANSPORTATION = 12;

	/**
	 * The feature id for the '<em><b>Transportation Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERACTION_CLASS__TRANSPORTATION_NOTES = 13;

	/**
	 * The feature id for the '<em><b>Subscribing Federates</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERACTION_CLASS__SUBSCRIBING_FEDERATES = 14;

	/**
	 * The feature id for the '<em><b>Publishing Federates</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERACTION_CLASS__PUBLISHING_FEDERATES = 15;

	/**
	 * The number of structural features of the '<em>Interaction Class</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERACTION_CLASS_FEATURE_COUNT = 16;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.InteractionsImpl <em>Interactions</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.InteractionsImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getInteractions()
	 * @generated
	 */
	int INTERACTIONS = 21;

	/**
	 * The feature id for the '<em><b>Interaction Class</b></em>' containment reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERACTIONS__INTERACTION_CLASS = 0;

	/**
	 * The number of structural features of the '<em>Interactions</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERACTIONS_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.LookaheadImpl <em>Lookahead</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.LookaheadImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getLookahead()
	 * @generated
	 */
	int LOOKAHEAD = 22;

	/**
	 * The feature id for the '<em><b>Data Type</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int LOOKAHEAD__DATA_TYPE = 0;

	/**
	 * The feature id for the '<em><b>Data Type Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOOKAHEAD__DATA_TYPE_NOTES = 1;

	/**
	 * The feature id for the '<em><b>Semantics</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int LOOKAHEAD__SEMANTICS = 2;

	/**
	 * The feature id for the '<em><b>Semantics Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOOKAHEAD__SEMANTICS_NOTES = 3;

	/**
	 * The number of structural features of the '<em>Lookahead</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOOKAHEAD_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.NoteImpl <em>Note</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.NoteImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getNote()
	 * @generated
	 */
	int NOTE = 23;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int NOTE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Semantics</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int NOTE__SEMANTICS = 1;

	/**
	 * The feature id for the '<em><b>Semantics Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NOTE__SEMANTICS_NOTES = 2;

	/**
	 * The number of structural features of the '<em>Note</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NOTE_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.NotesImpl <em>Notes</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.NotesImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getNotes()
	 * @generated
	 */
	int NOTES = 24;

	/**
	 * The feature id for the '<em><b>Note</b></em>' containment reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NOTES__NOTE = 0;

	/**
	 * The number of structural features of the '<em>Notes</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NOTES_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.ObjectClassImpl <em>Object Class</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.ObjectClassImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getObjectClass()
	 * @generated
	 */
	int OBJECT_CLASS = 25;

	/**
	 * The feature id for the '<em><b>Attributes</b></em>' containment reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_CLASS__ATTRIBUTES = 0;

	/**
	 * The feature id for the '<em><b>Sub Classes</b></em>' containment reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_CLASS__SUB_CLASSES = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OBJECT_CLASS__NAME = 2;

	/**
	 * The feature id for the '<em><b>Name Notes</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OBJECT_CLASS__NAME_NOTES = 3;

	/**
	 * The feature id for the '<em><b>Semantics</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OBJECT_CLASS__SEMANTICS = 4;

	/**
	 * The feature id for the '<em><b>Semantics Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_CLASS__SEMANTICS_NOTES = 5;

	/**
	 * The feature id for the '<em><b>Sharing</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OBJECT_CLASS__SHARING = 6;

	/**
	 * The feature id for the '<em><b>Sharing Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_CLASS__SHARING_NOTES = 7;

	/**
	 * The number of structural features of the '<em>Object Class</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_CLASS_FEATURE_COUNT = 8;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl <em>Object Model</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.ObjectModelImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getObjectModel()
	 * @generated
	 */
	int OBJECT_MODEL = 26;

	/**
	 * The feature id for the '<em><b>Objects</b></em>' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__OBJECTS = 0;

	/**
	 * The feature id for the '<em><b>Interactions</b></em>' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__INTERACTIONS = 1;

	/**
	 * The feature id for the '<em><b>Dimensions</b></em>' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__DIMENSIONS = 2;

	/**
	 * The feature id for the '<em><b>Time</b></em>' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__TIME = 3;

	/**
	 * The feature id for the '<em><b>Tags</b></em>' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__TAGS = 4;

	/**
	 * The feature id for the '<em><b>Synchronizations</b></em>' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__SYNCHRONIZATIONS = 5;

	/**
	 * The feature id for the '<em><b>Transportations</b></em>' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__TRANSPORTATIONS = 6;

	/**
	 * The feature id for the '<em><b>Switches</b></em>' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__SWITCHES = 7;

	/**
	 * The feature id for the '<em><b>Data Types</b></em>' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__DATA_TYPES = 8;

	/**
	 * The feature id for the '<em><b>Notes</b></em>' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__NOTES = 9;

	/**
	 * The feature id for the '<em><b>App Domain</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__APP_DOMAIN = 10;

	/**
	 * The feature id for the '<em><b>App Domain Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__APP_DOMAIN_NOTES = 11;

	/**
	 * The feature id for the '<em><b>Date</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__DATE = 12;

	/**
	 * The feature id for the '<em><b>Date Notes</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__DATE_NOTES = 13;

	/**
	 * The feature id for the '<em><b>DT Dversion</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__DT_DVERSION = 14;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__NAME = 15;

	/**
	 * The feature id for the '<em><b>Name Notes</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__NAME_NOTES = 16;

	/**
	 * The feature id for the '<em><b>Other</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__OTHER = 17;

	/**
	 * The feature id for the '<em><b>Other Notes</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__OTHER_NOTES = 18;

	/**
	 * The feature id for the '<em><b>Poc Email</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__POC_EMAIL = 19;

	/**
	 * The feature id for the '<em><b>Poc Email Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__POC_EMAIL_NOTES = 20;

	/**
	 * The feature id for the '<em><b>Poc Name</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__POC_NAME = 21;

	/**
	 * The feature id for the '<em><b>Poc Name Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__POC_NAME_NOTES = 22;

	/**
	 * The feature id for the '<em><b>Poc Org</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__POC_ORG = 23;

	/**
	 * The feature id for the '<em><b>Poc Org Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__POC_ORG_NOTES = 24;

	/**
	 * The feature id for the '<em><b>Poc Phone</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__POC_PHONE = 25;

	/**
	 * The feature id for the '<em><b>Poc Phone Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__POC_PHONE_NOTES = 26;

	/**
	 * The feature id for the '<em><b>Purpose</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__PURPOSE = 27;

	/**
	 * The feature id for the '<em><b>Purpose Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__PURPOSE_NOTES = 28;

	/**
	 * The feature id for the '<em><b>References</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__REFERENCES = 29;

	/**
	 * The feature id for the '<em><b>References Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__REFERENCES_NOTES = 30;

	/**
	 * The feature id for the '<em><b>Sponsor</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__SPONSOR = 31;

	/**
	 * The feature id for the '<em><b>Sponsor Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__SPONSOR_NOTES = 32;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__TYPE = 33;

	/**
	 * The feature id for the '<em><b>Type Notes</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__TYPE_NOTES = 34;

	/**
	 * The feature id for the '<em><b>Version</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__VERSION = 35;

	/**
	 * The feature id for the '<em><b>Version Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL__VERSION_NOTES = 36;

	/**
	 * The number of structural features of the '<em>Object Model</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_MODEL_FEATURE_COUNT = 37;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.ObjectsImpl <em>Objects</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.ObjectsImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getObjects()
	 * @generated
	 */
	int OBJECTS = 27;

	/**
	 * The feature id for the '<em><b>Object Class</b></em>' containment reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECTS__OBJECT_CLASS = 0;

	/**
	 * The number of structural features of the '<em>Objects</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECTS_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.ParameterImpl <em>Parameter</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.ParameterImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getParameter()
	 * @generated
	 */
	int PARAMETER = 28;

	/**
	 * The feature id for the '<em><b>Data Type</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PARAMETER__DATA_TYPE = 0;

	/**
	 * The feature id for the '<em><b>Data Type Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARAMETER__DATA_TYPE_NOTES = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PARAMETER__NAME = 2;

	/**
	 * The feature id for the '<em><b>Name Notes</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PARAMETER__NAME_NOTES = 3;

	/**
	 * The feature id for the '<em><b>Semantics</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int PARAMETER__SEMANTICS = 4;

	/**
	 * The feature id for the '<em><b>Semantics Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARAMETER__SEMANTICS_NOTES = 5;

	/**
	 * The number of structural features of the '<em>Parameter</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARAMETER_FEATURE_COUNT = 6;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.RequestUpdateTagImpl <em>Request Update Tag</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.RequestUpdateTagImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getRequestUpdateTag()
	 * @generated
	 */
	int REQUEST_UPDATE_TAG = 29;

	/**
	 * The feature id for the '<em><b>Data Type</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int REQUEST_UPDATE_TAG__DATA_TYPE = 0;

	/**
	 * The feature id for the '<em><b>Data Type Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUEST_UPDATE_TAG__DATA_TYPE_NOTES = 1;

	/**
	 * The feature id for the '<em><b>Semantics</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int REQUEST_UPDATE_TAG__SEMANTICS = 2;

	/**
	 * The feature id for the '<em><b>Semantics Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUEST_UPDATE_TAG__SEMANTICS_NOTES = 3;

	/**
	 * The number of structural features of the '<em>Request Update Tag</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUEST_UPDATE_TAG_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.SendReceiveTagImpl <em>Send Receive Tag</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.SendReceiveTagImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getSendReceiveTag()
	 * @generated
	 */
	int SEND_RECEIVE_TAG = 30;

	/**
	 * The feature id for the '<em><b>Data Type</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int SEND_RECEIVE_TAG__DATA_TYPE = 0;

	/**
	 * The feature id for the '<em><b>Data Type Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEND_RECEIVE_TAG__DATA_TYPE_NOTES = 1;

	/**
	 * The feature id for the '<em><b>Semantics</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int SEND_RECEIVE_TAG__SEMANTICS = 2;

	/**
	 * The feature id for the '<em><b>Semantics Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEND_RECEIVE_TAG__SEMANTICS_NOTES = 3;

	/**
	 * The number of structural features of the '<em>Send Receive Tag</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEND_RECEIVE_TAG_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.SimpleDataImpl <em>Simple Data</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.SimpleDataImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getSimpleData()
	 * @generated
	 */
	int SIMPLE_DATA = 31;

	/**
	 * The feature id for the '<em><b>Accuracy</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int SIMPLE_DATA__ACCURACY = 0;

	/**
	 * The feature id for the '<em><b>Accuracy Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SIMPLE_DATA__ACCURACY_NOTES = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int SIMPLE_DATA__NAME = 2;

	/**
	 * The feature id for the '<em><b>Name Notes</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int SIMPLE_DATA__NAME_NOTES = 3;

	/**
	 * The feature id for the '<em><b>Representation</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SIMPLE_DATA__REPRESENTATION = 4;

	/**
	 * The feature id for the '<em><b>Representation Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SIMPLE_DATA__REPRESENTATION_NOTES = 5;

	/**
	 * The feature id for the '<em><b>Resolution</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int SIMPLE_DATA__RESOLUTION = 6;

	/**
	 * The feature id for the '<em><b>Resolution Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SIMPLE_DATA__RESOLUTION_NOTES = 7;

	/**
	 * The feature id for the '<em><b>Semantics</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int SIMPLE_DATA__SEMANTICS = 8;

	/**
	 * The feature id for the '<em><b>Semantics Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SIMPLE_DATA__SEMANTICS_NOTES = 9;

	/**
	 * The feature id for the '<em><b>Units</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int SIMPLE_DATA__UNITS = 10;

	/**
	 * The feature id for the '<em><b>Units Notes</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int SIMPLE_DATA__UNITS_NOTES = 11;

	/**
	 * The number of structural features of the '<em>Simple Data</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SIMPLE_DATA_FEATURE_COUNT = 12;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.SimpleDataTypesImpl <em>Simple Data Types</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.SimpleDataTypesImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getSimpleDataTypes()
	 * @generated
	 */
	int SIMPLE_DATA_TYPES = 32;

	/**
	 * The feature id for the '<em><b>Simple Data</b></em>' containment reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SIMPLE_DATA_TYPES__SIMPLE_DATA = 0;

	/**
	 * The number of structural features of the '<em>Simple Data Types</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SIMPLE_DATA_TYPES_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.SwitchesImpl <em>Switches</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.SwitchesImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getSwitches()
	 * @generated
	 */
	int SWITCHES = 33;

	/**
	 * The feature id for the '<em><b>Attribute Relevance Advisory</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SWITCHES__ATTRIBUTE_RELEVANCE_ADVISORY = 0;

	/**
	 * The feature id for the '<em><b>Attribute Relevance Advisory Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SWITCHES__ATTRIBUTE_RELEVANCE_ADVISORY_NOTES = 1;

	/**
	 * The feature id for the '<em><b>Attribute Scope Advisory</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SWITCHES__ATTRIBUTE_SCOPE_ADVISORY = 2;

	/**
	 * The feature id for the '<em><b>Attribute Scope Advisory Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SWITCHES__ATTRIBUTE_SCOPE_ADVISORY_NOTES = 3;

	/**
	 * The feature id for the '<em><b>Auto Provide</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SWITCHES__AUTO_PROVIDE = 4;

	/**
	 * The feature id for the '<em><b>Auto Provide Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SWITCHES__AUTO_PROVIDE_NOTES = 5;

	/**
	 * The feature id for the '<em><b>Convey Region Designator Sets</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SWITCHES__CONVEY_REGION_DESIGNATOR_SETS = 6;

	/**
	 * The feature id for the '<em><b>Convey Region Designator Sets Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SWITCHES__CONVEY_REGION_DESIGNATOR_SETS_NOTES = 7;

	/**
	 * The feature id for the '<em><b>Interaction Relevance Advisory</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SWITCHES__INTERACTION_RELEVANCE_ADVISORY = 8;

	/**
	 * The feature id for the '<em><b>Interaction Relevance Advisory Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SWITCHES__INTERACTION_RELEVANCE_ADVISORY_NOTES = 9;

	/**
	 * The feature id for the '<em><b>Object Class Relevance Advisory</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SWITCHES__OBJECT_CLASS_RELEVANCE_ADVISORY = 10;

	/**
	 * The feature id for the '<em><b>Object Class Relevance Advisory Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SWITCHES__OBJECT_CLASS_RELEVANCE_ADVISORY_NOTES = 11;

	/**
	 * The feature id for the '<em><b>Service Reporting</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SWITCHES__SERVICE_REPORTING = 12;

	/**
	 * The feature id for the '<em><b>Service Reporting Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SWITCHES__SERVICE_REPORTING_NOTES = 13;

	/**
	 * The number of structural features of the '<em>Switches</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SWITCHES_FEATURE_COUNT = 14;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.SynchronizationImpl <em>Synchronization</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.SynchronizationImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getSynchronization()
	 * @generated
	 */
	int SYNCHRONIZATION = 34;

	/**
	 * The feature id for the '<em><b>Capability</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int SYNCHRONIZATION__CAPABILITY = 0;

	/**
	 * The feature id for the '<em><b>Capability Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYNCHRONIZATION__CAPABILITY_NOTES = 1;

	/**
	 * The feature id for the '<em><b>Data Type</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int SYNCHRONIZATION__DATA_TYPE = 2;

	/**
	 * The feature id for the '<em><b>Data Type Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYNCHRONIZATION__DATA_TYPE_NOTES = 3;

	/**
	 * The feature id for the '<em><b>Label</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int SYNCHRONIZATION__LABEL = 4;

	/**
	 * The feature id for the '<em><b>Label Notes</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int SYNCHRONIZATION__LABEL_NOTES = 5;

	/**
	 * The feature id for the '<em><b>Semantics</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int SYNCHRONIZATION__SEMANTICS = 6;

	/**
	 * The feature id for the '<em><b>Semantics Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYNCHRONIZATION__SEMANTICS_NOTES = 7;

	/**
	 * The number of structural features of the '<em>Synchronization</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYNCHRONIZATION_FEATURE_COUNT = 8;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.SynchronizationsImpl <em>Synchronizations</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.SynchronizationsImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getSynchronizations()
	 * @generated
	 */
	int SYNCHRONIZATIONS = 35;

	/**
	 * The feature id for the '<em><b>Synchronization</b></em>' containment reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYNCHRONIZATIONS__SYNCHRONIZATION = 0;

	/**
	 * The number of structural features of the '<em>Synchronizations</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYNCHRONIZATIONS_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.TagsImpl <em>Tags</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.TagsImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getTags()
	 * @generated
	 */
	int TAGS = 36;

	/**
	 * The feature id for the '<em><b>Update Reflect Tag</b></em>' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAGS__UPDATE_REFLECT_TAG = 0;

	/**
	 * The feature id for the '<em><b>Send Receive Tag</b></em>' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAGS__SEND_RECEIVE_TAG = 1;

	/**
	 * The feature id for the '<em><b>Delete Remove Tag</b></em>' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAGS__DELETE_REMOVE_TAG = 2;

	/**
	 * The feature id for the '<em><b>Divestiture Request Tag</b></em>' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAGS__DIVESTITURE_REQUEST_TAG = 3;

	/**
	 * The feature id for the '<em><b>Divestiture Completion Tag</b></em>' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAGS__DIVESTITURE_COMPLETION_TAG = 4;

	/**
	 * The feature id for the '<em><b>Acquisition Request Tag</b></em>' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAGS__ACQUISITION_REQUEST_TAG = 5;

	/**
	 * The feature id for the '<em><b>Request Update Tag</b></em>' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAGS__REQUEST_UPDATE_TAG = 6;

	/**
	 * The number of structural features of the '<em>Tags</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAGS_FEATURE_COUNT = 7;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.TimeImpl <em>Time</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.TimeImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getTime()
	 * @generated
	 */
	int TIME = 37;

	/**
	 * The feature id for the '<em><b>Time Stamp</b></em>' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TIME__TIME_STAMP = 0;

	/**
	 * The feature id for the '<em><b>Lookahead</b></em>' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TIME__LOOKAHEAD = 1;

	/**
	 * The number of structural features of the '<em>Time</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TIME_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.TimeStampImpl <em>Time Stamp</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.TimeStampImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getTimeStamp()
	 * @generated
	 */
	int TIME_STAMP = 38;

	/**
	 * The feature id for the '<em><b>Data Type</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int TIME_STAMP__DATA_TYPE = 0;

	/**
	 * The feature id for the '<em><b>Data Type Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TIME_STAMP__DATA_TYPE_NOTES = 1;

	/**
	 * The feature id for the '<em><b>Semantics</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int TIME_STAMP__SEMANTICS = 2;

	/**
	 * The feature id for the '<em><b>Semantics Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TIME_STAMP__SEMANTICS_NOTES = 3;

	/**
	 * The number of structural features of the '<em>Time Stamp</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TIME_STAMP_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.TransportationImpl <em>Transportation</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.TransportationImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getTransportation()
	 * @generated
	 */
	int TRANSPORTATION = 39;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int TRANSPORTATION__DESCRIPTION = 0;

	/**
	 * The feature id for the '<em><b>Description Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSPORTATION__DESCRIPTION_NOTES = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int TRANSPORTATION__NAME = 2;

	/**
	 * The feature id for the '<em><b>Name Notes</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int TRANSPORTATION__NAME_NOTES = 3;

	/**
	 * The number of structural features of the '<em>Transportation</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSPORTATION_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.TransportationsImpl <em>Transportations</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.TransportationsImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getTransportations()
	 * @generated
	 */
	int TRANSPORTATIONS = 40;

	/**
	 * The feature id for the '<em><b>Transportation</b></em>' containment reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSPORTATIONS__TRANSPORTATION = 0;

	/**
	 * The number of structural features of the '<em>Transportations</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSPORTATIONS_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.UpdateReflectTagImpl <em>Update Reflect Tag</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.UpdateReflectTagImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getUpdateReflectTag()
	 * @generated
	 */
	int UPDATE_REFLECT_TAG = 41;

	/**
	 * The feature id for the '<em><b>Data Type</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int UPDATE_REFLECT_TAG__DATA_TYPE = 0;

	/**
	 * The feature id for the '<em><b>Data Type Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UPDATE_REFLECT_TAG__DATA_TYPE_NOTES = 1;

	/**
	 * The feature id for the '<em><b>Semantics</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int UPDATE_REFLECT_TAG__SEMANTICS = 2;

	/**
	 * The feature id for the '<em><b>Semantics Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UPDATE_REFLECT_TAG__SEMANTICS_NOTES = 3;

	/**
	 * The number of structural features of the '<em>Update Reflect Tag</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UPDATE_REFLECT_TAG_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.VariantRecordDataImpl <em>Variant Record Data</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.VariantRecordDataImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getVariantRecordData()
	 * @generated
	 */
	int VARIANT_RECORD_DATA = 42;

	/**
	 * The feature id for the '<em><b>Alternative</b></em>' containment reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VARIANT_RECORD_DATA__ALTERNATIVE = 0;

	/**
	 * The feature id for the '<em><b>Data Type</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int VARIANT_RECORD_DATA__DATA_TYPE = 1;

	/**
	 * The feature id for the '<em><b>Data Type Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VARIANT_RECORD_DATA__DATA_TYPE_NOTES = 2;

	/**
	 * The feature id for the '<em><b>Discriminant</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VARIANT_RECORD_DATA__DISCRIMINANT = 3;

	/**
	 * The feature id for the '<em><b>Discriminant Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VARIANT_RECORD_DATA__DISCRIMINANT_NOTES = 4;

	/**
	 * The feature id for the '<em><b>Encoding</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int VARIANT_RECORD_DATA__ENCODING = 5;

	/**
	 * The feature id for the '<em><b>Encoding Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VARIANT_RECORD_DATA__ENCODING_NOTES = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int VARIANT_RECORD_DATA__NAME = 7;

	/**
	 * The feature id for the '<em><b>Name Notes</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int VARIANT_RECORD_DATA__NAME_NOTES = 8;

	/**
	 * The feature id for the '<em><b>Semantics</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int VARIANT_RECORD_DATA__SEMANTICS = 9;

	/**
	 * The feature id for the '<em><b>Semantics Notes</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VARIANT_RECORD_DATA__SEMANTICS_NOTES = 10;

	/**
	 * The number of structural features of the '<em>Variant Record Data</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VARIANT_RECORD_DATA_FEATURE_COUNT = 11;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.impl.VariantRecordDataTypesImpl <em>Variant Record Data Types</em>}' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.impl.VariantRecordDataTypesImpl
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getVariantRecordDataTypes()
	 * @generated
	 */
	int VARIANT_RECORD_DATA_TYPES = 43;

	/**
	 * The feature id for the '<em><b>Variant Record Data</b></em>' containment reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VARIANT_RECORD_DATA_TYPES__VARIANT_RECORD_DATA = 0;

	/**
	 * The number of structural features of the '<em>Variant Record Data Types</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VARIANT_RECORD_DATA_TYPES_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.EndianEnum <em>Endian Enum</em>}' enum.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.EndianEnum
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getEndianEnum()
	 * @generated
	 */
	int ENDIAN_ENUM = 45;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.ObjectModelTypeEnum <em>Object Model Type Enum</em>}' enum.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.ObjectModelTypeEnum
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getObjectModelTypeEnum()
	 * @generated
	 */
	int OBJECT_MODEL_TYPE_ENUM = 46;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.OrderEnum <em>Order Enum</em>}' enum.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.OrderEnum
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getOrderEnum()
	 * @generated
	 */
	int ORDER_ENUM = 47;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.OwnershipEnum <em>Ownership Enum</em>}' enum.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.OwnershipEnum
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getOwnershipEnum()
	 * @generated
	 */
	int OWNERSHIP_ENUM = 48;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.SharingEnum <em>Sharing Enum</em>}' enum.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.SharingEnum
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getSharingEnum()
	 * @generated
	 */
	int SHARING_ENUM = 49;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.StateEnum <em>State Enum</em>}' enum.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.StateEnum
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getStateEnum()
	 * @generated
	 */
	int STATE_ENUM = 50;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.SyncCapabilityEnum <em>Sync Capability Enum</em>}' enum.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.SyncCapabilityEnum
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getSyncCapabilityEnum()
	 * @generated
	 */
	int SYNC_CAPABILITY_ENUM = 51;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.UpdateTypeEnum <em>Update Type Enum</em>}' enum.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.UpdateTypeEnum
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getUpdateTypeEnum()
	 * @generated
	 */
	int UPDATE_TYPE_ENUM = 52;

	/**
	 * The meta object id for the '<em>DTD Version Enum Object</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.DTDVersionEnum
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getDTDVersionEnumObject()
	 * @generated
	 */
	int DTD_VERSION_ENUM_OBJECT = 53;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.omt.DTDVersionEnum <em>DTD Version Enum</em>}' enum.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.DTDVersionEnum
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getDTDVersionEnum()
	 * @generated
	 */
	int DTD_VERSION_ENUM = 44;

	/**
	 * The meta object id for the '<em>Endian Enum Object</em>' data type.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.EndianEnum
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getEndianEnumObject()
	 * @generated
	 */
	int ENDIAN_ENUM_OBJECT = 54;

	/**
	 * The meta object id for the '<em>Object Model Type Enum Object</em>' data type.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.ObjectModelTypeEnum
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getObjectModelTypeEnumObject()
	 * @generated
	 */
	int OBJECT_MODEL_TYPE_ENUM_OBJECT = 55;

	/**
	 * The meta object id for the '<em>Order Enum Object</em>' data type.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.OrderEnum
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getOrderEnumObject()
	 * @generated
	 */
	int ORDER_ENUM_OBJECT = 56;

	/**
	 * The meta object id for the '<em>Ownership Enum Object</em>' data type.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.OwnershipEnum
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getOwnershipEnumObject()
	 * @generated
	 */
	int OWNERSHIP_ENUM_OBJECT = 57;

	/**
	 * The meta object id for the '<em>Sharing Enum Object</em>' data type.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.SharingEnum
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getSharingEnumObject()
	 * @generated
	 */
	int SHARING_ENUM_OBJECT = 58;

	/**
	 * The meta object id for the '<em>State Enum Object</em>' data type.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.StateEnum
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getStateEnumObject()
	 * @generated
	 */
	int STATE_ENUM_OBJECT = 59;

	/**
	 * The meta object id for the '<em>Sync Capability Enum Object</em>' data type.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.SyncCapabilityEnum
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getSyncCapabilityEnumObject()
	 * @generated
	 */
	int SYNC_CAPABILITY_ENUM_OBJECT = 60;

	/**
	 * The meta object id for the '<em>Update Type Enum Object</em>' data type.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.omt.UpdateTypeEnum
	 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getUpdateTypeEnumObject()
	 * @generated
	 */
	int UPDATE_TYPE_ENUM_OBJECT = 61;

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.AcquisitionRequestTag <em>Acquisition Request Tag</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Acquisition Request Tag</em>'.
	 * @see org.eodisp.hla.crc.omt.AcquisitionRequestTag
	 * @generated
	 */
	EClass getAcquisitionRequestTag();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.AcquisitionRequestTag#getDataType <em>Data Type</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type</em>'.
	 * @see org.eodisp.hla.crc.omt.AcquisitionRequestTag#getDataType()
	 * @see #getAcquisitionRequestTag()
	 * @generated
	 */
	EAttribute getAcquisitionRequestTag_DataType();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.AcquisitionRequestTag#getDataTypeNotes <em>Data Type Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.AcquisitionRequestTag#getDataTypeNotes()
	 * @see #getAcquisitionRequestTag()
	 * @generated
	 */
	EAttribute getAcquisitionRequestTag_DataTypeNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.AcquisitionRequestTag#getSemantics <em>Semantics</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics</em>'.
	 * @see org.eodisp.hla.crc.omt.AcquisitionRequestTag#getSemantics()
	 * @see #getAcquisitionRequestTag()
	 * @generated
	 */
	EAttribute getAcquisitionRequestTag_Semantics();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.AcquisitionRequestTag#getSemanticsNotes <em>Semantics Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.AcquisitionRequestTag#getSemanticsNotes()
	 * @see #getAcquisitionRequestTag()
	 * @generated
	 */
	EAttribute getAcquisitionRequestTag_SemanticsNotes();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.Alternative <em>Alternative</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Alternative</em>'.
	 * @see org.eodisp.hla.crc.omt.Alternative
	 * @generated
	 */
	EClass getAlternative();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Alternative#getDataType <em>Data Type</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type</em>'.
	 * @see org.eodisp.hla.crc.omt.Alternative#getDataType()
	 * @see #getAlternative()
	 * @generated
	 */
	EAttribute getAlternative_DataType();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Alternative#getDataTypeNotes <em>Data Type Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Alternative#getDataTypeNotes()
	 * @see #getAlternative()
	 * @generated
	 */
	EAttribute getAlternative_DataTypeNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Alternative#getEnumerator <em>Enumerator</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Enumerator</em>'.
	 * @see org.eodisp.hla.crc.omt.Alternative#getEnumerator()
	 * @see #getAlternative()
	 * @generated
	 */
	EAttribute getAlternative_Enumerator();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Alternative#getEnumeratorNotes <em>Enumerator Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Enumerator Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Alternative#getEnumeratorNotes()
	 * @see #getAlternative()
	 * @generated
	 */
	EAttribute getAlternative_EnumeratorNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Alternative#getName <em>Name</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eodisp.hla.crc.omt.Alternative#getName()
	 * @see #getAlternative()
	 * @generated
	 */
	EAttribute getAlternative_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Alternative#getNameNotes <em>Name Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Alternative#getNameNotes()
	 * @see #getAlternative()
	 * @generated
	 */
	EAttribute getAlternative_NameNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Alternative#getSemantics <em>Semantics</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics</em>'.
	 * @see org.eodisp.hla.crc.omt.Alternative#getSemantics()
	 * @see #getAlternative()
	 * @generated
	 */
	EAttribute getAlternative_Semantics();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Alternative#getSemanticsNotes <em>Semantics Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Alternative#getSemanticsNotes()
	 * @see #getAlternative()
	 * @generated
	 */
	EAttribute getAlternative_SemanticsNotes();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.ArrayData <em>Array Data</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Array Data</em>'.
	 * @see org.eodisp.hla.crc.omt.ArrayData
	 * @generated
	 */
	EClass getArrayData();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ArrayData#getCardinality <em>Cardinality</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Cardinality</em>'.
	 * @see org.eodisp.hla.crc.omt.ArrayData#getCardinality()
	 * @see #getArrayData()
	 * @generated
	 */
	EAttribute getArrayData_Cardinality();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ArrayData#getCardinalityNotes <em>Cardinality Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Cardinality Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.ArrayData#getCardinalityNotes()
	 * @see #getArrayData()
	 * @generated
	 */
	EAttribute getArrayData_CardinalityNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ArrayData#getDataType <em>Data Type</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type</em>'.
	 * @see org.eodisp.hla.crc.omt.ArrayData#getDataType()
	 * @see #getArrayData()
	 * @generated
	 */
	EAttribute getArrayData_DataType();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ArrayData#getDataTypeNotes <em>Data Type Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.ArrayData#getDataTypeNotes()
	 * @see #getArrayData()
	 * @generated
	 */
	EAttribute getArrayData_DataTypeNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ArrayData#getEncoding <em>Encoding</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Encoding</em>'.
	 * @see org.eodisp.hla.crc.omt.ArrayData#getEncoding()
	 * @see #getArrayData()
	 * @generated
	 */
	EAttribute getArrayData_Encoding();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ArrayData#getEncodingNotes <em>Encoding Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Encoding Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.ArrayData#getEncodingNotes()
	 * @see #getArrayData()
	 * @generated
	 */
	EAttribute getArrayData_EncodingNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ArrayData#getName <em>Name</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eodisp.hla.crc.omt.ArrayData#getName()
	 * @see #getArrayData()
	 * @generated
	 */
	EAttribute getArrayData_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ArrayData#getNameNotes <em>Name Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.ArrayData#getNameNotes()
	 * @see #getArrayData()
	 * @generated
	 */
	EAttribute getArrayData_NameNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ArrayData#getSemantics <em>Semantics</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics</em>'.
	 * @see org.eodisp.hla.crc.omt.ArrayData#getSemantics()
	 * @see #getArrayData()
	 * @generated
	 */
	EAttribute getArrayData_Semantics();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ArrayData#getSemanticsNotes <em>Semantics Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.ArrayData#getSemanticsNotes()
	 * @see #getArrayData()
	 * @generated
	 */
	EAttribute getArrayData_SemanticsNotes();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.ArrayDataTypes <em>Array Data Types</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Array Data Types</em>'.
	 * @see org.eodisp.hla.crc.omt.ArrayDataTypes
	 * @generated
	 */
	EClass getArrayDataTypes();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eodisp.hla.crc.omt.ArrayDataTypes#getArrayData <em>Array Data</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Array Data</em>'.
	 * @see org.eodisp.hla.crc.omt.ArrayDataTypes#getArrayData()
	 * @see #getArrayDataTypes()
	 * @generated
	 */
	EReference getArrayDataTypes_ArrayData();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.Attribute <em>Attribute</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Attribute</em>'.
	 * @see org.eodisp.hla.crc.omt.Attribute
	 * @generated
	 */
	EClass getAttribute();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Attribute#getDataType <em>Data Type</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type</em>'.
	 * @see org.eodisp.hla.crc.omt.Attribute#getDataType()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_DataType();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Attribute#getDataTypeNotes <em>Data Type Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Attribute#getDataTypeNotes()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_DataTypeNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Attribute#getDimensions <em>Dimensions</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Dimensions</em>'.
	 * @see org.eodisp.hla.crc.omt.Attribute#getDimensions()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_Dimensions();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Attribute#getDimensionsNotes <em>Dimensions Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Dimensions Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Attribute#getDimensionsNotes()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_DimensionsNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Attribute#getName <em>Name</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eodisp.hla.crc.omt.Attribute#getName()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Attribute#getNameNotes <em>Name Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Attribute#getNameNotes()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_NameNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Attribute#getOrder <em>Order</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Order</em>'.
	 * @see org.eodisp.hla.crc.omt.Attribute#getOrder()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_Order();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Attribute#getOrderNotes <em>Order Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Order Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Attribute#getOrderNotes()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_OrderNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Attribute#getOwnership <em>Ownership</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ownership</em>'.
	 * @see org.eodisp.hla.crc.omt.Attribute#getOwnership()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_Ownership();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Attribute#getOwnershipNotes <em>Ownership Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ownership Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Attribute#getOwnershipNotes()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_OwnershipNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Attribute#getSemantics <em>Semantics</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics</em>'.
	 * @see org.eodisp.hla.crc.omt.Attribute#getSemantics()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_Semantics();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Attribute#getSemanticsNotes <em>Semantics Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Attribute#getSemanticsNotes()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_SemanticsNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Attribute#getSharing <em>Sharing</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sharing</em>'.
	 * @see org.eodisp.hla.crc.omt.Attribute#getSharing()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_Sharing();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Attribute#getSharingNotes <em>Sharing Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sharing Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Attribute#getSharingNotes()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_SharingNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Attribute#getTransportation <em>Transportation</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Transportation</em>'.
	 * @see org.eodisp.hla.crc.omt.Attribute#getTransportation()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_Transportation();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Attribute#getTransportationNotes <em>Transportation Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Transportation Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Attribute#getTransportationNotes()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_TransportationNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Attribute#getUpdateCondition <em>Update Condition</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Update Condition</em>'.
	 * @see org.eodisp.hla.crc.omt.Attribute#getUpdateCondition()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_UpdateCondition();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Attribute#getUpdateConditionNotes <em>Update Condition Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Update Condition Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Attribute#getUpdateConditionNotes()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_UpdateConditionNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Attribute#getUpdateType <em>Update Type</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Update Type</em>'.
	 * @see org.eodisp.hla.crc.omt.Attribute#getUpdateType()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_UpdateType();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Attribute#getUpdateTypeNotes <em>Update Type Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Update Type Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Attribute#getUpdateTypeNotes()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_UpdateTypeNotes();

	/**
	 * Returns the meta object for the reference list '{@link org.eodisp.hla.crc.omt.Attribute#getSubscribingFederates <em>Subscribing Federates</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Subscribing Federates</em>'.
	 * @see org.eodisp.hla.crc.omt.Attribute#getSubscribingFederates()
	 * @see #getAttribute()
	 * @generated
	 */
	EReference getAttribute_SubscribingFederates();

	/**
	 * Returns the meta object for the reference list '{@link org.eodisp.hla.crc.omt.Attribute#getPublishingFederates <em>Publishing Federates</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Publishing Federates</em>'.
	 * @see org.eodisp.hla.crc.omt.Attribute#getPublishingFederates()
	 * @see #getAttribute()
	 * @generated
	 */
	EReference getAttribute_PublishingFederates();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.BasicData <em>Basic Data</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Basic Data</em>'.
	 * @see org.eodisp.hla.crc.omt.BasicData
	 * @generated
	 */
	EClass getBasicData();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.BasicData#getEncoding <em>Encoding</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Encoding</em>'.
	 * @see org.eodisp.hla.crc.omt.BasicData#getEncoding()
	 * @see #getBasicData()
	 * @generated
	 */
	EAttribute getBasicData_Encoding();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.BasicData#getEncodingNotes <em>Encoding Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Encoding Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.BasicData#getEncodingNotes()
	 * @see #getBasicData()
	 * @generated
	 */
	EAttribute getBasicData_EncodingNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.BasicData#getEndian <em>Endian</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Endian</em>'.
	 * @see org.eodisp.hla.crc.omt.BasicData#getEndian()
	 * @see #getBasicData()
	 * @generated
	 */
	EAttribute getBasicData_Endian();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.BasicData#getEndianNotes <em>Endian Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Endian Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.BasicData#getEndianNotes()
	 * @see #getBasicData()
	 * @generated
	 */
	EAttribute getBasicData_EndianNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.BasicData#getInterpretation <em>Interpretation</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Interpretation</em>'.
	 * @see org.eodisp.hla.crc.omt.BasicData#getInterpretation()
	 * @see #getBasicData()
	 * @generated
	 */
	EAttribute getBasicData_Interpretation();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.BasicData#getInterpretationNotes <em>Interpretation Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Interpretation Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.BasicData#getInterpretationNotes()
	 * @see #getBasicData()
	 * @generated
	 */
	EAttribute getBasicData_InterpretationNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.BasicData#getName <em>Name</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eodisp.hla.crc.omt.BasicData#getName()
	 * @see #getBasicData()
	 * @generated
	 */
	EAttribute getBasicData_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.BasicData#getNameNotes <em>Name Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.BasicData#getNameNotes()
	 * @see #getBasicData()
	 * @generated
	 */
	EAttribute getBasicData_NameNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.BasicData#getSize <em>Size</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Size</em>'.
	 * @see org.eodisp.hla.crc.omt.BasicData#getSize()
	 * @see #getBasicData()
	 * @generated
	 */
	EAttribute getBasicData_Size();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.BasicData#getSizeNotes <em>Size Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Size Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.BasicData#getSizeNotes()
	 * @see #getBasicData()
	 * @generated
	 */
	EAttribute getBasicData_SizeNotes();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.BasicDataRepresentations <em>Basic Data Representations</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Basic Data Representations</em>'.
	 * @see org.eodisp.hla.crc.omt.BasicDataRepresentations
	 * @generated
	 */
	EClass getBasicDataRepresentations();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eodisp.hla.crc.omt.BasicDataRepresentations#getBasicData <em>Basic Data</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Basic Data</em>'.
	 * @see org.eodisp.hla.crc.omt.BasicDataRepresentations#getBasicData()
	 * @see #getBasicDataRepresentations()
	 * @generated
	 */
	EReference getBasicDataRepresentations_BasicData();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.DataTypes <em>Data Types</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Data Types</em>'.
	 * @see org.eodisp.hla.crc.omt.DataTypes
	 * @generated
	 */
	EClass getDataTypes();

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.hla.crc.omt.DataTypes#getBasicDataRepresentations <em>Basic Data Representations</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Basic Data Representations</em>'.
	 * @see org.eodisp.hla.crc.omt.DataTypes#getBasicDataRepresentations()
	 * @see #getDataTypes()
	 * @generated
	 */
	EReference getDataTypes_BasicDataRepresentations();

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.hla.crc.omt.DataTypes#getSimpleDataTypes <em>Simple Data Types</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Simple Data Types</em>'.
	 * @see org.eodisp.hla.crc.omt.DataTypes#getSimpleDataTypes()
	 * @see #getDataTypes()
	 * @generated
	 */
	EReference getDataTypes_SimpleDataTypes();

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.hla.crc.omt.DataTypes#getEnumeratedDataTypes <em>Enumerated Data Types</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Enumerated Data Types</em>'.
	 * @see org.eodisp.hla.crc.omt.DataTypes#getEnumeratedDataTypes()
	 * @see #getDataTypes()
	 * @generated
	 */
	EReference getDataTypes_EnumeratedDataTypes();

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.hla.crc.omt.DataTypes#getArrayDataTypes <em>Array Data Types</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Array Data Types</em>'.
	 * @see org.eodisp.hla.crc.omt.DataTypes#getArrayDataTypes()
	 * @see #getDataTypes()
	 * @generated
	 */
	EReference getDataTypes_ArrayDataTypes();

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.hla.crc.omt.DataTypes#getFixedRecordDataTypes <em>Fixed Record Data Types</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Fixed Record Data Types</em>'.
	 * @see org.eodisp.hla.crc.omt.DataTypes#getFixedRecordDataTypes()
	 * @see #getDataTypes()
	 * @generated
	 */
	EReference getDataTypes_FixedRecordDataTypes();

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.hla.crc.omt.DataTypes#getVariantRecordDataTypes <em>Variant Record Data Types</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Variant Record Data Types</em>'.
	 * @see org.eodisp.hla.crc.omt.DataTypes#getVariantRecordDataTypes()
	 * @see #getDataTypes()
	 * @generated
	 */
	EReference getDataTypes_VariantRecordDataTypes();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.DeleteRemoveTag <em>Delete Remove Tag</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Delete Remove Tag</em>'.
	 * @see org.eodisp.hla.crc.omt.DeleteRemoveTag
	 * @generated
	 */
	EClass getDeleteRemoveTag();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.DeleteRemoveTag#getDataType <em>Data Type</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type</em>'.
	 * @see org.eodisp.hla.crc.omt.DeleteRemoveTag#getDataType()
	 * @see #getDeleteRemoveTag()
	 * @generated
	 */
	EAttribute getDeleteRemoveTag_DataType();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.DeleteRemoveTag#getDataTypeNotes <em>Data Type Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.DeleteRemoveTag#getDataTypeNotes()
	 * @see #getDeleteRemoveTag()
	 * @generated
	 */
	EAttribute getDeleteRemoveTag_DataTypeNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.DeleteRemoveTag#getSemantics <em>Semantics</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics</em>'.
	 * @see org.eodisp.hla.crc.omt.DeleteRemoveTag#getSemantics()
	 * @see #getDeleteRemoveTag()
	 * @generated
	 */
	EAttribute getDeleteRemoveTag_Semantics();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.DeleteRemoveTag#getSemanticsNotes <em>Semantics Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.DeleteRemoveTag#getSemanticsNotes()
	 * @see #getDeleteRemoveTag()
	 * @generated
	 */
	EAttribute getDeleteRemoveTag_SemanticsNotes();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.Dimension <em>Dimension</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Dimension</em>'.
	 * @see org.eodisp.hla.crc.omt.Dimension
	 * @generated
	 */
	EClass getDimension();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Dimension#getDataType <em>Data Type</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type</em>'.
	 * @see org.eodisp.hla.crc.omt.Dimension#getDataType()
	 * @see #getDimension()
	 * @generated
	 */
	EAttribute getDimension_DataType();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Dimension#getDataTypeNotes <em>Data Type Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Dimension#getDataTypeNotes()
	 * @see #getDimension()
	 * @generated
	 */
	EAttribute getDimension_DataTypeNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Dimension#getName <em>Name</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eodisp.hla.crc.omt.Dimension#getName()
	 * @see #getDimension()
	 * @generated
	 */
	EAttribute getDimension_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Dimension#getNameNotes <em>Name Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Dimension#getNameNotes()
	 * @see #getDimension()
	 * @generated
	 */
	EAttribute getDimension_NameNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Dimension#getNormalization <em>Normalization</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Normalization</em>'.
	 * @see org.eodisp.hla.crc.omt.Dimension#getNormalization()
	 * @see #getDimension()
	 * @generated
	 */
	EAttribute getDimension_Normalization();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Dimension#getNormalizationNotes <em>Normalization Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Normalization Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Dimension#getNormalizationNotes()
	 * @see #getDimension()
	 * @generated
	 */
	EAttribute getDimension_NormalizationNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Dimension#getUpperBound <em>Upper Bound</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Upper Bound</em>'.
	 * @see org.eodisp.hla.crc.omt.Dimension#getUpperBound()
	 * @see #getDimension()
	 * @generated
	 */
	EAttribute getDimension_UpperBound();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Dimension#getUpperBoundNotes <em>Upper Bound Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Upper Bound Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Dimension#getUpperBoundNotes()
	 * @see #getDimension()
	 * @generated
	 */
	EAttribute getDimension_UpperBoundNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Dimension#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see org.eodisp.hla.crc.omt.Dimension#getValue()
	 * @see #getDimension()
	 * @generated
	 */
	EAttribute getDimension_Value();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Dimension#getValueNotes <em>Value Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Dimension#getValueNotes()
	 * @see #getDimension()
	 * @generated
	 */
	EAttribute getDimension_ValueNotes();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.Dimensions <em>Dimensions</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Dimensions</em>'.
	 * @see org.eodisp.hla.crc.omt.Dimensions
	 * @generated
	 */
	EClass getDimensions();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eodisp.hla.crc.omt.Dimensions#getDimension <em>Dimension</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Dimension</em>'.
	 * @see org.eodisp.hla.crc.omt.Dimensions#getDimension()
	 * @see #getDimensions()
	 * @generated
	 */
	EReference getDimensions_Dimension();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.DivestitureCompletionTag <em>Divestiture Completion Tag</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Divestiture Completion Tag</em>'.
	 * @see org.eodisp.hla.crc.omt.DivestitureCompletionTag
	 * @generated
	 */
	EClass getDivestitureCompletionTag();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.DivestitureCompletionTag#getDataType <em>Data Type</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type</em>'.
	 * @see org.eodisp.hla.crc.omt.DivestitureCompletionTag#getDataType()
	 * @see #getDivestitureCompletionTag()
	 * @generated
	 */
	EAttribute getDivestitureCompletionTag_DataType();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.DivestitureCompletionTag#getDataTypeNotes <em>Data Type Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.DivestitureCompletionTag#getDataTypeNotes()
	 * @see #getDivestitureCompletionTag()
	 * @generated
	 */
	EAttribute getDivestitureCompletionTag_DataTypeNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.DivestitureCompletionTag#getSemantics <em>Semantics</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics</em>'.
	 * @see org.eodisp.hla.crc.omt.DivestitureCompletionTag#getSemantics()
	 * @see #getDivestitureCompletionTag()
	 * @generated
	 */
	EAttribute getDivestitureCompletionTag_Semantics();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.DivestitureCompletionTag#getSemanticsNotes <em>Semantics Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.DivestitureCompletionTag#getSemanticsNotes()
	 * @see #getDivestitureCompletionTag()
	 * @generated
	 */
	EAttribute getDivestitureCompletionTag_SemanticsNotes();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.DivestitureRequestTag <em>Divestiture Request Tag</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Divestiture Request Tag</em>'.
	 * @see org.eodisp.hla.crc.omt.DivestitureRequestTag
	 * @generated
	 */
	EClass getDivestitureRequestTag();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.DivestitureRequestTag#getDataType <em>Data Type</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type</em>'.
	 * @see org.eodisp.hla.crc.omt.DivestitureRequestTag#getDataType()
	 * @see #getDivestitureRequestTag()
	 * @generated
	 */
	EAttribute getDivestitureRequestTag_DataType();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.DivestitureRequestTag#getDataTypeNotes <em>Data Type Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.DivestitureRequestTag#getDataTypeNotes()
	 * @see #getDivestitureRequestTag()
	 * @generated
	 */
	EAttribute getDivestitureRequestTag_DataTypeNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.DivestitureRequestTag#getSemantics <em>Semantics</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics</em>'.
	 * @see org.eodisp.hla.crc.omt.DivestitureRequestTag#getSemantics()
	 * @see #getDivestitureRequestTag()
	 * @generated
	 */
	EAttribute getDivestitureRequestTag_Semantics();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.DivestitureRequestTag#getSemanticsNotes <em>Semantics Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.DivestitureRequestTag#getSemanticsNotes()
	 * @see #getDivestitureRequestTag()
	 * @generated
	 */
	EAttribute getDivestitureRequestTag_SemanticsNotes();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.DocumentRoot <em>Document Root</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Document Root</em>'.
	 * @see org.eodisp.hla.crc.omt.DocumentRoot
	 * @generated
	 */
	EClass getDocumentRoot();

	/**
	 * Returns the meta object for the attribute list '{@link org.eodisp.hla.crc.omt.DocumentRoot#getMixed <em>Mixed</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Mixed</em>'.
	 * @see org.eodisp.hla.crc.omt.DocumentRoot#getMixed()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EAttribute getDocumentRoot_Mixed();

	/**
	 * Returns the meta object for the map '{@link org.eodisp.hla.crc.omt.DocumentRoot#getXMLNSPrefixMap <em>XMLNS Prefix Map</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the map '<em>XMLNS Prefix Map</em>'.
	 * @see org.eodisp.hla.crc.omt.DocumentRoot#getXMLNSPrefixMap()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_XMLNSPrefixMap();

	/**
	 * Returns the meta object for the map '{@link org.eodisp.hla.crc.omt.DocumentRoot#getXSISchemaLocation <em>XSI Schema Location</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the map '<em>XSI Schema Location</em>'.
	 * @see org.eodisp.hla.crc.omt.DocumentRoot#getXSISchemaLocation()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_XSISchemaLocation();

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.hla.crc.omt.DocumentRoot#getObjectModel <em>Object Model</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Object Model</em>'.
	 * @see org.eodisp.hla.crc.omt.DocumentRoot#getObjectModel()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_ObjectModel();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.EnumeratedData <em>Enumerated Data</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Enumerated Data</em>'.
	 * @see org.eodisp.hla.crc.omt.EnumeratedData
	 * @generated
	 */
	EClass getEnumeratedData();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eodisp.hla.crc.omt.EnumeratedData#getEnumerator <em>Enumerator</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Enumerator</em>'.
	 * @see org.eodisp.hla.crc.omt.EnumeratedData#getEnumerator()
	 * @see #getEnumeratedData()
	 * @generated
	 */
	EReference getEnumeratedData_Enumerator();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.EnumeratedData#getName <em>Name</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eodisp.hla.crc.omt.EnumeratedData#getName()
	 * @see #getEnumeratedData()
	 * @generated
	 */
	EAttribute getEnumeratedData_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.EnumeratedData#getNameNotes <em>Name Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.EnumeratedData#getNameNotes()
	 * @see #getEnumeratedData()
	 * @generated
	 */
	EAttribute getEnumeratedData_NameNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.EnumeratedData#getRepresentation <em>Representation</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Representation</em>'.
	 * @see org.eodisp.hla.crc.omt.EnumeratedData#getRepresentation()
	 * @see #getEnumeratedData()
	 * @generated
	 */
	EAttribute getEnumeratedData_Representation();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.EnumeratedData#getRepresentationNotes <em>Representation Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Representation Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.EnumeratedData#getRepresentationNotes()
	 * @see #getEnumeratedData()
	 * @generated
	 */
	EAttribute getEnumeratedData_RepresentationNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.EnumeratedData#getSemantics <em>Semantics</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics</em>'.
	 * @see org.eodisp.hla.crc.omt.EnumeratedData#getSemantics()
	 * @see #getEnumeratedData()
	 * @generated
	 */
	EAttribute getEnumeratedData_Semantics();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.EnumeratedData#getSemanticsNotes <em>Semantics Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.EnumeratedData#getSemanticsNotes()
	 * @see #getEnumeratedData()
	 * @generated
	 */
	EAttribute getEnumeratedData_SemanticsNotes();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.EnumeratedDataTypes <em>Enumerated Data Types</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Enumerated Data Types</em>'.
	 * @see org.eodisp.hla.crc.omt.EnumeratedDataTypes
	 * @generated
	 */
	EClass getEnumeratedDataTypes();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eodisp.hla.crc.omt.EnumeratedDataTypes#getEnumeratedData <em>Enumerated Data</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Enumerated Data</em>'.
	 * @see org.eodisp.hla.crc.omt.EnumeratedDataTypes#getEnumeratedData()
	 * @see #getEnumeratedDataTypes()
	 * @generated
	 */
	EReference getEnumeratedDataTypes_EnumeratedData();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.Enumerator <em>Enumerator</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Enumerator</em>'.
	 * @see org.eodisp.hla.crc.omt.Enumerator
	 * @generated
	 */
	EClass getEnumerator();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Enumerator#getName <em>Name</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eodisp.hla.crc.omt.Enumerator#getName()
	 * @see #getEnumerator()
	 * @generated
	 */
	EAttribute getEnumerator_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Enumerator#getNameNotes <em>Name Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Enumerator#getNameNotes()
	 * @see #getEnumerator()
	 * @generated
	 */
	EAttribute getEnumerator_NameNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Enumerator#getValues <em>Values</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Values</em>'.
	 * @see org.eodisp.hla.crc.omt.Enumerator#getValues()
	 * @see #getEnumerator()
	 * @generated
	 */
	EAttribute getEnumerator_Values();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Enumerator#getValuesNotes <em>Values Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Values Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Enumerator#getValuesNotes()
	 * @see #getEnumerator()
	 * @generated
	 */
	EAttribute getEnumerator_ValuesNotes();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.Field <em>Field</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Field</em>'.
	 * @see org.eodisp.hla.crc.omt.Field
	 * @generated
	 */
	EClass getField();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Field#getDataType <em>Data Type</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type</em>'.
	 * @see org.eodisp.hla.crc.omt.Field#getDataType()
	 * @see #getField()
	 * @generated
	 */
	EAttribute getField_DataType();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Field#getDataTypeNotes <em>Data Type Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Field#getDataTypeNotes()
	 * @see #getField()
	 * @generated
	 */
	EAttribute getField_DataTypeNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Field#getName <em>Name</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eodisp.hla.crc.omt.Field#getName()
	 * @see #getField()
	 * @generated
	 */
	EAttribute getField_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Field#getNameNotes <em>Name Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Field#getNameNotes()
	 * @see #getField()
	 * @generated
	 */
	EAttribute getField_NameNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Field#getSemantics <em>Semantics</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics</em>'.
	 * @see org.eodisp.hla.crc.omt.Field#getSemantics()
	 * @see #getField()
	 * @generated
	 */
	EAttribute getField_Semantics();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Field#getSemanticsNotes <em>Semantics Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Field#getSemanticsNotes()
	 * @see #getField()
	 * @generated
	 */
	EAttribute getField_SemanticsNotes();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.FixedRecordData <em>Fixed Record Data</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Fixed Record Data</em>'.
	 * @see org.eodisp.hla.crc.omt.FixedRecordData
	 * @generated
	 */
	EClass getFixedRecordData();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eodisp.hla.crc.omt.FixedRecordData#getField <em>Field</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Field</em>'.
	 * @see org.eodisp.hla.crc.omt.FixedRecordData#getField()
	 * @see #getFixedRecordData()
	 * @generated
	 */
	EReference getFixedRecordData_Field();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.FixedRecordData#getEncoding <em>Encoding</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Encoding</em>'.
	 * @see org.eodisp.hla.crc.omt.FixedRecordData#getEncoding()
	 * @see #getFixedRecordData()
	 * @generated
	 */
	EAttribute getFixedRecordData_Encoding();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.FixedRecordData#getEncodingNotes <em>Encoding Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Encoding Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.FixedRecordData#getEncodingNotes()
	 * @see #getFixedRecordData()
	 * @generated
	 */
	EAttribute getFixedRecordData_EncodingNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.FixedRecordData#getName <em>Name</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eodisp.hla.crc.omt.FixedRecordData#getName()
	 * @see #getFixedRecordData()
	 * @generated
	 */
	EAttribute getFixedRecordData_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.FixedRecordData#getNameNotes <em>Name Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.FixedRecordData#getNameNotes()
	 * @see #getFixedRecordData()
	 * @generated
	 */
	EAttribute getFixedRecordData_NameNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.FixedRecordData#getSemantics <em>Semantics</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics</em>'.
	 * @see org.eodisp.hla.crc.omt.FixedRecordData#getSemantics()
	 * @see #getFixedRecordData()
	 * @generated
	 */
	EAttribute getFixedRecordData_Semantics();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.FixedRecordData#getSemanticsNotes <em>Semantics Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.FixedRecordData#getSemanticsNotes()
	 * @see #getFixedRecordData()
	 * @generated
	 */
	EAttribute getFixedRecordData_SemanticsNotes();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.FixedRecordDataTypes <em>Fixed Record Data Types</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Fixed Record Data Types</em>'.
	 * @see org.eodisp.hla.crc.omt.FixedRecordDataTypes
	 * @generated
	 */
	EClass getFixedRecordDataTypes();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eodisp.hla.crc.omt.FixedRecordDataTypes#getFixedRecordData <em>Fixed Record Data</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Fixed Record Data</em>'.
	 * @see org.eodisp.hla.crc.omt.FixedRecordDataTypes#getFixedRecordData()
	 * @see #getFixedRecordDataTypes()
	 * @generated
	 */
	EReference getFixedRecordDataTypes_FixedRecordData();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.InteractionClass <em>Interaction Class</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Interaction Class</em>'.
	 * @see org.eodisp.hla.crc.omt.InteractionClass
	 * @generated
	 */
	EClass getInteractionClass();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eodisp.hla.crc.omt.InteractionClass#getParameters <em>Parameters</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Parameters</em>'.
	 * @see org.eodisp.hla.crc.omt.InteractionClass#getParameters()
	 * @see #getInteractionClass()
	 * @generated
	 */
	EReference getInteractionClass_Parameters();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eodisp.hla.crc.omt.InteractionClass#getSubClasses <em>Sub Classes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Sub Classes</em>'.
	 * @see org.eodisp.hla.crc.omt.InteractionClass#getSubClasses()
	 * @see #getInteractionClass()
	 * @generated
	 */
	EReference getInteractionClass_SubClasses();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.InteractionClass#getDimensions <em>Dimensions</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Dimensions</em>'.
	 * @see org.eodisp.hla.crc.omt.InteractionClass#getDimensions()
	 * @see #getInteractionClass()
	 * @generated
	 */
	EAttribute getInteractionClass_Dimensions();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.InteractionClass#getDimensionsNotes <em>Dimensions Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Dimensions Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.InteractionClass#getDimensionsNotes()
	 * @see #getInteractionClass()
	 * @generated
	 */
	EAttribute getInteractionClass_DimensionsNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.InteractionClass#getName <em>Name</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eodisp.hla.crc.omt.InteractionClass#getName()
	 * @see #getInteractionClass()
	 * @generated
	 */
	EAttribute getInteractionClass_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.InteractionClass#getNameNotes <em>Name Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.InteractionClass#getNameNotes()
	 * @see #getInteractionClass()
	 * @generated
	 */
	EAttribute getInteractionClass_NameNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.InteractionClass#getOrder <em>Order</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Order</em>'.
	 * @see org.eodisp.hla.crc.omt.InteractionClass#getOrder()
	 * @see #getInteractionClass()
	 * @generated
	 */
	EAttribute getInteractionClass_Order();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.InteractionClass#getOrderNotes <em>Order Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Order Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.InteractionClass#getOrderNotes()
	 * @see #getInteractionClass()
	 * @generated
	 */
	EAttribute getInteractionClass_OrderNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.InteractionClass#getSemantics <em>Semantics</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics</em>'.
	 * @see org.eodisp.hla.crc.omt.InteractionClass#getSemantics()
	 * @see #getInteractionClass()
	 * @generated
	 */
	EAttribute getInteractionClass_Semantics();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.InteractionClass#getSemanticsNotes <em>Semantics Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.InteractionClass#getSemanticsNotes()
	 * @see #getInteractionClass()
	 * @generated
	 */
	EAttribute getInteractionClass_SemanticsNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.InteractionClass#getSharing <em>Sharing</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sharing</em>'.
	 * @see org.eodisp.hla.crc.omt.InteractionClass#getSharing()
	 * @see #getInteractionClass()
	 * @generated
	 */
	EAttribute getInteractionClass_Sharing();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.InteractionClass#getSharingNotes <em>Sharing Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sharing Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.InteractionClass#getSharingNotes()
	 * @see #getInteractionClass()
	 * @generated
	 */
	EAttribute getInteractionClass_SharingNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.InteractionClass#getTransportation <em>Transportation</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Transportation</em>'.
	 * @see org.eodisp.hla.crc.omt.InteractionClass#getTransportation()
	 * @see #getInteractionClass()
	 * @generated
	 */
	EAttribute getInteractionClass_Transportation();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.InteractionClass#getTransportationNotes <em>Transportation Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Transportation Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.InteractionClass#getTransportationNotes()
	 * @see #getInteractionClass()
	 * @generated
	 */
	EAttribute getInteractionClass_TransportationNotes();

	/**
	 * Returns the meta object for the reference list '{@link org.eodisp.hla.crc.omt.InteractionClass#getSubscribingFederates <em>Subscribing Federates</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Subscribing Federates</em>'.
	 * @see org.eodisp.hla.crc.omt.InteractionClass#getSubscribingFederates()
	 * @see #getInteractionClass()
	 * @generated
	 */
	EReference getInteractionClass_SubscribingFederates();

	/**
	 * Returns the meta object for the reference list '{@link org.eodisp.hla.crc.omt.InteractionClass#getPublishingFederates <em>Publishing Federates</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Publishing Federates</em>'.
	 * @see org.eodisp.hla.crc.omt.InteractionClass#getPublishingFederates()
	 * @see #getInteractionClass()
	 * @generated
	 */
	EReference getInteractionClass_PublishingFederates();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.Interactions <em>Interactions</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Interactions</em>'.
	 * @see org.eodisp.hla.crc.omt.Interactions
	 * @generated
	 */
	EClass getInteractions();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eodisp.hla.crc.omt.Interactions#getInteractionClass <em>Interaction Class</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Interaction Class</em>'.
	 * @see org.eodisp.hla.crc.omt.Interactions#getInteractionClass()
	 * @see #getInteractions()
	 * @generated
	 */
	EReference getInteractions_InteractionClass();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.Lookahead <em>Lookahead</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Lookahead</em>'.
	 * @see org.eodisp.hla.crc.omt.Lookahead
	 * @generated
	 */
	EClass getLookahead();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Lookahead#getDataType <em>Data Type</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type</em>'.
	 * @see org.eodisp.hla.crc.omt.Lookahead#getDataType()
	 * @see #getLookahead()
	 * @generated
	 */
	EAttribute getLookahead_DataType();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Lookahead#getDataTypeNotes <em>Data Type Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Lookahead#getDataTypeNotes()
	 * @see #getLookahead()
	 * @generated
	 */
	EAttribute getLookahead_DataTypeNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Lookahead#getSemantics <em>Semantics</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics</em>'.
	 * @see org.eodisp.hla.crc.omt.Lookahead#getSemantics()
	 * @see #getLookahead()
	 * @generated
	 */
	EAttribute getLookahead_Semantics();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Lookahead#getSemanticsNotes <em>Semantics Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Lookahead#getSemanticsNotes()
	 * @see #getLookahead()
	 * @generated
	 */
	EAttribute getLookahead_SemanticsNotes();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.Note <em>Note</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Note</em>'.
	 * @see org.eodisp.hla.crc.omt.Note
	 * @generated
	 */
	EClass getNote();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Note#getName <em>Name</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eodisp.hla.crc.omt.Note#getName()
	 * @see #getNote()
	 * @generated
	 */
	EAttribute getNote_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Note#getSemantics <em>Semantics</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics</em>'.
	 * @see org.eodisp.hla.crc.omt.Note#getSemantics()
	 * @see #getNote()
	 * @generated
	 */
	EAttribute getNote_Semantics();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Note#getSemanticsNotes <em>Semantics Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Note#getSemanticsNotes()
	 * @see #getNote()
	 * @generated
	 */
	EAttribute getNote_SemanticsNotes();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.Notes <em>Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Notes
	 * @generated
	 */
	EClass getNotes();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eodisp.hla.crc.omt.Notes#getNote <em>Note</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Note</em>'.
	 * @see org.eodisp.hla.crc.omt.Notes#getNote()
	 * @see #getNotes()
	 * @generated
	 */
	EReference getNotes_Note();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.ObjectClass <em>Object Class</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Object Class</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectClass
	 * @generated
	 */
	EClass getObjectClass();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eodisp.hla.crc.omt.ObjectClass#getAttributes <em>Attributes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Attributes</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectClass#getAttributes()
	 * @see #getObjectClass()
	 * @generated
	 */
	EReference getObjectClass_Attributes();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eodisp.hla.crc.omt.ObjectClass#getSubClasses <em>Sub Classes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Sub Classes</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectClass#getSubClasses()
	 * @see #getObjectClass()
	 * @generated
	 */
	EReference getObjectClass_SubClasses();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectClass#getName <em>Name</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectClass#getName()
	 * @see #getObjectClass()
	 * @generated
	 */
	EAttribute getObjectClass_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectClass#getNameNotes <em>Name Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectClass#getNameNotes()
	 * @see #getObjectClass()
	 * @generated
	 */
	EAttribute getObjectClass_NameNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectClass#getSemantics <em>Semantics</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectClass#getSemantics()
	 * @see #getObjectClass()
	 * @generated
	 */
	EAttribute getObjectClass_Semantics();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectClass#getSemanticsNotes <em>Semantics Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectClass#getSemanticsNotes()
	 * @see #getObjectClass()
	 * @generated
	 */
	EAttribute getObjectClass_SemanticsNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectClass#getSharing <em>Sharing</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sharing</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectClass#getSharing()
	 * @see #getObjectClass()
	 * @generated
	 */
	EAttribute getObjectClass_Sharing();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectClass#getSharingNotes <em>Sharing Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sharing Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectClass#getSharingNotes()
	 * @see #getObjectClass()
	 * @generated
	 */
	EAttribute getObjectClass_SharingNotes();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.ObjectModel <em>Object Model</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Object Model</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel
	 * @generated
	 */
	EClass getObjectModel();

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.hla.crc.omt.ObjectModel#getObjects <em>Objects</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Objects</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getObjects()
	 * @see #getObjectModel()
	 * @generated
	 */
	EReference getObjectModel_Objects();

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.hla.crc.omt.ObjectModel#getInteractions <em>Interactions</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Interactions</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getInteractions()
	 * @see #getObjectModel()
	 * @generated
	 */
	EReference getObjectModel_Interactions();

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.hla.crc.omt.ObjectModel#getDimensions <em>Dimensions</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Dimensions</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getDimensions()
	 * @see #getObjectModel()
	 * @generated
	 */
	EReference getObjectModel_Dimensions();

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.hla.crc.omt.ObjectModel#getTime <em>Time</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Time</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getTime()
	 * @see #getObjectModel()
	 * @generated
	 */
	EReference getObjectModel_Time();

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.hla.crc.omt.ObjectModel#getTags <em>Tags</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Tags</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getTags()
	 * @see #getObjectModel()
	 * @generated
	 */
	EReference getObjectModel_Tags();

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.hla.crc.omt.ObjectModel#getSynchronizations <em>Synchronizations</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Synchronizations</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getSynchronizations()
	 * @see #getObjectModel()
	 * @generated
	 */
	EReference getObjectModel_Synchronizations();

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.hla.crc.omt.ObjectModel#getTransportations <em>Transportations</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Transportations</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getTransportations()
	 * @see #getObjectModel()
	 * @generated
	 */
	EReference getObjectModel_Transportations();

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.hla.crc.omt.ObjectModel#getSwitches <em>Switches</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Switches</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getSwitches()
	 * @see #getObjectModel()
	 * @generated
	 */
	EReference getObjectModel_Switches();

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.hla.crc.omt.ObjectModel#getDataTypes <em>Data Types</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Data Types</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getDataTypes()
	 * @see #getObjectModel()
	 * @generated
	 */
	EReference getObjectModel_DataTypes();

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.hla.crc.omt.ObjectModel#getNotes <em>Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getNotes()
	 * @see #getObjectModel()
	 * @generated
	 */
	EReference getObjectModel_Notes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectModel#getAppDomain <em>App Domain</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>App Domain</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getAppDomain()
	 * @see #getObjectModel()
	 * @generated
	 */
	EAttribute getObjectModel_AppDomain();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectModel#getAppDomainNotes <em>App Domain Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>App Domain Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getAppDomainNotes()
	 * @see #getObjectModel()
	 * @generated
	 */
	EAttribute getObjectModel_AppDomainNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectModel#getDate <em>Date</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Date</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getDate()
	 * @see #getObjectModel()
	 * @generated
	 */
	EAttribute getObjectModel_Date();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectModel#getDateNotes <em>Date Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Date Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getDateNotes()
	 * @see #getObjectModel()
	 * @generated
	 */
	EAttribute getObjectModel_DateNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectModel#getDTDversion <em>DT Dversion</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>DT Dversion</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getDTDversion()
	 * @see #getObjectModel()
	 * @generated
	 */
	EAttribute getObjectModel_DTDversion();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectModel#getName <em>Name</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getName()
	 * @see #getObjectModel()
	 * @generated
	 */
	EAttribute getObjectModel_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectModel#getNameNotes <em>Name Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getNameNotes()
	 * @see #getObjectModel()
	 * @generated
	 */
	EAttribute getObjectModel_NameNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectModel#getOther <em>Other</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Other</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getOther()
	 * @see #getObjectModel()
	 * @generated
	 */
	EAttribute getObjectModel_Other();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectModel#getOtherNotes <em>Other Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Other Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getOtherNotes()
	 * @see #getObjectModel()
	 * @generated
	 */
	EAttribute getObjectModel_OtherNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectModel#getPocEmail <em>Poc Email</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Poc Email</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getPocEmail()
	 * @see #getObjectModel()
	 * @generated
	 */
	EAttribute getObjectModel_PocEmail();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectModel#getPocEmailNotes <em>Poc Email Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Poc Email Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getPocEmailNotes()
	 * @see #getObjectModel()
	 * @generated
	 */
	EAttribute getObjectModel_PocEmailNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectModel#getPocName <em>Poc Name</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Poc Name</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getPocName()
	 * @see #getObjectModel()
	 * @generated
	 */
	EAttribute getObjectModel_PocName();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectModel#getPocNameNotes <em>Poc Name Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Poc Name Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getPocNameNotes()
	 * @see #getObjectModel()
	 * @generated
	 */
	EAttribute getObjectModel_PocNameNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectModel#getPocOrg <em>Poc Org</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Poc Org</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getPocOrg()
	 * @see #getObjectModel()
	 * @generated
	 */
	EAttribute getObjectModel_PocOrg();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectModel#getPocOrgNotes <em>Poc Org Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Poc Org Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getPocOrgNotes()
	 * @see #getObjectModel()
	 * @generated
	 */
	EAttribute getObjectModel_PocOrgNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectModel#getPocPhone <em>Poc Phone</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Poc Phone</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getPocPhone()
	 * @see #getObjectModel()
	 * @generated
	 */
	EAttribute getObjectModel_PocPhone();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectModel#getPocPhoneNotes <em>Poc Phone Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Poc Phone Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getPocPhoneNotes()
	 * @see #getObjectModel()
	 * @generated
	 */
	EAttribute getObjectModel_PocPhoneNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectModel#getPurpose <em>Purpose</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Purpose</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getPurpose()
	 * @see #getObjectModel()
	 * @generated
	 */
	EAttribute getObjectModel_Purpose();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectModel#getPurposeNotes <em>Purpose Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Purpose Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getPurposeNotes()
	 * @see #getObjectModel()
	 * @generated
	 */
	EAttribute getObjectModel_PurposeNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectModel#getReferences <em>References</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>References</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getReferences()
	 * @see #getObjectModel()
	 * @generated
	 */
	EAttribute getObjectModel_References();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectModel#getReferencesNotes <em>References Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>References Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getReferencesNotes()
	 * @see #getObjectModel()
	 * @generated
	 */
	EAttribute getObjectModel_ReferencesNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectModel#getSponsor <em>Sponsor</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sponsor</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getSponsor()
	 * @see #getObjectModel()
	 * @generated
	 */
	EAttribute getObjectModel_Sponsor();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectModel#getSponsorNotes <em>Sponsor Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sponsor Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getSponsorNotes()
	 * @see #getObjectModel()
	 * @generated
	 */
	EAttribute getObjectModel_SponsorNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectModel#getType <em>Type</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getType()
	 * @see #getObjectModel()
	 * @generated
	 */
	EAttribute getObjectModel_Type();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectModel#getTypeNotes <em>Type Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getTypeNotes()
	 * @see #getObjectModel()
	 * @generated
	 */
	EAttribute getObjectModel_TypeNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectModel#getVersion <em>Version</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Version</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getVersion()
	 * @see #getObjectModel()
	 * @generated
	 */
	EAttribute getObjectModel_Version();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.ObjectModel#getVersionNotes <em>Version Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Version Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModel#getVersionNotes()
	 * @see #getObjectModel()
	 * @generated
	 */
	EAttribute getObjectModel_VersionNotes();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.Objects <em>Objects</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Objects</em>'.
	 * @see org.eodisp.hla.crc.omt.Objects
	 * @generated
	 */
	EClass getObjects();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eodisp.hla.crc.omt.Objects#getObjectClass <em>Object Class</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Object Class</em>'.
	 * @see org.eodisp.hla.crc.omt.Objects#getObjectClass()
	 * @see #getObjects()
	 * @generated
	 */
	EReference getObjects_ObjectClass();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.Parameter <em>Parameter</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Parameter</em>'.
	 * @see org.eodisp.hla.crc.omt.Parameter
	 * @generated
	 */
	EClass getParameter();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Parameter#getDataType <em>Data Type</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type</em>'.
	 * @see org.eodisp.hla.crc.omt.Parameter#getDataType()
	 * @see #getParameter()
	 * @generated
	 */
	EAttribute getParameter_DataType();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Parameter#getDataTypeNotes <em>Data Type Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Parameter#getDataTypeNotes()
	 * @see #getParameter()
	 * @generated
	 */
	EAttribute getParameter_DataTypeNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Parameter#getName <em>Name</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eodisp.hla.crc.omt.Parameter#getName()
	 * @see #getParameter()
	 * @generated
	 */
	EAttribute getParameter_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Parameter#getNameNotes <em>Name Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Parameter#getNameNotes()
	 * @see #getParameter()
	 * @generated
	 */
	EAttribute getParameter_NameNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Parameter#getSemantics <em>Semantics</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics</em>'.
	 * @see org.eodisp.hla.crc.omt.Parameter#getSemantics()
	 * @see #getParameter()
	 * @generated
	 */
	EAttribute getParameter_Semantics();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Parameter#getSemanticsNotes <em>Semantics Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Parameter#getSemanticsNotes()
	 * @see #getParameter()
	 * @generated
	 */
	EAttribute getParameter_SemanticsNotes();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.RequestUpdateTag <em>Request Update Tag</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Request Update Tag</em>'.
	 * @see org.eodisp.hla.crc.omt.RequestUpdateTag
	 * @generated
	 */
	EClass getRequestUpdateTag();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.RequestUpdateTag#getDataType <em>Data Type</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type</em>'.
	 * @see org.eodisp.hla.crc.omt.RequestUpdateTag#getDataType()
	 * @see #getRequestUpdateTag()
	 * @generated
	 */
	EAttribute getRequestUpdateTag_DataType();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.RequestUpdateTag#getDataTypeNotes <em>Data Type Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.RequestUpdateTag#getDataTypeNotes()
	 * @see #getRequestUpdateTag()
	 * @generated
	 */
	EAttribute getRequestUpdateTag_DataTypeNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.RequestUpdateTag#getSemantics <em>Semantics</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics</em>'.
	 * @see org.eodisp.hla.crc.omt.RequestUpdateTag#getSemantics()
	 * @see #getRequestUpdateTag()
	 * @generated
	 */
	EAttribute getRequestUpdateTag_Semantics();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.RequestUpdateTag#getSemanticsNotes <em>Semantics Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.RequestUpdateTag#getSemanticsNotes()
	 * @see #getRequestUpdateTag()
	 * @generated
	 */
	EAttribute getRequestUpdateTag_SemanticsNotes();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.SendReceiveTag <em>Send Receive Tag</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Send Receive Tag</em>'.
	 * @see org.eodisp.hla.crc.omt.SendReceiveTag
	 * @generated
	 */
	EClass getSendReceiveTag();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.SendReceiveTag#getDataType <em>Data Type</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type</em>'.
	 * @see org.eodisp.hla.crc.omt.SendReceiveTag#getDataType()
	 * @see #getSendReceiveTag()
	 * @generated
	 */
	EAttribute getSendReceiveTag_DataType();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.SendReceiveTag#getDataTypeNotes <em>Data Type Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.SendReceiveTag#getDataTypeNotes()
	 * @see #getSendReceiveTag()
	 * @generated
	 */
	EAttribute getSendReceiveTag_DataTypeNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.SendReceiveTag#getSemantics <em>Semantics</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics</em>'.
	 * @see org.eodisp.hla.crc.omt.SendReceiveTag#getSemantics()
	 * @see #getSendReceiveTag()
	 * @generated
	 */
	EAttribute getSendReceiveTag_Semantics();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.SendReceiveTag#getSemanticsNotes <em>Semantics Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.SendReceiveTag#getSemanticsNotes()
	 * @see #getSendReceiveTag()
	 * @generated
	 */
	EAttribute getSendReceiveTag_SemanticsNotes();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.SimpleData <em>Simple Data</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Simple Data</em>'.
	 * @see org.eodisp.hla.crc.omt.SimpleData
	 * @generated
	 */
	EClass getSimpleData();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.SimpleData#getAccuracy <em>Accuracy</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Accuracy</em>'.
	 * @see org.eodisp.hla.crc.omt.SimpleData#getAccuracy()
	 * @see #getSimpleData()
	 * @generated
	 */
	EAttribute getSimpleData_Accuracy();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.SimpleData#getAccuracyNotes <em>Accuracy Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Accuracy Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.SimpleData#getAccuracyNotes()
	 * @see #getSimpleData()
	 * @generated
	 */
	EAttribute getSimpleData_AccuracyNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.SimpleData#getName <em>Name</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eodisp.hla.crc.omt.SimpleData#getName()
	 * @see #getSimpleData()
	 * @generated
	 */
	EAttribute getSimpleData_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.SimpleData#getNameNotes <em>Name Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.SimpleData#getNameNotes()
	 * @see #getSimpleData()
	 * @generated
	 */
	EAttribute getSimpleData_NameNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.SimpleData#getRepresentation <em>Representation</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Representation</em>'.
	 * @see org.eodisp.hla.crc.omt.SimpleData#getRepresentation()
	 * @see #getSimpleData()
	 * @generated
	 */
	EAttribute getSimpleData_Representation();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.SimpleData#getRepresentationNotes <em>Representation Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Representation Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.SimpleData#getRepresentationNotes()
	 * @see #getSimpleData()
	 * @generated
	 */
	EAttribute getSimpleData_RepresentationNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.SimpleData#getResolution <em>Resolution</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Resolution</em>'.
	 * @see org.eodisp.hla.crc.omt.SimpleData#getResolution()
	 * @see #getSimpleData()
	 * @generated
	 */
	EAttribute getSimpleData_Resolution();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.SimpleData#getResolutionNotes <em>Resolution Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Resolution Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.SimpleData#getResolutionNotes()
	 * @see #getSimpleData()
	 * @generated
	 */
	EAttribute getSimpleData_ResolutionNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.SimpleData#getSemantics <em>Semantics</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics</em>'.
	 * @see org.eodisp.hla.crc.omt.SimpleData#getSemantics()
	 * @see #getSimpleData()
	 * @generated
	 */
	EAttribute getSimpleData_Semantics();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.SimpleData#getSemanticsNotes <em>Semantics Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.SimpleData#getSemanticsNotes()
	 * @see #getSimpleData()
	 * @generated
	 */
	EAttribute getSimpleData_SemanticsNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.SimpleData#getUnits <em>Units</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Units</em>'.
	 * @see org.eodisp.hla.crc.omt.SimpleData#getUnits()
	 * @see #getSimpleData()
	 * @generated
	 */
	EAttribute getSimpleData_Units();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.SimpleData#getUnitsNotes <em>Units Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Units Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.SimpleData#getUnitsNotes()
	 * @see #getSimpleData()
	 * @generated
	 */
	EAttribute getSimpleData_UnitsNotes();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.SimpleDataTypes <em>Simple Data Types</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Simple Data Types</em>'.
	 * @see org.eodisp.hla.crc.omt.SimpleDataTypes
	 * @generated
	 */
	EClass getSimpleDataTypes();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eodisp.hla.crc.omt.SimpleDataTypes#getSimpleData <em>Simple Data</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Simple Data</em>'.
	 * @see org.eodisp.hla.crc.omt.SimpleDataTypes#getSimpleData()
	 * @see #getSimpleDataTypes()
	 * @generated
	 */
	EReference getSimpleDataTypes_SimpleData();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.Switches <em>Switches</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Switches</em>'.
	 * @see org.eodisp.hla.crc.omt.Switches
	 * @generated
	 */
	EClass getSwitches();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Switches#getAttributeRelevanceAdvisory <em>Attribute Relevance Advisory</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Attribute Relevance Advisory</em>'.
	 * @see org.eodisp.hla.crc.omt.Switches#getAttributeRelevanceAdvisory()
	 * @see #getSwitches()
	 * @generated
	 */
	EAttribute getSwitches_AttributeRelevanceAdvisory();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Switches#getAttributeRelevanceAdvisoryNotes <em>Attribute Relevance Advisory Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Attribute Relevance Advisory Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Switches#getAttributeRelevanceAdvisoryNotes()
	 * @see #getSwitches()
	 * @generated
	 */
	EAttribute getSwitches_AttributeRelevanceAdvisoryNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Switches#getAttributeScopeAdvisory <em>Attribute Scope Advisory</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Attribute Scope Advisory</em>'.
	 * @see org.eodisp.hla.crc.omt.Switches#getAttributeScopeAdvisory()
	 * @see #getSwitches()
	 * @generated
	 */
	EAttribute getSwitches_AttributeScopeAdvisory();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Switches#getAttributeScopeAdvisoryNotes <em>Attribute Scope Advisory Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Attribute Scope Advisory Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Switches#getAttributeScopeAdvisoryNotes()
	 * @see #getSwitches()
	 * @generated
	 */
	EAttribute getSwitches_AttributeScopeAdvisoryNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Switches#getAutoProvide <em>Auto Provide</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Auto Provide</em>'.
	 * @see org.eodisp.hla.crc.omt.Switches#getAutoProvide()
	 * @see #getSwitches()
	 * @generated
	 */
	EAttribute getSwitches_AutoProvide();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Switches#getAutoProvideNotes <em>Auto Provide Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Auto Provide Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Switches#getAutoProvideNotes()
	 * @see #getSwitches()
	 * @generated
	 */
	EAttribute getSwitches_AutoProvideNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Switches#getConveyRegionDesignatorSets <em>Convey Region Designator Sets</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Convey Region Designator Sets</em>'.
	 * @see org.eodisp.hla.crc.omt.Switches#getConveyRegionDesignatorSets()
	 * @see #getSwitches()
	 * @generated
	 */
	EAttribute getSwitches_ConveyRegionDesignatorSets();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Switches#getConveyRegionDesignatorSetsNotes <em>Convey Region Designator Sets Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Convey Region Designator Sets Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Switches#getConveyRegionDesignatorSetsNotes()
	 * @see #getSwitches()
	 * @generated
	 */
	EAttribute getSwitches_ConveyRegionDesignatorSetsNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Switches#getInteractionRelevanceAdvisory <em>Interaction Relevance Advisory</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Interaction Relevance Advisory</em>'.
	 * @see org.eodisp.hla.crc.omt.Switches#getInteractionRelevanceAdvisory()
	 * @see #getSwitches()
	 * @generated
	 */
	EAttribute getSwitches_InteractionRelevanceAdvisory();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Switches#getInteractionRelevanceAdvisoryNotes <em>Interaction Relevance Advisory Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Interaction Relevance Advisory Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Switches#getInteractionRelevanceAdvisoryNotes()
	 * @see #getSwitches()
	 * @generated
	 */
	EAttribute getSwitches_InteractionRelevanceAdvisoryNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Switches#getObjectClassRelevanceAdvisory <em>Object Class Relevance Advisory</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Object Class Relevance Advisory</em>'.
	 * @see org.eodisp.hla.crc.omt.Switches#getObjectClassRelevanceAdvisory()
	 * @see #getSwitches()
	 * @generated
	 */
	EAttribute getSwitches_ObjectClassRelevanceAdvisory();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Switches#getObjectClassRelevanceAdvisoryNotes <em>Object Class Relevance Advisory Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Object Class Relevance Advisory Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Switches#getObjectClassRelevanceAdvisoryNotes()
	 * @see #getSwitches()
	 * @generated
	 */
	EAttribute getSwitches_ObjectClassRelevanceAdvisoryNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Switches#getServiceReporting <em>Service Reporting</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Service Reporting</em>'.
	 * @see org.eodisp.hla.crc.omt.Switches#getServiceReporting()
	 * @see #getSwitches()
	 * @generated
	 */
	EAttribute getSwitches_ServiceReporting();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Switches#getServiceReportingNotes <em>Service Reporting Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Service Reporting Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Switches#getServiceReportingNotes()
	 * @see #getSwitches()
	 * @generated
	 */
	EAttribute getSwitches_ServiceReportingNotes();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.Synchronization <em>Synchronization</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Synchronization</em>'.
	 * @see org.eodisp.hla.crc.omt.Synchronization
	 * @generated
	 */
	EClass getSynchronization();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Synchronization#getCapability <em>Capability</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Capability</em>'.
	 * @see org.eodisp.hla.crc.omt.Synchronization#getCapability()
	 * @see #getSynchronization()
	 * @generated
	 */
	EAttribute getSynchronization_Capability();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Synchronization#getCapabilityNotes <em>Capability Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Capability Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Synchronization#getCapabilityNotes()
	 * @see #getSynchronization()
	 * @generated
	 */
	EAttribute getSynchronization_CapabilityNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Synchronization#getDataType <em>Data Type</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type</em>'.
	 * @see org.eodisp.hla.crc.omt.Synchronization#getDataType()
	 * @see #getSynchronization()
	 * @generated
	 */
	EAttribute getSynchronization_DataType();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Synchronization#getDataTypeNotes <em>Data Type Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Synchronization#getDataTypeNotes()
	 * @see #getSynchronization()
	 * @generated
	 */
	EAttribute getSynchronization_DataTypeNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Synchronization#getLabel <em>Label</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Label</em>'.
	 * @see org.eodisp.hla.crc.omt.Synchronization#getLabel()
	 * @see #getSynchronization()
	 * @generated
	 */
	EAttribute getSynchronization_Label();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Synchronization#getLabelNotes <em>Label Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Label Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Synchronization#getLabelNotes()
	 * @see #getSynchronization()
	 * @generated
	 */
	EAttribute getSynchronization_LabelNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Synchronization#getSemantics <em>Semantics</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics</em>'.
	 * @see org.eodisp.hla.crc.omt.Synchronization#getSemantics()
	 * @see #getSynchronization()
	 * @generated
	 */
	EAttribute getSynchronization_Semantics();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Synchronization#getSemanticsNotes <em>Semantics Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Synchronization#getSemanticsNotes()
	 * @see #getSynchronization()
	 * @generated
	 */
	EAttribute getSynchronization_SemanticsNotes();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.Synchronizations <em>Synchronizations</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Synchronizations</em>'.
	 * @see org.eodisp.hla.crc.omt.Synchronizations
	 * @generated
	 */
	EClass getSynchronizations();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eodisp.hla.crc.omt.Synchronizations#getSynchronization <em>Synchronization</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Synchronization</em>'.
	 * @see org.eodisp.hla.crc.omt.Synchronizations#getSynchronization()
	 * @see #getSynchronizations()
	 * @generated
	 */
	EReference getSynchronizations_Synchronization();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.Tags <em>Tags</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Tags</em>'.
	 * @see org.eodisp.hla.crc.omt.Tags
	 * @generated
	 */
	EClass getTags();

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.hla.crc.omt.Tags#getUpdateReflectTag <em>Update Reflect Tag</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Update Reflect Tag</em>'.
	 * @see org.eodisp.hla.crc.omt.Tags#getUpdateReflectTag()
	 * @see #getTags()
	 * @generated
	 */
	EReference getTags_UpdateReflectTag();

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.hla.crc.omt.Tags#getSendReceiveTag <em>Send Receive Tag</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Send Receive Tag</em>'.
	 * @see org.eodisp.hla.crc.omt.Tags#getSendReceiveTag()
	 * @see #getTags()
	 * @generated
	 */
	EReference getTags_SendReceiveTag();

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.hla.crc.omt.Tags#getDeleteRemoveTag <em>Delete Remove Tag</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Delete Remove Tag</em>'.
	 * @see org.eodisp.hla.crc.omt.Tags#getDeleteRemoveTag()
	 * @see #getTags()
	 * @generated
	 */
	EReference getTags_DeleteRemoveTag();

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.hla.crc.omt.Tags#getDivestitureRequestTag <em>Divestiture Request Tag</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Divestiture Request Tag</em>'.
	 * @see org.eodisp.hla.crc.omt.Tags#getDivestitureRequestTag()
	 * @see #getTags()
	 * @generated
	 */
	EReference getTags_DivestitureRequestTag();

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.hla.crc.omt.Tags#getDivestitureCompletionTag <em>Divestiture Completion Tag</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Divestiture Completion Tag</em>'.
	 * @see org.eodisp.hla.crc.omt.Tags#getDivestitureCompletionTag()
	 * @see #getTags()
	 * @generated
	 */
	EReference getTags_DivestitureCompletionTag();

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.hla.crc.omt.Tags#getAcquisitionRequestTag <em>Acquisition Request Tag</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Acquisition Request Tag</em>'.
	 * @see org.eodisp.hla.crc.omt.Tags#getAcquisitionRequestTag()
	 * @see #getTags()
	 * @generated
	 */
	EReference getTags_AcquisitionRequestTag();

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.hla.crc.omt.Tags#getRequestUpdateTag <em>Request Update Tag</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Request Update Tag</em>'.
	 * @see org.eodisp.hla.crc.omt.Tags#getRequestUpdateTag()
	 * @see #getTags()
	 * @generated
	 */
	EReference getTags_RequestUpdateTag();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.Time <em>Time</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Time</em>'.
	 * @see org.eodisp.hla.crc.omt.Time
	 * @generated
	 */
	EClass getTime();

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.hla.crc.omt.Time#getTimeStamp <em>Time Stamp</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Time Stamp</em>'.
	 * @see org.eodisp.hla.crc.omt.Time#getTimeStamp()
	 * @see #getTime()
	 * @generated
	 */
	EReference getTime_TimeStamp();

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.hla.crc.omt.Time#getLookahead <em>Lookahead</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Lookahead</em>'.
	 * @see org.eodisp.hla.crc.omt.Time#getLookahead()
	 * @see #getTime()
	 * @generated
	 */
	EReference getTime_Lookahead();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.TimeStamp <em>Time Stamp</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Time Stamp</em>'.
	 * @see org.eodisp.hla.crc.omt.TimeStamp
	 * @generated
	 */
	EClass getTimeStamp();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.TimeStamp#getDataType <em>Data Type</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type</em>'.
	 * @see org.eodisp.hla.crc.omt.TimeStamp#getDataType()
	 * @see #getTimeStamp()
	 * @generated
	 */
	EAttribute getTimeStamp_DataType();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.TimeStamp#getDataTypeNotes <em>Data Type Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.TimeStamp#getDataTypeNotes()
	 * @see #getTimeStamp()
	 * @generated
	 */
	EAttribute getTimeStamp_DataTypeNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.TimeStamp#getSemantics <em>Semantics</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics</em>'.
	 * @see org.eodisp.hla.crc.omt.TimeStamp#getSemantics()
	 * @see #getTimeStamp()
	 * @generated
	 */
	EAttribute getTimeStamp_Semantics();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.TimeStamp#getSemanticsNotes <em>Semantics Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.TimeStamp#getSemanticsNotes()
	 * @see #getTimeStamp()
	 * @generated
	 */
	EAttribute getTimeStamp_SemanticsNotes();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.Transportation <em>Transportation</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Transportation</em>'.
	 * @see org.eodisp.hla.crc.omt.Transportation
	 * @generated
	 */
	EClass getTransportation();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Transportation#getDescription <em>Description</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description</em>'.
	 * @see org.eodisp.hla.crc.omt.Transportation#getDescription()
	 * @see #getTransportation()
	 * @generated
	 */
	EAttribute getTransportation_Description();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Transportation#getDescriptionNotes <em>Description Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Transportation#getDescriptionNotes()
	 * @see #getTransportation()
	 * @generated
	 */
	EAttribute getTransportation_DescriptionNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Transportation#getName <em>Name</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eodisp.hla.crc.omt.Transportation#getName()
	 * @see #getTransportation()
	 * @generated
	 */
	EAttribute getTransportation_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.Transportation#getNameNotes <em>Name Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.Transportation#getNameNotes()
	 * @see #getTransportation()
	 * @generated
	 */
	EAttribute getTransportation_NameNotes();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.Transportations <em>Transportations</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Transportations</em>'.
	 * @see org.eodisp.hla.crc.omt.Transportations
	 * @generated
	 */
	EClass getTransportations();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eodisp.hla.crc.omt.Transportations#getTransportation <em>Transportation</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Transportation</em>'.
	 * @see org.eodisp.hla.crc.omt.Transportations#getTransportation()
	 * @see #getTransportations()
	 * @generated
	 */
	EReference getTransportations_Transportation();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.UpdateReflectTag <em>Update Reflect Tag</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Update Reflect Tag</em>'.
	 * @see org.eodisp.hla.crc.omt.UpdateReflectTag
	 * @generated
	 */
	EClass getUpdateReflectTag();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.UpdateReflectTag#getDataType <em>Data Type</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type</em>'.
	 * @see org.eodisp.hla.crc.omt.UpdateReflectTag#getDataType()
	 * @see #getUpdateReflectTag()
	 * @generated
	 */
	EAttribute getUpdateReflectTag_DataType();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.UpdateReflectTag#getDataTypeNotes <em>Data Type Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.UpdateReflectTag#getDataTypeNotes()
	 * @see #getUpdateReflectTag()
	 * @generated
	 */
	EAttribute getUpdateReflectTag_DataTypeNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.UpdateReflectTag#getSemantics <em>Semantics</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics</em>'.
	 * @see org.eodisp.hla.crc.omt.UpdateReflectTag#getSemantics()
	 * @see #getUpdateReflectTag()
	 * @generated
	 */
	EAttribute getUpdateReflectTag_Semantics();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.UpdateReflectTag#getSemanticsNotes <em>Semantics Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.UpdateReflectTag#getSemanticsNotes()
	 * @see #getUpdateReflectTag()
	 * @generated
	 */
	EAttribute getUpdateReflectTag_SemanticsNotes();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.VariantRecordData <em>Variant Record Data</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Variant Record Data</em>'.
	 * @see org.eodisp.hla.crc.omt.VariantRecordData
	 * @generated
	 */
	EClass getVariantRecordData();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eodisp.hla.crc.omt.VariantRecordData#getAlternative <em>Alternative</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Alternative</em>'.
	 * @see org.eodisp.hla.crc.omt.VariantRecordData#getAlternative()
	 * @see #getVariantRecordData()
	 * @generated
	 */
	EReference getVariantRecordData_Alternative();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.VariantRecordData#getDataType <em>Data Type</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type</em>'.
	 * @see org.eodisp.hla.crc.omt.VariantRecordData#getDataType()
	 * @see #getVariantRecordData()
	 * @generated
	 */
	EAttribute getVariantRecordData_DataType();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.VariantRecordData#getDataTypeNotes <em>Data Type Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Type Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.VariantRecordData#getDataTypeNotes()
	 * @see #getVariantRecordData()
	 * @generated
	 */
	EAttribute getVariantRecordData_DataTypeNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.VariantRecordData#getDiscriminant <em>Discriminant</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Discriminant</em>'.
	 * @see org.eodisp.hla.crc.omt.VariantRecordData#getDiscriminant()
	 * @see #getVariantRecordData()
	 * @generated
	 */
	EAttribute getVariantRecordData_Discriminant();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.VariantRecordData#getDiscriminantNotes <em>Discriminant Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Discriminant Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.VariantRecordData#getDiscriminantNotes()
	 * @see #getVariantRecordData()
	 * @generated
	 */
	EAttribute getVariantRecordData_DiscriminantNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.VariantRecordData#getEncoding <em>Encoding</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Encoding</em>'.
	 * @see org.eodisp.hla.crc.omt.VariantRecordData#getEncoding()
	 * @see #getVariantRecordData()
	 * @generated
	 */
	EAttribute getVariantRecordData_Encoding();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.VariantRecordData#getEncodingNotes <em>Encoding Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Encoding Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.VariantRecordData#getEncodingNotes()
	 * @see #getVariantRecordData()
	 * @generated
	 */
	EAttribute getVariantRecordData_EncodingNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.VariantRecordData#getName <em>Name</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eodisp.hla.crc.omt.VariantRecordData#getName()
	 * @see #getVariantRecordData()
	 * @generated
	 */
	EAttribute getVariantRecordData_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.VariantRecordData#getNameNotes <em>Name Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.VariantRecordData#getNameNotes()
	 * @see #getVariantRecordData()
	 * @generated
	 */
	EAttribute getVariantRecordData_NameNotes();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.VariantRecordData#getSemantics <em>Semantics</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics</em>'.
	 * @see org.eodisp.hla.crc.omt.VariantRecordData#getSemantics()
	 * @see #getVariantRecordData()
	 * @generated
	 */
	EAttribute getVariantRecordData_Semantics();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.omt.VariantRecordData#getSemanticsNotes <em>Semantics Notes</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Semantics Notes</em>'.
	 * @see org.eodisp.hla.crc.omt.VariantRecordData#getSemanticsNotes()
	 * @see #getVariantRecordData()
	 * @generated
	 */
	EAttribute getVariantRecordData_SemanticsNotes();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.omt.VariantRecordDataTypes <em>Variant Record Data Types</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for class '<em>Variant Record Data Types</em>'.
	 * @see org.eodisp.hla.crc.omt.VariantRecordDataTypes
	 * @generated
	 */
	EClass getVariantRecordDataTypes();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eodisp.hla.crc.omt.VariantRecordDataTypes#getVariantRecordData <em>Variant Record Data</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Variant Record Data</em>'.
	 * @see org.eodisp.hla.crc.omt.VariantRecordDataTypes#getVariantRecordData()
	 * @see #getVariantRecordDataTypes()
	 * @generated
	 */
	EReference getVariantRecordDataTypes_VariantRecordData();

	/**
	 * Returns the meta object for enum '{@link org.eodisp.hla.crc.omt.EndianEnum <em>Endian Enum</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Endian Enum</em>'.
	 * @see org.eodisp.hla.crc.omt.EndianEnum
	 * @generated
	 */
	EEnum getEndianEnum();

	/**
	 * Returns the meta object for enum '{@link org.eodisp.hla.crc.omt.ObjectModelTypeEnum <em>Object Model Type Enum</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Object Model Type Enum</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModelTypeEnum
	 * @generated
	 */
	EEnum getObjectModelTypeEnum();

	/**
	 * Returns the meta object for enum '{@link org.eodisp.hla.crc.omt.OrderEnum <em>Order Enum</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Order Enum</em>'.
	 * @see org.eodisp.hla.crc.omt.OrderEnum
	 * @generated
	 */
	EEnum getOrderEnum();

	/**
	 * Returns the meta object for enum '{@link org.eodisp.hla.crc.omt.OwnershipEnum <em>Ownership Enum</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Ownership Enum</em>'.
	 * @see org.eodisp.hla.crc.omt.OwnershipEnum
	 * @generated
	 */
	EEnum getOwnershipEnum();

	/**
	 * Returns the meta object for enum '{@link org.eodisp.hla.crc.omt.SharingEnum <em>Sharing Enum</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Sharing Enum</em>'.
	 * @see org.eodisp.hla.crc.omt.SharingEnum
	 * @generated
	 */
	EEnum getSharingEnum();

	/**
	 * Returns the meta object for enum '{@link org.eodisp.hla.crc.omt.StateEnum <em>State Enum</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for enum '<em>State Enum</em>'.
	 * @see org.eodisp.hla.crc.omt.StateEnum
	 * @generated
	 */
	EEnum getStateEnum();

	/**
	 * Returns the meta object for enum '{@link org.eodisp.hla.crc.omt.SyncCapabilityEnum <em>Sync Capability Enum</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Sync Capability Enum</em>'.
	 * @see org.eodisp.hla.crc.omt.SyncCapabilityEnum
	 * @generated
	 */
	EEnum getSyncCapabilityEnum();

	/**
	 * Returns the meta object for enum '{@link org.eodisp.hla.crc.omt.UpdateTypeEnum <em>Update Type Enum</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Update Type Enum</em>'.
	 * @see org.eodisp.hla.crc.omt.UpdateTypeEnum
	 * @generated
	 */
	EEnum getUpdateTypeEnum();

	/**
	 * Returns the meta object for data type '{@link org.eodisp.hla.crc.omt.DTDVersionEnum <em>DTD Version Enum Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>DTD Version Enum Object</em>'.
	 * @see org.eodisp.hla.crc.omt.DTDVersionEnum
	 * @model instanceClass="org.eodisp.hla.crc.omt.DTDVersionEnum"
	 *        extendedMetaData="name='DTDVersionEnum:Object' baseType='DTDVersionEnum'" 
	 * @generated
	 */
	EDataType getDTDVersionEnumObject();

	/**
	 * Returns the meta object for enum '{@link org.eodisp.hla.crc.omt.DTDVersionEnum <em>DTD Version Enum</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for enum '<em>DTD Version Enum</em>'.
	 * @see org.eodisp.hla.crc.omt.DTDVersionEnum
	 * @generated
	 */
	EEnum getDTDVersionEnum();

	/**
	 * Returns the meta object for data type '{@link org.eodisp.hla.crc.omt.EndianEnum <em>Endian Enum Object</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Endian Enum Object</em>'.
	 * @see org.eodisp.hla.crc.omt.EndianEnum
	 * @model instanceClass="org.eodisp.hla.crc.omt.EndianEnum"
	 *        extendedMetaData="name='EndianEnum:Object' baseType='EndianEnum'" 
	 * @generated
	 */
	EDataType getEndianEnumObject();

	/**
	 * Returns the meta object for data type '{@link org.eodisp.hla.crc.omt.ObjectModelTypeEnum <em>Object Model Type Enum Object</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Object Model Type Enum Object</em>'.
	 * @see org.eodisp.hla.crc.omt.ObjectModelTypeEnum
	 * @model instanceClass="org.eodisp.hla.crc.omt.ObjectModelTypeEnum"
	 *        extendedMetaData="name='ObjectModelTypeEnum:Object' baseType='ObjectModelTypeEnum'" 
	 * @generated
	 */
	EDataType getObjectModelTypeEnumObject();

	/**
	 * Returns the meta object for data type '{@link org.eodisp.hla.crc.omt.OrderEnum <em>Order Enum Object</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Order Enum Object</em>'.
	 * @see org.eodisp.hla.crc.omt.OrderEnum
	 * @model instanceClass="org.eodisp.hla.crc.omt.OrderEnum"
	 *        extendedMetaData="name='OrderEnum:Object' baseType='OrderEnum'" 
	 * @generated
	 */
	EDataType getOrderEnumObject();

	/**
	 * Returns the meta object for data type '{@link org.eodisp.hla.crc.omt.OwnershipEnum <em>Ownership Enum Object</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Ownership Enum Object</em>'.
	 * @see org.eodisp.hla.crc.omt.OwnershipEnum
	 * @model instanceClass="org.eodisp.hla.crc.omt.OwnershipEnum"
	 *        extendedMetaData="name='OwnershipEnum:Object' baseType='OwnershipEnum'" 
	 * @generated
	 */
	EDataType getOwnershipEnumObject();

	/**
	 * Returns the meta object for data type '{@link org.eodisp.hla.crc.omt.SharingEnum <em>Sharing Enum Object</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Sharing Enum Object</em>'.
	 * @see org.eodisp.hla.crc.omt.SharingEnum
	 * @model instanceClass="org.eodisp.hla.crc.omt.SharingEnum"
	 *        extendedMetaData="name='SharingEnum:Object' baseType='SharingEnum'" 
	 * @generated
	 */
	EDataType getSharingEnumObject();

	/**
	 * Returns the meta object for data type '{@link org.eodisp.hla.crc.omt.StateEnum <em>State Enum Object</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for data type '<em>State Enum Object</em>'.
	 * @see org.eodisp.hla.crc.omt.StateEnum
	 * @model instanceClass="org.eodisp.hla.crc.omt.StateEnum"
	 *        extendedMetaData="name='StateEnum:Object' baseType='StateEnum'" 
	 * @generated
	 */
	EDataType getStateEnumObject();

	/**
	 * Returns the meta object for data type '{@link org.eodisp.hla.crc.omt.SyncCapabilityEnum <em>Sync Capability Enum Object</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Sync Capability Enum Object</em>'.
	 * @see org.eodisp.hla.crc.omt.SyncCapabilityEnum
	 * @model instanceClass="org.eodisp.hla.crc.omt.SyncCapabilityEnum"
	 *        extendedMetaData="name='SyncCapabilityEnum:Object' baseType='SyncCapabilityEnum'" 
	 * @generated
	 */
	EDataType getSyncCapabilityEnumObject();

	/**
	 * Returns the meta object for data type '{@link org.eodisp.hla.crc.omt.UpdateTypeEnum <em>Update Type Enum Object</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Update Type Enum Object</em>'.
	 * @see org.eodisp.hla.crc.omt.UpdateTypeEnum
	 * @model instanceClass="org.eodisp.hla.crc.omt.UpdateTypeEnum"
	 *        extendedMetaData="name='UpdateTypeEnum:Object' baseType='UpdateTypeEnum'" 
	 * @generated
	 */
	EDataType getUpdateTypeEnumObject();

	/**
	 * Returns the factory that creates the instances of the model. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	OmtFactory getOmtFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.AcquisitionRequestTagImpl <em>Acquisition Request Tag</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.AcquisitionRequestTagImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getAcquisitionRequestTag()
		 * @generated
		 */
		EClass ACQUISITION_REQUEST_TAG = eINSTANCE.getAcquisitionRequestTag();

		/**
		 * The meta object literal for the '<em><b>Data Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ACQUISITION_REQUEST_TAG__DATA_TYPE = eINSTANCE.getAcquisitionRequestTag_DataType();

		/**
		 * The meta object literal for the '<em><b>Data Type Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ACQUISITION_REQUEST_TAG__DATA_TYPE_NOTES = eINSTANCE.getAcquisitionRequestTag_DataTypeNotes();

		/**
		 * The meta object literal for the '<em><b>Semantics</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ACQUISITION_REQUEST_TAG__SEMANTICS = eINSTANCE.getAcquisitionRequestTag_Semantics();

		/**
		 * The meta object literal for the '<em><b>Semantics Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ACQUISITION_REQUEST_TAG__SEMANTICS_NOTES = eINSTANCE.getAcquisitionRequestTag_SemanticsNotes();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.AlternativeImpl <em>Alternative</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.AlternativeImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getAlternative()
		 * @generated
		 */
		EClass ALTERNATIVE = eINSTANCE.getAlternative();

		/**
		 * The meta object literal for the '<em><b>Data Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ALTERNATIVE__DATA_TYPE = eINSTANCE.getAlternative_DataType();

		/**
		 * The meta object literal for the '<em><b>Data Type Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ALTERNATIVE__DATA_TYPE_NOTES = eINSTANCE.getAlternative_DataTypeNotes();

		/**
		 * The meta object literal for the '<em><b>Enumerator</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ALTERNATIVE__ENUMERATOR = eINSTANCE.getAlternative_Enumerator();

		/**
		 * The meta object literal for the '<em><b>Enumerator Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ALTERNATIVE__ENUMERATOR_NOTES = eINSTANCE.getAlternative_EnumeratorNotes();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ALTERNATIVE__NAME = eINSTANCE.getAlternative_Name();

		/**
		 * The meta object literal for the '<em><b>Name Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ALTERNATIVE__NAME_NOTES = eINSTANCE.getAlternative_NameNotes();

		/**
		 * The meta object literal for the '<em><b>Semantics</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ALTERNATIVE__SEMANTICS = eINSTANCE.getAlternative_Semantics();

		/**
		 * The meta object literal for the '<em><b>Semantics Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ALTERNATIVE__SEMANTICS_NOTES = eINSTANCE.getAlternative_SemanticsNotes();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.ArrayDataImpl <em>Array Data</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.ArrayDataImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getArrayData()
		 * @generated
		 */
		EClass ARRAY_DATA = eINSTANCE.getArrayData();

		/**
		 * The meta object literal for the '<em><b>Cardinality</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ARRAY_DATA__CARDINALITY = eINSTANCE.getArrayData_Cardinality();

		/**
		 * The meta object literal for the '<em><b>Cardinality Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ARRAY_DATA__CARDINALITY_NOTES = eINSTANCE.getArrayData_CardinalityNotes();

		/**
		 * The meta object literal for the '<em><b>Data Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ARRAY_DATA__DATA_TYPE = eINSTANCE.getArrayData_DataType();

		/**
		 * The meta object literal for the '<em><b>Data Type Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ARRAY_DATA__DATA_TYPE_NOTES = eINSTANCE.getArrayData_DataTypeNotes();

		/**
		 * The meta object literal for the '<em><b>Encoding</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ARRAY_DATA__ENCODING = eINSTANCE.getArrayData_Encoding();

		/**
		 * The meta object literal for the '<em><b>Encoding Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ARRAY_DATA__ENCODING_NOTES = eINSTANCE.getArrayData_EncodingNotes();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ARRAY_DATA__NAME = eINSTANCE.getArrayData_Name();

		/**
		 * The meta object literal for the '<em><b>Name Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ARRAY_DATA__NAME_NOTES = eINSTANCE.getArrayData_NameNotes();

		/**
		 * The meta object literal for the '<em><b>Semantics</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ARRAY_DATA__SEMANTICS = eINSTANCE.getArrayData_Semantics();

		/**
		 * The meta object literal for the '<em><b>Semantics Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ARRAY_DATA__SEMANTICS_NOTES = eINSTANCE.getArrayData_SemanticsNotes();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.ArrayDataTypesImpl <em>Array Data Types</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.ArrayDataTypesImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getArrayDataTypes()
		 * @generated
		 */
		EClass ARRAY_DATA_TYPES = eINSTANCE.getArrayDataTypes();

		/**
		 * The meta object literal for the '<em><b>Array Data</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ARRAY_DATA_TYPES__ARRAY_DATA = eINSTANCE.getArrayDataTypes_ArrayData();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.AttributeImpl <em>Attribute</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.AttributeImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getAttribute()
		 * @generated
		 */
		EClass ATTRIBUTE = eINSTANCE.getAttribute();

		/**
		 * The meta object literal for the '<em><b>Data Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__DATA_TYPE = eINSTANCE.getAttribute_DataType();

		/**
		 * The meta object literal for the '<em><b>Data Type Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__DATA_TYPE_NOTES = eINSTANCE.getAttribute_DataTypeNotes();

		/**
		 * The meta object literal for the '<em><b>Dimensions</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__DIMENSIONS = eINSTANCE.getAttribute_Dimensions();

		/**
		 * The meta object literal for the '<em><b>Dimensions Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__DIMENSIONS_NOTES = eINSTANCE.getAttribute_DimensionsNotes();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__NAME = eINSTANCE.getAttribute_Name();

		/**
		 * The meta object literal for the '<em><b>Name Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__NAME_NOTES = eINSTANCE.getAttribute_NameNotes();

		/**
		 * The meta object literal for the '<em><b>Order</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__ORDER = eINSTANCE.getAttribute_Order();

		/**
		 * The meta object literal for the '<em><b>Order Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__ORDER_NOTES = eINSTANCE.getAttribute_OrderNotes();

		/**
		 * The meta object literal for the '<em><b>Ownership</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__OWNERSHIP = eINSTANCE.getAttribute_Ownership();

		/**
		 * The meta object literal for the '<em><b>Ownership Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__OWNERSHIP_NOTES = eINSTANCE.getAttribute_OwnershipNotes();

		/**
		 * The meta object literal for the '<em><b>Semantics</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__SEMANTICS = eINSTANCE.getAttribute_Semantics();

		/**
		 * The meta object literal for the '<em><b>Semantics Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__SEMANTICS_NOTES = eINSTANCE.getAttribute_SemanticsNotes();

		/**
		 * The meta object literal for the '<em><b>Sharing</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__SHARING = eINSTANCE.getAttribute_Sharing();

		/**
		 * The meta object literal for the '<em><b>Sharing Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__SHARING_NOTES = eINSTANCE.getAttribute_SharingNotes();

		/**
		 * The meta object literal for the '<em><b>Transportation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__TRANSPORTATION = eINSTANCE.getAttribute_Transportation();

		/**
		 * The meta object literal for the '<em><b>Transportation Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__TRANSPORTATION_NOTES = eINSTANCE.getAttribute_TransportationNotes();

		/**
		 * The meta object literal for the '<em><b>Update Condition</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__UPDATE_CONDITION = eINSTANCE.getAttribute_UpdateCondition();

		/**
		 * The meta object literal for the '<em><b>Update Condition Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__UPDATE_CONDITION_NOTES = eINSTANCE.getAttribute_UpdateConditionNotes();

		/**
		 * The meta object literal for the '<em><b>Update Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__UPDATE_TYPE = eINSTANCE.getAttribute_UpdateType();

		/**
		 * The meta object literal for the '<em><b>Update Type Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__UPDATE_TYPE_NOTES = eINSTANCE.getAttribute_UpdateTypeNotes();

		/**
		 * The meta object literal for the '<em><b>Subscribing Federates</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATTRIBUTE__SUBSCRIBING_FEDERATES = eINSTANCE.getAttribute_SubscribingFederates();

		/**
		 * The meta object literal for the '<em><b>Publishing Federates</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATTRIBUTE__PUBLISHING_FEDERATES = eINSTANCE.getAttribute_PublishingFederates();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.BasicDataImpl <em>Basic Data</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.BasicDataImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getBasicData()
		 * @generated
		 */
		EClass BASIC_DATA = eINSTANCE.getBasicData();

		/**
		 * The meta object literal for the '<em><b>Encoding</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BASIC_DATA__ENCODING = eINSTANCE.getBasicData_Encoding();

		/**
		 * The meta object literal for the '<em><b>Encoding Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BASIC_DATA__ENCODING_NOTES = eINSTANCE.getBasicData_EncodingNotes();

		/**
		 * The meta object literal for the '<em><b>Endian</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BASIC_DATA__ENDIAN = eINSTANCE.getBasicData_Endian();

		/**
		 * The meta object literal for the '<em><b>Endian Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BASIC_DATA__ENDIAN_NOTES = eINSTANCE.getBasicData_EndianNotes();

		/**
		 * The meta object literal for the '<em><b>Interpretation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BASIC_DATA__INTERPRETATION = eINSTANCE.getBasicData_Interpretation();

		/**
		 * The meta object literal for the '<em><b>Interpretation Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BASIC_DATA__INTERPRETATION_NOTES = eINSTANCE.getBasicData_InterpretationNotes();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BASIC_DATA__NAME = eINSTANCE.getBasicData_Name();

		/**
		 * The meta object literal for the '<em><b>Name Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BASIC_DATA__NAME_NOTES = eINSTANCE.getBasicData_NameNotes();

		/**
		 * The meta object literal for the '<em><b>Size</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BASIC_DATA__SIZE = eINSTANCE.getBasicData_Size();

		/**
		 * The meta object literal for the '<em><b>Size Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BASIC_DATA__SIZE_NOTES = eINSTANCE.getBasicData_SizeNotes();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.BasicDataRepresentationsImpl <em>Basic Data Representations</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.BasicDataRepresentationsImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getBasicDataRepresentations()
		 * @generated
		 */
		EClass BASIC_DATA_REPRESENTATIONS = eINSTANCE.getBasicDataRepresentations();

		/**
		 * The meta object literal for the '<em><b>Basic Data</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BASIC_DATA_REPRESENTATIONS__BASIC_DATA = eINSTANCE.getBasicDataRepresentations_BasicData();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.DataTypesImpl <em>Data Types</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.DataTypesImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getDataTypes()
		 * @generated
		 */
		EClass DATA_TYPES = eINSTANCE.getDataTypes();

		/**
		 * The meta object literal for the '<em><b>Basic Data Representations</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DATA_TYPES__BASIC_DATA_REPRESENTATIONS = eINSTANCE.getDataTypes_BasicDataRepresentations();

		/**
		 * The meta object literal for the '<em><b>Simple Data Types</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DATA_TYPES__SIMPLE_DATA_TYPES = eINSTANCE.getDataTypes_SimpleDataTypes();

		/**
		 * The meta object literal for the '<em><b>Enumerated Data Types</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DATA_TYPES__ENUMERATED_DATA_TYPES = eINSTANCE.getDataTypes_EnumeratedDataTypes();

		/**
		 * The meta object literal for the '<em><b>Array Data Types</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DATA_TYPES__ARRAY_DATA_TYPES = eINSTANCE.getDataTypes_ArrayDataTypes();

		/**
		 * The meta object literal for the '<em><b>Fixed Record Data Types</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DATA_TYPES__FIXED_RECORD_DATA_TYPES = eINSTANCE.getDataTypes_FixedRecordDataTypes();

		/**
		 * The meta object literal for the '<em><b>Variant Record Data Types</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DATA_TYPES__VARIANT_RECORD_DATA_TYPES = eINSTANCE.getDataTypes_VariantRecordDataTypes();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.DeleteRemoveTagImpl <em>Delete Remove Tag</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.DeleteRemoveTagImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getDeleteRemoveTag()
		 * @generated
		 */
		EClass DELETE_REMOVE_TAG = eINSTANCE.getDeleteRemoveTag();

		/**
		 * The meta object literal for the '<em><b>Data Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DELETE_REMOVE_TAG__DATA_TYPE = eINSTANCE.getDeleteRemoveTag_DataType();

		/**
		 * The meta object literal for the '<em><b>Data Type Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DELETE_REMOVE_TAG__DATA_TYPE_NOTES = eINSTANCE.getDeleteRemoveTag_DataTypeNotes();

		/**
		 * The meta object literal for the '<em><b>Semantics</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DELETE_REMOVE_TAG__SEMANTICS = eINSTANCE.getDeleteRemoveTag_Semantics();

		/**
		 * The meta object literal for the '<em><b>Semantics Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DELETE_REMOVE_TAG__SEMANTICS_NOTES = eINSTANCE.getDeleteRemoveTag_SemanticsNotes();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.DimensionImpl <em>Dimension</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.DimensionImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getDimension()
		 * @generated
		 */
		EClass DIMENSION = eINSTANCE.getDimension();

		/**
		 * The meta object literal for the '<em><b>Data Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DIMENSION__DATA_TYPE = eINSTANCE.getDimension_DataType();

		/**
		 * The meta object literal for the '<em><b>Data Type Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DIMENSION__DATA_TYPE_NOTES = eINSTANCE.getDimension_DataTypeNotes();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DIMENSION__NAME = eINSTANCE.getDimension_Name();

		/**
		 * The meta object literal for the '<em><b>Name Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DIMENSION__NAME_NOTES = eINSTANCE.getDimension_NameNotes();

		/**
		 * The meta object literal for the '<em><b>Normalization</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DIMENSION__NORMALIZATION = eINSTANCE.getDimension_Normalization();

		/**
		 * The meta object literal for the '<em><b>Normalization Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DIMENSION__NORMALIZATION_NOTES = eINSTANCE.getDimension_NormalizationNotes();

		/**
		 * The meta object literal for the '<em><b>Upper Bound</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DIMENSION__UPPER_BOUND = eINSTANCE.getDimension_UpperBound();

		/**
		 * The meta object literal for the '<em><b>Upper Bound Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DIMENSION__UPPER_BOUND_NOTES = eINSTANCE.getDimension_UpperBoundNotes();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DIMENSION__VALUE = eINSTANCE.getDimension_Value();

		/**
		 * The meta object literal for the '<em><b>Value Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DIMENSION__VALUE_NOTES = eINSTANCE.getDimension_ValueNotes();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.DimensionsImpl <em>Dimensions</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.DimensionsImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getDimensions()
		 * @generated
		 */
		EClass DIMENSIONS = eINSTANCE.getDimensions();

		/**
		 * The meta object literal for the '<em><b>Dimension</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIMENSIONS__DIMENSION = eINSTANCE.getDimensions_Dimension();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.DivestitureCompletionTagImpl <em>Divestiture Completion Tag</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.DivestitureCompletionTagImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getDivestitureCompletionTag()
		 * @generated
		 */
		EClass DIVESTITURE_COMPLETION_TAG = eINSTANCE.getDivestitureCompletionTag();

		/**
		 * The meta object literal for the '<em><b>Data Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DIVESTITURE_COMPLETION_TAG__DATA_TYPE = eINSTANCE.getDivestitureCompletionTag_DataType();

		/**
		 * The meta object literal for the '<em><b>Data Type Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DIVESTITURE_COMPLETION_TAG__DATA_TYPE_NOTES = eINSTANCE.getDivestitureCompletionTag_DataTypeNotes();

		/**
		 * The meta object literal for the '<em><b>Semantics</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DIVESTITURE_COMPLETION_TAG__SEMANTICS = eINSTANCE.getDivestitureCompletionTag_Semantics();

		/**
		 * The meta object literal for the '<em><b>Semantics Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DIVESTITURE_COMPLETION_TAG__SEMANTICS_NOTES = eINSTANCE.getDivestitureCompletionTag_SemanticsNotes();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.DivestitureRequestTagImpl <em>Divestiture Request Tag</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.DivestitureRequestTagImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getDivestitureRequestTag()
		 * @generated
		 */
		EClass DIVESTITURE_REQUEST_TAG = eINSTANCE.getDivestitureRequestTag();

		/**
		 * The meta object literal for the '<em><b>Data Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DIVESTITURE_REQUEST_TAG__DATA_TYPE = eINSTANCE.getDivestitureRequestTag_DataType();

		/**
		 * The meta object literal for the '<em><b>Data Type Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DIVESTITURE_REQUEST_TAG__DATA_TYPE_NOTES = eINSTANCE.getDivestitureRequestTag_DataTypeNotes();

		/**
		 * The meta object literal for the '<em><b>Semantics</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DIVESTITURE_REQUEST_TAG__SEMANTICS = eINSTANCE.getDivestitureRequestTag_Semantics();

		/**
		 * The meta object literal for the '<em><b>Semantics Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DIVESTITURE_REQUEST_TAG__SEMANTICS_NOTES = eINSTANCE.getDivestitureRequestTag_SemanticsNotes();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.DocumentRootImpl <em>Document Root</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.DocumentRootImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getDocumentRoot()
		 * @generated
		 */
		EClass DOCUMENT_ROOT = eINSTANCE.getDocumentRoot();

		/**
		 * The meta object literal for the '<em><b>Mixed</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCUMENT_ROOT__MIXED = eINSTANCE.getDocumentRoot_Mixed();

		/**
		 * The meta object literal for the '<em><b>XMLNS Prefix Map</b></em>' map feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__XMLNS_PREFIX_MAP = eINSTANCE.getDocumentRoot_XMLNSPrefixMap();

		/**
		 * The meta object literal for the '<em><b>XSI Schema Location</b></em>' map feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__XSI_SCHEMA_LOCATION = eINSTANCE.getDocumentRoot_XSISchemaLocation();

		/**
		 * The meta object literal for the '<em><b>Object Model</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__OBJECT_MODEL = eINSTANCE.getDocumentRoot_ObjectModel();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.EnumeratedDataImpl <em>Enumerated Data</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.EnumeratedDataImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getEnumeratedData()
		 * @generated
		 */
		EClass ENUMERATED_DATA = eINSTANCE.getEnumeratedData();

		/**
		 * The meta object literal for the '<em><b>Enumerator</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENUMERATED_DATA__ENUMERATOR = eINSTANCE.getEnumeratedData_Enumerator();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENUMERATED_DATA__NAME = eINSTANCE.getEnumeratedData_Name();

		/**
		 * The meta object literal for the '<em><b>Name Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENUMERATED_DATA__NAME_NOTES = eINSTANCE.getEnumeratedData_NameNotes();

		/**
		 * The meta object literal for the '<em><b>Representation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENUMERATED_DATA__REPRESENTATION = eINSTANCE.getEnumeratedData_Representation();

		/**
		 * The meta object literal for the '<em><b>Representation Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENUMERATED_DATA__REPRESENTATION_NOTES = eINSTANCE.getEnumeratedData_RepresentationNotes();

		/**
		 * The meta object literal for the '<em><b>Semantics</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENUMERATED_DATA__SEMANTICS = eINSTANCE.getEnumeratedData_Semantics();

		/**
		 * The meta object literal for the '<em><b>Semantics Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENUMERATED_DATA__SEMANTICS_NOTES = eINSTANCE.getEnumeratedData_SemanticsNotes();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.EnumeratedDataTypesImpl <em>Enumerated Data Types</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.EnumeratedDataTypesImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getEnumeratedDataTypes()
		 * @generated
		 */
		EClass ENUMERATED_DATA_TYPES = eINSTANCE.getEnumeratedDataTypes();

		/**
		 * The meta object literal for the '<em><b>Enumerated Data</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENUMERATED_DATA_TYPES__ENUMERATED_DATA = eINSTANCE.getEnumeratedDataTypes_EnumeratedData();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.EnumeratorImpl <em>Enumerator</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.EnumeratorImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getEnumerator()
		 * @generated
		 */
		EClass ENUMERATOR = eINSTANCE.getEnumerator();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENUMERATOR__NAME = eINSTANCE.getEnumerator_Name();

		/**
		 * The meta object literal for the '<em><b>Name Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENUMERATOR__NAME_NOTES = eINSTANCE.getEnumerator_NameNotes();

		/**
		 * The meta object literal for the '<em><b>Values</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENUMERATOR__VALUES = eINSTANCE.getEnumerator_Values();

		/**
		 * The meta object literal for the '<em><b>Values Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENUMERATOR__VALUES_NOTES = eINSTANCE.getEnumerator_ValuesNotes();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.FieldImpl <em>Field</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.FieldImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getField()
		 * @generated
		 */
		EClass FIELD = eINSTANCE.getField();

		/**
		 * The meta object literal for the '<em><b>Data Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FIELD__DATA_TYPE = eINSTANCE.getField_DataType();

		/**
		 * The meta object literal for the '<em><b>Data Type Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FIELD__DATA_TYPE_NOTES = eINSTANCE.getField_DataTypeNotes();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FIELD__NAME = eINSTANCE.getField_Name();

		/**
		 * The meta object literal for the '<em><b>Name Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FIELD__NAME_NOTES = eINSTANCE.getField_NameNotes();

		/**
		 * The meta object literal for the '<em><b>Semantics</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FIELD__SEMANTICS = eINSTANCE.getField_Semantics();

		/**
		 * The meta object literal for the '<em><b>Semantics Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FIELD__SEMANTICS_NOTES = eINSTANCE.getField_SemanticsNotes();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.FixedRecordDataImpl <em>Fixed Record Data</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.FixedRecordDataImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getFixedRecordData()
		 * @generated
		 */
		EClass FIXED_RECORD_DATA = eINSTANCE.getFixedRecordData();

		/**
		 * The meta object literal for the '<em><b>Field</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FIXED_RECORD_DATA__FIELD = eINSTANCE.getFixedRecordData_Field();

		/**
		 * The meta object literal for the '<em><b>Encoding</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FIXED_RECORD_DATA__ENCODING = eINSTANCE.getFixedRecordData_Encoding();

		/**
		 * The meta object literal for the '<em><b>Encoding Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FIXED_RECORD_DATA__ENCODING_NOTES = eINSTANCE.getFixedRecordData_EncodingNotes();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FIXED_RECORD_DATA__NAME = eINSTANCE.getFixedRecordData_Name();

		/**
		 * The meta object literal for the '<em><b>Name Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FIXED_RECORD_DATA__NAME_NOTES = eINSTANCE.getFixedRecordData_NameNotes();

		/**
		 * The meta object literal for the '<em><b>Semantics</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FIXED_RECORD_DATA__SEMANTICS = eINSTANCE.getFixedRecordData_Semantics();

		/**
		 * The meta object literal for the '<em><b>Semantics Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FIXED_RECORD_DATA__SEMANTICS_NOTES = eINSTANCE.getFixedRecordData_SemanticsNotes();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.FixedRecordDataTypesImpl <em>Fixed Record Data Types</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.FixedRecordDataTypesImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getFixedRecordDataTypes()
		 * @generated
		 */
		EClass FIXED_RECORD_DATA_TYPES = eINSTANCE.getFixedRecordDataTypes();

		/**
		 * The meta object literal for the '<em><b>Fixed Record Data</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FIXED_RECORD_DATA_TYPES__FIXED_RECORD_DATA = eINSTANCE.getFixedRecordDataTypes_FixedRecordData();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.InteractionClassImpl <em>Interaction Class</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.InteractionClassImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getInteractionClass()
		 * @generated
		 */
		EClass INTERACTION_CLASS = eINSTANCE.getInteractionClass();

		/**
		 * The meta object literal for the '<em><b>Parameters</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERACTION_CLASS__PARAMETERS = eINSTANCE.getInteractionClass_Parameters();

		/**
		 * The meta object literal for the '<em><b>Sub Classes</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERACTION_CLASS__SUB_CLASSES = eINSTANCE.getInteractionClass_SubClasses();

		/**
		 * The meta object literal for the '<em><b>Dimensions</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INTERACTION_CLASS__DIMENSIONS = eINSTANCE.getInteractionClass_Dimensions();

		/**
		 * The meta object literal for the '<em><b>Dimensions Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INTERACTION_CLASS__DIMENSIONS_NOTES = eINSTANCE.getInteractionClass_DimensionsNotes();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INTERACTION_CLASS__NAME = eINSTANCE.getInteractionClass_Name();

		/**
		 * The meta object literal for the '<em><b>Name Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INTERACTION_CLASS__NAME_NOTES = eINSTANCE.getInteractionClass_NameNotes();

		/**
		 * The meta object literal for the '<em><b>Order</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INTERACTION_CLASS__ORDER = eINSTANCE.getInteractionClass_Order();

		/**
		 * The meta object literal for the '<em><b>Order Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INTERACTION_CLASS__ORDER_NOTES = eINSTANCE.getInteractionClass_OrderNotes();

		/**
		 * The meta object literal for the '<em><b>Semantics</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INTERACTION_CLASS__SEMANTICS = eINSTANCE.getInteractionClass_Semantics();

		/**
		 * The meta object literal for the '<em><b>Semantics Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INTERACTION_CLASS__SEMANTICS_NOTES = eINSTANCE.getInteractionClass_SemanticsNotes();

		/**
		 * The meta object literal for the '<em><b>Sharing</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INTERACTION_CLASS__SHARING = eINSTANCE.getInteractionClass_Sharing();

		/**
		 * The meta object literal for the '<em><b>Sharing Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INTERACTION_CLASS__SHARING_NOTES = eINSTANCE.getInteractionClass_SharingNotes();

		/**
		 * The meta object literal for the '<em><b>Transportation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INTERACTION_CLASS__TRANSPORTATION = eINSTANCE.getInteractionClass_Transportation();

		/**
		 * The meta object literal for the '<em><b>Transportation Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INTERACTION_CLASS__TRANSPORTATION_NOTES = eINSTANCE.getInteractionClass_TransportationNotes();

		/**
		 * The meta object literal for the '<em><b>Subscribing Federates</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERACTION_CLASS__SUBSCRIBING_FEDERATES = eINSTANCE.getInteractionClass_SubscribingFederates();

		/**
		 * The meta object literal for the '<em><b>Publishing Federates</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERACTION_CLASS__PUBLISHING_FEDERATES = eINSTANCE.getInteractionClass_PublishingFederates();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.InteractionsImpl <em>Interactions</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.InteractionsImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getInteractions()
		 * @generated
		 */
		EClass INTERACTIONS = eINSTANCE.getInteractions();

		/**
		 * The meta object literal for the '<em><b>Interaction Class</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERACTIONS__INTERACTION_CLASS = eINSTANCE.getInteractions_InteractionClass();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.LookaheadImpl <em>Lookahead</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.LookaheadImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getLookahead()
		 * @generated
		 */
		EClass LOOKAHEAD = eINSTANCE.getLookahead();

		/**
		 * The meta object literal for the '<em><b>Data Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LOOKAHEAD__DATA_TYPE = eINSTANCE.getLookahead_DataType();

		/**
		 * The meta object literal for the '<em><b>Data Type Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LOOKAHEAD__DATA_TYPE_NOTES = eINSTANCE.getLookahead_DataTypeNotes();

		/**
		 * The meta object literal for the '<em><b>Semantics</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LOOKAHEAD__SEMANTICS = eINSTANCE.getLookahead_Semantics();

		/**
		 * The meta object literal for the '<em><b>Semantics Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LOOKAHEAD__SEMANTICS_NOTES = eINSTANCE.getLookahead_SemanticsNotes();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.NoteImpl <em>Note</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.NoteImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getNote()
		 * @generated
		 */
		EClass NOTE = eINSTANCE.getNote();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NOTE__NAME = eINSTANCE.getNote_Name();

		/**
		 * The meta object literal for the '<em><b>Semantics</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NOTE__SEMANTICS = eINSTANCE.getNote_Semantics();

		/**
		 * The meta object literal for the '<em><b>Semantics Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NOTE__SEMANTICS_NOTES = eINSTANCE.getNote_SemanticsNotes();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.NotesImpl <em>Notes</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.NotesImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getNotes()
		 * @generated
		 */
		EClass NOTES = eINSTANCE.getNotes();

		/**
		 * The meta object literal for the '<em><b>Note</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference NOTES__NOTE = eINSTANCE.getNotes_Note();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.ObjectClassImpl <em>Object Class</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.ObjectClassImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getObjectClass()
		 * @generated
		 */
		EClass OBJECT_CLASS = eINSTANCE.getObjectClass();

		/**
		 * The meta object literal for the '<em><b>Attributes</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OBJECT_CLASS__ATTRIBUTES = eINSTANCE.getObjectClass_Attributes();

		/**
		 * The meta object literal for the '<em><b>Sub Classes</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OBJECT_CLASS__SUB_CLASSES = eINSTANCE.getObjectClass_SubClasses();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_CLASS__NAME = eINSTANCE.getObjectClass_Name();

		/**
		 * The meta object literal for the '<em><b>Name Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_CLASS__NAME_NOTES = eINSTANCE.getObjectClass_NameNotes();

		/**
		 * The meta object literal for the '<em><b>Semantics</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_CLASS__SEMANTICS = eINSTANCE.getObjectClass_Semantics();

		/**
		 * The meta object literal for the '<em><b>Semantics Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_CLASS__SEMANTICS_NOTES = eINSTANCE.getObjectClass_SemanticsNotes();

		/**
		 * The meta object literal for the '<em><b>Sharing</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_CLASS__SHARING = eINSTANCE.getObjectClass_Sharing();

		/**
		 * The meta object literal for the '<em><b>Sharing Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_CLASS__SHARING_NOTES = eINSTANCE.getObjectClass_SharingNotes();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl <em>Object Model</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.ObjectModelImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getObjectModel()
		 * @generated
		 */
		EClass OBJECT_MODEL = eINSTANCE.getObjectModel();

		/**
		 * The meta object literal for the '<em><b>Objects</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OBJECT_MODEL__OBJECTS = eINSTANCE.getObjectModel_Objects();

		/**
		 * The meta object literal for the '<em><b>Interactions</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OBJECT_MODEL__INTERACTIONS = eINSTANCE.getObjectModel_Interactions();

		/**
		 * The meta object literal for the '<em><b>Dimensions</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OBJECT_MODEL__DIMENSIONS = eINSTANCE.getObjectModel_Dimensions();

		/**
		 * The meta object literal for the '<em><b>Time</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OBJECT_MODEL__TIME = eINSTANCE.getObjectModel_Time();

		/**
		 * The meta object literal for the '<em><b>Tags</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OBJECT_MODEL__TAGS = eINSTANCE.getObjectModel_Tags();

		/**
		 * The meta object literal for the '<em><b>Synchronizations</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OBJECT_MODEL__SYNCHRONIZATIONS = eINSTANCE.getObjectModel_Synchronizations();

		/**
		 * The meta object literal for the '<em><b>Transportations</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OBJECT_MODEL__TRANSPORTATIONS = eINSTANCE.getObjectModel_Transportations();

		/**
		 * The meta object literal for the '<em><b>Switches</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OBJECT_MODEL__SWITCHES = eINSTANCE.getObjectModel_Switches();

		/**
		 * The meta object literal for the '<em><b>Data Types</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OBJECT_MODEL__DATA_TYPES = eINSTANCE.getObjectModel_DataTypes();

		/**
		 * The meta object literal for the '<em><b>Notes</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OBJECT_MODEL__NOTES = eINSTANCE.getObjectModel_Notes();

		/**
		 * The meta object literal for the '<em><b>App Domain</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_MODEL__APP_DOMAIN = eINSTANCE.getObjectModel_AppDomain();

		/**
		 * The meta object literal for the '<em><b>App Domain Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_MODEL__APP_DOMAIN_NOTES = eINSTANCE.getObjectModel_AppDomainNotes();

		/**
		 * The meta object literal for the '<em><b>Date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_MODEL__DATE = eINSTANCE.getObjectModel_Date();

		/**
		 * The meta object literal for the '<em><b>Date Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_MODEL__DATE_NOTES = eINSTANCE.getObjectModel_DateNotes();

		/**
		 * The meta object literal for the '<em><b>DT Dversion</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_MODEL__DT_DVERSION = eINSTANCE.getObjectModel_DTDversion();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_MODEL__NAME = eINSTANCE.getObjectModel_Name();

		/**
		 * The meta object literal for the '<em><b>Name Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_MODEL__NAME_NOTES = eINSTANCE.getObjectModel_NameNotes();

		/**
		 * The meta object literal for the '<em><b>Other</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_MODEL__OTHER = eINSTANCE.getObjectModel_Other();

		/**
		 * The meta object literal for the '<em><b>Other Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_MODEL__OTHER_NOTES = eINSTANCE.getObjectModel_OtherNotes();

		/**
		 * The meta object literal for the '<em><b>Poc Email</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_MODEL__POC_EMAIL = eINSTANCE.getObjectModel_PocEmail();

		/**
		 * The meta object literal for the '<em><b>Poc Email Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_MODEL__POC_EMAIL_NOTES = eINSTANCE.getObjectModel_PocEmailNotes();

		/**
		 * The meta object literal for the '<em><b>Poc Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_MODEL__POC_NAME = eINSTANCE.getObjectModel_PocName();

		/**
		 * The meta object literal for the '<em><b>Poc Name Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_MODEL__POC_NAME_NOTES = eINSTANCE.getObjectModel_PocNameNotes();

		/**
		 * The meta object literal for the '<em><b>Poc Org</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_MODEL__POC_ORG = eINSTANCE.getObjectModel_PocOrg();

		/**
		 * The meta object literal for the '<em><b>Poc Org Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_MODEL__POC_ORG_NOTES = eINSTANCE.getObjectModel_PocOrgNotes();

		/**
		 * The meta object literal for the '<em><b>Poc Phone</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_MODEL__POC_PHONE = eINSTANCE.getObjectModel_PocPhone();

		/**
		 * The meta object literal for the '<em><b>Poc Phone Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_MODEL__POC_PHONE_NOTES = eINSTANCE.getObjectModel_PocPhoneNotes();

		/**
		 * The meta object literal for the '<em><b>Purpose</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_MODEL__PURPOSE = eINSTANCE.getObjectModel_Purpose();

		/**
		 * The meta object literal for the '<em><b>Purpose Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_MODEL__PURPOSE_NOTES = eINSTANCE.getObjectModel_PurposeNotes();

		/**
		 * The meta object literal for the '<em><b>References</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_MODEL__REFERENCES = eINSTANCE.getObjectModel_References();

		/**
		 * The meta object literal for the '<em><b>References Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_MODEL__REFERENCES_NOTES = eINSTANCE.getObjectModel_ReferencesNotes();

		/**
		 * The meta object literal for the '<em><b>Sponsor</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_MODEL__SPONSOR = eINSTANCE.getObjectModel_Sponsor();

		/**
		 * The meta object literal for the '<em><b>Sponsor Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_MODEL__SPONSOR_NOTES = eINSTANCE.getObjectModel_SponsorNotes();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_MODEL__TYPE = eINSTANCE.getObjectModel_Type();

		/**
		 * The meta object literal for the '<em><b>Type Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_MODEL__TYPE_NOTES = eINSTANCE.getObjectModel_TypeNotes();

		/**
		 * The meta object literal for the '<em><b>Version</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_MODEL__VERSION = eINSTANCE.getObjectModel_Version();

		/**
		 * The meta object literal for the '<em><b>Version Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_MODEL__VERSION_NOTES = eINSTANCE.getObjectModel_VersionNotes();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.ObjectsImpl <em>Objects</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.ObjectsImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getObjects()
		 * @generated
		 */
		EClass OBJECTS = eINSTANCE.getObjects();

		/**
		 * The meta object literal for the '<em><b>Object Class</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OBJECTS__OBJECT_CLASS = eINSTANCE.getObjects_ObjectClass();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.ParameterImpl <em>Parameter</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.ParameterImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getParameter()
		 * @generated
		 */
		EClass PARAMETER = eINSTANCE.getParameter();

		/**
		 * The meta object literal for the '<em><b>Data Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PARAMETER__DATA_TYPE = eINSTANCE.getParameter_DataType();

		/**
		 * The meta object literal for the '<em><b>Data Type Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PARAMETER__DATA_TYPE_NOTES = eINSTANCE.getParameter_DataTypeNotes();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PARAMETER__NAME = eINSTANCE.getParameter_Name();

		/**
		 * The meta object literal for the '<em><b>Name Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PARAMETER__NAME_NOTES = eINSTANCE.getParameter_NameNotes();

		/**
		 * The meta object literal for the '<em><b>Semantics</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PARAMETER__SEMANTICS = eINSTANCE.getParameter_Semantics();

		/**
		 * The meta object literal for the '<em><b>Semantics Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PARAMETER__SEMANTICS_NOTES = eINSTANCE.getParameter_SemanticsNotes();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.RequestUpdateTagImpl <em>Request Update Tag</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.RequestUpdateTagImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getRequestUpdateTag()
		 * @generated
		 */
		EClass REQUEST_UPDATE_TAG = eINSTANCE.getRequestUpdateTag();

		/**
		 * The meta object literal for the '<em><b>Data Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REQUEST_UPDATE_TAG__DATA_TYPE = eINSTANCE.getRequestUpdateTag_DataType();

		/**
		 * The meta object literal for the '<em><b>Data Type Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REQUEST_UPDATE_TAG__DATA_TYPE_NOTES = eINSTANCE.getRequestUpdateTag_DataTypeNotes();

		/**
		 * The meta object literal for the '<em><b>Semantics</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REQUEST_UPDATE_TAG__SEMANTICS = eINSTANCE.getRequestUpdateTag_Semantics();

		/**
		 * The meta object literal for the '<em><b>Semantics Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REQUEST_UPDATE_TAG__SEMANTICS_NOTES = eINSTANCE.getRequestUpdateTag_SemanticsNotes();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.SendReceiveTagImpl <em>Send Receive Tag</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.SendReceiveTagImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getSendReceiveTag()
		 * @generated
		 */
		EClass SEND_RECEIVE_TAG = eINSTANCE.getSendReceiveTag();

		/**
		 * The meta object literal for the '<em><b>Data Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEND_RECEIVE_TAG__DATA_TYPE = eINSTANCE.getSendReceiveTag_DataType();

		/**
		 * The meta object literal for the '<em><b>Data Type Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEND_RECEIVE_TAG__DATA_TYPE_NOTES = eINSTANCE.getSendReceiveTag_DataTypeNotes();

		/**
		 * The meta object literal for the '<em><b>Semantics</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEND_RECEIVE_TAG__SEMANTICS = eINSTANCE.getSendReceiveTag_Semantics();

		/**
		 * The meta object literal for the '<em><b>Semantics Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEND_RECEIVE_TAG__SEMANTICS_NOTES = eINSTANCE.getSendReceiveTag_SemanticsNotes();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.SimpleDataImpl <em>Simple Data</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.SimpleDataImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getSimpleData()
		 * @generated
		 */
		EClass SIMPLE_DATA = eINSTANCE.getSimpleData();

		/**
		 * The meta object literal for the '<em><b>Accuracy</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SIMPLE_DATA__ACCURACY = eINSTANCE.getSimpleData_Accuracy();

		/**
		 * The meta object literal for the '<em><b>Accuracy Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SIMPLE_DATA__ACCURACY_NOTES = eINSTANCE.getSimpleData_AccuracyNotes();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SIMPLE_DATA__NAME = eINSTANCE.getSimpleData_Name();

		/**
		 * The meta object literal for the '<em><b>Name Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SIMPLE_DATA__NAME_NOTES = eINSTANCE.getSimpleData_NameNotes();

		/**
		 * The meta object literal for the '<em><b>Representation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SIMPLE_DATA__REPRESENTATION = eINSTANCE.getSimpleData_Representation();

		/**
		 * The meta object literal for the '<em><b>Representation Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SIMPLE_DATA__REPRESENTATION_NOTES = eINSTANCE.getSimpleData_RepresentationNotes();

		/**
		 * The meta object literal for the '<em><b>Resolution</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SIMPLE_DATA__RESOLUTION = eINSTANCE.getSimpleData_Resolution();

		/**
		 * The meta object literal for the '<em><b>Resolution Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SIMPLE_DATA__RESOLUTION_NOTES = eINSTANCE.getSimpleData_ResolutionNotes();

		/**
		 * The meta object literal for the '<em><b>Semantics</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SIMPLE_DATA__SEMANTICS = eINSTANCE.getSimpleData_Semantics();

		/**
		 * The meta object literal for the '<em><b>Semantics Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SIMPLE_DATA__SEMANTICS_NOTES = eINSTANCE.getSimpleData_SemanticsNotes();

		/**
		 * The meta object literal for the '<em><b>Units</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SIMPLE_DATA__UNITS = eINSTANCE.getSimpleData_Units();

		/**
		 * The meta object literal for the '<em><b>Units Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SIMPLE_DATA__UNITS_NOTES = eINSTANCE.getSimpleData_UnitsNotes();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.SimpleDataTypesImpl <em>Simple Data Types</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.SimpleDataTypesImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getSimpleDataTypes()
		 * @generated
		 */
		EClass SIMPLE_DATA_TYPES = eINSTANCE.getSimpleDataTypes();

		/**
		 * The meta object literal for the '<em><b>Simple Data</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SIMPLE_DATA_TYPES__SIMPLE_DATA = eINSTANCE.getSimpleDataTypes_SimpleData();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.SwitchesImpl <em>Switches</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.SwitchesImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getSwitches()
		 * @generated
		 */
		EClass SWITCHES = eINSTANCE.getSwitches();

		/**
		 * The meta object literal for the '<em><b>Attribute Relevance Advisory</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SWITCHES__ATTRIBUTE_RELEVANCE_ADVISORY = eINSTANCE.getSwitches_AttributeRelevanceAdvisory();

		/**
		 * The meta object literal for the '<em><b>Attribute Relevance Advisory Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SWITCHES__ATTRIBUTE_RELEVANCE_ADVISORY_NOTES = eINSTANCE
				.getSwitches_AttributeRelevanceAdvisoryNotes();

		/**
		 * The meta object literal for the '<em><b>Attribute Scope Advisory</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SWITCHES__ATTRIBUTE_SCOPE_ADVISORY = eINSTANCE.getSwitches_AttributeScopeAdvisory();

		/**
		 * The meta object literal for the '<em><b>Attribute Scope Advisory Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SWITCHES__ATTRIBUTE_SCOPE_ADVISORY_NOTES = eINSTANCE.getSwitches_AttributeScopeAdvisoryNotes();

		/**
		 * The meta object literal for the '<em><b>Auto Provide</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SWITCHES__AUTO_PROVIDE = eINSTANCE.getSwitches_AutoProvide();

		/**
		 * The meta object literal for the '<em><b>Auto Provide Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SWITCHES__AUTO_PROVIDE_NOTES = eINSTANCE.getSwitches_AutoProvideNotes();

		/**
		 * The meta object literal for the '<em><b>Convey Region Designator Sets</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SWITCHES__CONVEY_REGION_DESIGNATOR_SETS = eINSTANCE.getSwitches_ConveyRegionDesignatorSets();

		/**
		 * The meta object literal for the '<em><b>Convey Region Designator Sets Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SWITCHES__CONVEY_REGION_DESIGNATOR_SETS_NOTES = eINSTANCE
				.getSwitches_ConveyRegionDesignatorSetsNotes();

		/**
		 * The meta object literal for the '<em><b>Interaction Relevance Advisory</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SWITCHES__INTERACTION_RELEVANCE_ADVISORY = eINSTANCE.getSwitches_InteractionRelevanceAdvisory();

		/**
		 * The meta object literal for the '<em><b>Interaction Relevance Advisory Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SWITCHES__INTERACTION_RELEVANCE_ADVISORY_NOTES = eINSTANCE
				.getSwitches_InteractionRelevanceAdvisoryNotes();

		/**
		 * The meta object literal for the '<em><b>Object Class Relevance Advisory</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SWITCHES__OBJECT_CLASS_RELEVANCE_ADVISORY = eINSTANCE.getSwitches_ObjectClassRelevanceAdvisory();

		/**
		 * The meta object literal for the '<em><b>Object Class Relevance Advisory Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SWITCHES__OBJECT_CLASS_RELEVANCE_ADVISORY_NOTES = eINSTANCE
				.getSwitches_ObjectClassRelevanceAdvisoryNotes();

		/**
		 * The meta object literal for the '<em><b>Service Reporting</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SWITCHES__SERVICE_REPORTING = eINSTANCE.getSwitches_ServiceReporting();

		/**
		 * The meta object literal for the '<em><b>Service Reporting Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SWITCHES__SERVICE_REPORTING_NOTES = eINSTANCE.getSwitches_ServiceReportingNotes();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.SynchronizationImpl <em>Synchronization</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.SynchronizationImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getSynchronization()
		 * @generated
		 */
		EClass SYNCHRONIZATION = eINSTANCE.getSynchronization();

		/**
		 * The meta object literal for the '<em><b>Capability</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SYNCHRONIZATION__CAPABILITY = eINSTANCE.getSynchronization_Capability();

		/**
		 * The meta object literal for the '<em><b>Capability Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SYNCHRONIZATION__CAPABILITY_NOTES = eINSTANCE.getSynchronization_CapabilityNotes();

		/**
		 * The meta object literal for the '<em><b>Data Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SYNCHRONIZATION__DATA_TYPE = eINSTANCE.getSynchronization_DataType();

		/**
		 * The meta object literal for the '<em><b>Data Type Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SYNCHRONIZATION__DATA_TYPE_NOTES = eINSTANCE.getSynchronization_DataTypeNotes();

		/**
		 * The meta object literal for the '<em><b>Label</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SYNCHRONIZATION__LABEL = eINSTANCE.getSynchronization_Label();

		/**
		 * The meta object literal for the '<em><b>Label Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SYNCHRONIZATION__LABEL_NOTES = eINSTANCE.getSynchronization_LabelNotes();

		/**
		 * The meta object literal for the '<em><b>Semantics</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SYNCHRONIZATION__SEMANTICS = eINSTANCE.getSynchronization_Semantics();

		/**
		 * The meta object literal for the '<em><b>Semantics Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SYNCHRONIZATION__SEMANTICS_NOTES = eINSTANCE.getSynchronization_SemanticsNotes();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.SynchronizationsImpl <em>Synchronizations</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.SynchronizationsImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getSynchronizations()
		 * @generated
		 */
		EClass SYNCHRONIZATIONS = eINSTANCE.getSynchronizations();

		/**
		 * The meta object literal for the '<em><b>Synchronization</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SYNCHRONIZATIONS__SYNCHRONIZATION = eINSTANCE.getSynchronizations_Synchronization();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.TagsImpl <em>Tags</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.TagsImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getTags()
		 * @generated
		 */
		EClass TAGS = eINSTANCE.getTags();

		/**
		 * The meta object literal for the '<em><b>Update Reflect Tag</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TAGS__UPDATE_REFLECT_TAG = eINSTANCE.getTags_UpdateReflectTag();

		/**
		 * The meta object literal for the '<em><b>Send Receive Tag</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TAGS__SEND_RECEIVE_TAG = eINSTANCE.getTags_SendReceiveTag();

		/**
		 * The meta object literal for the '<em><b>Delete Remove Tag</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TAGS__DELETE_REMOVE_TAG = eINSTANCE.getTags_DeleteRemoveTag();

		/**
		 * The meta object literal for the '<em><b>Divestiture Request Tag</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TAGS__DIVESTITURE_REQUEST_TAG = eINSTANCE.getTags_DivestitureRequestTag();

		/**
		 * The meta object literal for the '<em><b>Divestiture Completion Tag</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TAGS__DIVESTITURE_COMPLETION_TAG = eINSTANCE.getTags_DivestitureCompletionTag();

		/**
		 * The meta object literal for the '<em><b>Acquisition Request Tag</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TAGS__ACQUISITION_REQUEST_TAG = eINSTANCE.getTags_AcquisitionRequestTag();

		/**
		 * The meta object literal for the '<em><b>Request Update Tag</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TAGS__REQUEST_UPDATE_TAG = eINSTANCE.getTags_RequestUpdateTag();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.TimeImpl <em>Time</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.TimeImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getTime()
		 * @generated
		 */
		EClass TIME = eINSTANCE.getTime();

		/**
		 * The meta object literal for the '<em><b>Time Stamp</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TIME__TIME_STAMP = eINSTANCE.getTime_TimeStamp();

		/**
		 * The meta object literal for the '<em><b>Lookahead</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TIME__LOOKAHEAD = eINSTANCE.getTime_Lookahead();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.TimeStampImpl <em>Time Stamp</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.TimeStampImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getTimeStamp()
		 * @generated
		 */
		EClass TIME_STAMP = eINSTANCE.getTimeStamp();

		/**
		 * The meta object literal for the '<em><b>Data Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TIME_STAMP__DATA_TYPE = eINSTANCE.getTimeStamp_DataType();

		/**
		 * The meta object literal for the '<em><b>Data Type Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TIME_STAMP__DATA_TYPE_NOTES = eINSTANCE.getTimeStamp_DataTypeNotes();

		/**
		 * The meta object literal for the '<em><b>Semantics</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TIME_STAMP__SEMANTICS = eINSTANCE.getTimeStamp_Semantics();

		/**
		 * The meta object literal for the '<em><b>Semantics Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TIME_STAMP__SEMANTICS_NOTES = eINSTANCE.getTimeStamp_SemanticsNotes();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.TransportationImpl <em>Transportation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.TransportationImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getTransportation()
		 * @generated
		 */
		EClass TRANSPORTATION = eINSTANCE.getTransportation();

		/**
		 * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSPORTATION__DESCRIPTION = eINSTANCE.getTransportation_Description();

		/**
		 * The meta object literal for the '<em><b>Description Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSPORTATION__DESCRIPTION_NOTES = eINSTANCE.getTransportation_DescriptionNotes();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSPORTATION__NAME = eINSTANCE.getTransportation_Name();

		/**
		 * The meta object literal for the '<em><b>Name Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSPORTATION__NAME_NOTES = eINSTANCE.getTransportation_NameNotes();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.TransportationsImpl <em>Transportations</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.TransportationsImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getTransportations()
		 * @generated
		 */
		EClass TRANSPORTATIONS = eINSTANCE.getTransportations();

		/**
		 * The meta object literal for the '<em><b>Transportation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRANSPORTATIONS__TRANSPORTATION = eINSTANCE.getTransportations_Transportation();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.UpdateReflectTagImpl <em>Update Reflect Tag</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.UpdateReflectTagImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getUpdateReflectTag()
		 * @generated
		 */
		EClass UPDATE_REFLECT_TAG = eINSTANCE.getUpdateReflectTag();

		/**
		 * The meta object literal for the '<em><b>Data Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute UPDATE_REFLECT_TAG__DATA_TYPE = eINSTANCE.getUpdateReflectTag_DataType();

		/**
		 * The meta object literal for the '<em><b>Data Type Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute UPDATE_REFLECT_TAG__DATA_TYPE_NOTES = eINSTANCE.getUpdateReflectTag_DataTypeNotes();

		/**
		 * The meta object literal for the '<em><b>Semantics</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute UPDATE_REFLECT_TAG__SEMANTICS = eINSTANCE.getUpdateReflectTag_Semantics();

		/**
		 * The meta object literal for the '<em><b>Semantics Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute UPDATE_REFLECT_TAG__SEMANTICS_NOTES = eINSTANCE.getUpdateReflectTag_SemanticsNotes();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.VariantRecordDataImpl <em>Variant Record Data</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.VariantRecordDataImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getVariantRecordData()
		 * @generated
		 */
		EClass VARIANT_RECORD_DATA = eINSTANCE.getVariantRecordData();

		/**
		 * The meta object literal for the '<em><b>Alternative</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VARIANT_RECORD_DATA__ALTERNATIVE = eINSTANCE.getVariantRecordData_Alternative();

		/**
		 * The meta object literal for the '<em><b>Data Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VARIANT_RECORD_DATA__DATA_TYPE = eINSTANCE.getVariantRecordData_DataType();

		/**
		 * The meta object literal for the '<em><b>Data Type Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VARIANT_RECORD_DATA__DATA_TYPE_NOTES = eINSTANCE.getVariantRecordData_DataTypeNotes();

		/**
		 * The meta object literal for the '<em><b>Discriminant</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VARIANT_RECORD_DATA__DISCRIMINANT = eINSTANCE.getVariantRecordData_Discriminant();

		/**
		 * The meta object literal for the '<em><b>Discriminant Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VARIANT_RECORD_DATA__DISCRIMINANT_NOTES = eINSTANCE.getVariantRecordData_DiscriminantNotes();

		/**
		 * The meta object literal for the '<em><b>Encoding</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VARIANT_RECORD_DATA__ENCODING = eINSTANCE.getVariantRecordData_Encoding();

		/**
		 * The meta object literal for the '<em><b>Encoding Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VARIANT_RECORD_DATA__ENCODING_NOTES = eINSTANCE.getVariantRecordData_EncodingNotes();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VARIANT_RECORD_DATA__NAME = eINSTANCE.getVariantRecordData_Name();

		/**
		 * The meta object literal for the '<em><b>Name Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VARIANT_RECORD_DATA__NAME_NOTES = eINSTANCE.getVariantRecordData_NameNotes();

		/**
		 * The meta object literal for the '<em><b>Semantics</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VARIANT_RECORD_DATA__SEMANTICS = eINSTANCE.getVariantRecordData_Semantics();

		/**
		 * The meta object literal for the '<em><b>Semantics Notes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VARIANT_RECORD_DATA__SEMANTICS_NOTES = eINSTANCE.getVariantRecordData_SemanticsNotes();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.impl.VariantRecordDataTypesImpl <em>Variant Record Data Types</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.impl.VariantRecordDataTypesImpl
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getVariantRecordDataTypes()
		 * @generated
		 */
		EClass VARIANT_RECORD_DATA_TYPES = eINSTANCE.getVariantRecordDataTypes();

		/**
		 * The meta object literal for the '<em><b>Variant Record Data</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VARIANT_RECORD_DATA_TYPES__VARIANT_RECORD_DATA = eINSTANCE
				.getVariantRecordDataTypes_VariantRecordData();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.DTDVersionEnum <em>DTD Version Enum</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.DTDVersionEnum
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getDTDVersionEnum()
		 * @generated
		 */
		EEnum DTD_VERSION_ENUM = eINSTANCE.getDTDVersionEnum();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.EndianEnum <em>Endian Enum</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.EndianEnum
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getEndianEnum()
		 * @generated
		 */
		EEnum ENDIAN_ENUM = eINSTANCE.getEndianEnum();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.ObjectModelTypeEnum <em>Object Model Type Enum</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.ObjectModelTypeEnum
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getObjectModelTypeEnum()
		 * @generated
		 */
		EEnum OBJECT_MODEL_TYPE_ENUM = eINSTANCE.getObjectModelTypeEnum();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.OrderEnum <em>Order Enum</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.OrderEnum
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getOrderEnum()
		 * @generated
		 */
		EEnum ORDER_ENUM = eINSTANCE.getOrderEnum();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.OwnershipEnum <em>Ownership Enum</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.OwnershipEnum
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getOwnershipEnum()
		 * @generated
		 */
		EEnum OWNERSHIP_ENUM = eINSTANCE.getOwnershipEnum();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.SharingEnum <em>Sharing Enum</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.SharingEnum
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getSharingEnum()
		 * @generated
		 */
		EEnum SHARING_ENUM = eINSTANCE.getSharingEnum();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.StateEnum <em>State Enum</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.StateEnum
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getStateEnum()
		 * @generated
		 */
		EEnum STATE_ENUM = eINSTANCE.getStateEnum();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.SyncCapabilityEnum <em>Sync Capability Enum</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.SyncCapabilityEnum
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getSyncCapabilityEnum()
		 * @generated
		 */
		EEnum SYNC_CAPABILITY_ENUM = eINSTANCE.getSyncCapabilityEnum();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.omt.UpdateTypeEnum <em>Update Type Enum</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.UpdateTypeEnum
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getUpdateTypeEnum()
		 * @generated
		 */
		EEnum UPDATE_TYPE_ENUM = eINSTANCE.getUpdateTypeEnum();

		/**
		 * The meta object literal for the '<em>DTD Version Enum Object</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.DTDVersionEnum
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getDTDVersionEnumObject()
		 * @generated
		 */
		EDataType DTD_VERSION_ENUM_OBJECT = eINSTANCE.getDTDVersionEnumObject();

		/**
		 * The meta object literal for the '<em>Endian Enum Object</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.EndianEnum
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getEndianEnumObject()
		 * @generated
		 */
		EDataType ENDIAN_ENUM_OBJECT = eINSTANCE.getEndianEnumObject();

		/**
		 * The meta object literal for the '<em>Object Model Type Enum Object</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.ObjectModelTypeEnum
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getObjectModelTypeEnumObject()
		 * @generated
		 */
		EDataType OBJECT_MODEL_TYPE_ENUM_OBJECT = eINSTANCE.getObjectModelTypeEnumObject();

		/**
		 * The meta object literal for the '<em>Order Enum Object</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.OrderEnum
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getOrderEnumObject()
		 * @generated
		 */
		EDataType ORDER_ENUM_OBJECT = eINSTANCE.getOrderEnumObject();

		/**
		 * The meta object literal for the '<em>Ownership Enum Object</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.OwnershipEnum
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getOwnershipEnumObject()
		 * @generated
		 */
		EDataType OWNERSHIP_ENUM_OBJECT = eINSTANCE.getOwnershipEnumObject();

		/**
		 * The meta object literal for the '<em>Sharing Enum Object</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.SharingEnum
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getSharingEnumObject()
		 * @generated
		 */
		EDataType SHARING_ENUM_OBJECT = eINSTANCE.getSharingEnumObject();

		/**
		 * The meta object literal for the '<em>State Enum Object</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.StateEnum
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getStateEnumObject()
		 * @generated
		 */
		EDataType STATE_ENUM_OBJECT = eINSTANCE.getStateEnumObject();

		/**
		 * The meta object literal for the '<em>Sync Capability Enum Object</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.SyncCapabilityEnum
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getSyncCapabilityEnumObject()
		 * @generated
		 */
		EDataType SYNC_CAPABILITY_ENUM_OBJECT = eINSTANCE.getSyncCapabilityEnumObject();

		/**
		 * The meta object literal for the '<em>Update Type Enum Object</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.omt.UpdateTypeEnum
		 * @see org.eodisp.hla.crc.omt.impl.OmtPackageImpl#getUpdateTypeEnumObject()
		 * @generated
		 */
		EDataType UPDATE_TYPE_ENUM_OBJECT = eINSTANCE.getUpdateTypeEnumObject();

	}

} // OmtPackage
