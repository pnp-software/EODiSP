/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt.impl;

import java.util.List;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eodisp.hla.crc.omt.Enumerator;
import org.eodisp.hla.crc.omt.OmtPackage;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Enumerator</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.EnumeratorImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.EnumeratorImpl#getNameNotes <em>Name Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.EnumeratorImpl#getValues <em>Values</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.EnumeratorImpl#getValuesNotes <em>Values Notes</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class EnumeratorImpl extends EObjectImpl implements Enumerator {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getNameNotes() <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getNameNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List NAME_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNameNotes() <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getNameNotes()
	 * @generated
	 * @ordered
	 */
	protected List nameNotes = NAME_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getValues() <em>Values</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getValues()
	 * @generated
	 * @ordered
	 */
	protected static final List VALUES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getValues() <em>Values</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getValues()
	 * @generated
	 * @ordered
	 */
	protected List values = VALUES_EDEFAULT;

	/**
	 * The default value of the '{@link #getValuesNotes() <em>Values Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getValuesNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List VALUES_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getValuesNotes() <em>Values Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getValuesNotes()
	 * @generated
	 * @ordered
	 */
	protected List valuesNotes = VALUES_NOTES_EDEFAULT;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected EnumeratorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return OmtPackage.Literals.ENUMERATOR;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OmtPackage.ENUMERATOR__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getNameNotes() {
		return nameNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setNameNotes(List newNameNotes) {
		List oldNameNotes = nameNotes;
		nameNotes = newNameNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ENUMERATOR__NAME_NOTES,
					oldNameNotes,
					nameNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getValues() {
		return values;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setValues(List newValues) {
		List oldValues = values;
		values = newValues;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OmtPackage.ENUMERATOR__VALUES, oldValues, values));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getValuesNotes() {
		return valuesNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setValuesNotes(List newValuesNotes) {
		List oldValuesNotes = valuesNotes;
		valuesNotes = newValuesNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ENUMERATOR__VALUES_NOTES,
					oldValuesNotes,
					valuesNotes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case OmtPackage.ENUMERATOR__NAME:
			return getName();
		case OmtPackage.ENUMERATOR__NAME_NOTES:
			return getNameNotes();
		case OmtPackage.ENUMERATOR__VALUES:
			return getValues();
		case OmtPackage.ENUMERATOR__VALUES_NOTES:
			return getValuesNotes();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case OmtPackage.ENUMERATOR__NAME:
			setName((String) newValue);
			return;
		case OmtPackage.ENUMERATOR__NAME_NOTES:
			setNameNotes((List) newValue);
			return;
		case OmtPackage.ENUMERATOR__VALUES:
			setValues((List) newValue);
			return;
		case OmtPackage.ENUMERATOR__VALUES_NOTES:
			setValuesNotes((List) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
		case OmtPackage.ENUMERATOR__NAME:
			setName(NAME_EDEFAULT);
			return;
		case OmtPackage.ENUMERATOR__NAME_NOTES:
			setNameNotes(NAME_NOTES_EDEFAULT);
			return;
		case OmtPackage.ENUMERATOR__VALUES:
			setValues(VALUES_EDEFAULT);
			return;
		case OmtPackage.ENUMERATOR__VALUES_NOTES:
			setValuesNotes(VALUES_NOTES_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case OmtPackage.ENUMERATOR__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case OmtPackage.ENUMERATOR__NAME_NOTES:
			return NAME_NOTES_EDEFAULT == null ? nameNotes != null : !NAME_NOTES_EDEFAULT.equals(nameNotes);
		case OmtPackage.ENUMERATOR__VALUES:
			return VALUES_EDEFAULT == null ? values != null : !VALUES_EDEFAULT.equals(values);
		case OmtPackage.ENUMERATOR__VALUES_NOTES:
			return VALUES_NOTES_EDEFAULT == null ? valuesNotes != null : !VALUES_NOTES_EDEFAULT.equals(valuesNotes);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", nameNotes: ");
		result.append(nameNotes);
		result.append(", values: ");
		result.append(values);
		result.append(", valuesNotes: ");
		result.append(valuesNotes);
		result.append(')');
		return result.toString();
	}

} // EnumeratorImpl
