/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Tags</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.Tags#getUpdateReflectTag <em>Update Reflect Tag</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Tags#getSendReceiveTag <em>Send Receive Tag</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Tags#getDeleteRemoveTag <em>Delete Remove Tag</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Tags#getDivestitureRequestTag <em>Divestiture Request Tag</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Tags#getDivestitureCompletionTag <em>Divestiture Completion Tag</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Tags#getAcquisitionRequestTag <em>Acquisition Request Tag</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Tags#getRequestUpdateTag <em>Request Update Tag</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eodisp.hla.crc.omt.OmtPackage#getTags()
 * @model extendedMetaData="name='Tags' kind='elementOnly'"
 * @generated
 */
public interface Tags extends EObject {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * Returns the value of the '<em><b>Update Reflect Tag</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Update Reflect Tag</em>' containment
	 * reference isn't clear, there really should be more of a description
	 * here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Update Reflect Tag</em>' containment reference.
	 * @see #setUpdateReflectTag(UpdateReflectTag)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getTags_UpdateReflectTag()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='updateReflectTag' namespace='##targetNamespace'"
	 * @generated
	 */
	UpdateReflectTag getUpdateReflectTag();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Tags#getUpdateReflectTag <em>Update Reflect Tag</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Update Reflect Tag</em>' containment reference.
	 * @see #getUpdateReflectTag()
	 * @generated
	 */
	void setUpdateReflectTag(UpdateReflectTag value);

	/**
	 * Returns the value of the '<em><b>Send Receive Tag</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Send Receive Tag</em>' containment
	 * reference isn't clear, there really should be more of a description
	 * here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Send Receive Tag</em>' containment reference.
	 * @see #setSendReceiveTag(SendReceiveTag)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getTags_SendReceiveTag()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='sendReceiveTag' namespace='##targetNamespace'"
	 * @generated
	 */
	SendReceiveTag getSendReceiveTag();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Tags#getSendReceiveTag <em>Send Receive Tag</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Send Receive Tag</em>' containment reference.
	 * @see #getSendReceiveTag()
	 * @generated
	 */
	void setSendReceiveTag(SendReceiveTag value);

	/**
	 * Returns the value of the '<em><b>Delete Remove Tag</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Delete Remove Tag</em>' containment
	 * reference isn't clear, there really should be more of a description
	 * here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Delete Remove Tag</em>' containment reference.
	 * @see #setDeleteRemoveTag(DeleteRemoveTag)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getTags_DeleteRemoveTag()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='deleteRemoveTag' namespace='##targetNamespace'"
	 * @generated
	 */
	DeleteRemoveTag getDeleteRemoveTag();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Tags#getDeleteRemoveTag <em>Delete Remove Tag</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Delete Remove Tag</em>' containment reference.
	 * @see #getDeleteRemoveTag()
	 * @generated
	 */
	void setDeleteRemoveTag(DeleteRemoveTag value);

	/**
	 * Returns the value of the '<em><b>Divestiture Request Tag</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Divestiture Request Tag</em>' containment
	 * reference isn't clear, there really should be more of a description
	 * here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Divestiture Request Tag</em>' containment reference.
	 * @see #setDivestitureRequestTag(DivestitureRequestTag)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getTags_DivestitureRequestTag()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='divestitureRequestTag' namespace='##targetNamespace'"
	 * @generated
	 */
	DivestitureRequestTag getDivestitureRequestTag();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Tags#getDivestitureRequestTag <em>Divestiture Request Tag</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Divestiture Request Tag</em>' containment reference.
	 * @see #getDivestitureRequestTag()
	 * @generated
	 */
	void setDivestitureRequestTag(DivestitureRequestTag value);

	/**
	 * Returns the value of the '<em><b>Divestiture Completion Tag</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Divestiture Completion Tag</em>'
	 * containment reference isn't clear, there really should be more of a
	 * description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Divestiture Completion Tag</em>' containment reference.
	 * @see #setDivestitureCompletionTag(DivestitureCompletionTag)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getTags_DivestitureCompletionTag()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='divestitureCompletionTag' namespace='##targetNamespace'"
	 * @generated
	 */
	DivestitureCompletionTag getDivestitureCompletionTag();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Tags#getDivestitureCompletionTag <em>Divestiture Completion Tag</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Divestiture Completion Tag</em>' containment reference.
	 * @see #getDivestitureCompletionTag()
	 * @generated
	 */
	void setDivestitureCompletionTag(DivestitureCompletionTag value);

	/**
	 * Returns the value of the '<em><b>Acquisition Request Tag</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Acquisition Request Tag</em>' containment
	 * reference isn't clear, there really should be more of a description
	 * here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Acquisition Request Tag</em>' containment reference.
	 * @see #setAcquisitionRequestTag(AcquisitionRequestTag)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getTags_AcquisitionRequestTag()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='acquisitionRequestTag' namespace='##targetNamespace'"
	 * @generated
	 */
	AcquisitionRequestTag getAcquisitionRequestTag();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Tags#getAcquisitionRequestTag <em>Acquisition Request Tag</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Acquisition Request Tag</em>' containment reference.
	 * @see #getAcquisitionRequestTag()
	 * @generated
	 */
	void setAcquisitionRequestTag(AcquisitionRequestTag value);

	/**
	 * Returns the value of the '<em><b>Request Update Tag</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Request Update Tag</em>' containment
	 * reference isn't clear, there really should be more of a description
	 * here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Request Update Tag</em>' containment reference.
	 * @see #setRequestUpdateTag(RequestUpdateTag)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getTags_RequestUpdateTag()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='requestUpdateTag' namespace='##targetNamespace'"
	 * @generated
	 */
	RequestUpdateTag getRequestUpdateTag();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Tags#getRequestUpdateTag <em>Request Update Tag</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Request Update Tag</em>' containment reference.
	 * @see #getRequestUpdateTag()
	 * @generated
	 */
	void setRequestUpdateTag(RequestUpdateTag value);

} // Tags
