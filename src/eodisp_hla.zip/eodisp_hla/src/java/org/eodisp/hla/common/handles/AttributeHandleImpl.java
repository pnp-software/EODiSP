/**
 * 
 */
package org.eodisp.hla.common.handles;


import hla.rti1516.AttributeHandle;
import hla.rti1516.FederateHandle;

/**
 * @author ibirrer
 */
public class AttributeHandleImpl extends HandleImpl implements AttributeHandle {
	private static final long serialVersionUID = 1L;
	
	/**
	 * {@inheritDoc}
	 */
	public AttributeHandleImpl(int id) {
		super(id);
	}
}
