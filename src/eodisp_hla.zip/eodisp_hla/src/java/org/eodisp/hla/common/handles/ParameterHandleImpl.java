/**
 * 
 */
package org.eodisp.hla.common.handles;


import hla.rti1516.ParameterHandle;

/**
 * A federation execution wide parameter handle.
 * @author ibirrer
 */
public class ParameterHandleImpl extends HandleImpl implements ParameterHandle {
	
	private static final long serialVersionUID = 1L;
	
	/**
	 * {@inheritDoc}
	 */
	public ParameterHandleImpl(int id) {
		super(id);
	}
}
