/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt;

import java.util.List;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Simple Data</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.SimpleData#getAccuracy <em>Accuracy</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.SimpleData#getAccuracyNotes <em>Accuracy Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.SimpleData#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.SimpleData#getNameNotes <em>Name Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.SimpleData#getRepresentation <em>Representation</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.SimpleData#getRepresentationNotes <em>Representation Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.SimpleData#getResolution <em>Resolution</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.SimpleData#getResolutionNotes <em>Resolution Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.SimpleData#getSemantics <em>Semantics</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.SimpleData#getSemanticsNotes <em>Semantics Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.SimpleData#getUnits <em>Units</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.SimpleData#getUnitsNotes <em>Units Notes</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eodisp.hla.crc.omt.OmtPackage#getSimpleData()
 * @model extendedMetaData="name='SimpleData' kind='empty'"
 * @generated
 */
public interface SimpleData extends EObject {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * Returns the value of the '<em><b>Accuracy</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Accuracy</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Accuracy</em>' attribute.
	 * @see #setAccuracy(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSimpleData_Accuracy()
	 * @model unique="false"
	 *        dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='accuracy'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	Object getAccuracy();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.SimpleData#getAccuracy <em>Accuracy</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Accuracy</em>' attribute.
	 * @see #getAccuracy()
	 * @generated
	 */
	void setAccuracy(Object value);

	/**
	 * Returns the value of the '<em><b>Accuracy Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Accuracy Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Accuracy Notes</em>' attribute.
	 * @see #setAccuracyNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSimpleData_AccuracyNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='accuracyNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getAccuracyNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.SimpleData#getAccuracyNotes <em>Accuracy Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Accuracy Notes</em>' attribute.
	 * @see #getAccuracyNotes()
	 * @generated
	 */
	void setAccuracyNotes(List value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSimpleData_Name()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKEN"
	 *        required="true" extendedMetaData="kind='attribute' name='name'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.SimpleData#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Name Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name Notes</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name Notes</em>' attribute.
	 * @see #setNameNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSimpleData_NameNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='nameNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getNameNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.SimpleData#getNameNotes <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name Notes</em>' attribute.
	 * @see #getNameNotes()
	 * @generated
	 */
	void setNameNotes(List value);

	/**
	 * Returns the value of the '<em><b>Representation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Representation</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Representation</em>' attribute.
	 * @see #setRepresentation(String)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSimpleData_Representation()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKEN"
	 *        extendedMetaData="kind='attribute' name='representation' namespace='##targetNamespace'"
	 * @generated
	 */
	String getRepresentation();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.SimpleData#getRepresentation <em>Representation</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Representation</em>' attribute.
	 * @see #getRepresentation()
	 * @generated
	 */
	void setRepresentation(String value);

	/**
	 * Returns the value of the '<em><b>Representation Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Representation Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Representation Notes</em>' attribute.
	 * @see #setRepresentationNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSimpleData_RepresentationNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='representationNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getRepresentationNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.SimpleData#getRepresentationNotes <em>Representation Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Representation Notes</em>' attribute.
	 * @see #getRepresentationNotes()
	 * @generated
	 */
	void setRepresentationNotes(List value);

	/**
	 * Returns the value of the '<em><b>Resolution</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Resolution</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Resolution</em>' attribute.
	 * @see #setResolution(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSimpleData_Resolution()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='resolution' namespace='##targetNamespace'"
	 * @generated
	 */
	Object getResolution();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.SimpleData#getResolution <em>Resolution</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Resolution</em>' attribute.
	 * @see #getResolution()
	 * @generated
	 */
	void setResolution(Object value);

	/**
	 * Returns the value of the '<em><b>Resolution Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Resolution Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Resolution Notes</em>' attribute.
	 * @see #setResolutionNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSimpleData_ResolutionNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='resolutionNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getResolutionNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.SimpleData#getResolutionNotes <em>Resolution Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Resolution Notes</em>' attribute.
	 * @see #getResolutionNotes()
	 * @generated
	 */
	void setResolutionNotes(List value);

	/**
	 * Returns the value of the '<em><b>Semantics</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Semantics</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Semantics</em>' attribute.
	 * @see #setSemantics(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSimpleData_Semantics()
	 * @model unique="false"
	 *        dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='semantics'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	Object getSemantics();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.SimpleData#getSemantics <em>Semantics</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Semantics</em>' attribute.
	 * @see #getSemantics()
	 * @generated
	 */
	void setSemantics(Object value);

	/**
	 * Returns the value of the '<em><b>Semantics Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Semantics Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Semantics Notes</em>' attribute.
	 * @see #setSemanticsNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSimpleData_SemanticsNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='semanticsNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSemanticsNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.SimpleData#getSemanticsNotes <em>Semantics Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Semantics Notes</em>' attribute.
	 * @see #getSemanticsNotes()
	 * @generated
	 */
	void setSemanticsNotes(List value);

	/**
	 * Returns the value of the '<em><b>Units</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Units</em>' attribute isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Units</em>' attribute.
	 * @see #setUnits(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSimpleData_Units()
	 * @model unique="false"
	 *        dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='units'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	Object getUnits();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.SimpleData#getUnits <em>Units</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Units</em>' attribute.
	 * @see #getUnits()
	 * @generated
	 */
	void setUnits(Object value);

	/**
	 * Returns the value of the '<em><b>Units Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Units Notes</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Units Notes</em>' attribute.
	 * @see #setUnitsNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSimpleData_UnitsNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='unitsNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getUnitsNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.SimpleData#getUnitsNotes <em>Units Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Units Notes</em>' attribute.
	 * @see #getUnitsNotes()
	 * @generated
	 */
	void setUnitsNotes(List value);

} // SimpleData
