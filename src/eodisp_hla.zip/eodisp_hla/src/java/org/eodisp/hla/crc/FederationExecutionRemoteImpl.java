/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.hla.crc;

import hla.rti1516.*;

import java.rmi.RemoteException;
import java.util.Map;
import java.util.Set;

import org.eodisp.hla.common.crc.FederationExecutionRemote;
import org.eodisp.hla.common.lrc.LrcRemote;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 * @UML -------------------------------------------------------------------
 * 
 * @navassoc - federationExecution 1 FederationExecution
 * 
 */
public class FederationExecutionRemoteImpl implements FederationExecutionRemote {

	private final FederationExecution federationExecution;

	/**
	 * Constructor
	 */
	public FederationExecutionRemoteImpl(FederationExecution federationExecution) {
		this.federationExecution = federationExecution;
	}

	/**
	 * {@inheritDoc}
	 */
	public void resign(ResignAction resignAction, FederateHandle federateHandle) throws OwnershipAcquisitionPending,
			FederateOwnsAttributes, FederateNotExecutionMember {
		federationExecution.resign(resignAction, federateHandle);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @throws FederateNotExecutionMember
	 */
	public void registerFederationSynchronizationPoint(String synchronizationPointLabel, byte[] userSuppliedTag,
			FederateHandle askingFederate) throws SaveInProgress, RestoreInProgress, FederateNotExecutionMember {
		federationExecution.registerFederationSynchronizationPoint(
				synchronizationPointLabel,
				userSuppliedTag,
				askingFederate);
	}

	public void registerFederationSynchronizationPoint(String synchronizationPointLabel, byte[] userSuppliedTag,
			FederateHandle[] synchronizationSet, FederateHandle askingFederate) throws SaveInProgress,
			RestoreInProgress, FederateNotExecutionMember {
		federationExecution.registerFederationSynchronizationPoint(
				synchronizationPointLabel,
				userSuppliedTag,
				synchronizationSet,
				askingFederate);
	}

	/**
	 * {@inheritDoc}
	 */
	public void synchronizationPointAchieved(String synchronizationPointLabel, FederateHandle askingFederate)
			throws SynchronizationPointLabelNotAnnounced, SaveInProgress, RestoreInProgress {
		federationExecution.synchronizationPointAchieved(synchronizationPointLabel, askingFederate);

	}

	/**
	 * {@inheritDoc}
	 */
	public ObjectClassHandle getObjectClassHandle(String theName) throws NameNotFound {
		return federationExecution.getObjectClassHandle(theName);
	}

	/**
	 * {@inheritDoc}
	 */
	public String getObjectClassName(ObjectClassHandle theHandle) throws ObjectClassNotDefined {
		return federationExecution.getObjectClassName(theHandle);
	}

	/**
	 * {@inheritDoc}
	 */
	public AttributeHandle getAttributeHandle(ObjectClassHandle objectClassHandle, String theName)
			throws ObjectClassNotDefined, NameNotFound {
		return federationExecution.getAttributeHandle(objectClassHandle, theName);
	}

	/**
	 * {@inheritDoc}
	 */
	public String getAttributeName(ObjectClassHandle whichClass, AttributeHandle theHandle)
			throws ObjectClassNotDefined, InvalidAttributeHandle, AttributeNotDefined {
		return federationExecution.getAttributeName(whichClass, theHandle);
	}

	/**
	 * {@inheritDoc}
	 */
	public InteractionClassHandle getInteractionClassHandle(String theName) throws NameNotFound {
		return federationExecution.getInteractionClassHandle(theName);
	}

	/**
	 * {@inheritDoc}
	 */
	public String getInteractionClassName(InteractionClassHandle theHandle) throws InteractionClassNotDefined {
		return federationExecution.getInteractionClassName(theHandle);
	}

	/**
	 * {@inheritDoc}
	 */
	public ParameterHandle getParameterHandle(InteractionClassHandle interactionClassHandle, String theName)
			throws NameNotFound, InteractionClassNotDefined {
		return federationExecution.getParameterHandle(interactionClassHandle, theName);
	}

	/**
	 * {@inheritDoc}
	 */
	public String getParameterName(InteractionClassHandle interactionClassHandle, ParameterHandle parameterHandle)
			throws InteractionClassNotDefined, InteractionParameterNotDefined, InvalidParameterHandle {
		return federationExecution.getParameterName(interactionClassHandle, parameterHandle);
	}

	/**
	 * {@inheritDoc}
	 */
	public ObjectInstanceHandle getObjectInstanceHandle(String theName) throws ObjectInstanceNotKnown {
		return federationExecution.getObjectInstanceHandle(theName);
	}

	/**
	 * {@inheritDoc}
	 */
	public String getObjectInstanceName(ObjectInstanceHandle objectInstanceHandle) throws ObjectInstanceNotKnown,
			RemoteException {
		return federationExecution.getObjectInstanceName(objectInstanceHandle);
	}

	/**
	 * {@inheritDoc}
	 */
	public ObjectClassHandle getKnownObjectClassHandle(ObjectInstanceHandle objectInstanceHandle)
			throws ObjectInstanceNotKnown {
		return federationExecution.getKnownObjectClassHandle(objectInstanceHandle);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @throws InvalidAttributeHandle
	 * @throws InvalidFederateHandle
	 * @throws InvalidObjectClassHandle
	 */
	public void publishObjectClassAttributes(ObjectClassHandle theClass, AttributeHandle[] attributeHandles,
			FederateHandle federateHandle) throws ObjectClassNotDefined, AttributeNotDefined,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, InvalidFederateHandle,
			InvalidAttributeHandle, InvalidObjectClassHandle {
		federationExecution.publishObjectClassAttributes(theClass, attributeHandles, federateHandle);
	}

	/**
	 * {@inheritDoc}
	 */
	public void unpublishObjectClass(ObjectClassHandle objectClassHandle, FederateHandle federateHandle)
			throws ObjectClassNotDefined, FederateNotExecutionMember {
		federationExecution.unpublishObjectClass(objectClassHandle, federateHandle);
	}

	/**
	 * {@inheritDoc}
	 */
	public void unpublishObjectClassAttributes(ObjectClassHandle objectClassHandle, AttributeHandle[] attributeHandles,
			FederateHandle federateHandle) throws ObjectClassNotDefined, AttributeNotDefined,
			FederateNotExecutionMember, InvalidAttributeHandle {
		federationExecution.unpublishObjectClassAttributes(objectClassHandle, attributeHandles, federateHandle);
	}

	/**
	 * {@inheritDoc}
	 */
	public void publishInteractionClass(InteractionClassHandle interactionClassHandle, FederateHandle federateHandle)
			throws InteractionClassNotDefined, FederateNotExecutionMember, SaveInProgress, RestoreInProgress {
		federationExecution.publishInteractionClass(interactionClassHandle, federateHandle);

	}

	public void unpublishInteractionClass(InteractionClassHandle interactionClassHandle, FederateHandle federateHandle)
			throws InteractionClassNotDefined, FederateNotExecutionMember, SaveInProgress, RestoreInProgress {
		federationExecution.unpusblishInteractionClass(interactionClassHandle, federateHandle);
	}

	/**
	 * {@inheritDoc}
	 */
	public void subscribeObjectClassAttributes(ObjectClassHandle objectClassHandle, AttributeHandle[] attributeHandles,
			FederateHandle federateHandle) throws ObjectClassNotDefined, AttributeNotDefined,
			FederateNotExecutionMember, InvalidAttributeHandle {
		federationExecution.subscribeObjectClassAttributes(objectClassHandle, attributeHandles, federateHandle);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @throws InvalidAttributeHandle
	 */
	public void unsubscribeObjectClassAttributes(ObjectClassHandle objectClassHandle,
			AttributeHandle[] attributeHandles, FederateHandle federateHandle) throws ObjectClassNotDefined,
			AttributeNotDefined, FederateNotExecutionMember, InvalidAttributeHandle {
		federationExecution.unsubscribeObjectClassAttributes(objectClassHandle, attributeHandles, federateHandle);
	}

	/**
	 * {@inheritDoc}
	 */
	public void unsubscribeObjectClass(ObjectClassHandle objectClassHandle, FederateHandle federateHandle)
			throws ObjectClassNotDefined, FederateNotExecutionMember {
		federationExecution.unsubscribeObjectClass(objectClassHandle, federateHandle);
	}

	/**
	 * {@inheritDoc}
	 */
	public void subscribeInteractionClass(InteractionClassHandle interactionClassHandle, FederateHandle federateHandle)
			throws InteractionClassNotDefined, FederateServiceInvocationsAreBeingReportedViaMOM,
			FederateNotExecutionMember {
		federationExecution.subscribeInteractionClass(interactionClassHandle, federateHandle);
	}

	/**
	 * {@inheritDoc}
	 */
	public void unsubscribeInteractionClass(InteractionClassHandle interactionClassHandle, FederateHandle federateHandle)
			throws InteractionClassNotDefined, FederateNotExecutionMember, SaveInProgress, RestoreInProgress {
		federationExecution.unsubscribeInteractionClass(interactionClassHandle, federateHandle);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @throws InvalidObjectClassHandle
	 */
	public ObjectInstanceHandle registerObjectInstance(ObjectClassHandle objectClassHandle,
			FederateHandle federateHandle) throws ObjectClassNotDefined, ObjectClassNotPublished,
			FederateNotExecutionMember, InvalidObjectClassHandle {
		return federationExecution.registerObjectInstance(objectClassHandle, federateHandle);
	}

	public ObjectInstanceHandle registerObjectInstance(ObjectClassHandle objectClassHandle, String instanceName,
			FederateHandle federateHandle) throws ObjectClassNotDefined, ObjectClassNotPublished,
			ObjectInstanceNameNotReserved, ObjectInstanceNameInUse, FederateNotExecutionMember, SaveInProgress,
			RestoreInProgress {
		throw new UnsupportedOperationException("Use the registerObjectInstance(...) without specifying instead.");
	}

	/**
	 * {@inheritDoc}
	 */
	public Map<LrcRemote, Map<FederateHandle, AttributeHandle[]>> getSubscriptions(
			ObjectInstanceHandle objectInstanceHandle, AttributeHandle[] attributeHandles,
			FederateHandle askingFederateHandle) throws AttributeNotDefined, AttributeNotOwned,
			FederateNotExecutionMember, InvalidAttributeHandle, ObjectInstanceNotKnown {
		return federationExecution.getSubscriptions(objectInstanceHandle, attributeHandles, askingFederateHandle);
	}

	/**
	 * {@inheritDoc}
	 */
	public Map<LrcRemote, Set<FederateHandle>> getSubscriptions(InteractionClassHandle interactionClassHandle,
			FederateHandle federateHandle) throws InteractionClassNotDefined, InteractionClassNotPublished,
			FederateNotExecutionMember {
		return federationExecution.getSubscriptions(interactionClassHandle, federateHandle);
	}

	/**
	 * {@inheritDoc}
	 */
	public void requestAttributeValueUpdate(ObjectInstanceHandle objectInstanceHandle,
			AttributeHandle[] attributeHandles, byte[] userSuppliedTag) throws ObjectInstanceNotKnown,
			AttributeNotDefined, SaveInProgress, RestoreInProgress {
		// TODO requestAttributeValueUpdate

	}

	/**
	 * {@inheritDoc}
	 */
	public int getJoinedFederates() throws RemoteException {
		return federationExecution.getNrOfJoinedFederates();
	}

}
