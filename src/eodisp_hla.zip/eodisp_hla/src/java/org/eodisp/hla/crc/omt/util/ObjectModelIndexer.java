/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.hla.crc.omt.util;

import hla.rti1516.*;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import net.jcip.annotations.GuardedBy;

import org.eclipse.emf.ecore.EObject;
import org.eodisp.hla.crc.omt.*;

/**
 * Creates all indices for an object model, these are:
 * 
 * <ul>
 * <li></li>
 * </ul>
 * 
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class ObjectModelIndexer {

	private final Map<String, ObjectClass> objectClassNameIndex = new HashMap<String, ObjectClass>();

	private final Map<String, InteractionClass> interactionClassNameIndex = new HashMap<String, InteractionClass>();

	public ObjectModelIndexer(ObjectModel objectModel) {
		OmtSwitch omtSwitch = new OmtSwitch() {

			/**
			 * {@inheritDoc}
			 */
			@Override
			public Object caseObjectClass(ObjectClass objectClass) {
				objectClassNameIndex.put(objectClass.getQualifiedName(true), objectClass);
				objectClassNameIndex.put(objectClass.getQualifiedName(false), objectClass);
				return super.caseObjectClass(objectClass);
			}

			/**
			 * {@inheritDoc}
			 */
			@Override
			public Object caseInteractionClass(InteractionClass interactionClass) {
				interactionClassNameIndex.put(interactionClass.getQualifiedName(true), interactionClass);
				interactionClassNameIndex.put(interactionClass.getQualifiedName(false), interactionClass);
				return super.caseInteractionClass(interactionClass);
			}
		};

		// Iterate over all model elements
		Iterator it = objectModel.eAllContents();
		while (it.hasNext()) {
			omtSwitch.doSwitch((EObject) it.next());
		}
	}

	public ObjectClass getObjectClass(String name) {
		return objectClassNameIndex.get(name);
	}

	public InteractionClass getInteractionClass(String name) {
		return interactionClassNameIndex.get(name);
	}

}
