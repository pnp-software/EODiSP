package org.eodisp.hla.common.handles;

import hla.rti1516.FederateHandle;
import hla.rti1516.FederateHandleSet;

import java.util.Collection;
import java.util.HashSet;

/**
 * All <code>Set</code> operations are required, none are optional. Methods
 * <code>add</code> and <code>remove</code> should throw
 * <code>IllegalArgumentException</code> if the argument is not a
 * <code>FederateHandleHandle</code>. Methods <code>addAll</code>,
 * <code>removeAll</code> and <code>retainAll</code> should throw
 * <code>IllegalArgumentException</code> if the argument is not a
 * <code>FederateHandleSet</code>.
 * 
 * @author Andrzej Kapolka
 */

public class FederateHandleSetImpl extends HashSet implements FederateHandleSet {
	/**
	 * Constructor.
	 */
	protected FederateHandleSetImpl() {
		super();
	}

	/**
	 * Adds the specified object to this set.
	 * 
	 * @param o
	 *            the object to add
	 * @return <code>true</code> if the set changed as a result of this method
	 *         call, <code>false</code> otherwise
	 * @exception IllegalArgumentException
	 *                if the object is not a <code>FederateHandle</code>
	 */
	public boolean add(Object o) {
		if (!(o instanceof FederateHandle)) {
			throw new IllegalArgumentException("object must be FederateHandle");
		}

		return super.add(o);
	}

	/**
	 * Removes the specified object from this set.
	 * 
	 * @param o
	 *            the object to remove
	 * @return <code>true</code> if the set changed as a result of this method
	 *         call, <code>false</code> otherwise
	 * @exception IllegalArgumentException
	 *                if the object is not a <code>FederateHandle</code>
	 */
	public boolean remove(Object o) {
		if (!(o instanceof FederateHandle)) {
			throw new IllegalArgumentException("object must be FederateHandle");
		}

		return super.remove(o);
	}

	/**
	 * Adds all of the objects in the specified collection to this set.
	 * 
	 * @param c
	 *            the collection containing the objects to add
	 * @return <code>true</code> if the set changed as a result of this method
	 *         call, <code>false</code> otherwise
	 * @exception IllegalArgumentException
	 *                if the collection is not a <code>FederateHandleSet</code>
	 */
	public boolean addAll(Collection c) {
		if (!(c instanceof FederateHandleSet)) {
			throw new IllegalArgumentException(
					"collection must be FederateHandleSet");
		}

		return super.addAll(c);
	}

	/**
	 * Removes all of the objects in the specified collection from this set.
	 * 
	 * @param c
	 *            the collection containing the objects to remove
	 * @return <code>true</code> if the set changed as a result of this method
	 *         call, <code>false</code> otherwise
	 * @exception IllegalArgumentException
	 *                if the collection is not a <code>FederateHandleSet</code>
	 */
	public boolean removeAll(Collection c) {
		if (!(c instanceof FederateHandleSet)) {
			throw new IllegalArgumentException(
					"collection must be FederateHandleSet");
		}

		return super.removeAll(c);
	}

	/**
	 * Removes all of the objects in this set except for those present in the
	 * specified collection.
	 * 
	 * @param c
	 *            the collection containing the objects to retain
	 * @return <code>true</code> if the set changed as a result of this method
	 *         call, <code>false</code> otherwise
	 * @exception IllegalArgumentException
	 *                if the collection is not a <code>FederateHandleSet</code>
	 */
	public boolean retainAll(Collection c) {
		if (!(c instanceof FederateHandleSet)) {
			throw new IllegalArgumentException(
					"collection must be FederateHandleSet");
		}

		return super.retainAll(c);
	}
}
