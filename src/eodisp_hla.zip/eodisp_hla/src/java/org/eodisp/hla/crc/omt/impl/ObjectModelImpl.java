/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt.impl;

import java.util.List;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eodisp.hla.crc.omt.DTDVersionEnum;
import org.eodisp.hla.crc.omt.DataTypes;
import org.eodisp.hla.crc.omt.Dimensions;
import org.eodisp.hla.crc.omt.Interactions;
import org.eodisp.hla.crc.omt.Notes;
import org.eodisp.hla.crc.omt.ObjectModel;
import org.eodisp.hla.crc.omt.ObjectModelTypeEnum;
import org.eodisp.hla.crc.omt.Objects;
import org.eodisp.hla.crc.omt.OmtPackage;
import org.eodisp.hla.crc.omt.Switches;
import org.eodisp.hla.crc.omt.Synchronizations;
import org.eodisp.hla.crc.omt.Tags;
import org.eodisp.hla.crc.omt.Time;
import org.eodisp.hla.crc.omt.Transportations;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Object Model</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getObjects <em>Objects</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getInteractions <em>Interactions</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getDimensions <em>Dimensions</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getTime <em>Time</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getTags <em>Tags</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getSynchronizations <em>Synchronizations</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getTransportations <em>Transportations</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getSwitches <em>Switches</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getDataTypes <em>Data Types</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getNotes <em>Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getAppDomain <em>App Domain</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getAppDomainNotes <em>App Domain Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getDate <em>Date</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getDateNotes <em>Date Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getDTDversion <em>DT Dversion</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getNameNotes <em>Name Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getOther <em>Other</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getOtherNotes <em>Other Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getPocEmail <em>Poc Email</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getPocEmailNotes <em>Poc Email Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getPocName <em>Poc Name</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getPocNameNotes <em>Poc Name Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getPocOrg <em>Poc Org</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getPocOrgNotes <em>Poc Org Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getPocPhone <em>Poc Phone</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getPocPhoneNotes <em>Poc Phone Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getPurpose <em>Purpose</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getPurposeNotes <em>Purpose Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getReferences <em>References</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getReferencesNotes <em>References Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getSponsor <em>Sponsor</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getSponsorNotes <em>Sponsor Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getType <em>Type</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getTypeNotes <em>Type Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getVersion <em>Version</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectModelImpl#getVersionNotes <em>Version Notes</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ObjectModelImpl extends EObjectImpl implements ObjectModel {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The cached value of the '{@link #getObjects() <em>Objects</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getObjects()
	 * @generated
	 * @ordered
	 */
	protected Objects objects = null;

	/**
	 * The cached value of the '{@link #getInteractions() <em>Interactions</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getInteractions()
	 * @generated
	 * @ordered
	 */
	protected Interactions interactions = null;

	/**
	 * The cached value of the '{@link #getDimensions() <em>Dimensions</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDimensions()
	 * @generated
	 * @ordered
	 */
	protected Dimensions dimensions = null;

	/**
	 * The cached value of the '{@link #getTime() <em>Time</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getTime()
	 * @generated
	 * @ordered
	 */
	protected Time time = null;

	/**
	 * The cached value of the '{@link #getTags() <em>Tags</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getTags()
	 * @generated
	 * @ordered
	 */
	protected Tags tags = null;

	/**
	 * The cached value of the '{@link #getSynchronizations() <em>Synchronizations</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSynchronizations()
	 * @generated
	 * @ordered
	 */
	protected Synchronizations synchronizations = null;

	/**
	 * The cached value of the '{@link #getTransportations() <em>Transportations</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getTransportations()
	 * @generated
	 * @ordered
	 */
	protected Transportations transportations = null;

	/**
	 * The cached value of the '{@link #getSwitches() <em>Switches</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSwitches()
	 * @generated
	 * @ordered
	 */
	protected Switches switches = null;

	/**
	 * The cached value of the '{@link #getDataTypes() <em>Data Types</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDataTypes()
	 * @generated
	 * @ordered
	 */
	protected DataTypes dataTypes = null;

	/**
	 * The cached value of the '{@link #getNotes() <em>Notes</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getNotes()
	 * @generated
	 * @ordered
	 */
	protected Notes notes = null;

	/**
	 * The default value of the '{@link #getAppDomain() <em>App Domain</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getAppDomain()
	 * @generated
	 * @ordered
	 */
	protected static final Object APP_DOMAIN_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getAppDomain() <em>App Domain</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getAppDomain()
	 * @generated
	 * @ordered
	 */
	protected Object appDomain = APP_DOMAIN_EDEFAULT;

	/**
	 * The default value of the '{@link #getAppDomainNotes() <em>App Domain Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getAppDomainNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List APP_DOMAIN_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getAppDomainNotes() <em>App Domain Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getAppDomainNotes()
	 * @generated
	 * @ordered
	 */
	protected List appDomainNotes = APP_DOMAIN_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getDate() <em>Date</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDate()
	 * @generated
	 * @ordered
	 */
	protected static final Object DATE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDate() <em>Date</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDate()
	 * @generated
	 * @ordered
	 */
	protected Object date = DATE_EDEFAULT;

	/**
	 * The default value of the '{@link #getDateNotes() <em>Date Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDateNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List DATE_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDateNotes() <em>Date Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDateNotes()
	 * @generated
	 * @ordered
	 */
	protected List dateNotes = DATE_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getDTDversion() <em>DT Dversion</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDTDversion()
	 * @generated
	 * @ordered
	 */
	protected static final DTDVersionEnum DT_DVERSION_EDEFAULT = DTDVersionEnum._15162_LITERAL;

	/**
	 * The cached value of the '{@link #getDTDversion() <em>DT Dversion</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDTDversion()
	 * @generated
	 * @ordered
	 */
	protected DTDVersionEnum dTDversion = DT_DVERSION_EDEFAULT;

	/**
	 * This is true if the DT Dversion attribute has been set. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	protected boolean dTDversionESet = false;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final Object NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected Object name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getNameNotes() <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getNameNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List NAME_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNameNotes() <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getNameNotes()
	 * @generated
	 * @ordered
	 */
	protected List nameNotes = NAME_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getOther() <em>Other</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getOther()
	 * @generated
	 * @ordered
	 */
	protected static final Object OTHER_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getOther() <em>Other</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getOther()
	 * @generated
	 * @ordered
	 */
	protected Object other = OTHER_EDEFAULT;

	/**
	 * The default value of the '{@link #getOtherNotes() <em>Other Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getOtherNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List OTHER_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getOtherNotes() <em>Other Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getOtherNotes()
	 * @generated
	 * @ordered
	 */
	protected List otherNotes = OTHER_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getPocEmail() <em>Poc Email</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getPocEmail()
	 * @generated
	 * @ordered
	 */
	protected static final Object POC_EMAIL_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPocEmail() <em>Poc Email</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getPocEmail()
	 * @generated
	 * @ordered
	 */
	protected Object pocEmail = POC_EMAIL_EDEFAULT;

	/**
	 * The default value of the '{@link #getPocEmailNotes() <em>Poc Email Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getPocEmailNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List POC_EMAIL_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPocEmailNotes() <em>Poc Email Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getPocEmailNotes()
	 * @generated
	 * @ordered
	 */
	protected List pocEmailNotes = POC_EMAIL_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getPocName() <em>Poc Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getPocName()
	 * @generated
	 * @ordered
	 */
	protected static final Object POC_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPocName() <em>Poc Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getPocName()
	 * @generated
	 * @ordered
	 */
	protected Object pocName = POC_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getPocNameNotes() <em>Poc Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getPocNameNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List POC_NAME_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPocNameNotes() <em>Poc Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getPocNameNotes()
	 * @generated
	 * @ordered
	 */
	protected List pocNameNotes = POC_NAME_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getPocOrg() <em>Poc Org</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getPocOrg()
	 * @generated
	 * @ordered
	 */
	protected static final Object POC_ORG_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPocOrg() <em>Poc Org</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getPocOrg()
	 * @generated
	 * @ordered
	 */
	protected Object pocOrg = POC_ORG_EDEFAULT;

	/**
	 * The default value of the '{@link #getPocOrgNotes() <em>Poc Org Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getPocOrgNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List POC_ORG_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPocOrgNotes() <em>Poc Org Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getPocOrgNotes()
	 * @generated
	 * @ordered
	 */
	protected List pocOrgNotes = POC_ORG_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getPocPhone() <em>Poc Phone</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getPocPhone()
	 * @generated
	 * @ordered
	 */
	protected static final Object POC_PHONE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPocPhone() <em>Poc Phone</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getPocPhone()
	 * @generated
	 * @ordered
	 */
	protected Object pocPhone = POC_PHONE_EDEFAULT;

	/**
	 * The default value of the '{@link #getPocPhoneNotes() <em>Poc Phone Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getPocPhoneNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List POC_PHONE_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPocPhoneNotes() <em>Poc Phone Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getPocPhoneNotes()
	 * @generated
	 * @ordered
	 */
	protected List pocPhoneNotes = POC_PHONE_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getPurpose() <em>Purpose</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getPurpose()
	 * @generated
	 * @ordered
	 */
	protected static final Object PURPOSE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPurpose() <em>Purpose</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getPurpose()
	 * @generated
	 * @ordered
	 */
	protected Object purpose = PURPOSE_EDEFAULT;

	/**
	 * The default value of the '{@link #getPurposeNotes() <em>Purpose Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getPurposeNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List PURPOSE_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPurposeNotes() <em>Purpose Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getPurposeNotes()
	 * @generated
	 * @ordered
	 */
	protected List purposeNotes = PURPOSE_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getReferences() <em>References</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getReferences()
	 * @generated
	 * @ordered
	 */
	protected static final Object REFERENCES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getReferences() <em>References</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getReferences()
	 * @generated
	 * @ordered
	 */
	protected Object references = REFERENCES_EDEFAULT;

	/**
	 * The default value of the '{@link #getReferencesNotes() <em>References Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getReferencesNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List REFERENCES_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getReferencesNotes() <em>References Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getReferencesNotes()
	 * @generated
	 * @ordered
	 */
	protected List referencesNotes = REFERENCES_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getSponsor() <em>Sponsor</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSponsor()
	 * @generated
	 * @ordered
	 */
	protected static final Object SPONSOR_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSponsor() <em>Sponsor</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSponsor()
	 * @generated
	 * @ordered
	 */
	protected Object sponsor = SPONSOR_EDEFAULT;

	/**
	 * The default value of the '{@link #getSponsorNotes() <em>Sponsor Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSponsorNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List SPONSOR_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSponsorNotes() <em>Sponsor Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSponsorNotes()
	 * @generated
	 * @ordered
	 */
	protected List sponsorNotes = SPONSOR_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final ObjectModelTypeEnum TYPE_EDEFAULT = ObjectModelTypeEnum.FOM_LITERAL;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected ObjectModelTypeEnum type = TYPE_EDEFAULT;

	/**
	 * This is true if the Type attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean typeESet = false;

	/**
	 * The default value of the '{@link #getTypeNotes() <em>Type Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getTypeNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List TYPE_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTypeNotes() <em>Type Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getTypeNotes()
	 * @generated
	 * @ordered
	 */
	protected List typeNotes = TYPE_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getVersion() <em>Version</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getVersion()
	 * @generated
	 * @ordered
	 */
	protected static final Object VERSION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getVersion() <em>Version</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getVersion()
	 * @generated
	 * @ordered
	 */
	protected Object version = VERSION_EDEFAULT;

	/**
	 * The default value of the '{@link #getVersionNotes() <em>Version Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getVersionNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List VERSION_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getVersionNotes() <em>Version Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getVersionNotes()
	 * @generated
	 * @ordered
	 */
	protected List versionNotes = VERSION_NOTES_EDEFAULT;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected ObjectModelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return OmtPackage.Literals.OBJECT_MODEL;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Objects getObjects() {
		return objects;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetObjects(Objects newObjects, NotificationChain msgs) {
		Objects oldObjects = objects;
		objects = newObjects;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__OBJECTS,
					oldObjects,
					newObjects);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setObjects(Objects newObjects) {
		if (newObjects != objects) {
			NotificationChain msgs = null;
			if (objects != null)
				msgs = ((InternalEObject) objects).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.OBJECT_MODEL__OBJECTS, null, msgs);
			if (newObjects != null)
				msgs = ((InternalEObject) newObjects).eInverseAdd(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.OBJECT_MODEL__OBJECTS, null, msgs);
			msgs = basicSetObjects(newObjects, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__OBJECTS,
					newObjects,
					newObjects));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Interactions getInteractions() {
		return interactions;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetInteractions(Interactions newInteractions, NotificationChain msgs) {
		Interactions oldInteractions = interactions;
		interactions = newInteractions;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__INTERACTIONS,
					oldInteractions,
					newInteractions);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setInteractions(Interactions newInteractions) {
		if (newInteractions != interactions) {
			NotificationChain msgs = null;
			if (interactions != null)
				msgs = ((InternalEObject) interactions).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.OBJECT_MODEL__INTERACTIONS, null, msgs);
			if (newInteractions != null)
				msgs = ((InternalEObject) newInteractions).eInverseAdd(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.OBJECT_MODEL__INTERACTIONS, null, msgs);
			msgs = basicSetInteractions(newInteractions, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__INTERACTIONS,
					newInteractions,
					newInteractions));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Dimensions getDimensions() {
		return dimensions;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetDimensions(Dimensions newDimensions, NotificationChain msgs) {
		Dimensions oldDimensions = dimensions;
		dimensions = newDimensions;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__DIMENSIONS,
					oldDimensions,
					newDimensions);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setDimensions(Dimensions newDimensions) {
		if (newDimensions != dimensions) {
			NotificationChain msgs = null;
			if (dimensions != null)
				msgs = ((InternalEObject) dimensions).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.OBJECT_MODEL__DIMENSIONS, null, msgs);
			if (newDimensions != null)
				msgs = ((InternalEObject) newDimensions).eInverseAdd(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.OBJECT_MODEL__DIMENSIONS, null, msgs);
			msgs = basicSetDimensions(newDimensions, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__DIMENSIONS,
					newDimensions,
					newDimensions));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Time getTime() {
		return time;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetTime(Time newTime, NotificationChain msgs) {
		Time oldTime = time;
		time = newTime;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__TIME,
					oldTime,
					newTime);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setTime(Time newTime) {
		if (newTime != time) {
			NotificationChain msgs = null;
			if (time != null)
				msgs = ((InternalEObject) time).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.OBJECT_MODEL__TIME, null, msgs);
			if (newTime != null)
				msgs = ((InternalEObject) newTime).eInverseAdd(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.OBJECT_MODEL__TIME, null, msgs);
			msgs = basicSetTime(newTime, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OmtPackage.OBJECT_MODEL__TIME, newTime, newTime));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Tags getTags() {
		return tags;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetTags(Tags newTags, NotificationChain msgs) {
		Tags oldTags = tags;
		tags = newTags;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__TAGS,
					oldTags,
					newTags);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setTags(Tags newTags) {
		if (newTags != tags) {
			NotificationChain msgs = null;
			if (tags != null)
				msgs = ((InternalEObject) tags).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.OBJECT_MODEL__TAGS, null, msgs);
			if (newTags != null)
				msgs = ((InternalEObject) newTags).eInverseAdd(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.OBJECT_MODEL__TAGS, null, msgs);
			msgs = basicSetTags(newTags, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OmtPackage.OBJECT_MODEL__TAGS, newTags, newTags));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Synchronizations getSynchronizations() {
		return synchronizations;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetSynchronizations(Synchronizations newSynchronizations, NotificationChain msgs) {
		Synchronizations oldSynchronizations = synchronizations;
		synchronizations = newSynchronizations;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__SYNCHRONIZATIONS,
					oldSynchronizations,
					newSynchronizations);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setSynchronizations(Synchronizations newSynchronizations) {
		if (newSynchronizations != synchronizations) {
			NotificationChain msgs = null;
			if (synchronizations != null)
				msgs = ((InternalEObject) synchronizations).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.OBJECT_MODEL__SYNCHRONIZATIONS, null, msgs);
			if (newSynchronizations != null)
				msgs = ((InternalEObject) newSynchronizations).eInverseAdd(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.OBJECT_MODEL__SYNCHRONIZATIONS, null, msgs);
			msgs = basicSetSynchronizations(newSynchronizations, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__SYNCHRONIZATIONS,
					newSynchronizations,
					newSynchronizations));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Transportations getTransportations() {
		return transportations;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetTransportations(Transportations newTransportations, NotificationChain msgs) {
		Transportations oldTransportations = transportations;
		transportations = newTransportations;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__TRANSPORTATIONS,
					oldTransportations,
					newTransportations);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setTransportations(Transportations newTransportations) {
		if (newTransportations != transportations) {
			NotificationChain msgs = null;
			if (transportations != null)
				msgs = ((InternalEObject) transportations).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.OBJECT_MODEL__TRANSPORTATIONS, null, msgs);
			if (newTransportations != null)
				msgs = ((InternalEObject) newTransportations).eInverseAdd(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.OBJECT_MODEL__TRANSPORTATIONS, null, msgs);
			msgs = basicSetTransportations(newTransportations, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__TRANSPORTATIONS,
					newTransportations,
					newTransportations));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Switches getSwitches() {
		return switches;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetSwitches(Switches newSwitches, NotificationChain msgs) {
		Switches oldSwitches = switches;
		switches = newSwitches;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__SWITCHES,
					oldSwitches,
					newSwitches);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setSwitches(Switches newSwitches) {
		if (newSwitches != switches) {
			NotificationChain msgs = null;
			if (switches != null)
				msgs = ((InternalEObject) switches).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.OBJECT_MODEL__SWITCHES, null, msgs);
			if (newSwitches != null)
				msgs = ((InternalEObject) newSwitches).eInverseAdd(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.OBJECT_MODEL__SWITCHES, null, msgs);
			msgs = basicSetSwitches(newSwitches, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__SWITCHES,
					newSwitches,
					newSwitches));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public DataTypes getDataTypes() {
		return dataTypes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetDataTypes(DataTypes newDataTypes, NotificationChain msgs) {
		DataTypes oldDataTypes = dataTypes;
		dataTypes = newDataTypes;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__DATA_TYPES,
					oldDataTypes,
					newDataTypes);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setDataTypes(DataTypes newDataTypes) {
		if (newDataTypes != dataTypes) {
			NotificationChain msgs = null;
			if (dataTypes != null)
				msgs = ((InternalEObject) dataTypes).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.OBJECT_MODEL__DATA_TYPES, null, msgs);
			if (newDataTypes != null)
				msgs = ((InternalEObject) newDataTypes).eInverseAdd(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.OBJECT_MODEL__DATA_TYPES, null, msgs);
			msgs = basicSetDataTypes(newDataTypes, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__DATA_TYPES,
					newDataTypes,
					newDataTypes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Notes getNotes() {
		return notes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetNotes(Notes newNotes, NotificationChain msgs) {
		Notes oldNotes = notes;
		notes = newNotes;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__NOTES,
					oldNotes,
					newNotes);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setNotes(Notes newNotes) {
		if (newNotes != notes) {
			NotificationChain msgs = null;
			if (notes != null)
				msgs = ((InternalEObject) notes).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.OBJECT_MODEL__NOTES, null, msgs);
			if (newNotes != null)
				msgs = ((InternalEObject) newNotes).eInverseAdd(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.OBJECT_MODEL__NOTES, null, msgs);
			msgs = basicSetNotes(newNotes, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OmtPackage.OBJECT_MODEL__NOTES, newNotes, newNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getAppDomain() {
		return appDomain;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setAppDomain(Object newAppDomain) {
		Object oldAppDomain = appDomain;
		appDomain = newAppDomain;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__APP_DOMAIN,
					oldAppDomain,
					appDomain));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getAppDomainNotes() {
		return appDomainNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setAppDomainNotes(List newAppDomainNotes) {
		List oldAppDomainNotes = appDomainNotes;
		appDomainNotes = newAppDomainNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__APP_DOMAIN_NOTES,
					oldAppDomainNotes,
					appDomainNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getDate() {
		return date;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setDate(Object newDate) {
		Object oldDate = date;
		date = newDate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OmtPackage.OBJECT_MODEL__DATE, oldDate, date));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getDateNotes() {
		return dateNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setDateNotes(List newDateNotes) {
		List oldDateNotes = dateNotes;
		dateNotes = newDateNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__DATE_NOTES,
					oldDateNotes,
					dateNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public DTDVersionEnum getDTDversion() {
		return dTDversion;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDTDversion(DTDVersionEnum newDTDversion) {
		DTDVersionEnum oldDTDversion = dTDversion;
		dTDversion = newDTDversion == null ? DT_DVERSION_EDEFAULT : newDTDversion;
		boolean oldDTDversionESet = dTDversionESet;
		dTDversionESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__DT_DVERSION,
					oldDTDversion,
					dTDversion,
					!oldDTDversionESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetDTDversion() {
		DTDVersionEnum oldDTDversion = dTDversion;
		boolean oldDTDversionESet = dTDversionESet;
		dTDversion = DT_DVERSION_EDEFAULT;
		dTDversionESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.UNSET,
					OmtPackage.OBJECT_MODEL__DT_DVERSION,
					oldDTDversion,
					DT_DVERSION_EDEFAULT,
					oldDTDversionESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetDTDversion() {
		return dTDversionESet;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(Object newName) {
		Object oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OmtPackage.OBJECT_MODEL__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getNameNotes() {
		return nameNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setNameNotes(List newNameNotes) {
		List oldNameNotes = nameNotes;
		nameNotes = newNameNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__NAME_NOTES,
					oldNameNotes,
					nameNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getOther() {
		return other;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setOther(Object newOther) {
		Object oldOther = other;
		other = newOther;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OmtPackage.OBJECT_MODEL__OTHER, oldOther, other));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getOtherNotes() {
		return otherNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setOtherNotes(List newOtherNotes) {
		List oldOtherNotes = otherNotes;
		otherNotes = newOtherNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__OTHER_NOTES,
					oldOtherNotes,
					otherNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getPocEmail() {
		return pocEmail;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setPocEmail(Object newPocEmail) {
		Object oldPocEmail = pocEmail;
		pocEmail = newPocEmail;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__POC_EMAIL,
					oldPocEmail,
					pocEmail));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getPocEmailNotes() {
		return pocEmailNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setPocEmailNotes(List newPocEmailNotes) {
		List oldPocEmailNotes = pocEmailNotes;
		pocEmailNotes = newPocEmailNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__POC_EMAIL_NOTES,
					oldPocEmailNotes,
					pocEmailNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getPocName() {
		return pocName;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setPocName(Object newPocName) {
		Object oldPocName = pocName;
		pocName = newPocName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__POC_NAME,
					oldPocName,
					pocName));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getPocNameNotes() {
		return pocNameNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setPocNameNotes(List newPocNameNotes) {
		List oldPocNameNotes = pocNameNotes;
		pocNameNotes = newPocNameNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__POC_NAME_NOTES,
					oldPocNameNotes,
					pocNameNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getPocOrg() {
		return pocOrg;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setPocOrg(Object newPocOrg) {
		Object oldPocOrg = pocOrg;
		pocOrg = newPocOrg;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OmtPackage.OBJECT_MODEL__POC_ORG, oldPocOrg, pocOrg));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getPocOrgNotes() {
		return pocOrgNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setPocOrgNotes(List newPocOrgNotes) {
		List oldPocOrgNotes = pocOrgNotes;
		pocOrgNotes = newPocOrgNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__POC_ORG_NOTES,
					oldPocOrgNotes,
					pocOrgNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getPocPhone() {
		return pocPhone;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setPocPhone(Object newPocPhone) {
		Object oldPocPhone = pocPhone;
		pocPhone = newPocPhone;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__POC_PHONE,
					oldPocPhone,
					pocPhone));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getPocPhoneNotes() {
		return pocPhoneNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setPocPhoneNotes(List newPocPhoneNotes) {
		List oldPocPhoneNotes = pocPhoneNotes;
		pocPhoneNotes = newPocPhoneNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__POC_PHONE_NOTES,
					oldPocPhoneNotes,
					pocPhoneNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getPurpose() {
		return purpose;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setPurpose(Object newPurpose) {
		Object oldPurpose = purpose;
		purpose = newPurpose;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OmtPackage.OBJECT_MODEL__PURPOSE, oldPurpose, purpose));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getPurposeNotes() {
		return purposeNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setPurposeNotes(List newPurposeNotes) {
		List oldPurposeNotes = purposeNotes;
		purposeNotes = newPurposeNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__PURPOSE_NOTES,
					oldPurposeNotes,
					purposeNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getReferences() {
		return references;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setReferences(Object newReferences) {
		Object oldReferences = references;
		references = newReferences;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__REFERENCES,
					oldReferences,
					references));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getReferencesNotes() {
		return referencesNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setReferencesNotes(List newReferencesNotes) {
		List oldReferencesNotes = referencesNotes;
		referencesNotes = newReferencesNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__REFERENCES_NOTES,
					oldReferencesNotes,
					referencesNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getSponsor() {
		return sponsor;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setSponsor(Object newSponsor) {
		Object oldSponsor = sponsor;
		sponsor = newSponsor;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OmtPackage.OBJECT_MODEL__SPONSOR, oldSponsor, sponsor));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getSponsorNotes() {
		return sponsorNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setSponsorNotes(List newSponsorNotes) {
		List oldSponsorNotes = sponsorNotes;
		sponsorNotes = newSponsorNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__SPONSOR_NOTES,
					oldSponsorNotes,
					sponsorNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public ObjectModelTypeEnum getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(ObjectModelTypeEnum newType) {
		ObjectModelTypeEnum oldType = type;
		type = newType == null ? TYPE_EDEFAULT : newType;
		boolean oldTypeESet = typeESet;
		typeESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__TYPE,
					oldType,
					type,
					!oldTypeESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetType() {
		ObjectModelTypeEnum oldType = type;
		boolean oldTypeESet = typeESet;
		type = TYPE_EDEFAULT;
		typeESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.UNSET,
					OmtPackage.OBJECT_MODEL__TYPE,
					oldType,
					TYPE_EDEFAULT,
					oldTypeESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetType() {
		return typeESet;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getTypeNotes() {
		return typeNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setTypeNotes(List newTypeNotes) {
		List oldTypeNotes = typeNotes;
		typeNotes = newTypeNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__TYPE_NOTES,
					oldTypeNotes,
					typeNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getVersion() {
		return version;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setVersion(Object newVersion) {
		Object oldVersion = version;
		version = newVersion;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OmtPackage.OBJECT_MODEL__VERSION, oldVersion, version));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getVersionNotes() {
		return versionNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setVersionNotes(List newVersionNotes) {
		List oldVersionNotes = versionNotes;
		versionNotes = newVersionNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_MODEL__VERSION_NOTES,
					oldVersionNotes,
					versionNotes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case OmtPackage.OBJECT_MODEL__OBJECTS:
			return basicSetObjects(null, msgs);
		case OmtPackage.OBJECT_MODEL__INTERACTIONS:
			return basicSetInteractions(null, msgs);
		case OmtPackage.OBJECT_MODEL__DIMENSIONS:
			return basicSetDimensions(null, msgs);
		case OmtPackage.OBJECT_MODEL__TIME:
			return basicSetTime(null, msgs);
		case OmtPackage.OBJECT_MODEL__TAGS:
			return basicSetTags(null, msgs);
		case OmtPackage.OBJECT_MODEL__SYNCHRONIZATIONS:
			return basicSetSynchronizations(null, msgs);
		case OmtPackage.OBJECT_MODEL__TRANSPORTATIONS:
			return basicSetTransportations(null, msgs);
		case OmtPackage.OBJECT_MODEL__SWITCHES:
			return basicSetSwitches(null, msgs);
		case OmtPackage.OBJECT_MODEL__DATA_TYPES:
			return basicSetDataTypes(null, msgs);
		case OmtPackage.OBJECT_MODEL__NOTES:
			return basicSetNotes(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case OmtPackage.OBJECT_MODEL__OBJECTS:
			return getObjects();
		case OmtPackage.OBJECT_MODEL__INTERACTIONS:
			return getInteractions();
		case OmtPackage.OBJECT_MODEL__DIMENSIONS:
			return getDimensions();
		case OmtPackage.OBJECT_MODEL__TIME:
			return getTime();
		case OmtPackage.OBJECT_MODEL__TAGS:
			return getTags();
		case OmtPackage.OBJECT_MODEL__SYNCHRONIZATIONS:
			return getSynchronizations();
		case OmtPackage.OBJECT_MODEL__TRANSPORTATIONS:
			return getTransportations();
		case OmtPackage.OBJECT_MODEL__SWITCHES:
			return getSwitches();
		case OmtPackage.OBJECT_MODEL__DATA_TYPES:
			return getDataTypes();
		case OmtPackage.OBJECT_MODEL__NOTES:
			return getNotes();
		case OmtPackage.OBJECT_MODEL__APP_DOMAIN:
			return getAppDomain();
		case OmtPackage.OBJECT_MODEL__APP_DOMAIN_NOTES:
			return getAppDomainNotes();
		case OmtPackage.OBJECT_MODEL__DATE:
			return getDate();
		case OmtPackage.OBJECT_MODEL__DATE_NOTES:
			return getDateNotes();
		case OmtPackage.OBJECT_MODEL__DT_DVERSION:
			return getDTDversion();
		case OmtPackage.OBJECT_MODEL__NAME:
			return getName();
		case OmtPackage.OBJECT_MODEL__NAME_NOTES:
			return getNameNotes();
		case OmtPackage.OBJECT_MODEL__OTHER:
			return getOther();
		case OmtPackage.OBJECT_MODEL__OTHER_NOTES:
			return getOtherNotes();
		case OmtPackage.OBJECT_MODEL__POC_EMAIL:
			return getPocEmail();
		case OmtPackage.OBJECT_MODEL__POC_EMAIL_NOTES:
			return getPocEmailNotes();
		case OmtPackage.OBJECT_MODEL__POC_NAME:
			return getPocName();
		case OmtPackage.OBJECT_MODEL__POC_NAME_NOTES:
			return getPocNameNotes();
		case OmtPackage.OBJECT_MODEL__POC_ORG:
			return getPocOrg();
		case OmtPackage.OBJECT_MODEL__POC_ORG_NOTES:
			return getPocOrgNotes();
		case OmtPackage.OBJECT_MODEL__POC_PHONE:
			return getPocPhone();
		case OmtPackage.OBJECT_MODEL__POC_PHONE_NOTES:
			return getPocPhoneNotes();
		case OmtPackage.OBJECT_MODEL__PURPOSE:
			return getPurpose();
		case OmtPackage.OBJECT_MODEL__PURPOSE_NOTES:
			return getPurposeNotes();
		case OmtPackage.OBJECT_MODEL__REFERENCES:
			return getReferences();
		case OmtPackage.OBJECT_MODEL__REFERENCES_NOTES:
			return getReferencesNotes();
		case OmtPackage.OBJECT_MODEL__SPONSOR:
			return getSponsor();
		case OmtPackage.OBJECT_MODEL__SPONSOR_NOTES:
			return getSponsorNotes();
		case OmtPackage.OBJECT_MODEL__TYPE:
			return getType();
		case OmtPackage.OBJECT_MODEL__TYPE_NOTES:
			return getTypeNotes();
		case OmtPackage.OBJECT_MODEL__VERSION:
			return getVersion();
		case OmtPackage.OBJECT_MODEL__VERSION_NOTES:
			return getVersionNotes();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case OmtPackage.OBJECT_MODEL__OBJECTS:
			setObjects((Objects) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__INTERACTIONS:
			setInteractions((Interactions) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__DIMENSIONS:
			setDimensions((Dimensions) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__TIME:
			setTime((Time) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__TAGS:
			setTags((Tags) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__SYNCHRONIZATIONS:
			setSynchronizations((Synchronizations) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__TRANSPORTATIONS:
			setTransportations((Transportations) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__SWITCHES:
			setSwitches((Switches) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__DATA_TYPES:
			setDataTypes((DataTypes) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__NOTES:
			setNotes((Notes) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__APP_DOMAIN:
			setAppDomain((Object) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__APP_DOMAIN_NOTES:
			setAppDomainNotes((List) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__DATE:
			setDate((Object) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__DATE_NOTES:
			setDateNotes((List) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__DT_DVERSION:
			setDTDversion((DTDVersionEnum) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__NAME:
			setName((Object) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__NAME_NOTES:
			setNameNotes((List) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__OTHER:
			setOther((Object) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__OTHER_NOTES:
			setOtherNotes((List) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__POC_EMAIL:
			setPocEmail((Object) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__POC_EMAIL_NOTES:
			setPocEmailNotes((List) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__POC_NAME:
			setPocName((Object) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__POC_NAME_NOTES:
			setPocNameNotes((List) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__POC_ORG:
			setPocOrg((Object) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__POC_ORG_NOTES:
			setPocOrgNotes((List) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__POC_PHONE:
			setPocPhone((Object) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__POC_PHONE_NOTES:
			setPocPhoneNotes((List) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__PURPOSE:
			setPurpose((Object) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__PURPOSE_NOTES:
			setPurposeNotes((List) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__REFERENCES:
			setReferences((Object) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__REFERENCES_NOTES:
			setReferencesNotes((List) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__SPONSOR:
			setSponsor((Object) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__SPONSOR_NOTES:
			setSponsorNotes((List) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__TYPE:
			setType((ObjectModelTypeEnum) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__TYPE_NOTES:
			setTypeNotes((List) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__VERSION:
			setVersion((Object) newValue);
			return;
		case OmtPackage.OBJECT_MODEL__VERSION_NOTES:
			setVersionNotes((List) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
		case OmtPackage.OBJECT_MODEL__OBJECTS:
			setObjects((Objects) null);
			return;
		case OmtPackage.OBJECT_MODEL__INTERACTIONS:
			setInteractions((Interactions) null);
			return;
		case OmtPackage.OBJECT_MODEL__DIMENSIONS:
			setDimensions((Dimensions) null);
			return;
		case OmtPackage.OBJECT_MODEL__TIME:
			setTime((Time) null);
			return;
		case OmtPackage.OBJECT_MODEL__TAGS:
			setTags((Tags) null);
			return;
		case OmtPackage.OBJECT_MODEL__SYNCHRONIZATIONS:
			setSynchronizations((Synchronizations) null);
			return;
		case OmtPackage.OBJECT_MODEL__TRANSPORTATIONS:
			setTransportations((Transportations) null);
			return;
		case OmtPackage.OBJECT_MODEL__SWITCHES:
			setSwitches((Switches) null);
			return;
		case OmtPackage.OBJECT_MODEL__DATA_TYPES:
			setDataTypes((DataTypes) null);
			return;
		case OmtPackage.OBJECT_MODEL__NOTES:
			setNotes((Notes) null);
			return;
		case OmtPackage.OBJECT_MODEL__APP_DOMAIN:
			setAppDomain(APP_DOMAIN_EDEFAULT);
			return;
		case OmtPackage.OBJECT_MODEL__APP_DOMAIN_NOTES:
			setAppDomainNotes(APP_DOMAIN_NOTES_EDEFAULT);
			return;
		case OmtPackage.OBJECT_MODEL__DATE:
			setDate(DATE_EDEFAULT);
			return;
		case OmtPackage.OBJECT_MODEL__DATE_NOTES:
			setDateNotes(DATE_NOTES_EDEFAULT);
			return;
		case OmtPackage.OBJECT_MODEL__DT_DVERSION:
			unsetDTDversion();
			return;
		case OmtPackage.OBJECT_MODEL__NAME:
			setName(NAME_EDEFAULT);
			return;
		case OmtPackage.OBJECT_MODEL__NAME_NOTES:
			setNameNotes(NAME_NOTES_EDEFAULT);
			return;
		case OmtPackage.OBJECT_MODEL__OTHER:
			setOther(OTHER_EDEFAULT);
			return;
		case OmtPackage.OBJECT_MODEL__OTHER_NOTES:
			setOtherNotes(OTHER_NOTES_EDEFAULT);
			return;
		case OmtPackage.OBJECT_MODEL__POC_EMAIL:
			setPocEmail(POC_EMAIL_EDEFAULT);
			return;
		case OmtPackage.OBJECT_MODEL__POC_EMAIL_NOTES:
			setPocEmailNotes(POC_EMAIL_NOTES_EDEFAULT);
			return;
		case OmtPackage.OBJECT_MODEL__POC_NAME:
			setPocName(POC_NAME_EDEFAULT);
			return;
		case OmtPackage.OBJECT_MODEL__POC_NAME_NOTES:
			setPocNameNotes(POC_NAME_NOTES_EDEFAULT);
			return;
		case OmtPackage.OBJECT_MODEL__POC_ORG:
			setPocOrg(POC_ORG_EDEFAULT);
			return;
		case OmtPackage.OBJECT_MODEL__POC_ORG_NOTES:
			setPocOrgNotes(POC_ORG_NOTES_EDEFAULT);
			return;
		case OmtPackage.OBJECT_MODEL__POC_PHONE:
			setPocPhone(POC_PHONE_EDEFAULT);
			return;
		case OmtPackage.OBJECT_MODEL__POC_PHONE_NOTES:
			setPocPhoneNotes(POC_PHONE_NOTES_EDEFAULT);
			return;
		case OmtPackage.OBJECT_MODEL__PURPOSE:
			setPurpose(PURPOSE_EDEFAULT);
			return;
		case OmtPackage.OBJECT_MODEL__PURPOSE_NOTES:
			setPurposeNotes(PURPOSE_NOTES_EDEFAULT);
			return;
		case OmtPackage.OBJECT_MODEL__REFERENCES:
			setReferences(REFERENCES_EDEFAULT);
			return;
		case OmtPackage.OBJECT_MODEL__REFERENCES_NOTES:
			setReferencesNotes(REFERENCES_NOTES_EDEFAULT);
			return;
		case OmtPackage.OBJECT_MODEL__SPONSOR:
			setSponsor(SPONSOR_EDEFAULT);
			return;
		case OmtPackage.OBJECT_MODEL__SPONSOR_NOTES:
			setSponsorNotes(SPONSOR_NOTES_EDEFAULT);
			return;
		case OmtPackage.OBJECT_MODEL__TYPE:
			unsetType();
			return;
		case OmtPackage.OBJECT_MODEL__TYPE_NOTES:
			setTypeNotes(TYPE_NOTES_EDEFAULT);
			return;
		case OmtPackage.OBJECT_MODEL__VERSION:
			setVersion(VERSION_EDEFAULT);
			return;
		case OmtPackage.OBJECT_MODEL__VERSION_NOTES:
			setVersionNotes(VERSION_NOTES_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case OmtPackage.OBJECT_MODEL__OBJECTS:
			return objects != null;
		case OmtPackage.OBJECT_MODEL__INTERACTIONS:
			return interactions != null;
		case OmtPackage.OBJECT_MODEL__DIMENSIONS:
			return dimensions != null;
		case OmtPackage.OBJECT_MODEL__TIME:
			return time != null;
		case OmtPackage.OBJECT_MODEL__TAGS:
			return tags != null;
		case OmtPackage.OBJECT_MODEL__SYNCHRONIZATIONS:
			return synchronizations != null;
		case OmtPackage.OBJECT_MODEL__TRANSPORTATIONS:
			return transportations != null;
		case OmtPackage.OBJECT_MODEL__SWITCHES:
			return switches != null;
		case OmtPackage.OBJECT_MODEL__DATA_TYPES:
			return dataTypes != null;
		case OmtPackage.OBJECT_MODEL__NOTES:
			return notes != null;
		case OmtPackage.OBJECT_MODEL__APP_DOMAIN:
			return APP_DOMAIN_EDEFAULT == null ? appDomain != null : !APP_DOMAIN_EDEFAULT.equals(appDomain);
		case OmtPackage.OBJECT_MODEL__APP_DOMAIN_NOTES:
			return APP_DOMAIN_NOTES_EDEFAULT == null ? appDomainNotes != null : !APP_DOMAIN_NOTES_EDEFAULT
					.equals(appDomainNotes);
		case OmtPackage.OBJECT_MODEL__DATE:
			return DATE_EDEFAULT == null ? date != null : !DATE_EDEFAULT.equals(date);
		case OmtPackage.OBJECT_MODEL__DATE_NOTES:
			return DATE_NOTES_EDEFAULT == null ? dateNotes != null : !DATE_NOTES_EDEFAULT.equals(dateNotes);
		case OmtPackage.OBJECT_MODEL__DT_DVERSION:
			return isSetDTDversion();
		case OmtPackage.OBJECT_MODEL__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case OmtPackage.OBJECT_MODEL__NAME_NOTES:
			return NAME_NOTES_EDEFAULT == null ? nameNotes != null : !NAME_NOTES_EDEFAULT.equals(nameNotes);
		case OmtPackage.OBJECT_MODEL__OTHER:
			return OTHER_EDEFAULT == null ? other != null : !OTHER_EDEFAULT.equals(other);
		case OmtPackage.OBJECT_MODEL__OTHER_NOTES:
			return OTHER_NOTES_EDEFAULT == null ? otherNotes != null : !OTHER_NOTES_EDEFAULT.equals(otherNotes);
		case OmtPackage.OBJECT_MODEL__POC_EMAIL:
			return POC_EMAIL_EDEFAULT == null ? pocEmail != null : !POC_EMAIL_EDEFAULT.equals(pocEmail);
		case OmtPackage.OBJECT_MODEL__POC_EMAIL_NOTES:
			return POC_EMAIL_NOTES_EDEFAULT == null ? pocEmailNotes != null : !POC_EMAIL_NOTES_EDEFAULT
					.equals(pocEmailNotes);
		case OmtPackage.OBJECT_MODEL__POC_NAME:
			return POC_NAME_EDEFAULT == null ? pocName != null : !POC_NAME_EDEFAULT.equals(pocName);
		case OmtPackage.OBJECT_MODEL__POC_NAME_NOTES:
			return POC_NAME_NOTES_EDEFAULT == null ? pocNameNotes != null : !POC_NAME_NOTES_EDEFAULT
					.equals(pocNameNotes);
		case OmtPackage.OBJECT_MODEL__POC_ORG:
			return POC_ORG_EDEFAULT == null ? pocOrg != null : !POC_ORG_EDEFAULT.equals(pocOrg);
		case OmtPackage.OBJECT_MODEL__POC_ORG_NOTES:
			return POC_ORG_NOTES_EDEFAULT == null ? pocOrgNotes != null : !POC_ORG_NOTES_EDEFAULT.equals(pocOrgNotes);
		case OmtPackage.OBJECT_MODEL__POC_PHONE:
			return POC_PHONE_EDEFAULT == null ? pocPhone != null : !POC_PHONE_EDEFAULT.equals(pocPhone);
		case OmtPackage.OBJECT_MODEL__POC_PHONE_NOTES:
			return POC_PHONE_NOTES_EDEFAULT == null ? pocPhoneNotes != null : !POC_PHONE_NOTES_EDEFAULT
					.equals(pocPhoneNotes);
		case OmtPackage.OBJECT_MODEL__PURPOSE:
			return PURPOSE_EDEFAULT == null ? purpose != null : !PURPOSE_EDEFAULT.equals(purpose);
		case OmtPackage.OBJECT_MODEL__PURPOSE_NOTES:
			return PURPOSE_NOTES_EDEFAULT == null ? purposeNotes != null : !PURPOSE_NOTES_EDEFAULT.equals(purposeNotes);
		case OmtPackage.OBJECT_MODEL__REFERENCES:
			return REFERENCES_EDEFAULT == null ? references != null : !REFERENCES_EDEFAULT.equals(references);
		case OmtPackage.OBJECT_MODEL__REFERENCES_NOTES:
			return REFERENCES_NOTES_EDEFAULT == null ? referencesNotes != null : !REFERENCES_NOTES_EDEFAULT
					.equals(referencesNotes);
		case OmtPackage.OBJECT_MODEL__SPONSOR:
			return SPONSOR_EDEFAULT == null ? sponsor != null : !SPONSOR_EDEFAULT.equals(sponsor);
		case OmtPackage.OBJECT_MODEL__SPONSOR_NOTES:
			return SPONSOR_NOTES_EDEFAULT == null ? sponsorNotes != null : !SPONSOR_NOTES_EDEFAULT.equals(sponsorNotes);
		case OmtPackage.OBJECT_MODEL__TYPE:
			return isSetType();
		case OmtPackage.OBJECT_MODEL__TYPE_NOTES:
			return TYPE_NOTES_EDEFAULT == null ? typeNotes != null : !TYPE_NOTES_EDEFAULT.equals(typeNotes);
		case OmtPackage.OBJECT_MODEL__VERSION:
			return VERSION_EDEFAULT == null ? version != null : !VERSION_EDEFAULT.equals(version);
		case OmtPackage.OBJECT_MODEL__VERSION_NOTES:
			return VERSION_NOTES_EDEFAULT == null ? versionNotes != null : !VERSION_NOTES_EDEFAULT.equals(versionNotes);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (appDomain: ");
		result.append(appDomain);
		result.append(", appDomainNotes: ");
		result.append(appDomainNotes);
		result.append(", date: ");
		result.append(date);
		result.append(", dateNotes: ");
		result.append(dateNotes);
		result.append(", dTDversion: ");
		if (dTDversionESet)
			result.append(dTDversion);
		else
			result.append("<unset>");
		result.append(", name: ");
		result.append(name);
		result.append(", nameNotes: ");
		result.append(nameNotes);
		result.append(", other: ");
		result.append(other);
		result.append(", otherNotes: ");
		result.append(otherNotes);
		result.append(", pocEmail: ");
		result.append(pocEmail);
		result.append(", pocEmailNotes: ");
		result.append(pocEmailNotes);
		result.append(", pocName: ");
		result.append(pocName);
		result.append(", pocNameNotes: ");
		result.append(pocNameNotes);
		result.append(", pocOrg: ");
		result.append(pocOrg);
		result.append(", pocOrgNotes: ");
		result.append(pocOrgNotes);
		result.append(", pocPhone: ");
		result.append(pocPhone);
		result.append(", pocPhoneNotes: ");
		result.append(pocPhoneNotes);
		result.append(", purpose: ");
		result.append(purpose);
		result.append(", purposeNotes: ");
		result.append(purposeNotes);
		result.append(", references: ");
		result.append(references);
		result.append(", referencesNotes: ");
		result.append(referencesNotes);
		result.append(", sponsor: ");
		result.append(sponsor);
		result.append(", sponsorNotes: ");
		result.append(sponsorNotes);
		result.append(", type: ");
		if (typeESet)
			result.append(type);
		else
			result.append("<unset>");
		result.append(", typeNotes: ");
		result.append(typeNotes);
		result.append(", version: ");
		result.append(version);
		result.append(", versionNotes: ");
		result.append(versionNotes);
		result.append(')');
		return result.toString();
	}

} // ObjectModelImpl
