/**
 * 
 */
package org.eodisp.hla.common.handles;


import hla.rti1516.ObjectInstanceHandle;

/**
 * @author ibirrer
 */
public class ObjectInstanceHandleImpl extends HandleImpl implements
		ObjectInstanceHandle {

	private static final long serialVersionUID = 1L;

	/**
	 * {@inheritDoc}
	 */
	public ObjectInstanceHandleImpl(int id) {
		super(id);
	}	
}
