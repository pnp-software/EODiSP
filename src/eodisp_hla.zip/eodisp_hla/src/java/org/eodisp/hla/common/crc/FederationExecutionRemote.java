/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.hla.common.crc;

import hla.rti1516.*;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.eodisp.hla.common.lrc.LrcRemote;

/**
 * Remote interface of a federation execution.
 * 
 * @author ibirrer
 * @version $Id:$
 */
public interface FederationExecutionRemote extends Remote {

	/**
	 * Implements HLA service 4.6 (See IEEE Std 1516.1-2000).
	 * 
	 * Resign from this federation execution
	 * 
	 * @param resignAction
	 *            unused
	 * @param federateHandle
	 *            the handle of the federate that shall be resigned
	 * @throws OwnershipAcquisitionPending
	 *             not implemented
	 * @throws FederateOwnsAttributes
	 *             thrown if the federate still owns attributes
	 * @throws FederateNotExecutionMember
	 *             if the federate identified by the given handle is not
	 *             currently joined to this federation execution
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 */
	void resign(ResignAction resignAction, FederateHandle federateHandle) throws OwnershipAcquisitionPending,
			FederateOwnsAttributes, FederateNotExecutionMember, RemoteException;

	/**
	 * Implements HLA service 4.6 (See IEEE Std 1516.1-2000).
	 * 
	 * Registers a new synchronization point for this federation execution
	 * 
	 * @param synchronizationPointLabel
	 *            the label of the new synchronization point
	 * 
	 * @param userSuppliedTag
	 *            user supplied tag
	 * @param handles
	 * @throws SaveInProgress
	 *             no implemented
	 * @throws RestoreInProgress
	 *             not implemented
	 * @throws FederateNotExecutionMember
	 *             if the federate identified by the given handle is not
	 *             currently joined to this federation execution
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 * 
	 * 
	 */
	void registerFederationSynchronizationPoint(String synchronizationPointLabel, byte[] userSuppliedTag,
			FederateHandle askingFederate) throws SaveInProgress, RestoreInProgress, FederateNotExecutionMember,
			RemoteException;

	/**
	 * Implements HLA service 4.6 (See IEEE Std 1516.1-2000).
	 * 
	 * Registers a new synchronization point for this federation execution
	 * 
	 * @param synchronizationPointLabel
	 *            the label of the new synchronization point
	 * 
	 * @param userSuppliedTag
	 *            user supplied tag
	 * @param handles
	 * @throws SaveInProgress
	 *             no implemented
	 * @throws RestoreInProgress
	 *             not implemented
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 * @throws FederateNotExecutionMember
	 * 
	 */
	void registerFederationSynchronizationPoint(String synchronizationPointLabel, byte[] userSuppliedTag,
			FederateHandle[] handles, FederateHandle askingFederate) throws SaveInProgress, RestoreInProgress,
			FederateNotExecutionMember, RemoteException;

	/**
	 * Implements HLA service 4.9 (See IEEE Std 1516.1-2000).
	 * 
	 * Tells this federation execution that the given federate has achieved the
	 * synchronization point with the label
	 * <code>synchronizationPointLabel</code>.
	 * 
	 * @param synchronizationPointLabel
	 *            the label of the synchronization to be achieved
	 * @param federateHandle
	 *            the handle of the federate that achieved the synchronization
	 *            point
	 * @throws SynchronizationPointLabelNotAnnounced
	 *             the synchronization point has never been announced, i.e.
	 *             {@link #registerFederationSynchronizationPoint(String, byte[])}
	 *             was not called with the the
	 *             <code>synchronizationPointLabel</code> given here.
	 * 
	 * @throws SaveInProgress
	 *             no implemented
	 * @throws RestoreInProgress
	 *             not implemented
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 */
	public void synchronizationPointAchieved(String synchronizationPointLabel, FederateHandle federateHandle)
			throws SynchronizationPointLabelNotAnnounced, SaveInProgress, RestoreInProgress, RemoteException;

	/**
	 * Implements HLA service 10.2 (See IEEE Std 1516.1-2000).
	 * 
	 * Returns the object class handle of the object class with the given name.
	 * 
	 * @param theName
	 *            the fully qualified name of the object class.
	 * @return the object class handle of the object class with the given name
	 * @throws NameNotFound
	 *             the FOM does not contain a class with this fully qualified
	 *             name
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 */
	public ObjectClassHandle getObjectClassHandle(String theName) throws NameNotFound, RemoteException;

	/**
	 * Implements HLA service 10.3 (See IEEE Std 1516.1-2000).
	 * 
	 * Returns the fully qualified name of this object class. See section 10.1.1
	 * in IEEE 1516.1-2000. Always starts with the string
	 * <code>HLAobjectRoot</code>.
	 * 
	 * @param theHandle
	 *            the object class handle for which the name shall be returned
	 * @return the fully qualified name of the object class identified by the
	 *         given handle
	 * 
	 * @throws ObjectClassNotDefined
	 *             the given object class handle does not identify an object
	 *             class of this federation execution.
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 */
	public String getObjectClassName(ObjectClassHandle theHandle) throws ObjectClassNotDefined, RemoteException;

	/**
	 * Implements HLA service 10.4 (See IEEE Std 1516.1-2000).
	 * 
	 * Returns the attribute handle that is defined in the object class
	 * identified by the given object class handle and which name equals the
	 * given name.
	 * 
	 * @param objectClassHandle
	 *            the object class handle the attribute is defined in
	 * @param theName
	 *            the name of the attribute for which the attribute handle shall
	 *            be returned
	 * @return the attribute handle that is defined in the object class
	 *         identified by the given object class handle and which name equals
	 *         the given name.
	 * @throws NameNotFound
	 *             there is no attribute defined with the given name in the
	 *             object class identified by the given object class handle
	 *             handle.
	 * @throws ObjectClassNotDefined
	 *             the given object class handle does not identify an object
	 *             class of this federation execution.
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 * 
	 */
	public AttributeHandle getAttributeHandle(ObjectClassHandle objectClassHandle, String theName)
			throws ObjectClassNotDefined, NameNotFound, RemoteException;

	/**
	 * Implements HLA service 10.5 (See IEEE Std 1516.1-2000). Returns the name
	 * of the attribute identified by the given object class and attribute
	 * handle.
	 * 
	 * @param whichClass
	 *            the object class
	 * 
	 * @param theHandle
	 *            the handle of the attribute
	 * @return the name of the attribute identified by the given object class
	 *         and attribute handle.
	 * @throws InvalidAttributeHandle
	 *             the given attribute handle is not valid
	 * @throws AttributeNotDefined
	 *             the attribute is not defined for the class identified with
	 *             the given object class handle
	 * @throws ObjectClassNotDefined
	 *             the given object class handle does not identify an object
	 *             class of this federation execution.
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 */
	public String getAttributeName(ObjectClassHandle whichClass, AttributeHandle theHandle)
			throws InvalidAttributeHandle, AttributeNotDefined, ObjectClassNotDefined, RemoteException;

	/**
	 * Implements HLA service 10.6 (See IEEE Std 1516.1-2000).
	 * 
	 * Returns the handle of the interaction class with the given fully
	 * qualified name
	 * 
	 * @param theName
	 *            the fully qualified name of the interaction for which the
	 *            handle shall be returned.
	 * @return the handle of the interaction class with the given fully
	 *         qualified name
	 * @throws NameNotFound
	 *             no interaction class is defined in the FOM with the given
	 *             name
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 */
	public InteractionClassHandle getInteractionClassHandle(String theName) throws NameNotFound, RemoteException;

	/**
	 * Implements HLA service 10.7 (See IEEE Std 1516.1-2000).
	 * 
	 * Returns the name of the interaction class identified by the given handle.
	 * 
	 * @param theHandle
	 *            the interaction class handle for which the name shall be
	 *            returned.
	 * @return the name of the interaction class identified by the given handle
	 * 
	 * @throws InteractionClassNotDefined
	 *             the given interaction class handle is not defined for this
	 *             federation execution
	 * 
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 */
	public String getInteractionClassName(InteractionClassHandle theHandle) throws InteractionClassNotDefined,
			RemoteException;

	/**
	 * Implements HLA service 10.8 (See IEEE Std 1516.1-2000).
	 * 
	 * Returns the parameter handle of the parameter that is defined within the
	 * given interaction class and equals to the given name.
	 * 
	 * @param whichClass
	 *            the interaction class the parameter is defined in
	 * @param theName
	 *            the name of the parameter
	 * @return the parameter handle of the parameter that is defined within the
	 *         given interaction class and equals to the given name.
	 * @throws InteractionClassNotDefined
	 *             the given interaction class handle is not defined for this
	 *             federation execution
	 * @throws NameNotFound
	 *             the interaction class has not defined a parameter with the
	 *             given name
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 */
	public ParameterHandle getParameterHandle(InteractionClassHandle whichClass, String theName) throws NameNotFound,
			InteractionClassNotDefined, RemoteException;

	/**
	 * Implements HLA service 10.9 (See IEEE Std 1516.1-2000). Returns the fully
	 * qualified name of the parameter identified by the given interaction class
	 * handle and parameter handle.
	 * 
	 * @param whichClass
	 *            the interaction class handle containing the parameter
	 * @param theHandle
	 *            the parameter handle for which the name shall be returned
	 * @return the fully qualified name of the parameter identified by the given
	 *         interaction class handle and parameter handle.
	 * 
	 * @throws InvalidParameterHandle
	 *             the parameter has not been defined of is not valid
	 * @throws InteractionParameterNotDefined
	 *             the interaction class identified by the given interaction
	 *             class handle has not defined a parameter with the given
	 *             parameter handle.
	 * @throws InteractionClassNotDefined
	 *             the interaction class has not been defined in this federation
	 *             execution
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 */
	public String getParameterName(InteractionClassHandle whichClass, ParameterHandle theHandle)
			throws InvalidParameterHandle, InteractionParameterNotDefined, InteractionClassNotDefined, RemoteException;

	/**
	 * Implements HLA service 10.10 (See IEEE Std 1516.1-2000).
	 * 
	 * Returns the object instance handle of the object instance that was
	 * registered with the given name.
	 * 
	 * 
	 * @param theName
	 *            the name of the object instance for which the object instance
	 *            handle shall be returned
	 * @return the object instance handle of the object instance that was
	 *         registered with the given name
	 * @throws ObjectInstanceNotKnown
	 *             no object instance was previously registered with the name
	 *             given
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 * @see RTIambassador#registerObjectInstance(ObjectClassHandle, String)
	 * 
	 */
	public ObjectInstanceHandle getObjectInstanceHandle(String theName) throws ObjectInstanceNotKnown, RemoteException;

	/**
	 * Implements HLA service 10.11 (See IEEE Std 1516.1-2000).
	 * 
	 * Returns the name of the object instance identified by the given object
	 * instance handle.
	 * 
	 * @param theHandle
	 *            the handle identifying the object instance for which the name
	 *            shall be returned
	 * @return the name of the object instance identified by the given object
	 *         instance handle.
	 * @throws ObjectInstanceNotKnown
	 *             the object instance handle is not valid
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 */
	public String getObjectInstanceName(ObjectInstanceHandle theHandle) throws ObjectInstanceNotKnown, RemoteException;

	/**
	 * Implements HLA service 10.16 (See IEEE Std 1516.1-2000).
	 * 
	 * Returns the object class handle of the object instance identified by the
	 * given object instance handle. This is the object class given when the
	 * object instance was registered.
	 * 
	 * @param theObject
	 *            the object instance handle identifying the object instance for
	 *            which its object class shall be returned
	 * @return the object class handle of the object instance identified by the
	 *         given object instance handle
	 * @throws ObjectInstanceNotKnown
	 *             the given object instance is not valid
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 * 
	 */
	public ObjectClassHandle getKnownObjectClassHandle(ObjectInstanceHandle theObject) throws ObjectInstanceNotKnown,
			RemoteException;

	/**
	 * Implements HLA service 5.2 (See IEEE Std 1516.1-2000).
	 * 
	 * Adds the given attributes to the published attributes of the given
	 * federate.
	 * 
	 * @param theClass
	 *            the object class the attributes are defined in
	 * @param attributeHandles
	 *            a list of attributes to be added to the published attributes
	 *            of the given federate
	 * @param federateHandle
	 *            the handle of the federate that publishes the given attributes
	 * @throws ObjectClassNotDefined
	 *             the object class given by the object class handle is not
	 *             defined in the FOM of this federation execution
	 * @throws AttributeNotDefined
	 *             one or more of the attributes are not defined in the given
	 *             object class
	 * @throws FederateNotExecutionMember
	 *             the federate identified with the given federate handle is not
	 *             joined tho this federation execution
	 * @throws SaveInProgress
	 *             not implemented
	 * @throws RestoreInProgress
	 *             not implemented
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 * @throws InvalidAttributeHandle
	 * @throws InvalidFederateHandle
	 * @throws InvalidObjectClassHandle
	 */
	public void publishObjectClassAttributes(ObjectClassHandle theClass, AttributeHandle[] attributeHandles,
			FederateHandle federateHandle) throws ObjectClassNotDefined, AttributeNotDefined,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, InvalidFederateHandle,
			InvalidAttributeHandle, RemoteException, InvalidObjectClassHandle;

	/**
	 * Implements HLA service 5.3 (See IEEE Std 1516.1-2000).
	 * 
	 * Remove all attributes of the given class from the published attributes of
	 * the given federate.
	 * 
	 * @param theClass
	 *            the object class that contains the attributes which shall be
	 *            removed from the published attributes
	 * @param federateHandle
	 *            the handle of the federate that shall unpublish the given
	 *            attributes
	 * @throws ObjectClassNotDefined
	 *             the object class given by the object class handle is not
	 *             defined in the FOM of this federation execution
	 * @throws OwnershipAcquisitionPending
	 *             not implemented
	 * @throws FederateNotExecutionMember
	 *             the federate identified with the given federate handle is not
	 *             joined tho this federation execution
	 * @throws SaveInProgress
	 *             not implemented
	 * @throws RestoreInProgress
	 *             not implemented
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 */
	public void unpublishObjectClass(ObjectClassHandle theClass, FederateHandle federateHandle)
			throws ObjectClassNotDefined, FederateNotExecutionMember, RemoteException;

	/**
	 * Implements HLA service 5.3 (See IEEE Std 1516.1-2000).
	 * 
	 * Un-publishes the given attributes at the given federate.
	 * 
	 * @param objectClassHandle
	 *            the object class that defines the given attributes
	 * @param attributeList
	 *            the attributes to be un-published
	 * @param federateHandle
	 *            the federate that un-publishes the given attributes
	 * @throws ObjectClassNotDefined
	 *             if the given object class is not defined in the FOM of this
	 *             federation executoin
	 * @throws AttributeNotDefined
	 *             if one of the attributes is not defined
	 * @throws FederateNotExecutionMember
	 *             if the given federat is not joined to this federation
	 *             execution
	 * @throws InvalidAttributeHandle
	 *             if one of the attributes is not valid
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 * 
	 */
	public void unpublishObjectClassAttributes(ObjectClassHandle objectClassHandle, AttributeHandle[] attributeHandles,
			FederateHandle federateHandle) throws ObjectClassNotDefined, AttributeNotDefined,
			FederateNotExecutionMember, InvalidAttributeHandle, RemoteException;

	/**
	 * Implements HLA service 5.4 (See IEEE Std 1516.1-2000).
	 * 
	 * Adds the given interaction class to the published interactions of the
	 * given federate
	 * 
	 * @param interactionClassHandle
	 *            the interaction to be added to the to the published
	 *            interactions of the given federate
	 * @param federateHandle
	 *            the handle of the federate that wants to publish the given
	 *            interaction
	 * @throws InteractionClassNotDefined
	 *             the interaction class given by the interaction class handle
	 *             is not defined in the FOM of this federation execution
	 * @throws FederateNotExecutionMember
	 *             the federate identified with the given federate handle is not
	 *             joined tho this federation execution
	 * @throws SaveInProgress
	 *             not implemented
	 * @throws RestoreInProgress
	 *             not implemented
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 */
	public void publishInteractionClass(InteractionClassHandle interactionClassHandle, FederateHandle federateHandle)
			throws InteractionClassNotDefined, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
			RemoteException;

	void unpublishInteractionClass(InteractionClassHandle interactionClassHandle, FederateHandle federateHandle)
			throws InteractionClassNotDefined, FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RemoteException;

	/**
	 * Implements HLA service 5.6 (See IEEE Std 1516.1-2000).
	 * 
	 * Subscribes the given federate with the given object class attributes.
	 * 
	 * @param objectClassHandle
	 *            the object class the attributes are defined in
	 * @param attributeHandles
	 *            the object class attributes that the given federate shall be
	 *            subscribed to
	 * @param federateHandle
	 *            the federate that shall subscribe to the given object class
	 *            attributes
	 * @throws ObjectClassNotDefined
	 *             the object class given by the object class handle is not
	 *             defined in the FOM of this federation execution
	 * @throws AttributeNotDefined
	 *             one or more of the attributes are not defined in the given
	 *             object class
	 * @throws FederateNotExecutionMember
	 *             the federate identified with the given federate handle is not
	 *             joined tho this federation execution
	 * @throws InvalidAttributeHandle
	 *             the given attribute handle is not valid
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 */
	public void subscribeObjectClassAttributes(ObjectClassHandle objectClassHandle, AttributeHandle[] attributeHandles,
			FederateHandle federateHandle) throws ObjectClassNotDefined, AttributeNotDefined,
			FederateNotExecutionMember, InvalidAttributeHandle, RemoteException;

	/**
	 * 
	 * Implements HLA service 5.7 (See IEEE Std 1516.1-2000).
	 * 
	 * Unsubscribes the given federate from the given object class attributes.
	 * 
	 * @param theClass
	 *            the object class the attributes are defined in
	 * @param attributeHandles
	 *            the object class attributes that the given federate shall be
	 *            unsubscribed from
	 * @param federateHandle
	 *            the federate that shall unsubscribe from the given object
	 *            class attributes
	 * @throws ObjectClassNotDefined
	 *             the object class given by the object class handle is not
	 *             defined in the FOM of this federation execution
	 * @throws AttributeNotDefined
	 *             one or more of the attributes are not defined in the given
	 *             object class
	 * @throws FederateNotExecutionMember
	 *             the federate identified with the given federate handle is not
	 *             joined tho this federation execution
	 * @throws SaveInProgress
	 *             not implemented
	 * @throws RestoreInProgress
	 *             not implemented
	 * @throws InvalidAttributeHandle
	 *             If one of the attribute handles given is not valid
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 */
	public void unsubscribeObjectClassAttributes(ObjectClassHandle theClass, AttributeHandle[] attributeHandles,
			FederateHandle federateHandle) throws ObjectClassNotDefined, AttributeNotDefined,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, InvalidAttributeHandle, RemoteException;

	/**
	 * Implements HLA service 5.7 (See IEEE Std 1516.1-2000).
	 * 
	 * Unsubscribes the given federate from all attributes defined in the given
	 * object class
	 * 
	 * @param theClass
	 *            the object class the attributes are defined in
	 * @param federateHandle
	 *            the federate that shall unsubscribe from the given object
	 *            class attributes
	 * @throws ObjectClassNotDefined
	 *             the object class given by the object class handle is not
	 *             defined in the FOM of this federation execution
	 * @throws FederateNotExecutionMember
	 *             the federate identified with the given federate handle is not
	 *             joined tho this federation execution
	 * @throws SaveInProgress
	 *             not implemented
	 * @throws RestoreInProgress
	 *             not implemented
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 */
	public void unsubscribeObjectClass(ObjectClassHandle theClass, FederateHandle federateHandle)
			throws ObjectClassNotDefined, FederateNotExecutionMember, RemoteException;

	/**
	 * Implements HLA service 5.8 (See IEEE Std 1516.1-2000).
	 * 
	 * Subscribes the given federate to the given interaction class.
	 * 
	 * 
	 * @param interactionClassHandle
	 *            the interaction class handle to be subscribed to
	 * @param federateHandle
	 *            the federate that subscribes to the interaction class
	 * @throws InteractionClassNotDefined
	 *             if the interfaction class is not defined in the FOM of this
	 *             federation execution
	 * @throws FederateServiceInvocationsAreBeingReportedViaMOM
	 * 
	 * @throws FederateNotExecutionMember
	 *             the federate identified with the given federate handle is not
	 *             joined tho this federation execution
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 */
	public void subscribeInteractionClass(InteractionClassHandle interactionClassHandle, FederateHandle federateHandle)
			throws InteractionClassNotDefined, FederateServiceInvocationsAreBeingReportedViaMOM,
			FederateNotExecutionMember, RemoteException;

	/**
	 * Implements HLA service 5.9 (See IEEE Std 1516.1-2000).
	 * 
	 * Unsubscribes the given federate from the given interaction class.
	 * 
	 * @param theClass
	 *            the interaction class the given federate shall be subscribed
	 *            to
	 * @param federateHandle
	 *            the federate that shall be subscribed to the given interaction
	 *            class
	 * @throws InteractionClassNotDefined
	 *             the interaction class given by the interaction class handle
	 *             is not defined in the FOM of this federation execution
	 * @throws FederateNotExecutionMember
	 *             the federate identified with the given federate handle is not
	 *             joined tho this federation execution
	 * @throws SaveInProgress
	 *             not implemented
	 * @throws RestoreInProgress
	 *             not implemented
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 */
	public void unsubscribeInteractionClass(InteractionClassHandle theClass, FederateHandle federateHandle)
			throws InteractionClassNotDefined, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
			RemoteException;

	/**
	 * Implements HLA service 6.4 (See IEEE Std 1516.1-2000).
	 * 
	 * Registers a new object instance of the given object class with the given
	 * federate.
	 * 
	 * @param objectClassHandle
	 *            the object class of the instance to be registered.
	 * @param federateHandle
	 *            the federate that registers the new instance
	 * @return a handle to the newly registered instance
	 * @throws ObjectClassNotDefined
	 *             the object class given by the object class handle is not
	 *             defined in the FOM of this federation execution
	 * @throws ObjectClassNotPublished
	 *             the federate (given with the federate handle) does not
	 *             publish the given object class and can therefore not register
	 *             an instance
	 * @throws FederateNotExecutionMember
	 *             the federate identified with the given federate handle is not
	 *             joined tho this federation execution
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 * @throws InvalidObjectClassHandle
	 */
	public ObjectInstanceHandle registerObjectInstance(ObjectClassHandle objectClassHandle,
			FederateHandle federateHandle) throws ObjectClassNotDefined, ObjectClassNotPublished,
			FederateNotExecutionMember, RemoteException, InvalidObjectClassHandle;

	/**
	 * Implements HLA service 6.4 (See IEEE Std 1516.1-2000).
	 * 
	 * Registers a new object instance of the given object class with the given
	 * federate and the given name.
	 * 
	 * @throws ObjectClassNotDefined
	 *             the object class given by the object class handle is not
	 *             defined in the FOM of this federation execution
	 * @throws ObjectClassNotPublished
	 *             the federate (given with the federate handle) does not
	 *             publish the given object class and can therefore not register
	 *             an instance
	 * @throws ObjectInstanceNameNotReserved
	 *             The object instance name was not reserved.
	 * @throws ObjectInstanceNameInUse
	 *             the object instance name was already coadunated with another
	 *             object instance
	 * @throws FederateNotExecutionMember
	 *             the federate identified with the given federate handle is not
	 *             joined tho this federation execution
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 * @throws InvalidObjectClassHandle
	 * 
	 */
	public ObjectInstanceHandle registerObjectInstance(ObjectClassHandle objectClassHandle, String instanceName,
			FederateHandle federateHandle) throws ObjectClassNotDefined, ObjectClassNotPublished,
			ObjectInstanceNameNotReserved, ObjectInstanceNameInUse, FederateNotExecutionMember, SaveInProgress,
			RestoreInProgress, RemoteException;

	/**
	 * Implements part of the HLA service 6.6 (See IEEE Std 1516.1-2000).
	 * 
	 * This method does two things at once, it searches and returns the
	 * federates which are subscribed to at least one of the given attributes
	 * and checks if the federate identified by the given federate handle
	 * parameter owns all the attributes of the given object instance. This is
	 * due to performance reasons, i.e. it avoids two remote method calls. Note
	 * that subscriptions made by the asking federates are not included in the
	 * result.
	 * 
	 * @param objectInstanceHandle
	 *            the object instance handle of the attributes to checked for
	 *            ownership.
	 * @param attributeHandles
	 *            the attribute handles to be checked for subscribed federates.
	 * @param askingFederateHandle
	 *            the federate asking for the subscribed federates
	 * @return A map that contains all federate han TODO
	 * @throws AttributeNotDefined
	 *             one or more of the attributes in the attribute value map are
	 *             not defined in the class of the instance
	 * @throws AttributeNotOwned
	 *             one or more of the attributes in the attribute value map are
	 *             not owned by the given federate
	 * @throws FederateNotExecutionMember
	 *             the federate identified with the given federate handle is not
	 *             joined tho this federation execution
	 * @throws ObjectInstanceNotKnown
	 *             if the given object instance handle is not identifying a
	 *             registered object instance of this federation execution
	 * @throws InvalidAttributeHandle
	 *             If one of the attribute handles given is not valid
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 */
	public Map<LrcRemote, Map<FederateHandle, AttributeHandle[]>> getSubscriptions(
			ObjectInstanceHandle objectInstanceHandle, AttributeHandle[] attributeHandles,
			FederateHandle askingFederateHandle) throws AttributeNotDefined, AttributeNotOwned,
			FederateNotExecutionMember, InvalidAttributeHandle, ObjectInstanceNotKnown, RemoteException;

	/**
	 * Implements part of the HLA service 6.17 (See IEEE Std 1516.1-2000).
	 * 
	 * This method does two things at once, it searches and returns the
	 * federates which are subscribed to the given interaction class and checks
	 * if the federate identified by the given federate handle parameter
	 * publishes the given interaction class. This is due to performance
	 * reasons, i.e. it avoids two remote method calls. Note that subscriptions
	 * made by the asking federates are not included in the result.
	 * 
	 * @param interactionClassHandle
	 *            the interaction class handle to be checked for subscribed
	 *            federates
	 * @param federateHandle
	 *            the federate asking for the subscribed federates
	 * @throws InteractionClassNotDefined
	 *             the given interaction class is not defined in the FOM of this
	 *             federation execution
	 * @throws InteractionClassNotDefined
	 *             the given interaction class is not published by the given
	 *             federate
	 * @throws FederateNotExecutionMember
	 *             the federate identified with the given federate handle is not
	 *             joined tho this federation execution
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 */
	public Map<LrcRemote, Set<FederateHandle>> getSubscriptions(InteractionClassHandle interactionClassHandle,
			FederateHandle askingFederate) throws InteractionClassNotDefined, InteractionClassNotPublished,
			FederateNotExecutionMember, RemoteException;

	/**
	 * Implements HLA service 6.17 (See IEEE Std 1516.1-2000).
	 * 
	 * Requests that the federate(s) owning the given attributes on the given
	 * instance to update the values.
	 * 
	 * @see LrcRemote#provideAttributeValueUpdate(ObjectInstanceHandle,
	 *      AttributeHandleSet, byte[], FederateHandle[], String)
	 * 
	 * @param objectInstanceHandle
	 *            the object instance handle for which updates shall be provided
	 * 
	 * @param attributeHandles
	 *            the attributes for which updates shall be provided
	 * @param userSuppliedTag
	 *            user supplied tag (delivered as is to the applicable
	 *            federates)
	 * @throws ObjectInstanceNotKnown
	 *             the object instance has not been register previously
	 * @throws AttributeNotDefined
	 *             on or more of the given attributes are not defined for the
	 *             object class of the given object instance
	 * @throws SaveInProgress
	 *             not implemented
	 * @throws RestoreInProgress
	 *             not implemented
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 */
	public void requestAttributeValueUpdate(ObjectInstanceHandle objectInstanceHandle,
			AttributeHandle[] attributeHandles, byte[] userSuppliedTag) throws ObjectInstanceNotKnown,
			AttributeNotDefined, SaveInProgress, RestoreInProgress, RemoteException;

	/**
	 * Returns the number of currently joined federates.
	 * 
	 * @return the number of currently joined federates.
	 */
	public int getJoinedFederates() throws RemoteException;

}

// /**
// * Implements HLA service 6.6 (See IEEE Std 1516.1-2000).
// *
// * Updates the attribute values of the given instance. Updating values
// * causes the values to be reflected on federates which are subscribed to
// * any of the attribute that is being updated.
// *
// * @param objectInstanceHandle
// * the object instance for which attrbutes are being updated
// * @param attributeHandleValueMap
// * a map of attributes and associated values.
// * @param userSuppliedTag
// * a user supplied tag
// * @param updatingFederate
// * a handle of the federate from which the updated origins.
// * @throws ObjectInstanceNotKnown
// * the given object instance is not a valid handle
// * @throws AttributeNotDefined
// * one or more of the attrbibutes in the attribute value map are
// * not defined in the class of the instance
// * @throws AttributeNotOwned
// * one or more of the attrbutes in the attribute value map are
// * not owned by the given federate
// */
// public void updateAttributeValues(ObjectInstanceHandle objectInstanceHandle,
// AttributeHandleValueMap attributeHandleValueMap, byte[] userSuppliedTag,
// FederateHandle updatingFederate)
// throws ObjectInstanceNotKnown, AttributeNotDefined, AttributeNotOwned;
//
// /**
// * Implements HLA service 6.17 (See IEEE Std 1516.1-2000).
// *
// * Sends the given interaction to all subscribed federates.
// *
// * @param theInteraction
// * the ineraction to be sent
// * @param theParameters
// * a map of interaction parameters with associated values
// * @param userSuppliedTag
// * user supplied tag
// * @param sendingFederate
// * the federate that sends the interaction
// * @throws InteractionClassNotPublished
// * the interaction class has not been published by the given
// * federate
// * @throws InteractionClassNotDefined
// * the interaction class is not defined in the FOM of this
// * federation execution
// * @throws InteractionParameterNotDefined
// * one or more of the given interaction parameters are not
// * defined in the given interaction class.
// * @throws FederateNotExecutionMember
// * the federate identified with the given federate handle is not
// * joined tho this federation execution
// * @throws SaveInProgress
// * not implemented
// * @throws RestoreInProgress
// * not implemented
// */
// public void sendInteraction(InteractionClassHandle theInteraction,
// ParameterHandleValueMap theParameters,
// byte[] userSuppliedTag, FederateHandle sendingFederate) throws
// InteractionClassNotPublished,
// InteractionClassNotDefined, InteractionParameterNotDefined,
// FederateNotExecutionMember, SaveInProgress,
// RestoreInProgress;
