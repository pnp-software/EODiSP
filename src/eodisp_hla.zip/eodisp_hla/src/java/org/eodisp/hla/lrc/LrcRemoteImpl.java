/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.hla.lrc;

import hla.rti1516.*;

import java.rmi.RemoteException;
import java.util.Map;

import org.apache.log4j.Logger;
import org.eodisp.hla.common.lrc.LrcRemote;

/**
 * 
 * @author ibirrer
 * @version $Id:$
 * 
 * @UML -------------------------------------------------------------------
 * 
 * @navassoc - lrc 1 Lrc
 * 
 */
public class LrcRemoteImpl implements LrcRemote {

	private static final long serialVersionUID = 1L;

	private final Lrc lrc;

	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	private final static Logger logger = Logger.getLogger(LrcRemoteImpl.class);

	public LrcRemoteImpl(Lrc lrc) {
		this.lrc = lrc;
	}

	public void synchronizationPointRegistrationSucceeded(String synchronizationPointLabel,
			FederateHandle federateHandle, String federationExecutionName) throws FederateInternalError,
			RemoteException {
		lrc.getFederateAmbassador(federationExecutionName, federateHandle).synchronizationPointRegistrationSucceeded(
				synchronizationPointLabel);
	}

	public void synchronizationPointRegistrationFailed(String synchronizationPointLabel,
			SynchronizationPointFailureReason reason, FederateHandle federateHandle, String federationExecutionName)
			throws FederateInternalError, RemoteException {

		lrc.getFederateAmbassador(federationExecutionName, federateHandle).synchronizationPointRegistrationFailed(
				synchronizationPointLabel, reason);
	}

	public void announceSynchronizationPoint(String synchronizationPointLabel, byte[] userSuppliedTag,
			FederateHandle[] federateHandles, String federationExecutionName) throws FederateInternalError,
			RemoteException {
		logger.debug(String.format("Announce Synchronization Point %s to federate(s) %s", synchronizationPointLabel,
				federateHandles));
		for (FederateHandle federateHandle : federateHandles) {
			FederateAmbassador federateAmbassador = lrc.getFederateAmbassador(federationExecutionName, federateHandle);
			federateAmbassador.announceSynchronizationPoint(synchronizationPointLabel, userSuppliedTag);
		}

	}

	public void federationSynchronized(String synchronizationPointLabel, FederateHandle[] federateHandles,
			String federationExecutionName, byte[] userSuppliedTag) throws FederateInternalError, RemoteException {
		for (FederateHandle federateHandle : federateHandles) {
			FederateAmbassador federateAmbassador = lrc.getFederateAmbassador(federationExecutionName, federateHandle);
			federateAmbassador.federationSynchronized(synchronizationPointLabel);
		}
	}

	public void discoverObjectInstance(ObjectInstanceHandle theObject, ObjectClassHandle theObjectClass,
			String objectName, FederateHandle[] federateHandles, String federationExecutionName)
			throws CouldNotDiscover, ObjectClassNotRecognized, FederateInternalError, RemoteException {
		for (FederateHandle federateHandle : federateHandles) {
			FederateAmbassador federateAmbassador = lrc.getFederateAmbassador(federationExecutionName, federateHandle);
			federateAmbassador.discoverObjectInstance(theObject, theObjectClass, objectName);
		}
	}

	public void receiveInteraction(InteractionClassHandle interactionClass, ParameterHandleValueMap theParameters,
			byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport,
			FederateHandle[] federateHandles, String federationExecutionName) throws InteractionClassNotRecognized,
			InteractionParameterNotRecognized, InteractionClassNotSubscribed, FederateInternalError, RemoteException {
		for (FederateHandle federateHandle : federateHandles) {
			FederateAmbassador federateAmbassador = lrc.getFederateAmbassador(federationExecutionName, federateHandle);
			federateAmbassador.receiveInteraction(interactionClass, theParameters, userSuppliedTag, sentOrdering,
					theTransport);
		}
	}

	public void provideAttributeValueUpdate(ObjectInstanceHandle theObject, AttributeHandleSet theAttributes,
			byte[] userSuppliedTag, FederateHandle[] federateHandles, String federationExecutionName)
			throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotOwned, FederateInternalError,
			RemoteException {
		for (FederateHandle federateHandle : federateHandles) {
			FederateAmbassador federateAmbassador = lrc.getFederateAmbassador(federationExecutionName, federateHandle);
			federateAmbassador.provideAttributeValueUpdate(theObject, theAttributes, userSuppliedTag);
		}
	}

	public void startRegistrationForObjectClass(String federationExecutionName, ObjectClassHandle objectClassHandle,
			FederateHandle[] federateHandles) throws ObjectClassNotPublished, FederateInternalError {
		for (FederateHandle federateHandle : federateHandles) {
			FederateAmbassador federateAmbassador = lrc.getFederateAmbassador(federationExecutionName, federateHandle);
			federateAmbassador.startRegistrationForObjectClass(objectClassHandle);
		}
	}

	public void reflectAttributeValues(ObjectInstanceHandle objectInstanceHandle, Map<AttributeHandle, byte[]> values,
			byte[] userSuppliedTag, Map<FederateHandle, AttributeHandle[]> federateSubscriptions,
			String federationExecutionName) throws ObjectInstanceNotKnown, AttributeNotRecognized,
			AttributeNotSubscribed, FederateInternalError, RemoteException {
		logger.debug("Call reflect on LrcRemote");
		lrc.reflectAttributeValues(objectInstanceHandle, values, userSuppliedTag, federateSubscriptions,
				federationExecutionName);
	}
}
