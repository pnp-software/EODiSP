/**
 * 
 */
package org.eodisp.hla.common.handles;


import hla.rti1516.CouldNotDecode;
import hla.rti1516.DimensionHandle;

/**
 * @author ibirrer
 */
public class DimensionHandleImpl extends UUIDHandle implements DimensionHandle {

	public DimensionHandleImpl() {
		super();
	}

	public DimensionHandleImpl(String s) {
		super(s);
	}

	public DimensionHandleImpl(byte[] buffer, int offset) throws CouldNotDecode {
		super(buffer, offset);
	}
}
