/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.hla.common.lrc;

import hla.rti1516.*;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Map;

/**
 * Remote interface of the local RTI component.
 * 
 * @author ibirrer
 * @version $Id:$
 * 
 */
public interface LrcRemote extends Remote {

	// /////////////////////////////////
	// Federation Management Services //
	// /////////////////////////////////

	public static final String REGISTRY_NAME = "lrcRemote";

	/**
	 * HLA service 4.7 (See IEEE Std 1516.1-2000).
	 * 
	 * Confirm that the registration of the synchronization point was
	 * successful.
	 * 
	 * @param synchronizationPointLabel
	 *            the label of the synchronization point which registration has
	 *            succeeded.
	 * @param federateHandle
	 *            the federate for which the synchronization point registration
	 *            succeeded.
	 * @param federationExecutionName
	 *            the name of the federation execution this call is applicable
	 *            for
	 * @throws FederateInternalError
	 *             Exceptions thrown by the federation implementation TODO: use
	 *             a w
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 */
	public void synchronizationPointRegistrationSucceeded(String synchronizationPointLabel,
			FederateHandle federateHandle, String federationExecutionName) throws FederateInternalError,
			RemoteException;

	/**
	 * HLA service 4.7 (See IEEE Std 1516.1-2000).
	 * 
	 * Report that a synchronization point could not be registered.
	 * 
	 * @param synchronizationPointLabel
	 *            the label of the synchronization point which registration has
	 *            failed.
	 * @param federateHandle
	 *            the federate, for which the synchronization point registration
	 *            failed.
	 * @param federationExecutionName
	 *            the name of the federation execution this call is applicable
	 *            for
	 * @throws FederateInternalError
	 *             Exceptions thrown by the federation implementation TODO: use
	 *             a wrapper exception here?
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 */
	public void synchronizationPointRegistrationFailed(String synchronizationPointLabel,
			SynchronizationPointFailureReason reason, FederateHandle federateHandle, String federationExecutionName)
			throws FederateInternalError, RemoteException;

	/**
	 * HLA service 4.8 (See IEEE Std 1516.1-2000).
	 * 
	 * Announces a new synchronization point to the given federates
	 * 
	 * @param synchronizationPointLabel
	 *            the label of the synchronization point
	 * @param userSuppliedTag
	 *            user supplied tag
	 * @param federateHandles
	 *            the federates which shall be informed of a new synchronization
	 *            point
	 * @param federationExecutionName
	 *            the name of the federation execution this call is applicable
	 *            for
	 * @throws FederateInternalError
	 *             Exceptions thrown by the federation implementation TODO: use
	 *             a wrapper exception here?
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 */
	public void announceSynchronizationPoint(String synchronizationPointLabel, byte[] userSuppliedTag,
			FederateHandle[] federateHandles, String fedreationExecutionName) throws FederateInternalError,
			RemoteException;

	/**
	 * HLA service 4.10 (See IEEE Std 1516.1-2000).
	 * 
	 * Inform the given federates that a federation execution has synchronized
	 * at the given synchronization point.
	 * 
	 * @param synchronizationPointLabel
	 *            the label of the synchronization point
	 * @param federateHandles
	 *            the federates which shall be informed that the federation
	 *            execution has synchronized
	 * @param federationExecutionName
	 *            the name of the federation execution this call is applicable
	 *            for
	 * @param userSuppliedTag 
	 * @throws FederateInternalError
	 *             Exceptions thrown by the federation implementation TODO: use
	 *             a wrapper exception here?
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 */
	public void federationSynchronized(String synchronizationPointLabel, FederateHandle[] federateHandles,
			String federationExecutionName, byte[] userSuppliedTag) throws FederateInternalError, RemoteException;

	// //////////////////////////////
	// Object Management Services //
	// //////////////////////////////

	/**
	 * HLA service 6.5 (See IEEE Std 1516.1-2000).
	 * 
	 * Informs the given federates about a newly registered object instance.
	 * 
	 * @param theObject
	 *            the object instance that was registered by another federate
	 * @param theObjectClass
	 *            the object class of the newly registered instance
	 * @param objectName
	 *            the unique name of the newly registered instance
	 * @param federateHandles
	 *            the federates that shall be informed about the newly
	 *            registered instance
	 * @param federationExecutionName
	 *            the name of the federation execution this call is applicable
	 *            for
	 * @throws CouldNotDiscover
	 *             TODO: check
	 * @throws ObjectClassNotRecognized
	 *             TODO: check
	 * @throws FederateInternalError
	 *             Exceptions thrown by the federation implementation TODO: use
	 *             a wrapper exception here?
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 */
	public void discoverObjectInstance(ObjectInstanceHandle theObject, ObjectClassHandle theObjectClass,
			String objectName, FederateHandle[] federateHandles, String federationExecutionName)
			throws CouldNotDiscover, ObjectClassNotRecognized, FederateInternalError, RemoteException;

	/**
	 * HLA service 6.7 (See IEEE Std 1516.1-2000).
	 * 
	 * Informs the given federates about attribute value updates.
	 * 
	 * TODO: Consider other ways of delivering data from one LRC to another.
	 * 
	 * @param theObject
	 *            the object instance which attributes are being updated
	 * @param attributeHandleValueMap
	 *            a map with attribute handles as keys and its associated
	 *            values.
	 * @param userSuppliedTag
	 *            user supplied tag
	 * @param sentOrdering
	 *            not implemented
	 * @param theTransport
	 *            not implemented
	 * @param federateHandles
	 *            the federates that shall receive the updates on this LRC
	 * @param federationExecutionName
	 *            the name of the federation execution this call is applicable
	 *            for
	 * @throws ObjectInstanceNotKnown
	 *             TODO: check
	 * @throws AttributeNotRecognized
	 *             TODO: check
	 * @throws AttributeNotSubscribed
	 *             TODO: check
	 * @throws FederateInternalError
	 *             Exceptions thrown by the federation implementation TODO: use
	 *             a wrapper exception here?
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 */
	// public void reflectAttributeValues(ObjectInstanceHandle theObject,
	// AttributeHandleValueMap attributeHandleValueMap,
	// byte[] userSuppliedTag, OrderType sentOrdering, TransportationType
	// theTransport,
	// FederateHandle[] federateHandles, String federationExecutionName) throws
	// ObjectInstanceNotKnown,
	// AttributeNotRecognized, AttributeNotSubscribed, FederateInternalError,
	// RemoteException;
	public void reflectAttributeValues(ObjectInstanceHandle objectInstanceHandle,
			Map<AttributeHandle, byte[]> values, byte[] userSuppliedTag,
			Map<FederateHandle, AttributeHandle[]> federateSubscriptions, String federationExecutionName)
			throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotSubscribed, FederateInternalError,
			RemoteException;

	/**
	 * HLA service 6.9 (See IEEE Std 1516.1-2000).
	 * 
	 * Informs the given federates about an interaction sent by another
	 * federate.
	 * 
	 * @param interactionClass
	 *            the interaction class sent by another federate
	 * @param theParameters
	 *            parameter values for the received interaction
	 * @param userSuppliedTag
	 *            the tag supplied by the sending federate
	 * @param sentOrdering
	 *            not implemented
	 * @param theTransport
	 *            not implemented
	 * @param federateHandles
	 *            the federates that shall receive the interaction on this LRC
	 * @param federationExecutionName
	 *            the name of the federation execution this call is applicable
	 *            for
	 * @throws InteractionClassNotRecognized
	 *             TODO: check
	 * @throws InteractionParameterNotRecognized
	 *             TODO: check
	 * @throws InteractionClassNotSubscribed
	 *             TODO: check
	 * @throws FederateInternalError
	 *             Exceptions thrown by the federation implementation TODO: use
	 *             a wrapper exception here?
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 */
	public void receiveInteraction(InteractionClassHandle interactionClass, ParameterHandleValueMap theParameters,
			byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport,
			FederateHandle[] federateHandles, String federationExecutionName) throws InteractionClassNotRecognized,
			InteractionParameterNotRecognized, InteractionClassNotSubscribed, FederateInternalError, RemoteException;

	/**
	 * HLA service 6.18 (See IEEE Std 1516.1-2000).
	 * 
	 * Requests the given federate to call
	 * {@link RTIambassador#updateAttributeValues(ObjectInstanceHandle, AttributeHandleValueMap, byte[])}
	 * for all values it owns of the given object instance.
	 * 
	 * @param theObject
	 *            the object instance for which the federate shall call update
	 *            attribute values
	 * @param theAttributes
	 *            the attributes for which for which the given federate shall
	 *            provide updates. TODO: Do we need to deliver all attributes
	 *            originally requested or only the ones owned by the given
	 *            federate(s)?
	 * @param federationExecutionName
	 *            the name of the federation execution this call is applicable
	 *            for
	 * @param userSuppliedTag
	 *            user supplied tag
	 * @param federateHandles
	 *            the federate(s) which own the given object and shall provide
	 *            updates
	 * @throws ObjectInstanceNotKnown
	 *             TODO: check
	 * @throws AttributeNotRecognized
	 *             TODO: check
	 * @throws AttributeNotOwned
	 *             TODO: check
	 * @throws FederateInternalError
	 *             Exceptions thrown by the federation implementation TODO: use
	 *             a wrapper exception here?
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method
	 */
	public void provideAttributeValueUpdate(ObjectInstanceHandle theObject, AttributeHandleSet theAttributes,
			byte[] userSuppliedTag, FederateHandle[] federateHandles, String federationExecutionName)
			throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotOwned, FederateInternalError,
			RemoteException;

	public void startRegistrationForObjectClass(String federationExecutionName, ObjectClassHandle objectClassHandle,
			FederateHandle[] federateHandles) throws RemoteException, ObjectClassNotPublished, FederateInternalError;
}
