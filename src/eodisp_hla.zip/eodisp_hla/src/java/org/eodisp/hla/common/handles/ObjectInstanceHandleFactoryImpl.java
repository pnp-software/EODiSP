package org.eodisp.hla.common.handles;

import hla.rti1516.*;

public class ObjectInstanceHandleFactoryImpl implements
		ObjectInstanceHandleFactory {

	public ObjectInstanceHandle decode(byte[] buffer, int offset)
			throws CouldNotDecode, FederateNotExecutionMember {
//		 TODO
		return null;
//		return new ObjectInstanceHandleImpl(buffer, offset);
	}

}
