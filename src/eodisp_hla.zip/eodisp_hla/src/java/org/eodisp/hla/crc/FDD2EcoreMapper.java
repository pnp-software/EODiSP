package org.eodisp.hla.crc;


/**
 * Maps an FDD Model to an ecore model. This is not used at the moment. This can be reused for implementing the federates.
 * 
 * @author ibirrer
 * @hidden
 */
public class FDD2EcoreMapper {

//	private static final Logger logger = Logger.getLogger(FDD2EcoreMapper.class.getName());
//
//	private static final EcorePackage ecorePackage = EcorePackage.eINSTANCE;
//
//	private static final EcoreFactory ecoreFactory = EcoreFactory.eINSTANCE;
//
//	/**
//	 * Package of the newly generated ecore model
//	 */
//	private EPackage rootPackage;
//
//	/**
//	 * FDD input resource
//	 */
//	private DocumentRoot fddDocRoot;
//
//	public FDD2EcoreMapper(DocumentRoot fddDocRoot) {
//		this.fddDocRoot = fddDocRoot;
//		rootPackage = ecoreFactory.createEPackage();
//		map();
//	}
//
//	private void map() {
//		ObjectModelType1 objectModel = fddDocRoot.getObjectModel();
//		List objectClasses = objectModel.getObjects().getObjectClass();
//		EClass rootClass = createRootEClass();
//		rootPackage.getEClassifiers().add(rootClass);
//		map(objectClasses, rootClass);
//	}
//
//	private void map(List objectClasses, EClass superEClass) {
//		for (int i = 0; i < objectClasses.size(); i++) {
//			ObjectClassType objectClass = (ObjectClassType) objectClasses.get(i);
//
//			EClass newSuperEClass = objectClass2EClass(objectClass);
//			if (superEClass != null) {
//				newSuperEClass.getESuperTypes().add(superEClass);
//			}
//			map(objectClass.getObjectClass(), newSuperEClass);
//		}
//	}
//
//	private EClass objectClass2EClass(ObjectClassType objectClass) {
//		EClass eClass = ecoreFactory.createEClass();
//		eClass.setName(objectClass.getName());
//
//		// TODO: Each EClass should inherit from a super class 'OMT' which
//		// defines things like a link to its coressponding instance handle.
//
//		for (Iterator iter = objectClass.getAttribute().iterator(); iter.hasNext();) {
//			AttributeType omtAttribute = (AttributeType) iter.next();
//			EAttribute eAttribute = ecoreFactory.createEAttribute();
//			eAttribute.setName(omtAttribute.getName());
//			eAttribute.setEType(ecorePackage.getEString());
//			eClass.getEStructuralFeatures().add(eAttribute);
//		}
//
//		rootPackage.getEClassifiers().add(eClass);
//		return eClass;
//	}
//
//	/**
//	 * Creates super class (OMTRoot) for all other generated classes.
//	 * 
//	 * This class includes the handle id which all classes have to provide.
//	 * 
//	 * @return
//	 */
//	private EClass createRootEClass() {
//		EClass eClass = ecoreFactory.createEClass();
//		eClass.setName("OMTRoot");
//		EAttribute handleAttribute = ecoreFactory.createEAttribute();
//		handleAttribute.setName("_omt_instance_name");
//		handleAttribute.setID(true);
//		handleAttribute.setVolatile(true);
//		handleAttribute.setTransient(true);
//		handleAttribute.setEType(ecorePackage.getEString());
//		eClass.getEStructuralFeatures().add(handleAttribute);
//		return eClass;
//	}
//
//	/**
//	 * @return Returns the rootPackage.
//	 */
//	public EPackage getEcore() {
//		return rootPackage;
//	}
}
