/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eodisp.hla.crc.omt.Lookahead;
import org.eodisp.hla.crc.omt.OmtPackage;
import org.eodisp.hla.crc.omt.Time;
import org.eodisp.hla.crc.omt.TimeStamp;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Time</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.TimeImpl#getTimeStamp <em>Time Stamp</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.TimeImpl#getLookahead <em>Lookahead</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class TimeImpl extends EObjectImpl implements Time {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The cached value of the '{@link #getTimeStamp() <em>Time Stamp</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getTimeStamp()
	 * @generated
	 * @ordered
	 */
	protected TimeStamp timeStamp = null;

	/**
	 * The cached value of the '{@link #getLookahead() <em>Lookahead</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getLookahead()
	 * @generated
	 * @ordered
	 */
	protected Lookahead lookahead = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected TimeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return OmtPackage.Literals.TIME;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public TimeStamp getTimeStamp() {
		return timeStamp;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetTimeStamp(TimeStamp newTimeStamp, NotificationChain msgs) {
		TimeStamp oldTimeStamp = timeStamp;
		timeStamp = newTimeStamp;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.TIME__TIME_STAMP,
					oldTimeStamp,
					newTimeStamp);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setTimeStamp(TimeStamp newTimeStamp) {
		if (newTimeStamp != timeStamp) {
			NotificationChain msgs = null;
			if (timeStamp != null)
				msgs = ((InternalEObject) timeStamp).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.TIME__TIME_STAMP, null, msgs);
			if (newTimeStamp != null)
				msgs = ((InternalEObject) newTimeStamp).eInverseAdd(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.TIME__TIME_STAMP, null, msgs);
			msgs = basicSetTimeStamp(newTimeStamp, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.TIME__TIME_STAMP,
					newTimeStamp,
					newTimeStamp));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Lookahead getLookahead() {
		return lookahead;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetLookahead(Lookahead newLookahead, NotificationChain msgs) {
		Lookahead oldLookahead = lookahead;
		lookahead = newLookahead;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.TIME__LOOKAHEAD,
					oldLookahead,
					newLookahead);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setLookahead(Lookahead newLookahead) {
		if (newLookahead != lookahead) {
			NotificationChain msgs = null;
			if (lookahead != null)
				msgs = ((InternalEObject) lookahead).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.TIME__LOOKAHEAD, null, msgs);
			if (newLookahead != null)
				msgs = ((InternalEObject) newLookahead).eInverseAdd(this, EOPPOSITE_FEATURE_BASE
						- OmtPackage.TIME__LOOKAHEAD, null, msgs);
			msgs = basicSetLookahead(newLookahead, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.TIME__LOOKAHEAD,
					newLookahead,
					newLookahead));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case OmtPackage.TIME__TIME_STAMP:
			return basicSetTimeStamp(null, msgs);
		case OmtPackage.TIME__LOOKAHEAD:
			return basicSetLookahead(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case OmtPackage.TIME__TIME_STAMP:
			return getTimeStamp();
		case OmtPackage.TIME__LOOKAHEAD:
			return getLookahead();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case OmtPackage.TIME__TIME_STAMP:
			setTimeStamp((TimeStamp) newValue);
			return;
		case OmtPackage.TIME__LOOKAHEAD:
			setLookahead((Lookahead) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
		case OmtPackage.TIME__TIME_STAMP:
			setTimeStamp((TimeStamp) null);
			return;
		case OmtPackage.TIME__LOOKAHEAD:
			setLookahead((Lookahead) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case OmtPackage.TIME__TIME_STAMP:
			return timeStamp != null;
		case OmtPackage.TIME__LOOKAHEAD:
			return lookahead != null;
		}
		return super.eIsSet(featureID);
	}

} // TimeImpl
