/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt.impl;

import java.util.List;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eodisp.hla.crc.omt.OmtPackage;
import org.eodisp.hla.crc.omt.Transportation;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Transportation</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.TransportationImpl#getDescription <em>Description</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.TransportationImpl#getDescriptionNotes <em>Description Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.TransportationImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.TransportationImpl#getNameNotes <em>Name Notes</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class TransportationImpl extends EObjectImpl implements Transportation {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The default value of the '{@link #getDescription() <em>Description</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDescription()
	 * @generated
	 * @ordered
	 */
	protected static final Object DESCRIPTION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDescription() <em>Description</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDescription()
	 * @generated
	 * @ordered
	 */
	protected Object description = DESCRIPTION_EDEFAULT;

	/**
	 * The default value of the '{@link #getDescriptionNotes() <em>Description Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDescriptionNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List DESCRIPTION_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDescriptionNotes() <em>Description Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDescriptionNotes()
	 * @generated
	 * @ordered
	 */
	protected List descriptionNotes = DESCRIPTION_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getNameNotes() <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getNameNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List NAME_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNameNotes() <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getNameNotes()
	 * @generated
	 * @ordered
	 */
	protected List nameNotes = NAME_NOTES_EDEFAULT;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected TransportationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return OmtPackage.Literals.TRANSPORTATION;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getDescription() {
		return description;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setDescription(Object newDescription) {
		Object oldDescription = description;
		description = newDescription;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.TRANSPORTATION__DESCRIPTION,
					oldDescription,
					description));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getDescriptionNotes() {
		return descriptionNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setDescriptionNotes(List newDescriptionNotes) {
		List oldDescriptionNotes = descriptionNotes;
		descriptionNotes = newDescriptionNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.TRANSPORTATION__DESCRIPTION_NOTES,
					oldDescriptionNotes,
					descriptionNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OmtPackage.TRANSPORTATION__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getNameNotes() {
		return nameNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setNameNotes(List newNameNotes) {
		List oldNameNotes = nameNotes;
		nameNotes = newNameNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.TRANSPORTATION__NAME_NOTES,
					oldNameNotes,
					nameNotes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case OmtPackage.TRANSPORTATION__DESCRIPTION:
			return getDescription();
		case OmtPackage.TRANSPORTATION__DESCRIPTION_NOTES:
			return getDescriptionNotes();
		case OmtPackage.TRANSPORTATION__NAME:
			return getName();
		case OmtPackage.TRANSPORTATION__NAME_NOTES:
			return getNameNotes();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case OmtPackage.TRANSPORTATION__DESCRIPTION:
			setDescription((Object) newValue);
			return;
		case OmtPackage.TRANSPORTATION__DESCRIPTION_NOTES:
			setDescriptionNotes((List) newValue);
			return;
		case OmtPackage.TRANSPORTATION__NAME:
			setName((String) newValue);
			return;
		case OmtPackage.TRANSPORTATION__NAME_NOTES:
			setNameNotes((List) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
		case OmtPackage.TRANSPORTATION__DESCRIPTION:
			setDescription(DESCRIPTION_EDEFAULT);
			return;
		case OmtPackage.TRANSPORTATION__DESCRIPTION_NOTES:
			setDescriptionNotes(DESCRIPTION_NOTES_EDEFAULT);
			return;
		case OmtPackage.TRANSPORTATION__NAME:
			setName(NAME_EDEFAULT);
			return;
		case OmtPackage.TRANSPORTATION__NAME_NOTES:
			setNameNotes(NAME_NOTES_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case OmtPackage.TRANSPORTATION__DESCRIPTION:
			return DESCRIPTION_EDEFAULT == null ? description != null : !DESCRIPTION_EDEFAULT.equals(description);
		case OmtPackage.TRANSPORTATION__DESCRIPTION_NOTES:
			return DESCRIPTION_NOTES_EDEFAULT == null ? descriptionNotes != null : !DESCRIPTION_NOTES_EDEFAULT
					.equals(descriptionNotes);
		case OmtPackage.TRANSPORTATION__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case OmtPackage.TRANSPORTATION__NAME_NOTES:
			return NAME_NOTES_EDEFAULT == null ? nameNotes != null : !NAME_NOTES_EDEFAULT.equals(nameNotes);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (description: ");
		result.append(description);
		result.append(", descriptionNotes: ");
		result.append(descriptionNotes);
		result.append(", name: ");
		result.append(name);
		result.append(", nameNotes: ");
		result.append(nameNotes);
		result.append(')');
		return result.toString();
	}

} // TransportationImpl
