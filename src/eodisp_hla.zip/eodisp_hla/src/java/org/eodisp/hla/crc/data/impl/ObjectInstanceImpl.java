/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.data.impl;

import hla.rti1516.ObjectInstanceHandle;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EcoreUtil;

import org.eodisp.hla.crc.data.DataPackage;
import org.eodisp.hla.crc.data.Federate;
import org.eodisp.hla.crc.data.ObjectInstance;

import org.eodisp.hla.crc.omt.ObjectClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Object Instance</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.data.impl.ObjectInstanceImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.data.impl.ObjectInstanceImpl#getObjectClass <em>Object Class</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.data.impl.ObjectInstanceImpl#getRegisteringFederate <em>Registering Federate</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.data.impl.ObjectInstanceImpl#getHandle <em>Handle</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ObjectInstanceImpl extends EObjectImpl implements ObjectInstance {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getObjectClass() <em>Object Class</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getObjectClass()
	 * @generated
	 * @ordered
	 */
	protected ObjectClass objectClass = null;

	/**
	 * The default value of the '{@link #getHandle() <em>Handle</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHandle()
	 * @generated
	 * @ordered
	 */
	protected static final ObjectInstanceHandle HANDLE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getHandle() <em>Handle</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHandle()
	 * @generated
	 * @ordered
	 */
	protected ObjectInstanceHandle handle = HANDLE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ObjectInstanceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return DataPackage.Literals.OBJECT_INSTANCE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DataPackage.OBJECT_INSTANCE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ObjectClass getObjectClass() {
		if (objectClass != null && objectClass.eIsProxy()) {
			InternalEObject oldObjectClass = (InternalEObject) objectClass;
			objectClass = (ObjectClass) eResolveProxy(oldObjectClass);
			if (objectClass != oldObjectClass) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(
							this,
							Notification.RESOLVE,
							DataPackage.OBJECT_INSTANCE__OBJECT_CLASS,
							oldObjectClass,
							objectClass));
			}
		}
		return objectClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ObjectClass basicGetObjectClass() {
		return objectClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setObjectClass(ObjectClass newObjectClass) {
		ObjectClass oldObjectClass = objectClass;
		objectClass = newObjectClass;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					DataPackage.OBJECT_INSTANCE__OBJECT_CLASS,
					oldObjectClass,
					objectClass));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Federate getRegisteringFederate() {
		if (eContainerFeatureID != DataPackage.OBJECT_INSTANCE__REGISTERING_FEDERATE)
			return null;
		return (Federate) eContainer();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetRegisteringFederate(Federate newRegisteringFederate, NotificationChain msgs) {
		msgs = eBasicSetContainer(
				(InternalEObject) newRegisteringFederate,
				DataPackage.OBJECT_INSTANCE__REGISTERING_FEDERATE,
				msgs);
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRegisteringFederate(Federate newRegisteringFederate) {
		if (newRegisteringFederate != eInternalContainer()
				|| (eContainerFeatureID != DataPackage.OBJECT_INSTANCE__REGISTERING_FEDERATE && newRegisteringFederate != null)) {
			if (EcoreUtil.isAncestor(this, newRegisteringFederate))
				throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
			NotificationChain msgs = null;
			if (eInternalContainer() != null)
				msgs = eBasicRemoveFromContainer(msgs);
			if (newRegisteringFederate != null)
				msgs = ((InternalEObject) newRegisteringFederate).eInverseAdd(
						this,
						DataPackage.FEDERATE__REGISTERED_OBJECT_INSTANCES,
						Federate.class,
						msgs);
			msgs = basicSetRegisteringFederate(newRegisteringFederate, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					DataPackage.OBJECT_INSTANCE__REGISTERING_FEDERATE,
					newRegisteringFederate,
					newRegisteringFederate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ObjectInstanceHandle getHandle() {
		return handle;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHandle(ObjectInstanceHandle newHandle) {
		ObjectInstanceHandle oldHandle = handle;
		handle = newHandle;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					DataPackage.OBJECT_INSTANCE__HANDLE,
					oldHandle,
					handle));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case DataPackage.OBJECT_INSTANCE__REGISTERING_FEDERATE:
			if (eInternalContainer() != null)
				msgs = eBasicRemoveFromContainer(msgs);
			return basicSetRegisteringFederate((Federate) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case DataPackage.OBJECT_INSTANCE__REGISTERING_FEDERATE:
			return basicSetRegisteringFederate(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eBasicRemoveFromContainerFeature(NotificationChain msgs) {
		switch (eContainerFeatureID) {
		case DataPackage.OBJECT_INSTANCE__REGISTERING_FEDERATE:
			return eInternalContainer().eInverseRemove(
					this,
					DataPackage.FEDERATE__REGISTERED_OBJECT_INSTANCES,
					Federate.class,
					msgs);
		}
		return super.eBasicRemoveFromContainerFeature(msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case DataPackage.OBJECT_INSTANCE__NAME:
			return getName();
		case DataPackage.OBJECT_INSTANCE__OBJECT_CLASS:
			if (resolve)
				return getObjectClass();
			return basicGetObjectClass();
		case DataPackage.OBJECT_INSTANCE__REGISTERING_FEDERATE:
			return getRegisteringFederate();
		case DataPackage.OBJECT_INSTANCE__HANDLE:
			return getHandle();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case DataPackage.OBJECT_INSTANCE__NAME:
			setName((String) newValue);
			return;
		case DataPackage.OBJECT_INSTANCE__OBJECT_CLASS:
			setObjectClass((ObjectClass) newValue);
			return;
		case DataPackage.OBJECT_INSTANCE__REGISTERING_FEDERATE:
			setRegisteringFederate((Federate) newValue);
			return;
		case DataPackage.OBJECT_INSTANCE__HANDLE:
			setHandle((ObjectInstanceHandle) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
		case DataPackage.OBJECT_INSTANCE__NAME:
			setName(NAME_EDEFAULT);
			return;
		case DataPackage.OBJECT_INSTANCE__OBJECT_CLASS:
			setObjectClass((ObjectClass) null);
			return;
		case DataPackage.OBJECT_INSTANCE__REGISTERING_FEDERATE:
			setRegisteringFederate((Federate) null);
			return;
		case DataPackage.OBJECT_INSTANCE__HANDLE:
			setHandle(HANDLE_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case DataPackage.OBJECT_INSTANCE__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case DataPackage.OBJECT_INSTANCE__OBJECT_CLASS:
			return objectClass != null;
		case DataPackage.OBJECT_INSTANCE__REGISTERING_FEDERATE:
			return getRegisteringFederate() != null;
		case DataPackage.OBJECT_INSTANCE__HANDLE:
			return HANDLE_EDEFAULT == null ? handle != null : !HANDLE_EDEFAULT.equals(handle);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", handle: ");
		result.append(handle);
		result.append(')');
		return result.toString();
	}

} //ObjectInstanceImpl