/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.hla.crc.launcher;

import java.rmi.RemoteException;

import org.eodisp.hla.crc.application.CrcMain;
import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.remote.launcher.*;
import org.eodisp.util.AppRegistry;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class CrcProcessFactoryRemoteImpl extends RootAppProcessFactoryRemoteImpl implements CrcProcessFactoryRemote {
	public ProcessRemote newProcess() throws RemoteException {
		RootAppProcessImpl crcApplicationProcess = new RootAppProcessImpl(CrcMain.class.getName(), getTransports(), 0);
		RemoteAppModule remoteAppModule = (RemoteAppModule) AppRegistry.getRootApp().getAppModule(RemoteAppModule.ID);
		RootAppProcessRemoteImpl rootAppProcessRemoteImpl = new RootAppProcessRemoteImpl(crcApplicationProcess);
		return (ProcessRemote) remoteAppModule.export(rootAppProcessRemoteImpl);
	}
}
