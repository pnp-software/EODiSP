/**
 * 
 */
package org.eodisp.hla.common.handles;

import hla.rti1516.*;

import java.io.UnsupportedEncodingException;
import java.util.UUID;

/**
 * @author ibirrer
 */
public class UUIDHandle implements FederateHandle, ObjectClassHandle,
		AttributeHandle, ObjectInstanceHandle {

	private UUID uuid;

	/**
	 * TODO: should be made configurable by config framework
	 */
	private static final String CHARSET = "UTF-8";

	public UUIDHandle() {
		uuid = UUID.randomUUID();
	}

	public UUIDHandle(String s) {
		uuid = UUID.fromString(s);
	}

	public UUIDHandle(byte[] buffer, int offset) throws CouldNotDecode {
		try {
			uuid = UUID.fromString(new String(buffer, offset, buffer.length
					- offset, CHARSET));
		} catch (IllegalArgumentException e) {
			throw new CouldNotDecode("Could not decode UUID Handle", e);
		} catch (UnsupportedEncodingException e) {
			// TODO: Change to EodispConfigExc if CHARSET is configurable
			// throw new EodispRuntimeException(e);
		}
	}

	/**
	 * TODO: See {@link #encode(byte[], int)}
	 */
	public int encodedLength() {
		return uuid.toString().length();
	}

	/**
	 * Returns the byte representation of the UUID.
	 */
	public void encode(byte[] buffer, int offset) {

		assert (buffer.length >= encodedLength());

		int index = offset;
		try {
			for (byte character : uuid.toString().getBytes(CHARSET)) {
				buffer[index++] = character;
			}
		} catch (UnsupportedEncodingException e) {
			// TODO: Change to EodispConfigExc if CHARSET is configurable
			// throw new EodispRuntimeException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj instanceof UUIDHandle) {
			return this.uuid.equals(((UUIDHandle) obj).uuid);
		}
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return uuid.hashCode();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return uuid.toString();
	}
}
