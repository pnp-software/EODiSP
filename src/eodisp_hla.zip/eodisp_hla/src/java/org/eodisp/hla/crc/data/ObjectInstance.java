/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.data;

import hla.rti1516.ObjectInstanceHandle;

import org.eclipse.emf.ecore.EObject;

import org.eodisp.hla.crc.omt.ObjectClass;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Object Instance</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.data.ObjectInstance#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.data.ObjectInstance#getObjectClass <em>Object Class</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.data.ObjectInstance#getRegisteringFederate <em>Registering Federate</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.data.ObjectInstance#getHandle <em>Handle</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eodisp.hla.crc.data.DataPackage#getObjectInstance()
 * @model
 * @generated
 */
public interface ObjectInstance extends EObject {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The prefix of the object instance name if created with
	 * {@link DataFactory#createObjectInstance(ObjectClass, ObjectInstanceHandle)}
	 */
	public static final String NAME_PREFIX = "HLA";

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.eodisp.hla.crc.data.DataPackage#getObjectInstance_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.data.ObjectInstance#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Object Class</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Object Class</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Object Class</em>' reference.
	 * @see #setObjectClass(ObjectClass)
	 * @see org.eodisp.hla.crc.data.DataPackage#getObjectInstance_ObjectClass()
	 * @model required="true"
	 * @generated
	 */
	ObjectClass getObjectClass();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.data.ObjectInstance#getObjectClass <em>Object Class</em>}' reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Object Class</em>' reference.
	 * @see #getObjectClass()
	 * @generated
	 */
	void setObjectClass(ObjectClass value);

	/**
	 * Returns the value of the '<em><b>Registering Federate</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link org.eodisp.hla.crc.data.Federate#getRegisteredObjectInstances <em>Registered Object Instances</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Registering Federate</em>' container
	 * reference isn't clear, there really should be more of a description
	 * here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Registering Federate</em>' container reference.
	 * @see #setRegisteringFederate(Federate)
	 * @see org.eodisp.hla.crc.data.DataPackage#getObjectInstance_RegisteringFederate()
	 * @see org.eodisp.hla.crc.data.Federate#getRegisteredObjectInstances
	 * @model opposite="registeredObjectInstances"
	 * @generated
	 */
	Federate getRegisteringFederate();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.data.ObjectInstance#getRegisteringFederate <em>Registering Federate</em>}' container reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Registering Federate</em>' container reference.
	 * @see #getRegisteringFederate()
	 * @generated
	 */
	void setRegisteringFederate(Federate value);

	/**
	 * Returns the value of the '<em><b>Handle</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Handle</em>' attribute isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Handle</em>' attribute.
	 * @see #setHandle(ObjectInstanceHandle)
	 * @see org.eodisp.hla.crc.data.DataPackage#getObjectInstance_Handle()
	 * @model dataType="org.eodisp.hla.crc.data.EObjectInstanceHandle"
	 *        required="true"
	 * @generated
	 */
	ObjectInstanceHandle getHandle();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.data.ObjectInstance#getHandle <em>Handle</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Handle</em>' attribute.
	 * @see #getHandle()
	 * @generated
	 */
	void setHandle(ObjectInstanceHandle value);

} // ObjectInstance
