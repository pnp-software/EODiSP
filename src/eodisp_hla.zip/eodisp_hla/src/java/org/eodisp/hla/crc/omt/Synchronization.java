/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt;

import java.util.List;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Synchronization</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.Synchronization#getCapability <em>Capability</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Synchronization#getCapabilityNotes <em>Capability Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Synchronization#getDataType <em>Data Type</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Synchronization#getDataTypeNotes <em>Data Type Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Synchronization#getLabel <em>Label</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Synchronization#getLabelNotes <em>Label Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Synchronization#getSemantics <em>Semantics</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Synchronization#getSemanticsNotes <em>Semantics Notes</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eodisp.hla.crc.omt.OmtPackage#getSynchronization()
 * @model extendedMetaData="name='Synchronization' kind='empty'"
 * @generated
 */
public interface Synchronization extends EObject {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * Returns the value of the '<em><b>Capability</b></em>' attribute. The
	 * default value is <code>"Register"</code>. The literals are from the
	 * enumeration {@link org.eodisp.hla.crc.omt.SyncCapabilityEnum}. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Capability</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Capability</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.SyncCapabilityEnum
	 * @see #isSetCapability()
	 * @see #unsetCapability()
	 * @see #setCapability(SyncCapabilityEnum)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSynchronization_Capability()
	 * @model default="Register" unique="false" unsettable="true"
	 *        extendedMetaData="kind='attribute' name='capability'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	SyncCapabilityEnum getCapability();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Synchronization#getCapability <em>Capability</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Capability</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.SyncCapabilityEnum
	 * @see #isSetCapability()
	 * @see #unsetCapability()
	 * @see #getCapability()
	 * @generated
	 */
	void setCapability(SyncCapabilityEnum value);

	/**
	 * Unsets the value of the '{@link org.eodisp.hla.crc.omt.Synchronization#getCapability <em>Capability</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #isSetCapability()
	 * @see #getCapability()
	 * @see #setCapability(SyncCapabilityEnum)
	 * @generated
	 */
	void unsetCapability();

	/**
	 * Returns whether the value of the '{@link org.eodisp.hla.crc.omt.Synchronization#getCapability <em>Capability</em>}' attribute is set.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return whether the value of the '<em>Capability</em>' attribute is set.
	 * @see #unsetCapability()
	 * @see #getCapability()
	 * @see #setCapability(SyncCapabilityEnum)
	 * @generated
	 */
	boolean isSetCapability();

	/**
	 * Returns the value of the '<em><b>Capability Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Capability Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Capability Notes</em>' attribute.
	 * @see #setCapabilityNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSynchronization_CapabilityNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='capabilityNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getCapabilityNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Synchronization#getCapabilityNotes <em>Capability Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Capability Notes</em>' attribute.
	 * @see #getCapabilityNotes()
	 * @generated
	 */
	void setCapabilityNotes(List value);

	/**
	 * Returns the value of the '<em><b>Data Type</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Data Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Data Type</em>' attribute.
	 * @see #setDataType(String)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSynchronization_DataType()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKEN"
	 *        extendedMetaData="kind='attribute' name='dataType'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	String getDataType();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Synchronization#getDataType <em>Data Type</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Data Type</em>' attribute.
	 * @see #getDataType()
	 * @generated
	 */
	void setDataType(String value);

	/**
	 * Returns the value of the '<em><b>Data Type Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Data Type Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Data Type Notes</em>' attribute.
	 * @see #setDataTypeNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSynchronization_DataTypeNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='dataTypeNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getDataTypeNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Synchronization#getDataTypeNotes <em>Data Type Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Data Type Notes</em>' attribute.
	 * @see #getDataTypeNotes()
	 * @generated
	 */
	void setDataTypeNotes(List value);

	/**
	 * Returns the value of the '<em><b>Label</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Label</em>' attribute isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Label</em>' attribute.
	 * @see #setLabel(String)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSynchronization_Label()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKEN"
	 *        required="true" extendedMetaData="kind='attribute' name='label'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	String getLabel();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Synchronization#getLabel <em>Label</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Label</em>' attribute.
	 * @see #getLabel()
	 * @generated
	 */
	void setLabel(String value);

	/**
	 * Returns the value of the '<em><b>Label Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Label Notes</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Label Notes</em>' attribute.
	 * @see #setLabelNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSynchronization_LabelNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='labelNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getLabelNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Synchronization#getLabelNotes <em>Label Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Label Notes</em>' attribute.
	 * @see #getLabelNotes()
	 * @generated
	 */
	void setLabelNotes(List value);

	/**
	 * Returns the value of the '<em><b>Semantics</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Semantics</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Semantics</em>' attribute.
	 * @see #setSemantics(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSynchronization_Semantics()
	 * @model unique="false"
	 *        dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='semantics'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	Object getSemantics();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Synchronization#getSemantics <em>Semantics</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Semantics</em>' attribute.
	 * @see #getSemantics()
	 * @generated
	 */
	void setSemantics(Object value);

	/**
	 * Returns the value of the '<em><b>Semantics Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Semantics Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Semantics Notes</em>' attribute.
	 * @see #setSemanticsNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSynchronization_SemanticsNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='semanticsNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSemanticsNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Synchronization#getSemanticsNotes <em>Semantics Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Semantics Notes</em>' attribute.
	 * @see #getSemanticsNotes()
	 * @generated
	 */
	void setSemanticsNotes(List value);

} // Synchronization
