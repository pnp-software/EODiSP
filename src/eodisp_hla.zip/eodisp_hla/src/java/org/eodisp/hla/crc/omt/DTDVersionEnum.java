/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.AbstractEnumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>DTD Version Enum</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see org.eodisp.hla.crc.omt.OmtPackage#getDTDVersionEnum()
 * @model
 * @generated
 */
public final class DTDVersionEnum extends AbstractEnumerator {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The '<em><b>15162</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>15162</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #_15162_LITERAL
	 * @model literal="1516.2"
	 * @generated
	 * @ordered
	 */
	public static final int _15162 = 0;

	/**
	 * The '<em><b>15162</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #_15162
	 * @generated
	 * @ordered
	 */
	public static final DTDVersionEnum _15162_LITERAL = new DTDVersionEnum(_15162, "_15162", "1516.2");

	/**
	 * An array of all the '<em><b>DTD Version Enum</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final DTDVersionEnum[] VALUES_ARRAY = new DTDVersionEnum[] { _15162_LITERAL, };

	/**
	 * A public read-only list of all the '<em><b>DTD Version Enum</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>DTD Version Enum</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static DTDVersionEnum get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			DTDVersionEnum result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>DTD Version Enum</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static DTDVersionEnum getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			DTDVersionEnum result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>DTD Version Enum</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static DTDVersionEnum get(int value) {
		switch (value) {
		case _15162:
			return _15162_LITERAL;
		}
		return null;
	}

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private DTDVersionEnum(int value, String name, String literal) {
		super(value, name, literal);
	}

} //DTDVersionEnum
