/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.hla.util;

import java.util.*;

import org.eodisp.hla.crc.omt.*;

public class OmtModel {
	private Map<ObjectClass, Integer> objectClassIndex = new IdentityHashMap<ObjectClass, Integer>();

	private Map<InteractionClass, Integer> interactionClassIndex = new IdentityHashMap<InteractionClass, Integer>();

	public OmtModel(ObjectModel objectModel) {
		final Objects objects = objectModel.getObjects();
		if (objects != null) {
			List<ObjectClass> allObjectClasses = objects.getAllObjectClasses();
			int i = 0;
			for (ObjectClass class1 : allObjectClasses) {
				objectClassIndex.put(class1, new Integer(i++));
			}
		}

		
		final Interactions interactions = objectModel.getInteractions();
		if (interactions != null) {
			List<InteractionClass> allInteractionClasses = interactions.getAllInteractionClasses();
			int i = 0;
			for (InteractionClass class1 : allInteractionClasses) {
				interactionClassIndex.put(class1, new Integer(i++));
			}
		}
	}

	public int getIndex(ObjectClass objectClass) {
		return objectClassIndex.get(objectClass).intValue();
	}

	public int getIndex(InteractionClass interaction) {
		return interactionClassIndex.get(interaction).intValue();
	}

	public Set<ObjectClass> getAllObjectClasses() {
		return objectClassIndex.keySet();
	}

	public Set<InteractionClass> getAllInteractionClasses() {
		return interactionClassIndex.keySet();
	}

	public static String getSharingString(Attribute attribute) {
		return getSharingString(attribute.getSharing().getValue());
	}

	public static String getSharingString(InteractionClass interactionClass) {
		return getSharingString(interactionClass.getSharing().getValue());
	}

	public static String getSharingString(ObjectClass objectClass) {
		return getSharingString(objectClass.getSharing().getValue());
	}

	/**
	 * @param value
	 * @return
	 */
	private static String getSharingString(int value) {
		switch (value) {
		case SharingEnum.NEITHER:
			return "N";
		case SharingEnum.SUBSCRIBE:
			return "S";
		case SharingEnum.PUBLISH:
			return "P";
		case SharingEnum.PUBLISH_SUBSCRIBE:
			return "PS";

		default:
			return "ERROR";
		}
	}
}