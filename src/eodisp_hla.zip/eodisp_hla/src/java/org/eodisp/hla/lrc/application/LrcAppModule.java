/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.hla.lrc.application;

import java.io.File;

import org.eodisp.hla.common.lrc.LrcRemote;
import org.eodisp.hla.lrc.Lrc;
import org.eodisp.hla.lrc.LrcRemoteImpl;
import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.util.AppModule;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.RootApp;
import org.eodisp.util.configuration.BasicSystemPropertyMapper;
import org.eodisp.util.configuration.CommandlineMapper;

/**
 * Application module for the central RTI component.
 * 
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class LrcAppModule implements AppModule {

	/**
	 * The Id of this Application Module.
	 */
	public static final String ID = LrcAppModule.class.getName();

	private Lrc lrc;

	/**
	 * {@inheritDoc}
	 */
	public String getId() {
		return ID;
	}

	/**
	 * {@inheritDoc}
	 */
	public void registerConfiguration(RootApp rootApp) throws Exception {
		LrcConfiguration lrcConfiguration = new LrcConfiguration(new File(rootApp.getConfigurationDir(), "lrc.conf"));
		rootApp.registerConfiguration(
				lrcConfiguration,
				CommandlineMapper.NULL_COMMAND_LINE_MAPPER,
				new BasicSystemPropertyMapper("org.eodisp.hla.lrc."));
	}

	/**
	 * {@inheritDoc}
	 */
	public void startup(RootApp rootApp) throws Exception {
		lrc = new Lrc();
		LrcRemote lrcRemoteImpl = new LrcRemoteImpl(lrc);
		RemoteAppModule remoteAppModule = (RemoteAppModule) rootApp.getAppModule(RemoteAppModule.ID);
		remoteAppModule.exportAndRegister(lrcRemoteImpl, LrcRemote.REGISTRY_NAME);
	}

	/**
	 * {@inheritDoc}
	 */
	public void shutdown(RootApp rootApp) throws Exception {
		RemoteAppModule remoteAppModule = (RemoteAppModule) rootApp.getAppModule(RemoteAppModule.ID);
		remoteAppModule.getRegistry().unbind(LrcRemote.REGISTRY_NAME);
	}

	/**
	 * {@inheritDoc}
	 */
	public void postShutdown(RootApp rootApp) throws Exception {
	}

	public Lrc getLrc() {
		return lrc;
	}

	public void preStartup(RootApp rootApp) throws Exception {
		// TODO Auto-generated method stub
		
	}
}
