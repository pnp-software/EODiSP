/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.hla.crc;

import hla.rti1516.*;

import java.rmi.server.ExportException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import net.jcip.annotations.ThreadSafe;

import org.apache.log4j.Logger;
import org.eodisp.hla.common.lrc.LrcHandle;
import org.eodisp.hla.common.lrc.LrcRemote;

/**
 * This class implements the basic functionality of the Central RTI Component
 * (RTI).
 * 
 * @author ibirrer
 * @version $Id: Crc.java 4379 2006-11-02 00:36:39Z ibirrer $
 * 
 * @UML -------------------------------------------------------------------
 * 
 * 
 * @stereotype singleton
 * @composed - federationExecutions 0..* FederationExecution
 */
@ThreadSafe
public class Crc {

	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	static Logger logger = Logger.getLogger(Crc.class);

	private final ConcurrentHashMap<LrcHandle, LrcRemote> registeredLrcs = new ConcurrentHashMap<LrcHandle, LrcRemote>();

	private final AtomicInteger nextLrcHandle = new AtomicInteger(0);

	/**
	 * Currently created federation executions
	 */
	private final Map<String, FederationExecution> federationExecutions = new HashMap<String, FederationExecution>();

	/**
	 * Creates a new federation execution. Implements HLA service 4.2 (See IEEE
	 * Std 1516.1-2000).
	 * 
	 * @param federationExecutionName
	 *            the name of the federation execution
	 * @param fdd
	 *            the federation object model (FOM)
	 * @return a reference to the new federation execution
	 * @throws FederationExecutionAlreadyExists
	 *             if a federation execution with the same name has been created
	 *             before
	 * @throws ErrorReadingFDD
	 *             if the given FDD has errors.
	 * @throws NullPointerException
	 *             if <code>federationExecutionName</code> or <code>fdd</code>
	 *             is null.
	 * @throws ExportException
	 * 
	 * @prio 1
	 */
	synchronized FederationExecution createFederationExecution(String federationExecutionName, byte[] fdd)
			throws FederationExecutionAlreadyExists, ErrorReadingFDD {
		if (federationExecutionName == null || fdd == null) {
			throw new NullPointerException("federationExecutionName and fdd must not be null");
		}

		if (federationExecutions.containsKey(federationExecutionName)) {
			throw new FederationExecutionAlreadyExists("A federation execution with the name "
					+ federationExecutionName + " already exists.");
		}

		FederationExecution federationExecution = new FederationExecution(federationExecutionName, fdd);
		federationExecutions.put(federationExecutionName, federationExecution);
		logger.debug("Created and registered federation execution: " + federationExecutionName);
		return federationExecution;
	}

	/**
	 * Returns the federation execution with the given name.
	 * 
	 * @param federationExecutionName
	 *            the name of the federation execution
	 * @return the federation execution with the given name or null if there is
	 *         no federation execution associated with the given name.
	 */
	synchronized FederationExecution getFederationExecution(String federationExecutionName) {
		return federationExecutions.get(federationExecutionName);
	}

	/**
	 * Implements HLA service 4.3 (See IEEE Std 1516.1-2000).
	 * 
	 * @param federationExecutionName
	 *            the name of the federation execution to be destroyed
	 * @throws FederatesCurrentlyJoined
	 *             if there are still federates joined to the the federation
	 *             execution with the given name
	 * @throws FederationExecutionDoesNotExist
	 *             If a federation execution with the given name does not exist
	 * @prio 1
	 */
	synchronized void destroyFederationExecution(String federationExecutionName) throws FederatesCurrentlyJoined,
			FederationExecutionDoesNotExist {
		if (!federationExecutions.containsKey(federationExecutionName)) {
			throw new FederationExecutionDoesNotExist("A federation execution with the name " + federationExecutionName
					+ " does not exist.");
		}

		if (federationExecutions.get(federationExecutionName).getNrOfJoinedFederates() != 0) {
			throw new FederatesCurrentlyJoined(String.format(
					"Federation Execution '%s' cannot be destroyed because there are still federates joined to it.",
					federationExecutionName));
		}
		logger.debug(String.format("Destroyed federation execution %s", federationExecutionName));
		FederationExecution federationExecution = federationExecutions.remove(federationExecutionName);
		federationExecution.unexport();
	}

	synchronized FederateHandle joinFederationExecution(String federationExecutionName, String federateType,
			LrcHandle lrcHandle, MobileFederateServices serviceReferences) throws FederationExecutionDoesNotExist {
		if (!federationExecutions.containsKey(federationExecutionName)) {
			throw new FederationExecutionDoesNotExist("A federation execution with the name " + federationExecutionName
					+ " does not exist.");
		}
		FederationExecution federationExecution = federationExecutions.get(federationExecutionName);
		return federationExecution.join(federateType, lrcHandle, serviceReferences);
	}

	/**
	 * @param lrcHandle
	 * @return users of this method should always check the return value for
	 *         <code>null</code>!
	 */
	LrcRemote getLrcRemote(LrcHandle lrcHandle) {
		return registeredLrcs.get(lrcHandle);
		// if( lrcRemote == null ) {
		// logger.error( String.format("Could not find lrcRemote proxy for
		// lrcHandle [%s] on CRC", lrcHandle) );
		// }
		// return lrcRemote;
	}

	LrcHandle registerLrc(LrcRemote lrcRemote) {
		LrcHandle lrcHandle = new LrcHandle(nextLrcHandle.incrementAndGet());
		registeredLrcs.put(lrcHandle, lrcRemote);
		logger.debug(String.format("Registered LRC [%s] with handle [%s]", lrcRemote, lrcHandle));
		return lrcHandle;
	}

	void unregisterLrc(LrcHandle lrcHandle) {
		logger.debug(String.format("Unregister LRC [%s] with handle [%s]", getLrcRemote(lrcHandle), lrcHandle));
		registeredLrcs.remove(lrcHandle);
	}

	/**
	 * Destroys all federation executions. Use for testing only, it does not
	 * inform federates about destroying the federation executions but just
	 * clears the map of current federation executions!
	 * 
	 * @deprecated Use for testing only!
	 */
	synchronized void destroyAllFederationExecutions() {
		federationExecutions.clear();
	}

	/**
	 * @deprecated Use for testing only!
	 */
	synchronized void reset() {
		logger.debug("Reset CRC");
		for (FederationExecution federationExecution : federationExecutions.values()) {
			federationExecution.reset();
		}
		federationExecutions.clear();
		nextLrcHandle.set(0);
		registeredLrcs.clear();
	}
}
