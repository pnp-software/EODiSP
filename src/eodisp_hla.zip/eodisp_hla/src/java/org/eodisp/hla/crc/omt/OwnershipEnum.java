/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.AbstractEnumerator;

/**
 * <!-- begin-user-doc --> A representation of the literals of the enumeration '<em><b>Ownership Enum</b></em>',
 * and utility methods for working with them. <!-- end-user-doc -->
 * @see org.eodisp.hla.crc.omt.OmtPackage#getOwnershipEnum()
 * @model
 * @generated
 */
public final class OwnershipEnum extends AbstractEnumerator {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The '<em><b>Divest</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Divest</b></em>' literal object isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #DIVEST_LITERAL
	 * @model name="Divest"
	 * @generated
	 * @ordered
	 */
	public static final int DIVEST = 0;

	/**
	 * The '<em><b>Acquire</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Acquire</b></em>' literal object isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #ACQUIRE_LITERAL
	 * @model name="Acquire"
	 * @generated
	 * @ordered
	 */
	public static final int ACQUIRE = 1;

	/**
	 * The '<em><b>Divest Acquire</b></em>' literal value. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Divest Acquire</b></em>' literal object
	 * isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @see #DIVEST_ACQUIRE_LITERAL
	 * @model name="DivestAcquire"
	 * @generated
	 * @ordered
	 */
	public static final int DIVEST_ACQUIRE = 2;

	/**
	 * The '<em><b>No Transfer</b></em>' literal value.
	 * <!-- begin-user-doc
	 * -->
	 * <p>
	 * If the meaning of '<em><b>No Transfer</b></em>' literal object isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #NO_TRANSFER_LITERAL
	 * @model name="NoTransfer"
	 * @generated
	 * @ordered
	 */
	public static final int NO_TRANSFER = 3;

	/**
	 * The '<em><b>Divest</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #DIVEST
	 * @generated
	 * @ordered
	 */
	public static final OwnershipEnum DIVEST_LITERAL = new OwnershipEnum(DIVEST, "Divest", "Divest");

	/**
	 * The '<em><b>Acquire</b></em>' literal object.
	 * <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * @see #ACQUIRE
	 * @generated
	 * @ordered
	 */
	public static final OwnershipEnum ACQUIRE_LITERAL = new OwnershipEnum(ACQUIRE, "Acquire", "Acquire");

	/**
	 * The '<em><b>Divest Acquire</b></em>' literal object. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #DIVEST_ACQUIRE
	 * @generated
	 * @ordered
	 */
	public static final OwnershipEnum DIVEST_ACQUIRE_LITERAL = new OwnershipEnum(
			DIVEST_ACQUIRE,
			"DivestAcquire",
			"DivestAcquire");

	/**
	 * The '<em><b>No Transfer</b></em>' literal object. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #NO_TRANSFER
	 * @generated
	 * @ordered
	 */
	public static final OwnershipEnum NO_TRANSFER_LITERAL = new OwnershipEnum(NO_TRANSFER, "NoTransfer", "NoTransfer");

	/**
	 * An array of all the '<em><b>Ownership Enum</b></em>' enumerators.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	private static final OwnershipEnum[] VALUES_ARRAY = new OwnershipEnum[] { DIVEST_LITERAL, ACQUIRE_LITERAL,
			DIVEST_ACQUIRE_LITERAL, NO_TRANSFER_LITERAL, };

	/**
	 * A public read-only list of all the '<em><b>Ownership Enum</b></em>' enumerators.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public static final List VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Ownership Enum</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public static OwnershipEnum get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			OwnershipEnum result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Ownership Enum</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static OwnershipEnum getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			OwnershipEnum result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Ownership Enum</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public static OwnershipEnum get(int value) {
		switch (value) {
		case DIVEST:
			return DIVEST_LITERAL;
		case ACQUIRE:
			return ACQUIRE_LITERAL;
		case DIVEST_ACQUIRE:
			return DIVEST_ACQUIRE_LITERAL;
		case NO_TRANSFER:
			return NO_TRANSFER_LITERAL;
		}
		return null;
	}

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private OwnershipEnum(int value, String name, String literal) {
		super(value, name, literal);
	}

} // OwnershipEnum
