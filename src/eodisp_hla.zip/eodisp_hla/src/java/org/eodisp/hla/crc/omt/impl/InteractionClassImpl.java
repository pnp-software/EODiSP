/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt.impl;

import hla.rti1516.InteractionClassHandle;
import hla.rti1516.ObjectClassHandle;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.eodisp.hla.crc.data.DataPackage;
import org.eodisp.hla.crc.data.Federate;

import org.eodisp.hla.crc.omt.InteractionClass;
import org.eodisp.hla.crc.omt.OmtPackage;
import org.eodisp.hla.crc.omt.OrderEnum;
import org.eodisp.hla.crc.omt.Parameter;
import org.eodisp.hla.crc.omt.SharingEnum;

import org.eodisp.hla.crc.omt.*;

import org.eodisp.hla.crc.omt.*;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Interaction Class</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.InteractionClassImpl#getParameters <em>Parameters</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.InteractionClassImpl#getSubClasses <em>Sub Classes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.InteractionClassImpl#getDimensions <em>Dimensions</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.InteractionClassImpl#getDimensionsNotes <em>Dimensions Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.InteractionClassImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.InteractionClassImpl#getNameNotes <em>Name Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.InteractionClassImpl#getOrder <em>Order</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.InteractionClassImpl#getOrderNotes <em>Order Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.InteractionClassImpl#getSemantics <em>Semantics</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.InteractionClassImpl#getSemanticsNotes <em>Semantics Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.InteractionClassImpl#getSharing <em>Sharing</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.InteractionClassImpl#getSharingNotes <em>Sharing Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.InteractionClassImpl#getTransportation <em>Transportation</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.InteractionClassImpl#getTransportationNotes <em>Transportation Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.InteractionClassImpl#getSubscribingFederates <em>Subscribing Federates</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.InteractionClassImpl#getPublishingFederates <em>Publishing Federates</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class InteractionClassImpl extends EObjectImpl implements InteractionClass {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The cached value of the '{@link #getParameters() <em>Parameters</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getParameters()
	 * @generated
	 * @ordered
	 */
	protected EList parameters = null;

	/**
	 * The cached value of the '{@link #getSubClasses() <em>Sub Classes</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSubClasses()
	 * @generated
	 * @ordered
	 */
	protected EList subClasses = null;

	/**
	 * The default value of the '{@link #getDimensions() <em>Dimensions</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDimensions()
	 * @generated
	 * @ordered
	 */
	protected static final List DIMENSIONS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDimensions() <em>Dimensions</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDimensions()
	 * @generated
	 * @ordered
	 */
	protected List dimensions = DIMENSIONS_EDEFAULT;

	/**
	 * The default value of the '{@link #getDimensionsNotes() <em>Dimensions Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDimensionsNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List DIMENSIONS_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDimensionsNotes() <em>Dimensions Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDimensionsNotes()
	 * @generated
	 * @ordered
	 */
	protected List dimensionsNotes = DIMENSIONS_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getNameNotes() <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getNameNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List NAME_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNameNotes() <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getNameNotes()
	 * @generated
	 * @ordered
	 */
	protected List nameNotes = NAME_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getOrder() <em>Order</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getOrder()
	 * @generated
	 * @ordered
	 */
	protected static final OrderEnum ORDER_EDEFAULT = OrderEnum.RECEIVE_LITERAL;

	/**
	 * The cached value of the '{@link #getOrder() <em>Order</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getOrder()
	 * @generated
	 * @ordered
	 */
	protected OrderEnum order = ORDER_EDEFAULT;

	/**
	 * This is true if the Order attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean orderESet = false;

	/**
	 * The default value of the '{@link #getOrderNotes() <em>Order Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getOrderNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List ORDER_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getOrderNotes() <em>Order Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getOrderNotes()
	 * @generated
	 * @ordered
	 */
	protected List orderNotes = ORDER_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getSemantics() <em>Semantics</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSemantics()
	 * @generated
	 * @ordered
	 */
	protected static final Object SEMANTICS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSemantics() <em>Semantics</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSemantics()
	 * @generated
	 * @ordered
	 */
	protected Object semantics = SEMANTICS_EDEFAULT;

	/**
	 * The default value of the '{@link #getSemanticsNotes() <em>Semantics Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSemanticsNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List SEMANTICS_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSemanticsNotes() <em>Semantics Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSemanticsNotes()
	 * @generated
	 * @ordered
	 */
	protected List semanticsNotes = SEMANTICS_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getSharing() <em>Sharing</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSharing()
	 * @generated
	 * @ordered
	 */
	protected static final SharingEnum SHARING_EDEFAULT = SharingEnum.PUBLISH_LITERAL;

	/**
	 * The cached value of the '{@link #getSharing() <em>Sharing</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSharing()
	 * @generated
	 * @ordered
	 */
	protected SharingEnum sharing = SHARING_EDEFAULT;

	/**
	 * This is true if the Sharing attribute has been set.
	 * <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean sharingESet = false;

	/**
	 * The default value of the '{@link #getSharingNotes() <em>Sharing Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSharingNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List SHARING_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSharingNotes() <em>Sharing Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSharingNotes()
	 * @generated
	 * @ordered
	 */
	protected List sharingNotes = SHARING_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getTransportation() <em>Transportation</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getTransportation()
	 * @generated
	 * @ordered
	 */
	protected static final String TRANSPORTATION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTransportation() <em>Transportation</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getTransportation()
	 * @generated
	 * @ordered
	 */
	protected String transportation = TRANSPORTATION_EDEFAULT;

	/**
	 * The default value of the '{@link #getTransportationNotes() <em>Transportation Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getTransportationNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List TRANSPORTATION_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTransportationNotes() <em>Transportation Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getTransportationNotes()
	 * @generated
	 * @ordered
	 */
	protected List transportationNotes = TRANSPORTATION_NOTES_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSubscribingFederates() <em>Subscribing Federates</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSubscribingFederates()
	 * @generated
	 * @ordered
	 */
	protected EList subscribingFederates = null;

	/**
	 * The cached value of the '{@link #getPublishingFederates() <em>Publishing Federates</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPublishingFederates()
	 * @generated
	 * @ordered
	 */
	protected EList publishingFederates = null;

	/**
	 * This object class's handle
	 */
	private InteractionClassHandle handle = null;

	/** 
	 * {@inheritDoc}
	 */
	public InteractionClassHandle getHandle() {
		return handle;
	}

	/** 
	 * {@inheritDoc}
	 */
	public void setHandle(InteractionClassHandle interactionClassHandle) {
		this.handle = interactionClassHandle;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected InteractionClassImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return OmtPackage.Literals.INTERACTION_CLASS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getParameters() {
		if (parameters == null) {
			parameters = new EObjectContainmentEList(Parameter.class, this, OmtPackage.INTERACTION_CLASS__PARAMETERS);
		}
		return parameters;
	}

	/** 
	 * {@inheritDoc}
	 * @generated not
	 */
	public List getAllParameters() {
		List allParameters = new ArrayList();
		InteractionClass parent = this;
		while (parent != null) {
			allParameters.addAll(parent.getParameters());
			parent = parent.getSuperClass();
		}
		return allParameters;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getSubClasses() {
		if (subClasses == null) {
			subClasses = new EObjectContainmentEList(
					InteractionClass.class,
					this,
					OmtPackage.INTERACTION_CLASS__SUB_CLASSES);
		}
		return subClasses;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getDimensions() {
		return dimensions;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setDimensions(List newDimensions) {
		List oldDimensions = dimensions;
		dimensions = newDimensions;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.INTERACTION_CLASS__DIMENSIONS,
					oldDimensions,
					dimensions));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getDimensionsNotes() {
		return dimensionsNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setDimensionsNotes(List newDimensionsNotes) {
		List oldDimensionsNotes = dimensionsNotes;
		dimensionsNotes = newDimensionsNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.INTERACTION_CLASS__DIMENSIONS_NOTES,
					oldDimensionsNotes,
					dimensionsNotes));
	}

	/** 
	 * {@inheritDoc}
	 */
	public InteractionClass getSuperClass() {
		if (eContainer instanceof InteractionClass) {
			return (InteractionClass) eContainer();
		}
		return null;
	}

	/** 
	 * {@inheritDoc}
	 */
	public List<InteractionClass> getAllSuperClasses() {
		List<InteractionClass> allSuperClasses = new ArrayList<InteractionClass>();
		InteractionClass superClass = getSuperClass();
		while (superClass != null) {
			allSuperClasses.add(0, superClass);
			superClass = superClass.getSuperClass();
		}
		return allSuperClasses;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/** 
	 * {@inheritDoc}
	 */
	public String getQualifiedName(boolean omitInteractionRoot) {
		StringBuilder builder = new StringBuilder();
		List<InteractionClass> allSuperClasses = getAllSuperClasses();
		allSuperClasses.add(this);

		int index = 0;
		if (omitInteractionRoot) {
			index = 1;
		}
		for (; index < allSuperClasses.size(); index++) {
			builder.append(allSuperClasses.get(index).getName());
			if ((index + 1) < allSuperClasses.size()) {
				builder.append(".");
			}
		}
		return builder.toString();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OmtPackage.INTERACTION_CLASS__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getNameNotes() {
		return nameNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setNameNotes(List newNameNotes) {
		List oldNameNotes = nameNotes;
		nameNotes = newNameNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.INTERACTION_CLASS__NAME_NOTES,
					oldNameNotes,
					nameNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public OrderEnum getOrder() {
		return order;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setOrder(OrderEnum newOrder) {
		OrderEnum oldOrder = order;
		order = newOrder == null ? ORDER_EDEFAULT : newOrder;
		boolean oldOrderESet = orderESet;
		orderESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.INTERACTION_CLASS__ORDER,
					oldOrder,
					order,
					!oldOrderESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetOrder() {
		OrderEnum oldOrder = order;
		boolean oldOrderESet = orderESet;
		order = ORDER_EDEFAULT;
		orderESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.UNSET,
					OmtPackage.INTERACTION_CLASS__ORDER,
					oldOrder,
					ORDER_EDEFAULT,
					oldOrderESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetOrder() {
		return orderESet;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getOrderNotes() {
		return orderNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setOrderNotes(List newOrderNotes) {
		List oldOrderNotes = orderNotes;
		orderNotes = newOrderNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.INTERACTION_CLASS__ORDER_NOTES,
					oldOrderNotes,
					orderNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getSemantics() {
		return semantics;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setSemantics(Object newSemantics) {
		Object oldSemantics = semantics;
		semantics = newSemantics;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.INTERACTION_CLASS__SEMANTICS,
					oldSemantics,
					semantics));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getSemanticsNotes() {
		return semanticsNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setSemanticsNotes(List newSemanticsNotes) {
		List oldSemanticsNotes = semanticsNotes;
		semanticsNotes = newSemanticsNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.INTERACTION_CLASS__SEMANTICS_NOTES,
					oldSemanticsNotes,
					semanticsNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public SharingEnum getSharing() {
		return sharing;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setSharing(SharingEnum newSharing) {
		SharingEnum oldSharing = sharing;
		sharing = newSharing == null ? SHARING_EDEFAULT : newSharing;
		boolean oldSharingESet = sharingESet;
		sharingESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.INTERACTION_CLASS__SHARING,
					oldSharing,
					sharing,
					!oldSharingESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetSharing() {
		SharingEnum oldSharing = sharing;
		boolean oldSharingESet = sharingESet;
		sharing = SHARING_EDEFAULT;
		sharingESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.UNSET,
					OmtPackage.INTERACTION_CLASS__SHARING,
					oldSharing,
					SHARING_EDEFAULT,
					oldSharingESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetSharing() {
		return sharingESet;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getSharingNotes() {
		return sharingNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setSharingNotes(List newSharingNotes) {
		List oldSharingNotes = sharingNotes;
		sharingNotes = newSharingNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.INTERACTION_CLASS__SHARING_NOTES,
					oldSharingNotes,
					sharingNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String getTransportation() {
		return transportation;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setTransportation(String newTransportation) {
		String oldTransportation = transportation;
		transportation = newTransportation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.INTERACTION_CLASS__TRANSPORTATION,
					oldTransportation,
					transportation));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getTransportationNotes() {
		return transportationNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setTransportationNotes(List newTransportationNotes) {
		List oldTransportationNotes = transportationNotes;
		transportationNotes = newTransportationNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.INTERACTION_CLASS__TRANSPORTATION_NOTES,
					oldTransportationNotes,
					transportationNotes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getSubscribingFederates() {
		if (subscribingFederates == null) {
			subscribingFederates = new EObjectWithInverseResolvingEList.ManyInverse(
					Federate.class,
					this,
					OmtPackage.INTERACTION_CLASS__SUBSCRIBING_FEDERATES,
					DataPackage.FEDERATE__SUBSCRIBED_INTERACTIONS);
		}
		return subscribingFederates;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getPublishingFederates() {
		if (publishingFederates == null) {
			publishingFederates = new EObjectWithInverseResolvingEList.ManyInverse(
					Federate.class,
					this,
					OmtPackage.INTERACTION_CLASS__PUBLISHING_FEDERATES,
					DataPackage.FEDERATE__PUBLISHED_INTERACTIONS);
		}
		return publishingFederates;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case OmtPackage.INTERACTION_CLASS__SUBSCRIBING_FEDERATES:
			return ((InternalEList) getSubscribingFederates()).basicAdd(otherEnd, msgs);
		case OmtPackage.INTERACTION_CLASS__PUBLISHING_FEDERATES:
			return ((InternalEList) getPublishingFederates()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case OmtPackage.INTERACTION_CLASS__PARAMETERS:
			return ((InternalEList) getParameters()).basicRemove(otherEnd, msgs);
		case OmtPackage.INTERACTION_CLASS__SUB_CLASSES:
			return ((InternalEList) getSubClasses()).basicRemove(otherEnd, msgs);
		case OmtPackage.INTERACTION_CLASS__SUBSCRIBING_FEDERATES:
			return ((InternalEList) getSubscribingFederates()).basicRemove(otherEnd, msgs);
		case OmtPackage.INTERACTION_CLASS__PUBLISHING_FEDERATES:
			return ((InternalEList) getPublishingFederates()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case OmtPackage.INTERACTION_CLASS__PARAMETERS:
			return getParameters();
		case OmtPackage.INTERACTION_CLASS__SUB_CLASSES:
			return getSubClasses();
		case OmtPackage.INTERACTION_CLASS__DIMENSIONS:
			return getDimensions();
		case OmtPackage.INTERACTION_CLASS__DIMENSIONS_NOTES:
			return getDimensionsNotes();
		case OmtPackage.INTERACTION_CLASS__NAME:
			return getName();
		case OmtPackage.INTERACTION_CLASS__NAME_NOTES:
			return getNameNotes();
		case OmtPackage.INTERACTION_CLASS__ORDER:
			return getOrder();
		case OmtPackage.INTERACTION_CLASS__ORDER_NOTES:
			return getOrderNotes();
		case OmtPackage.INTERACTION_CLASS__SEMANTICS:
			return getSemantics();
		case OmtPackage.INTERACTION_CLASS__SEMANTICS_NOTES:
			return getSemanticsNotes();
		case OmtPackage.INTERACTION_CLASS__SHARING:
			return getSharing();
		case OmtPackage.INTERACTION_CLASS__SHARING_NOTES:
			return getSharingNotes();
		case OmtPackage.INTERACTION_CLASS__TRANSPORTATION:
			return getTransportation();
		case OmtPackage.INTERACTION_CLASS__TRANSPORTATION_NOTES:
			return getTransportationNotes();
		case OmtPackage.INTERACTION_CLASS__SUBSCRIBING_FEDERATES:
			return getSubscribingFederates();
		case OmtPackage.INTERACTION_CLASS__PUBLISHING_FEDERATES:
			return getPublishingFederates();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case OmtPackage.INTERACTION_CLASS__PARAMETERS:
			getParameters().clear();
			getParameters().addAll((Collection) newValue);
			return;
		case OmtPackage.INTERACTION_CLASS__SUB_CLASSES:
			getSubClasses().clear();
			getSubClasses().addAll((Collection) newValue);
			return;
		case OmtPackage.INTERACTION_CLASS__DIMENSIONS:
			setDimensions((List) newValue);
			return;
		case OmtPackage.INTERACTION_CLASS__DIMENSIONS_NOTES:
			setDimensionsNotes((List) newValue);
			return;
		case OmtPackage.INTERACTION_CLASS__NAME:
			setName((String) newValue);
			return;
		case OmtPackage.INTERACTION_CLASS__NAME_NOTES:
			setNameNotes((List) newValue);
			return;
		case OmtPackage.INTERACTION_CLASS__ORDER:
			setOrder((OrderEnum) newValue);
			return;
		case OmtPackage.INTERACTION_CLASS__ORDER_NOTES:
			setOrderNotes((List) newValue);
			return;
		case OmtPackage.INTERACTION_CLASS__SEMANTICS:
			setSemantics((Object) newValue);
			return;
		case OmtPackage.INTERACTION_CLASS__SEMANTICS_NOTES:
			setSemanticsNotes((List) newValue);
			return;
		case OmtPackage.INTERACTION_CLASS__SHARING:
			setSharing((SharingEnum) newValue);
			return;
		case OmtPackage.INTERACTION_CLASS__SHARING_NOTES:
			setSharingNotes((List) newValue);
			return;
		case OmtPackage.INTERACTION_CLASS__TRANSPORTATION:
			setTransportation((String) newValue);
			return;
		case OmtPackage.INTERACTION_CLASS__TRANSPORTATION_NOTES:
			setTransportationNotes((List) newValue);
			return;
		case OmtPackage.INTERACTION_CLASS__SUBSCRIBING_FEDERATES:
			getSubscribingFederates().clear();
			getSubscribingFederates().addAll((Collection) newValue);
			return;
		case OmtPackage.INTERACTION_CLASS__PUBLISHING_FEDERATES:
			getPublishingFederates().clear();
			getPublishingFederates().addAll((Collection) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
		case OmtPackage.INTERACTION_CLASS__PARAMETERS:
			getParameters().clear();
			return;
		case OmtPackage.INTERACTION_CLASS__SUB_CLASSES:
			getSubClasses().clear();
			return;
		case OmtPackage.INTERACTION_CLASS__DIMENSIONS:
			setDimensions(DIMENSIONS_EDEFAULT);
			return;
		case OmtPackage.INTERACTION_CLASS__DIMENSIONS_NOTES:
			setDimensionsNotes(DIMENSIONS_NOTES_EDEFAULT);
			return;
		case OmtPackage.INTERACTION_CLASS__NAME:
			setName(NAME_EDEFAULT);
			return;
		case OmtPackage.INTERACTION_CLASS__NAME_NOTES:
			setNameNotes(NAME_NOTES_EDEFAULT);
			return;
		case OmtPackage.INTERACTION_CLASS__ORDER:
			unsetOrder();
			return;
		case OmtPackage.INTERACTION_CLASS__ORDER_NOTES:
			setOrderNotes(ORDER_NOTES_EDEFAULT);
			return;
		case OmtPackage.INTERACTION_CLASS__SEMANTICS:
			setSemantics(SEMANTICS_EDEFAULT);
			return;
		case OmtPackage.INTERACTION_CLASS__SEMANTICS_NOTES:
			setSemanticsNotes(SEMANTICS_NOTES_EDEFAULT);
			return;
		case OmtPackage.INTERACTION_CLASS__SHARING:
			unsetSharing();
			return;
		case OmtPackage.INTERACTION_CLASS__SHARING_NOTES:
			setSharingNotes(SHARING_NOTES_EDEFAULT);
			return;
		case OmtPackage.INTERACTION_CLASS__TRANSPORTATION:
			setTransportation(TRANSPORTATION_EDEFAULT);
			return;
		case OmtPackage.INTERACTION_CLASS__TRANSPORTATION_NOTES:
			setTransportationNotes(TRANSPORTATION_NOTES_EDEFAULT);
			return;
		case OmtPackage.INTERACTION_CLASS__SUBSCRIBING_FEDERATES:
			getSubscribingFederates().clear();
			return;
		case OmtPackage.INTERACTION_CLASS__PUBLISHING_FEDERATES:
			getPublishingFederates().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case OmtPackage.INTERACTION_CLASS__PARAMETERS:
			return parameters != null && !parameters.isEmpty();
		case OmtPackage.INTERACTION_CLASS__SUB_CLASSES:
			return subClasses != null && !subClasses.isEmpty();
		case OmtPackage.INTERACTION_CLASS__DIMENSIONS:
			return DIMENSIONS_EDEFAULT == null ? dimensions != null : !DIMENSIONS_EDEFAULT.equals(dimensions);
		case OmtPackage.INTERACTION_CLASS__DIMENSIONS_NOTES:
			return DIMENSIONS_NOTES_EDEFAULT == null ? dimensionsNotes != null : !DIMENSIONS_NOTES_EDEFAULT
					.equals(dimensionsNotes);
		case OmtPackage.INTERACTION_CLASS__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case OmtPackage.INTERACTION_CLASS__NAME_NOTES:
			return NAME_NOTES_EDEFAULT == null ? nameNotes != null : !NAME_NOTES_EDEFAULT.equals(nameNotes);
		case OmtPackage.INTERACTION_CLASS__ORDER:
			return isSetOrder();
		case OmtPackage.INTERACTION_CLASS__ORDER_NOTES:
			return ORDER_NOTES_EDEFAULT == null ? orderNotes != null : !ORDER_NOTES_EDEFAULT.equals(orderNotes);
		case OmtPackage.INTERACTION_CLASS__SEMANTICS:
			return SEMANTICS_EDEFAULT == null ? semantics != null : !SEMANTICS_EDEFAULT.equals(semantics);
		case OmtPackage.INTERACTION_CLASS__SEMANTICS_NOTES:
			return SEMANTICS_NOTES_EDEFAULT == null ? semanticsNotes != null : !SEMANTICS_NOTES_EDEFAULT
					.equals(semanticsNotes);
		case OmtPackage.INTERACTION_CLASS__SHARING:
			return isSetSharing();
		case OmtPackage.INTERACTION_CLASS__SHARING_NOTES:
			return SHARING_NOTES_EDEFAULT == null ? sharingNotes != null : !SHARING_NOTES_EDEFAULT.equals(sharingNotes);
		case OmtPackage.INTERACTION_CLASS__TRANSPORTATION:
			return TRANSPORTATION_EDEFAULT == null ? transportation != null : !TRANSPORTATION_EDEFAULT
					.equals(transportation);
		case OmtPackage.INTERACTION_CLASS__TRANSPORTATION_NOTES:
			return TRANSPORTATION_NOTES_EDEFAULT == null ? transportationNotes != null : !TRANSPORTATION_NOTES_EDEFAULT
					.equals(transportationNotes);
		case OmtPackage.INTERACTION_CLASS__SUBSCRIBING_FEDERATES:
			return subscribingFederates != null && !subscribingFederates.isEmpty();
		case OmtPackage.INTERACTION_CLASS__PUBLISHING_FEDERATES:
			return publishingFederates != null && !publishingFederates.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated not
	 */
	public String toString() {
		if (eIsProxy())
			return super.toString();

		return getQualifiedName(true);
	}

} // InteractionClassImpl
