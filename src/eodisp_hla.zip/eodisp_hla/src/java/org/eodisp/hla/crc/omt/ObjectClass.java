/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt;

import hla.rti1516.AttributeHandle;
import hla.rti1516.ObjectClassHandle;

import java.util.List;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Object Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectClass#getAttributes <em>Attributes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectClass#getSubClasses <em>Sub Classes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectClass#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectClass#getNameNotes <em>Name Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectClass#getSemantics <em>Semantics</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectClass#getSemanticsNotes <em>Semantics Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectClass#getSharing <em>Sharing</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.ObjectClass#getSharingNotes <em>Sharing Notes</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectClass()
 * @model extendedMetaData="name='ObjectClass' kind='elementOnly'"
 * @generated
 */
public interface ObjectClass extends EObject {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The name of the HLA object root. See section 4.2.1 in IEEE 1516.2-2000,
	 * Page 21, first paragraph.
	 */
	public static final String HLA_OBJECT_ROOT_NAME = "HLAobjectRoot";

	/**
	 * Returns the object class handle of this object class.
	 * 
	 * @return the object class handle of this object class.
	 */
	ObjectClassHandle getHandle();

	/**
	 * Sets the object class handle of this object class. TODO: Should be set when
	 * constructing
	 * 
	 * @param objectClassHandle
	 */
	void setHandle(ObjectClassHandle objectClassHandle);

	/**
	 * Returns the value of the '<em><b>Attributes</b></em>' containment reference list.
	 * The list contents are of type {@link org.eodisp.hla.crc.omt.Attribute}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Attributes</em>' containment reference
	 * list isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attributes</em>' containment reference list.
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectClass_Attributes()
	 * @model type="org.eodisp.hla.crc.omt.Attribute" containment="true"
	 *        extendedMetaData="kind='element' name='attribute' namespace='##targetNamespace'"
	 * @generated
	 */
	EList getAttributes();

	/**
	 * Returns all attributes including attributes of all super classes.
	 * 
	 * @return
	 */
	List getAllAttributes();

	/**
	 * Returns the value of the '<em><b>Sub Classes</b></em>' containment reference list.
	 * The list contents are of type {@link org.eodisp.hla.crc.omt.ObjectClass}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sub Classes</em>' containment reference
	 * list isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sub Classes</em>' containment reference list.
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectClass_SubClasses()
	 * @model type="org.eodisp.hla.crc.omt.ObjectClass" containment="true"
	 *        extendedMetaData="kind='element' name='objectClass' namespace='##targetNamespace'"
	 * @generated
	 */
	EList getSubClasses();

	/**
	 * Returns the super object class of this object class.
	 * 
	 * @return the super object class of this object class or null if this
	 *         object class does not have a super class
	 */
	ObjectClass getSuperClass();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectClass_Name()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKEN"
	 *        required="true" extendedMetaData="kind='attribute' name='name'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	String getName();

	/**
	 * Returns the fully qualified name of this object class. See section 10.1.1
	 * in IEEE 1516.1-2000.
	 * 
	 * @param omitObjectRoot
	 *            if <code>true</code> omits the topmost super class
	 *            HLAobjectRoot.
	 * @return the fully qualified name of this object class. Delimiter is a
	 *         dot(.).
	 */
	String getQualifiedName(boolean omitObjectRoot);

	/**
	 * Returns all super classes in an ordered list. The first element in the
	 * list is the immediate super class, the last the top most class, which is
	 * always the HLAobjectRoot
	 * 
	 * @return all super classes of this object class
	 */
	List<ObjectClass> getAllSuperClasses();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectClass#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Name Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name Notes</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name Notes</em>' attribute.
	 * @see #setNameNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectClass_NameNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='nameNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getNameNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectClass#getNameNotes <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name Notes</em>' attribute.
	 * @see #getNameNotes()
	 * @generated
	 */
	void setNameNotes(List value);

	/**
	 * Returns the value of the '<em><b>Semantics</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Semantics</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Semantics</em>' attribute.
	 * @see #setSemantics(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectClass_Semantics()
	 * @model unique="false"
	 *        dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='semantics'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	Object getSemantics();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectClass#getSemantics <em>Semantics</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Semantics</em>' attribute.
	 * @see #getSemantics()
	 * @generated
	 */
	void setSemantics(Object value);

	/**
	 * Returns the value of the '<em><b>Semantics Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Semantics Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Semantics Notes</em>' attribute.
	 * @see #setSemanticsNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectClass_SemanticsNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='semanticsNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSemanticsNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectClass#getSemanticsNotes <em>Semantics Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Semantics Notes</em>' attribute.
	 * @see #getSemanticsNotes()
	 * @generated
	 */
	void setSemanticsNotes(List value);

	/**
	 * Returns the value of the '<em><b>Sharing</b></em>' attribute. The
	 * default value is <code>"Publish"</code>. The literals are from the
	 * enumeration {@link org.eodisp.hla.crc.omt.SharingEnum}. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sharing</em>' attribute isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Sharing</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.SharingEnum
	 * @see #isSetSharing()
	 * @see #unsetSharing()
	 * @see #setSharing(SharingEnum)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectClass_Sharing()
	 * @model default="Publish" unique="false" unsettable="true"
	 *        extendedMetaData="kind='attribute' name='sharing'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	SharingEnum getSharing();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectClass#getSharing <em>Sharing</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sharing</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.SharingEnum
	 * @see #isSetSharing()
	 * @see #unsetSharing()
	 * @see #getSharing()
	 * @generated
	 */
	void setSharing(SharingEnum value);

	/**
	 * Unsets the value of the '{@link org.eodisp.hla.crc.omt.ObjectClass#getSharing <em>Sharing</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #isSetSharing()
	 * @see #getSharing()
	 * @see #setSharing(SharingEnum)
	 * @generated
	 */
	void unsetSharing();

	/**
	 * Returns whether the value of the '{@link org.eodisp.hla.crc.omt.ObjectClass#getSharing <em>Sharing</em>}' attribute is set.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return whether the value of the '<em>Sharing</em>' attribute is set.
	 * @see #unsetSharing()
	 * @see #getSharing()
	 * @see #setSharing(SharingEnum)
	 * @generated
	 */
	boolean isSetSharing();

	/**
	 * Returns the value of the '<em><b>Sharing Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sharing Notes</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sharing Notes</em>' attribute.
	 * @see #setSharingNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getObjectClass_SharingNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='sharingNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSharingNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.ObjectClass#getSharingNotes <em>Sharing Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sharing Notes</em>' attribute.
	 * @see #getSharingNotes()
	 * @generated
	 */
	void setSharingNotes(List value);

} // ObjectClass
