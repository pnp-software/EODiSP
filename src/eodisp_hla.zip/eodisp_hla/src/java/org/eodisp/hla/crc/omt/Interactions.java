/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Interactions</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.Interactions#getInteractionClass <em>Interaction Class</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eodisp.hla.crc.omt.OmtPackage#getInteractions()
 * @model extendedMetaData="name='Interactions' kind='elementOnly'"
 * @generated
 */
public interface Interactions extends EObject {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * Returns the value of the '<em><b>Interaction Class</b></em>' containment reference list.
	 * The list contents are of type {@link org.eodisp.hla.crc.omt.InteractionClass}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Interaction Class</em>' containment
	 * reference list isn't clear, there really should be more of a description
	 * here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Interaction Class</em>' containment reference list.
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getInteractions_InteractionClass()
	 * @model type="org.eodisp.hla.crc.omt.InteractionClass" containment="true" required="true"
	 *        extendedMetaData="kind='element' name='interactionClass' namespace='##targetNamespace'"
	 * @generated
	 */
	EList getInteractionClass();

	EList getAllInteractionClasses();

} // Interactions
