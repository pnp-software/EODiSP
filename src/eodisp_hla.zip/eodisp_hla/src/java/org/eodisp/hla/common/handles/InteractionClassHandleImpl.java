/**
 * 
 */
package org.eodisp.hla.common.handles;


import hla.rti1516.InteractionClassHandle;

/**
 * A federation execution wide interaction class handle.
 * @author ibirrer
 */
public class InteractionClassHandleImpl extends HandleImpl implements
		InteractionClassHandle {

	private static final long serialVersionUID = 1L;

	/**
	 * {@inheritDoc}
	 */
	public InteractionClassHandleImpl(int id) {
		super(id);
	}
}
