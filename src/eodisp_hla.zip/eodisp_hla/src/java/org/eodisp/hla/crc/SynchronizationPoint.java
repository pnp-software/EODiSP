/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.hla.crc;

import hla.rti1516.FederateHandle;

import java.util.*;

import net.jcip.annotations.ThreadSafe;

import org.apache.log4j.Logger;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
@ThreadSafe
public class SynchronizationPoint {
	private final String name;

	private final Set<FederateHandle> synchronizedFederates = Collections
			.synchronizedSet(new HashSet<FederateHandle>());

	private final Set<FederateHandle> notSynchronizedFederates = Collections
			.synchronizedSet(new HashSet<FederateHandle>());

	private final FederationExecution federationExecution;

	private final boolean fixedSet;

	private final FederationExecutionEventListener listener;

	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	private final static Logger logger = Logger.getLogger(SynchronizationPoint.class);

	private final byte[] userSuppliedTag;

	/**
	 * @param name
	 */
	public SynchronizationPoint(final String name, FederationExecution federationExecution, boolean fixedSet,
			byte[] userSuppliedTag) {
		this.name = name;
		this.federationExecution = federationExecution;
		this.fixedSet = fixedSet;
		this.userSuppliedTag = userSuppliedTag;
		this.listener = new FederationExecutionEventListener() {
			public void joined(FederateHandle federateHandle) {
				if (!SynchronizationPoint.this.fixedSet) {
					if (notSynchronizedFederates.isEmpty()) {
						// once the synchronization point has achieved do
						// not add newly joined federates
						return;
					}

					logger.debug(String.format(
							"Add federate %s to synchronization set %s, due joining",
							federateHandle,
							name));

					notSynchronizedFederates.add(federateHandle);

					/* Announce to newly joined federate only */
					Set<FederateHandle> newFederateSet = new HashSet<FederateHandle>();
					newFederateSet.add(federateHandle);
					SynchronizationPoint.this.federationExecution.doAnnounceSynchronizationPointCallback(
							name,
							newFederateSet,
							SynchronizationPoint.this.userSuppliedTag);
				}
			}

			public void resigned(FederateHandle federateHandle) {
				logger.debug(String.format(
						"Try to remove federate %s from synchronization set %s, due resigning",
						federateHandle,
						name));
				if (!notSynchronizedFederates.remove(federateHandle)) {
					logger.warn(String.format(
							"Federate %s achieved synchronization point %s before it has resigned",
							federateHandle,
							name));
					return;
				}
				if (notSynchronizedFederates.isEmpty()) {
					federationSynchronized();
				}
			}
		};
	}

	/**
	 * Call only once for the same synchronization point!
	 * 
	 * @param initialFederates
	 */
	public void start(Set<FederateHandle> initialFederates) {
		notSynchronizedFederates.addAll(initialFederates);
		federationExecution.doAnnounceSynchronizationPointCallback(name, notSynchronizedFederates, userSuppliedTag);
		federationExecution.addFederationExecutionEventListener(listener);
	}

	public void syncFederate(FederateHandle federateHandle) {
		if (notSynchronizedFederates.remove(federateHandle)) {
			synchronizedFederates.add(federateHandle);
		} else {
			logger
					.warn("Federate resigned from synchronization set %s before it could reach the synchronization point");
			return;
		}
		if (notSynchronizedFederates.isEmpty()) {
			/*
			 * any subsequent joins are ignored. As of now this is not even
			 * possible because the federation execution does not allow any
			 * concurrent access (all methods are synchronized)
			 */
			federationSynchronized();
		}
	}

	private void federationSynchronized() {
		logger.debug(String.format("Federation synchronized at point: %s", name));
		federationExecution.removeFederationExecutionEventListener(listener);
		federationExecution.doFederatesSynchronizedCallback(name, synchronizedFederates, userSuppliedTag);
	}
}
