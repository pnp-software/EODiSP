package org.eodisp.hla.crc.launcher;

import org.eodisp.remote.launcher.RootAppProcessFactoryRemote;

public interface CrcProcessFactoryRemote extends RootAppProcessFactoryRemote {
	static final String FACTORY_ID = CrcProcessFactoryRemote.class.getName();
}
