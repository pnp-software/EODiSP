/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.hla.common.handles;

import java.util.HashSet;
import java.util.Set;

import hla.rti1516.*;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class HandlesUtil {

	// public static AttributeHandle[]
	// attributeHandleSetToArray(AttributeHandleSet attributeHandleSet) {
	// AttributeHandle[] result = new
	// AttributeHandle[attributeHandleSet.size()];
	// int i = 0;
	// for (Object object : attributeHandleSet) {
	// AttributeHandle attributeHandle = (AttributeHandle) object;
	// result[i] = attributeHandle;
	// i++;
	// }
	// return result;
	// }

	@SuppressWarnings("unchecked")
	public static Set<AttributeHandle> toGenericSet(AttributeHandleSet attributeHandleSet) {
		Set<AttributeHandle> result = new HashSet<AttributeHandle>(attributeHandleSet.size());
		result.addAll(attributeHandleSet);
		return result;
	}

	@SuppressWarnings("unchecked")
	public static Set<FederateHandle> toGenericSet(FederateHandleSet federateHandleSet) {
		Set<FederateHandle> result = new HashSet<FederateHandle>();
		result.addAll(federateHandleSet);
		return result;
	}
	
	
	@SuppressWarnings("unchecked")
	public static AttributeHandle[] getAttributeHandleArray(final AttributeHandleValueMap attributeHandleValueMap) {
		return (AttributeHandle[])attributeHandleValueMap.keySet().toArray(new AttributeHandle[0]);
	}

	//
	// public static AttributeHandle[]
	// attributeHandlesToArray(Set<AttributeHandle> attributeHandleSet) {
	// Set<AttributeHandle> set = new
	// HashSet<AttributeHandle>(attributeHandleSet);
	// return set.toArray(new AttributeHandle[set.size()]);
	// }
}
