/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt.impl;

import java.util.List;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eodisp.hla.crc.omt.OmtPackage;
import org.eodisp.hla.crc.omt.StateEnum;
import org.eodisp.hla.crc.omt.Switches;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Switches</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SwitchesImpl#getAttributeRelevanceAdvisory <em>Attribute Relevance Advisory</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SwitchesImpl#getAttributeRelevanceAdvisoryNotes <em>Attribute Relevance Advisory Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SwitchesImpl#getAttributeScopeAdvisory <em>Attribute Scope Advisory</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SwitchesImpl#getAttributeScopeAdvisoryNotes <em>Attribute Scope Advisory Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SwitchesImpl#getAutoProvide <em>Auto Provide</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SwitchesImpl#getAutoProvideNotes <em>Auto Provide Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SwitchesImpl#getConveyRegionDesignatorSets <em>Convey Region Designator Sets</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SwitchesImpl#getConveyRegionDesignatorSetsNotes <em>Convey Region Designator Sets Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SwitchesImpl#getInteractionRelevanceAdvisory <em>Interaction Relevance Advisory</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SwitchesImpl#getInteractionRelevanceAdvisoryNotes <em>Interaction Relevance Advisory Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SwitchesImpl#getObjectClassRelevanceAdvisory <em>Object Class Relevance Advisory</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SwitchesImpl#getObjectClassRelevanceAdvisoryNotes <em>Object Class Relevance Advisory Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SwitchesImpl#getServiceReporting <em>Service Reporting</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SwitchesImpl#getServiceReportingNotes <em>Service Reporting Notes</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class SwitchesImpl extends EObjectImpl implements Switches {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The default value of the '{@link #getAttributeRelevanceAdvisory() <em>Attribute Relevance Advisory</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getAttributeRelevanceAdvisory()
	 * @generated
	 * @ordered
	 */
	protected static final StateEnum ATTRIBUTE_RELEVANCE_ADVISORY_EDEFAULT = StateEnum.ENABLED_LITERAL;

	/**
	 * The cached value of the '{@link #getAttributeRelevanceAdvisory() <em>Attribute Relevance Advisory</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getAttributeRelevanceAdvisory()
	 * @generated
	 * @ordered
	 */
	protected StateEnum attributeRelevanceAdvisory = ATTRIBUTE_RELEVANCE_ADVISORY_EDEFAULT;

	/**
	 * This is true if the Attribute Relevance Advisory attribute has been set.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean attributeRelevanceAdvisoryESet = false;

	/**
	 * The default value of the '{@link #getAttributeRelevanceAdvisoryNotes() <em>Attribute Relevance Advisory Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getAttributeRelevanceAdvisoryNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List ATTRIBUTE_RELEVANCE_ADVISORY_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getAttributeRelevanceAdvisoryNotes() <em>Attribute Relevance Advisory Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getAttributeRelevanceAdvisoryNotes()
	 * @generated
	 * @ordered
	 */
	protected List attributeRelevanceAdvisoryNotes = ATTRIBUTE_RELEVANCE_ADVISORY_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getAttributeScopeAdvisory() <em>Attribute Scope Advisory</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getAttributeScopeAdvisory()
	 * @generated
	 * @ordered
	 */
	protected static final StateEnum ATTRIBUTE_SCOPE_ADVISORY_EDEFAULT = StateEnum.ENABLED_LITERAL;

	/**
	 * The cached value of the '{@link #getAttributeScopeAdvisory() <em>Attribute Scope Advisory</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getAttributeScopeAdvisory()
	 * @generated
	 * @ordered
	 */
	protected StateEnum attributeScopeAdvisory = ATTRIBUTE_SCOPE_ADVISORY_EDEFAULT;

	/**
	 * This is true if the Attribute Scope Advisory attribute has been set. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	protected boolean attributeScopeAdvisoryESet = false;

	/**
	 * The default value of the '{@link #getAttributeScopeAdvisoryNotes() <em>Attribute Scope Advisory Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getAttributeScopeAdvisoryNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List ATTRIBUTE_SCOPE_ADVISORY_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getAttributeScopeAdvisoryNotes() <em>Attribute Scope Advisory Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getAttributeScopeAdvisoryNotes()
	 * @generated
	 * @ordered
	 */
	protected List attributeScopeAdvisoryNotes = ATTRIBUTE_SCOPE_ADVISORY_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getAutoProvide() <em>Auto Provide</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getAutoProvide()
	 * @generated
	 * @ordered
	 */
	protected static final StateEnum AUTO_PROVIDE_EDEFAULT = StateEnum.ENABLED_LITERAL;

	/**
	 * The cached value of the '{@link #getAutoProvide() <em>Auto Provide</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getAutoProvide()
	 * @generated
	 * @ordered
	 */
	protected StateEnum autoProvide = AUTO_PROVIDE_EDEFAULT;

	/**
	 * This is true if the Auto Provide attribute has been set. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	protected boolean autoProvideESet = false;

	/**
	 * The default value of the '{@link #getAutoProvideNotes() <em>Auto Provide Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getAutoProvideNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List AUTO_PROVIDE_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getAutoProvideNotes() <em>Auto Provide Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getAutoProvideNotes()
	 * @generated
	 * @ordered
	 */
	protected List autoProvideNotes = AUTO_PROVIDE_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getConveyRegionDesignatorSets() <em>Convey Region Designator Sets</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getConveyRegionDesignatorSets()
	 * @generated
	 * @ordered
	 */
	protected static final StateEnum CONVEY_REGION_DESIGNATOR_SETS_EDEFAULT = StateEnum.ENABLED_LITERAL;

	/**
	 * The cached value of the '{@link #getConveyRegionDesignatorSets() <em>Convey Region Designator Sets</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getConveyRegionDesignatorSets()
	 * @generated
	 * @ordered
	 */
	protected StateEnum conveyRegionDesignatorSets = CONVEY_REGION_DESIGNATOR_SETS_EDEFAULT;

	/**
	 * This is true if the Convey Region Designator Sets attribute has been set.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean conveyRegionDesignatorSetsESet = false;

	/**
	 * The default value of the '{@link #getConveyRegionDesignatorSetsNotes() <em>Convey Region Designator Sets Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getConveyRegionDesignatorSetsNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List CONVEY_REGION_DESIGNATOR_SETS_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getConveyRegionDesignatorSetsNotes() <em>Convey Region Designator Sets Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getConveyRegionDesignatorSetsNotes()
	 * @generated
	 * @ordered
	 */
	protected List conveyRegionDesignatorSetsNotes = CONVEY_REGION_DESIGNATOR_SETS_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getInteractionRelevanceAdvisory() <em>Interaction Relevance Advisory</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getInteractionRelevanceAdvisory()
	 * @generated
	 * @ordered
	 */
	protected static final StateEnum INTERACTION_RELEVANCE_ADVISORY_EDEFAULT = StateEnum.ENABLED_LITERAL;

	/**
	 * The cached value of the '{@link #getInteractionRelevanceAdvisory() <em>Interaction Relevance Advisory</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getInteractionRelevanceAdvisory()
	 * @generated
	 * @ordered
	 */
	protected StateEnum interactionRelevanceAdvisory = INTERACTION_RELEVANCE_ADVISORY_EDEFAULT;

	/**
	 * This is true if the Interaction Relevance Advisory attribute has been set.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean interactionRelevanceAdvisoryESet = false;

	/**
	 * The default value of the '{@link #getInteractionRelevanceAdvisoryNotes() <em>Interaction Relevance Advisory Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getInteractionRelevanceAdvisoryNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List INTERACTION_RELEVANCE_ADVISORY_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getInteractionRelevanceAdvisoryNotes() <em>Interaction Relevance Advisory Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getInteractionRelevanceAdvisoryNotes()
	 * @generated
	 * @ordered
	 */
	protected List interactionRelevanceAdvisoryNotes = INTERACTION_RELEVANCE_ADVISORY_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getObjectClassRelevanceAdvisory() <em>Object Class Relevance Advisory</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getObjectClassRelevanceAdvisory()
	 * @generated
	 * @ordered
	 */
	protected static final StateEnum OBJECT_CLASS_RELEVANCE_ADVISORY_EDEFAULT = StateEnum.ENABLED_LITERAL;

	/**
	 * The cached value of the '{@link #getObjectClassRelevanceAdvisory() <em>Object Class Relevance Advisory</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getObjectClassRelevanceAdvisory()
	 * @generated
	 * @ordered
	 */
	protected StateEnum objectClassRelevanceAdvisory = OBJECT_CLASS_RELEVANCE_ADVISORY_EDEFAULT;

	/**
	 * This is true if the Object Class Relevance Advisory attribute has been set.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean objectClassRelevanceAdvisoryESet = false;

	/**
	 * The default value of the '{@link #getObjectClassRelevanceAdvisoryNotes() <em>Object Class Relevance Advisory Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getObjectClassRelevanceAdvisoryNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List OBJECT_CLASS_RELEVANCE_ADVISORY_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getObjectClassRelevanceAdvisoryNotes() <em>Object Class Relevance Advisory Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getObjectClassRelevanceAdvisoryNotes()
	 * @generated
	 * @ordered
	 */
	protected List objectClassRelevanceAdvisoryNotes = OBJECT_CLASS_RELEVANCE_ADVISORY_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getServiceReporting() <em>Service Reporting</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getServiceReporting()
	 * @generated
	 * @ordered
	 */
	protected static final StateEnum SERVICE_REPORTING_EDEFAULT = StateEnum.ENABLED_LITERAL;

	/**
	 * The cached value of the '{@link #getServiceReporting() <em>Service Reporting</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getServiceReporting()
	 * @generated
	 * @ordered
	 */
	protected StateEnum serviceReporting = SERVICE_REPORTING_EDEFAULT;

	/**
	 * This is true if the Service Reporting attribute has been set. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	protected boolean serviceReportingESet = false;

	/**
	 * The default value of the '{@link #getServiceReportingNotes() <em>Service Reporting Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getServiceReportingNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List SERVICE_REPORTING_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getServiceReportingNotes() <em>Service Reporting Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getServiceReportingNotes()
	 * @generated
	 * @ordered
	 */
	protected List serviceReportingNotes = SERVICE_REPORTING_NOTES_EDEFAULT;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected SwitchesImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return OmtPackage.Literals.SWITCHES;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public StateEnum getAttributeRelevanceAdvisory() {
		return attributeRelevanceAdvisory;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setAttributeRelevanceAdvisory(StateEnum newAttributeRelevanceAdvisory) {
		StateEnum oldAttributeRelevanceAdvisory = attributeRelevanceAdvisory;
		attributeRelevanceAdvisory = newAttributeRelevanceAdvisory == null ? ATTRIBUTE_RELEVANCE_ADVISORY_EDEFAULT
				: newAttributeRelevanceAdvisory;
		boolean oldAttributeRelevanceAdvisoryESet = attributeRelevanceAdvisoryESet;
		attributeRelevanceAdvisoryESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SWITCHES__ATTRIBUTE_RELEVANCE_ADVISORY,
					oldAttributeRelevanceAdvisory,
					attributeRelevanceAdvisory,
					!oldAttributeRelevanceAdvisoryESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetAttributeRelevanceAdvisory() {
		StateEnum oldAttributeRelevanceAdvisory = attributeRelevanceAdvisory;
		boolean oldAttributeRelevanceAdvisoryESet = attributeRelevanceAdvisoryESet;
		attributeRelevanceAdvisory = ATTRIBUTE_RELEVANCE_ADVISORY_EDEFAULT;
		attributeRelevanceAdvisoryESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.UNSET,
					OmtPackage.SWITCHES__ATTRIBUTE_RELEVANCE_ADVISORY,
					oldAttributeRelevanceAdvisory,
					ATTRIBUTE_RELEVANCE_ADVISORY_EDEFAULT,
					oldAttributeRelevanceAdvisoryESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetAttributeRelevanceAdvisory() {
		return attributeRelevanceAdvisoryESet;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getAttributeRelevanceAdvisoryNotes() {
		return attributeRelevanceAdvisoryNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setAttributeRelevanceAdvisoryNotes(List newAttributeRelevanceAdvisoryNotes) {
		List oldAttributeRelevanceAdvisoryNotes = attributeRelevanceAdvisoryNotes;
		attributeRelevanceAdvisoryNotes = newAttributeRelevanceAdvisoryNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SWITCHES__ATTRIBUTE_RELEVANCE_ADVISORY_NOTES,
					oldAttributeRelevanceAdvisoryNotes,
					attributeRelevanceAdvisoryNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public StateEnum getAttributeScopeAdvisory() {
		return attributeScopeAdvisory;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setAttributeScopeAdvisory(StateEnum newAttributeScopeAdvisory) {
		StateEnum oldAttributeScopeAdvisory = attributeScopeAdvisory;
		attributeScopeAdvisory = newAttributeScopeAdvisory == null ? ATTRIBUTE_SCOPE_ADVISORY_EDEFAULT
				: newAttributeScopeAdvisory;
		boolean oldAttributeScopeAdvisoryESet = attributeScopeAdvisoryESet;
		attributeScopeAdvisoryESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SWITCHES__ATTRIBUTE_SCOPE_ADVISORY,
					oldAttributeScopeAdvisory,
					attributeScopeAdvisory,
					!oldAttributeScopeAdvisoryESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetAttributeScopeAdvisory() {
		StateEnum oldAttributeScopeAdvisory = attributeScopeAdvisory;
		boolean oldAttributeScopeAdvisoryESet = attributeScopeAdvisoryESet;
		attributeScopeAdvisory = ATTRIBUTE_SCOPE_ADVISORY_EDEFAULT;
		attributeScopeAdvisoryESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.UNSET,
					OmtPackage.SWITCHES__ATTRIBUTE_SCOPE_ADVISORY,
					oldAttributeScopeAdvisory,
					ATTRIBUTE_SCOPE_ADVISORY_EDEFAULT,
					oldAttributeScopeAdvisoryESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetAttributeScopeAdvisory() {
		return attributeScopeAdvisoryESet;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getAttributeScopeAdvisoryNotes() {
		return attributeScopeAdvisoryNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setAttributeScopeAdvisoryNotes(List newAttributeScopeAdvisoryNotes) {
		List oldAttributeScopeAdvisoryNotes = attributeScopeAdvisoryNotes;
		attributeScopeAdvisoryNotes = newAttributeScopeAdvisoryNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SWITCHES__ATTRIBUTE_SCOPE_ADVISORY_NOTES,
					oldAttributeScopeAdvisoryNotes,
					attributeScopeAdvisoryNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public StateEnum getAutoProvide() {
		return autoProvide;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setAutoProvide(StateEnum newAutoProvide) {
		StateEnum oldAutoProvide = autoProvide;
		autoProvide = newAutoProvide == null ? AUTO_PROVIDE_EDEFAULT : newAutoProvide;
		boolean oldAutoProvideESet = autoProvideESet;
		autoProvideESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SWITCHES__AUTO_PROVIDE,
					oldAutoProvide,
					autoProvide,
					!oldAutoProvideESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetAutoProvide() {
		StateEnum oldAutoProvide = autoProvide;
		boolean oldAutoProvideESet = autoProvideESet;
		autoProvide = AUTO_PROVIDE_EDEFAULT;
		autoProvideESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.UNSET,
					OmtPackage.SWITCHES__AUTO_PROVIDE,
					oldAutoProvide,
					AUTO_PROVIDE_EDEFAULT,
					oldAutoProvideESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetAutoProvide() {
		return autoProvideESet;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getAutoProvideNotes() {
		return autoProvideNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setAutoProvideNotes(List newAutoProvideNotes) {
		List oldAutoProvideNotes = autoProvideNotes;
		autoProvideNotes = newAutoProvideNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SWITCHES__AUTO_PROVIDE_NOTES,
					oldAutoProvideNotes,
					autoProvideNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public StateEnum getConveyRegionDesignatorSets() {
		return conveyRegionDesignatorSets;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setConveyRegionDesignatorSets(StateEnum newConveyRegionDesignatorSets) {
		StateEnum oldConveyRegionDesignatorSets = conveyRegionDesignatorSets;
		conveyRegionDesignatorSets = newConveyRegionDesignatorSets == null ? CONVEY_REGION_DESIGNATOR_SETS_EDEFAULT
				: newConveyRegionDesignatorSets;
		boolean oldConveyRegionDesignatorSetsESet = conveyRegionDesignatorSetsESet;
		conveyRegionDesignatorSetsESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SWITCHES__CONVEY_REGION_DESIGNATOR_SETS,
					oldConveyRegionDesignatorSets,
					conveyRegionDesignatorSets,
					!oldConveyRegionDesignatorSetsESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetConveyRegionDesignatorSets() {
		StateEnum oldConveyRegionDesignatorSets = conveyRegionDesignatorSets;
		boolean oldConveyRegionDesignatorSetsESet = conveyRegionDesignatorSetsESet;
		conveyRegionDesignatorSets = CONVEY_REGION_DESIGNATOR_SETS_EDEFAULT;
		conveyRegionDesignatorSetsESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.UNSET,
					OmtPackage.SWITCHES__CONVEY_REGION_DESIGNATOR_SETS,
					oldConveyRegionDesignatorSets,
					CONVEY_REGION_DESIGNATOR_SETS_EDEFAULT,
					oldConveyRegionDesignatorSetsESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetConveyRegionDesignatorSets() {
		return conveyRegionDesignatorSetsESet;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getConveyRegionDesignatorSetsNotes() {
		return conveyRegionDesignatorSetsNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setConveyRegionDesignatorSetsNotes(List newConveyRegionDesignatorSetsNotes) {
		List oldConveyRegionDesignatorSetsNotes = conveyRegionDesignatorSetsNotes;
		conveyRegionDesignatorSetsNotes = newConveyRegionDesignatorSetsNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SWITCHES__CONVEY_REGION_DESIGNATOR_SETS_NOTES,
					oldConveyRegionDesignatorSetsNotes,
					conveyRegionDesignatorSetsNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public StateEnum getInteractionRelevanceAdvisory() {
		return interactionRelevanceAdvisory;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setInteractionRelevanceAdvisory(StateEnum newInteractionRelevanceAdvisory) {
		StateEnum oldInteractionRelevanceAdvisory = interactionRelevanceAdvisory;
		interactionRelevanceAdvisory = newInteractionRelevanceAdvisory == null ? INTERACTION_RELEVANCE_ADVISORY_EDEFAULT
				: newInteractionRelevanceAdvisory;
		boolean oldInteractionRelevanceAdvisoryESet = interactionRelevanceAdvisoryESet;
		interactionRelevanceAdvisoryESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SWITCHES__INTERACTION_RELEVANCE_ADVISORY,
					oldInteractionRelevanceAdvisory,
					interactionRelevanceAdvisory,
					!oldInteractionRelevanceAdvisoryESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetInteractionRelevanceAdvisory() {
		StateEnum oldInteractionRelevanceAdvisory = interactionRelevanceAdvisory;
		boolean oldInteractionRelevanceAdvisoryESet = interactionRelevanceAdvisoryESet;
		interactionRelevanceAdvisory = INTERACTION_RELEVANCE_ADVISORY_EDEFAULT;
		interactionRelevanceAdvisoryESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.UNSET,
					OmtPackage.SWITCHES__INTERACTION_RELEVANCE_ADVISORY,
					oldInteractionRelevanceAdvisory,
					INTERACTION_RELEVANCE_ADVISORY_EDEFAULT,
					oldInteractionRelevanceAdvisoryESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetInteractionRelevanceAdvisory() {
		return interactionRelevanceAdvisoryESet;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getInteractionRelevanceAdvisoryNotes() {
		return interactionRelevanceAdvisoryNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setInteractionRelevanceAdvisoryNotes(List newInteractionRelevanceAdvisoryNotes) {
		List oldInteractionRelevanceAdvisoryNotes = interactionRelevanceAdvisoryNotes;
		interactionRelevanceAdvisoryNotes = newInteractionRelevanceAdvisoryNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SWITCHES__INTERACTION_RELEVANCE_ADVISORY_NOTES,
					oldInteractionRelevanceAdvisoryNotes,
					interactionRelevanceAdvisoryNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public StateEnum getObjectClassRelevanceAdvisory() {
		return objectClassRelevanceAdvisory;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setObjectClassRelevanceAdvisory(StateEnum newObjectClassRelevanceAdvisory) {
		StateEnum oldObjectClassRelevanceAdvisory = objectClassRelevanceAdvisory;
		objectClassRelevanceAdvisory = newObjectClassRelevanceAdvisory == null ? OBJECT_CLASS_RELEVANCE_ADVISORY_EDEFAULT
				: newObjectClassRelevanceAdvisory;
		boolean oldObjectClassRelevanceAdvisoryESet = objectClassRelevanceAdvisoryESet;
		objectClassRelevanceAdvisoryESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SWITCHES__OBJECT_CLASS_RELEVANCE_ADVISORY,
					oldObjectClassRelevanceAdvisory,
					objectClassRelevanceAdvisory,
					!oldObjectClassRelevanceAdvisoryESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetObjectClassRelevanceAdvisory() {
		StateEnum oldObjectClassRelevanceAdvisory = objectClassRelevanceAdvisory;
		boolean oldObjectClassRelevanceAdvisoryESet = objectClassRelevanceAdvisoryESet;
		objectClassRelevanceAdvisory = OBJECT_CLASS_RELEVANCE_ADVISORY_EDEFAULT;
		objectClassRelevanceAdvisoryESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.UNSET,
					OmtPackage.SWITCHES__OBJECT_CLASS_RELEVANCE_ADVISORY,
					oldObjectClassRelevanceAdvisory,
					OBJECT_CLASS_RELEVANCE_ADVISORY_EDEFAULT,
					oldObjectClassRelevanceAdvisoryESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetObjectClassRelevanceAdvisory() {
		return objectClassRelevanceAdvisoryESet;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getObjectClassRelevanceAdvisoryNotes() {
		return objectClassRelevanceAdvisoryNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setObjectClassRelevanceAdvisoryNotes(List newObjectClassRelevanceAdvisoryNotes) {
		List oldObjectClassRelevanceAdvisoryNotes = objectClassRelevanceAdvisoryNotes;
		objectClassRelevanceAdvisoryNotes = newObjectClassRelevanceAdvisoryNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SWITCHES__OBJECT_CLASS_RELEVANCE_ADVISORY_NOTES,
					oldObjectClassRelevanceAdvisoryNotes,
					objectClassRelevanceAdvisoryNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public StateEnum getServiceReporting() {
		return serviceReporting;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setServiceReporting(StateEnum newServiceReporting) {
		StateEnum oldServiceReporting = serviceReporting;
		serviceReporting = newServiceReporting == null ? SERVICE_REPORTING_EDEFAULT : newServiceReporting;
		boolean oldServiceReportingESet = serviceReportingESet;
		serviceReportingESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SWITCHES__SERVICE_REPORTING,
					oldServiceReporting,
					serviceReporting,
					!oldServiceReportingESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetServiceReporting() {
		StateEnum oldServiceReporting = serviceReporting;
		boolean oldServiceReportingESet = serviceReportingESet;
		serviceReporting = SERVICE_REPORTING_EDEFAULT;
		serviceReportingESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.UNSET,
					OmtPackage.SWITCHES__SERVICE_REPORTING,
					oldServiceReporting,
					SERVICE_REPORTING_EDEFAULT,
					oldServiceReportingESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetServiceReporting() {
		return serviceReportingESet;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getServiceReportingNotes() {
		return serviceReportingNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setServiceReportingNotes(List newServiceReportingNotes) {
		List oldServiceReportingNotes = serviceReportingNotes;
		serviceReportingNotes = newServiceReportingNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SWITCHES__SERVICE_REPORTING_NOTES,
					oldServiceReportingNotes,
					serviceReportingNotes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case OmtPackage.SWITCHES__ATTRIBUTE_RELEVANCE_ADVISORY:
			return getAttributeRelevanceAdvisory();
		case OmtPackage.SWITCHES__ATTRIBUTE_RELEVANCE_ADVISORY_NOTES:
			return getAttributeRelevanceAdvisoryNotes();
		case OmtPackage.SWITCHES__ATTRIBUTE_SCOPE_ADVISORY:
			return getAttributeScopeAdvisory();
		case OmtPackage.SWITCHES__ATTRIBUTE_SCOPE_ADVISORY_NOTES:
			return getAttributeScopeAdvisoryNotes();
		case OmtPackage.SWITCHES__AUTO_PROVIDE:
			return getAutoProvide();
		case OmtPackage.SWITCHES__AUTO_PROVIDE_NOTES:
			return getAutoProvideNotes();
		case OmtPackage.SWITCHES__CONVEY_REGION_DESIGNATOR_SETS:
			return getConveyRegionDesignatorSets();
		case OmtPackage.SWITCHES__CONVEY_REGION_DESIGNATOR_SETS_NOTES:
			return getConveyRegionDesignatorSetsNotes();
		case OmtPackage.SWITCHES__INTERACTION_RELEVANCE_ADVISORY:
			return getInteractionRelevanceAdvisory();
		case OmtPackage.SWITCHES__INTERACTION_RELEVANCE_ADVISORY_NOTES:
			return getInteractionRelevanceAdvisoryNotes();
		case OmtPackage.SWITCHES__OBJECT_CLASS_RELEVANCE_ADVISORY:
			return getObjectClassRelevanceAdvisory();
		case OmtPackage.SWITCHES__OBJECT_CLASS_RELEVANCE_ADVISORY_NOTES:
			return getObjectClassRelevanceAdvisoryNotes();
		case OmtPackage.SWITCHES__SERVICE_REPORTING:
			return getServiceReporting();
		case OmtPackage.SWITCHES__SERVICE_REPORTING_NOTES:
			return getServiceReportingNotes();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case OmtPackage.SWITCHES__ATTRIBUTE_RELEVANCE_ADVISORY:
			setAttributeRelevanceAdvisory((StateEnum) newValue);
			return;
		case OmtPackage.SWITCHES__ATTRIBUTE_RELEVANCE_ADVISORY_NOTES:
			setAttributeRelevanceAdvisoryNotes((List) newValue);
			return;
		case OmtPackage.SWITCHES__ATTRIBUTE_SCOPE_ADVISORY:
			setAttributeScopeAdvisory((StateEnum) newValue);
			return;
		case OmtPackage.SWITCHES__ATTRIBUTE_SCOPE_ADVISORY_NOTES:
			setAttributeScopeAdvisoryNotes((List) newValue);
			return;
		case OmtPackage.SWITCHES__AUTO_PROVIDE:
			setAutoProvide((StateEnum) newValue);
			return;
		case OmtPackage.SWITCHES__AUTO_PROVIDE_NOTES:
			setAutoProvideNotes((List) newValue);
			return;
		case OmtPackage.SWITCHES__CONVEY_REGION_DESIGNATOR_SETS:
			setConveyRegionDesignatorSets((StateEnum) newValue);
			return;
		case OmtPackage.SWITCHES__CONVEY_REGION_DESIGNATOR_SETS_NOTES:
			setConveyRegionDesignatorSetsNotes((List) newValue);
			return;
		case OmtPackage.SWITCHES__INTERACTION_RELEVANCE_ADVISORY:
			setInteractionRelevanceAdvisory((StateEnum) newValue);
			return;
		case OmtPackage.SWITCHES__INTERACTION_RELEVANCE_ADVISORY_NOTES:
			setInteractionRelevanceAdvisoryNotes((List) newValue);
			return;
		case OmtPackage.SWITCHES__OBJECT_CLASS_RELEVANCE_ADVISORY:
			setObjectClassRelevanceAdvisory((StateEnum) newValue);
			return;
		case OmtPackage.SWITCHES__OBJECT_CLASS_RELEVANCE_ADVISORY_NOTES:
			setObjectClassRelevanceAdvisoryNotes((List) newValue);
			return;
		case OmtPackage.SWITCHES__SERVICE_REPORTING:
			setServiceReporting((StateEnum) newValue);
			return;
		case OmtPackage.SWITCHES__SERVICE_REPORTING_NOTES:
			setServiceReportingNotes((List) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
		case OmtPackage.SWITCHES__ATTRIBUTE_RELEVANCE_ADVISORY:
			unsetAttributeRelevanceAdvisory();
			return;
		case OmtPackage.SWITCHES__ATTRIBUTE_RELEVANCE_ADVISORY_NOTES:
			setAttributeRelevanceAdvisoryNotes(ATTRIBUTE_RELEVANCE_ADVISORY_NOTES_EDEFAULT);
			return;
		case OmtPackage.SWITCHES__ATTRIBUTE_SCOPE_ADVISORY:
			unsetAttributeScopeAdvisory();
			return;
		case OmtPackage.SWITCHES__ATTRIBUTE_SCOPE_ADVISORY_NOTES:
			setAttributeScopeAdvisoryNotes(ATTRIBUTE_SCOPE_ADVISORY_NOTES_EDEFAULT);
			return;
		case OmtPackage.SWITCHES__AUTO_PROVIDE:
			unsetAutoProvide();
			return;
		case OmtPackage.SWITCHES__AUTO_PROVIDE_NOTES:
			setAutoProvideNotes(AUTO_PROVIDE_NOTES_EDEFAULT);
			return;
		case OmtPackage.SWITCHES__CONVEY_REGION_DESIGNATOR_SETS:
			unsetConveyRegionDesignatorSets();
			return;
		case OmtPackage.SWITCHES__CONVEY_REGION_DESIGNATOR_SETS_NOTES:
			setConveyRegionDesignatorSetsNotes(CONVEY_REGION_DESIGNATOR_SETS_NOTES_EDEFAULT);
			return;
		case OmtPackage.SWITCHES__INTERACTION_RELEVANCE_ADVISORY:
			unsetInteractionRelevanceAdvisory();
			return;
		case OmtPackage.SWITCHES__INTERACTION_RELEVANCE_ADVISORY_NOTES:
			setInteractionRelevanceAdvisoryNotes(INTERACTION_RELEVANCE_ADVISORY_NOTES_EDEFAULT);
			return;
		case OmtPackage.SWITCHES__OBJECT_CLASS_RELEVANCE_ADVISORY:
			unsetObjectClassRelevanceAdvisory();
			return;
		case OmtPackage.SWITCHES__OBJECT_CLASS_RELEVANCE_ADVISORY_NOTES:
			setObjectClassRelevanceAdvisoryNotes(OBJECT_CLASS_RELEVANCE_ADVISORY_NOTES_EDEFAULT);
			return;
		case OmtPackage.SWITCHES__SERVICE_REPORTING:
			unsetServiceReporting();
			return;
		case OmtPackage.SWITCHES__SERVICE_REPORTING_NOTES:
			setServiceReportingNotes(SERVICE_REPORTING_NOTES_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case OmtPackage.SWITCHES__ATTRIBUTE_RELEVANCE_ADVISORY:
			return isSetAttributeRelevanceAdvisory();
		case OmtPackage.SWITCHES__ATTRIBUTE_RELEVANCE_ADVISORY_NOTES:
			return ATTRIBUTE_RELEVANCE_ADVISORY_NOTES_EDEFAULT == null ? attributeRelevanceAdvisoryNotes != null
					: !ATTRIBUTE_RELEVANCE_ADVISORY_NOTES_EDEFAULT.equals(attributeRelevanceAdvisoryNotes);
		case OmtPackage.SWITCHES__ATTRIBUTE_SCOPE_ADVISORY:
			return isSetAttributeScopeAdvisory();
		case OmtPackage.SWITCHES__ATTRIBUTE_SCOPE_ADVISORY_NOTES:
			return ATTRIBUTE_SCOPE_ADVISORY_NOTES_EDEFAULT == null ? attributeScopeAdvisoryNotes != null
					: !ATTRIBUTE_SCOPE_ADVISORY_NOTES_EDEFAULT.equals(attributeScopeAdvisoryNotes);
		case OmtPackage.SWITCHES__AUTO_PROVIDE:
			return isSetAutoProvide();
		case OmtPackage.SWITCHES__AUTO_PROVIDE_NOTES:
			return AUTO_PROVIDE_NOTES_EDEFAULT == null ? autoProvideNotes != null : !AUTO_PROVIDE_NOTES_EDEFAULT
					.equals(autoProvideNotes);
		case OmtPackage.SWITCHES__CONVEY_REGION_DESIGNATOR_SETS:
			return isSetConveyRegionDesignatorSets();
		case OmtPackage.SWITCHES__CONVEY_REGION_DESIGNATOR_SETS_NOTES:
			return CONVEY_REGION_DESIGNATOR_SETS_NOTES_EDEFAULT == null ? conveyRegionDesignatorSetsNotes != null
					: !CONVEY_REGION_DESIGNATOR_SETS_NOTES_EDEFAULT.equals(conveyRegionDesignatorSetsNotes);
		case OmtPackage.SWITCHES__INTERACTION_RELEVANCE_ADVISORY:
			return isSetInteractionRelevanceAdvisory();
		case OmtPackage.SWITCHES__INTERACTION_RELEVANCE_ADVISORY_NOTES:
			return INTERACTION_RELEVANCE_ADVISORY_NOTES_EDEFAULT == null ? interactionRelevanceAdvisoryNotes != null
					: !INTERACTION_RELEVANCE_ADVISORY_NOTES_EDEFAULT.equals(interactionRelevanceAdvisoryNotes);
		case OmtPackage.SWITCHES__OBJECT_CLASS_RELEVANCE_ADVISORY:
			return isSetObjectClassRelevanceAdvisory();
		case OmtPackage.SWITCHES__OBJECT_CLASS_RELEVANCE_ADVISORY_NOTES:
			return OBJECT_CLASS_RELEVANCE_ADVISORY_NOTES_EDEFAULT == null ? objectClassRelevanceAdvisoryNotes != null
					: !OBJECT_CLASS_RELEVANCE_ADVISORY_NOTES_EDEFAULT.equals(objectClassRelevanceAdvisoryNotes);
		case OmtPackage.SWITCHES__SERVICE_REPORTING:
			return isSetServiceReporting();
		case OmtPackage.SWITCHES__SERVICE_REPORTING_NOTES:
			return SERVICE_REPORTING_NOTES_EDEFAULT == null ? serviceReportingNotes != null
					: !SERVICE_REPORTING_NOTES_EDEFAULT.equals(serviceReportingNotes);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (attributeRelevanceAdvisory: ");
		if (attributeRelevanceAdvisoryESet)
			result.append(attributeRelevanceAdvisory);
		else
			result.append("<unset>");
		result.append(", attributeRelevanceAdvisoryNotes: ");
		result.append(attributeRelevanceAdvisoryNotes);
		result.append(", attributeScopeAdvisory: ");
		if (attributeScopeAdvisoryESet)
			result.append(attributeScopeAdvisory);
		else
			result.append("<unset>");
		result.append(", attributeScopeAdvisoryNotes: ");
		result.append(attributeScopeAdvisoryNotes);
		result.append(", autoProvide: ");
		if (autoProvideESet)
			result.append(autoProvide);
		else
			result.append("<unset>");
		result.append(", autoProvideNotes: ");
		result.append(autoProvideNotes);
		result.append(", conveyRegionDesignatorSets: ");
		if (conveyRegionDesignatorSetsESet)
			result.append(conveyRegionDesignatorSets);
		else
			result.append("<unset>");
		result.append(", conveyRegionDesignatorSetsNotes: ");
		result.append(conveyRegionDesignatorSetsNotes);
		result.append(", interactionRelevanceAdvisory: ");
		if (interactionRelevanceAdvisoryESet)
			result.append(interactionRelevanceAdvisory);
		else
			result.append("<unset>");
		result.append(", interactionRelevanceAdvisoryNotes: ");
		result.append(interactionRelevanceAdvisoryNotes);
		result.append(", objectClassRelevanceAdvisory: ");
		if (objectClassRelevanceAdvisoryESet)
			result.append(objectClassRelevanceAdvisory);
		else
			result.append("<unset>");
		result.append(", objectClassRelevanceAdvisoryNotes: ");
		result.append(objectClassRelevanceAdvisoryNotes);
		result.append(", serviceReporting: ");
		if (serviceReportingESet)
			result.append(serviceReporting);
		else
			result.append("<unset>");
		result.append(", serviceReportingNotes: ");
		result.append(serviceReportingNotes);
		result.append(')');
		return result.toString();
	}

} // SwitchesImpl
