/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt.impl;

import java.util.List;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eodisp.hla.crc.omt.Dimension;
import org.eodisp.hla.crc.omt.OmtPackage;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Dimension</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.DimensionImpl#getDataType <em>Data Type</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.DimensionImpl#getDataTypeNotes <em>Data Type Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.DimensionImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.DimensionImpl#getNameNotes <em>Name Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.DimensionImpl#getNormalization <em>Normalization</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.DimensionImpl#getNormalizationNotes <em>Normalization Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.DimensionImpl#getUpperBound <em>Upper Bound</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.DimensionImpl#getUpperBoundNotes <em>Upper Bound Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.DimensionImpl#getValue <em>Value</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.DimensionImpl#getValueNotes <em>Value Notes</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class DimensionImpl extends EObjectImpl implements Dimension {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The default value of the '{@link #getDataType() <em>Data Type</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDataType()
	 * @generated
	 * @ordered
	 */
	protected static final String DATA_TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDataType() <em>Data Type</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDataType()
	 * @generated
	 * @ordered
	 */
	protected String dataType = DATA_TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getDataTypeNotes() <em>Data Type Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDataTypeNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List DATA_TYPE_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDataTypeNotes() <em>Data Type Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDataTypeNotes()
	 * @generated
	 * @ordered
	 */
	protected List dataTypeNotes = DATA_TYPE_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getNameNotes() <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getNameNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List NAME_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNameNotes() <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getNameNotes()
	 * @generated
	 * @ordered
	 */
	protected List nameNotes = NAME_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getNormalization() <em>Normalization</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getNormalization()
	 * @generated
	 * @ordered
	 */
	protected static final Object NORMALIZATION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNormalization() <em>Normalization</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getNormalization()
	 * @generated
	 * @ordered
	 */
	protected Object normalization = NORMALIZATION_EDEFAULT;

	/**
	 * The default value of the '{@link #getNormalizationNotes() <em>Normalization Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getNormalizationNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List NORMALIZATION_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNormalizationNotes() <em>Normalization Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getNormalizationNotes()
	 * @generated
	 * @ordered
	 */
	protected List normalizationNotes = NORMALIZATION_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getUpperBound() <em>Upper Bound</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getUpperBound()
	 * @generated
	 * @ordered
	 */
	protected static final Object UPPER_BOUND_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getUpperBound() <em>Upper Bound</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getUpperBound()
	 * @generated
	 * @ordered
	 */
	protected Object upperBound = UPPER_BOUND_EDEFAULT;

	/**
	 * The default value of the '{@link #getUpperBoundNotes() <em>Upper Bound Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getUpperBoundNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List UPPER_BOUND_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getUpperBoundNotes() <em>Upper Bound Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getUpperBoundNotes()
	 * @generated
	 * @ordered
	 */
	protected List upperBoundNotes = UPPER_BOUND_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getValue() <em>Value</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getValue()
	 * @generated
	 * @ordered
	 */
	protected static final Object VALUE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getValue() <em>Value</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getValue()
	 * @generated
	 * @ordered
	 */
	protected Object value = VALUE_EDEFAULT;

	/**
	 * The default value of the '{@link #getValueNotes() <em>Value Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getValueNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List VALUE_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getValueNotes() <em>Value Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getValueNotes()
	 * @generated
	 * @ordered
	 */
	protected List valueNotes = VALUE_NOTES_EDEFAULT;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected DimensionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return OmtPackage.Literals.DIMENSION;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String getDataType() {
		return dataType;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setDataType(String newDataType) {
		String oldDataType = dataType;
		dataType = newDataType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.DIMENSION__DATA_TYPE,
					oldDataType,
					dataType));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getDataTypeNotes() {
		return dataTypeNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setDataTypeNotes(List newDataTypeNotes) {
		List oldDataTypeNotes = dataTypeNotes;
		dataTypeNotes = newDataTypeNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.DIMENSION__DATA_TYPE_NOTES,
					oldDataTypeNotes,
					dataTypeNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OmtPackage.DIMENSION__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getNameNotes() {
		return nameNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setNameNotes(List newNameNotes) {
		List oldNameNotes = nameNotes;
		nameNotes = newNameNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.DIMENSION__NAME_NOTES,
					oldNameNotes,
					nameNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getNormalization() {
		return normalization;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setNormalization(Object newNormalization) {
		Object oldNormalization = normalization;
		normalization = newNormalization;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.DIMENSION__NORMALIZATION,
					oldNormalization,
					normalization));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getNormalizationNotes() {
		return normalizationNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setNormalizationNotes(List newNormalizationNotes) {
		List oldNormalizationNotes = normalizationNotes;
		normalizationNotes = newNormalizationNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.DIMENSION__NORMALIZATION_NOTES,
					oldNormalizationNotes,
					normalizationNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getUpperBound() {
		return upperBound;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setUpperBound(Object newUpperBound) {
		Object oldUpperBound = upperBound;
		upperBound = newUpperBound;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.DIMENSION__UPPER_BOUND,
					oldUpperBound,
					upperBound));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getUpperBoundNotes() {
		return upperBoundNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setUpperBoundNotes(List newUpperBoundNotes) {
		List oldUpperBoundNotes = upperBoundNotes;
		upperBoundNotes = newUpperBoundNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.DIMENSION__UPPER_BOUND_NOTES,
					oldUpperBoundNotes,
					upperBoundNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getValue() {
		return value;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setValue(Object newValue) {
		Object oldValue = value;
		value = newValue;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OmtPackage.DIMENSION__VALUE, oldValue, value));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getValueNotes() {
		return valueNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setValueNotes(List newValueNotes) {
		List oldValueNotes = valueNotes;
		valueNotes = newValueNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.DIMENSION__VALUE_NOTES,
					oldValueNotes,
					valueNotes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case OmtPackage.DIMENSION__DATA_TYPE:
			return getDataType();
		case OmtPackage.DIMENSION__DATA_TYPE_NOTES:
			return getDataTypeNotes();
		case OmtPackage.DIMENSION__NAME:
			return getName();
		case OmtPackage.DIMENSION__NAME_NOTES:
			return getNameNotes();
		case OmtPackage.DIMENSION__NORMALIZATION:
			return getNormalization();
		case OmtPackage.DIMENSION__NORMALIZATION_NOTES:
			return getNormalizationNotes();
		case OmtPackage.DIMENSION__UPPER_BOUND:
			return getUpperBound();
		case OmtPackage.DIMENSION__UPPER_BOUND_NOTES:
			return getUpperBoundNotes();
		case OmtPackage.DIMENSION__VALUE:
			return getValue();
		case OmtPackage.DIMENSION__VALUE_NOTES:
			return getValueNotes();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case OmtPackage.DIMENSION__DATA_TYPE:
			setDataType((String) newValue);
			return;
		case OmtPackage.DIMENSION__DATA_TYPE_NOTES:
			setDataTypeNotes((List) newValue);
			return;
		case OmtPackage.DIMENSION__NAME:
			setName((String) newValue);
			return;
		case OmtPackage.DIMENSION__NAME_NOTES:
			setNameNotes((List) newValue);
			return;
		case OmtPackage.DIMENSION__NORMALIZATION:
			setNormalization((Object) newValue);
			return;
		case OmtPackage.DIMENSION__NORMALIZATION_NOTES:
			setNormalizationNotes((List) newValue);
			return;
		case OmtPackage.DIMENSION__UPPER_BOUND:
			setUpperBound((Object) newValue);
			return;
		case OmtPackage.DIMENSION__UPPER_BOUND_NOTES:
			setUpperBoundNotes((List) newValue);
			return;
		case OmtPackage.DIMENSION__VALUE:
			setValue((Object) newValue);
			return;
		case OmtPackage.DIMENSION__VALUE_NOTES:
			setValueNotes((List) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
		case OmtPackage.DIMENSION__DATA_TYPE:
			setDataType(DATA_TYPE_EDEFAULT);
			return;
		case OmtPackage.DIMENSION__DATA_TYPE_NOTES:
			setDataTypeNotes(DATA_TYPE_NOTES_EDEFAULT);
			return;
		case OmtPackage.DIMENSION__NAME:
			setName(NAME_EDEFAULT);
			return;
		case OmtPackage.DIMENSION__NAME_NOTES:
			setNameNotes(NAME_NOTES_EDEFAULT);
			return;
		case OmtPackage.DIMENSION__NORMALIZATION:
			setNormalization(NORMALIZATION_EDEFAULT);
			return;
		case OmtPackage.DIMENSION__NORMALIZATION_NOTES:
			setNormalizationNotes(NORMALIZATION_NOTES_EDEFAULT);
			return;
		case OmtPackage.DIMENSION__UPPER_BOUND:
			setUpperBound(UPPER_BOUND_EDEFAULT);
			return;
		case OmtPackage.DIMENSION__UPPER_BOUND_NOTES:
			setUpperBoundNotes(UPPER_BOUND_NOTES_EDEFAULT);
			return;
		case OmtPackage.DIMENSION__VALUE:
			setValue(VALUE_EDEFAULT);
			return;
		case OmtPackage.DIMENSION__VALUE_NOTES:
			setValueNotes(VALUE_NOTES_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case OmtPackage.DIMENSION__DATA_TYPE:
			return DATA_TYPE_EDEFAULT == null ? dataType != null : !DATA_TYPE_EDEFAULT.equals(dataType);
		case OmtPackage.DIMENSION__DATA_TYPE_NOTES:
			return DATA_TYPE_NOTES_EDEFAULT == null ? dataTypeNotes != null : !DATA_TYPE_NOTES_EDEFAULT
					.equals(dataTypeNotes);
		case OmtPackage.DIMENSION__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case OmtPackage.DIMENSION__NAME_NOTES:
			return NAME_NOTES_EDEFAULT == null ? nameNotes != null : !NAME_NOTES_EDEFAULT.equals(nameNotes);
		case OmtPackage.DIMENSION__NORMALIZATION:
			return NORMALIZATION_EDEFAULT == null ? normalization != null : !NORMALIZATION_EDEFAULT
					.equals(normalization);
		case OmtPackage.DIMENSION__NORMALIZATION_NOTES:
			return NORMALIZATION_NOTES_EDEFAULT == null ? normalizationNotes != null : !NORMALIZATION_NOTES_EDEFAULT
					.equals(normalizationNotes);
		case OmtPackage.DIMENSION__UPPER_BOUND:
			return UPPER_BOUND_EDEFAULT == null ? upperBound != null : !UPPER_BOUND_EDEFAULT.equals(upperBound);
		case OmtPackage.DIMENSION__UPPER_BOUND_NOTES:
			return UPPER_BOUND_NOTES_EDEFAULT == null ? upperBoundNotes != null : !UPPER_BOUND_NOTES_EDEFAULT
					.equals(upperBoundNotes);
		case OmtPackage.DIMENSION__VALUE:
			return VALUE_EDEFAULT == null ? value != null : !VALUE_EDEFAULT.equals(value);
		case OmtPackage.DIMENSION__VALUE_NOTES:
			return VALUE_NOTES_EDEFAULT == null ? valueNotes != null : !VALUE_NOTES_EDEFAULT.equals(valueNotes);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (dataType: ");
		result.append(dataType);
		result.append(", dataTypeNotes: ");
		result.append(dataTypeNotes);
		result.append(", name: ");
		result.append(name);
		result.append(", nameNotes: ");
		result.append(nameNotes);
		result.append(", normalization: ");
		result.append(normalization);
		result.append(", normalizationNotes: ");
		result.append(normalizationNotes);
		result.append(", upperBound: ");
		result.append(upperBound);
		result.append(", upperBoundNotes: ");
		result.append(upperBoundNotes);
		result.append(", value: ");
		result.append(value);
		result.append(", valueNotes: ");
		result.append(valueNotes);
		result.append(')');
		return result.toString();
	}

} // DimensionImpl
