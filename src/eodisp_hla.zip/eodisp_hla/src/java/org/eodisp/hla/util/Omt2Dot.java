/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.hla.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.eclipse.emf.ecore.resource.Resource;
import org.eodisp.hla.crc.omt.DocumentRoot;
import org.eodisp.hla.crc.omt.util.OmtLoader;

/**
 * Creates a Dot file from an Omt file.
 * 
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class Omt2Dot {
	/**
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		File omtFile = new File(args[0]);
		// Exits if errors occur during load
		Resource resource = OmtLoader.loadOmtFromFile(omtFile);

		DocumentRoot documentRoot = (DocumentRoot) resource.getContents().get(0);
		Fom2DotTemplate template = new Fom2DotTemplate();
		final File file = new File(args[1]);
		System.out.printf("Write to: %s%n", file.getAbsolutePath());
		FileWriter fileWriter = new FileWriter(file);
		fileWriter.write(template.generate(new OmtModel(documentRoot.getObjectModel())));
		fileWriter.close();
	}
}
