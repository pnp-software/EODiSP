package org.eodisp.hla.common.handles;

import hla.rti1516.*;

public class ParameterHandleFactoryImpl implements ParameterHandleFactory {

	public ParameterHandle decode(byte[] buffer, int offset)
			throws CouldNotDecode, FederateNotExecutionMember {
//		 TODO
		return null;
//		return new ParameterHandleImpl(buffer, offset);
	}

}
