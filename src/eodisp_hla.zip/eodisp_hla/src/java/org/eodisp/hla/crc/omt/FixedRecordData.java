/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt;

import java.util.List;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Fixed Record Data</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.FixedRecordData#getField <em>Field</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.FixedRecordData#getEncoding <em>Encoding</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.FixedRecordData#getEncodingNotes <em>Encoding Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.FixedRecordData#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.FixedRecordData#getNameNotes <em>Name Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.FixedRecordData#getSemantics <em>Semantics</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.FixedRecordData#getSemanticsNotes <em>Semantics Notes</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eodisp.hla.crc.omt.OmtPackage#getFixedRecordData()
 * @model extendedMetaData="name='FixedRecordData' kind='elementOnly'"
 * @generated
 */
public interface FixedRecordData extends EObject {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * Returns the value of the '<em><b>Field</b></em>' containment reference list.
	 * The list contents are of type {@link org.eodisp.hla.crc.omt.Field}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Field</em>' containment reference list
	 * isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Field</em>' containment reference list.
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getFixedRecordData_Field()
	 * @model type="org.eodisp.hla.crc.omt.Field" containment="true" required="true"
	 *        extendedMetaData="kind='element' name='field' namespace='##targetNamespace'"
	 * @generated
	 */
	EList getField();

	/**
	 * Returns the value of the '<em><b>Encoding</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Encoding</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Encoding</em>' attribute.
	 * @see #setEncoding(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getFixedRecordData_Encoding()
	 * @model unique="false"
	 *        dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='encoding'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	Object getEncoding();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.FixedRecordData#getEncoding <em>Encoding</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Encoding</em>' attribute.
	 * @see #getEncoding()
	 * @generated
	 */
	void setEncoding(Object value);

	/**
	 * Returns the value of the '<em><b>Encoding Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Encoding Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Encoding Notes</em>' attribute.
	 * @see #setEncodingNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getFixedRecordData_EncodingNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='encodingNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getEncodingNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.FixedRecordData#getEncodingNotes <em>Encoding Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Encoding Notes</em>' attribute.
	 * @see #getEncodingNotes()
	 * @generated
	 */
	void setEncodingNotes(List value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getFixedRecordData_Name()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKEN"
	 *        required="true" extendedMetaData="kind='attribute' name='name'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.FixedRecordData#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Name Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name Notes</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name Notes</em>' attribute.
	 * @see #setNameNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getFixedRecordData_NameNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='nameNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getNameNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.FixedRecordData#getNameNotes <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name Notes</em>' attribute.
	 * @see #getNameNotes()
	 * @generated
	 */
	void setNameNotes(List value);

	/**
	 * Returns the value of the '<em><b>Semantics</b></em>' attribute. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Semantics</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Semantics</em>' attribute.
	 * @see #setSemantics(Object)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getFixedRecordData_Semantics()
	 * @model unique="false"
	 *        dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 *        extendedMetaData="kind='attribute' name='semantics'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	Object getSemantics();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.FixedRecordData#getSemantics <em>Semantics</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Semantics</em>' attribute.
	 * @see #getSemantics()
	 * @generated
	 */
	void setSemantics(Object value);

	/**
	 * Returns the value of the '<em><b>Semantics Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Semantics Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Semantics Notes</em>' attribute.
	 * @see #setSemanticsNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getFixedRecordData_SemanticsNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='semanticsNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSemanticsNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.FixedRecordData#getSemanticsNotes <em>Semantics Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Semantics Notes</em>' attribute.
	 * @see #getSemanticsNotes()
	 * @generated
	 */
	void setSemanticsNotes(List value);

} // FixedRecordData
