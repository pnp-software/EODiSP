package org.eodisp.hla.common.handles;

import hla.rti1516.*;

public class InteractionClassHandleFactoryImpl implements InteractionClassHandleFactory {

	public InteractionClassHandle decode(byte[] buffer, int offset)
			throws CouldNotDecode, FederateNotExecutionMember {
//		 TODO
		return null;
//		return new InteractionClassHandleImpl(buffer, offset);
	}

}
