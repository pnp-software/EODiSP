package org.eodisp.hla.common.handles;

import hla.rti1516.AttributeHandle;
import hla.rti1516.AttributeHandleSet;

import java.util.Collection;
import java.util.HashSet;

public class AttributeHandleSetImpl extends HashSet implements AttributeHandleSet {

	public AttributeHandleSetImpl() {
		super();
	}

	public boolean add(Object o) {
		if (!(o instanceof AttributeHandle)) {
			throw new IllegalArgumentException("object must be AttributeHandle");
		}

		return super.add(o);
	}

	public boolean remove(Object o) {
		if (!(o instanceof AttributeHandle)) {
			throw new IllegalArgumentException("object must be AttributeHandle");
		}

		return super.remove(o);
	}

	public boolean addAll(Collection c) {
		// It is not convenient if the collection needs to
		// be of type AttributeHandleSet.
		// TODO: we could check each entry, but this is slow. Just uncommenting
		// is for now.
		// if (!(c instanceof AttributeHandleSet)) {
		// throw new IllegalArgumentException(
		// "collection must be AttributeHandleSet");
		// }

		return super.addAll(c);
	}

	public boolean removeAll(Collection c) {
		if (!(c instanceof AttributeHandleSet)) {
			throw new IllegalArgumentException("collection must be AttributeHandleSet");
		}

		return super.removeAll(c);
	}

	public boolean retainAll(Collection c) {
		if (!(c instanceof AttributeHandleSet)) {
			throw new IllegalArgumentException("collection must be AttributeHandleSet");
		}

		return super.retainAll(c);
	}
}
