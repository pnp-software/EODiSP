package org.eodisp.hla.common.handles;

import hla.rti1516.AttributeRegionAssociation;
import hla.rti1516.AttributeSetRegionSetPairList;

import java.util.Collection;
import java.util.Vector;

public class AttributeSetRegionSetPairListImpl extends Vector implements
		AttributeSetRegionSetPairList {

	protected AttributeSetRegionSetPairListImpl(int capacity) {
		super(capacity);
	}

	public void add(int index, Object element) {
		if (!(element instanceof AttributeRegionAssociation)) {
			throw new IllegalArgumentException(
					"element must be AttributeSetRegionSetPair");
		}

		super.add(index, element);
	}

	public boolean add(Object element) {
		if (!(element instanceof AttributeRegionAssociation)) {
			throw new IllegalArgumentException(
					"element must be AttributeRegionAssociation");
		}

		return super.add(element);
	}

	public boolean addAll(Collection c) {
		if (!(c instanceof AttributeSetRegionSetPairList)) {
			throw new IllegalArgumentException(
					"collection must be AttributeSetRegionSetPairList");
		}

		return super.addAll(c);
	}

	public boolean addAll(int index, Collection c) {
		if (!(c instanceof AttributeSetRegionSetPairList)) {
			throw new IllegalArgumentException(
					"collection must be AttributeRegionAssociation");
		}

		return super.addAll(index, c);
	}

	public Object set(int index, Object element) {
		if (!(element instanceof AttributeRegionAssociation)) {
			throw new IllegalArgumentException(
					"element must be AttributeRegionAssociation");
		}

		return super.set(index, element);
	}
}
