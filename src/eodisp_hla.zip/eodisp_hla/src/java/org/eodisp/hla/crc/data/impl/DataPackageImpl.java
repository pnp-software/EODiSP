/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.data.impl;

import hla.rti1516.FederateHandle;

import hla.rti1516.ObjectInstanceHandle;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.eodisp.hla.common.lrc.LrcHandle;

import org.eodisp.hla.common.lrc.LrcRemote;

import org.eodisp.hla.crc.FederationExecution;

import org.eodisp.hla.crc.data.DataFactory;
import org.eodisp.hla.crc.data.DataPackage;
import org.eodisp.hla.crc.data.Federate;
import org.eodisp.hla.crc.data.ObjectInstance;

import org.eodisp.hla.crc.omt.OmtPackage;

import org.eodisp.hla.crc.omt.impl.OmtPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class DataPackageImpl extends EPackageImpl implements DataPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass federateEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass objectInstanceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType eFederateHandleEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType eFederationExecutionEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType eObjectInstanceHandleEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType eLrcHandleEDataType = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see org.eodisp.hla.crc.data.DataPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private DataPackageImpl() {
		super(eNS_URI, DataFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this
	 * model, and for any others upon which it depends.  Simple
	 * dependencies are satisfied by calling this method on all
	 * dependent packages before doing anything else.  This method drives
	 * initialization for interdependent packages directly, in parallel
	 * with this package, itself.
	 * <p>Of this package and its interdependencies, all packages which
	 * have not yet been registered by their URI values are first created
	 * and registered.  The packages are then initialized in two steps:
	 * meta-model objects for all of the packages are created before any
	 * are initialized, since one package's meta-model objects may refer to
	 * those of another.
	 * <p>Invocation of this method will not affect any packages that have
	 * already been initialized.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static DataPackage init() {
		if (isInited)
			return (DataPackage) EPackage.Registry.INSTANCE.getEPackage(DataPackage.eNS_URI);

		// Obtain or create and register package
		DataPackageImpl theDataPackage = (DataPackageImpl) (EPackage.Registry.INSTANCE.getEPackage(eNS_URI) instanceof DataPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(eNS_URI)
				: new DataPackageImpl());

		isInited = true;

		// Obtain or create and register interdependencies
		OmtPackageImpl theOmtPackage = (OmtPackageImpl) (EPackage.Registry.INSTANCE.getEPackage(OmtPackage.eNS_URI) instanceof OmtPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(OmtPackage.eNS_URI)
				: OmtPackage.eINSTANCE);

		// Create package meta-data objects
		theDataPackage.createPackageContents();
		theOmtPackage.createPackageContents();

		// Initialize created meta-data
		theDataPackage.initializePackageContents();
		theOmtPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theDataPackage.freeze();

		return theDataPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFederate() {
		return federateEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFederate_RegisteredObjectInstances() {
		return (EReference) federateEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFederate_SubscribedAttributes() {
		return (EReference) federateEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFederate_SubscribedInteractions() {
		return (EReference) federateEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFederate_PublishedAttributes() {
		return (EReference) federateEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFederate_PublishedInteractions() {
		return (EReference) federateEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFederate_LrcHandle() {
		return (EAttribute) federateEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFederate_Handle() {
		return (EAttribute) federateEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFederate_FederationExecution() {
		return (EAttribute) federateEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFederate_PublishedObjectClasses() {
		return (EReference) federateEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFederate_SubscribedObjectClasses() {
		return (EReference) federateEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getObjectInstance() {
		return objectInstanceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectInstance_Name() {
		return (EAttribute) objectInstanceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getObjectInstance_ObjectClass() {
		return (EReference) objectInstanceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getObjectInstance_RegisteringFederate() {
		return (EReference) objectInstanceEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getObjectInstance_Handle() {
		return (EAttribute) objectInstanceEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getEFederateHandle() {
		return eFederateHandleEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getEFederationExecution() {
		return eFederationExecutionEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getEObjectInstanceHandle() {
		return eObjectInstanceHandleEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getELrcHandle() {
		return eLrcHandleEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DataFactory getDataFactory() {
		return (DataFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		federateEClass = createEClass(FEDERATE);
		createEReference(federateEClass, FEDERATE__REGISTERED_OBJECT_INSTANCES);
		createEReference(federateEClass, FEDERATE__SUBSCRIBED_ATTRIBUTES);
		createEReference(federateEClass, FEDERATE__SUBSCRIBED_INTERACTIONS);
		createEReference(federateEClass, FEDERATE__PUBLISHED_ATTRIBUTES);
		createEReference(federateEClass, FEDERATE__PUBLISHED_INTERACTIONS);
		createEAttribute(federateEClass, FEDERATE__LRC_HANDLE);
		createEAttribute(federateEClass, FEDERATE__HANDLE);
		createEAttribute(federateEClass, FEDERATE__FEDERATION_EXECUTION);
		createEReference(federateEClass, FEDERATE__PUBLISHED_OBJECT_CLASSES);
		createEReference(federateEClass, FEDERATE__SUBSCRIBED_OBJECT_CLASSES);

		objectInstanceEClass = createEClass(OBJECT_INSTANCE);
		createEAttribute(objectInstanceEClass, OBJECT_INSTANCE__NAME);
		createEReference(objectInstanceEClass, OBJECT_INSTANCE__OBJECT_CLASS);
		createEReference(objectInstanceEClass, OBJECT_INSTANCE__REGISTERING_FEDERATE);
		createEAttribute(objectInstanceEClass, OBJECT_INSTANCE__HANDLE);

		// Create data types
		eFederateHandleEDataType = createEDataType(EFEDERATE_HANDLE);
		eFederationExecutionEDataType = createEDataType(EFEDERATION_EXECUTION);
		eObjectInstanceHandleEDataType = createEDataType(EOBJECT_INSTANCE_HANDLE);
		eLrcHandleEDataType = createEDataType(ELRC_HANDLE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		OmtPackage theOmtPackage = (OmtPackage) EPackage.Registry.INSTANCE.getEPackage(OmtPackage.eNS_URI);

		// Add supertypes to classes

		// Initialize classes and features; add operations and parameters
		initEClass(federateEClass, Federate.class, "Federate", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(
				getFederate_RegisteredObjectInstances(),
				this.getObjectInstance(),
				this.getObjectInstance_RegisteringFederate(),
				"registeredObjectInstances",
				"",
				0,
				-1,
				Federate.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getFederate_SubscribedAttributes(),
				theOmtPackage.getAttribute(),
				theOmtPackage.getAttribute_SubscribingFederates(),
				"subscribedAttributes",
				null,
				0,
				-1,
				Federate.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_COMPOSITE,
				IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getFederate_SubscribedInteractions(),
				theOmtPackage.getInteractionClass(),
				theOmtPackage.getInteractionClass_SubscribingFederates(),
				"subscribedInteractions",
				null,
				0,
				-1,
				Federate.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_COMPOSITE,
				IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getFederate_PublishedAttributes(),
				theOmtPackage.getAttribute(),
				theOmtPackage.getAttribute_PublishingFederates(),
				"publishedAttributes",
				null,
				0,
				-1,
				Federate.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_COMPOSITE,
				IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getFederate_PublishedInteractions(),
				theOmtPackage.getInteractionClass(),
				theOmtPackage.getInteractionClass_PublishingFederates(),
				"publishedInteractions",
				null,
				0,
				-1,
				Federate.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_COMPOSITE,
				IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getFederate_LrcHandle(),
				this.getELrcHandle(),
				"lrcHandle",
				null,
				0,
				1,
				Federate.class,
				IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getFederate_Handle(),
				this.getEFederateHandle(),
				"handle",
				null,
				0,
				1,
				Federate.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getFederate_FederationExecution(),
				this.getEFederationExecution(),
				"federationExecution",
				null,
				0,
				1,
				Federate.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getFederate_PublishedObjectClasses(),
				theOmtPackage.getObjectClass(),
				null,
				"publishedObjectClasses",
				"",
				0,
				-1,
				Federate.class,
				IS_TRANSIENT,
				IS_VOLATILE,
				!IS_CHANGEABLE,
				!IS_COMPOSITE,
				IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				!IS_UNIQUE,
				!IS_DERIVED,
				!IS_ORDERED);
		initEReference(
				getFederate_SubscribedObjectClasses(),
				theOmtPackage.getObjectClass(),
				null,
				"subscribedObjectClasses",
				"",
				0,
				-1,
				Federate.class,
				IS_TRANSIENT,
				IS_VOLATILE,
				!IS_CHANGEABLE,
				!IS_COMPOSITE,
				IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				!IS_UNIQUE,
				!IS_DERIVED,
				!IS_ORDERED);

		initEClass(
				objectInstanceEClass,
				ObjectInstance.class,
				"ObjectInstance",
				!IS_ABSTRACT,
				!IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(
				getObjectInstance_Name(),
				ecorePackage.getEString(),
				"name",
				null,
				0,
				1,
				ObjectInstance.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getObjectInstance_ObjectClass(),
				theOmtPackage.getObjectClass(),
				null,
				"objectClass",
				null,
				1,
				1,
				ObjectInstance.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_COMPOSITE,
				IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEReference(
				getObjectInstance_RegisteringFederate(),
				this.getFederate(),
				this.getFederate_RegisteredObjectInstances(),
				"registeringFederate",
				null,
				0,
				1,
				ObjectInstance.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_COMPOSITE,
				!IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getObjectInstance_Handle(),
				this.getEObjectInstanceHandle(),
				"handle",
				null,
				1,
				1,
				ObjectInstance.class,
				!IS_TRANSIENT,
				!IS_VOLATILE,
				IS_CHANGEABLE,
				!IS_UNSETTABLE,
				!IS_ID,
				IS_UNIQUE,
				!IS_DERIVED,
				IS_ORDERED);

		// Initialize data types
		initEDataType(
				eFederateHandleEDataType,
				FederateHandle.class,
				"EFederateHandle",
				IS_SERIALIZABLE,
				!IS_GENERATED_INSTANCE_CLASS);
		initEDataType(
				eFederationExecutionEDataType,
				FederationExecution.class,
				"EFederationExecution",
				!IS_SERIALIZABLE,
				!IS_GENERATED_INSTANCE_CLASS);
		initEDataType(
				eObjectInstanceHandleEDataType,
				ObjectInstanceHandle.class,
				"EObjectInstanceHandle",
				IS_SERIALIZABLE,
				!IS_GENERATED_INSTANCE_CLASS);
		initEDataType(eLrcHandleEDataType, LrcHandle.class, "ELrcHandle", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);

		// Create resource
		createResource(eNS_URI);
	}

} //DataPackageImpl
