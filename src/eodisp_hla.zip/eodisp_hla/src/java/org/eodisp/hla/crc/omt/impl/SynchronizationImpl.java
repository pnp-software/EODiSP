/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt.impl;

import java.util.List;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eodisp.hla.crc.omt.OmtPackage;
import org.eodisp.hla.crc.omt.SyncCapabilityEnum;
import org.eodisp.hla.crc.omt.Synchronization;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Synchronization</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SynchronizationImpl#getCapability <em>Capability</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SynchronizationImpl#getCapabilityNotes <em>Capability Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SynchronizationImpl#getDataType <em>Data Type</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SynchronizationImpl#getDataTypeNotes <em>Data Type Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SynchronizationImpl#getLabel <em>Label</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SynchronizationImpl#getLabelNotes <em>Label Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SynchronizationImpl#getSemantics <em>Semantics</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.SynchronizationImpl#getSemanticsNotes <em>Semantics Notes</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class SynchronizationImpl extends EObjectImpl implements Synchronization {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The default value of the '{@link #getCapability() <em>Capability</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getCapability()
	 * @generated
	 * @ordered
	 */
	protected static final SyncCapabilityEnum CAPABILITY_EDEFAULT = SyncCapabilityEnum.REGISTER_LITERAL;

	/**
	 * The cached value of the '{@link #getCapability() <em>Capability</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getCapability()
	 * @generated
	 * @ordered
	 */
	protected SyncCapabilityEnum capability = CAPABILITY_EDEFAULT;

	/**
	 * This is true if the Capability attribute has been set. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	protected boolean capabilityESet = false;

	/**
	 * The default value of the '{@link #getCapabilityNotes() <em>Capability Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getCapabilityNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List CAPABILITY_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCapabilityNotes() <em>Capability Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getCapabilityNotes()
	 * @generated
	 * @ordered
	 */
	protected List capabilityNotes = CAPABILITY_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getDataType() <em>Data Type</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDataType()
	 * @generated
	 * @ordered
	 */
	protected static final String DATA_TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDataType() <em>Data Type</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDataType()
	 * @generated
	 * @ordered
	 */
	protected String dataType = DATA_TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getDataTypeNotes() <em>Data Type Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDataTypeNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List DATA_TYPE_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDataTypeNotes() <em>Data Type Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDataTypeNotes()
	 * @generated
	 * @ordered
	 */
	protected List dataTypeNotes = DATA_TYPE_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getLabel() <em>Label</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getLabel()
	 * @generated
	 * @ordered
	 */
	protected static final String LABEL_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLabel() <em>Label</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getLabel()
	 * @generated
	 * @ordered
	 */
	protected String label = LABEL_EDEFAULT;

	/**
	 * The default value of the '{@link #getLabelNotes() <em>Label Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getLabelNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List LABEL_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLabelNotes() <em>Label Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getLabelNotes()
	 * @generated
	 * @ordered
	 */
	protected List labelNotes = LABEL_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getSemantics() <em>Semantics</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSemantics()
	 * @generated
	 * @ordered
	 */
	protected static final Object SEMANTICS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSemantics() <em>Semantics</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSemantics()
	 * @generated
	 * @ordered
	 */
	protected Object semantics = SEMANTICS_EDEFAULT;

	/**
	 * The default value of the '{@link #getSemanticsNotes() <em>Semantics Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSemanticsNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List SEMANTICS_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSemanticsNotes() <em>Semantics Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSemanticsNotes()
	 * @generated
	 * @ordered
	 */
	protected List semanticsNotes = SEMANTICS_NOTES_EDEFAULT;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected SynchronizationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return OmtPackage.Literals.SYNCHRONIZATION;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public SyncCapabilityEnum getCapability() {
		return capability;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setCapability(SyncCapabilityEnum newCapability) {
		SyncCapabilityEnum oldCapability = capability;
		capability = newCapability == null ? CAPABILITY_EDEFAULT : newCapability;
		boolean oldCapabilityESet = capabilityESet;
		capabilityESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SYNCHRONIZATION__CAPABILITY,
					oldCapability,
					capability,
					!oldCapabilityESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetCapability() {
		SyncCapabilityEnum oldCapability = capability;
		boolean oldCapabilityESet = capabilityESet;
		capability = CAPABILITY_EDEFAULT;
		capabilityESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.UNSET,
					OmtPackage.SYNCHRONIZATION__CAPABILITY,
					oldCapability,
					CAPABILITY_EDEFAULT,
					oldCapabilityESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetCapability() {
		return capabilityESet;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getCapabilityNotes() {
		return capabilityNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setCapabilityNotes(List newCapabilityNotes) {
		List oldCapabilityNotes = capabilityNotes;
		capabilityNotes = newCapabilityNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SYNCHRONIZATION__CAPABILITY_NOTES,
					oldCapabilityNotes,
					capabilityNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String getDataType() {
		return dataType;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setDataType(String newDataType) {
		String oldDataType = dataType;
		dataType = newDataType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SYNCHRONIZATION__DATA_TYPE,
					oldDataType,
					dataType));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getDataTypeNotes() {
		return dataTypeNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setDataTypeNotes(List newDataTypeNotes) {
		List oldDataTypeNotes = dataTypeNotes;
		dataTypeNotes = newDataTypeNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SYNCHRONIZATION__DATA_TYPE_NOTES,
					oldDataTypeNotes,
					dataTypeNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String getLabel() {
		return label;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setLabel(String newLabel) {
		String oldLabel = label;
		label = newLabel;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OmtPackage.SYNCHRONIZATION__LABEL, oldLabel, label));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getLabelNotes() {
		return labelNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setLabelNotes(List newLabelNotes) {
		List oldLabelNotes = labelNotes;
		labelNotes = newLabelNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SYNCHRONIZATION__LABEL_NOTES,
					oldLabelNotes,
					labelNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getSemantics() {
		return semantics;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setSemantics(Object newSemantics) {
		Object oldSemantics = semantics;
		semantics = newSemantics;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SYNCHRONIZATION__SEMANTICS,
					oldSemantics,
					semantics));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getSemanticsNotes() {
		return semanticsNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setSemanticsNotes(List newSemanticsNotes) {
		List oldSemanticsNotes = semanticsNotes;
		semanticsNotes = newSemanticsNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.SYNCHRONIZATION__SEMANTICS_NOTES,
					oldSemanticsNotes,
					semanticsNotes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case OmtPackage.SYNCHRONIZATION__CAPABILITY:
			return getCapability();
		case OmtPackage.SYNCHRONIZATION__CAPABILITY_NOTES:
			return getCapabilityNotes();
		case OmtPackage.SYNCHRONIZATION__DATA_TYPE:
			return getDataType();
		case OmtPackage.SYNCHRONIZATION__DATA_TYPE_NOTES:
			return getDataTypeNotes();
		case OmtPackage.SYNCHRONIZATION__LABEL:
			return getLabel();
		case OmtPackage.SYNCHRONIZATION__LABEL_NOTES:
			return getLabelNotes();
		case OmtPackage.SYNCHRONIZATION__SEMANTICS:
			return getSemantics();
		case OmtPackage.SYNCHRONIZATION__SEMANTICS_NOTES:
			return getSemanticsNotes();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case OmtPackage.SYNCHRONIZATION__CAPABILITY:
			setCapability((SyncCapabilityEnum) newValue);
			return;
		case OmtPackage.SYNCHRONIZATION__CAPABILITY_NOTES:
			setCapabilityNotes((List) newValue);
			return;
		case OmtPackage.SYNCHRONIZATION__DATA_TYPE:
			setDataType((String) newValue);
			return;
		case OmtPackage.SYNCHRONIZATION__DATA_TYPE_NOTES:
			setDataTypeNotes((List) newValue);
			return;
		case OmtPackage.SYNCHRONIZATION__LABEL:
			setLabel((String) newValue);
			return;
		case OmtPackage.SYNCHRONIZATION__LABEL_NOTES:
			setLabelNotes((List) newValue);
			return;
		case OmtPackage.SYNCHRONIZATION__SEMANTICS:
			setSemantics((Object) newValue);
			return;
		case OmtPackage.SYNCHRONIZATION__SEMANTICS_NOTES:
			setSemanticsNotes((List) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
		case OmtPackage.SYNCHRONIZATION__CAPABILITY:
			unsetCapability();
			return;
		case OmtPackage.SYNCHRONIZATION__CAPABILITY_NOTES:
			setCapabilityNotes(CAPABILITY_NOTES_EDEFAULT);
			return;
		case OmtPackage.SYNCHRONIZATION__DATA_TYPE:
			setDataType(DATA_TYPE_EDEFAULT);
			return;
		case OmtPackage.SYNCHRONIZATION__DATA_TYPE_NOTES:
			setDataTypeNotes(DATA_TYPE_NOTES_EDEFAULT);
			return;
		case OmtPackage.SYNCHRONIZATION__LABEL:
			setLabel(LABEL_EDEFAULT);
			return;
		case OmtPackage.SYNCHRONIZATION__LABEL_NOTES:
			setLabelNotes(LABEL_NOTES_EDEFAULT);
			return;
		case OmtPackage.SYNCHRONIZATION__SEMANTICS:
			setSemantics(SEMANTICS_EDEFAULT);
			return;
		case OmtPackage.SYNCHRONIZATION__SEMANTICS_NOTES:
			setSemanticsNotes(SEMANTICS_NOTES_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case OmtPackage.SYNCHRONIZATION__CAPABILITY:
			return isSetCapability();
		case OmtPackage.SYNCHRONIZATION__CAPABILITY_NOTES:
			return CAPABILITY_NOTES_EDEFAULT == null ? capabilityNotes != null : !CAPABILITY_NOTES_EDEFAULT
					.equals(capabilityNotes);
		case OmtPackage.SYNCHRONIZATION__DATA_TYPE:
			return DATA_TYPE_EDEFAULT == null ? dataType != null : !DATA_TYPE_EDEFAULT.equals(dataType);
		case OmtPackage.SYNCHRONIZATION__DATA_TYPE_NOTES:
			return DATA_TYPE_NOTES_EDEFAULT == null ? dataTypeNotes != null : !DATA_TYPE_NOTES_EDEFAULT
					.equals(dataTypeNotes);
		case OmtPackage.SYNCHRONIZATION__LABEL:
			return LABEL_EDEFAULT == null ? label != null : !LABEL_EDEFAULT.equals(label);
		case OmtPackage.SYNCHRONIZATION__LABEL_NOTES:
			return LABEL_NOTES_EDEFAULT == null ? labelNotes != null : !LABEL_NOTES_EDEFAULT.equals(labelNotes);
		case OmtPackage.SYNCHRONIZATION__SEMANTICS:
			return SEMANTICS_EDEFAULT == null ? semantics != null : !SEMANTICS_EDEFAULT.equals(semantics);
		case OmtPackage.SYNCHRONIZATION__SEMANTICS_NOTES:
			return SEMANTICS_NOTES_EDEFAULT == null ? semanticsNotes != null : !SEMANTICS_NOTES_EDEFAULT
					.equals(semanticsNotes);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (capability: ");
		if (capabilityESet)
			result.append(capability);
		else
			result.append("<unset>");
		result.append(", capabilityNotes: ");
		result.append(capabilityNotes);
		result.append(", dataType: ");
		result.append(dataType);
		result.append(", dataTypeNotes: ");
		result.append(dataTypeNotes);
		result.append(", label: ");
		result.append(label);
		result.append(", labelNotes: ");
		result.append(labelNotes);
		result.append(", semantics: ");
		result.append(semantics);
		result.append(", semanticsNotes: ");
		result.append(semanticsNotes);
		result.append(')');
		return result.toString();
	}

} // SynchronizationImpl
