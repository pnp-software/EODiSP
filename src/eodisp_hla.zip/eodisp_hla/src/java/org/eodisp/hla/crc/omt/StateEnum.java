/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.AbstractEnumerator;

/**
 * <!-- begin-user-doc --> A representation of the literals of the enumeration '<em><b>State Enum</b></em>',
 * and utility methods for working with them. <!-- end-user-doc -->
 * @see org.eodisp.hla.crc.omt.OmtPackage#getStateEnum()
 * @model
 * @generated
 */
public final class StateEnum extends AbstractEnumerator {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The '<em><b>Enabled</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Enabled</b></em>' literal object isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #ENABLED_LITERAL
	 * @model name="Enabled"
	 * @generated
	 * @ordered
	 */
	public static final int ENABLED = 0;

	/**
	 * The '<em><b>Disabled</b></em>' literal value.
	 * <!-- begin-user-doc
	 * -->
	 * <p>
	 * If the meaning of '<em><b>Disabled</b></em>' literal object isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #DISABLED_LITERAL
	 * @model name="Disabled"
	 * @generated
	 * @ordered
	 */
	public static final int DISABLED = 1;

	/**
	 * The '<em><b>Enabled</b></em>' literal object.
	 * <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * @see #ENABLED
	 * @generated
	 * @ordered
	 */
	public static final StateEnum ENABLED_LITERAL = new StateEnum(ENABLED, "Enabled", "Enabled");

	/**
	 * The '<em><b>Disabled</b></em>' literal object.
	 * <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * @see #DISABLED
	 * @generated
	 * @ordered
	 */
	public static final StateEnum DISABLED_LITERAL = new StateEnum(DISABLED, "Disabled", "Disabled");

	/**
	 * An array of all the '<em><b>State Enum</b></em>' enumerators. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	private static final StateEnum[] VALUES_ARRAY = new StateEnum[] { ENABLED_LITERAL, DISABLED_LITERAL, };

	/**
	 * A public read-only list of all the '<em><b>State Enum</b></em>' enumerators.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public static final List VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>State Enum</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public static StateEnum get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			StateEnum result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>State Enum</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static StateEnum getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			StateEnum result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>State Enum</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public static StateEnum get(int value) {
		switch (value) {
		case ENABLED:
			return ENABLED_LITERAL;
		case DISABLED:
			return DISABLED_LITERAL;
		}
		return null;
	}

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private StateEnum(int value, String name, String literal) {
		super(value, name, literal);
	}

} // StateEnum
