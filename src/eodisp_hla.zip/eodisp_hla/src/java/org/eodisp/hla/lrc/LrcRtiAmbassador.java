/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com
 *  mail: info@pnp-software.com
 */
package org.eodisp.hla.lrc;

import hla.rti1516.*;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.net.URL;
import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import net.jcip.annotations.GuardedBy;
import net.jcip.annotations.ThreadSafe;

import org.apache.log4j.Logger;
import org.eodisp.hla.common.crc.CrcRemote;
import org.eodisp.hla.common.crc.FederationExecutionRemote;
import org.eodisp.hla.common.handles.*;
import org.eodisp.hla.common.lrc.LrcRemote;
import org.eodisp.hla.lrc.application.LrcAppModule;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.FileUtil;

/**
 * Implementation of the RtiAmbassador interface. All methods of this class that
 * access the remote federation execution are synchronized to avoid concurrency
 * problems during join/resign.
 * 
 * @UML -------------------------------------------------------------------
 * @depend - <depends> - Lrc
 * @navassoc - remoteProxy 0..1 FederationExecutionRemote
 * @navassoc - remoteProxy 1 CrcRemote
 * @navassoc - federateHandle 0..1 FederateHandle
 * 
 */
@ThreadSafe
public class LrcRtiAmbassador implements RTIambassador {
	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	private final static Logger logger = Logger.getLogger(LrcRtiAmbassador.class);

	private static enum State {
		NOT_JOINED, JOINED, RESIGNED
	}

	/**
	 * The state of this RTI ambassador. Note that only the following state
	 * transitions are possible:
	 * 
	 * <p>
	 * <code>
	 *      NOT_JOINED -&gt; JOINED -&gt; RESIGNED
	 * </code>
	 */
	@GuardedBy("this")
	private State state = State.NOT_JOINED;

	/**
	 * The remote federation execution. Access to this field must must be
	 * synchronized because it indicates the connection state to the CRC.
	 */
	@GuardedBy("this")
	private FederationExecutionRemote federationExecutionRemote;

	/**
	 * The name of the federation execution that this federate is joined to.
	 * Only set when joined
	 */
	@GuardedBy("this")
	private String federationExecutionName;

	/**
	 * The handle of this federate. Only set when joined.
	 */
	@GuardedBy("this")
	private FederateHandle federateHandle;

	/**
	 * A proxy to the remote Crc. This is set at construction time, so this
	 * federate is always connected to the CRC.
	 */
	private final CrcRemote crcRemote;

	/* Handle Factories */
	private final static AttributeHandleFactory attributeHandleFactory = new AttributeHandleFactoryImpl();

	private final static DimensionHandleFactory dimensionHandleFactory = new DimensionHandleFactoryImpl();

	private final static InteractionClassHandleFactory interactionClassHandleFactory = new InteractionClassHandleFactoryImpl();

	private final static ObjectClassHandleFactory objectClassHandleFactory = new ObjectClassHandleFactoryImpl();

	private final static FederateHandleFactory federateHandleFactory = new FederateHandleFactoryImpl();

	private final static ObjectInstanceHandleFactory objectInstanceHandleFactory = new ObjectInstanceHandleFactoryImpl();

	private final static ParameterHandleFactory parameterHandleFactory = new ParameterHandleFactoryImpl();

	/* List/Set/Map factories */
	private final static AttributeHandleValueMapFactory attributeHandleValueMapFactory = new AttributeHandleValueMapFactoryImpl();

	private final static AttributeHandleSetFactory attributeHandleSetFactory = new AttributeHandleSetFactoryImpl();

	private final static AttributeSetRegionSetPairListFactory attributeSetRegionSetPairListFactory = new AttributeSetRegionSetPairListFactoryImpl();

	private final static DimensionHandleSetFactory dimensionHandleSetFactory = new DimensionHandleSetFactoryImpl();

	private final static FederateHandleSetFactory federateHandleSetFactory = new FederateHandleSetFactoryImpl();

	private final static ParameterHandleValueMapFactory parameterHandleValueMapFactory = new ParameterHandleValueMapFactoryImpl();

	private final static RegionHandleSetFactory regionHandleSetFactory = new RegionHandleSetFactoryImpl();

	public LrcRtiAmbassador(CrcRemote crcRemote) {
		this.crcRemote = crcRemote;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @throws NullPointerException
	 *             if either the federationExecutionName or the fdd are null
	 */
	public void createFederationExecution(String executionName, URL fdd) throws FederationExecutionAlreadyExists,
			CouldNotOpenFDD, ErrorReadingFDD, RTIinternalError {
		if( fdd == null ) {
			throw new CouldNotOpenFDD(String.format("Could not read fdd from URL: %s", fdd));
		}
		try {
			BufferedInputStream bufferedInputStream = (BufferedInputStream) fdd.getContent();
			byte[] fddByteArray = FileUtil.loadByteArray(bufferedInputStream);
			crcRemote.createFederationExecution(executionName, fddByteArray);
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		} catch (IOException e) {
			throw new CouldNotOpenFDD(String.format("Could not read fdd from URL: %s", fdd), e);
		}
	}

	public void destroyFederationExecution(String executionName) throws FederatesCurrentlyJoined,
			FederationExecutionDoesNotExist, RTIinternalError {
		try {
			crcRemote.destroyFederationExecution(executionName);
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		}
	}

	public synchronized FederateHandle joinFederationExecution(String federateType, String executionName,
			FederateAmbassador federateAmbassador, MobileFederateServices serviceReferences)
			throws FederateAlreadyExecutionMember, FederationExecutionDoesNotExist, SaveInProgress, RestoreInProgress,
			RTIinternalError {

		if (state == State.JOINED) {
			throw new FederateAlreadyExecutionMember(
					String
							.format(
									"Could not join federation execution. This RTI Ambassador is already joined to the "
											+ "federation execution: '%s'. Please create a new RTI Ambassador to join a second federate "
											+ "in this JVM to a federation execution",
									federationExecutionName));
		} else if (state == State.RESIGNED) {
			throw new RTIinternalError(String.format("This RTI ambassador has already been used and the federate was "
					+ "resigned from the federation execution '%s'. It is not possible to join "
					+ "with the same RTI ambassador again", federationExecutionName));
		}

		try {
			LrcAppModule lrcAppModule = (LrcAppModule) AppRegistry.getRootApp().getAppModule(LrcAppModule.ID);
			Lrc lrc = lrcAppModule.getLrc();
			federateHandle = lrc.joinFederationExecution(
					federateType,
					executionName,
					federateAmbassador,
					serviceReferences);
			state = State.JOINED;
			/*
			 * somebody else could have destroyed the federation execution in
			 * the meantime and the following getFederationExecution would
			 * return null. In practice this is only possible if the federation
			 * execution is destroyed forcibly, because a federation execution
			 * can normally not be destroyed if at least on federate is joined.
			 * This is always true at this point, because this federate is
			 * joined.
			 */
			federationExecutionRemote = crcRemote.getFederationExecution(executionName);
			if (federationExecutionRemote == null) {
				throw new FederationExecutionDoesNotExist(
						"Could not join federation execution. There is no federation execution with name "
								+ executionName);
			}
//			lrc.registerFederateAmbassador(executionName, federateHandle, federateAmbassador);
			this.federationExecutionName = executionName;

			return federateHandle;
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		}
	}

	public void resignFederationExecution(ResignAction resignAction) throws OwnershipAcquisitionPending,
			FederateOwnsAttributes, FederateNotExecutionMember, RTIinternalError {

		try {
			getFederationExecutionRemote().resign(resignAction, federateHandle);
			state = State.RESIGNED;
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		}
	}

	public void registerFederationSynchronizationPoint(String synchronizationPointLabel, byte[] userSuppliedTag)
			throws FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		try {
			getFederationExecutionRemote().registerFederationSynchronizationPoint(
					synchronizationPointLabel,
					userSuppliedTag,
					getFederateHandle());
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		}

	}

	public void registerFederationSynchronizationPoint(String synchronizationPointLabel, byte[] userSuppliedTag,
			FederateHandleSet synchronizationSet) throws FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
			RTIinternalError {
		try {
			getFederationExecutionRemote().registerFederationSynchronizationPoint(
					synchronizationPointLabel,
					userSuppliedTag,
					HandlesUtil.toGenericSet(synchronizationSet).toArray(new FederateHandle[0]),
					getFederateHandle());
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		}
	}

	public void synchronizationPointAchieved(String synchronizationPointLabel)
			throws SynchronizationPointLabelNotAnnounced, FederateNotExecutionMember, SaveInProgress,
			RestoreInProgress, RTIinternalError {
		try {
			getFederationExecutionRemote().synchronizationPointAchieved(synchronizationPointLabel, getFederateHandle());
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		}
	}

	public void requestFederationSave(String label) throws FederateNotExecutionMember, SaveInProgress,
			RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'requestFederationSave(String label)' is not implemented in the EODiSP HLA");
	}

	public void requestFederationSave(String label, LogicalTime theTime) throws LogicalTimeAlreadyPassed,
			InvalidLogicalTime, FederateUnableToUseTime, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
			RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'requestFederationSave(String label, LogicalTime theTime)' is not implemented in the EODiSP HLA");

	}

	public void federateSaveBegun() throws SaveNotInitiated, FederateNotExecutionMember, RestoreInProgress,
			RTIinternalError {
		throw new UnsupportedOperationException("The method 'federateSaveBegun()' is not implemented in the EODiSP HLA");

	}

	public void federateSaveComplete() throws FederateHasNotBegunSave, FederateNotExecutionMember, RestoreInProgress,
			RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'federateSaveComplete()' is not implemented in the EODiSP HLA");

	}

	public void federateSaveNotComplete() throws FederateHasNotBegunSave, FederateNotExecutionMember,
			RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'federateSaveNotComplete()' is not implemented in the EODiSP HLA");

	}

	public void queryFederationSaveStatus() throws FederateNotExecutionMember, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'queryFederationSaveStatus()' is not implemented in the EODiSP HLA");

	}

	public void requestFederationRestore(String label) throws FederateNotExecutionMember, SaveInProgress,
			RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'requestFederationRestore()' is not implemented in the EODiSP HLA");

	}

	public void federateRestoreComplete() throws RestoreNotRequested, FederateNotExecutionMember, SaveInProgress,
			RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'federateRestoreComplete()' is not implemented in the EODiSP HLA");

	}

	public void federateRestoreNotComplete() throws RestoreNotRequested, FederateNotExecutionMember, SaveInProgress,
			RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'federateRestoreNotComplete()' is not implemented in the EODiSP HLA");

	}

	public void queryFederationRestoreStatus() throws FederateNotExecutionMember, SaveInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'queryFederationRestoreStatus()' is not implemented in the EODiSP HLA");

	}

	public void publishObjectClassAttributes(ObjectClassHandle objectClassHandle, AttributeHandleSet attributeHandleSet)
			throws ObjectClassNotDefined, AttributeNotDefined, FederateNotExecutionMember, SaveInProgress,
			RestoreInProgress, RTIinternalError {

		try {
			getFederationExecutionRemote().publishObjectClassAttributes(
					objectClassHandle,
					HandlesUtil.toGenericSet(attributeHandleSet).toArray(new AttributeHandle[0]),
					federateHandle);
		} catch (InvalidFederateHandle e) {
			throw new RTIinternalError(e);
		} catch (InvalidAttributeHandle e) {
			throw new RTIinternalError(e);
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		} catch (InvalidObjectClassHandle e) {
			throw new RTIinternalError(e);
		}
	}

	public void unpublishObjectClass(ObjectClassHandle objectClassHandle) throws ObjectClassNotDefined,
			OwnershipAcquisitionPending, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
			RTIinternalError {
		try {
			getFederationExecutionRemote().unpublishObjectClass(objectClassHandle, federateHandle);
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		}
	}

	public void unpublishObjectClassAttributes(ObjectClassHandle objectClassHandle,
			AttributeHandleSet attributeHandleSet) throws ObjectClassNotDefined, AttributeNotDefined,
			OwnershipAcquisitionPending, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
			RTIinternalError {

		try {
			getFederationExecutionRemote().unpublishObjectClassAttributes(
					objectClassHandle,
					HandlesUtil.toGenericSet(attributeHandleSet).toArray(new AttributeHandle[0]),
					federateHandle);
		} catch (InvalidAttributeHandle e) {
			throw new RTIinternalError(e);
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		}
	}

	public void publishInteractionClass(InteractionClassHandle interactionClassHandle)
			throws InteractionClassNotDefined, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
			RTIinternalError {

		try {
			getFederationExecutionRemote().publishInteractionClass(interactionClassHandle, federateHandle);
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		}
	}

	public void unpublishInteractionClass(InteractionClassHandle interactionClassHandle)
			throws InteractionClassNotDefined, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
			RTIinternalError {

		try {
			getFederationExecutionRemote().unpublishInteractionClass(interactionClassHandle, federateHandle);
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		}
	}

	public void subscribeObjectClassAttributes(ObjectClassHandle objectClassHandle,
			AttributeHandleSet attributeHandleSet) throws ObjectClassNotDefined, AttributeNotDefined,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {

		try {
			getFederationExecutionRemote().subscribeObjectClassAttributes(
					objectClassHandle,
					HandlesUtil.toGenericSet(attributeHandleSet).toArray(new AttributeHandle[0]),
					federateHandle);
		} catch (InvalidAttributeHandle e) {
			throw new RTIinternalError(e);
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		}
	}

	public void subscribeObjectClassAttributesPassively(ObjectClassHandle theClass, AttributeHandleSet attributeList)
			throws ObjectClassNotDefined, AttributeNotDefined, FederateNotExecutionMember, SaveInProgress,
			RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'subscribeObjectClassAttributesPassively()' is not implemented in the EODiSP HLA");

	}

	public void unsubscribeObjectClass(ObjectClassHandle objectClassHandle) throws ObjectClassNotDefined,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {

		try {
			getFederationExecutionRemote().unsubscribeObjectClass(objectClassHandle, federateHandle);
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		}

	}

	public void unsubscribeObjectClassAttributes(ObjectClassHandle objectClassHandle,
			AttributeHandleSet attributeHandleSet) throws ObjectClassNotDefined, AttributeNotDefined,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {

		try {
			getFederationExecutionRemote().unpublishObjectClassAttributes(
					objectClassHandle,
					HandlesUtil.toGenericSet(attributeHandleSet).toArray(new AttributeHandle[0]),
					federateHandle);
		} catch (InvalidAttributeHandle e) {
			throw new RTIinternalError(e);
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		}
	}

	public void subscribeInteractionClass(InteractionClassHandle interactionClassHandle)
			throws InteractionClassNotDefined, FederateServiceInvocationsAreBeingReportedViaMOM,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {

		try {
			getFederationExecutionRemote().subscribeInteractionClass(interactionClassHandle, federateHandle);
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		}
	}

	public void subscribeInteractionClassPassively(InteractionClassHandle theClass) throws InteractionClassNotDefined,
			FederateServiceInvocationsAreBeingReportedViaMOM, FederateNotExecutionMember, SaveInProgress,
			RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'subscribeInteractionClassPassively(InteractionClassHandle theClass)' is not implemented in the EODiSP HLA");
	}

	public void unsubscribeInteractionClass(InteractionClassHandle interactionClassHandle)
			throws InteractionClassNotDefined, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
			RTIinternalError {

		try {
			getFederationExecutionRemote().unsubscribeInteractionClass(interactionClassHandle, federateHandle);
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		}
	}

	public void reserveObjectInstanceName(String theObjectName) throws IllegalName, FederateNotExecutionMember,
			SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'reserveObjectInstanceName(String theObjectName)' is not implemented in the EODiSP HLA");
	}

	public ObjectInstanceHandle registerObjectInstance(ObjectClassHandle objectClassHandle)
			throws ObjectClassNotDefined, ObjectClassNotPublished, FederateNotExecutionMember, SaveInProgress,
			RestoreInProgress, RTIinternalError {

		try {
			return getFederationExecutionRemote().registerObjectInstance(objectClassHandle, getFederateHandle());
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		} catch (InvalidObjectClassHandle e) {
			throw new RTIinternalError(e);
		}
	}

	public ObjectInstanceHandle registerObjectInstance(ObjectClassHandle objectClassHandle, String theObjectName)
			throws ObjectClassNotDefined, ObjectClassNotPublished, ObjectInstanceNameNotReserved,
			ObjectInstanceNameInUse, FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'registerObjectInstance(ObjectClassHandle objectClassHandle, String theObjectName)' is not implemented in the EODiSP HLA. Use 'registerObjectInstance(ObjectClassHandle theClass)' instead.");
	}

	public void updateAttributeValues(final ObjectInstanceHandle objectInstanceHandle,
			final AttributeHandleValueMap attributeHandleValueMap, final byte[] userSuppliedTag)
			throws ObjectInstanceNotKnown, AttributeNotDefined, AttributeNotOwned, FederateNotExecutionMember,
			RTIinternalError {
		try {
			final Map<LrcRemote, Map<FederateHandle, AttributeHandle[]>> lrcs = getFederationExecutionRemote()
					.getSubscriptions(
							objectInstanceHandle,
							HandlesUtil.getAttributeHandleArray(attributeHandleValueMap),
							getFederateHandle());
			// Publishing federationExectoinName is OK because it is immutable
			for (Map.Entry<LrcRemote, Map<FederateHandle, AttributeHandle[]>> entry : lrcs.entrySet()) {
				LrcRemote otherLrc = entry.getKey();
				Map<FederateHandle, AttributeHandle[]> subscriptions = entry.getValue();

				// Recreate value map. Only add values that are needed by one of
				// the
				// remote LRCs
				Map<AttributeHandle, byte[]> values = new HashMap<AttributeHandle, byte[]>();
				for (AttributeHandle[] handles : subscriptions.values()) {
					for (AttributeHandle handle : handles) {
						values.put(handle, (byte[]) attributeHandleValueMap.get(handle));
					}
				}

				try {
					logger.debug(String.format("Call reflectAttributeValues on other LRC [%s]", otherLrc));
					otherLrc.reflectAttributeValues(
							objectInstanceHandle,
							values,
							userSuppliedTag,
							subscriptions,
							federationExecutionName);
				} catch (RTIexception e) {
					logger.error("",e);
				} catch (RemoteException e) {
					logger.error("",e);
				}
			}
		} catch (InvalidAttributeHandle e) {
			logger.error("",e);
			throw new RTIinternalError(e);
		} catch (RemoteException e) {
			logger.error("",e);
			throw new CommunicationException(e);
		}
	}

	public MessageRetractionReturn updateAttributeValues(ObjectInstanceHandle theObject,
			AttributeHandleValueMap theAttributes, byte[] userSuppliedTag, LogicalTime theTime)
			throws ObjectInstanceNotKnown, AttributeNotDefined, AttributeNotOwned, InvalidLogicalTime,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'updateAttributeValues(ObjectInstanceHandle theObject,AttributeHandleValueMap "
						+ "theAttributes, byte[] userSuppliedTag, LogicalTime theTime)' is not implemented in the EODiSP HLA");
	}

	public void sendInteraction(InteractionClassHandle theInteraction, ParameterHandleValueMap theParameters,
			byte[] userSuppliedTag) throws InteractionClassNotPublished, InteractionClassNotDefined,
			InteractionParameterNotDefined, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
			RTIinternalError {
		try {
			Map<LrcRemote, Set<FederateHandle>> lrcs = getFederationExecutionRemote().getSubscriptions(
					theInteraction,
					getFederateHandle());
			for (Map.Entry<LrcRemote, Set<FederateHandle>> entry : lrcs.entrySet()) {
				LrcRemote lrcRemote = entry.getKey();
				Set<FederateHandle> federateHandles = entry.getValue();
				try {
					lrcRemote.receiveInteraction(
							theInteraction,
							theParameters,
							userSuppliedTag,
							OrderType.RECEIVE,
							TransportationType.HLA_RELIABLE,
							federateHandles.toArray(new FederateHandle[0]),
							getFederationExecutionName());
				} catch (InteractionClassNotRecognized e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InteractionParameterNotRecognized e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InteractionClassNotSubscribed e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (FederateInternalError e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		}

	}

	public MessageRetractionReturn sendInteraction(InteractionClassHandle theInteraction,
			ParameterHandleValueMap theParameters, byte[] userSuppliedTag, LogicalTime theTime)
			throws InteractionClassNotPublished, InteractionClassNotDefined, InteractionParameterNotDefined,
			InvalidLogicalTime, FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {

		throw new UnsupportedOperationException("The method 'sendInteraction(InteractionClassHandle theInteraction,"
				+ "ParameterHandleValueMap theParameters, byte[] userSuppliedTag, LogicalTime theTime)' "
				+ "is not implemented in the EODiSPHLA");
	}

	public void deleteObjectInstance(ObjectInstanceHandle objectHandle, byte[] userSuppliedTag)
			throws DeletePrivilegeNotHeld, ObjectInstanceNotKnown, FederateNotExecutionMember, SaveInProgress,
			RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'deleteObjectInstance(ObjectInstanceHandle objectHandle, byte[] userSuppliedTag)' is not implemented in the EODiSP HLA");

	}

	public MessageRetractionReturn deleteObjectInstance(ObjectInstanceHandle objectHandle, byte[] userSuppliedTag,
			LogicalTime theTime) throws DeletePrivilegeNotHeld, ObjectInstanceNotKnown, InvalidLogicalTime,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'deleteObjectInstance(ObjectInstanceHandle objectHandle, byte[] userSuppliedTag, LogicalTime theTime)' is not implemented in the EODiSP HLA");
	}

	public void localDeleteObjectInstance(ObjectInstanceHandle objectHandle) throws ObjectInstanceNotKnown,
			FederateOwnsAttributes, OwnershipAcquisitionPending, FederateNotExecutionMember, SaveInProgress,
			RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'localDeleteObjectInstance(ObjectInstanceHandle objectHandle)' is not implemented in the EODiSP HLA");

	}

	public void changeAttributeTransportationType(ObjectInstanceHandle theObject, AttributeHandleSet theAttributes,
			TransportationType theType) throws ObjectInstanceNotKnown, AttributeNotDefined, AttributeNotOwned,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'changeAttributeTransportationType(ObjectInstanceHandle theObject, AttributeHandleSet theAttributes, TransportationType theType)' is not implemented in the EODiSP HLA");
	}

	public void changeInteractionTransportationType(InteractionClassHandle theClass, TransportationType theType)
			throws InteractionClassNotDefined, InteractionClassNotPublished, FederateNotExecutionMember,
			SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'changeInteractionTransportationType(InteractionClassHandle theClass, TransportationType theType)' is not implemented in the EODiSP HLA");
	}

	public void requestAttributeValueUpdate(ObjectInstanceHandle objectInstanceHandle,
			AttributeHandleSet attributeHandleSet, byte[] userSuppliedTag) throws ObjectInstanceNotKnown,
			AttributeNotDefined, FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		try {
			getFederationExecutionRemote().requestAttributeValueUpdate(
					objectInstanceHandle,
					HandlesUtil.toGenericSet(attributeHandleSet).toArray(new AttributeHandle[0]),
					userSuppliedTag);
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		}

	}

	public void requestAttributeValueUpdate(ObjectClassHandle theClass, AttributeHandleSet theAttributes,
			byte[] userSuppliedTag) throws ObjectClassNotDefined, AttributeNotDefined, FederateNotExecutionMember,
			SaveInProgress, RestoreInProgress, RTIinternalError {

		// TODO Auto-generated method stub
	}

	public void unconditionalAttributeOwnershipDivestiture(ObjectInstanceHandle theObject,
			AttributeHandleSet theAttributes) throws ObjectInstanceNotKnown, AttributeNotDefined, AttributeNotOwned,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'unconditionalAttributeOwnershipDivestiture(ObjectInstanceHandle theObject, AttributeHandleSet theAttributes)' is not implemented in the EODiSP HLA");
	}

	public void negotiatedAttributeOwnershipDivestiture(ObjectInstanceHandle theObject,
			AttributeHandleSet theAttributes, byte[] userSuppliedTag) throws ObjectInstanceNotKnown,
			AttributeNotDefined, AttributeNotOwned, AttributeAlreadyBeingDivested, FederateNotExecutionMember,
			SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'negotiatedAttributeOwnershipDivestiture(ObjectInstanceHandle theObject, AttributeHandleSet theAttributes, byte[] userSuppliedTag)' is not implemented in the EODiSP HLA");
	}

	public void confirmDivestiture(ObjectInstanceHandle theObject, AttributeHandleSet theAttributes,
			byte[] userSuppliedTag) throws ObjectInstanceNotKnown, AttributeNotDefined, AttributeNotOwned,
			AttributeDivestitureWasNotRequested, NoAcquisitionPending, FederateNotExecutionMember, SaveInProgress,
			RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'confirmDivestiture(ObjectInstanceHandle theObject, AttributeHandleSet theAttributes, byte[] userSuppliedTag)' is not implemented in the EODiSP HLA");
	}

	public void attributeOwnershipAcquisition(ObjectInstanceHandle theObject, AttributeHandleSet desiredAttributes,
			byte[] userSuppliedTag) throws ObjectInstanceNotKnown, ObjectClassNotPublished, AttributeNotDefined,
			AttributeNotPublished, FederateOwnsAttributes, FederateNotExecutionMember, SaveInProgress,
			RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'attributeOwnershipAcquisition(ObjectInstanceHandle theObject, AttributeHandleSet desiredAttributes, byte[] userSuppliedTag)' is not implemented in the EODiSP HLA");
	}

	public void attributeOwnershipAcquisitionIfAvailable(ObjectInstanceHandle theObject,
			AttributeHandleSet desiredAttributes) throws ObjectInstanceNotKnown, ObjectClassNotPublished,
			AttributeNotDefined, AttributeNotPublished, FederateOwnsAttributes, AttributeAlreadyBeingAcquired,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'attributeOwnershipAcquisitionIfAvailable(ObjectInstanceHandle theObject, AttributeHandleSet desiredAttributes)' is not implemented in the EODiSP HLA");
	}

	public AttributeHandleSet attributeOwnershipDivestitureIfWanted(ObjectInstanceHandle theObject,
			AttributeHandleSet theAttributes) throws ObjectInstanceNotKnown, AttributeNotDefined, AttributeNotOwned,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'attributeOwnershipDivestitureIfWanted(ObjectInstanceHandle theObject, AttributeHandleSet theAttributes)' is not implemented in the EODiSP HLA");
	}

	public void cancelNegotiatedAttributeOwnershipDivestiture(ObjectInstanceHandle theObject,
			AttributeHandleSet theAttributes) throws ObjectInstanceNotKnown, AttributeNotDefined, AttributeNotOwned,
			AttributeDivestitureWasNotRequested, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
			RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'cancelNegotiatedAttributeOwnershipDivestiture()' is not implemented in the EODiSP HLA");

	}

	public void cancelAttributeOwnershipAcquisition(ObjectInstanceHandle objectInstanceHandle,
			AttributeHandleSet theAttributes) throws ObjectInstanceNotKnown, AttributeNotDefined,
			AttributeAlreadyOwned, AttributeAcquisitionWasNotRequested, FederateNotExecutionMember, SaveInProgress,
			RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'cancelAttributeOwnershipAcquisition()' is not implemented in the EODiSP HLA");
	}

	public void queryAttributeOwnership(ObjectInstanceHandle theObject, AttributeHandle theAttribute)
			throws ObjectInstanceNotKnown, AttributeNotDefined, FederateNotExecutionMember, SaveInProgress,
			RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'queryAttributeOwnership()' is not implemented in the EODiSP HLA");

	}

	public boolean isAttributeOwnedByFederate(ObjectInstanceHandle theObject, AttributeHandle theAttribute)
			throws ObjectInstanceNotKnown, AttributeNotDefined, FederateNotExecutionMember, SaveInProgress,
			RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'isAttributeOwnedByFederate()' is not implemented in the EODiSP HLA");
	}

	public void enableTimeRegulation(LogicalTimeInterval theLookahead) throws TimeRegulationAlreadyEnabled,
			InvalidLookahead, InTimeAdvancingState, RequestForTimeRegulationPending, FederateNotExecutionMember,
			SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'enableTimeRegulation()' is not implemented in the EODiSP HLA");

	}

	public void disableTimeRegulation() throws TimeRegulationIsNotEnabled, FederateNotExecutionMember, SaveInProgress,
			RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'disableTimeRegulation()' is not implemented in the EODiSP HLA");

	}

	public void enableTimeConstrained() throws TimeConstrainedAlreadyEnabled, InTimeAdvancingState,
			RequestForTimeConstrainedPending, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
			RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'enableTimeConstrained()' is not implemented in the EODiSP HLA");

	}

	public void disableTimeConstrained() throws TimeConstrainedIsNotEnabled, FederateNotExecutionMember,
			SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'disableTimeConstrained()' is not implemented in the EODiSP HLA");

	}

	public void timeAdvanceRequest(LogicalTime theTime) throws InvalidLogicalTime, LogicalTimeAlreadyPassed,
			InTimeAdvancingState, RequestForTimeRegulationPending, RequestForTimeConstrainedPending,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'timeAdvanceRequest()' is not implemented in the EODiSP HLA");

	}

	public void timeAdvanceRequestAvailable(LogicalTime theTime) throws InvalidLogicalTime, LogicalTimeAlreadyPassed,
			InTimeAdvancingState, RequestForTimeRegulationPending, RequestForTimeConstrainedPending,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'timeAdvanceRequestAvailable()' is not implemented in the EODiSP HLA");
	}

	public void nextMessageRequest(LogicalTime theTime) throws InvalidLogicalTime, LogicalTimeAlreadyPassed,
			InTimeAdvancingState, RequestForTimeRegulationPending, RequestForTimeConstrainedPending,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'nextMessageRequest()' is not implemented in the EODiSP HLA");

	}

	public void nextMessageRequestAvailable(LogicalTime theTime) throws InvalidLogicalTime, LogicalTimeAlreadyPassed,
			InTimeAdvancingState, RequestForTimeRegulationPending, RequestForTimeConstrainedPending,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'nextMessageRequestAvailable()' is not implemented in the EODiSP HLA");

	}

	public void flushQueueRequest(LogicalTime theTime) throws InvalidLogicalTime, LogicalTimeAlreadyPassed,
			InTimeAdvancingState, RequestForTimeRegulationPending, RequestForTimeConstrainedPending,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException("The method 'flushQueueRequest()' is not implemented in the EODiSP HLA");

	}

	public void enableAsynchronousDelivery() throws AsynchronousDeliveryAlreadyEnabled, FederateNotExecutionMember,
			SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'enableAsynchronousDelivery()' is not implemented in the EODiSP HLA");

	}

	public void disableAsynchronousDelivery() throws AsynchronousDeliveryAlreadyDisabled, FederateNotExecutionMember,
			SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'disableAsynchronousDelivery()' is not implemented in the EODiSP HLA");

	}

	public TimeQueryReturn queryGALT() throws FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
			RTIinternalError {
		throw new UnsupportedOperationException("The method 'queryGALT()' is not implemented in the EODiSP HLA");
	}

	public LogicalTime queryLogicalTime() throws FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
			RTIinternalError {
		throw new UnsupportedOperationException("The method 'queryLogicalTime()' is not implemented in the EODiSP HLA");
	}

	public TimeQueryReturn queryLITS() throws FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
			RTIinternalError {
		throw new UnsupportedOperationException("The method 'queryLITS()' is not implemented in the EODiSP HLA");
	}

	public void modifyLookahead(LogicalTimeInterval theLookahead) throws TimeRegulationIsNotEnabled, InvalidLookahead,
			InTimeAdvancingState, FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException("The method 'modifyLookahead()' is not implemented in the EODiSP HLA");
	}

	public LogicalTimeInterval queryLookahead() throws TimeRegulationIsNotEnabled, FederateNotExecutionMember,
			SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException("The method 'queryLookahead()' is not implemented in the EODiSP HLA");
	}

	public void retract(MessageRetractionHandle theHandle) throws InvalidMessageRetractionHandle,
			TimeRegulationIsNotEnabled, MessageCanNoLongerBeRetracted, FederateNotExecutionMember, SaveInProgress,
			RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException("The method 'retract()' is not implemented in the EODiSP HLA");

	}

	public void changeAttributeOrderType(ObjectInstanceHandle theObject, AttributeHandleSet theAttributes,
			OrderType theType) throws ObjectInstanceNotKnown, AttributeNotDefined, AttributeNotOwned,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'changeAttributeOrderType()' is not implemented in the EODiSP HLA");

	}

	public void changeInteractionOrderType(InteractionClassHandle theClass, OrderType theType)
			throws InteractionClassNotDefined, InteractionClassNotPublished, FederateNotExecutionMember,
			SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'changeInteractionOrderType()' is not implemented in the EODiSP HLA");

	}

	public RegionHandle createRegion(DimensionHandleSet dimensions) throws InvalidDimensionHandle,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException("The method 'createRegion()' is not implemented in the EODiSP HLA");
	}

	public void commitRegionModifications(RegionHandleSet regions) throws InvalidRegion,
			RegionNotCreatedByThisFederate, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
			RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'commitRegionModifications()' is not implemented in the EODiSP HLA");

	}

	public void deleteRegion(RegionHandle theRegion) throws InvalidRegion, RegionNotCreatedByThisFederate,
			RegionInUseForUpdateOrSubscription, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
			RTIinternalError {
		throw new UnsupportedOperationException("The method 'deleteRegion()' is not implemented in the EODiSP HLA");

	}

	public ObjectInstanceHandle registerObjectInstanceWithRegions(ObjectClassHandle theClass,
			AttributeSetRegionSetPairList attributesAndRegions) throws ObjectClassNotDefined, ObjectClassNotPublished,
			AttributeNotDefined, AttributeNotPublished, InvalidRegion, RegionNotCreatedByThisFederate,
			InvalidRegionContext, FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'registerObjectInstanceWithRegions()' is not implemented in the EODiSP HLA");
	}

	public ObjectInstanceHandle registerObjectInstanceWithRegions(ObjectClassHandle theClass,
			AttributeSetRegionSetPairList attributesAndRegions, String theObject) throws ObjectClassNotDefined,
			ObjectClassNotPublished, AttributeNotDefined, AttributeNotPublished, InvalidRegion,
			RegionNotCreatedByThisFederate, InvalidRegionContext, ObjectInstanceNameNotReserved,
			ObjectInstanceNameInUse, FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'registerObjectInstanceWithRegions()' is not implemented in the EODiSP HLA");
	}

	public void associateRegionsForUpdates(ObjectInstanceHandle theObject,
			AttributeSetRegionSetPairList attributesAndRegions) throws ObjectInstanceNotKnown, AttributeNotDefined,
			InvalidRegion, RegionNotCreatedByThisFederate, InvalidRegionContext, FederateNotExecutionMember,
			SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'associateRegionsForUpdates()' is not implemented in the EODiSP HLA");

	}

	public void unassociateRegionsForUpdates(ObjectInstanceHandle theObject,
			AttributeSetRegionSetPairList attributesAndRegions) throws ObjectInstanceNotKnown, AttributeNotDefined,
			InvalidRegion, RegionNotCreatedByThisFederate, FederateNotExecutionMember, SaveInProgress,
			RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'unassociateRegionsForUpdates()' is not implemented in the EODiSP HLA");

	}

	public void subscribeObjectClassAttributesWithRegions(ObjectClassHandle theClass,
			AttributeSetRegionSetPairList attributesAndRegions) throws ObjectClassNotDefined, AttributeNotDefined,
			InvalidRegion, RegionNotCreatedByThisFederate, InvalidRegionContext, FederateNotExecutionMember,
			SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'subscribeObjectClassAttributesWithRegions()' is not implemented in the EODiSP HLA");

	}

	public void subscribeObjectClassAttributesPassivelyWithRegions(ObjectClassHandle theClass,
			AttributeSetRegionSetPairList attributesAndRegions) throws ObjectClassNotDefined, AttributeNotDefined,
			InvalidRegion, RegionNotCreatedByThisFederate, InvalidRegionContext, FederateNotExecutionMember,
			SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'subscribeObjectClassAttributesPassivelyWithRegions()' is not implemented in the EODiSP HLA");

	}

	public void unsubscribeObjectClassAttributesWithRegions(ObjectClassHandle theClass,
			AttributeSetRegionSetPairList attributesAndRegions) throws ObjectClassNotDefined, AttributeNotDefined,
			InvalidRegion, RegionNotCreatedByThisFederate, FederateNotExecutionMember, SaveInProgress,
			RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'unsubscribeObjectClassAttributesWithRegions()' is not implemented in the EODiSP HLA");

	}

	public void subscribeInteractionClassWithRegions(InteractionClassHandle theClass, RegionHandleSet regions)
			throws InteractionClassNotDefined, InvalidRegion, RegionNotCreatedByThisFederate, InvalidRegionContext,
			FederateServiceInvocationsAreBeingReportedViaMOM, FederateNotExecutionMember, SaveInProgress,
			RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'subscribeInteractionClassWithRegions()' is not implemented in the EODiSP HLA");

	}

	public void subscribeInteractionClassPassivelyWithRegions(InteractionClassHandle theClass, RegionHandleSet regions)
			throws InteractionClassNotDefined, InvalidRegion, RegionNotCreatedByThisFederate, InvalidRegionContext,
			FederateServiceInvocationsAreBeingReportedViaMOM, FederateNotExecutionMember, SaveInProgress,
			RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'subscribeInteractionClassPassivelyWithRegions()' is not implemented in the EODiSP HLA");

	}

	public void unsubscribeInteractionClassWithRegions(InteractionClassHandle theClass, RegionHandleSet regions)
			throws InteractionClassNotDefined, InvalidRegion, RegionNotCreatedByThisFederate,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'unsubscribeInteractionClassWithRegions()' is not implemented in the EODiSP HLA");

	}

	public void sendInteractionWithRegions(InteractionClassHandle theInteraction,
			ParameterHandleValueMap theParameters, RegionHandleSet regions, byte[] userSuppliedTag)
			throws InteractionClassNotDefined, InteractionClassNotPublished, InteractionParameterNotDefined,
			InvalidRegion, RegionNotCreatedByThisFederate, InvalidRegionContext, FederateNotExecutionMember,
			SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'sendInteractionWithRegions()' is not implemented in the EODiSP HLA");

	}

	public MessageRetractionReturn sendInteractionWithRegions(InteractionClassHandle theInteraction,
			ParameterHandleValueMap theParameters, RegionHandleSet regions, byte[] userSuppliedTag, LogicalTime theTime)
			throws InteractionClassNotDefined, InteractionClassNotPublished, InteractionParameterNotDefined,
			InvalidRegion, RegionNotCreatedByThisFederate, InvalidRegionContext, InvalidLogicalTime,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'requestAttributeValueUpdateWithRegions()' is not implemented in the EODiSP HLA");
	}

	public void requestAttributeValueUpdateWithRegions(ObjectClassHandle theClass,
			AttributeSetRegionSetPairList attributesAndRegions, byte[] userSuppliedTag) throws ObjectClassNotDefined,
			AttributeNotDefined, InvalidRegion, RegionNotCreatedByThisFederate, InvalidRegionContext,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'requestAttributeValueUpdateWithRegions()' is not implemented in the EODiSP HLA");

	}

	public ObjectClassHandle getObjectClassHandle(String theName) throws NameNotFound, FederateNotExecutionMember,
			RTIinternalError {
		try {
			return getFederationExecutionRemote().getObjectClassHandle(theName);
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		}
	}

	public String getObjectClassName(ObjectClassHandle theHandle) throws InvalidObjectClassHandle,
			FederateNotExecutionMember, RTIinternalError {
		try {
			return getFederationExecutionRemote().getObjectClassName(theHandle);
		} catch (ObjectClassNotDefined e) {
			throw new RTIinternalError(e);
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		}
	}

	public AttributeHandle getAttributeHandle(ObjectClassHandle whichClass, String theName)
			throws InvalidObjectClassHandle, NameNotFound, FederateNotExecutionMember, RTIinternalError {
		try {
			return getFederationExecutionRemote().getAttributeHandle(whichClass, theName);
		} catch (ObjectClassNotDefined e) {
			throw new RTIinternalError(e);
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		}
	}

	public String getAttributeName(ObjectClassHandle whichClass, AttributeHandle theHandle)
			throws InvalidObjectClassHandle, InvalidAttributeHandle, AttributeNotDefined, FederateNotExecutionMember,
			RTIinternalError {
		try {
			return getFederationExecutionRemote().getAttributeName(whichClass, theHandle);
		} catch (ObjectClassNotDefined e) {
			throw new RTIinternalError(e);
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		}
	}

	public InteractionClassHandle getInteractionClassHandle(String theName) throws NameNotFound,
			FederateNotExecutionMember, RTIinternalError {
		try {
			return getFederationExecutionRemote().getInteractionClassHandle(theName);
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		}
	}

	public String getInteractionClassName(InteractionClassHandle theHandle) throws InvalidInteractionClassHandle,
			FederateNotExecutionMember, RTIinternalError {
		try {
			return getFederationExecutionRemote().getInteractionClassName(theHandle);
		} catch (InteractionClassNotDefined e) {
			throw new RTIinternalError(e);
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		}
	}

	public ParameterHandle getParameterHandle(InteractionClassHandle whichClass, String theName)
			throws InvalidInteractionClassHandle, NameNotFound, FederateNotExecutionMember, RTIinternalError {
		try {
			return getFederationExecutionRemote().getParameterHandle(whichClass, theName);
		} catch (InteractionClassNotDefined e) {
			throw new RTIinternalError(e);
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		}
	}

	public String getParameterName(InteractionClassHandle whichClass, ParameterHandle theHandle)
			throws InvalidInteractionClassHandle, InvalidParameterHandle, InteractionParameterNotDefined,
			FederateNotExecutionMember, RTIinternalError {
		try {
			return getFederationExecutionRemote().getParameterName(whichClass, theHandle);
		} catch (InteractionClassNotDefined e) {
			throw new RTIinternalError(e);
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		}
	}

	public ObjectInstanceHandle getObjectInstanceHandle(String theName) throws ObjectInstanceNotKnown,
			FederateNotExecutionMember, RTIinternalError {
		try {
			return getFederationExecutionRemote().getObjectInstanceHandle(theName);
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		}
	}

	public String getObjectInstanceName(ObjectInstanceHandle theHandle) throws ObjectInstanceNotKnown,
			FederateNotExecutionMember, RTIinternalError {
		try {
			return getFederationExecutionRemote().getObjectInstanceName(theHandle);
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		}
	}

	public DimensionHandle getDimensionHandle(String theName) throws NameNotFound, FederateNotExecutionMember,
			RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'getDimensionHandle()' is not implemented in the EODiSP HLA");
	}

	public String getDimensionName(DimensionHandle theHandle) throws InvalidDimensionHandle,
			FederateNotExecutionMember, RTIinternalError {
		throw new UnsupportedOperationException("The method 'getDimensionName()' is not implemented in the EODiSP HLA");
	}

	public long getDimensionUpperBound(DimensionHandle theHandle) throws InvalidDimensionHandle,
			FederateNotExecutionMember, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'getDimensionUpperBound()' is not implemented in the EODiSP HLA");
	}

	public DimensionHandleSet getAvailableDimensionsForClassAttribute(ObjectClassHandle whichClass,
			AttributeHandle theHandle) throws InvalidObjectClassHandle, InvalidAttributeHandle, AttributeNotDefined,
			FederateNotExecutionMember, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'getAvailableDimensionsForClassAttribute()' is not implemented in the EODiSP HLA");
	}

	public ObjectClassHandle getKnownObjectClassHandle(ObjectInstanceHandle theObject) throws ObjectInstanceNotKnown,
			FederateNotExecutionMember, RTIinternalError {
		try {
			return getFederationExecutionRemote().getKnownObjectClassHandle(theObject);
		} catch (RemoteException e) {
			throw new CommunicationException(e);
		}
	}

	public DimensionHandleSet getAvailableDimensionsForInteractionClass(InteractionClassHandle theHandle)
			throws InvalidInteractionClassHandle, FederateNotExecutionMember, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'getAvailableDimensionsForInteractionClass()' is not implemented in the EODiSP HLA");
	}

	public TransportationType getTransportationType(String theName) throws InvalidTransportationName,
			FederateNotExecutionMember, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'getTransportationType()' is not implemented in the EODiSP HLA");
	}

	public String getTransportationName(TransportationType theType) throws InvalidTransportationType,
			FederateNotExecutionMember, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'getTransportationName()' is not implemented in the EODiSP HLA");
	}

	public OrderType getOrderType(String theName) throws InvalidOrderName, FederateNotExecutionMember, RTIinternalError {
		throw new UnsupportedOperationException("The method 'getOrderType()' is not implemented in the EODiSP HLA");
	}

	public String getOrderName(OrderType theType) throws InvalidOrderType, FederateNotExecutionMember, RTIinternalError {
		throw new UnsupportedOperationException("The method 'getOrderName()' is not implemented in the EODiSP HLA");
	}

	public void enableObjectClassRelevanceAdvisorySwitch() throws FederateNotExecutionMember,
			ObjectClassRelevanceAdvisorySwitchIsOn, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'enableObjectClassRelevanceAdvisorySwitch()' is not implemented in the EODiSP HLA");

	}

	public void disableObjectClassRelevanceAdvisorySwitch() throws ObjectClassRelevanceAdvisorySwitchIsOff,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'disableObjectClassRelevanceAdvisorySwitch()' is not implemented in the EODiSP HLA");

	}

	public void enableAttributeRelevanceAdvisorySwitch() throws AttributeRelevanceAdvisorySwitchIsOn,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'enableAttributeRelevanceAdvisorySwitch()' is not implemented in the EODiSP HLA");
	}

	public void disableAttributeRelevanceAdvisorySwitch() throws AttributeRelevanceAdvisorySwitchIsOff,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'disableAttributeRelevanceAdvisorySwitch()' is not implemented in the EODiSP HLA");

	}

	public void enableAttributeScopeAdvisorySwitch() throws AttributeScopeAdvisorySwitchIsOn,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'enableAttributeScopeAdvisorySwitch()' is not implemented in the EODiSP HLA");

	}

	public void disableAttributeScopeAdvisorySwitch() throws AttributeScopeAdvisorySwitchIsOff,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'disableAttributeScopeAdvisorySwitch()' is not implemented in the EODiSP HLA");

	}

	public void enableInteractionRelevanceAdvisorySwitch() throws InteractionRelevanceAdvisorySwitchIsOn,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'enableInteractionRelevanceAdvisorySwitch()' is not implemented in the EODiSP HLA");

	}

	public void disableInteractionRelevanceAdvisorySwitch() throws InteractionRelevanceAdvisorySwitchIsOff,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'disableInteractionRelevanceAdvisorySwitch()' is not implemented in the EODiSP HLA");

	}

	public DimensionHandleSet getDimensionHandleSet(RegionHandle region) throws InvalidRegion,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'getDimensionHandleSet()' is not implemented in the EODiSP HLA");
	}

	public RangeBounds getRangeBounds(RegionHandle region, DimensionHandle dimension) throws InvalidRegion,
			RegionDoesNotContainSpecifiedDimension, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
			RTIinternalError {
		throw new UnsupportedOperationException("The method 'getRangeBounds()' is not implemented in the EODiSP HLA");
	}

	public void setRangeBounds(RegionHandle region, DimensionHandle dimension, RangeBounds bounds)
			throws InvalidRegion, RegionNotCreatedByThisFederate, RegionDoesNotContainSpecifiedDimension,
			InvalidRangeBound, FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		throw new UnsupportedOperationException("The method 'setRangeBounds()' is not implemented in the EODiSP HLA");

	}

	public long normalizeFederateHandle(FederateHandle federateHandle_) throws InvalidFederateHandle,
			FederateNotExecutionMember, RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'normalizeFederateHandle()' is not implemented in the EODiSP HLA");
	}

	public long normalizeServiceGroup(ServiceGroup group) throws InvalidServiceGroup, FederateNotExecutionMember,
			RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'normalizeServiceGroup()' is not implemented in the EODiSP HLA");
	}

	public boolean evokeCallback(double seconds) throws FederateNotExecutionMember, RTIinternalError {
		throw new UnsupportedOperationException("The method 'evokeCallback()' is not implemented in the EODiSP HLA");
	}

	public boolean evokeMultipleCallbacks(double minimumTime, double maximumTime) throws FederateNotExecutionMember,
			RTIinternalError {
		throw new UnsupportedOperationException(
				"The method 'evokeMultipleCallbacks()' is not implemented in the EODiSP HLA");
	}

	public void enableCallbacks() throws FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
			RTIinternalError {
		logger.warn("The method 'enableCallbacks()' is not implemented in the EODiSP HLA");
	}

	public void disableCallbacks() throws FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
			RTIinternalError {
		throw new UnsupportedOperationException("The method 'disableCallbacks()' is not implemented in the EODiSP HLA");

	}

	/**
	 * {@inheritDoc}
	 */
	public AttributeHandleFactory getAttributeHandleFactory() {
		return attributeHandleFactory;
	}

	/**
	 * {@inheritDoc}
	 */
	public AttributeHandleSetFactory getAttributeHandleSetFactory() {
		return attributeHandleSetFactory;
	}

	/**
	 * {@inheritDoc}
	 */
	public AttributeHandleValueMapFactory getAttributeHandleValueMapFactory() {
		return attributeHandleValueMapFactory;
	}

	/**
	 * {@inheritDoc}
	 */
	public AttributeSetRegionSetPairListFactory getAttributeSetRegionSetPairListFactory() {
		return attributeSetRegionSetPairListFactory;
	}

	/**
	 * {@inheritDoc}
	 */
	public DimensionHandleFactory getDimensionHandleFactory() {
		return dimensionHandleFactory;
	}

	/**
	 * {@inheritDoc}
	 */
	public DimensionHandleSetFactory getDimensionHandleSetFactory() {
		return dimensionHandleSetFactory;
	}

	/**
	 * {@inheritDoc}
	 */
	public FederateHandleFactory getFederateHandleFactory() {
		return federateHandleFactory;
	}

	/**
	 * {@inheritDoc}
	 */
	public FederateHandleSetFactory getFederateHandleSetFactory() {
		return federateHandleSetFactory;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getHLAversion() {
		return "1516.1";
	}

	/**
	 * {@inheritDoc}
	 */
	public InteractionClassHandleFactory getInteractionClassHandleFactory() {
		return interactionClassHandleFactory;
	}

	/**
	 * {@inheritDoc}
	 */
	public ObjectClassHandleFactory getObjectClassHandleFactory() {
		return objectClassHandleFactory;
	}

	/**
	 * {@inheritDoc}
	 */
	public ObjectInstanceHandleFactory getObjectInstanceHandleFactory() {
		return objectInstanceHandleFactory;
	}

	/**
	 * {@inheritDoc}
	 */
	public ParameterHandleFactory getParameterHandleFactory() {
		return parameterHandleFactory;
	}

	/**
	 * {@inheritDoc}
	 */
	public ParameterHandleValueMapFactory getParameterHandleValueMapFactory() {
		return parameterHandleValueMapFactory;
	}

	/**
	 * {@inheritDoc}
	 */
	public RegionHandleSetFactory getRegionHandleSetFactory() {
		return regionHandleSetFactory;
	}

	public synchronized FederationExecutionRemote getFederationExecutionRemote() throws FederateNotExecutionMember {
		if (federationExecutionRemote == null) {
			throw new FederateNotExecutionMember("This RTI Ambassador is not joined to a federation execution.");
		}
		return federationExecutionRemote;
	}

	public synchronized String getFederationExecutionName() throws FederateNotExecutionMember {
		if (federationExecutionRemote == null) {
			throw new FederateNotExecutionMember("This RTI Ambassador is not joined to a federation execution.");
		}
		return federationExecutionName;
	}

	public synchronized FederateHandle getFederateHandle() throws FederateNotExecutionMember {
		if (federationExecutionRemote == null) {
			throw new FederateNotExecutionMember("This RTI Ambassador is not joined to a federation execution.");
		}
		return federateHandle;
	}

	private class CommunicationException extends RTIinternalError {
		private static final long serialVersionUID = 1L;

		public CommunicationException(RemoteException remoteException) {
			super(String.format("Error during communication with CRC '%s' ", crcRemote), remoteException);
		}
	}
}
