/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.data;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see org.eodisp.hla.crc.data.DataFactory
 * @model kind="package"
 * @generated
 */
public interface DataPackage extends EPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "data";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	DataPackage eINSTANCE = org.eodisp.hla.crc.data.impl.DataPackageImpl.init();

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.data.impl.FederateImpl <em>Federate</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.data.impl.FederateImpl
	 * @see org.eodisp.hla.crc.data.impl.DataPackageImpl#getFederate()
	 * @generated
	 */
	int FEDERATE = 0;

	/**
	 * The feature id for the '<em><b>Registered Object Instances</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEDERATE__REGISTERED_OBJECT_INSTANCES = 0;

	/**
	 * The feature id for the '<em><b>Subscribed Attributes</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEDERATE__SUBSCRIBED_ATTRIBUTES = 1;

	/**
	 * The feature id for the '<em><b>Subscribed Interactions</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEDERATE__SUBSCRIBED_INTERACTIONS = 2;

	/**
	 * The feature id for the '<em><b>Published Attributes</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEDERATE__PUBLISHED_ATTRIBUTES = 3;

	/**
	 * The feature id for the '<em><b>Published Interactions</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEDERATE__PUBLISHED_INTERACTIONS = 4;

	/**
	 * The feature id for the '<em><b>Lrc Handle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEDERATE__LRC_HANDLE = 5;

	/**
	 * The feature id for the '<em><b>Handle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEDERATE__HANDLE = 6;

	/**
	 * The feature id for the '<em><b>Federation Execution</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEDERATE__FEDERATION_EXECUTION = 7;

	/**
	 * The feature id for the '<em><b>Published Object Classes</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEDERATE__PUBLISHED_OBJECT_CLASSES = 8;

	/**
	 * The feature id for the '<em><b>Subscribed Object Classes</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEDERATE__SUBSCRIBED_OBJECT_CLASSES = 9;

	/**
	 * The number of structural features of the '<em>Federate</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEDERATE_FEATURE_COUNT = 10;

	/**
	 * The meta object id for the '{@link org.eodisp.hla.crc.data.impl.ObjectInstanceImpl <em>Object Instance</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.data.impl.ObjectInstanceImpl
	 * @see org.eodisp.hla.crc.data.impl.DataPackageImpl#getObjectInstance()
	 * @generated
	 */
	int OBJECT_INSTANCE = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_INSTANCE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Object Class</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_INSTANCE__OBJECT_CLASS = 1;

	/**
	 * The feature id for the '<em><b>Registering Federate</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_INSTANCE__REGISTERING_FEDERATE = 2;

	/**
	 * The feature id for the '<em><b>Handle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_INSTANCE__HANDLE = 3;

	/**
	 * The number of structural features of the '<em>Object Instance</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_INSTANCE_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '<em>EFederate Handle</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see hla.rti1516.FederateHandle
	 * @see org.eodisp.hla.crc.data.impl.DataPackageImpl#getEFederateHandle()
	 * @generated
	 */
	int EFEDERATE_HANDLE = 2;

	/**
	 * The meta object id for the '<em>EFederation Execution</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eodisp.hla.crc.FederationExecution
	 * @see org.eodisp.hla.crc.data.impl.DataPackageImpl#getEFederationExecution()
	 * @generated
	 */
	int EFEDERATION_EXECUTION = 3;

	/**
	 * The meta object id for the '<em>EObject Instance Handle</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see hla.rti1516.ObjectInstanceHandle
	 * @see org.eodisp.hla.crc.data.impl.DataPackageImpl#getEObjectInstanceHandle()
	 * @generated
	 */
	int EOBJECT_INSTANCE_HANDLE = 4;

	/**
	 * The meta object id for the '<em>ELrc Handle</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eodisp.hla.common.lrc.LrcHandle
	 * @see org.eodisp.hla.crc.data.impl.DataPackageImpl#getELrcHandle()
	 * @generated
	 */
	int ELRC_HANDLE = 5;

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.data.Federate <em>Federate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Federate</em>'.
	 * @see org.eodisp.hla.crc.data.Federate
	 * @generated
	 */
	EClass getFederate();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eodisp.hla.crc.data.Federate#getRegisteredObjectInstances <em>Registered Object Instances</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Registered Object Instances</em>'.
	 * @see org.eodisp.hla.crc.data.Federate#getRegisteredObjectInstances()
	 * @see #getFederate()
	 * @generated
	 */
	EReference getFederate_RegisteredObjectInstances();

	/**
	 * Returns the meta object for the reference list '{@link org.eodisp.hla.crc.data.Federate#getSubscribedAttributes <em>Subscribed Attributes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Subscribed Attributes</em>'.
	 * @see org.eodisp.hla.crc.data.Federate#getSubscribedAttributes()
	 * @see #getFederate()
	 * @generated
	 */
	EReference getFederate_SubscribedAttributes();

	/**
	 * Returns the meta object for the reference list '{@link org.eodisp.hla.crc.data.Federate#getSubscribedInteractions <em>Subscribed Interactions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Subscribed Interactions</em>'.
	 * @see org.eodisp.hla.crc.data.Federate#getSubscribedInteractions()
	 * @see #getFederate()
	 * @generated
	 */
	EReference getFederate_SubscribedInteractions();

	/**
	 * Returns the meta object for the reference list '{@link org.eodisp.hla.crc.data.Federate#getPublishedAttributes <em>Published Attributes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Published Attributes</em>'.
	 * @see org.eodisp.hla.crc.data.Federate#getPublishedAttributes()
	 * @see #getFederate()
	 * @generated
	 */
	EReference getFederate_PublishedAttributes();

	/**
	 * Returns the meta object for the reference list '{@link org.eodisp.hla.crc.data.Federate#getPublishedInteractions <em>Published Interactions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Published Interactions</em>'.
	 * @see org.eodisp.hla.crc.data.Federate#getPublishedInteractions()
	 * @see #getFederate()
	 * @generated
	 */
	EReference getFederate_PublishedInteractions();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.data.Federate#getLrcHandle <em>Lrc Handle</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Lrc Handle</em>'.
	 * @see org.eodisp.hla.crc.data.Federate#getLrcHandle()
	 * @see #getFederate()
	 * @generated
	 */
	EAttribute getFederate_LrcHandle();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.data.Federate#getHandle <em>Handle</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Handle</em>'.
	 * @see org.eodisp.hla.crc.data.Federate#getHandle()
	 * @see #getFederate()
	 * @generated
	 */
	EAttribute getFederate_Handle();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.data.Federate#getFederationExecution <em>Federation Execution</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Federation Execution</em>'.
	 * @see org.eodisp.hla.crc.data.Federate#getFederationExecution()
	 * @see #getFederate()
	 * @generated
	 */
	EAttribute getFederate_FederationExecution();

	/**
	 * Returns the meta object for the reference list '{@link org.eodisp.hla.crc.data.Federate#getPublishedObjectClasses <em>Published Object Classes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Published Object Classes</em>'.
	 * @see org.eodisp.hla.crc.data.Federate#getPublishedObjectClasses()
	 * @see #getFederate()
	 * @generated
	 */
	EReference getFederate_PublishedObjectClasses();

	/**
	 * Returns the meta object for the reference list '{@link org.eodisp.hla.crc.data.Federate#getSubscribedObjectClasses <em>Subscribed Object Classes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Subscribed Object Classes</em>'.
	 * @see org.eodisp.hla.crc.data.Federate#getSubscribedObjectClasses()
	 * @see #getFederate()
	 * @generated
	 */
	EReference getFederate_SubscribedObjectClasses();

	/**
	 * Returns the meta object for class '{@link org.eodisp.hla.crc.data.ObjectInstance <em>Object Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Object Instance</em>'.
	 * @see org.eodisp.hla.crc.data.ObjectInstance
	 * @generated
	 */
	EClass getObjectInstance();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.data.ObjectInstance#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eodisp.hla.crc.data.ObjectInstance#getName()
	 * @see #getObjectInstance()
	 * @generated
	 */
	EAttribute getObjectInstance_Name();

	/**
	 * Returns the meta object for the reference '{@link org.eodisp.hla.crc.data.ObjectInstance#getObjectClass <em>Object Class</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Object Class</em>'.
	 * @see org.eodisp.hla.crc.data.ObjectInstance#getObjectClass()
	 * @see #getObjectInstance()
	 * @generated
	 */
	EReference getObjectInstance_ObjectClass();

	/**
	 * Returns the meta object for the container reference '{@link org.eodisp.hla.crc.data.ObjectInstance#getRegisteringFederate <em>Registering Federate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the container reference '<em>Registering Federate</em>'.
	 * @see org.eodisp.hla.crc.data.ObjectInstance#getRegisteringFederate()
	 * @see #getObjectInstance()
	 * @generated
	 */
	EReference getObjectInstance_RegisteringFederate();

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.hla.crc.data.ObjectInstance#getHandle <em>Handle</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Handle</em>'.
	 * @see org.eodisp.hla.crc.data.ObjectInstance#getHandle()
	 * @see #getObjectInstance()
	 * @generated
	 */
	EAttribute getObjectInstance_Handle();

	/**
	 * Returns the meta object for data type '{@link hla.rti1516.FederateHandle <em>EFederate Handle</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>EFederate Handle</em>'.
	 * @see hla.rti1516.FederateHandle
	 * @model instanceClass="hla.rti1516.FederateHandle"
	 * @generated
	 */
	EDataType getEFederateHandle();

	/**
	 * Returns the meta object for data type '{@link org.eodisp.hla.crc.FederationExecution <em>EFederation Execution</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>EFederation Execution</em>'.
	 * @see org.eodisp.hla.crc.FederationExecution
	 * @model instanceClass="org.eodisp.hla.crc.FederationExecution" serializable="false"
	 * @generated
	 */
	EDataType getEFederationExecution();

	/**
	 * Returns the meta object for data type '{@link hla.rti1516.ObjectInstanceHandle <em>EObject Instance Handle</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>EObject Instance Handle</em>'.
	 * @see hla.rti1516.ObjectInstanceHandle
	 * @model instanceClass="hla.rti1516.ObjectInstanceHandle"
	 * @generated
	 */
	EDataType getEObjectInstanceHandle();

	/**
	 * Returns the meta object for data type '{@link org.eodisp.hla.common.lrc.LrcHandle <em>ELrc Handle</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>ELrc Handle</em>'.
	 * @see org.eodisp.hla.common.lrc.LrcHandle
	 * @model instanceClass="org.eodisp.hla.common.lrc.LrcHandle"
	 * @generated
	 */
	EDataType getELrcHandle();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	DataFactory getDataFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.data.impl.FederateImpl <em>Federate</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.data.impl.FederateImpl
		 * @see org.eodisp.hla.crc.data.impl.DataPackageImpl#getFederate()
		 * @generated
		 */
		EClass FEDERATE = eINSTANCE.getFederate();

		/**
		 * The meta object literal for the '<em><b>Registered Object Instances</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FEDERATE__REGISTERED_OBJECT_INSTANCES = eINSTANCE.getFederate_RegisteredObjectInstances();

		/**
		 * The meta object literal for the '<em><b>Subscribed Attributes</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FEDERATE__SUBSCRIBED_ATTRIBUTES = eINSTANCE.getFederate_SubscribedAttributes();

		/**
		 * The meta object literal for the '<em><b>Subscribed Interactions</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FEDERATE__SUBSCRIBED_INTERACTIONS = eINSTANCE.getFederate_SubscribedInteractions();

		/**
		 * The meta object literal for the '<em><b>Published Attributes</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FEDERATE__PUBLISHED_ATTRIBUTES = eINSTANCE.getFederate_PublishedAttributes();

		/**
		 * The meta object literal for the '<em><b>Published Interactions</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FEDERATE__PUBLISHED_INTERACTIONS = eINSTANCE.getFederate_PublishedInteractions();

		/**
		 * The meta object literal for the '<em><b>Lrc Handle</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FEDERATE__LRC_HANDLE = eINSTANCE.getFederate_LrcHandle();

		/**
		 * The meta object literal for the '<em><b>Handle</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FEDERATE__HANDLE = eINSTANCE.getFederate_Handle();

		/**
		 * The meta object literal for the '<em><b>Federation Execution</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FEDERATE__FEDERATION_EXECUTION = eINSTANCE.getFederate_FederationExecution();

		/**
		 * The meta object literal for the '<em><b>Published Object Classes</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FEDERATE__PUBLISHED_OBJECT_CLASSES = eINSTANCE.getFederate_PublishedObjectClasses();

		/**
		 * The meta object literal for the '<em><b>Subscribed Object Classes</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FEDERATE__SUBSCRIBED_OBJECT_CLASSES = eINSTANCE.getFederate_SubscribedObjectClasses();

		/**
		 * The meta object literal for the '{@link org.eodisp.hla.crc.data.impl.ObjectInstanceImpl <em>Object Instance</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.data.impl.ObjectInstanceImpl
		 * @see org.eodisp.hla.crc.data.impl.DataPackageImpl#getObjectInstance()
		 * @generated
		 */
		EClass OBJECT_INSTANCE = eINSTANCE.getObjectInstance();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_INSTANCE__NAME = eINSTANCE.getObjectInstance_Name();

		/**
		 * The meta object literal for the '<em><b>Object Class</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OBJECT_INSTANCE__OBJECT_CLASS = eINSTANCE.getObjectInstance_ObjectClass();

		/**
		 * The meta object literal for the '<em><b>Registering Federate</b></em>' container reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OBJECT_INSTANCE__REGISTERING_FEDERATE = eINSTANCE.getObjectInstance_RegisteringFederate();

		/**
		 * The meta object literal for the '<em><b>Handle</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_INSTANCE__HANDLE = eINSTANCE.getObjectInstance_Handle();

		/**
		 * The meta object literal for the '<em>EFederate Handle</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see hla.rti1516.FederateHandle
		 * @see org.eodisp.hla.crc.data.impl.DataPackageImpl#getEFederateHandle()
		 * @generated
		 */
		EDataType EFEDERATE_HANDLE = eINSTANCE.getEFederateHandle();

		/**
		 * The meta object literal for the '<em>EFederation Execution</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.crc.FederationExecution
		 * @see org.eodisp.hla.crc.data.impl.DataPackageImpl#getEFederationExecution()
		 * @generated
		 */
		EDataType EFEDERATION_EXECUTION = eINSTANCE.getEFederationExecution();

		/**
		 * The meta object literal for the '<em>EObject Instance Handle</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see hla.rti1516.ObjectInstanceHandle
		 * @see org.eodisp.hla.crc.data.impl.DataPackageImpl#getEObjectInstanceHandle()
		 * @generated
		 */
		EDataType EOBJECT_INSTANCE_HANDLE = eINSTANCE.getEObjectInstanceHandle();

		/**
		 * The meta object literal for the '<em>ELrc Handle</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.hla.common.lrc.LrcHandle
		 * @see org.eodisp.hla.crc.data.impl.DataPackageImpl#getELrcHandle()
		 * @generated
		 */
		EDataType ELRC_HANDLE = eINSTANCE.getELrcHandle();

	}

} //DataPackage
