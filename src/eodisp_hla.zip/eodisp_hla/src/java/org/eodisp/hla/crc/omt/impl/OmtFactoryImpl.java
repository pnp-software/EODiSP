/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import org.eclipse.emf.ecore.xml.type.XMLTypeFactory;
import org.eclipse.emf.ecore.xml.type.XMLTypePackage;

import org.eodisp.hla.crc.omt.*;

/**
 * <!-- begin-user-doc --> An implementation of the model <b>Factory</b>. <!--
 * end-user-doc -->
 * @generated
 */
public class OmtFactoryImpl extends EFactoryImpl implements OmtFactory {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static OmtFactory init() {
		try {
			OmtFactory theOmtFactory = (OmtFactory) EPackage.Registry.INSTANCE
					.getEFactory("platform:/resource/eodisp_hla/src/xsd/HLA.xsd");
			if (theOmtFactory != null) {
				return theOmtFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new OmtFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * @generated
	 */
	public OmtFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case OmtPackage.ACQUISITION_REQUEST_TAG:
			return createAcquisitionRequestTag();
		case OmtPackage.ALTERNATIVE:
			return createAlternative();
		case OmtPackage.ARRAY_DATA:
			return createArrayData();
		case OmtPackage.ARRAY_DATA_TYPES:
			return createArrayDataTypes();
		case OmtPackage.ATTRIBUTE:
			return createAttribute();
		case OmtPackage.BASIC_DATA:
			return createBasicData();
		case OmtPackage.BASIC_DATA_REPRESENTATIONS:
			return createBasicDataRepresentations();
		case OmtPackage.DATA_TYPES:
			return createDataTypes();
		case OmtPackage.DELETE_REMOVE_TAG:
			return createDeleteRemoveTag();
		case OmtPackage.DIMENSION:
			return createDimension();
		case OmtPackage.DIMENSIONS:
			return createDimensions();
		case OmtPackage.DIVESTITURE_COMPLETION_TAG:
			return createDivestitureCompletionTag();
		case OmtPackage.DIVESTITURE_REQUEST_TAG:
			return createDivestitureRequestTag();
		case OmtPackage.DOCUMENT_ROOT:
			return createDocumentRoot();
		case OmtPackage.ENUMERATED_DATA:
			return createEnumeratedData();
		case OmtPackage.ENUMERATED_DATA_TYPES:
			return createEnumeratedDataTypes();
		case OmtPackage.ENUMERATOR:
			return createEnumerator();
		case OmtPackage.FIELD:
			return createField();
		case OmtPackage.FIXED_RECORD_DATA:
			return createFixedRecordData();
		case OmtPackage.FIXED_RECORD_DATA_TYPES:
			return createFixedRecordDataTypes();
		case OmtPackage.INTERACTION_CLASS:
			return createInteractionClass();
		case OmtPackage.INTERACTIONS:
			return createInteractions();
		case OmtPackage.LOOKAHEAD:
			return createLookahead();
		case OmtPackage.NOTE:
			return createNote();
		case OmtPackage.NOTES:
			return createNotes();
		case OmtPackage.OBJECT_CLASS:
			return createObjectClass();
		case OmtPackage.OBJECT_MODEL:
			return createObjectModel();
		case OmtPackage.OBJECTS:
			return createObjects();
		case OmtPackage.PARAMETER:
			return createParameter();
		case OmtPackage.REQUEST_UPDATE_TAG:
			return createRequestUpdateTag();
		case OmtPackage.SEND_RECEIVE_TAG:
			return createSendReceiveTag();
		case OmtPackage.SIMPLE_DATA:
			return createSimpleData();
		case OmtPackage.SIMPLE_DATA_TYPES:
			return createSimpleDataTypes();
		case OmtPackage.SWITCHES:
			return createSwitches();
		case OmtPackage.SYNCHRONIZATION:
			return createSynchronization();
		case OmtPackage.SYNCHRONIZATIONS:
			return createSynchronizations();
		case OmtPackage.TAGS:
			return createTags();
		case OmtPackage.TIME:
			return createTime();
		case OmtPackage.TIME_STAMP:
			return createTimeStamp();
		case OmtPackage.TRANSPORTATION:
			return createTransportation();
		case OmtPackage.TRANSPORTATIONS:
			return createTransportations();
		case OmtPackage.UPDATE_REFLECT_TAG:
			return createUpdateReflectTag();
		case OmtPackage.VARIANT_RECORD_DATA:
			return createVariantRecordData();
		case OmtPackage.VARIANT_RECORD_DATA_TYPES:
			return createVariantRecordDataTypes();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
		case OmtPackage.DTD_VERSION_ENUM:
			return createDTDVersionEnumFromString(eDataType, initialValue);
		case OmtPackage.ENDIAN_ENUM:
			return createEndianEnumFromString(eDataType, initialValue);
		case OmtPackage.OBJECT_MODEL_TYPE_ENUM:
			return createObjectModelTypeEnumFromString(eDataType, initialValue);
		case OmtPackage.ORDER_ENUM:
			return createOrderEnumFromString(eDataType, initialValue);
		case OmtPackage.OWNERSHIP_ENUM:
			return createOwnershipEnumFromString(eDataType, initialValue);
		case OmtPackage.SHARING_ENUM:
			return createSharingEnumFromString(eDataType, initialValue);
		case OmtPackage.STATE_ENUM:
			return createStateEnumFromString(eDataType, initialValue);
		case OmtPackage.SYNC_CAPABILITY_ENUM:
			return createSyncCapabilityEnumFromString(eDataType, initialValue);
		case OmtPackage.UPDATE_TYPE_ENUM:
			return createUpdateTypeEnumFromString(eDataType, initialValue);
		case OmtPackage.DTD_VERSION_ENUM_OBJECT:
			return createDTDVersionEnumObjectFromString(eDataType, initialValue);
		case OmtPackage.ENDIAN_ENUM_OBJECT:
			return createEndianEnumObjectFromString(eDataType, initialValue);
		case OmtPackage.OBJECT_MODEL_TYPE_ENUM_OBJECT:
			return createObjectModelTypeEnumObjectFromString(eDataType, initialValue);
		case OmtPackage.ORDER_ENUM_OBJECT:
			return createOrderEnumObjectFromString(eDataType, initialValue);
		case OmtPackage.OWNERSHIP_ENUM_OBJECT:
			return createOwnershipEnumObjectFromString(eDataType, initialValue);
		case OmtPackage.SHARING_ENUM_OBJECT:
			return createSharingEnumObjectFromString(eDataType, initialValue);
		case OmtPackage.STATE_ENUM_OBJECT:
			return createStateEnumObjectFromString(eDataType, initialValue);
		case OmtPackage.SYNC_CAPABILITY_ENUM_OBJECT:
			return createSyncCapabilityEnumObjectFromString(eDataType, initialValue);
		case OmtPackage.UPDATE_TYPE_ENUM_OBJECT:
			return createUpdateTypeEnumObjectFromString(eDataType, initialValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
		case OmtPackage.DTD_VERSION_ENUM:
			return convertDTDVersionEnumToString(eDataType, instanceValue);
		case OmtPackage.ENDIAN_ENUM:
			return convertEndianEnumToString(eDataType, instanceValue);
		case OmtPackage.OBJECT_MODEL_TYPE_ENUM:
			return convertObjectModelTypeEnumToString(eDataType, instanceValue);
		case OmtPackage.ORDER_ENUM:
			return convertOrderEnumToString(eDataType, instanceValue);
		case OmtPackage.OWNERSHIP_ENUM:
			return convertOwnershipEnumToString(eDataType, instanceValue);
		case OmtPackage.SHARING_ENUM:
			return convertSharingEnumToString(eDataType, instanceValue);
		case OmtPackage.STATE_ENUM:
			return convertStateEnumToString(eDataType, instanceValue);
		case OmtPackage.SYNC_CAPABILITY_ENUM:
			return convertSyncCapabilityEnumToString(eDataType, instanceValue);
		case OmtPackage.UPDATE_TYPE_ENUM:
			return convertUpdateTypeEnumToString(eDataType, instanceValue);
		case OmtPackage.DTD_VERSION_ENUM_OBJECT:
			return convertDTDVersionEnumObjectToString(eDataType, instanceValue);
		case OmtPackage.ENDIAN_ENUM_OBJECT:
			return convertEndianEnumObjectToString(eDataType, instanceValue);
		case OmtPackage.OBJECT_MODEL_TYPE_ENUM_OBJECT:
			return convertObjectModelTypeEnumObjectToString(eDataType, instanceValue);
		case OmtPackage.ORDER_ENUM_OBJECT:
			return convertOrderEnumObjectToString(eDataType, instanceValue);
		case OmtPackage.OWNERSHIP_ENUM_OBJECT:
			return convertOwnershipEnumObjectToString(eDataType, instanceValue);
		case OmtPackage.SHARING_ENUM_OBJECT:
			return convertSharingEnumObjectToString(eDataType, instanceValue);
		case OmtPackage.STATE_ENUM_OBJECT:
			return convertStateEnumObjectToString(eDataType, instanceValue);
		case OmtPackage.SYNC_CAPABILITY_ENUM_OBJECT:
			return convertSyncCapabilityEnumObjectToString(eDataType, instanceValue);
		case OmtPackage.UPDATE_TYPE_ENUM_OBJECT:
			return convertUpdateTypeEnumObjectToString(eDataType, instanceValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public AcquisitionRequestTag createAcquisitionRequestTag() {
		AcquisitionRequestTagImpl acquisitionRequestTag = new AcquisitionRequestTagImpl();
		return acquisitionRequestTag;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Alternative createAlternative() {
		AlternativeImpl alternative = new AlternativeImpl();
		return alternative;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public ArrayData createArrayData() {
		ArrayDataImpl arrayData = new ArrayDataImpl();
		return arrayData;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public ArrayDataTypes createArrayDataTypes() {
		ArrayDataTypesImpl arrayDataTypes = new ArrayDataTypesImpl();
		return arrayDataTypes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Attribute createAttribute() {
		AttributeImpl attribute = new AttributeImpl();
		return attribute;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public BasicData createBasicData() {
		BasicDataImpl basicData = new BasicDataImpl();
		return basicData;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public BasicDataRepresentations createBasicDataRepresentations() {
		BasicDataRepresentationsImpl basicDataRepresentations = new BasicDataRepresentationsImpl();
		return basicDataRepresentations;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public DataTypes createDataTypes() {
		DataTypesImpl dataTypes = new DataTypesImpl();
		return dataTypes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public DeleteRemoveTag createDeleteRemoveTag() {
		DeleteRemoveTagImpl deleteRemoveTag = new DeleteRemoveTagImpl();
		return deleteRemoveTag;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Dimension createDimension() {
		DimensionImpl dimension = new DimensionImpl();
		return dimension;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Dimensions createDimensions() {
		DimensionsImpl dimensions = new DimensionsImpl();
		return dimensions;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public DivestitureCompletionTag createDivestitureCompletionTag() {
		DivestitureCompletionTagImpl divestitureCompletionTag = new DivestitureCompletionTagImpl();
		return divestitureCompletionTag;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public DivestitureRequestTag createDivestitureRequestTag() {
		DivestitureRequestTagImpl divestitureRequestTag = new DivestitureRequestTagImpl();
		return divestitureRequestTag;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public DocumentRoot createDocumentRoot() {
		DocumentRootImpl documentRoot = new DocumentRootImpl();
		return documentRoot;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EnumeratedData createEnumeratedData() {
		EnumeratedDataImpl enumeratedData = new EnumeratedDataImpl();
		return enumeratedData;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EnumeratedDataTypes createEnumeratedDataTypes() {
		EnumeratedDataTypesImpl enumeratedDataTypes = new EnumeratedDataTypesImpl();
		return enumeratedDataTypes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Enumerator createEnumerator() {
		EnumeratorImpl enumerator = new EnumeratorImpl();
		return enumerator;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Field createField() {
		FieldImpl field = new FieldImpl();
		return field;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public FixedRecordData createFixedRecordData() {
		FixedRecordDataImpl fixedRecordData = new FixedRecordDataImpl();
		return fixedRecordData;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public FixedRecordDataTypes createFixedRecordDataTypes() {
		FixedRecordDataTypesImpl fixedRecordDataTypes = new FixedRecordDataTypesImpl();
		return fixedRecordDataTypes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public InteractionClass createInteractionClass() {
		InteractionClassImpl interactionClass = new InteractionClassImpl();
		return interactionClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Interactions createInteractions() {
		InteractionsImpl interactions = new InteractionsImpl();
		return interactions;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Lookahead createLookahead() {
		LookaheadImpl lookahead = new LookaheadImpl();
		return lookahead;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Note createNote() {
		NoteImpl note = new NoteImpl();
		return note;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Notes createNotes() {
		NotesImpl notes = new NotesImpl();
		return notes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public ObjectClass createObjectClass() {
		ObjectClassImpl objectClass = new ObjectClassImpl();
		return objectClass;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public ObjectModel createObjectModel() {
		ObjectModelImpl objectModel = new ObjectModelImpl();
		return objectModel;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Objects createObjects() {
		ObjectsImpl objects = new ObjectsImpl();
		return objects;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Parameter createParameter() {
		ParameterImpl parameter = new ParameterImpl();
		return parameter;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public RequestUpdateTag createRequestUpdateTag() {
		RequestUpdateTagImpl requestUpdateTag = new RequestUpdateTagImpl();
		return requestUpdateTag;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public SendReceiveTag createSendReceiveTag() {
		SendReceiveTagImpl sendReceiveTag = new SendReceiveTagImpl();
		return sendReceiveTag;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public SimpleData createSimpleData() {
		SimpleDataImpl simpleData = new SimpleDataImpl();
		return simpleData;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public SimpleDataTypes createSimpleDataTypes() {
		SimpleDataTypesImpl simpleDataTypes = new SimpleDataTypesImpl();
		return simpleDataTypes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Switches createSwitches() {
		SwitchesImpl switches = new SwitchesImpl();
		return switches;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Synchronization createSynchronization() {
		SynchronizationImpl synchronization = new SynchronizationImpl();
		return synchronization;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Synchronizations createSynchronizations() {
		SynchronizationsImpl synchronizations = new SynchronizationsImpl();
		return synchronizations;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Tags createTags() {
		TagsImpl tags = new TagsImpl();
		return tags;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Time createTime() {
		TimeImpl time = new TimeImpl();
		return time;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public TimeStamp createTimeStamp() {
		TimeStampImpl timeStamp = new TimeStampImpl();
		return timeStamp;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Transportation createTransportation() {
		TransportationImpl transportation = new TransportationImpl();
		return transportation;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Transportations createTransportations() {
		TransportationsImpl transportations = new TransportationsImpl();
		return transportations;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public UpdateReflectTag createUpdateReflectTag() {
		UpdateReflectTagImpl updateReflectTag = new UpdateReflectTagImpl();
		return updateReflectTag;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public VariantRecordData createVariantRecordData() {
		VariantRecordDataImpl variantRecordData = new VariantRecordDataImpl();
		return variantRecordData;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public VariantRecordDataTypes createVariantRecordDataTypes() {
		VariantRecordDataTypesImpl variantRecordDataTypes = new VariantRecordDataTypesImpl();
		return variantRecordDataTypes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public DTDVersionEnum createDTDVersionEnumFromString(EDataType eDataType, String initialValue) {
		DTDVersionEnum result = DTDVersionEnum.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '"
					+ eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String convertDTDVersionEnumToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EndianEnum createEndianEnumFromString(EDataType eDataType, String initialValue) {
		EndianEnum result = EndianEnum.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '"
					+ eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertEndianEnumToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ObjectModelTypeEnum createObjectModelTypeEnumFromString(EDataType eDataType, String initialValue) {
		ObjectModelTypeEnum result = ObjectModelTypeEnum.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '"
					+ eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertObjectModelTypeEnumToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OrderEnum createOrderEnumFromString(EDataType eDataType, String initialValue) {
		OrderEnum result = OrderEnum.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '"
					+ eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertOrderEnumToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OwnershipEnum createOwnershipEnumFromString(EDataType eDataType, String initialValue) {
		OwnershipEnum result = OwnershipEnum.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '"
					+ eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertOwnershipEnumToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SharingEnum createSharingEnumFromString(EDataType eDataType, String initialValue) {
		SharingEnum result = SharingEnum.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '"
					+ eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertSharingEnumToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StateEnum createStateEnumFromString(EDataType eDataType, String initialValue) {
		StateEnum result = StateEnum.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '"
					+ eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertStateEnumToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SyncCapabilityEnum createSyncCapabilityEnumFromString(EDataType eDataType, String initialValue) {
		SyncCapabilityEnum result = SyncCapabilityEnum.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '"
					+ eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertSyncCapabilityEnumToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UpdateTypeEnum createUpdateTypeEnumFromString(EDataType eDataType, String initialValue) {
		UpdateTypeEnum result = UpdateTypeEnum.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '"
					+ eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertUpdateTypeEnumToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DTDVersionEnum createDTDVersionEnumObjectFromString(EDataType eDataType, String initialValue) {
		return (DTDVersionEnum) createDTDVersionEnumFromString(OmtPackage.Literals.DTD_VERSION_ENUM, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertDTDVersionEnumObjectToString(EDataType eDataType, Object instanceValue) {
		return convertDTDVersionEnumToString(OmtPackage.Literals.DTD_VERSION_ENUM, instanceValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EndianEnum createEndianEnumObjectFromString(EDataType eDataType, String initialValue) {
		return (EndianEnum) createEndianEnumFromString(OmtPackage.Literals.ENDIAN_ENUM, initialValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String convertEndianEnumObjectToString(EDataType eDataType, Object instanceValue) {
		return convertEndianEnumToString(OmtPackage.Literals.ENDIAN_ENUM, instanceValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public ObjectModelTypeEnum createObjectModelTypeEnumObjectFromString(EDataType eDataType, String initialValue) {
		return (ObjectModelTypeEnum) createObjectModelTypeEnumFromString(
				OmtPackage.Literals.OBJECT_MODEL_TYPE_ENUM,
				initialValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String convertObjectModelTypeEnumObjectToString(EDataType eDataType, Object instanceValue) {
		return convertObjectModelTypeEnumToString(OmtPackage.Literals.OBJECT_MODEL_TYPE_ENUM, instanceValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public OrderEnum createOrderEnumObjectFromString(EDataType eDataType, String initialValue) {
		return (OrderEnum) createOrderEnumFromString(OmtPackage.Literals.ORDER_ENUM, initialValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String convertOrderEnumObjectToString(EDataType eDataType, Object instanceValue) {
		return convertOrderEnumToString(OmtPackage.Literals.ORDER_ENUM, instanceValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public OwnershipEnum createOwnershipEnumObjectFromString(EDataType eDataType, String initialValue) {
		return (OwnershipEnum) createOwnershipEnumFromString(OmtPackage.Literals.OWNERSHIP_ENUM, initialValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String convertOwnershipEnumObjectToString(EDataType eDataType, Object instanceValue) {
		return convertOwnershipEnumToString(OmtPackage.Literals.OWNERSHIP_ENUM, instanceValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public SharingEnum createSharingEnumObjectFromString(EDataType eDataType, String initialValue) {
		return (SharingEnum) createSharingEnumFromString(OmtPackage.Literals.SHARING_ENUM, initialValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String convertSharingEnumObjectToString(EDataType eDataType, Object instanceValue) {
		return convertSharingEnumToString(OmtPackage.Literals.SHARING_ENUM, instanceValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public StateEnum createStateEnumObjectFromString(EDataType eDataType, String initialValue) {
		return (StateEnum) createStateEnumFromString(OmtPackage.Literals.STATE_ENUM, initialValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String convertStateEnumObjectToString(EDataType eDataType, Object instanceValue) {
		return convertStateEnumToString(OmtPackage.Literals.STATE_ENUM, instanceValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public SyncCapabilityEnum createSyncCapabilityEnumObjectFromString(EDataType eDataType, String initialValue) {
		return (SyncCapabilityEnum) createSyncCapabilityEnumFromString(
				OmtPackage.Literals.SYNC_CAPABILITY_ENUM,
				initialValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String convertSyncCapabilityEnumObjectToString(EDataType eDataType, Object instanceValue) {
		return convertSyncCapabilityEnumToString(OmtPackage.Literals.SYNC_CAPABILITY_ENUM, instanceValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public UpdateTypeEnum createUpdateTypeEnumObjectFromString(EDataType eDataType, String initialValue) {
		return (UpdateTypeEnum) createUpdateTypeEnumFromString(OmtPackage.Literals.UPDATE_TYPE_ENUM, initialValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String convertUpdateTypeEnumObjectToString(EDataType eDataType, Object instanceValue) {
		return convertUpdateTypeEnumToString(OmtPackage.Literals.UPDATE_TYPE_ENUM, instanceValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public OmtPackage getOmtPackage() {
		return (OmtPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	public static OmtPackage getPackage() {
		return OmtPackage.eINSTANCE;
	}

} // OmtFactoryImpl
