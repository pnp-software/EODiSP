package org.eodisp.hla.common.handles;

import hla.rti1516.*;

public class ObjectClassHandleFactoryImpl implements ObjectClassHandleFactory {

	public ObjectClassHandle decode(byte[] buffer, int offset)
			throws CouldNotDecode, FederateNotExecutionMember {
//		 TODO
		return null;
//		return new ObjectClassHandleImpl(buffer, offset);
	}

}
