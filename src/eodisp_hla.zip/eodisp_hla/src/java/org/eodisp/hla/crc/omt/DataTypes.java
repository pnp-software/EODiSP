/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Data Types</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.DataTypes#getBasicDataRepresentations <em>Basic Data Representations</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.DataTypes#getSimpleDataTypes <em>Simple Data Types</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.DataTypes#getEnumeratedDataTypes <em>Enumerated Data Types</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.DataTypes#getArrayDataTypes <em>Array Data Types</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.DataTypes#getFixedRecordDataTypes <em>Fixed Record Data Types</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.DataTypes#getVariantRecordDataTypes <em>Variant Record Data Types</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eodisp.hla.crc.omt.OmtPackage#getDataTypes()
 * @model extendedMetaData="name='DataTypes' kind='elementOnly'"
 * @generated
 */
public interface DataTypes extends EObject {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * Returns the value of the '<em><b>Basic Data Representations</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Basic Data Representations</em>'
	 * containment reference isn't clear, there really should be more of a
	 * description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Basic Data Representations</em>' containment reference.
	 * @see #setBasicDataRepresentations(BasicDataRepresentations)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getDataTypes_BasicDataRepresentations()
	 * @model containment="true" required="true"
	 *        extendedMetaData="kind='element' name='basicDataRepresentations' namespace='##targetNamespace'"
	 * @generated
	 */
	BasicDataRepresentations getBasicDataRepresentations();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.DataTypes#getBasicDataRepresentations <em>Basic Data Representations</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Basic Data Representations</em>' containment reference.
	 * @see #getBasicDataRepresentations()
	 * @generated
	 */
	void setBasicDataRepresentations(BasicDataRepresentations value);

	/**
	 * Returns the value of the '<em><b>Simple Data Types</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Simple Data Types</em>' containment
	 * reference isn't clear, there really should be more of a description
	 * here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Simple Data Types</em>' containment reference.
	 * @see #setSimpleDataTypes(SimpleDataTypes)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getDataTypes_SimpleDataTypes()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='simpleDataTypes' namespace='##targetNamespace'"
	 * @generated
	 */
	SimpleDataTypes getSimpleDataTypes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.DataTypes#getSimpleDataTypes <em>Simple Data Types</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Simple Data Types</em>' containment reference.
	 * @see #getSimpleDataTypes()
	 * @generated
	 */
	void setSimpleDataTypes(SimpleDataTypes value);

	/**
	 * Returns the value of the '<em><b>Enumerated Data Types</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Enumerated Data Types</em>' containment
	 * reference isn't clear, there really should be more of a description
	 * here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Enumerated Data Types</em>' containment reference.
	 * @see #setEnumeratedDataTypes(EnumeratedDataTypes)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getDataTypes_EnumeratedDataTypes()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='enumeratedDataTypes' namespace='##targetNamespace'"
	 * @generated
	 */
	EnumeratedDataTypes getEnumeratedDataTypes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.DataTypes#getEnumeratedDataTypes <em>Enumerated Data Types</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Enumerated Data Types</em>' containment reference.
	 * @see #getEnumeratedDataTypes()
	 * @generated
	 */
	void setEnumeratedDataTypes(EnumeratedDataTypes value);

	/**
	 * Returns the value of the '<em><b>Array Data Types</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Array Data Types</em>' containment
	 * reference isn't clear, there really should be more of a description
	 * here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Array Data Types</em>' containment reference.
	 * @see #setArrayDataTypes(ArrayDataTypes)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getDataTypes_ArrayDataTypes()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='arrayDataTypes' namespace='##targetNamespace'"
	 * @generated
	 */
	ArrayDataTypes getArrayDataTypes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.DataTypes#getArrayDataTypes <em>Array Data Types</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Array Data Types</em>' containment reference.
	 * @see #getArrayDataTypes()
	 * @generated
	 */
	void setArrayDataTypes(ArrayDataTypes value);

	/**
	 * Returns the value of the '<em><b>Fixed Record Data Types</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Fixed Record Data Types</em>' containment
	 * reference isn't clear, there really should be more of a description
	 * here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Fixed Record Data Types</em>' containment reference.
	 * @see #setFixedRecordDataTypes(FixedRecordDataTypes)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getDataTypes_FixedRecordDataTypes()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='fixedRecordDataTypes' namespace='##targetNamespace'"
	 * @generated
	 */
	FixedRecordDataTypes getFixedRecordDataTypes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.DataTypes#getFixedRecordDataTypes <em>Fixed Record Data Types</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Fixed Record Data Types</em>' containment reference.
	 * @see #getFixedRecordDataTypes()
	 * @generated
	 */
	void setFixedRecordDataTypes(FixedRecordDataTypes value);

	/**
	 * Returns the value of the '<em><b>Variant Record Data Types</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Variant Record Data Types</em>'
	 * containment reference isn't clear, there really should be more of a
	 * description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Variant Record Data Types</em>' containment reference.
	 * @see #setVariantRecordDataTypes(VariantRecordDataTypes)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getDataTypes_VariantRecordDataTypes()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='variantRecordDataTypes' namespace='##targetNamespace'"
	 * @generated
	 */
	VariantRecordDataTypes getVariantRecordDataTypes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.DataTypes#getVariantRecordDataTypes <em>Variant Record Data Types</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Variant Record Data Types</em>' containment reference.
	 * @see #getVariantRecordDataTypes()
	 * @generated
	 */
	void setVariantRecordDataTypes(VariantRecordDataTypes value);

} // DataTypes
