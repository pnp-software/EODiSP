/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.data.impl;

import hla.rti1516.FederateHandle;

import hla.rti1516.ObjectInstanceHandle;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import org.eodisp.hla.common.lrc.LrcHandle;

import org.eodisp.hla.common.lrc.LrcRemote;

import org.eodisp.hla.crc.FederationExecution;
import org.eodisp.hla.crc.data.*;
import org.eodisp.hla.crc.omt.ObjectClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class DataFactoryImpl extends EFactoryImpl implements DataFactory {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	private static final String DEFAULT_OBJECT_INSTANCE_PREFIX = "HLA_";

	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static DataFactory init() {
		try {
			DataFactory theDataFactory = (DataFactory) EPackage.Registry.INSTANCE.getEFactory("");
			if (theDataFactory != null) {
				return theDataFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new DataFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DataFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case DataPackage.FEDERATE:
			return createFederate();
		case DataPackage.OBJECT_INSTANCE:
			return createObjectInstance();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
		case DataPackage.EFEDERATE_HANDLE:
			return createEFederateHandleFromString(eDataType, initialValue);
		case DataPackage.EOBJECT_INSTANCE_HANDLE:
			return createEObjectInstanceHandleFromString(eDataType, initialValue);
		case DataPackage.ELRC_HANDLE:
			return createELrcHandleFromString(eDataType, initialValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
		case DataPackage.EFEDERATE_HANDLE:
			return convertEFederateHandleToString(eDataType, instanceValue);
		case DataPackage.EOBJECT_INSTANCE_HANDLE:
			return convertEObjectInstanceHandleToString(eDataType, instanceValue);
		case DataPackage.ELRC_HANDLE:
			return convertELrcHandleToString(eDataType, instanceValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Federate createFederate() {
		FederateImpl federate = new FederateImpl();
		return federate;
	}

	/** 
	 * {@inheritDoc}
	 */
	public Federate createFederate(LrcHandle lrcHandle, FederateHandle federateHandle,
			FederationExecution federationExecution) {
		Federate federate = createFederate();
		federate.setLrcHandle(lrcHandle);
		federate.setHandle(federateHandle);
		federate.setFederationExecution(federationExecution);
		return federate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ObjectInstance createObjectInstance() {
		ObjectInstanceImpl objectInstance = new ObjectInstanceImpl();
		return objectInstance;
	}

	/** 
	 * {@inheritDoc}
	 */
	public ObjectInstance createObjectInstance(ObjectClass objectClass, ObjectInstanceHandle objectInstanceHandle) {
		ObjectInstance objectInstance = createObjectInstance();
		objectInstance.setObjectClass(objectClass);
		objectInstance.setHandle(objectInstanceHandle);
		objectInstance.setName(DEFAULT_OBJECT_INSTANCE_PREFIX + objectInstanceHandle.toString());
		return objectInstance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FederateHandle createEFederateHandleFromString(EDataType eDataType, String initialValue) {
		return (FederateHandle) super.createFromString(eDataType, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertEFederateHandleToString(EDataType eDataType, Object instanceValue) {
		return super.convertToString(eDataType, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ObjectInstanceHandle createEObjectInstanceHandleFromString(EDataType eDataType, String initialValue) {
		return (ObjectInstanceHandle) super.createFromString(eDataType, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertEObjectInstanceHandleToString(EDataType eDataType, Object instanceValue) {
		return super.convertToString(eDataType, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LrcHandle createELrcHandleFromString(EDataType eDataType, String initialValue) {
		return (LrcHandle) super.createFromString(eDataType, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertELrcHandleToString(EDataType eDataType, Object instanceValue) {
		return super.convertToString(eDataType, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DataPackage getDataPackage() {
		return (DataPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	public static DataPackage getPackage() {
		return DataPackage.eINSTANCE;
	}

} //DataFactoryImpl
