/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Transportations</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.Transportations#getTransportation <em>Transportation</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eodisp.hla.crc.omt.OmtPackage#getTransportations()
 * @model extendedMetaData="name='Transportations' kind='elementOnly'"
 * @generated
 */
public interface Transportations extends EObject {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * Returns the value of the '<em><b>Transportation</b></em>' containment reference list.
	 * The list contents are of type {@link org.eodisp.hla.crc.omt.Transportation}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Transportation</em>' containment reference
	 * list isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transportation</em>' containment reference list.
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getTransportations_Transportation()
	 * @model type="org.eodisp.hla.crc.omt.Transportation" containment="true" required="true"
	 *        extendedMetaData="kind='element' name='transportation' namespace='##targetNamespace'"
	 * @generated
	 */
	EList getTransportation();

} // Transportations
