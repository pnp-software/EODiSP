/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt.impl;

import java.util.List;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eodisp.hla.crc.omt.ArrayData;
import org.eodisp.hla.crc.omt.OmtPackage;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Array Data</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ArrayDataImpl#getCardinality <em>Cardinality</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ArrayDataImpl#getCardinalityNotes <em>Cardinality Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ArrayDataImpl#getDataType <em>Data Type</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ArrayDataImpl#getDataTypeNotes <em>Data Type Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ArrayDataImpl#getEncoding <em>Encoding</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ArrayDataImpl#getEncodingNotes <em>Encoding Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ArrayDataImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ArrayDataImpl#getNameNotes <em>Name Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ArrayDataImpl#getSemantics <em>Semantics</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ArrayDataImpl#getSemanticsNotes <em>Semantics Notes</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ArrayDataImpl extends EObjectImpl implements ArrayData {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The default value of the '{@link #getCardinality() <em>Cardinality</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getCardinality()
	 * @generated
	 * @ordered
	 */
	protected static final Object CARDINALITY_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCardinality() <em>Cardinality</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getCardinality()
	 * @generated
	 * @ordered
	 */
	protected Object cardinality = CARDINALITY_EDEFAULT;

	/**
	 * The default value of the '{@link #getCardinalityNotes() <em>Cardinality Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getCardinalityNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List CARDINALITY_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCardinalityNotes() <em>Cardinality Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getCardinalityNotes()
	 * @generated
	 * @ordered
	 */
	protected List cardinalityNotes = CARDINALITY_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getDataType() <em>Data Type</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDataType()
	 * @generated
	 * @ordered
	 */
	protected static final String DATA_TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDataType() <em>Data Type</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDataType()
	 * @generated
	 * @ordered
	 */
	protected String dataType = DATA_TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getDataTypeNotes() <em>Data Type Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDataTypeNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List DATA_TYPE_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDataTypeNotes() <em>Data Type Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDataTypeNotes()
	 * @generated
	 * @ordered
	 */
	protected List dataTypeNotes = DATA_TYPE_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getEncoding() <em>Encoding</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getEncoding()
	 * @generated
	 * @ordered
	 */
	protected static final Object ENCODING_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getEncoding() <em>Encoding</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getEncoding()
	 * @generated
	 * @ordered
	 */
	protected Object encoding = ENCODING_EDEFAULT;

	/**
	 * The default value of the '{@link #getEncodingNotes() <em>Encoding Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getEncodingNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List ENCODING_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getEncodingNotes() <em>Encoding Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getEncodingNotes()
	 * @generated
	 * @ordered
	 */
	protected List encodingNotes = ENCODING_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getNameNotes() <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getNameNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List NAME_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNameNotes() <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getNameNotes()
	 * @generated
	 * @ordered
	 */
	protected List nameNotes = NAME_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getSemantics() <em>Semantics</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSemantics()
	 * @generated
	 * @ordered
	 */
	protected static final Object SEMANTICS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSemantics() <em>Semantics</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSemantics()
	 * @generated
	 * @ordered
	 */
	protected Object semantics = SEMANTICS_EDEFAULT;

	/**
	 * The default value of the '{@link #getSemanticsNotes() <em>Semantics Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSemanticsNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List SEMANTICS_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSemanticsNotes() <em>Semantics Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSemanticsNotes()
	 * @generated
	 * @ordered
	 */
	protected List semanticsNotes = SEMANTICS_NOTES_EDEFAULT;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected ArrayDataImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return OmtPackage.Literals.ARRAY_DATA;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getCardinality() {
		return cardinality;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setCardinality(Object newCardinality) {
		Object oldCardinality = cardinality;
		cardinality = newCardinality;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ARRAY_DATA__CARDINALITY,
					oldCardinality,
					cardinality));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getCardinalityNotes() {
		return cardinalityNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setCardinalityNotes(List newCardinalityNotes) {
		List oldCardinalityNotes = cardinalityNotes;
		cardinalityNotes = newCardinalityNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ARRAY_DATA__CARDINALITY_NOTES,
					oldCardinalityNotes,
					cardinalityNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String getDataType() {
		return dataType;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setDataType(String newDataType) {
		String oldDataType = dataType;
		dataType = newDataType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ARRAY_DATA__DATA_TYPE,
					oldDataType,
					dataType));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getDataTypeNotes() {
		return dataTypeNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setDataTypeNotes(List newDataTypeNotes) {
		List oldDataTypeNotes = dataTypeNotes;
		dataTypeNotes = newDataTypeNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ARRAY_DATA__DATA_TYPE_NOTES,
					oldDataTypeNotes,
					dataTypeNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getEncoding() {
		return encoding;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setEncoding(Object newEncoding) {
		Object oldEncoding = encoding;
		encoding = newEncoding;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ARRAY_DATA__ENCODING,
					oldEncoding,
					encoding));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getEncodingNotes() {
		return encodingNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setEncodingNotes(List newEncodingNotes) {
		List oldEncodingNotes = encodingNotes;
		encodingNotes = newEncodingNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ARRAY_DATA__ENCODING_NOTES,
					oldEncodingNotes,
					encodingNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OmtPackage.ARRAY_DATA__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getNameNotes() {
		return nameNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setNameNotes(List newNameNotes) {
		List oldNameNotes = nameNotes;
		nameNotes = newNameNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ARRAY_DATA__NAME_NOTES,
					oldNameNotes,
					nameNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getSemantics() {
		return semantics;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setSemantics(Object newSemantics) {
		Object oldSemantics = semantics;
		semantics = newSemantics;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ARRAY_DATA__SEMANTICS,
					oldSemantics,
					semantics));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getSemanticsNotes() {
		return semanticsNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setSemanticsNotes(List newSemanticsNotes) {
		List oldSemanticsNotes = semanticsNotes;
		semanticsNotes = newSemanticsNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ARRAY_DATA__SEMANTICS_NOTES,
					oldSemanticsNotes,
					semanticsNotes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case OmtPackage.ARRAY_DATA__CARDINALITY:
			return getCardinality();
		case OmtPackage.ARRAY_DATA__CARDINALITY_NOTES:
			return getCardinalityNotes();
		case OmtPackage.ARRAY_DATA__DATA_TYPE:
			return getDataType();
		case OmtPackage.ARRAY_DATA__DATA_TYPE_NOTES:
			return getDataTypeNotes();
		case OmtPackage.ARRAY_DATA__ENCODING:
			return getEncoding();
		case OmtPackage.ARRAY_DATA__ENCODING_NOTES:
			return getEncodingNotes();
		case OmtPackage.ARRAY_DATA__NAME:
			return getName();
		case OmtPackage.ARRAY_DATA__NAME_NOTES:
			return getNameNotes();
		case OmtPackage.ARRAY_DATA__SEMANTICS:
			return getSemantics();
		case OmtPackage.ARRAY_DATA__SEMANTICS_NOTES:
			return getSemanticsNotes();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case OmtPackage.ARRAY_DATA__CARDINALITY:
			setCardinality((Object) newValue);
			return;
		case OmtPackage.ARRAY_DATA__CARDINALITY_NOTES:
			setCardinalityNotes((List) newValue);
			return;
		case OmtPackage.ARRAY_DATA__DATA_TYPE:
			setDataType((String) newValue);
			return;
		case OmtPackage.ARRAY_DATA__DATA_TYPE_NOTES:
			setDataTypeNotes((List) newValue);
			return;
		case OmtPackage.ARRAY_DATA__ENCODING:
			setEncoding((Object) newValue);
			return;
		case OmtPackage.ARRAY_DATA__ENCODING_NOTES:
			setEncodingNotes((List) newValue);
			return;
		case OmtPackage.ARRAY_DATA__NAME:
			setName((String) newValue);
			return;
		case OmtPackage.ARRAY_DATA__NAME_NOTES:
			setNameNotes((List) newValue);
			return;
		case OmtPackage.ARRAY_DATA__SEMANTICS:
			setSemantics((Object) newValue);
			return;
		case OmtPackage.ARRAY_DATA__SEMANTICS_NOTES:
			setSemanticsNotes((List) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
		case OmtPackage.ARRAY_DATA__CARDINALITY:
			setCardinality(CARDINALITY_EDEFAULT);
			return;
		case OmtPackage.ARRAY_DATA__CARDINALITY_NOTES:
			setCardinalityNotes(CARDINALITY_NOTES_EDEFAULT);
			return;
		case OmtPackage.ARRAY_DATA__DATA_TYPE:
			setDataType(DATA_TYPE_EDEFAULT);
			return;
		case OmtPackage.ARRAY_DATA__DATA_TYPE_NOTES:
			setDataTypeNotes(DATA_TYPE_NOTES_EDEFAULT);
			return;
		case OmtPackage.ARRAY_DATA__ENCODING:
			setEncoding(ENCODING_EDEFAULT);
			return;
		case OmtPackage.ARRAY_DATA__ENCODING_NOTES:
			setEncodingNotes(ENCODING_NOTES_EDEFAULT);
			return;
		case OmtPackage.ARRAY_DATA__NAME:
			setName(NAME_EDEFAULT);
			return;
		case OmtPackage.ARRAY_DATA__NAME_NOTES:
			setNameNotes(NAME_NOTES_EDEFAULT);
			return;
		case OmtPackage.ARRAY_DATA__SEMANTICS:
			setSemantics(SEMANTICS_EDEFAULT);
			return;
		case OmtPackage.ARRAY_DATA__SEMANTICS_NOTES:
			setSemanticsNotes(SEMANTICS_NOTES_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case OmtPackage.ARRAY_DATA__CARDINALITY:
			return CARDINALITY_EDEFAULT == null ? cardinality != null : !CARDINALITY_EDEFAULT.equals(cardinality);
		case OmtPackage.ARRAY_DATA__CARDINALITY_NOTES:
			return CARDINALITY_NOTES_EDEFAULT == null ? cardinalityNotes != null : !CARDINALITY_NOTES_EDEFAULT
					.equals(cardinalityNotes);
		case OmtPackage.ARRAY_DATA__DATA_TYPE:
			return DATA_TYPE_EDEFAULT == null ? dataType != null : !DATA_TYPE_EDEFAULT.equals(dataType);
		case OmtPackage.ARRAY_DATA__DATA_TYPE_NOTES:
			return DATA_TYPE_NOTES_EDEFAULT == null ? dataTypeNotes != null : !DATA_TYPE_NOTES_EDEFAULT
					.equals(dataTypeNotes);
		case OmtPackage.ARRAY_DATA__ENCODING:
			return ENCODING_EDEFAULT == null ? encoding != null : !ENCODING_EDEFAULT.equals(encoding);
		case OmtPackage.ARRAY_DATA__ENCODING_NOTES:
			return ENCODING_NOTES_EDEFAULT == null ? encodingNotes != null : !ENCODING_NOTES_EDEFAULT
					.equals(encodingNotes);
		case OmtPackage.ARRAY_DATA__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case OmtPackage.ARRAY_DATA__NAME_NOTES:
			return NAME_NOTES_EDEFAULT == null ? nameNotes != null : !NAME_NOTES_EDEFAULT.equals(nameNotes);
		case OmtPackage.ARRAY_DATA__SEMANTICS:
			return SEMANTICS_EDEFAULT == null ? semantics != null : !SEMANTICS_EDEFAULT.equals(semantics);
		case OmtPackage.ARRAY_DATA__SEMANTICS_NOTES:
			return SEMANTICS_NOTES_EDEFAULT == null ? semanticsNotes != null : !SEMANTICS_NOTES_EDEFAULT
					.equals(semanticsNotes);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (cardinality: ");
		result.append(cardinality);
		result.append(", cardinalityNotes: ");
		result.append(cardinalityNotes);
		result.append(", dataType: ");
		result.append(dataType);
		result.append(", dataTypeNotes: ");
		result.append(dataTypeNotes);
		result.append(", encoding: ");
		result.append(encoding);
		result.append(", encodingNotes: ");
		result.append(encodingNotes);
		result.append(", name: ");
		result.append(name);
		result.append(", nameNotes: ");
		result.append(nameNotes);
		result.append(", semantics: ");
		result.append(semantics);
		result.append(", semanticsNotes: ");
		result.append(semanticsNotes);
		result.append(')');
		return result.toString();
	}

} // ArrayDataImpl
