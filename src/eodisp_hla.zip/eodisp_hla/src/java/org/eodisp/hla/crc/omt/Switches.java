/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt;

import java.util.List;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Switches</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.Switches#getAttributeRelevanceAdvisory <em>Attribute Relevance Advisory</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Switches#getAttributeRelevanceAdvisoryNotes <em>Attribute Relevance Advisory Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Switches#getAttributeScopeAdvisory <em>Attribute Scope Advisory</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Switches#getAttributeScopeAdvisoryNotes <em>Attribute Scope Advisory Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Switches#getAutoProvide <em>Auto Provide</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Switches#getAutoProvideNotes <em>Auto Provide Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Switches#getConveyRegionDesignatorSets <em>Convey Region Designator Sets</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Switches#getConveyRegionDesignatorSetsNotes <em>Convey Region Designator Sets Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Switches#getInteractionRelevanceAdvisory <em>Interaction Relevance Advisory</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Switches#getInteractionRelevanceAdvisoryNotes <em>Interaction Relevance Advisory Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Switches#getObjectClassRelevanceAdvisory <em>Object Class Relevance Advisory</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Switches#getObjectClassRelevanceAdvisoryNotes <em>Object Class Relevance Advisory Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Switches#getServiceReporting <em>Service Reporting</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Switches#getServiceReportingNotes <em>Service Reporting Notes</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eodisp.hla.crc.omt.OmtPackage#getSwitches()
 * @model extendedMetaData="name='Switches' kind='empty'"
 * @generated
 */
public interface Switches extends EObject {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * Returns the value of the '<em><b>Attribute Relevance Advisory</b></em>'
	 * attribute. The default value is <code>"Enabled"</code>. The literals
	 * are from the enumeration {@link org.eodisp.hla.crc.omt.StateEnum}. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Attribute Relevance Advisory</em>'
	 * attribute isn't clear, there really should be more of a description
	 * here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Attribute Relevance Advisory</em>'
	 *         attribute.
	 * @see org.eodisp.hla.crc.omt.StateEnum
	 * @see #isSetAttributeRelevanceAdvisory()
	 * @see #unsetAttributeRelevanceAdvisory()
	 * @see #setAttributeRelevanceAdvisory(StateEnum)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSwitches_AttributeRelevanceAdvisory()
	 * @model default="Enabled" unique="false" unsettable="true"
	 *        extendedMetaData="kind='attribute'
	 *        name='attributeRelevanceAdvisory' namespace='##targetNamespace'"
	 * @generated
	 */
	StateEnum getAttributeRelevanceAdvisory();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Switches#getAttributeRelevanceAdvisory <em>Attribute Relevance Advisory</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Attribute Relevance Advisory</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.StateEnum
	 * @see #isSetAttributeRelevanceAdvisory()
	 * @see #unsetAttributeRelevanceAdvisory()
	 * @see #getAttributeRelevanceAdvisory()
	 * @generated
	 */
	void setAttributeRelevanceAdvisory(StateEnum value);

	/**
	 * Unsets the value of the '{@link org.eodisp.hla.crc.omt.Switches#getAttributeRelevanceAdvisory <em>Attribute Relevance Advisory</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #isSetAttributeRelevanceAdvisory()
	 * @see #getAttributeRelevanceAdvisory()
	 * @see #setAttributeRelevanceAdvisory(StateEnum)
	 * @generated
	 */
	void unsetAttributeRelevanceAdvisory();

	/**
	 * Returns whether the value of the '{@link org.eodisp.hla.crc.omt.Switches#getAttributeRelevanceAdvisory <em>Attribute Relevance Advisory</em>}' attribute is set.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return whether the value of the '<em>Attribute Relevance Advisory</em>' attribute is set.
	 * @see #unsetAttributeRelevanceAdvisory()
	 * @see #getAttributeRelevanceAdvisory()
	 * @see #setAttributeRelevanceAdvisory(StateEnum)
	 * @generated
	 */
	boolean isSetAttributeRelevanceAdvisory();

	/**
	 * Returns the value of the '<em><b>Attribute Relevance Advisory Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Attribute Relevance Advisory Notes</em>'
	 * attribute isn't clear, there really should be more of a description
	 * here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attribute Relevance Advisory Notes</em>' attribute.
	 * @see #setAttributeRelevanceAdvisoryNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSwitches_AttributeRelevanceAdvisoryNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='attributeRelevanceAdvisoryNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getAttributeRelevanceAdvisoryNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Switches#getAttributeRelevanceAdvisoryNotes <em>Attribute Relevance Advisory Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Attribute Relevance Advisory Notes</em>' attribute.
	 * @see #getAttributeRelevanceAdvisoryNotes()
	 * @generated
	 */
	void setAttributeRelevanceAdvisoryNotes(List value);

	/**
	 * Returns the value of the '<em><b>Attribute Scope Advisory</b></em>'
	 * attribute. The default value is <code>"Enabled"</code>. The literals
	 * are from the enumeration {@link org.eodisp.hla.crc.omt.StateEnum}. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Attribute Scope Advisory</em>' attribute
	 * isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Attribute Scope Advisory</em>'
	 *         attribute.
	 * @see org.eodisp.hla.crc.omt.StateEnum
	 * @see #isSetAttributeScopeAdvisory()
	 * @see #unsetAttributeScopeAdvisory()
	 * @see #setAttributeScopeAdvisory(StateEnum)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSwitches_AttributeScopeAdvisory()
	 * @model default="Enabled" unique="false" unsettable="true"
	 *        extendedMetaData="kind='attribute' name='attributeScopeAdvisory'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	StateEnum getAttributeScopeAdvisory();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Switches#getAttributeScopeAdvisory <em>Attribute Scope Advisory</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Attribute Scope Advisory</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.StateEnum
	 * @see #isSetAttributeScopeAdvisory()
	 * @see #unsetAttributeScopeAdvisory()
	 * @see #getAttributeScopeAdvisory()
	 * @generated
	 */
	void setAttributeScopeAdvisory(StateEnum value);

	/**
	 * Unsets the value of the '{@link org.eodisp.hla.crc.omt.Switches#getAttributeScopeAdvisory <em>Attribute Scope Advisory</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #isSetAttributeScopeAdvisory()
	 * @see #getAttributeScopeAdvisory()
	 * @see #setAttributeScopeAdvisory(StateEnum)
	 * @generated
	 */
	void unsetAttributeScopeAdvisory();

	/**
	 * Returns whether the value of the '{@link org.eodisp.hla.crc.omt.Switches#getAttributeScopeAdvisory <em>Attribute Scope Advisory</em>}' attribute is set.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return whether the value of the '<em>Attribute Scope Advisory</em>' attribute is set.
	 * @see #unsetAttributeScopeAdvisory()
	 * @see #getAttributeScopeAdvisory()
	 * @see #setAttributeScopeAdvisory(StateEnum)
	 * @generated
	 */
	boolean isSetAttributeScopeAdvisory();

	/**
	 * Returns the value of the '<em><b>Attribute Scope Advisory Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Attribute Scope Advisory Notes</em>'
	 * attribute isn't clear, there really should be more of a description
	 * here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attribute Scope Advisory Notes</em>' attribute.
	 * @see #setAttributeScopeAdvisoryNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSwitches_AttributeScopeAdvisoryNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='attributeScopeAdvisoryNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getAttributeScopeAdvisoryNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Switches#getAttributeScopeAdvisoryNotes <em>Attribute Scope Advisory Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Attribute Scope Advisory Notes</em>' attribute.
	 * @see #getAttributeScopeAdvisoryNotes()
	 * @generated
	 */
	void setAttributeScopeAdvisoryNotes(List value);

	/**
	 * Returns the value of the '<em><b>Auto Provide</b></em>' attribute.
	 * The default value is <code>"Enabled"</code>. The literals are from the
	 * enumeration {@link org.eodisp.hla.crc.omt.StateEnum}. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Auto Provide</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Auto Provide</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.StateEnum
	 * @see #isSetAutoProvide()
	 * @see #unsetAutoProvide()
	 * @see #setAutoProvide(StateEnum)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSwitches_AutoProvide()
	 * @model default="Enabled" unique="false" unsettable="true"
	 *        extendedMetaData="kind='attribute' name='autoProvide'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	StateEnum getAutoProvide();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Switches#getAutoProvide <em>Auto Provide</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Auto Provide</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.StateEnum
	 * @see #isSetAutoProvide()
	 * @see #unsetAutoProvide()
	 * @see #getAutoProvide()
	 * @generated
	 */
	void setAutoProvide(StateEnum value);

	/**
	 * Unsets the value of the '{@link org.eodisp.hla.crc.omt.Switches#getAutoProvide <em>Auto Provide</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #isSetAutoProvide()
	 * @see #getAutoProvide()
	 * @see #setAutoProvide(StateEnum)
	 * @generated
	 */
	void unsetAutoProvide();

	/**
	 * Returns whether the value of the '{@link org.eodisp.hla.crc.omt.Switches#getAutoProvide <em>Auto Provide</em>}' attribute is set.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return whether the value of the '<em>Auto Provide</em>' attribute is set.
	 * @see #unsetAutoProvide()
	 * @see #getAutoProvide()
	 * @see #setAutoProvide(StateEnum)
	 * @generated
	 */
	boolean isSetAutoProvide();

	/**
	 * Returns the value of the '<em><b>Auto Provide Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Auto Provide Notes</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Auto Provide Notes</em>' attribute.
	 * @see #setAutoProvideNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSwitches_AutoProvideNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='autoProvideNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getAutoProvideNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Switches#getAutoProvideNotes <em>Auto Provide Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Auto Provide Notes</em>' attribute.
	 * @see #getAutoProvideNotes()
	 * @generated
	 */
	void setAutoProvideNotes(List value);

	/**
	 * Returns the value of the '<em><b>Convey Region Designator Sets</b></em>'
	 * attribute. The default value is <code>"Enabled"</code>. The literals
	 * are from the enumeration {@link org.eodisp.hla.crc.omt.StateEnum}. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Convey Region Designator Sets</em>'
	 * attribute isn't clear, there really should be more of a description
	 * here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Convey Region Designator Sets</em>'
	 *         attribute.
	 * @see org.eodisp.hla.crc.omt.StateEnum
	 * @see #isSetConveyRegionDesignatorSets()
	 * @see #unsetConveyRegionDesignatorSets()
	 * @see #setConveyRegionDesignatorSets(StateEnum)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSwitches_ConveyRegionDesignatorSets()
	 * @model default="Enabled" unique="false" unsettable="true"
	 *        extendedMetaData="kind='attribute'
	 *        name='conveyRegionDesignatorSets' namespace='##targetNamespace'"
	 * @generated
	 */
	StateEnum getConveyRegionDesignatorSets();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Switches#getConveyRegionDesignatorSets <em>Convey Region Designator Sets</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Convey Region Designator Sets</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.StateEnum
	 * @see #isSetConveyRegionDesignatorSets()
	 * @see #unsetConveyRegionDesignatorSets()
	 * @see #getConveyRegionDesignatorSets()
	 * @generated
	 */
	void setConveyRegionDesignatorSets(StateEnum value);

	/**
	 * Unsets the value of the '{@link org.eodisp.hla.crc.omt.Switches#getConveyRegionDesignatorSets <em>Convey Region Designator Sets</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #isSetConveyRegionDesignatorSets()
	 * @see #getConveyRegionDesignatorSets()
	 * @see #setConveyRegionDesignatorSets(StateEnum)
	 * @generated
	 */
	void unsetConveyRegionDesignatorSets();

	/**
	 * Returns whether the value of the '{@link org.eodisp.hla.crc.omt.Switches#getConveyRegionDesignatorSets <em>Convey Region Designator Sets</em>}' attribute is set.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return whether the value of the '<em>Convey Region Designator Sets</em>' attribute is set.
	 * @see #unsetConveyRegionDesignatorSets()
	 * @see #getConveyRegionDesignatorSets()
	 * @see #setConveyRegionDesignatorSets(StateEnum)
	 * @generated
	 */
	boolean isSetConveyRegionDesignatorSets();

	/**
	 * Returns the value of the '<em><b>Convey Region Designator Sets Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Convey Region Designator Sets Notes</em>'
	 * attribute isn't clear, there really should be more of a description
	 * here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Convey Region Designator Sets Notes</em>' attribute.
	 * @see #setConveyRegionDesignatorSetsNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSwitches_ConveyRegionDesignatorSetsNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='conveyRegionDesignatorSetsNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getConveyRegionDesignatorSetsNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Switches#getConveyRegionDesignatorSetsNotes <em>Convey Region Designator Sets Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Convey Region Designator Sets Notes</em>' attribute.
	 * @see #getConveyRegionDesignatorSetsNotes()
	 * @generated
	 */
	void setConveyRegionDesignatorSetsNotes(List value);

	/**
	 * Returns the value of the '<em><b>Interaction Relevance Advisory</b></em>'
	 * attribute. The default value is <code>"Enabled"</code>. The literals
	 * are from the enumeration {@link org.eodisp.hla.crc.omt.StateEnum}. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Interaction Relevance Advisory</em>'
	 * attribute isn't clear, there really should be more of a description
	 * here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Interaction Relevance Advisory</em>'
	 *         attribute.
	 * @see org.eodisp.hla.crc.omt.StateEnum
	 * @see #isSetInteractionRelevanceAdvisory()
	 * @see #unsetInteractionRelevanceAdvisory()
	 * @see #setInteractionRelevanceAdvisory(StateEnum)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSwitches_InteractionRelevanceAdvisory()
	 * @model default="Enabled" unique="false" unsettable="true"
	 *        extendedMetaData="kind='attribute'
	 *        name='interactionRelevanceAdvisory' namespace='##targetNamespace'"
	 * @generated
	 */
	StateEnum getInteractionRelevanceAdvisory();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Switches#getInteractionRelevanceAdvisory <em>Interaction Relevance Advisory</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Interaction Relevance Advisory</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.StateEnum
	 * @see #isSetInteractionRelevanceAdvisory()
	 * @see #unsetInteractionRelevanceAdvisory()
	 * @see #getInteractionRelevanceAdvisory()
	 * @generated
	 */
	void setInteractionRelevanceAdvisory(StateEnum value);

	/**
	 * Unsets the value of the '{@link org.eodisp.hla.crc.omt.Switches#getInteractionRelevanceAdvisory <em>Interaction Relevance Advisory</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #isSetInteractionRelevanceAdvisory()
	 * @see #getInteractionRelevanceAdvisory()
	 * @see #setInteractionRelevanceAdvisory(StateEnum)
	 * @generated
	 */
	void unsetInteractionRelevanceAdvisory();

	/**
	 * Returns whether the value of the '{@link org.eodisp.hla.crc.omt.Switches#getInteractionRelevanceAdvisory <em>Interaction Relevance Advisory</em>}' attribute is set.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return whether the value of the '<em>Interaction Relevance Advisory</em>' attribute is set.
	 * @see #unsetInteractionRelevanceAdvisory()
	 * @see #getInteractionRelevanceAdvisory()
	 * @see #setInteractionRelevanceAdvisory(StateEnum)
	 * @generated
	 */
	boolean isSetInteractionRelevanceAdvisory();

	/**
	 * Returns the value of the '<em><b>Interaction Relevance Advisory Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Interaction Relevance Advisory Notes</em>'
	 * attribute isn't clear, there really should be more of a description
	 * here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Interaction Relevance Advisory Notes</em>' attribute.
	 * @see #setInteractionRelevanceAdvisoryNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSwitches_InteractionRelevanceAdvisoryNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='interactionRelevanceAdvisoryNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getInteractionRelevanceAdvisoryNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Switches#getInteractionRelevanceAdvisoryNotes <em>Interaction Relevance Advisory Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Interaction Relevance Advisory Notes</em>' attribute.
	 * @see #getInteractionRelevanceAdvisoryNotes()
	 * @generated
	 */
	void setInteractionRelevanceAdvisoryNotes(List value);

	/**
	 * Returns the value of the '<em><b>Object Class Relevance Advisory</b></em>'
	 * attribute. The default value is <code>"Enabled"</code>. The literals
	 * are from the enumeration {@link org.eodisp.hla.crc.omt.StateEnum}. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Object Class Relevance Advisory</em>'
	 * attribute isn't clear, there really should be more of a description
	 * here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Object Class Relevance Advisory</em>'
	 *         attribute.
	 * @see org.eodisp.hla.crc.omt.StateEnum
	 * @see #isSetObjectClassRelevanceAdvisory()
	 * @see #unsetObjectClassRelevanceAdvisory()
	 * @see #setObjectClassRelevanceAdvisory(StateEnum)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSwitches_ObjectClassRelevanceAdvisory()
	 * @model default="Enabled" unique="false" unsettable="true"
	 *        extendedMetaData="kind='attribute'
	 *        name='objectClassRelevanceAdvisory' namespace='##targetNamespace'"
	 * @generated
	 */
	StateEnum getObjectClassRelevanceAdvisory();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Switches#getObjectClassRelevanceAdvisory <em>Object Class Relevance Advisory</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Object Class Relevance Advisory</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.StateEnum
	 * @see #isSetObjectClassRelevanceAdvisory()
	 * @see #unsetObjectClassRelevanceAdvisory()
	 * @see #getObjectClassRelevanceAdvisory()
	 * @generated
	 */
	void setObjectClassRelevanceAdvisory(StateEnum value);

	/**
	 * Unsets the value of the '{@link org.eodisp.hla.crc.omt.Switches#getObjectClassRelevanceAdvisory <em>Object Class Relevance Advisory</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #isSetObjectClassRelevanceAdvisory()
	 * @see #getObjectClassRelevanceAdvisory()
	 * @see #setObjectClassRelevanceAdvisory(StateEnum)
	 * @generated
	 */
	void unsetObjectClassRelevanceAdvisory();

	/**
	 * Returns whether the value of the '{@link org.eodisp.hla.crc.omt.Switches#getObjectClassRelevanceAdvisory <em>Object Class Relevance Advisory</em>}' attribute is set.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return whether the value of the '<em>Object Class Relevance Advisory</em>' attribute is set.
	 * @see #unsetObjectClassRelevanceAdvisory()
	 * @see #getObjectClassRelevanceAdvisory()
	 * @see #setObjectClassRelevanceAdvisory(StateEnum)
	 * @generated
	 */
	boolean isSetObjectClassRelevanceAdvisory();

	/**
	 * Returns the value of the '<em><b>Object Class Relevance Advisory Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Object Class Relevance Advisory Notes</em>'
	 * attribute isn't clear, there really should be more of a description
	 * here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Object Class Relevance Advisory Notes</em>' attribute.
	 * @see #setObjectClassRelevanceAdvisoryNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSwitches_ObjectClassRelevanceAdvisoryNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='objectClassRelevanceAdvisoryNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getObjectClassRelevanceAdvisoryNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Switches#getObjectClassRelevanceAdvisoryNotes <em>Object Class Relevance Advisory Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Object Class Relevance Advisory Notes</em>' attribute.
	 * @see #getObjectClassRelevanceAdvisoryNotes()
	 * @generated
	 */
	void setObjectClassRelevanceAdvisoryNotes(List value);

	/**
	 * Returns the value of the '<em><b>Service Reporting</b></em>'
	 * attribute. The default value is <code>"Enabled"</code>. The literals
	 * are from the enumeration {@link org.eodisp.hla.crc.omt.StateEnum}. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Service Reporting</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Service Reporting</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.StateEnum
	 * @see #isSetServiceReporting()
	 * @see #unsetServiceReporting()
	 * @see #setServiceReporting(StateEnum)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSwitches_ServiceReporting()
	 * @model default="Enabled" unique="false" unsettable="true"
	 *        extendedMetaData="kind='attribute' name='serviceReporting'
	 *        namespace='##targetNamespace'"
	 * @generated
	 */
	StateEnum getServiceReporting();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Switches#getServiceReporting <em>Service Reporting</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Service Reporting</em>' attribute.
	 * @see org.eodisp.hla.crc.omt.StateEnum
	 * @see #isSetServiceReporting()
	 * @see #unsetServiceReporting()
	 * @see #getServiceReporting()
	 * @generated
	 */
	void setServiceReporting(StateEnum value);

	/**
	 * Unsets the value of the '{@link org.eodisp.hla.crc.omt.Switches#getServiceReporting <em>Service Reporting</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #isSetServiceReporting()
	 * @see #getServiceReporting()
	 * @see #setServiceReporting(StateEnum)
	 * @generated
	 */
	void unsetServiceReporting();

	/**
	 * Returns whether the value of the '{@link org.eodisp.hla.crc.omt.Switches#getServiceReporting <em>Service Reporting</em>}' attribute is set.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @return whether the value of the '<em>Service Reporting</em>' attribute is set.
	 * @see #unsetServiceReporting()
	 * @see #getServiceReporting()
	 * @see #setServiceReporting(StateEnum)
	 * @generated
	 */
	boolean isSetServiceReporting();

	/**
	 * Returns the value of the '<em><b>Service Reporting Notes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Service Reporting Notes</em>' attribute
	 * isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Service Reporting Notes</em>' attribute.
	 * @see #setServiceReportingNotes(List)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getSwitches_ServiceReportingNotes()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.NMTOKENS" many="false"
	 *        extendedMetaData="kind='attribute' name='serviceReportingNotes' namespace='##targetNamespace'"
	 * @generated
	 */
	List getServiceReportingNotes();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Switches#getServiceReportingNotes <em>Service Reporting Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Service Reporting Notes</em>' attribute.
	 * @see #getServiceReportingNotes()
	 * @generated
	 */
	void setServiceReportingNotes(List value);

} // Switches
