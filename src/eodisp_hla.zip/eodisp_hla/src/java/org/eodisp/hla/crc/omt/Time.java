/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Time</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.Time#getTimeStamp <em>Time Stamp</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.Time#getLookahead <em>Lookahead</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eodisp.hla.crc.omt.OmtPackage#getTime()
 * @model extendedMetaData="name='Time' kind='elementOnly'"
 * @generated
 */
public interface Time extends EObject {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * Returns the value of the '<em><b>Time Stamp</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Time Stamp</em>' containment reference
	 * isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Time Stamp</em>' containment reference.
	 * @see #setTimeStamp(TimeStamp)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getTime_TimeStamp()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='timeStamp' namespace='##targetNamespace'"
	 * @generated
	 */
	TimeStamp getTimeStamp();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Time#getTimeStamp <em>Time Stamp</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Time Stamp</em>' containment reference.
	 * @see #getTimeStamp()
	 * @generated
	 */
	void setTimeStamp(TimeStamp value);

	/**
	 * Returns the value of the '<em><b>Lookahead</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Lookahead</em>' containment reference
	 * isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Lookahead</em>' containment reference.
	 * @see #setLookahead(Lookahead)
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getTime_Lookahead()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='lookahead' namespace='##targetNamespace'"
	 * @generated
	 */
	Lookahead getLookahead();

	/**
	 * Sets the value of the '{@link org.eodisp.hla.crc.omt.Time#getLookahead <em>Lookahead</em>}' containment reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @param value the new value of the '<em>Lookahead</em>' containment reference.
	 * @see #getLookahead()
	 * @generated
	 */
	void setLookahead(Lookahead value);

} // Time
