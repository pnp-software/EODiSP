/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.eodisp.hla.crc.omt.FixedRecordData;
import org.eodisp.hla.crc.omt.FixedRecordDataTypes;
import org.eodisp.hla.crc.omt.OmtPackage;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Fixed Record Data Types</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.FixedRecordDataTypesImpl#getFixedRecordData <em>Fixed Record Data</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class FixedRecordDataTypesImpl extends EObjectImpl implements FixedRecordDataTypes {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The cached value of the '{@link #getFixedRecordData() <em>Fixed Record Data</em>}' containment reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getFixedRecordData()
	 * @generated
	 * @ordered
	 */
	protected EList fixedRecordData = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected FixedRecordDataTypesImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return OmtPackage.Literals.FIXED_RECORD_DATA_TYPES;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EList getFixedRecordData() {
		if (fixedRecordData == null) {
			fixedRecordData = new EObjectContainmentEList(
					FixedRecordData.class,
					this,
					OmtPackage.FIXED_RECORD_DATA_TYPES__FIXED_RECORD_DATA);
		}
		return fixedRecordData;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case OmtPackage.FIXED_RECORD_DATA_TYPES__FIXED_RECORD_DATA:
			return ((InternalEList) getFixedRecordData()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case OmtPackage.FIXED_RECORD_DATA_TYPES__FIXED_RECORD_DATA:
			return getFixedRecordData();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case OmtPackage.FIXED_RECORD_DATA_TYPES__FIXED_RECORD_DATA:
			getFixedRecordData().clear();
			getFixedRecordData().addAll((Collection) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
		case OmtPackage.FIXED_RECORD_DATA_TYPES__FIXED_RECORD_DATA:
			getFixedRecordData().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case OmtPackage.FIXED_RECORD_DATA_TYPES__FIXED_RECORD_DATA:
			return fixedRecordData != null && !fixedRecordData.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} // FixedRecordDataTypesImpl
