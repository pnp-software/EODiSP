/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt.impl;

import java.util.Collection;
import hla.rti1516.AttributeHandle;

import java.util.List;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.eodisp.hla.crc.data.DataPackage;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;

import org.eodisp.hla.crc.data.Federate;

import org.eodisp.hla.crc.omt.Attribute;
import org.eodisp.hla.crc.omt.OmtPackage;
import org.eodisp.hla.crc.omt.OrderEnum;
import org.eodisp.hla.crc.omt.OwnershipEnum;
import org.eodisp.hla.crc.omt.SharingEnum;
import org.eodisp.hla.crc.omt.UpdateTypeEnum;

import org.eodisp.hla.crc.omt.*;

import org.eodisp.hla.crc.omt.*;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Attribute</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AttributeImpl#getDataType <em>Data Type</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AttributeImpl#getDataTypeNotes <em>Data Type Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AttributeImpl#getDimensions <em>Dimensions</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AttributeImpl#getDimensionsNotes <em>Dimensions Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AttributeImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AttributeImpl#getNameNotes <em>Name Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AttributeImpl#getOrder <em>Order</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AttributeImpl#getOrderNotes <em>Order Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AttributeImpl#getOwnership <em>Ownership</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AttributeImpl#getOwnershipNotes <em>Ownership Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AttributeImpl#getSemantics <em>Semantics</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AttributeImpl#getSemanticsNotes <em>Semantics Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AttributeImpl#getSharing <em>Sharing</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AttributeImpl#getSharingNotes <em>Sharing Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AttributeImpl#getTransportation <em>Transportation</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AttributeImpl#getTransportationNotes <em>Transportation Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AttributeImpl#getUpdateCondition <em>Update Condition</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AttributeImpl#getUpdateConditionNotes <em>Update Condition Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AttributeImpl#getUpdateType <em>Update Type</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AttributeImpl#getUpdateTypeNotes <em>Update Type Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AttributeImpl#getSubscribingFederates <em>Subscribing Federates</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.AttributeImpl#getPublishingFederates <em>Publishing Federates</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class AttributeImpl extends EObjectImpl implements Attribute {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The default value of the '{@link #getDataType() <em>Data Type</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDataType()
	 * @generated
	 * @ordered
	 */
	protected static final String DATA_TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDataType() <em>Data Type</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDataType()
	 * @generated
	 * @ordered
	 */
	protected String dataType = DATA_TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getDataTypeNotes() <em>Data Type Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDataTypeNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List DATA_TYPE_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDataTypeNotes() <em>Data Type Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDataTypeNotes()
	 * @generated
	 * @ordered
	 */
	protected List dataTypeNotes = DATA_TYPE_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getDimensions() <em>Dimensions</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDimensions()
	 * @generated
	 * @ordered
	 */
	protected static final List DIMENSIONS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDimensions() <em>Dimensions</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDimensions()
	 * @generated
	 * @ordered
	 */
	protected List dimensions = DIMENSIONS_EDEFAULT;

	/**
	 * The default value of the '{@link #getDimensionsNotes() <em>Dimensions Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDimensionsNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List DIMENSIONS_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDimensionsNotes() <em>Dimensions Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getDimensionsNotes()
	 * @generated
	 * @ordered
	 */
	protected List dimensionsNotes = DIMENSIONS_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getNameNotes() <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getNameNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List NAME_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNameNotes() <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getNameNotes()
	 * @generated
	 * @ordered
	 */
	protected List nameNotes = NAME_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getOrder() <em>Order</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getOrder()
	 * @generated
	 * @ordered
	 */
	protected static final OrderEnum ORDER_EDEFAULT = OrderEnum.RECEIVE_LITERAL;

	/**
	 * The cached value of the '{@link #getOrder() <em>Order</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getOrder()
	 * @generated
	 * @ordered
	 */
	protected OrderEnum order = ORDER_EDEFAULT;

	/**
	 * This is true if the Order attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean orderESet = false;

	/**
	 * The default value of the '{@link #getOrderNotes() <em>Order Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getOrderNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List ORDER_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getOrderNotes() <em>Order Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getOrderNotes()
	 * @generated
	 * @ordered
	 */
	protected List orderNotes = ORDER_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getOwnership() <em>Ownership</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getOwnership()
	 * @generated
	 * @ordered
	 */
	protected static final OwnershipEnum OWNERSHIP_EDEFAULT = OwnershipEnum.DIVEST_LITERAL;

	/**
	 * The cached value of the '{@link #getOwnership() <em>Ownership</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getOwnership()
	 * @generated
	 * @ordered
	 */
	protected OwnershipEnum ownership = OWNERSHIP_EDEFAULT;

	/**
	 * This is true if the Ownership attribute has been set.
	 * <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean ownershipESet = false;

	/**
	 * The default value of the '{@link #getOwnershipNotes() <em>Ownership Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getOwnershipNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List OWNERSHIP_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getOwnershipNotes() <em>Ownership Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getOwnershipNotes()
	 * @generated
	 * @ordered
	 */
	protected List ownershipNotes = OWNERSHIP_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getSemantics() <em>Semantics</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSemantics()
	 * @generated
	 * @ordered
	 */
	protected static final Object SEMANTICS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSemantics() <em>Semantics</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSemantics()
	 * @generated
	 * @ordered
	 */
	protected Object semantics = SEMANTICS_EDEFAULT;

	/**
	 * The default value of the '{@link #getSemanticsNotes() <em>Semantics Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSemanticsNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List SEMANTICS_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSemanticsNotes() <em>Semantics Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSemanticsNotes()
	 * @generated
	 * @ordered
	 */
	protected List semanticsNotes = SEMANTICS_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getSharing() <em>Sharing</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSharing()
	 * @generated
	 * @ordered
	 */
	protected static final SharingEnum SHARING_EDEFAULT = SharingEnum.PUBLISH_LITERAL;

	/**
	 * The cached value of the '{@link #getSharing() <em>Sharing</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSharing()
	 * @generated
	 * @ordered
	 */
	protected SharingEnum sharing = SHARING_EDEFAULT;

	/**
	 * This is true if the Sharing attribute has been set.
	 * <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean sharingESet = false;

	/**
	 * The default value of the '{@link #getSharingNotes() <em>Sharing Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSharingNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List SHARING_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSharingNotes() <em>Sharing Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSharingNotes()
	 * @generated
	 * @ordered
	 */
	protected List sharingNotes = SHARING_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getTransportation() <em>Transportation</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getTransportation()
	 * @generated
	 * @ordered
	 */
	protected static final String TRANSPORTATION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTransportation() <em>Transportation</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getTransportation()
	 * @generated
	 * @ordered
	 */
	protected String transportation = TRANSPORTATION_EDEFAULT;

	/**
	 * The default value of the '{@link #getTransportationNotes() <em>Transportation Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getTransportationNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List TRANSPORTATION_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTransportationNotes() <em>Transportation Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getTransportationNotes()
	 * @generated
	 * @ordered
	 */
	protected List transportationNotes = TRANSPORTATION_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getUpdateCondition() <em>Update Condition</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getUpdateCondition()
	 * @generated
	 * @ordered
	 */
	protected static final Object UPDATE_CONDITION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getUpdateCondition() <em>Update Condition</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getUpdateCondition()
	 * @generated
	 * @ordered
	 */
	protected Object updateCondition = UPDATE_CONDITION_EDEFAULT;

	/**
	 * The default value of the '{@link #getUpdateConditionNotes() <em>Update Condition Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getUpdateConditionNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List UPDATE_CONDITION_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getUpdateConditionNotes() <em>Update Condition Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getUpdateConditionNotes()
	 * @generated
	 * @ordered
	 */
	protected List updateConditionNotes = UPDATE_CONDITION_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getUpdateType() <em>Update Type</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getUpdateType()
	 * @generated
	 * @ordered
	 */
	protected static final UpdateTypeEnum UPDATE_TYPE_EDEFAULT = UpdateTypeEnum.STATIC_LITERAL;

	/**
	 * The cached value of the '{@link #getUpdateType() <em>Update Type</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getUpdateType()
	 * @generated
	 * @ordered
	 */
	protected UpdateTypeEnum updateType = UPDATE_TYPE_EDEFAULT;

	/**
	 * This is true if the Update Type attribute has been set. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	protected boolean updateTypeESet = false;

	/**
	 * The default value of the '{@link #getUpdateTypeNotes() <em>Update Type Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getUpdateTypeNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List UPDATE_TYPE_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getUpdateTypeNotes() <em>Update Type Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getUpdateTypeNotes()
	 * @generated
	 * @ordered
	 */
	protected List updateTypeNotes = UPDATE_TYPE_NOTES_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSubscribingFederates() <em>Subscribing Federates</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSubscribingFederates()
	 * @generated
	 * @ordered
	 */
	protected EList subscribingFederates = null;

	/**
	 * The cached value of the '{@link #getPublishingFederates() <em>Publishing Federates</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPublishingFederates()
	 * @generated
	 * @ordered
	 */
	protected EList publishingFederates = null;

	/**
	 * This attribute's handle
	 */
	private AttributeHandle handle = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AttributeImpl() {
		super();
	}

	/** 
	 * {@inheritDoc}
	 */
	public AttributeHandle getHandle() {
		return handle;
	}

	public void setHandle(AttributeHandle attributeHandle) {
		this.handle = attributeHandle;
	}

	/** 
	 * {@inheritDoc}
	 */
	public ObjectClass getObjectClass() {
		return (ObjectClass) eContainer();
	}

	/** 
	 * {@inheritDoc}
	 */
	public boolean isAvailableFrom(ObjectClass objectClass) {
		return objectClass.getAllAttributes().contains(this);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return OmtPackage.Literals.ATTRIBUTE;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String getDataType() {
		return dataType;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setDataType(String newDataType) {
		String oldDataType = dataType;
		dataType = newDataType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ATTRIBUTE__DATA_TYPE,
					oldDataType,
					dataType));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getDataTypeNotes() {
		return dataTypeNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setDataTypeNotes(List newDataTypeNotes) {
		List oldDataTypeNotes = dataTypeNotes;
		dataTypeNotes = newDataTypeNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ATTRIBUTE__DATA_TYPE_NOTES,
					oldDataTypeNotes,
					dataTypeNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getDimensions() {
		return dimensions;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setDimensions(List newDimensions) {
		List oldDimensions = dimensions;
		dimensions = newDimensions;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ATTRIBUTE__DIMENSIONS,
					oldDimensions,
					dimensions));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getDimensionsNotes() {
		return dimensionsNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setDimensionsNotes(List newDimensionsNotes) {
		List oldDimensionsNotes = dimensionsNotes;
		dimensionsNotes = newDimensionsNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ATTRIBUTE__DIMENSIONS_NOTES,
					oldDimensionsNotes,
					dimensionsNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/** 
	 * {@inheritDoc}
	 * 
	 * @generated not
	 */
	public String getQualifiedName(boolean omitObjectRoot) {
		return getObjectClass().getQualifiedName(omitObjectRoot) + "." + name;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OmtPackage.ATTRIBUTE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getNameNotes() {
		return nameNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setNameNotes(List newNameNotes) {
		List oldNameNotes = nameNotes;
		nameNotes = newNameNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ATTRIBUTE__NAME_NOTES,
					oldNameNotes,
					nameNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public OrderEnum getOrder() {
		return order;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setOrder(OrderEnum newOrder) {
		OrderEnum oldOrder = order;
		order = newOrder == null ? ORDER_EDEFAULT : newOrder;
		boolean oldOrderESet = orderESet;
		orderESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ATTRIBUTE__ORDER,
					oldOrder,
					order,
					!oldOrderESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetOrder() {
		OrderEnum oldOrder = order;
		boolean oldOrderESet = orderESet;
		order = ORDER_EDEFAULT;
		orderESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.UNSET,
					OmtPackage.ATTRIBUTE__ORDER,
					oldOrder,
					ORDER_EDEFAULT,
					oldOrderESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetOrder() {
		return orderESet;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getOrderNotes() {
		return orderNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setOrderNotes(List newOrderNotes) {
		List oldOrderNotes = orderNotes;
		orderNotes = newOrderNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ATTRIBUTE__ORDER_NOTES,
					oldOrderNotes,
					orderNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public OwnershipEnum getOwnership() {
		return ownership;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setOwnership(OwnershipEnum newOwnership) {
		OwnershipEnum oldOwnership = ownership;
		ownership = newOwnership == null ? OWNERSHIP_EDEFAULT : newOwnership;
		boolean oldOwnershipESet = ownershipESet;
		ownershipESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ATTRIBUTE__OWNERSHIP,
					oldOwnership,
					ownership,
					!oldOwnershipESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetOwnership() {
		OwnershipEnum oldOwnership = ownership;
		boolean oldOwnershipESet = ownershipESet;
		ownership = OWNERSHIP_EDEFAULT;
		ownershipESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.UNSET,
					OmtPackage.ATTRIBUTE__OWNERSHIP,
					oldOwnership,
					OWNERSHIP_EDEFAULT,
					oldOwnershipESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetOwnership() {
		return ownershipESet;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getOwnershipNotes() {
		return ownershipNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setOwnershipNotes(List newOwnershipNotes) {
		List oldOwnershipNotes = ownershipNotes;
		ownershipNotes = newOwnershipNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ATTRIBUTE__OWNERSHIP_NOTES,
					oldOwnershipNotes,
					ownershipNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getSemantics() {
		return semantics;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setSemantics(Object newSemantics) {
		Object oldSemantics = semantics;
		semantics = newSemantics;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ATTRIBUTE__SEMANTICS,
					oldSemantics,
					semantics));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getSemanticsNotes() {
		return semanticsNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setSemanticsNotes(List newSemanticsNotes) {
		List oldSemanticsNotes = semanticsNotes;
		semanticsNotes = newSemanticsNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ATTRIBUTE__SEMANTICS_NOTES,
					oldSemanticsNotes,
					semanticsNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public SharingEnum getSharing() {
		return sharing;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setSharing(SharingEnum newSharing) {
		SharingEnum oldSharing = sharing;
		sharing = newSharing == null ? SHARING_EDEFAULT : newSharing;
		boolean oldSharingESet = sharingESet;
		sharingESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ATTRIBUTE__SHARING,
					oldSharing,
					sharing,
					!oldSharingESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetSharing() {
		SharingEnum oldSharing = sharing;
		boolean oldSharingESet = sharingESet;
		sharing = SHARING_EDEFAULT;
		sharingESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.UNSET,
					OmtPackage.ATTRIBUTE__SHARING,
					oldSharing,
					SHARING_EDEFAULT,
					oldSharingESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetSharing() {
		return sharingESet;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getSharingNotes() {
		return sharingNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setSharingNotes(List newSharingNotes) {
		List oldSharingNotes = sharingNotes;
		sharingNotes = newSharingNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ATTRIBUTE__SHARING_NOTES,
					oldSharingNotes,
					sharingNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String getTransportation() {
		return transportation;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setTransportation(String newTransportation) {
		String oldTransportation = transportation;
		transportation = newTransportation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ATTRIBUTE__TRANSPORTATION,
					oldTransportation,
					transportation));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getTransportationNotes() {
		return transportationNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setTransportationNotes(List newTransportationNotes) {
		List oldTransportationNotes = transportationNotes;
		transportationNotes = newTransportationNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ATTRIBUTE__TRANSPORTATION_NOTES,
					oldTransportationNotes,
					transportationNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getUpdateCondition() {
		return updateCondition;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setUpdateCondition(Object newUpdateCondition) {
		Object oldUpdateCondition = updateCondition;
		updateCondition = newUpdateCondition;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ATTRIBUTE__UPDATE_CONDITION,
					oldUpdateCondition,
					updateCondition));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getUpdateConditionNotes() {
		return updateConditionNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setUpdateConditionNotes(List newUpdateConditionNotes) {
		List oldUpdateConditionNotes = updateConditionNotes;
		updateConditionNotes = newUpdateConditionNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ATTRIBUTE__UPDATE_CONDITION_NOTES,
					oldUpdateConditionNotes,
					updateConditionNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public UpdateTypeEnum getUpdateType() {
		return updateType;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setUpdateType(UpdateTypeEnum newUpdateType) {
		UpdateTypeEnum oldUpdateType = updateType;
		updateType = newUpdateType == null ? UPDATE_TYPE_EDEFAULT : newUpdateType;
		boolean oldUpdateTypeESet = updateTypeESet;
		updateTypeESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ATTRIBUTE__UPDATE_TYPE,
					oldUpdateType,
					updateType,
					!oldUpdateTypeESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetUpdateType() {
		UpdateTypeEnum oldUpdateType = updateType;
		boolean oldUpdateTypeESet = updateTypeESet;
		updateType = UPDATE_TYPE_EDEFAULT;
		updateTypeESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.UNSET,
					OmtPackage.ATTRIBUTE__UPDATE_TYPE,
					oldUpdateType,
					UPDATE_TYPE_EDEFAULT,
					oldUpdateTypeESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetUpdateType() {
		return updateTypeESet;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getUpdateTypeNotes() {
		return updateTypeNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setUpdateTypeNotes(List newUpdateTypeNotes) {
		List oldUpdateTypeNotes = updateTypeNotes;
		updateTypeNotes = newUpdateTypeNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.ATTRIBUTE__UPDATE_TYPE_NOTES,
					oldUpdateTypeNotes,
					updateTypeNotes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getSubscribingFederates() {
		if (subscribingFederates == null) {
			subscribingFederates = new EObjectWithInverseResolvingEList.ManyInverse(
					Federate.class,
					this,
					OmtPackage.ATTRIBUTE__SUBSCRIBING_FEDERATES,
					DataPackage.FEDERATE__SUBSCRIBED_ATTRIBUTES);
		}
		return subscribingFederates;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getPublishingFederates() {
		if (publishingFederates == null) {
			publishingFederates = new EObjectWithInverseResolvingEList.ManyInverse(
					Federate.class,
					this,
					OmtPackage.ATTRIBUTE__PUBLISHING_FEDERATES,
					DataPackage.FEDERATE__PUBLISHED_ATTRIBUTES);
		}
		return publishingFederates;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case OmtPackage.ATTRIBUTE__SUBSCRIBING_FEDERATES:
			return ((InternalEList) getSubscribingFederates()).basicAdd(otherEnd, msgs);
		case OmtPackage.ATTRIBUTE__PUBLISHING_FEDERATES:
			return ((InternalEList) getPublishingFederates()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case OmtPackage.ATTRIBUTE__SUBSCRIBING_FEDERATES:
			return ((InternalEList) getSubscribingFederates()).basicRemove(otherEnd, msgs);
		case OmtPackage.ATTRIBUTE__PUBLISHING_FEDERATES:
			return ((InternalEList) getPublishingFederates()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case OmtPackage.ATTRIBUTE__DATA_TYPE:
			return getDataType();
		case OmtPackage.ATTRIBUTE__DATA_TYPE_NOTES:
			return getDataTypeNotes();
		case OmtPackage.ATTRIBUTE__DIMENSIONS:
			return getDimensions();
		case OmtPackage.ATTRIBUTE__DIMENSIONS_NOTES:
			return getDimensionsNotes();
		case OmtPackage.ATTRIBUTE__NAME:
			return getName();
		case OmtPackage.ATTRIBUTE__NAME_NOTES:
			return getNameNotes();
		case OmtPackage.ATTRIBUTE__ORDER:
			return getOrder();
		case OmtPackage.ATTRIBUTE__ORDER_NOTES:
			return getOrderNotes();
		case OmtPackage.ATTRIBUTE__OWNERSHIP:
			return getOwnership();
		case OmtPackage.ATTRIBUTE__OWNERSHIP_NOTES:
			return getOwnershipNotes();
		case OmtPackage.ATTRIBUTE__SEMANTICS:
			return getSemantics();
		case OmtPackage.ATTRIBUTE__SEMANTICS_NOTES:
			return getSemanticsNotes();
		case OmtPackage.ATTRIBUTE__SHARING:
			return getSharing();
		case OmtPackage.ATTRIBUTE__SHARING_NOTES:
			return getSharingNotes();
		case OmtPackage.ATTRIBUTE__TRANSPORTATION:
			return getTransportation();
		case OmtPackage.ATTRIBUTE__TRANSPORTATION_NOTES:
			return getTransportationNotes();
		case OmtPackage.ATTRIBUTE__UPDATE_CONDITION:
			return getUpdateCondition();
		case OmtPackage.ATTRIBUTE__UPDATE_CONDITION_NOTES:
			return getUpdateConditionNotes();
		case OmtPackage.ATTRIBUTE__UPDATE_TYPE:
			return getUpdateType();
		case OmtPackage.ATTRIBUTE__UPDATE_TYPE_NOTES:
			return getUpdateTypeNotes();
		case OmtPackage.ATTRIBUTE__SUBSCRIBING_FEDERATES:
			return getSubscribingFederates();
		case OmtPackage.ATTRIBUTE__PUBLISHING_FEDERATES:
			return getPublishingFederates();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case OmtPackage.ATTRIBUTE__DATA_TYPE:
			setDataType((String) newValue);
			return;
		case OmtPackage.ATTRIBUTE__DATA_TYPE_NOTES:
			setDataTypeNotes((List) newValue);
			return;
		case OmtPackage.ATTRIBUTE__DIMENSIONS:
			setDimensions((List) newValue);
			return;
		case OmtPackage.ATTRIBUTE__DIMENSIONS_NOTES:
			setDimensionsNotes((List) newValue);
			return;
		case OmtPackage.ATTRIBUTE__NAME:
			setName((String) newValue);
			return;
		case OmtPackage.ATTRIBUTE__NAME_NOTES:
			setNameNotes((List) newValue);
			return;
		case OmtPackage.ATTRIBUTE__ORDER:
			setOrder((OrderEnum) newValue);
			return;
		case OmtPackage.ATTRIBUTE__ORDER_NOTES:
			setOrderNotes((List) newValue);
			return;
		case OmtPackage.ATTRIBUTE__OWNERSHIP:
			setOwnership((OwnershipEnum) newValue);
			return;
		case OmtPackage.ATTRIBUTE__OWNERSHIP_NOTES:
			setOwnershipNotes((List) newValue);
			return;
		case OmtPackage.ATTRIBUTE__SEMANTICS:
			setSemantics((Object) newValue);
			return;
		case OmtPackage.ATTRIBUTE__SEMANTICS_NOTES:
			setSemanticsNotes((List) newValue);
			return;
		case OmtPackage.ATTRIBUTE__SHARING:
			setSharing((SharingEnum) newValue);
			return;
		case OmtPackage.ATTRIBUTE__SHARING_NOTES:
			setSharingNotes((List) newValue);
			return;
		case OmtPackage.ATTRIBUTE__TRANSPORTATION:
			setTransportation((String) newValue);
			return;
		case OmtPackage.ATTRIBUTE__TRANSPORTATION_NOTES:
			setTransportationNotes((List) newValue);
			return;
		case OmtPackage.ATTRIBUTE__UPDATE_CONDITION:
			setUpdateCondition((Object) newValue);
			return;
		case OmtPackage.ATTRIBUTE__UPDATE_CONDITION_NOTES:
			setUpdateConditionNotes((List) newValue);
			return;
		case OmtPackage.ATTRIBUTE__UPDATE_TYPE:
			setUpdateType((UpdateTypeEnum) newValue);
			return;
		case OmtPackage.ATTRIBUTE__UPDATE_TYPE_NOTES:
			setUpdateTypeNotes((List) newValue);
			return;
		case OmtPackage.ATTRIBUTE__SUBSCRIBING_FEDERATES:
			getSubscribingFederates().clear();
			getSubscribingFederates().addAll((Collection) newValue);
			return;
		case OmtPackage.ATTRIBUTE__PUBLISHING_FEDERATES:
			getPublishingFederates().clear();
			getPublishingFederates().addAll((Collection) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
		case OmtPackage.ATTRIBUTE__DATA_TYPE:
			setDataType(DATA_TYPE_EDEFAULT);
			return;
		case OmtPackage.ATTRIBUTE__DATA_TYPE_NOTES:
			setDataTypeNotes(DATA_TYPE_NOTES_EDEFAULT);
			return;
		case OmtPackage.ATTRIBUTE__DIMENSIONS:
			setDimensions(DIMENSIONS_EDEFAULT);
			return;
		case OmtPackage.ATTRIBUTE__DIMENSIONS_NOTES:
			setDimensionsNotes(DIMENSIONS_NOTES_EDEFAULT);
			return;
		case OmtPackage.ATTRIBUTE__NAME:
			setName(NAME_EDEFAULT);
			return;
		case OmtPackage.ATTRIBUTE__NAME_NOTES:
			setNameNotes(NAME_NOTES_EDEFAULT);
			return;
		case OmtPackage.ATTRIBUTE__ORDER:
			unsetOrder();
			return;
		case OmtPackage.ATTRIBUTE__ORDER_NOTES:
			setOrderNotes(ORDER_NOTES_EDEFAULT);
			return;
		case OmtPackage.ATTRIBUTE__OWNERSHIP:
			unsetOwnership();
			return;
		case OmtPackage.ATTRIBUTE__OWNERSHIP_NOTES:
			setOwnershipNotes(OWNERSHIP_NOTES_EDEFAULT);
			return;
		case OmtPackage.ATTRIBUTE__SEMANTICS:
			setSemantics(SEMANTICS_EDEFAULT);
			return;
		case OmtPackage.ATTRIBUTE__SEMANTICS_NOTES:
			setSemanticsNotes(SEMANTICS_NOTES_EDEFAULT);
			return;
		case OmtPackage.ATTRIBUTE__SHARING:
			unsetSharing();
			return;
		case OmtPackage.ATTRIBUTE__SHARING_NOTES:
			setSharingNotes(SHARING_NOTES_EDEFAULT);
			return;
		case OmtPackage.ATTRIBUTE__TRANSPORTATION:
			setTransportation(TRANSPORTATION_EDEFAULT);
			return;
		case OmtPackage.ATTRIBUTE__TRANSPORTATION_NOTES:
			setTransportationNotes(TRANSPORTATION_NOTES_EDEFAULT);
			return;
		case OmtPackage.ATTRIBUTE__UPDATE_CONDITION:
			setUpdateCondition(UPDATE_CONDITION_EDEFAULT);
			return;
		case OmtPackage.ATTRIBUTE__UPDATE_CONDITION_NOTES:
			setUpdateConditionNotes(UPDATE_CONDITION_NOTES_EDEFAULT);
			return;
		case OmtPackage.ATTRIBUTE__UPDATE_TYPE:
			unsetUpdateType();
			return;
		case OmtPackage.ATTRIBUTE__UPDATE_TYPE_NOTES:
			setUpdateTypeNotes(UPDATE_TYPE_NOTES_EDEFAULT);
			return;
		case OmtPackage.ATTRIBUTE__SUBSCRIBING_FEDERATES:
			getSubscribingFederates().clear();
			return;
		case OmtPackage.ATTRIBUTE__PUBLISHING_FEDERATES:
			getPublishingFederates().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case OmtPackage.ATTRIBUTE__DATA_TYPE:
			return DATA_TYPE_EDEFAULT == null ? dataType != null : !DATA_TYPE_EDEFAULT.equals(dataType);
		case OmtPackage.ATTRIBUTE__DATA_TYPE_NOTES:
			return DATA_TYPE_NOTES_EDEFAULT == null ? dataTypeNotes != null : !DATA_TYPE_NOTES_EDEFAULT
					.equals(dataTypeNotes);
		case OmtPackage.ATTRIBUTE__DIMENSIONS:
			return DIMENSIONS_EDEFAULT == null ? dimensions != null : !DIMENSIONS_EDEFAULT.equals(dimensions);
		case OmtPackage.ATTRIBUTE__DIMENSIONS_NOTES:
			return DIMENSIONS_NOTES_EDEFAULT == null ? dimensionsNotes != null : !DIMENSIONS_NOTES_EDEFAULT
					.equals(dimensionsNotes);
		case OmtPackage.ATTRIBUTE__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case OmtPackage.ATTRIBUTE__NAME_NOTES:
			return NAME_NOTES_EDEFAULT == null ? nameNotes != null : !NAME_NOTES_EDEFAULT.equals(nameNotes);
		case OmtPackage.ATTRIBUTE__ORDER:
			return isSetOrder();
		case OmtPackage.ATTRIBUTE__ORDER_NOTES:
			return ORDER_NOTES_EDEFAULT == null ? orderNotes != null : !ORDER_NOTES_EDEFAULT.equals(orderNotes);
		case OmtPackage.ATTRIBUTE__OWNERSHIP:
			return isSetOwnership();
		case OmtPackage.ATTRIBUTE__OWNERSHIP_NOTES:
			return OWNERSHIP_NOTES_EDEFAULT == null ? ownershipNotes != null : !OWNERSHIP_NOTES_EDEFAULT
					.equals(ownershipNotes);
		case OmtPackage.ATTRIBUTE__SEMANTICS:
			return SEMANTICS_EDEFAULT == null ? semantics != null : !SEMANTICS_EDEFAULT.equals(semantics);
		case OmtPackage.ATTRIBUTE__SEMANTICS_NOTES:
			return SEMANTICS_NOTES_EDEFAULT == null ? semanticsNotes != null : !SEMANTICS_NOTES_EDEFAULT
					.equals(semanticsNotes);
		case OmtPackage.ATTRIBUTE__SHARING:
			return isSetSharing();
		case OmtPackage.ATTRIBUTE__SHARING_NOTES:
			return SHARING_NOTES_EDEFAULT == null ? sharingNotes != null : !SHARING_NOTES_EDEFAULT.equals(sharingNotes);
		case OmtPackage.ATTRIBUTE__TRANSPORTATION:
			return TRANSPORTATION_EDEFAULT == null ? transportation != null : !TRANSPORTATION_EDEFAULT
					.equals(transportation);
		case OmtPackage.ATTRIBUTE__TRANSPORTATION_NOTES:
			return TRANSPORTATION_NOTES_EDEFAULT == null ? transportationNotes != null : !TRANSPORTATION_NOTES_EDEFAULT
					.equals(transportationNotes);
		case OmtPackage.ATTRIBUTE__UPDATE_CONDITION:
			return UPDATE_CONDITION_EDEFAULT == null ? updateCondition != null : !UPDATE_CONDITION_EDEFAULT
					.equals(updateCondition);
		case OmtPackage.ATTRIBUTE__UPDATE_CONDITION_NOTES:
			return UPDATE_CONDITION_NOTES_EDEFAULT == null ? updateConditionNotes != null
					: !UPDATE_CONDITION_NOTES_EDEFAULT.equals(updateConditionNotes);
		case OmtPackage.ATTRIBUTE__UPDATE_TYPE:
			return isSetUpdateType();
		case OmtPackage.ATTRIBUTE__UPDATE_TYPE_NOTES:
			return UPDATE_TYPE_NOTES_EDEFAULT == null ? updateTypeNotes != null : !UPDATE_TYPE_NOTES_EDEFAULT
					.equals(updateTypeNotes);
		case OmtPackage.ATTRIBUTE__SUBSCRIBING_FEDERATES:
			return subscribingFederates != null && !subscribingFederates.isEmpty();
		case OmtPackage.ATTRIBUTE__PUBLISHING_FEDERATES:
			return publishingFederates != null && !publishingFederates.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated not
	 */
	public String toString() {
		if (eIsProxy())
			return super.toString();
		return name;
	}

} // AttributeImpl
