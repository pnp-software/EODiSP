/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt.impl;

import java.util.List;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eodisp.hla.crc.omt.BasicData;
import org.eodisp.hla.crc.omt.EndianEnum;
import org.eodisp.hla.crc.omt.OmtPackage;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Basic Data</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.BasicDataImpl#getEncoding <em>Encoding</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.BasicDataImpl#getEncodingNotes <em>Encoding Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.BasicDataImpl#getEndian <em>Endian</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.BasicDataImpl#getEndianNotes <em>Endian Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.BasicDataImpl#getInterpretation <em>Interpretation</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.BasicDataImpl#getInterpretationNotes <em>Interpretation Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.BasicDataImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.BasicDataImpl#getNameNotes <em>Name Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.BasicDataImpl#getSize <em>Size</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.BasicDataImpl#getSizeNotes <em>Size Notes</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class BasicDataImpl extends EObjectImpl implements BasicData {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * The default value of the '{@link #getEncoding() <em>Encoding</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getEncoding()
	 * @generated
	 * @ordered
	 */
	protected static final Object ENCODING_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getEncoding() <em>Encoding</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getEncoding()
	 * @generated
	 * @ordered
	 */
	protected Object encoding = ENCODING_EDEFAULT;

	/**
	 * The default value of the '{@link #getEncodingNotes() <em>Encoding Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getEncodingNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List ENCODING_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getEncodingNotes() <em>Encoding Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getEncodingNotes()
	 * @generated
	 * @ordered
	 */
	protected List encodingNotes = ENCODING_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getEndian() <em>Endian</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getEndian()
	 * @generated
	 * @ordered
	 */
	protected static final EndianEnum ENDIAN_EDEFAULT = EndianEnum.BIG_LITERAL;

	/**
	 * The cached value of the '{@link #getEndian() <em>Endian</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getEndian()
	 * @generated
	 * @ordered
	 */
	protected EndianEnum endian = ENDIAN_EDEFAULT;

	/**
	 * This is true if the Endian attribute has been set.
	 * <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean endianESet = false;

	/**
	 * The default value of the '{@link #getEndianNotes() <em>Endian Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getEndianNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List ENDIAN_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getEndianNotes() <em>Endian Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getEndianNotes()
	 * @generated
	 * @ordered
	 */
	protected List endianNotes = ENDIAN_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getInterpretation() <em>Interpretation</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getInterpretation()
	 * @generated
	 * @ordered
	 */
	protected static final Object INTERPRETATION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getInterpretation() <em>Interpretation</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getInterpretation()
	 * @generated
	 * @ordered
	 */
	protected Object interpretation = INTERPRETATION_EDEFAULT;

	/**
	 * The default value of the '{@link #getInterpretationNotes() <em>Interpretation Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getInterpretationNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List INTERPRETATION_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getInterpretationNotes() <em>Interpretation Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getInterpretationNotes()
	 * @generated
	 * @ordered
	 */
	protected List interpretationNotes = INTERPRETATION_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getNameNotes() <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getNameNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List NAME_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNameNotes() <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getNameNotes()
	 * @generated
	 * @ordered
	 */
	protected List nameNotes = NAME_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getSize() <em>Size</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSize()
	 * @generated
	 * @ordered
	 */
	protected static final Object SIZE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSize() <em>Size</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSize()
	 * @generated
	 * @ordered
	 */
	protected Object size = SIZE_EDEFAULT;

	/**
	 * The default value of the '{@link #getSizeNotes() <em>Size Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSizeNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List SIZE_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSizeNotes() <em>Size Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSizeNotes()
	 * @generated
	 * @ordered
	 */
	protected List sizeNotes = SIZE_NOTES_EDEFAULT;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected BasicDataImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return OmtPackage.Literals.BASIC_DATA;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getEncoding() {
		return encoding;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setEncoding(Object newEncoding) {
		Object oldEncoding = encoding;
		encoding = newEncoding;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.BASIC_DATA__ENCODING,
					oldEncoding,
					encoding));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getEncodingNotes() {
		return encodingNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setEncodingNotes(List newEncodingNotes) {
		List oldEncodingNotes = encodingNotes;
		encodingNotes = newEncodingNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.BASIC_DATA__ENCODING_NOTES,
					oldEncodingNotes,
					encodingNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EndianEnum getEndian() {
		return endian;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setEndian(EndianEnum newEndian) {
		EndianEnum oldEndian = endian;
		endian = newEndian == null ? ENDIAN_EDEFAULT : newEndian;
		boolean oldEndianESet = endianESet;
		endianESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.BASIC_DATA__ENDIAN,
					oldEndian,
					endian,
					!oldEndianESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetEndian() {
		EndianEnum oldEndian = endian;
		boolean oldEndianESet = endianESet;
		endian = ENDIAN_EDEFAULT;
		endianESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.UNSET,
					OmtPackage.BASIC_DATA__ENDIAN,
					oldEndian,
					ENDIAN_EDEFAULT,
					oldEndianESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetEndian() {
		return endianESet;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getEndianNotes() {
		return endianNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setEndianNotes(List newEndianNotes) {
		List oldEndianNotes = endianNotes;
		endianNotes = newEndianNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.BASIC_DATA__ENDIAN_NOTES,
					oldEndianNotes,
					endianNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getInterpretation() {
		return interpretation;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setInterpretation(Object newInterpretation) {
		Object oldInterpretation = interpretation;
		interpretation = newInterpretation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.BASIC_DATA__INTERPRETATION,
					oldInterpretation,
					interpretation));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getInterpretationNotes() {
		return interpretationNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setInterpretationNotes(List newInterpretationNotes) {
		List oldInterpretationNotes = interpretationNotes;
		interpretationNotes = newInterpretationNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.BASIC_DATA__INTERPRETATION_NOTES,
					oldInterpretationNotes,
					interpretationNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OmtPackage.BASIC_DATA__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getNameNotes() {
		return nameNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setNameNotes(List newNameNotes) {
		List oldNameNotes = nameNotes;
		nameNotes = newNameNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.BASIC_DATA__NAME_NOTES,
					oldNameNotes,
					nameNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getSize() {
		return size;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setSize(Object newSize) {
		Object oldSize = size;
		size = newSize;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OmtPackage.BASIC_DATA__SIZE, oldSize, size));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getSizeNotes() {
		return sizeNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setSizeNotes(List newSizeNotes) {
		List oldSizeNotes = sizeNotes;
		sizeNotes = newSizeNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.BASIC_DATA__SIZE_NOTES,
					oldSizeNotes,
					sizeNotes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case OmtPackage.BASIC_DATA__ENCODING:
			return getEncoding();
		case OmtPackage.BASIC_DATA__ENCODING_NOTES:
			return getEncodingNotes();
		case OmtPackage.BASIC_DATA__ENDIAN:
			return getEndian();
		case OmtPackage.BASIC_DATA__ENDIAN_NOTES:
			return getEndianNotes();
		case OmtPackage.BASIC_DATA__INTERPRETATION:
			return getInterpretation();
		case OmtPackage.BASIC_DATA__INTERPRETATION_NOTES:
			return getInterpretationNotes();
		case OmtPackage.BASIC_DATA__NAME:
			return getName();
		case OmtPackage.BASIC_DATA__NAME_NOTES:
			return getNameNotes();
		case OmtPackage.BASIC_DATA__SIZE:
			return getSize();
		case OmtPackage.BASIC_DATA__SIZE_NOTES:
			return getSizeNotes();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case OmtPackage.BASIC_DATA__ENCODING:
			setEncoding((Object) newValue);
			return;
		case OmtPackage.BASIC_DATA__ENCODING_NOTES:
			setEncodingNotes((List) newValue);
			return;
		case OmtPackage.BASIC_DATA__ENDIAN:
			setEndian((EndianEnum) newValue);
			return;
		case OmtPackage.BASIC_DATA__ENDIAN_NOTES:
			setEndianNotes((List) newValue);
			return;
		case OmtPackage.BASIC_DATA__INTERPRETATION:
			setInterpretation((Object) newValue);
			return;
		case OmtPackage.BASIC_DATA__INTERPRETATION_NOTES:
			setInterpretationNotes((List) newValue);
			return;
		case OmtPackage.BASIC_DATA__NAME:
			setName((String) newValue);
			return;
		case OmtPackage.BASIC_DATA__NAME_NOTES:
			setNameNotes((List) newValue);
			return;
		case OmtPackage.BASIC_DATA__SIZE:
			setSize((Object) newValue);
			return;
		case OmtPackage.BASIC_DATA__SIZE_NOTES:
			setSizeNotes((List) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
		case OmtPackage.BASIC_DATA__ENCODING:
			setEncoding(ENCODING_EDEFAULT);
			return;
		case OmtPackage.BASIC_DATA__ENCODING_NOTES:
			setEncodingNotes(ENCODING_NOTES_EDEFAULT);
			return;
		case OmtPackage.BASIC_DATA__ENDIAN:
			unsetEndian();
			return;
		case OmtPackage.BASIC_DATA__ENDIAN_NOTES:
			setEndianNotes(ENDIAN_NOTES_EDEFAULT);
			return;
		case OmtPackage.BASIC_DATA__INTERPRETATION:
			setInterpretation(INTERPRETATION_EDEFAULT);
			return;
		case OmtPackage.BASIC_DATA__INTERPRETATION_NOTES:
			setInterpretationNotes(INTERPRETATION_NOTES_EDEFAULT);
			return;
		case OmtPackage.BASIC_DATA__NAME:
			setName(NAME_EDEFAULT);
			return;
		case OmtPackage.BASIC_DATA__NAME_NOTES:
			setNameNotes(NAME_NOTES_EDEFAULT);
			return;
		case OmtPackage.BASIC_DATA__SIZE:
			setSize(SIZE_EDEFAULT);
			return;
		case OmtPackage.BASIC_DATA__SIZE_NOTES:
			setSizeNotes(SIZE_NOTES_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case OmtPackage.BASIC_DATA__ENCODING:
			return ENCODING_EDEFAULT == null ? encoding != null : !ENCODING_EDEFAULT.equals(encoding);
		case OmtPackage.BASIC_DATA__ENCODING_NOTES:
			return ENCODING_NOTES_EDEFAULT == null ? encodingNotes != null : !ENCODING_NOTES_EDEFAULT
					.equals(encodingNotes);
		case OmtPackage.BASIC_DATA__ENDIAN:
			return isSetEndian();
		case OmtPackage.BASIC_DATA__ENDIAN_NOTES:
			return ENDIAN_NOTES_EDEFAULT == null ? endianNotes != null : !ENDIAN_NOTES_EDEFAULT.equals(endianNotes);
		case OmtPackage.BASIC_DATA__INTERPRETATION:
			return INTERPRETATION_EDEFAULT == null ? interpretation != null : !INTERPRETATION_EDEFAULT
					.equals(interpretation);
		case OmtPackage.BASIC_DATA__INTERPRETATION_NOTES:
			return INTERPRETATION_NOTES_EDEFAULT == null ? interpretationNotes != null : !INTERPRETATION_NOTES_EDEFAULT
					.equals(interpretationNotes);
		case OmtPackage.BASIC_DATA__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case OmtPackage.BASIC_DATA__NAME_NOTES:
			return NAME_NOTES_EDEFAULT == null ? nameNotes != null : !NAME_NOTES_EDEFAULT.equals(nameNotes);
		case OmtPackage.BASIC_DATA__SIZE:
			return SIZE_EDEFAULT == null ? size != null : !SIZE_EDEFAULT.equals(size);
		case OmtPackage.BASIC_DATA__SIZE_NOTES:
			return SIZE_NOTES_EDEFAULT == null ? sizeNotes != null : !SIZE_NOTES_EDEFAULT.equals(sizeNotes);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (encoding: ");
		result.append(encoding);
		result.append(", encodingNotes: ");
		result.append(encodingNotes);
		result.append(", endian: ");
		if (endianESet)
			result.append(endian);
		else
			result.append("<unset>");
		result.append(", endianNotes: ");
		result.append(endianNotes);
		result.append(", interpretation: ");
		result.append(interpretation);
		result.append(", interpretationNotes: ");
		result.append(interpretationNotes);
		result.append(", name: ");
		result.append(name);
		result.append(", nameNotes: ");
		result.append(nameNotes);
		result.append(", size: ");
		result.append(size);
		result.append(", sizeNotes: ");
		result.append(sizeNotes);
		result.append(')');
		return result.toString();
	}

} // BasicDataImpl
