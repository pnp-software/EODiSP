/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt.util;

import java.util.Collection;
import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;

import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.EObjectValidator;

import org.eclipse.emf.ecore.xml.type.util.XMLTypeValidator;

import org.eodisp.hla.crc.omt.*;

/**
 * <!-- begin-user-doc --> The <b>Validator</b> for the model. <!--
 * end-user-doc -->
 * @see org.eodisp.hla.crc.omt.OmtPackage
 * @generated
 */
public class OmtValidator extends EObjectValidator {
	/**
	 * The cached model package
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public static final OmtValidator INSTANCE = new OmtValidator();

	/**
	 * A constant for the {@link org.eclipse.emf.common.util.Diagnostic#getSource() source} of diagnostic {@link org.eclipse.emf.common.util.Diagnostic#getCode() codes} from this package.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see org.eclipse.emf.common.util.Diagnostic#getSource()
	 * @see org.eclipse.emf.common.util.Diagnostic#getCode()
	 * @generated
	 */
	public static final String DIAGNOSTIC_SOURCE = "org.eodisp.hla.crc.omt";

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants.
	 * <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * @generated
	 */
	private static final int GENERATED_DIAGNOSTIC_CODE_COUNT = 0;

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants in a derived class.
	 * <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * @generated
	 */
	protected static final int DIAGNOSTIC_CODE_COUNT = GENERATED_DIAGNOSTIC_CODE_COUNT;

	/**
	 * The cached base package validator.
	 * <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * @generated
	 */
	protected XMLTypeValidator xmlTypeValidator;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * @generated
	 */
	public OmtValidator() {
		super();
		xmlTypeValidator = XMLTypeValidator.INSTANCE;
	}

	/**
	 * Returns the package of this validator switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EPackage getEPackage() {
		return OmtPackage.eINSTANCE;
	}

	/**
	 * Calls <code>validateXXX</code> for the corresonding classifier of the model.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected boolean validate(int classifierID, Object value, DiagnosticChain diagnostics, Map context) {
		switch (classifierID) {
		case OmtPackage.ACQUISITION_REQUEST_TAG:
			return validateAcquisitionRequestTag((AcquisitionRequestTag) value, diagnostics, context);
		case OmtPackage.ALTERNATIVE:
			return validateAlternative((Alternative) value, diagnostics, context);
		case OmtPackage.ARRAY_DATA:
			return validateArrayData((ArrayData) value, diagnostics, context);
		case OmtPackage.ARRAY_DATA_TYPES:
			return validateArrayDataTypes((ArrayDataTypes) value, diagnostics, context);
		case OmtPackage.ATTRIBUTE:
			return validateAttribute((Attribute) value, diagnostics, context);
		case OmtPackage.BASIC_DATA:
			return validateBasicData((BasicData) value, diagnostics, context);
		case OmtPackage.BASIC_DATA_REPRESENTATIONS:
			return validateBasicDataRepresentations((BasicDataRepresentations) value, diagnostics, context);
		case OmtPackage.DATA_TYPES:
			return validateDataTypes((DataTypes) value, diagnostics, context);
		case OmtPackage.DELETE_REMOVE_TAG:
			return validateDeleteRemoveTag((DeleteRemoveTag) value, diagnostics, context);
		case OmtPackage.DIMENSION:
			return validateDimension((Dimension) value, diagnostics, context);
		case OmtPackage.DIMENSIONS:
			return validateDimensions((Dimensions) value, diagnostics, context);
		case OmtPackage.DIVESTITURE_COMPLETION_TAG:
			return validateDivestitureCompletionTag((DivestitureCompletionTag) value, diagnostics, context);
		case OmtPackage.DIVESTITURE_REQUEST_TAG:
			return validateDivestitureRequestTag((DivestitureRequestTag) value, diagnostics, context);
		case OmtPackage.DOCUMENT_ROOT:
			return validateDocumentRoot((DocumentRoot) value, diagnostics, context);
		case OmtPackage.ENUMERATED_DATA:
			return validateEnumeratedData((EnumeratedData) value, diagnostics, context);
		case OmtPackage.ENUMERATED_DATA_TYPES:
			return validateEnumeratedDataTypes((EnumeratedDataTypes) value, diagnostics, context);
		case OmtPackage.ENUMERATOR:
			return validateEnumerator((Enumerator) value, diagnostics, context);
		case OmtPackage.FIELD:
			return validateField((Field) value, diagnostics, context);
		case OmtPackage.FIXED_RECORD_DATA:
			return validateFixedRecordData((FixedRecordData) value, diagnostics, context);
		case OmtPackage.FIXED_RECORD_DATA_TYPES:
			return validateFixedRecordDataTypes((FixedRecordDataTypes) value, diagnostics, context);
		case OmtPackage.INTERACTION_CLASS:
			return validateInteractionClass((InteractionClass) value, diagnostics, context);
		case OmtPackage.INTERACTIONS:
			return validateInteractions((Interactions) value, diagnostics, context);
		case OmtPackage.LOOKAHEAD:
			return validateLookahead((Lookahead) value, diagnostics, context);
		case OmtPackage.NOTE:
			return validateNote((Note) value, diagnostics, context);
		case OmtPackage.NOTES:
			return validateNotes((Notes) value, diagnostics, context);
		case OmtPackage.OBJECT_CLASS:
			return validateObjectClass((ObjectClass) value, diagnostics, context);
		case OmtPackage.OBJECT_MODEL:
			return validateObjectModel((ObjectModel) value, diagnostics, context);
		case OmtPackage.OBJECTS:
			return validateObjects((Objects) value, diagnostics, context);
		case OmtPackage.PARAMETER:
			return validateParameter((Parameter) value, diagnostics, context);
		case OmtPackage.REQUEST_UPDATE_TAG:
			return validateRequestUpdateTag((RequestUpdateTag) value, diagnostics, context);
		case OmtPackage.SEND_RECEIVE_TAG:
			return validateSendReceiveTag((SendReceiveTag) value, diagnostics, context);
		case OmtPackage.SIMPLE_DATA:
			return validateSimpleData((SimpleData) value, diagnostics, context);
		case OmtPackage.SIMPLE_DATA_TYPES:
			return validateSimpleDataTypes((SimpleDataTypes) value, diagnostics, context);
		case OmtPackage.SWITCHES:
			return validateSwitches((Switches) value, diagnostics, context);
		case OmtPackage.SYNCHRONIZATION:
			return validateSynchronization((Synchronization) value, diagnostics, context);
		case OmtPackage.SYNCHRONIZATIONS:
			return validateSynchronizations((Synchronizations) value, diagnostics, context);
		case OmtPackage.TAGS:
			return validateTags((Tags) value, diagnostics, context);
		case OmtPackage.TIME:
			return validateTime((Time) value, diagnostics, context);
		case OmtPackage.TIME_STAMP:
			return validateTimeStamp((TimeStamp) value, diagnostics, context);
		case OmtPackage.TRANSPORTATION:
			return validateTransportation((Transportation) value, diagnostics, context);
		case OmtPackage.TRANSPORTATIONS:
			return validateTransportations((Transportations) value, diagnostics, context);
		case OmtPackage.UPDATE_REFLECT_TAG:
			return validateUpdateReflectTag((UpdateReflectTag) value, diagnostics, context);
		case OmtPackage.VARIANT_RECORD_DATA:
			return validateVariantRecordData((VariantRecordData) value, diagnostics, context);
		case OmtPackage.VARIANT_RECORD_DATA_TYPES:
			return validateVariantRecordDataTypes((VariantRecordDataTypes) value, diagnostics, context);
		case OmtPackage.ENDIAN_ENUM:
			return validateEndianEnum((Object) value, diagnostics, context);
		case OmtPackage.OBJECT_MODEL_TYPE_ENUM:
			return validateObjectModelTypeEnum((Object) value, diagnostics, context);
		case OmtPackage.ORDER_ENUM:
			return validateOrderEnum((Object) value, diagnostics, context);
		case OmtPackage.OWNERSHIP_ENUM:
			return validateOwnershipEnum((Object) value, diagnostics, context);
		case OmtPackage.SHARING_ENUM:
			return validateSharingEnum((Object) value, diagnostics, context);
		case OmtPackage.STATE_ENUM:
			return validateStateEnum((Object) value, diagnostics, context);
		case OmtPackage.SYNC_CAPABILITY_ENUM:
			return validateSyncCapabilityEnum((Object) value, diagnostics, context);
		case OmtPackage.UPDATE_TYPE_ENUM:
			return validateUpdateTypeEnum((Object) value, diagnostics, context);
		case OmtPackage.DTD_VERSION_ENUM:
			return validateDTDVersionEnum((String) value, diagnostics, context);
		case OmtPackage.ENDIAN_ENUM_OBJECT:
			return validateEndianEnumObject((EndianEnum) value, diagnostics, context);
		case OmtPackage.OBJECT_MODEL_TYPE_ENUM_OBJECT:
			return validateObjectModelTypeEnumObject((ObjectModelTypeEnum) value, diagnostics, context);
		case OmtPackage.ORDER_ENUM_OBJECT:
			return validateOrderEnumObject((OrderEnum) value, diagnostics, context);
		case OmtPackage.OWNERSHIP_ENUM_OBJECT:
			return validateOwnershipEnumObject((OwnershipEnum) value, diagnostics, context);
		case OmtPackage.SHARING_ENUM_OBJECT:
			return validateSharingEnumObject((SharingEnum) value, diagnostics, context);
		case OmtPackage.STATE_ENUM_OBJECT:
			return validateStateEnumObject((StateEnum) value, diagnostics, context);
		case OmtPackage.SYNC_CAPABILITY_ENUM_OBJECT:
			return validateSyncCapabilityEnumObject((SyncCapabilityEnum) value, diagnostics, context);
		case OmtPackage.UPDATE_TYPE_ENUM_OBJECT:
			return validateUpdateTypeEnumObject((UpdateTypeEnum) value, diagnostics, context);
		default:
			return true;
		}
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateAcquisitionRequestTag(AcquisitionRequestTag acquisitionRequestTag,
			DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(acquisitionRequestTag, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateAlternative(Alternative alternative, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(alternative, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateArrayData(ArrayData arrayData, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(arrayData, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateArrayDataTypes(ArrayDataTypes arrayDataTypes, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(arrayDataTypes, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateAttribute(Attribute attribute, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(attribute, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateBasicData(BasicData basicData, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(basicData, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateBasicDataRepresentations(BasicDataRepresentations basicDataRepresentations,
			DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(basicDataRepresentations, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDataTypes(DataTypes dataTypes, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(dataTypes, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDeleteRemoveTag(DeleteRemoveTag deleteRemoveTag, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(deleteRemoveTag, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDimension(Dimension dimension, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(dimension, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDimensions(Dimensions dimensions, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(dimensions, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDivestitureCompletionTag(DivestitureCompletionTag divestitureCompletionTag,
			DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(divestitureCompletionTag, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDivestitureRequestTag(DivestitureRequestTag divestitureRequestTag,
			DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(divestitureRequestTag, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDocumentRoot(DocumentRoot documentRoot, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(documentRoot, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEnumeratedData(EnumeratedData enumeratedData, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(enumeratedData, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEnumeratedDataTypes(EnumeratedDataTypes enumeratedDataTypes, DiagnosticChain diagnostics,
			Map context) {
		return validate_EveryDefaultConstraint(enumeratedDataTypes, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEnumerator(Enumerator enumerator, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(enumerator, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateField(Field field, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(field, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateFixedRecordData(FixedRecordData fixedRecordData, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(fixedRecordData, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateFixedRecordDataTypes(FixedRecordDataTypes fixedRecordDataTypes, DiagnosticChain diagnostics,
			Map context) {
		return validate_EveryDefaultConstraint(fixedRecordDataTypes, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateInteractionClass(InteractionClass interactionClass, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(interactionClass, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateInteractions(Interactions interactions, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(interactions, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateLookahead(Lookahead lookahead, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(lookahead, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateNote(Note note, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(note, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateNotes(Notes notes, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(notes, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateObjectClass(ObjectClass objectClass, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(objectClass, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateObjectModel(ObjectModel objectModel, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(objectModel, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateObjects(Objects objects, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(objects, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateParameter(Parameter parameter, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(parameter, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateRequestUpdateTag(RequestUpdateTag requestUpdateTag, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(requestUpdateTag, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSendReceiveTag(SendReceiveTag sendReceiveTag, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(sendReceiveTag, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSimpleData(SimpleData simpleData, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(simpleData, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSimpleDataTypes(SimpleDataTypes simpleDataTypes, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(simpleDataTypes, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSwitches(Switches switches, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(switches, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSynchronization(Synchronization synchronization, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(synchronization, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSynchronizations(Synchronizations synchronizations, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(synchronizations, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTags(Tags tags, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(tags, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTime(Time time, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(time, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTimeStamp(TimeStamp timeStamp, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(timeStamp, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTransportation(Transportation transportation, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(transportation, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTransportations(Transportations transportations, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(transportations, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateUpdateReflectTag(UpdateReflectTag updateReflectTag, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(updateReflectTag, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateVariantRecordData(VariantRecordData variantRecordData, DiagnosticChain diagnostics,
			Map context) {
		return validate_EveryDefaultConstraint(variantRecordData, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateVariantRecordDataTypes(VariantRecordDataTypes variantRecordDataTypes,
			DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(variantRecordDataTypes, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEndianEnum(Object endianEnum, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateObjectModelTypeEnum(Object objectModelTypeEnum, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateOrderEnum(Object orderEnum, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateOwnershipEnum(Object ownershipEnum, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSharingEnum(Object sharingEnum, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateStateEnum(Object stateEnum, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSyncCapabilityEnum(Object syncCapabilityEnum, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateUpdateTypeEnum(Object updateTypeEnum, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDTDVersionEnum(String dtdVersionEnum, DiagnosticChain diagnostics, Map context) {
		boolean result = validateDTDVersionEnum_Enumeration(dtdVersionEnum, diagnostics, context);
		return result;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 * @see #validateDTDVersionEnum_Enumeration
	 */
	public static final Collection DTD_VERSION_ENUM__ENUMERATION__VALUES = wrapEnumerationValues(new Object[] { "1516.2" });

	/**
	 * Validates the Enumeration constraint of '<em>DTD Version Enum</em>'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDTDVersionEnum_Enumeration(String dtdVersionEnum, DiagnosticChain diagnostics, Map context) {
		boolean result = DTD_VERSION_ENUM__ENUMERATION__VALUES.contains(dtdVersionEnum);
		if (!result && diagnostics != null)
			reportEnumerationViolation(
					OmtPackage.eINSTANCE.getDTDVersionEnum(),
					dtdVersionEnum,
					DTD_VERSION_ENUM__ENUMERATION__VALUES,
					diagnostics,
					context);
		return result;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEndianEnumObject(EndianEnum endianEnumObject, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateObjectModelTypeEnumObject(ObjectModelTypeEnum objectModelTypeEnumObject,
			DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateOrderEnumObject(OrderEnum orderEnumObject, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateOwnershipEnumObject(OwnershipEnum ownershipEnumObject, DiagnosticChain diagnostics,
			Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSharingEnumObject(SharingEnum sharingEnumObject, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateStateEnumObject(StateEnum stateEnumObject, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSyncCapabilityEnumObject(SyncCapabilityEnum syncCapabilityEnumObject,
			DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateUpdateTypeEnumObject(UpdateTypeEnum updateTypeEnumObject, DiagnosticChain diagnostics,
			Map context) {
		return true;
	}

} // OmtValidator
