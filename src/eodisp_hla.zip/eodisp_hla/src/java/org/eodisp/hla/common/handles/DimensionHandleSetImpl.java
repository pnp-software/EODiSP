package org.eodisp.hla.common.handles;

import hla.rti1516.DimensionHandle;
import hla.rti1516.DimensionHandleSet;

import java.util.Collection;
import java.util.HashSet;

public class DimensionHandleSetImpl extends HashSet implements
		DimensionHandleSet {

	protected DimensionHandleSetImpl() {
		super();
	}

	public boolean add(Object o) {
		if (!(o instanceof DimensionHandle)) {
			throw new IllegalArgumentException("object must be DimensionHandle");
		}

		return super.add(o);
	}

	public boolean remove(Object o) {
		if (!(o instanceof DimensionHandle)) {
			throw new IllegalArgumentException("object must be DimensionHandle");
		}

		return super.remove(o);
	}

	public boolean addAll(Collection c) {
		if (!(c instanceof DimensionHandleSet)) {
			throw new IllegalArgumentException(
					"collection must be DimensionHandleSet");
		}

		return super.addAll(c);
	}

	public boolean removeAll(Collection c) {
		if (!(c instanceof DimensionHandleSet)) {
			throw new IllegalArgumentException(
					"collection must be DimensionHandleSet");
		}

		return super.removeAll(c);
	}

	public boolean retainAll(Collection c) {
		if (!(c instanceof DimensionHandleSet)) {
			throw new IllegalArgumentException(
					"collection must be DimensionHandleSet");
		}

		return super.retainAll(c);
	}
}
