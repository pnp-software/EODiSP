/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt.impl;

import hla.rti1516.ObjectClassHandle;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.log4j.Logger;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;
import org.eodisp.hla.crc.omt.Attribute;
import org.eodisp.hla.crc.omt.ObjectClass;
import org.eodisp.hla.crc.omt.OmtPackage;
import org.eodisp.hla.crc.omt.SharingEnum;

import org.eodisp.hla.crc.omt.*;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Object Class</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectClassImpl#getAttributes <em>Attributes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectClassImpl#getSubClasses <em>Sub Classes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectClassImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectClassImpl#getNameNotes <em>Name Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectClassImpl#getSemantics <em>Semantics</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectClassImpl#getSemanticsNotes <em>Semantics Notes</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectClassImpl#getSharing <em>Sharing</em>}</li>
 *   <li>{@link org.eodisp.hla.crc.omt.impl.ObjectClassImpl#getSharingNotes <em>Sharing Notes</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ObjectClassImpl extends EObjectImpl implements ObjectClass {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * Log4J logger for this class
	 * @hidden
	 */
	static Logger logger = Logger.getLogger(ObjectClassImpl.class);

	/**
	 * The cached value of the '{@link #getAttributes() <em>Attributes</em>}' containment reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getAttributes()
	 * @generated
	 * @ordered
	 */
	protected EList attributes = null;

	/**
	 * The cached value of the '{@link #getSubClasses() <em>Sub Classes</em>}' containment reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSubClasses()
	 * @generated
	 * @ordered
	 */
	protected EList subClasses = null;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getNameNotes() <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getNameNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List NAME_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNameNotes() <em>Name Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getNameNotes()
	 * @generated
	 * @ordered
	 */
	protected List nameNotes = NAME_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getSemantics() <em>Semantics</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSemantics()
	 * @generated
	 * @ordered
	 */
	protected static final Object SEMANTICS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSemantics() <em>Semantics</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSemantics()
	 * @generated
	 * @ordered
	 */
	protected Object semantics = SEMANTICS_EDEFAULT;

	/**
	 * The default value of the '{@link #getSemanticsNotes() <em>Semantics Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSemanticsNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List SEMANTICS_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSemanticsNotes() <em>Semantics Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSemanticsNotes()
	 * @generated
	 * @ordered
	 */
	protected List semanticsNotes = SEMANTICS_NOTES_EDEFAULT;

	/**
	 * The default value of the '{@link #getSharing() <em>Sharing</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSharing()
	 * @generated
	 * @ordered
	 */
	protected static final SharingEnum SHARING_EDEFAULT = SharingEnum.PUBLISH_LITERAL;

	/**
	 * The cached value of the '{@link #getSharing() <em>Sharing</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSharing()
	 * @generated
	 * @ordered
	 */
	protected SharingEnum sharing = SHARING_EDEFAULT;

	/**
	 * This is true if the Sharing attribute has been set.
	 * <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean sharingESet = false;

	/**
	 * The default value of the '{@link #getSharingNotes() <em>Sharing Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSharingNotes()
	 * @generated
	 * @ordered
	 */
	protected static final List SHARING_NOTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSharingNotes() <em>Sharing Notes</em>}' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @see #getSharingNotes()
	 * @generated
	 * @ordered
	 */
	protected List sharingNotes = SHARING_NOTES_EDEFAULT;

	/**
	 * This object class's handle
	 */
	private ObjectClassHandle handle = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected ObjectClassImpl() {
		super();
	}

	/** 
	 * {@inheritDoc}
	 */
	public ObjectClassHandle getHandle() {
		return handle;
	}

	/** 
	 * {@inheritDoc}
	 */
	public void setHandle(ObjectClassHandle objectClassHandle) {
		this.handle = objectClassHandle;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return OmtPackage.Literals.OBJECT_CLASS;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EList getAttributes() {
		if (attributes == null) {
			attributes = new EObjectContainmentEList(Attribute.class, this, OmtPackage.OBJECT_CLASS__ATTRIBUTES);
		}
		return attributes;
	}

	/** 
	 * {@inheritDoc}
	 */
	public List getAllAttributes() {
		List allAttributes = new ArrayList();
		ObjectClass parent = this;
		while (parent != null) {
			allAttributes.addAll(parent.getAttributes());
			parent = parent.getSuperClass();
		}
		return allAttributes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public EList getSubClasses() {
		if (subClasses == null) {
			subClasses = new EObjectContainmentEList(ObjectClass.class, this, OmtPackage.OBJECT_CLASS__SUB_CLASSES);
		}
		return subClasses;
	}

	/** 
	 * {@inheritDoc}
	 */
	public ObjectClass getSuperClass() {
		if (eContainer instanceof ObjectClass) {
			return (ObjectClass) eContainer();
		}
		return null;
	}

	/** 
	 * {@inheritDoc}
	 */
	public List<ObjectClass> getAllSuperClasses() {
		List<ObjectClass> allSuperClasses = new ArrayList<ObjectClass>();
		ObjectClass superClass = getSuperClass();
		while (superClass != null) {
			allSuperClasses.add(0, superClass);
			superClass = superClass.getSuperClass();
		}
		return allSuperClasses;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/** 
	 * {@inheritDoc}
	 */
	public String getQualifiedName(boolean omitObjectRoot) {
		StringBuilder builder = new StringBuilder();
		List<ObjectClass> allSuperClasses = getAllSuperClasses();
		allSuperClasses.add(this);

		int index = 0;
		if (omitObjectRoot) {
			index = 1;
		}
		for (; index < allSuperClasses.size(); index++) {
			builder.append(allSuperClasses.get(index).getName());
			if ((index + 1) < allSuperClasses.size()) {
				builder.append(".");
			}
		}
		return builder.toString();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OmtPackage.OBJECT_CLASS__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getNameNotes() {
		return nameNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setNameNotes(List newNameNotes) {
		List oldNameNotes = nameNotes;
		nameNotes = newNameNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_CLASS__NAME_NOTES,
					oldNameNotes,
					nameNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public Object getSemantics() {
		return semantics;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setSemantics(Object newSemantics) {
		Object oldSemantics = semantics;
		semantics = newSemantics;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_CLASS__SEMANTICS,
					oldSemantics,
					semantics));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getSemanticsNotes() {
		return semanticsNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setSemanticsNotes(List newSemanticsNotes) {
		List oldSemanticsNotes = semanticsNotes;
		semanticsNotes = newSemanticsNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_CLASS__SEMANTICS_NOTES,
					oldSemanticsNotes,
					semanticsNotes));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public SharingEnum getSharing() {
		return sharing;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setSharing(SharingEnum newSharing) {
		SharingEnum oldSharing = sharing;
		sharing = newSharing == null ? SHARING_EDEFAULT : newSharing;
		boolean oldSharingESet = sharingESet;
		sharingESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_CLASS__SHARING,
					oldSharing,
					sharing,
					!oldSharingESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetSharing() {
		SharingEnum oldSharing = sharing;
		boolean oldSharingESet = sharingESet;
		sharing = SHARING_EDEFAULT;
		sharingESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.UNSET,
					OmtPackage.OBJECT_CLASS__SHARING,
					oldSharing,
					SHARING_EDEFAULT,
					oldSharingESet));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetSharing() {
		return sharingESet;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public List getSharingNotes() {
		return sharingNotes;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
	public void setSharingNotes(List newSharingNotes) {
		List oldSharingNotes = sharingNotes;
		sharingNotes = newSharingNotes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(
					this,
					Notification.SET,
					OmtPackage.OBJECT_CLASS__SHARING_NOTES,
					oldSharingNotes,
					sharingNotes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case OmtPackage.OBJECT_CLASS__ATTRIBUTES:
			return ((InternalEList) getAttributes()).basicRemove(otherEnd, msgs);
		case OmtPackage.OBJECT_CLASS__SUB_CLASSES:
			return ((InternalEList) getSubClasses()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case OmtPackage.OBJECT_CLASS__ATTRIBUTES:
			return getAttributes();
		case OmtPackage.OBJECT_CLASS__SUB_CLASSES:
			return getSubClasses();
		case OmtPackage.OBJECT_CLASS__NAME:
			return getName();
		case OmtPackage.OBJECT_CLASS__NAME_NOTES:
			return getNameNotes();
		case OmtPackage.OBJECT_CLASS__SEMANTICS:
			return getSemantics();
		case OmtPackage.OBJECT_CLASS__SEMANTICS_NOTES:
			return getSemanticsNotes();
		case OmtPackage.OBJECT_CLASS__SHARING:
			return getSharing();
		case OmtPackage.OBJECT_CLASS__SHARING_NOTES:
			return getSharingNotes();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case OmtPackage.OBJECT_CLASS__ATTRIBUTES:
			getAttributes().clear();
			getAttributes().addAll((Collection) newValue);
			return;
		case OmtPackage.OBJECT_CLASS__SUB_CLASSES:
			getSubClasses().clear();
			getSubClasses().addAll((Collection) newValue);
			return;
		case OmtPackage.OBJECT_CLASS__NAME:
			setName((String) newValue);
			return;
		case OmtPackage.OBJECT_CLASS__NAME_NOTES:
			setNameNotes((List) newValue);
			return;
		case OmtPackage.OBJECT_CLASS__SEMANTICS:
			setSemantics((Object) newValue);
			return;
		case OmtPackage.OBJECT_CLASS__SEMANTICS_NOTES:
			setSemanticsNotes((List) newValue);
			return;
		case OmtPackage.OBJECT_CLASS__SHARING:
			setSharing((SharingEnum) newValue);
			return;
		case OmtPackage.OBJECT_CLASS__SHARING_NOTES:
			setSharingNotes((List) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
		case OmtPackage.OBJECT_CLASS__ATTRIBUTES:
			getAttributes().clear();
			return;
		case OmtPackage.OBJECT_CLASS__SUB_CLASSES:
			getSubClasses().clear();
			return;
		case OmtPackage.OBJECT_CLASS__NAME:
			setName(NAME_EDEFAULT);
			return;
		case OmtPackage.OBJECT_CLASS__NAME_NOTES:
			setNameNotes(NAME_NOTES_EDEFAULT);
			return;
		case OmtPackage.OBJECT_CLASS__SEMANTICS:
			setSemantics(SEMANTICS_EDEFAULT);
			return;
		case OmtPackage.OBJECT_CLASS__SEMANTICS_NOTES:
			setSemanticsNotes(SEMANTICS_NOTES_EDEFAULT);
			return;
		case OmtPackage.OBJECT_CLASS__SHARING:
			unsetSharing();
			return;
		case OmtPackage.OBJECT_CLASS__SHARING_NOTES:
			setSharingNotes(SHARING_NOTES_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case OmtPackage.OBJECT_CLASS__ATTRIBUTES:
			return attributes != null && !attributes.isEmpty();
		case OmtPackage.OBJECT_CLASS__SUB_CLASSES:
			return subClasses != null && !subClasses.isEmpty();
		case OmtPackage.OBJECT_CLASS__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case OmtPackage.OBJECT_CLASS__NAME_NOTES:
			return NAME_NOTES_EDEFAULT == null ? nameNotes != null : !NAME_NOTES_EDEFAULT.equals(nameNotes);
		case OmtPackage.OBJECT_CLASS__SEMANTICS:
			return SEMANTICS_EDEFAULT == null ? semantics != null : !SEMANTICS_EDEFAULT.equals(semantics);
		case OmtPackage.OBJECT_CLASS__SEMANTICS_NOTES:
			return SEMANTICS_NOTES_EDEFAULT == null ? semanticsNotes != null : !SEMANTICS_NOTES_EDEFAULT
					.equals(semanticsNotes);
		case OmtPackage.OBJECT_CLASS__SHARING:
			return isSetSharing();
		case OmtPackage.OBJECT_CLASS__SHARING_NOTES:
			return SHARING_NOTES_EDEFAULT == null ? sharingNotes != null : !SHARING_NOTES_EDEFAULT.equals(sharingNotes);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated not
	 */
	public String toString() {
		if (eIsProxy())
			return super.toString();

		return getQualifiedName(true);
	}

} // ObjectClassImpl
