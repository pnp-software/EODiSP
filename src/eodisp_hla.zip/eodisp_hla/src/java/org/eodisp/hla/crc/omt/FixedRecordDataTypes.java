/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.hla.crc.omt;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Fixed Record Data Types</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.hla.crc.omt.FixedRecordDataTypes#getFixedRecordData <em>Fixed Record Data</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eodisp.hla.crc.omt.OmtPackage#getFixedRecordDataTypes()
 * @model extendedMetaData="name='FixedRecordDataTypes' kind='elementOnly'"
 * @generated
 */
public interface FixedRecordDataTypes extends EObject {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright (C) 2005, 2006  P&P Software GmbH";

	/**
	 * Returns the value of the '<em><b>Fixed Record Data</b></em>' containment reference list.
	 * The list contents are of type {@link org.eodisp.hla.crc.omt.FixedRecordData}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Fixed Record Data</em>' containment
	 * reference list isn't clear, there really should be more of a description
	 * here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Fixed Record Data</em>' containment reference list.
	 * @see org.eodisp.hla.crc.omt.OmtPackage#getFixedRecordDataTypes_FixedRecordData()
	 * @model type="org.eodisp.hla.crc.omt.FixedRecordData" containment="true" required="true"
	 *        extendedMetaData="kind='element' name='fixedRecordData' namespace='##targetNamespace'"
	 * @generated
	 */
	EList getFixedRecordData();

} // FixedRecordDataTypes
