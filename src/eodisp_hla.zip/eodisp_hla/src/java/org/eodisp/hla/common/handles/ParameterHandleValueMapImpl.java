package org.eodisp.hla.common.handles;

import hla.rti1516.ParameterHandle;
import hla.rti1516.ParameterHandleValueMap;

import java.util.HashMap;
import java.util.Map;

public class ParameterHandleValueMapImpl extends HashMap implements
		ParameterHandleValueMap {

	protected ParameterHandleValueMapImpl(int capacity) {
		super(capacity);
	}

	public Object put(Object key, Object value) {
		if (!(key instanceof ParameterHandle)) {
			throw new IllegalArgumentException("key must be ParameterHandle");
		} else if (!(value instanceof byte[])) {
			throw new IllegalArgumentException("value must be byte[]");
		}

		return super.put(key, value);
	}

	public void putAll(Map t) {
		if (!(t instanceof ParameterHandleValueMap)) {
			throw new IllegalArgumentException(
					"map must be ParameterHandleValueMap");
		}

		super.putAll(t);
	}

	public Object remove(Object key) {
		if (!(key instanceof ParameterHandle)) {
			throw new IllegalArgumentException("key must be ParameterHandle");
		}

		return super.remove(key);
	}
}
