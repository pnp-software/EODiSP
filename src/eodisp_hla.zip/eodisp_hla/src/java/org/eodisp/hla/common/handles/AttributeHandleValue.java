package org.eodisp.hla.common.handles;

import hla.rti1516.AttributeHandleValueMap;

import java.util.HashMap;

public class AttributeHandleValue extends HashMap implements
		AttributeHandleValueMap {

}
