/**
 * 
 */
package org.eodisp.hla.common.handles;

import hla.rti1516.FederateHandle;

/**
 * A federation execution wide federate handle.
 * 
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class FederateHandleImpl extends HandleImpl implements FederateHandle {
	private static final long serialVersionUID = 1L;

	/**
	 * {@inheritDoc}
	 */
	public FederateHandleImpl(int id) {
		super(id);
	}
}
