package org.eodisp.hla.common.handles;

import hla.rti1516.FederateHandleSet;
import hla.rti1516.FederateHandleSetFactory;

/**
 * A factory for <code>FederateHandleSet</code> instances.
 * 
 * @author Andrzej Kapolka
 */

public class FederateHandleSetFactoryImpl implements FederateHandleSetFactory {
	/**
	 * Creates and returns a new <code>FederateHandleSet</code>.
	 * 
	 * @return the newly created <code>FederateHandleSet</code>
	 */
	public FederateHandleSet create() {
		return new FederateHandleSetImpl();
	}
}
