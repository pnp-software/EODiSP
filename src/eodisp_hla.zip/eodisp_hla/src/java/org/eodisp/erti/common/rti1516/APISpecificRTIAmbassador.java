/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com/
 *  mail: info@pnp-software.com
 */
package org.eodisp.erti.common.rti1516;

import hla.rti1516.*;

import org.eodisp.hla.common.handles.*;



/**
 * Implements the Java API specific interface of the HLA Federate Interface
 * Specification. It is both used on the server (RTI) and on the client side
 * (Federate). It does not have an internal state and only returns statically
 * created factory instances. Please see the <i>IEEE Std 1516.1-2000 document</i>
 * for a detailed description of the methods implemented in this class (No
 * Javadoc available).
 * 
 * @author ibirrer
 * @version $Id: APISpecificRTIAmbassador.java 2245 2006-06-07 08:23:53Z ibirrer $
 */
public abstract class APISpecificRTIAmbassador implements RTIambassador {

	/* Handle Factories */
	private static AttributeHandleFactory attributeHandleFactory = new AttributeHandleFactoryImpl();

	private static DimensionHandleFactory dimensionHandleFactory = new DimensionHandleFactoryImpl();

	private static InteractionClassHandleFactory interactionClassHandleFactory = new InteractionClassHandleFactoryImpl();

	private static ObjectClassHandleFactory objectClassHandleFactory = new ObjectClassHandleFactoryImpl();

	private static FederateHandleFactory federateHandleFactory = new FederateHandleFactoryImpl();

	private static ObjectInstanceHandleFactory objectInstanceHandleFactory = new ObjectInstanceHandleFactoryImpl();

	private static ParameterHandleFactory parameterHandleFactory = new ParameterHandleFactoryImpl();

	/* List/Set/Map factories */
	private static AttributeHandleValueMapFactory attributeHandleValueMapFactory = new AttributeHandleValueMapFactoryImpl();

	private static AttributeHandleSetFactory attributeHandleSetFactory = new AttributeHandleSetFactoryImpl();

	private static AttributeSetRegionSetPairListFactory attributeSetRegionSetPairListFactory = new AttributeSetRegionSetPairListFactoryImpl();

	private static DimensionHandleSetFactory dimensionHandleSetFactory = new DimensionHandleSetFactoryImpl();

	private static FederateHandleSetFactory federateHandleSetFactory = new FederateHandleSetFactoryImpl();

	private static ParameterHandleValueMapFactory parameterHandleValueMapFactory = new ParameterHandleValueMapFactoryImpl();

	private static RegionHandleSetFactory regionHandleSetFactory = new RegionHandleSetFactoryImpl();

	/*
	 * (non-Javadoc)
	 * 
	 * @see hla.rti.RTIambassador#getAttributeHandleFactory()
	 */
	public AttributeHandleFactory getAttributeHandleFactory() {
		return attributeHandleFactory;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see hla.rti.RTIambassador#getAttributeHandleSetFactory()
	 */
	public AttributeHandleSetFactory getAttributeHandleSetFactory() {
		return attributeHandleSetFactory;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see hla.rti.RTIambassador#getAttributeHandleValueMapFactory()
	 */
	public AttributeHandleValueMapFactory getAttributeHandleValueMapFactory() {
		return attributeHandleValueMapFactory;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see hla.rti.RTIambassador#getAttributeSetRegionSetPairListFactory()
	 */
	public AttributeSetRegionSetPairListFactory getAttributeSetRegionSetPairListFactory() {
		return attributeSetRegionSetPairListFactory;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see hla.rti.RTIambassador#getDimensionHandleFactory()
	 */
	public DimensionHandleFactory getDimensionHandleFactory() {
		return dimensionHandleFactory;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see hla.rti.RTIambassador#getDimensionHandleSetFactory()
	 */
	public DimensionHandleSetFactory getDimensionHandleSetFactory() {
		return dimensionHandleSetFactory;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see hla.rti.RTIambassador#getFederateHandleFactory()
	 */
	public FederateHandleFactory getFederateHandleFactory() {
		return federateHandleFactory;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see hla.rti.RTIambassador#getFederateHandleSetFactory()
	 */
	public FederateHandleSetFactory getFederateHandleSetFactory() {
		return federateHandleSetFactory;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see hla.rti.RTIambassador#getHLAversion()
	 */
	public String getHLAversion() {
		return "1516.1";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see hla.rti.RTIambassador#getInteractionClassHandleFactory()
	 */
	public InteractionClassHandleFactory getInteractionClassHandleFactory() {
		return interactionClassHandleFactory;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see hla.rti.RTIambassador#getObjectClassHandleFactory()
	 */
	public ObjectClassHandleFactory getObjectClassHandleFactory() {
		return objectClassHandleFactory;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see hla.rti.RTIambassador#getObjectInstanceHandleFactory()
	 */
	public ObjectInstanceHandleFactory getObjectInstanceHandleFactory() {
		return objectInstanceHandleFactory;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see hla.rti.RTIambassador#getParameterHandleFactory()
	 */
	public ParameterHandleFactory getParameterHandleFactory() {
		return parameterHandleFactory;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see hla.rti.RTIambassador#getParameterHandleValueMapFactory()
	 */
	public ParameterHandleValueMapFactory getParameterHandleValueMapFactory() {
		return parameterHandleValueMapFactory;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see hla.rti.RTIambassador#getRegionHandleSetFactory()
	 */
	public RegionHandleSetFactory getRegionHandleSetFactory() {
		return regionHandleSetFactory;
	}
}
