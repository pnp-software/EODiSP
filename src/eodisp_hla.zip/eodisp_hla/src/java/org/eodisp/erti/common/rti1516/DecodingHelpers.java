package org.eodisp.erti.common.rti1516;

import hla.rti1516.*;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.channels.FileChannel;

/**
 * Utility methods for encoding and decoding basic types, modeled after those
 * supplied with the DMSO RTI.
 * 
 * This class is mostly undocumented as it was directly copied from the XRTI
 * implementation. It is planned to completely re-implement the decoding helpers,
 * so no effort is being done to document this class.
 * 
 * @author Andrzej Kapolka
 */

public class DecodingHelpers {
	private static final RTIambassador rtiAmbassador = new APISpecificRTIAmbassador() {

		public void createFederationExecution(String federationExecutionName, URL fdd)
				throws FederationExecutionAlreadyExists, CouldNotOpenFDD, ErrorReadingFDD, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void destroyFederationExecution(String federationExecutionName) throws FederatesCurrentlyJoined,
				FederationExecutionDoesNotExist, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public FederateHandle joinFederationExecution(String federateType, String federationExecutionName,
				FederateAmbassador federateReference, MobileFederateServices serviceReferences)
				throws FederateAlreadyExecutionMember, FederationExecutionDoesNotExist, SaveInProgress,
				RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public void resignFederationExecution(ResignAction resignAction) throws OwnershipAcquisitionPending,
				FederateOwnsAttributes, FederateNotExecutionMember, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void registerFederationSynchronizationPoint(String synchronizationPointLabel, byte[] userSuppliedTag)
				throws FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void registerFederationSynchronizationPoint(String synchronizationPointLabel, byte[] userSuppliedTag,
				FederateHandleSet synchronizationSet) throws FederateNotExecutionMember, SaveInProgress,
				RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void synchronizationPointAchieved(String synchronizationPointLabel)
				throws SynchronizationPointLabelNotAnnounced, FederateNotExecutionMember, SaveInProgress,
				RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void requestFederationSave(String label) throws FederateNotExecutionMember, SaveInProgress,
				RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void requestFederationSave(String label, LogicalTime theTime) throws LogicalTimeAlreadyPassed,
				InvalidLogicalTime, FederateUnableToUseTime, FederateNotExecutionMember, SaveInProgress,
				RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void federateSaveBegun() throws SaveNotInitiated, FederateNotExecutionMember, RestoreInProgress,
				RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void federateSaveComplete() throws FederateHasNotBegunSave, FederateNotExecutionMember,
				RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void federateSaveNotComplete() throws FederateHasNotBegunSave, FederateNotExecutionMember,
				RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void queryFederationSaveStatus() throws FederateNotExecutionMember, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void requestFederationRestore(String label) throws FederateNotExecutionMember, SaveInProgress,
				RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void federateRestoreComplete() throws RestoreNotRequested, FederateNotExecutionMember, SaveInProgress,
				RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void federateRestoreNotComplete() throws RestoreNotRequested, FederateNotExecutionMember,
				SaveInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void queryFederationRestoreStatus() throws FederateNotExecutionMember, SaveInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void publishObjectClassAttributes(ObjectClassHandle theClass, AttributeHandleSet attributeList)
				throws ObjectClassNotDefined, AttributeNotDefined, FederateNotExecutionMember, SaveInProgress,
				RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void unpublishObjectClass(ObjectClassHandle theClass) throws ObjectClassNotDefined,
				OwnershipAcquisitionPending, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
				RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void unpublishObjectClassAttributes(ObjectClassHandle theClass, AttributeHandleSet attributeList)
				throws ObjectClassNotDefined, AttributeNotDefined, OwnershipAcquisitionPending,
				FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void publishInteractionClass(InteractionClassHandle theInteraction) throws InteractionClassNotDefined,
				FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void unpublishInteractionClass(InteractionClassHandle theInteraction) throws InteractionClassNotDefined,
				FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void subscribeObjectClassAttributes(ObjectClassHandle theClass, AttributeHandleSet attributeList)
				throws ObjectClassNotDefined, AttributeNotDefined, FederateNotExecutionMember, SaveInProgress,
				RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void subscribeObjectClassAttributesPassively(ObjectClassHandle theClass, AttributeHandleSet attributeList)
				throws ObjectClassNotDefined, AttributeNotDefined, FederateNotExecutionMember, SaveInProgress,
				RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void unsubscribeObjectClass(ObjectClassHandle theClass) throws ObjectClassNotDefined,
				FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void unsubscribeObjectClassAttributes(ObjectClassHandle theClass, AttributeHandleSet attributeList)
				throws ObjectClassNotDefined, AttributeNotDefined, FederateNotExecutionMember, SaveInProgress,
				RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void subscribeInteractionClass(InteractionClassHandle theClass) throws InteractionClassNotDefined,
				FederateServiceInvocationsAreBeingReportedViaMOM, FederateNotExecutionMember, SaveInProgress,
				RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void subscribeInteractionClassPassively(InteractionClassHandle theClass)
				throws InteractionClassNotDefined, FederateServiceInvocationsAreBeingReportedViaMOM,
				FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void unsubscribeInteractionClass(InteractionClassHandle theClass) throws InteractionClassNotDefined,
				FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void reserveObjectInstanceName(String theObjectName) throws IllegalName, FederateNotExecutionMember,
				SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public ObjectInstanceHandle registerObjectInstance(ObjectClassHandle theClass) throws ObjectClassNotDefined,
				ObjectClassNotPublished, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
				RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public ObjectInstanceHandle registerObjectInstance(ObjectClassHandle theClass, String theObjectName)
				throws ObjectClassNotDefined, ObjectClassNotPublished, ObjectInstanceNameNotReserved,
				ObjectInstanceNameInUse, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
				RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public void updateAttributeValues(ObjectInstanceHandle theObject, AttributeHandleValueMap theAttributes,
				byte[] userSuppliedTag) throws ObjectInstanceNotKnown, AttributeNotDefined, AttributeNotOwned,
				FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public MessageRetractionReturn updateAttributeValues(ObjectInstanceHandle theObject,
				AttributeHandleValueMap theAttributes, byte[] userSuppliedTag, LogicalTime theTime)
				throws ObjectInstanceNotKnown, AttributeNotDefined, AttributeNotOwned, InvalidLogicalTime,
				FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public void sendInteraction(InteractionClassHandle theInteraction, ParameterHandleValueMap theParameters,
				byte[] userSuppliedTag) throws InteractionClassNotPublished, InteractionClassNotDefined,
				InteractionParameterNotDefined, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
				RTIinternalError {
			// TODO Auto-generated method stub

		}

		public MessageRetractionReturn sendInteraction(InteractionClassHandle theInteraction,
				ParameterHandleValueMap theParameters, byte[] userSuppliedTag, LogicalTime theTime)
				throws InteractionClassNotPublished, InteractionClassNotDefined, InteractionParameterNotDefined,
				InvalidLogicalTime, FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public void deleteObjectInstance(ObjectInstanceHandle objectHandle, byte[] userSuppliedTag)
				throws DeletePrivilegeNotHeld, ObjectInstanceNotKnown, FederateNotExecutionMember, SaveInProgress,
				RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public MessageRetractionReturn deleteObjectInstance(ObjectInstanceHandle objectHandle, byte[] userSuppliedTag,
				LogicalTime theTime) throws DeletePrivilegeNotHeld, ObjectInstanceNotKnown, InvalidLogicalTime,
				FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public void localDeleteObjectInstance(ObjectInstanceHandle objectHandle) throws ObjectInstanceNotKnown,
				FederateOwnsAttributes, OwnershipAcquisitionPending, FederateNotExecutionMember, SaveInProgress,
				RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void changeAttributeTransportationType(ObjectInstanceHandle theObject, AttributeHandleSet theAttributes,
				TransportationType theType) throws ObjectInstanceNotKnown, AttributeNotDefined, AttributeNotOwned,
				FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void changeInteractionTransportationType(InteractionClassHandle theClass, TransportationType theType)
				throws InteractionClassNotDefined, InteractionClassNotPublished, FederateNotExecutionMember,
				SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void requestAttributeValueUpdate(ObjectInstanceHandle theObject, AttributeHandleSet theAttributes,
				byte[] userSuppliedTag) throws ObjectInstanceNotKnown, AttributeNotDefined, FederateNotExecutionMember,
				SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void requestAttributeValueUpdate(ObjectClassHandle theClass, AttributeHandleSet theAttributes,
				byte[] userSuppliedTag) throws ObjectClassNotDefined, AttributeNotDefined, FederateNotExecutionMember,
				SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void unconditionalAttributeOwnershipDivestiture(ObjectInstanceHandle theObject,
				AttributeHandleSet theAttributes) throws ObjectInstanceNotKnown, AttributeNotDefined,
				AttributeNotOwned, FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void negotiatedAttributeOwnershipDivestiture(ObjectInstanceHandle theObject,
				AttributeHandleSet theAttributes, byte[] userSuppliedTag) throws ObjectInstanceNotKnown,
				AttributeNotDefined, AttributeNotOwned, AttributeAlreadyBeingDivested, FederateNotExecutionMember,
				SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void confirmDivestiture(ObjectInstanceHandle theObject, AttributeHandleSet theAttributes,
				byte[] userSuppliedTag) throws ObjectInstanceNotKnown, AttributeNotDefined, AttributeNotOwned,
				AttributeDivestitureWasNotRequested, NoAcquisitionPending, FederateNotExecutionMember, SaveInProgress,
				RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void attributeOwnershipAcquisition(ObjectInstanceHandle theObject, AttributeHandleSet desiredAttributes,
				byte[] userSuppliedTag) throws ObjectInstanceNotKnown, ObjectClassNotPublished, AttributeNotDefined,
				AttributeNotPublished, FederateOwnsAttributes, FederateNotExecutionMember, SaveInProgress,
				RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void attributeOwnershipAcquisitionIfAvailable(ObjectInstanceHandle theObject,
				AttributeHandleSet desiredAttributes) throws ObjectInstanceNotKnown, ObjectClassNotPublished,
				AttributeNotDefined, AttributeNotPublished, FederateOwnsAttributes, AttributeAlreadyBeingAcquired,
				FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public AttributeHandleSet attributeOwnershipDivestitureIfWanted(ObjectInstanceHandle theObject,
				AttributeHandleSet theAttributes) throws ObjectInstanceNotKnown, AttributeNotDefined,
				AttributeNotOwned, FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public void cancelNegotiatedAttributeOwnershipDivestiture(ObjectInstanceHandle theObject,
				AttributeHandleSet theAttributes) throws ObjectInstanceNotKnown, AttributeNotDefined,
				AttributeNotOwned, AttributeDivestitureWasNotRequested, FederateNotExecutionMember, SaveInProgress,
				RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void cancelAttributeOwnershipAcquisition(ObjectInstanceHandle theObject, AttributeHandleSet theAttributes)
				throws ObjectInstanceNotKnown, AttributeNotDefined, AttributeAlreadyOwned,
				AttributeAcquisitionWasNotRequested, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
				RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void queryAttributeOwnership(ObjectInstanceHandle theObject, AttributeHandle theAttribute)
				throws ObjectInstanceNotKnown, AttributeNotDefined, FederateNotExecutionMember, SaveInProgress,
				RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public boolean isAttributeOwnedByFederate(ObjectInstanceHandle theObject, AttributeHandle theAttribute)
				throws ObjectInstanceNotKnown, AttributeNotDefined, FederateNotExecutionMember, SaveInProgress,
				RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub
			return false;
		}

		public void enableTimeRegulation(LogicalTimeInterval theLookahead) throws TimeRegulationAlreadyEnabled,
				InvalidLookahead, InTimeAdvancingState, RequestForTimeRegulationPending, FederateNotExecutionMember,
				SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void disableTimeRegulation() throws TimeRegulationIsNotEnabled, FederateNotExecutionMember,
				SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void enableTimeConstrained() throws TimeConstrainedAlreadyEnabled, InTimeAdvancingState,
				RequestForTimeConstrainedPending, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
				RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void disableTimeConstrained() throws TimeConstrainedIsNotEnabled, FederateNotExecutionMember,
				SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void timeAdvanceRequest(LogicalTime theTime) throws InvalidLogicalTime, LogicalTimeAlreadyPassed,
				InTimeAdvancingState, RequestForTimeRegulationPending, RequestForTimeConstrainedPending,
				FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void timeAdvanceRequestAvailable(LogicalTime theTime) throws InvalidLogicalTime,
				LogicalTimeAlreadyPassed, InTimeAdvancingState, RequestForTimeRegulationPending,
				RequestForTimeConstrainedPending, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
				RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void nextMessageRequest(LogicalTime theTime) throws InvalidLogicalTime, LogicalTimeAlreadyPassed,
				InTimeAdvancingState, RequestForTimeRegulationPending, RequestForTimeConstrainedPending,
				FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void nextMessageRequestAvailable(LogicalTime theTime) throws InvalidLogicalTime,
				LogicalTimeAlreadyPassed, InTimeAdvancingState, RequestForTimeRegulationPending,
				RequestForTimeConstrainedPending, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
				RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void flushQueueRequest(LogicalTime theTime) throws InvalidLogicalTime, LogicalTimeAlreadyPassed,
				InTimeAdvancingState, RequestForTimeRegulationPending, RequestForTimeConstrainedPending,
				FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void enableAsynchronousDelivery() throws AsynchronousDeliveryAlreadyEnabled, FederateNotExecutionMember,
				SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void disableAsynchronousDelivery() throws AsynchronousDeliveryAlreadyDisabled,
				FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public TimeQueryReturn queryGALT() throws FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
				RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public LogicalTime queryLogicalTime() throws FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
				RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public TimeQueryReturn queryLITS() throws FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
				RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public void modifyLookahead(LogicalTimeInterval theLookahead) throws TimeRegulationIsNotEnabled,
				InvalidLookahead, InTimeAdvancingState, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
				RTIinternalError {
			// TODO Auto-generated method stub

		}

		public LogicalTimeInterval queryLookahead() throws TimeRegulationIsNotEnabled, FederateNotExecutionMember,
				SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public void retract(MessageRetractionHandle theHandle) throws InvalidMessageRetractionHandle,
				TimeRegulationIsNotEnabled, MessageCanNoLongerBeRetracted, FederateNotExecutionMember, SaveInProgress,
				RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void changeAttributeOrderType(ObjectInstanceHandle theObject, AttributeHandleSet theAttributes,
				OrderType theType) throws ObjectInstanceNotKnown, AttributeNotDefined, AttributeNotOwned,
				FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void changeInteractionOrderType(InteractionClassHandle theClass, OrderType theType)
				throws InteractionClassNotDefined, InteractionClassNotPublished, FederateNotExecutionMember,
				SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public RegionHandle createRegion(DimensionHandleSet dimensions) throws InvalidDimensionHandle,
				FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public void commitRegionModifications(RegionHandleSet regions) throws InvalidRegion,
				RegionNotCreatedByThisFederate, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
				RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void deleteRegion(RegionHandle theRegion) throws InvalidRegion, RegionNotCreatedByThisFederate,
				RegionInUseForUpdateOrSubscription, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
				RTIinternalError {
			// TODO Auto-generated method stub

		}

		public ObjectInstanceHandle registerObjectInstanceWithRegions(ObjectClassHandle theClass,
				AttributeSetRegionSetPairList attributesAndRegions) throws ObjectClassNotDefined,
				ObjectClassNotPublished, AttributeNotDefined, AttributeNotPublished, InvalidRegion,
				RegionNotCreatedByThisFederate, InvalidRegionContext, FederateNotExecutionMember, SaveInProgress,
				RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public ObjectInstanceHandle registerObjectInstanceWithRegions(ObjectClassHandle theClass,
				AttributeSetRegionSetPairList attributesAndRegions, String theObject) throws ObjectClassNotDefined,
				ObjectClassNotPublished, AttributeNotDefined, AttributeNotPublished, InvalidRegion,
				RegionNotCreatedByThisFederate, InvalidRegionContext, ObjectInstanceNameNotReserved,
				ObjectInstanceNameInUse, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
				RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public void associateRegionsForUpdates(ObjectInstanceHandle theObject,
				AttributeSetRegionSetPairList attributesAndRegions) throws ObjectInstanceNotKnown, AttributeNotDefined,
				InvalidRegion, RegionNotCreatedByThisFederate, InvalidRegionContext, FederateNotExecutionMember,
				SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void unassociateRegionsForUpdates(ObjectInstanceHandle theObject,
				AttributeSetRegionSetPairList attributesAndRegions) throws ObjectInstanceNotKnown, AttributeNotDefined,
				InvalidRegion, RegionNotCreatedByThisFederate, FederateNotExecutionMember, SaveInProgress,
				RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void subscribeObjectClassAttributesWithRegions(ObjectClassHandle theClass,
				AttributeSetRegionSetPairList attributesAndRegions) throws ObjectClassNotDefined, AttributeNotDefined,
				InvalidRegion, RegionNotCreatedByThisFederate, InvalidRegionContext, FederateNotExecutionMember,
				SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void subscribeObjectClassAttributesPassivelyWithRegions(ObjectClassHandle theClass,
				AttributeSetRegionSetPairList attributesAndRegions) throws ObjectClassNotDefined, AttributeNotDefined,
				InvalidRegion, RegionNotCreatedByThisFederate, InvalidRegionContext, FederateNotExecutionMember,
				SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void unsubscribeObjectClassAttributesWithRegions(ObjectClassHandle theClass,
				AttributeSetRegionSetPairList attributesAndRegions) throws ObjectClassNotDefined, AttributeNotDefined,
				InvalidRegion, RegionNotCreatedByThisFederate, FederateNotExecutionMember, SaveInProgress,
				RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void subscribeInteractionClassWithRegions(InteractionClassHandle theClass, RegionHandleSet regions)
				throws InteractionClassNotDefined, InvalidRegion, RegionNotCreatedByThisFederate, InvalidRegionContext,
				FederateServiceInvocationsAreBeingReportedViaMOM, FederateNotExecutionMember, SaveInProgress,
				RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void subscribeInteractionClassPassivelyWithRegions(InteractionClassHandle theClass,
				RegionHandleSet regions) throws InteractionClassNotDefined, InvalidRegion,
				RegionNotCreatedByThisFederate, InvalidRegionContext, FederateServiceInvocationsAreBeingReportedViaMOM,
				FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void unsubscribeInteractionClassWithRegions(InteractionClassHandle theClass, RegionHandleSet regions)
				throws InteractionClassNotDefined, InvalidRegion, RegionNotCreatedByThisFederate,
				FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void sendInteractionWithRegions(InteractionClassHandle theInteraction,
				ParameterHandleValueMap theParameters, RegionHandleSet regions, byte[] userSuppliedTag)
				throws InteractionClassNotDefined, InteractionClassNotPublished, InteractionParameterNotDefined,
				InvalidRegion, RegionNotCreatedByThisFederate, InvalidRegionContext, FederateNotExecutionMember,
				SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public MessageRetractionReturn sendInteractionWithRegions(InteractionClassHandle theInteraction,
				ParameterHandleValueMap theParameters, RegionHandleSet regions, byte[] userSuppliedTag,
				LogicalTime theTime) throws InteractionClassNotDefined, InteractionClassNotPublished,
				InteractionParameterNotDefined, InvalidRegion, RegionNotCreatedByThisFederate, InvalidRegionContext,
				InvalidLogicalTime, FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public void requestAttributeValueUpdateWithRegions(ObjectClassHandle theClass,
				AttributeSetRegionSetPairList attributesAndRegions, byte[] userSuppliedTag)
				throws ObjectClassNotDefined, AttributeNotDefined, InvalidRegion, RegionNotCreatedByThisFederate,
				InvalidRegionContext, FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public ObjectClassHandle getObjectClassHandle(String theName) throws NameNotFound, FederateNotExecutionMember,
				RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public String getObjectClassName(ObjectClassHandle theHandle) throws InvalidObjectClassHandle,
				FederateNotExecutionMember, RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public AttributeHandle getAttributeHandle(ObjectClassHandle whichClass, String theName)
				throws InvalidObjectClassHandle, NameNotFound, FederateNotExecutionMember, RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public String getAttributeName(ObjectClassHandle whichClass, AttributeHandle theHandle)
				throws InvalidObjectClassHandle, InvalidAttributeHandle, AttributeNotDefined,
				FederateNotExecutionMember, RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public InteractionClassHandle getInteractionClassHandle(String theName) throws NameNotFound,
				FederateNotExecutionMember, RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public String getInteractionClassName(InteractionClassHandle theHandle) throws InvalidInteractionClassHandle,
				FederateNotExecutionMember, RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public ParameterHandle getParameterHandle(InteractionClassHandle whichClass, String theName)
				throws InvalidInteractionClassHandle, NameNotFound, FederateNotExecutionMember, RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public String getParameterName(InteractionClassHandle whichClass, ParameterHandle theHandle)
				throws InvalidInteractionClassHandle, InvalidParameterHandle, InteractionParameterNotDefined,
				FederateNotExecutionMember, RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public ObjectInstanceHandle getObjectInstanceHandle(String theName) throws ObjectInstanceNotKnown,
				FederateNotExecutionMember, RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public String getObjectInstanceName(ObjectInstanceHandle theHandle) throws ObjectInstanceNotKnown,
				FederateNotExecutionMember, RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public DimensionHandle getDimensionHandle(String theName) throws NameNotFound, FederateNotExecutionMember,
				RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public String getDimensionName(DimensionHandle theHandle) throws InvalidDimensionHandle,
				FederateNotExecutionMember, RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public long getDimensionUpperBound(DimensionHandle theHandle) throws InvalidDimensionHandle,
				FederateNotExecutionMember, RTIinternalError {
			// TODO Auto-generated method stub
			return 0;
		}

		public DimensionHandleSet getAvailableDimensionsForClassAttribute(ObjectClassHandle whichClass,
				AttributeHandle theHandle) throws InvalidObjectClassHandle, InvalidAttributeHandle,
				AttributeNotDefined, FederateNotExecutionMember, RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public ObjectClassHandle getKnownObjectClassHandle(ObjectInstanceHandle theObject)
				throws ObjectInstanceNotKnown, FederateNotExecutionMember, RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public DimensionHandleSet getAvailableDimensionsForInteractionClass(InteractionClassHandle theHandle)
				throws InvalidInteractionClassHandle, FederateNotExecutionMember, RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public TransportationType getTransportationType(String theName) throws InvalidTransportationName,
				FederateNotExecutionMember, RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public String getTransportationName(TransportationType theType) throws InvalidTransportationType,
				FederateNotExecutionMember, RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public OrderType getOrderType(String theName) throws InvalidOrderName, FederateNotExecutionMember,
				RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public String getOrderName(OrderType theType) throws InvalidOrderType, FederateNotExecutionMember,
				RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public void enableObjectClassRelevanceAdvisorySwitch() throws FederateNotExecutionMember,
				ObjectClassRelevanceAdvisorySwitchIsOn, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void disableObjectClassRelevanceAdvisorySwitch() throws ObjectClassRelevanceAdvisorySwitchIsOff,
				FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void enableAttributeRelevanceAdvisorySwitch() throws AttributeRelevanceAdvisorySwitchIsOn,
				FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void disableAttributeRelevanceAdvisorySwitch() throws AttributeRelevanceAdvisorySwitchIsOff,
				FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void enableAttributeScopeAdvisorySwitch() throws AttributeScopeAdvisorySwitchIsOn,
				FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void disableAttributeScopeAdvisorySwitch() throws AttributeScopeAdvisorySwitchIsOff,
				FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void enableInteractionRelevanceAdvisorySwitch() throws InteractionRelevanceAdvisorySwitchIsOn,
				FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void disableInteractionRelevanceAdvisorySwitch() throws InteractionRelevanceAdvisorySwitchIsOff,
				FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public DimensionHandleSet getDimensionHandleSet(RegionHandle region) throws InvalidRegion,
				FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public RangeBounds getRangeBounds(RegionHandle region, DimensionHandle dimension) throws InvalidRegion,
				RegionDoesNotContainSpecifiedDimension, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
				RTIinternalError {
			// TODO Auto-generated method stub
			return null;
		}

		public void setRangeBounds(RegionHandle region, DimensionHandle dimension, RangeBounds bounds)
				throws InvalidRegion, RegionNotCreatedByThisFederate, RegionDoesNotContainSpecifiedDimension,
				InvalidRangeBound, FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
			// TODO Auto-generated method stub

		}

		public long normalizeFederateHandle(FederateHandle federateHandle) throws InvalidFederateHandle,
				FederateNotExecutionMember, RTIinternalError {
			// TODO Auto-generated method stub
			return 0;
		}

		public long normalizeServiceGroup(ServiceGroup group) throws InvalidServiceGroup, FederateNotExecutionMember,
				RTIinternalError {
			// TODO Auto-generated method stub
			return 0;
		}

		public boolean evokeCallback(double seconds) throws FederateNotExecutionMember, RTIinternalError {
			// TODO Auto-generated method stub
			return false;
		}

		public boolean evokeMultipleCallbacks(double minimumTime, double maximumTime)
				throws FederateNotExecutionMember, RTIinternalError {
			// TODO Auto-generated method stub
			return false;
		}

		public void enableCallbacks() throws FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
				RTIinternalError {
			// TODO Auto-generated method stub

		}

		public void disableCallbacks() throws FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
				RTIinternalError {
			// TODO Auto-generated method stub

		}

	};

	public DecodingHelpers(RTIambassador rtiAmbassador) {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Decodes and returns the value stored in the specified buffer.
	 * 
	 * @param buffer
	 *            the buffer containing the encoded value
	 * @return the decoded value
	 * @exception CouldNotDecode
	 *                if the value could not be decoded
	 */
	public static boolean decodeBoolean(byte[] buffer) throws CouldNotDecode {
		ByteArrayInputStream bais = new ByteArrayInputStream(buffer);
		DataInputStream dis = new DataInputStream(bais);

		try {
			return dis.readBoolean();
		} catch (IOException ioe) {
			throw new CouldNotDecode("bad boolean");
		}
	}

	/**
	 * Decodes and returns the value stored in the specified buffer.
	 * 
	 * @param buffer
	 *            the buffer containing the encoded value
	 * @return the decoded value
	 * @exception CouldNotDecode
	 *                if the value could not be decoded
	 */
	public static byte decodeByte(byte[] buffer) throws CouldNotDecode {
		ByteArrayInputStream bais = new ByteArrayInputStream(buffer);
		DataInputStream dis = new DataInputStream(bais);

		try {
			return dis.readByte();
		} catch (IOException ioe) {
			throw new CouldNotDecode("bad byte");
		}
	}

	/**
	 * Decodes and returns the value stored in the specified buffer.
	 * 
	 * @param buffer
	 *            the buffer containing the encoded value
	 * @return the decoded value
	 * @exception CouldNotDecode
	 *                if the value could not be decoded
	 */
	public static char decodeChar(byte[] buffer) throws CouldNotDecode {
		ByteArrayInputStream bais = new ByteArrayInputStream(buffer);
		DataInputStream dis = new DataInputStream(bais);

		try {
			return dis.readChar();
		} catch (IOException ioe) {
			throw new CouldNotDecode("bad char");
		}
	}

	/**
	 * Decodes and returns the value stored in the specified buffer.
	 * 
	 * @param buffer
	 *            the buffer containing the encoded value
	 * @return the decoded value
	 * @exception CouldNotDecode
	 *                if the value could not be decoded
	 */
	public static double decodeDouble(byte[] buffer) throws CouldNotDecode {
		ByteArrayInputStream bais = new ByteArrayInputStream(buffer);
		DataInputStream dis = new DataInputStream(bais);

		try {
			return dis.readDouble();
		} catch (IOException ioe) {
			throw new CouldNotDecode("bad double");
		}
	}

	/**
	 * Decodes and returns the value stored in the specified buffer.
	 * 
	 * @param buffer
	 *            the buffer containing the encoded value
	 * @return the decoded value
	 * @exception CouldNotDecode
	 *                if the value could not be decoded
	 */
	public static float decodeFloat(byte[] buffer) throws CouldNotDecode {
		ByteArrayInputStream bais = new ByteArrayInputStream(buffer);
		DataInputStream dis = new DataInputStream(bais);

		try {
			return dis.readFloat();
		} catch (IOException ioe) {
			throw new CouldNotDecode("bad float");
		}
	}

	/**
	 * Decodes and returns the value stored in the specified buffer.
	 * 
	 * @param buffer
	 *            the buffer containing the encoded value
	 * @return the decoded value
	 * @exception CouldNotDecode
	 *                if the value could not be decoded
	 */
	public static int decodeInt(byte[] buffer) throws CouldNotDecode {
		ByteArrayInputStream bais = new ByteArrayInputStream(buffer);
		DataInputStream dis = new DataInputStream(bais);

		try {
			return dis.readInt();
		} catch (IOException ioe) {
			throw new CouldNotDecode("bad int");
		}
	}

	/**
	 * Decodes and returns the value stored in the specified buffer.
	 * 
	 * @param buffer
	 *            the buffer containing the encoded value
	 * @return the decoded value
	 * @exception CouldNotDecode
	 *                if the value could not be decoded
	 */
	public static long decodeLong(byte[] buffer) throws CouldNotDecode {
		ByteArrayInputStream bais = new ByteArrayInputStream(buffer);
		DataInputStream dis = new DataInputStream(bais);

		try {
			return dis.readLong();
		} catch (IOException ioe) {
			throw new CouldNotDecode("bad long");
		}
	}

	/**
	 * Decodes and returns the value stored in the specified buffer.
	 * 
	 * @param buffer
	 *            the buffer containing the encoded value
	 * @return the decoded value
	 * @exception CouldNotDecode
	 *                if the value could not be decoded
	 */
	public static short decodeShort(byte[] buffer) throws CouldNotDecode {
		ByteArrayInputStream bais = new ByteArrayInputStream(buffer);
		DataInputStream dis = new DataInputStream(bais);

		try {
			return dis.readShort();
		} catch (IOException ioe) {
			throw new CouldNotDecode("bad short");
		}
	}

	/**
	 * Decodes and returns the value stored in the specified buffer.
	 * 
	 * @param buffer
	 *            the buffer containing the encoded value
	 * @return the decoded value
	 * @exception CouldNotDecode
	 *                if the value could not be decoded
	 */
	public static String decodeString(byte[] buffer) throws CouldNotDecode {
		ByteArrayInputStream bais = new ByteArrayInputStream(buffer);
		DataInputStream dis = new DataInputStream(bais);

		try {
			return dis.readUTF();
		} catch (IOException ioe) {
			throw new CouldNotDecode("bad string");
		}
	}

	/**
	 * Reverses the specified byte array in-place.
	 * 
	 * @param buffer
	 *            the byte array to reverse
	 */
	public static void reverse(byte[] buffer) {
		byte tmp;

		for (int i = 0, j = buffer.length - 1; i < j; i++, j--) {
			tmp = buffer[i];

			buffer[i] = buffer[j];

			buffer[j] = tmp;
		}
	}

	public static AttributeHandle decodeAttributeHandle(byte[] attributeHandle) throws CouldNotDecode,
			FederateNotExecutionMember {
		return rtiAmbassador.getAttributeHandleFactory().decode(attributeHandle, 0);
	}

	public static ObjectInstanceHandle decodeObjectInstanceHandle(byte[] objectInstanceHandle) throws CouldNotDecode,
			FederateNotExecutionMember {
		return rtiAmbassador.getObjectInstanceHandleFactory().decode(objectInstanceHandle, 0);
	}

	public static ObjectClassHandle decodeObjectClassHandle(byte[] objectClassHandle) throws CouldNotDecode,
			FederateNotExecutionMember {
		return rtiAmbassador.getObjectClassHandleFactory().decode(objectClassHandle, 0);
	}

	public static FederateHandle decodeFederateHandle(byte[] federateHandle) throws CouldNotDecode,
			FederateNotExecutionMember {
		return rtiAmbassador.getFederateHandleFactory().decode(federateHandle, 0);
	}

	public static URL decodeURL(byte[] fdd) throws CouldNotDecode {
		URL url = null;

		try {
			File tmpFile = File.createTempFile("Prefix_", "_FOM.xml");
			java.nio.ByteBuffer buf = java.nio.ByteBuffer.wrap(fdd);
			FileChannel wChannel = new FileOutputStream(tmpFile, false).getChannel();
			wChannel.write(buf);
			wChannel.close();
			url = tmpFile.toURL();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return url;
	}

}