package org.eodisp.erti.client.rti1516;

import hla.rti1516.*;
import junit.framework.TestCase;

/**
 * Tests HLA services of the RTIambassador interface. Before starting this test
 * a simulation manager must run with its JMX port set to 10028.
 * 
 * @author ibirrer
 * @version $Id: HLAServicesTest.java 2241 2006-06-07 08:12:09Z ibirrer $
 */
public class HLAServicesTest extends TestCase {
	private static final String FEDERATION_EXECUTION_NAME = "federation-execution_1";

	private static final int ERTI_SERVER_JMX_RMI_REGISTRY_PORT = 10028;

	/**
	 * A proxy to the simulation manager. This simulation manager must run
	 * locally on port 10028.
	 */
//	private static SimulationManagerAppMBean simulationManager;

	// Initialize connection to the simulation manager
//	static {
//		try {
//			MBeanServerConnection mBeanServerConnection = null;
//			JMXServiceURL url = new JMXServiceURL("service:jmx:rmi:///jndi/rmi://localhost:"
//					+ ERTI_SERVER_JMX_RMI_REGISTRY_PORT + "/ertiMBeanServer");
//			JMXConnector jmxc = JMXConnectorFactory.connect(url, null);
//			mBeanServerConnection = jmxc.getMBeanServerConnection();
//			ObjectName ertiServerObjectName = null;
//			ertiServerObjectName = new ObjectName(ERTIConstants.ERTI_SIMULATION_MANAGER_JMX_OBJECT_NAME);
//
//			simulationManager = (SimulationManagerAppMBean) MBeanServerInvocationHandler.newProxyInstance(
//					mBeanServerConnection,
//					ertiServerObjectName,
//					SimulationManagerAppMBean.class,
//					true);
//
//			// start HLA if not yet started
//			if (simulationManager.getState().equals(AppManagerState.JMX_STARTED)) {
//				simulationManager.startHLA();
//			}
//
//		} catch (Exception e) {
//			e.printStackTrace();
//			System.exit(1);
//		}
//	}

	/**
	 * RTIambassador is set up in the setUp() method
	 */
	private RTIambassador rtiAmbassador;

	public static void main(String[] args) {
		junit.textui.TestRunner.run(HLAServicesTest.class);
		System.exit(0);
	}

	/**
	 * Destroys all federation executions on the simulation manager and receives
	 * a proxy for an RTIambassador. Executed each time before a testXXX method
	 * is executed.
	 */
	@Override
	protected void setUp() throws Exception {
		// Destroy all federation executions before each test run
//		simulationManager.destroyAllFederationExecutions();
//
//		RtiFactory rtiFactory = RtiFactoryFactory.getRtiFactory();
//		rtiAmbassador = rtiFactory.getRtiAmbassador();
	}

	/**
	 * Creates a federation execution. Is is assumed that the creation of the
	 * federation execution was successful if the no exception is being thrown.
	 */
	public void testCreateFederationExecution() {
		try {
			rtiAmbassador.createFederationExecution(FEDERATION_EXECUTION_NAME, null);
		} catch (FederationExecutionAlreadyExists e) {
			fail(e.getMessage());
		} catch (CouldNotOpenFDD e) {
			fail(e.getMessage());
		} catch (ErrorReadingFDD e) {
			fail(e.getMessage());
		} catch (RTIinternalError e) {
			fail(e.getMessage());
		}
	}

	/**
	 * Creates two federation executions with the same name. The second call to
	 * <code>createFederationExection()</code> should throw a
	 * {@link FederationExecutionAlreadyExists} exception. If this is not the
	 * case the test fails.
	 * 
	 * @throws Throwable
	 *             Thrown if the test case fails because of an error other than
	 *             this test case is testing. This does not mean that the test
	 *             case actually failed, but that the test case itself is
	 *             probably wrong or the setup of the platform is not correct.
	 */
	public void testCreateFederationExecution_FederationExecutionAlreadyExists() throws Exception {
		rtiAmbassador.createFederationExecution(FEDERATION_EXECUTION_NAME, null);
		try {
			rtiAmbassador.createFederationExecution(FEDERATION_EXECUTION_NAME, null);
			fail("Expected FederationExecutionAlreadyExists exception to be thrown");
		} catch (FederationExecutionAlreadyExists expected) {
			assertTrue(true);
		}
	}

	/**
	 * Tests destroying a federation execution. First a federation execution is
	 * created and then deleted. The next call to create the same federation
	 * execution must not fail with a
	 * <code>FederationExecutionAlreadyExists</code> because the federation
	 * execution should have been destroyed before. If it does this test fails.
	 * 
	 * @throws Exception
	 *             Thrown if the test case fails because of an error other than
	 *             this test case is testing. This does not mean that the test
	 *             case actually failed, but that the test case itself is
	 *             probably wrong or the setup of the platform is not correct.
	 */
	public void testDestroyFederationExecution() throws Exception {
		rtiAmbassador.createFederationExecution(FEDERATION_EXECUTION_NAME, null);
		rtiAmbassador.destroyFederationExecution(FEDERATION_EXECUTION_NAME);
		try {
			rtiAmbassador.createFederationExecution(FEDERATION_EXECUTION_NAME, null);
		} catch (FederationExecutionAlreadyExists e) {
			fail("Creating a federation execution after it has been destroyed should be possible");
		}
	}

	/**
	 * Tries to destroy a federation execution that does not exist. If no
	 * {@link FederationExecutionAlreadyExists} exception is thrown, this test
	 * fails.
	 * 
	 * @throws Exception
	 *             Thrown if the test case fails because of an error other than
	 *             this test case is testing. This does not mean that the test
	 *             case actually failed, but that the test case itself is
	 *             probably wrong or the setup of the platform is not correct.
	 */
	public void testDestroyFederationExecution_FederationExecutionDoesNotExist() throws Exception {
		try {
			rtiAmbassador.destroyFederationExecution(FEDERATION_EXECUTION_NAME);
			fail("Expected FederationExecutionAlreadyExists exception to be thrown");
		} catch (FederationExecutionDoesNotExist expected) {
			assertTrue(true);
		}
	}

}
