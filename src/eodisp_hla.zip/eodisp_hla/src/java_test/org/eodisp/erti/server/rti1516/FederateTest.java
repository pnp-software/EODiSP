package org.eodisp.erti.server.rti1516;

import hla.rti1516.*;
import junit.framework.TestCase;

import org.eodisp.erti.client.rti1516.TestFederateAmbassador;

public class FederateTest extends TestCase {

	public static class MyFederateAmbassador extends TestFederateAmbassador {
		public boolean objectClassDiscovered = false;

		@Override
		public void discoverObjectInstance(ObjectInstanceHandle theObject, ObjectClassHandle theObjectClass,
				String objectName) throws CouldNotDiscover, ObjectClassNotRecognized, FederateInternalError {
			objectClassDiscovered = true;
		}
	}

	public static class ReflectFederateAmbassador extends TestFederateAmbassador {
		public AttributeHandleValueMap attributeHandleValueMap;

		public ObjectInstanceHandle objectInstance;

		@Override
		public void reflectAttributeValues(ObjectInstanceHandle theObject, AttributeHandleValueMap theAttributes,
				byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport)
				throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotSubscribed, FederateInternalError {
			this.attributeHandleValueMap = theAttributes;
			this.objectInstance = theObject;
		}
	}

//	/**
//	 * TODO: Add more tests. Different subsrciption possibilities etc. Test
//	 * method for {@link FederateOld#registerObjectInstance(ObjectClassHandle)}
//	 */
//	public void testUpdateAttributeValues() throws Exception {
//		FederationExecution federationExecution = new FederationExecution("TestFederationExecution", TestOMTModel
//				.getURL());
//		ReflectFederateAmbassador federateAmbassador1 = new ReflectFederateAmbassador();
//		ReflectFederateAmbassador federateAmbassador2 = new ReflectFederateAmbassador();
//		ReflectFederateAmbassador federateAmbassador3 = new ReflectFederateAmbassador();
//
//		FederateHandle federateHandle1 = federationExecution.join("", federateAmbassador1, null);
//		FederateHandle federateHandle2 = federationExecution.join("", federateAmbassador2, null);
//		FederateHandle federateHandle3 = federationExecution.join("", federateAmbassador3, null);
//
//		FederateOld federate1 = federationExecution.getFederate(federateHandle1);
//		FederateOld federate2 = federationExecution.getFederate(federateHandle2);
//
//		ObjectClassHandle objectClassHandle = federationExecution.getObjectClassHandle("A_1.B_1");
//
//		ObjectClass objectClass = federationExecution.getObjectClass(objectClassHandle);
//		AttributeHandleSet attributeHandleSet = new AttributeHandleSetImpl();
//
//		for (Object obj : objectClass.getAllAttributes()) {
//			Attribute attr = (Attribute) obj;
//			attributeHandleSet.add(attr.getHandle());
//		}
//
//		ObjectInstanceHandle instanceHandleA1 = federate1.registerObjectInstance(objectClassHandle);
//		federate2.subscribeObjectClassAttributes(objectClassHandle, attributeHandleSet);
//
//		AttributeHandleValueMap attributeHandleValueMap = new AttributeHandleValueMapImpl();
//		for (Object obj : attributeHandleSet) {
//			AttributeHandle attrHandle = (AttributeHandle) obj;
//			attributeHandleValueMap.put(attrHandle, "TestValue".getBytes());
//		}
//
//		federate1.updateAttributeValues(instanceHandleA1, attributeHandleValueMap, new byte[0]);
//
//		assertTrue(attributeHandleValueMap.values().containsAll(federateAmbassador2.attributeHandleValueMap.values()));
//
//		assertNull(
//				"The updating federate must not receive the reflect callback",
//				federateAmbassador1.attributeHandleValueMap);
//		assertNull(
//				"Federate 3 must not receive the reflect callack because it is not subscribed",
//				federateAmbassador3.attributeHandleValueMap);
//
//	}
//
//	/**
//	 * Test method for
//	 * {@link FederateOld#updateAttributeValues(ObjectInstanceHandle, AttributeHandleValueMap, byte[])}
//	 */
//	public void testRegisterObjectInstance() throws Exception {
//		FederationExecution federationExecution = new FederationExecution("TestFederationExecution", TestOMTModel
//				.getURL());
//		MyFederateAmbassador myFederateAmbassador1 = new MyFederateAmbassador();
//		MyFederateAmbassador myFederateAmbassador2 = new MyFederateAmbassador();
//		MyFederateAmbassador myFederateAmbassador3 = new MyFederateAmbassador();
//
//		FederateHandle federateHandle1 = federationExecution.join("", myFederateAmbassador1, null);
//		FederateHandle federateHandle2 = federationExecution.join("", myFederateAmbassador2, null);
//		FederateHandle federateHandle3 = federationExecution.join("", myFederateAmbassador3, null);
//
//		FederateOld federate1 = federationExecution.getFederate(federateHandle1);
//		FederateOld federate2 = federationExecution.getFederate(federateHandle2);
//
//		ObjectClassHandle objectClassHandle = federationExecution.getObjectClassHandle("A_1");
//
//		ObjectClass objectClass = federationExecution.getObjectClass(objectClassHandle);
//		AttributeHandleSet attributeHandleSet = new AttributeHandleSetImpl();
//
//		for (Object obj : objectClass.getAllAttributes()) {
//			Attribute attr = (Attribute) obj;
//			attributeHandleSet.add(attr.getHandle());
//		}
//
//		federate2.subscribeObjectClassAttributes(objectClassHandle, attributeHandleSet);
//		federate1.registerObjectInstance(objectClassHandle);
//
//		assertTrue(
//				"Federate 2 did not discover the object instance registartion of federate 1",
//				myFederateAmbassador2.objectClassDiscovered);
//		assertFalse(
//				"Federate 1 discovered the object instance of its own registration",
//				myFederateAmbassador1.objectClassDiscovered);
//		assertFalse(
//				"Federate 3 discovered the object instance registered by federate1 even though it did not subscribe for it",
//				myFederateAmbassador3.objectClassDiscovered);
//	}

}
