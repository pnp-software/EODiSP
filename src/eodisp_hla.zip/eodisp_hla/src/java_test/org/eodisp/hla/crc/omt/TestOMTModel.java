/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.hla.crc.omt;

import java.io.*;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eodisp.hla.crc.omt.util.OmtResourceFactoryImpl;

/**
 * An OMT model for testing purposes. The model has the following structure:
 * 
 * <pre>
 *            HLAobjectRoot
 *                 &circ;
 *                 |
 *                A_1
 *                 &circ;
 *                _|___
 *               |     |
 *              B_1   B_2
 *               &circ;
 *               |
 *              C_1
 *              
 *              HLAinteractionRoot
 *                 &circ;
 *                 |
 *                I_1
 *                 &circ;
 *                _|___
 *               |     |
 *              J_1   J_2
 *               &circ;
 *               |
 *              K_1
 *              
 * </pre>
 * 
 * The following attributes are defined for the given object classes:
 * <ul>
 * <li>HLAobjectRoot: HLAprivilegeToDeleteObject</li>
 * <li>A_1: x,y</li>
 * <li>B_1: z</li>
 * <li>B_2: q</li>
 * <li>C_1: none</li>
 * </ul>
 * 
 * The following parameters are defined for the given interaction classes:
 * <ul>
 * <li>HLAobjectRoot: HLAprivilegeToDeleteObject</li>
 * <li>I_1: p1,p2</li>
 * <li>J_1: p3</li>
 * <li>J_2: p4</li>
 * <li>K_1: none</li>
 * </ul>
 * 
 * @author ibirrer
 * @version $Id:$
 */
public class TestOMTModel {

	public static final String P4 = "p4";

	public static final String P3 = "p3";

	public static final String P2 = "p2";

	public static final String P1 = "p1";

	public static final String Q = "q";

	public static final String Z = "z";

	public static final String Y = "y";

	public static final String X = "x";

	public static final String K_1 = "K_1";

	public static final String J_2 = "J_2";

	public static final String J_1 = "J_1";

	public static final String I_1 = "I_1";

	public static final String C_1 = "C_1";

	public static final String B_2 = "B_2";

	public static final String B_1 = "B_1";
	
	public static final String B_1_ABS = "A_1.B_1";

	public static final String A_1 = "A_1";

	/**
	 * test object classes
	 */
	public ObjectClass hlaObjectRoot, a1, b1, b2, c1;

	/**
	 * test interaction classes
	 */
	public InteractionClass hlaInteractionRoot, i1, j1, j2, k1;

	/**
	 * test attributes
	 */
	Attribute hlaPrivilegeToDeleteObject, x, y, z, q;

	/**
	 * test parameters
	 */
	public Parameter p1, p2, p3, p4;

	public DocumentRoot documentRoot;

	private ObjectModel objectModel;

	static {
		// make sure the file is written to disk
		TestOMTModel testOMTModel = new TestOMTModel();
		try {
			FileOutputStream outputStream = new FileOutputStream(getURL().getFile());
			testOMTModel.print(outputStream);
			outputStream.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Creates the structure. See class documentation.
	 * 
	 */
	@SuppressWarnings("unchecked")
	public TestOMTModel() {
		documentRoot = OmtFactory.eINSTANCE.createDocumentRoot();
		objectModel = OmtFactory.eINSTANCE.createObjectModel();
		objectModel.setName("TestOMTModel");
		objectModel.setType(ObjectModelTypeEnum.FOM_LITERAL);
		documentRoot.setObjectModel(objectModel);

		// Object classes
		Objects objects = OmtFactory.eINSTANCE.createObjects();
		hlaObjectRoot = OmtFactory.eINSTANCE.createObjectClass();
		objectModel.setObjects(objects);
		objects.getObjectClass().add(hlaObjectRoot);

		hlaObjectRoot.setName(ObjectClass.HLA_OBJECT_ROOT_NAME);
		a1 = OmtFactory.eINSTANCE.createObjectClass();
		a1.setName(A_1);
		b1 = OmtFactory.eINSTANCE.createObjectClass();
		b1.setName(B_1);
		b2 = OmtFactory.eINSTANCE.createObjectClass();
		b2.setName(B_2);
		c1 = OmtFactory.eINSTANCE.createObjectClass();
		c1.setName(C_1);

		hlaPrivilegeToDeleteObject = OmtFactory.eINSTANCE.createAttribute();
		x = OmtFactory.eINSTANCE.createAttribute();
		y = OmtFactory.eINSTANCE.createAttribute();
		z = OmtFactory.eINSTANCE.createAttribute();
		q = OmtFactory.eINSTANCE.createAttribute();

		hlaPrivilegeToDeleteObject.setName("hlaPrivilegeToDeleteObject");
		x.setName(X);
		y.setName(Y);
		z.setName(Z);
		q.setName(Q);

		// Hierarchy
		hlaObjectRoot.getSubClasses().add(a1);
		a1.getSubClasses().add(b1);
		a1.getSubClasses().add(b2);
		b1.getSubClasses().add(c1);

		// Attributes
		hlaObjectRoot.getAttributes().add(hlaPrivilegeToDeleteObject);
		a1.getAttributes().add(x);
		a1.getAttributes().add(y);
		b1.getAttributes().add(z);
		b2.getAttributes().add(q);

		// Interactions
		Interactions interactions = OmtFactory.eINSTANCE.createInteractions();
		hlaInteractionRoot = OmtFactory.eINSTANCE.createInteractionClass();
		objectModel.setInteractions(interactions);
		interactions.getInteractionClass().add(hlaInteractionRoot);

		hlaInteractionRoot.setName(InteractionClass.HLA_INTERACTION_ROOT_NAME);
		i1 = OmtFactory.eINSTANCE.createInteractionClass();
		i1.setName(I_1);

		j1 = OmtFactory.eINSTANCE.createInteractionClass();
		j1.setName(J_1);
		j2 = OmtFactory.eINSTANCE.createInteractionClass();
		j2.setName(J_2);

		k1 = OmtFactory.eINSTANCE.createInteractionClass();
		k1.setName(K_1);

		p1 = OmtFactory.eINSTANCE.createParameter();
		p2 = OmtFactory.eINSTANCE.createParameter();
		p3 = OmtFactory.eINSTANCE.createParameter();
		p4 = OmtFactory.eINSTANCE.createParameter();

		p1.setName(P1);
		p2.setName(P2);
		p3.setName(P3);
		p4.setName(P4);

		// Hierarchy
		hlaInteractionRoot.getSubClasses().add(i1);
		i1.getSubClasses().add(j1);
		i1.getSubClasses().add(j2);
		j1.getSubClasses().add(k1);

		// Attributes
		i1.getParameters().add(p1);
		i1.getParameters().add(p2);
		j1.getParameters().add(p3);
		j2.getParameters().add(p4);
	}

	public static URL getURL() {
		return TestOMTModel.class.getClassLoader().getResource("org/eodisp/hla/resources/testOmtModel.fdd");
	}

	public byte[] getAsByteArray() {
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		try {
			print(byteArrayOutputStream);
		} catch (IOException e) {
			throw new RuntimeException("Unexpected IOException in TestOMTModel.getAsByteArray()", e);
		}
		return byteArrayOutputStream.toByteArray();
	}

	public static void main(String[] args) throws IOException {
		TestOMTModel testOMTModel = new TestOMTModel();
		Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put("fdd", new XMIResourceFactoryImpl());
		URI fileURI = URI.createFileURI("test.fdd");
		ResourceSet resourceSet = new ResourceSetImpl();
		Resource resource = resourceSet.createResource(fileURI);
		resource.getContents().add(testOMTModel.documentRoot);
		Map options = new HashMap();
		options.put(XMLResource.OPTION_ENCODING, "UTF-8");
		resource.save(System.out, options);
	}

	public void print(OutputStream out) throws IOException {
		Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put("fdd", new OmtResourceFactoryImpl());
		URI fileURI = URI.createFileURI("test.fdd");
		ResourceSet resourceSet = new ResourceSetImpl();
		Resource resource = resourceSet.createResource(fileURI);
		resource.getContents().add(this.documentRoot);
		Map options = new HashMap();
		options.put(XMLResource.OPTION_ENCODING, "UTF-8");
		resource.save(out, options);
	}
	
	public ObjectModel getObjectModel() {
		return objectModel;
	}

	public DocumentRoot getDocumentRoot() {
		return documentRoot;
	}
}
