package org.eodisp.hla.crc.omt;

import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eodisp.hla.crc.omt.util.*;

public class SomMergerTest extends TestCase {
	public void testMerge_Empty_1() throws Exception {
		SomMerger merger = new SomMerger();
		merger.merge(TestObjectModelFactory.newEmptySom());
		merger.merge(TestObjectModelFactory.newSom_1());
		internalTestMerge_Empty_1(merger);
	}

	public void testMerge_1_Empty() throws Exception {
		SomMerger merger = new SomMerger();
		merger.merge(TestObjectModelFactory.newSom_1());
		merger.merge(TestObjectModelFactory.newEmptySom());
		internalTestMerge_Empty_1(merger);
	}

	private void internalTestMerge_Empty_1(SomMerger merger) {
		assertTrue("Merge caused unexpected errors", merger.getErrors().isEmpty());
		ObjectModelIndexer index = new ObjectModelIndexer(merger.getFom().getObjectModel());
		assertNotNull(index.getObjectClass("A_1"));
		assertNotNull(index.getInteractionClass("I_1"));
	}

	public void testMerge_addingAttributesToEmpty() throws Exception {
		SomMerger merger = new SomMerger();
		merger.merge(TestObjectModelFactory.newSom_1());
		merger.merge(TestObjectModelFactory.newSom_2());
		ObjectModelIndexer index = new ObjectModelIndexer(merger.getFom().getObjectModel());

		ObjectClass a1 = index.getObjectClass("A_1");
		Attribute attr = (Attribute) a1.getAttributes().get(0);
		assertEquals("x", attr.getName());
	}

	public void testMerge_keepAttributesFromEmpty() throws Exception {
		SomMerger merger = new SomMerger();
		merger.merge(TestObjectModelFactory.newSom_2());
		merger.merge(TestObjectModelFactory.newSom_1());
		ObjectModelIndexer index = new ObjectModelIndexer(merger.getFom().getObjectModel());

		ObjectClass a1 = index.getObjectClass("A_1");
		Attribute attr = (Attribute) a1.getAttributes().get(0);
		assertEquals("x", attr.getName());
	}

	public void testMerge_addingParametersToEmpty() throws Exception {
		SomMerger merger = new SomMerger();
		merger.merge(TestObjectModelFactory.newSom_1());
		merger.merge(TestObjectModelFactory.newSom_2());
		ObjectModelIndexer index = new ObjectModelIndexer(merger.getFom().getObjectModel());

		InteractionClass i1 = index.getInteractionClass("I_1");
		Parameter param = (Parameter) i1.getParameters().get(0);
		assertEquals("p1", param.getName());
	}

	public void testMerge_keepParametersFromEmpty() throws Exception {
		SomMerger merger = new SomMerger();
		merger.merge(TestObjectModelFactory.newSom_2());
		merger.merge(TestObjectModelFactory.newSom_1());
		ObjectModelIndexer index = new ObjectModelIndexer(merger.getFom().getObjectModel());

		InteractionClass i1 = index.getInteractionClass("I_1");
		Parameter param = (Parameter) i1.getParameters().get(0);
		assertEquals("p1", param.getName());
	}

	public void testMerge_differentAttributes() throws Exception {
		SomMerger merger = new SomMerger();
		merger.merge(TestObjectModelFactory.newSom_2());
		merger.merge(TestObjectModelFactory.newSom_3());
		assertEquals("Merging two object class with different attributes must cause errors", 2, merger
				.getErrors()
				.size());
	}

	public void testMerge_addMultipleSubclasses() throws Exception {
		SomMerger merger = new SomMerger();
		merger.merge(TestObjectModelFactory.newEmptySom());
		merger.merge(TestObjectModelFactory.newSom_4());
		ObjectModelIndexer index = new ObjectModelIndexer(merger.getFom().getObjectModel());
		assertNotNull(index.getObjectClass("A_1"));
		assertNotNull(index.getObjectClass("A_1.B_1"));
		assertNotNull(index.getInteractionClass("I_1"));
		assertNotNull(index.getInteractionClass("I_1.J_1"));
	}

	public void testname() throws Exception {
		URL lidFilterUrl = this.getClass().getClassLoader().getResource("org/eodisp/hla/resources/SOM_LidFilter.xml");
		URL simControllerUrl = this.getClass().getClassLoader().getResource(
				"org/eodisp/hla/resources/SOM_SimController.xml");

		OmtResourceFactoryImpl fact = new OmtResourceFactoryImpl();
		Resource lidFilterRes = fact.createResource(URI.createURI(lidFilterUrl.toURI().toString()));
		Resource simControllerRes = fact.createResource(URI.createURI(simControllerUrl.toURI().toString()));
		lidFilterRes.load(Collections.EMPTY_MAP);
		simControllerRes.load(Collections.EMPTY_MAP);
		DocumentRoot lidFilterDocumentRoot = (DocumentRoot) lidFilterRes.getContents().get(0);
		DocumentRoot simControllerDocumentRoot = (DocumentRoot) simControllerRes.getContents().get(0);
		// Util.print(System.out, lidFilterDocumentRoot);
		System.out.println(Util.toString(lidFilterDocumentRoot.getObjectModel()));
		System.out.println(Util.toString(simControllerDocumentRoot.getObjectModel()));

		SomMerger somMerger = new SomMerger();
		somMerger.merge(lidFilterDocumentRoot);
		somMerger.merge(simControllerDocumentRoot);

		System.out.println(Util.toString(somMerger.getFom().getObjectModel()));
		System.out.println(somMerger.getErrors());

		Util.print(System.out, somMerger.getFom());

	}
}
