/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.hla.crc;

import hla.rti1516.*;

import java.util.Arrays;

import org.eodisp.hla.common.handles.AttributeHandleSetImpl;
import org.eodisp.hla.crc.application.CrcApplication;
import org.eodisp.hla.crc.omt.TestOMTModel;
import org.eodisp.remote.application.RemoteAppModule;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class TestFederationExecution {
	private static Crc crc;

	private static CrcApplication crcApplication;

	private static final String FEDERATION_EXECUTION_NAME = "testFederationExecution";

	public final ObjectClassHandle A1;

	public final ObjectClassHandle B1;

	public final ObjectClassHandle B2;

	public final ObjectClassHandle C1;

	public final InteractionClassHandle I1;

	public final InteractionClassHandle J1;

	public final InteractionClassHandle J2;

	public final InteractionClassHandle K1;

	public final AttributeHandle X;

	public final AttributeHandle Y;

	public final AttributeHandle Z;

	public final AttributeHandle Q;

	public final AttributeHandleSet SET_XYZQ;

	public final AttributeHandleSet SET_XYQ;

	public final AttributeHandleSet SET_Q;

	public final AttributeHandleSet SET_XYZ;

	public final AttributeHandleSet SET_XY;

	public final AttributeHandleSet SET_X;

	public final AttributeHandle[] ARRAY_XYZQ;

	public final AttributeHandle[] ARRAY_XYQ;

	public final AttributeHandle[] ARRAY_Q;

	public final AttributeHandle[] ARRAY_XYZ;

	public final AttributeHandle[] ARRAY_XY;

	public final AttributeHandle[] ARRAY_X;

	public final AttributeHandle[] ARRAY_Y;

	public final ParameterHandle P1;

	public final ParameterHandle P2;

	public final ParameterHandle P3;

	public final ParameterHandle P4;

	private FederationExecution federationExecution;

	static {
		crcApplication = new CrcApplication();
		// Use tcp to start faster...
		crcApplication.execute(new String[] { "--transport", "tcp" });
		crc = crcApplication.getCrcAppModule().getCrc();
	}

	public static RemoteAppModule getRemoteAppModule() {
		return crcApplication.getRemoteAppModule();
	}

	public TestFederationExecution() throws Exception {

		byte[] FDD = new TestOMTModel().getAsByteArray();
		crc.destroyAllFederationExecutions();
		federationExecution = crc.createFederationExecution(FEDERATION_EXECUTION_NAME, FDD);
		A1 = federationExecution.getObjectClassHandle(TestOMTModel.A_1);
		B1 = federationExecution.getObjectClassHandle(TestOMTModel.A_1 + "." + TestOMTModel.B_1);
		B2 = federationExecution.getObjectClassHandle(TestOMTModel.A_1 + "." + TestOMTModel.B_2);
		C1 = federationExecution.getObjectClassHandle(TestOMTModel.A_1 + "." + TestOMTModel.B_1 + "."
				+ TestOMTModel.C_1);
		I1 = federationExecution.getInteractionClassHandle(TestOMTModel.I_1);
		J1 = federationExecution.getInteractionClassHandle(TestOMTModel.I_1 + "." + TestOMTModel.J_1);
		J2 = federationExecution.getInteractionClassHandle(TestOMTModel.I_1 + "." + TestOMTModel.J_2);
		K1 = federationExecution.getInteractionClassHandle(TestOMTModel.I_1 + "." + TestOMTModel.J_1 + "."
				+ TestOMTModel.K_1);
		X = federationExecution.getAttributeHandle(A1, TestOMTModel.X);
		Y = federationExecution.getAttributeHandle(A1, TestOMTModel.Y);
		Z = federationExecution.getAttributeHandle(B1, TestOMTModel.Z);
		Q = federationExecution.getAttributeHandle(B2, TestOMTModel.Q);
		P1 = federationExecution.getParameterHandle(I1, TestOMTModel.P1);
		P2 = federationExecution.getParameterHandle(I1, TestOMTModel.P2);
		P3 = federationExecution.getParameterHandle(J1, TestOMTModel.P3);
		P4 = federationExecution.getParameterHandle(J2, TestOMTModel.P4);

		ARRAY_Q = new AttributeHandle[] { Q };
		SET_Q = new AttributeHandleSetImpl();
		SET_Q.addAll(Arrays.asList(ARRAY_Q));

		ARRAY_XY = new AttributeHandle[] { X, Y };
		SET_XY = new AttributeHandleSetImpl();
		SET_XY.addAll(Arrays.asList(ARRAY_XY));

		ARRAY_XYZ = new AttributeHandle[] { X, Y, Z };
		SET_XYZ = new AttributeHandleSetImpl();
		SET_XYZ.addAll(Arrays.asList(ARRAY_XYZ));

		ARRAY_XYZQ = new AttributeHandle[] { X, Y, Z, Q };
		SET_XYZQ = new AttributeHandleSetImpl();
		SET_XYZQ.addAll(Arrays.asList(ARRAY_XYZQ));

		ARRAY_XYQ = new AttributeHandle[] { X, Y, Q };
		SET_XYQ = new AttributeHandleSetImpl();
		SET_XYQ.addAll(Arrays.asList(ARRAY_XYQ));

		ARRAY_X = new AttributeHandle[] { X };
		SET_X = new AttributeHandleSetImpl();
		SET_X.addAll(Arrays.asList(ARRAY_X));

		ARRAY_Y = new AttributeHandle[] { Y };
	}

	public FederationExecution getFederationExecution() {
		return federationExecution;
	}

	public static Crc getCrc() {
		return crc;
	}
}
