package org.eodisp.hla.crc;

import hla.rti1516.FederatesCurrentlyJoined;
import hla.rti1516.FederationExecutionAlreadyExists;
import hla.rti1516.FederationExecutionDoesNotExist;
import junit.framework.TestCase;

import org.eodisp.hla.common.crc.CrcRemote;
import org.eodisp.hla.common.crc.FederationExecutionRemote;
import org.eodisp.hla.crc.application.CrcApplication;
import org.eodisp.hla.crc.omt.TestOMTModel;

public class CrcTest extends TestCase {

	private static final String TEST_FEDERATION_1_EXECUTION_NAME = "testFederationExecution1";

	private static final String TEST_FEDERATION_2_EXECUTION_NAME = "testFederationExecution2";

	private byte[] FDD;

	private static CrcRemote crcRemote;
	private static Crc crc;
	
	static {
		CrcApplication crcApplication = new CrcApplication();
		// Use tcp to start faster...
		crcApplication.execute(new String[] { "--transport", "tcp" });
		crcRemote = crcApplication.getCrcAppModule().getCrcRemote();
		crc = crcApplication.getCrcAppModule().getCrc();
	}

	@Override
	protected void setUp() throws Exception {
		FDD = new TestOMTModel().getAsByteArray();
		crc.destroyAllFederationExecutions();
	}

	/**
	 * Test method for
	 * {@link org.eodisp.hla.crc.Crc#createFederationExecution(java.lang.String, byte[])}.
	 */
	public void testCreateFederationExecution() throws Exception {
		FederationExecutionRemote federationExecution1 = crcRemote.createFederationExecution(TEST_FEDERATION_1_EXECUTION_NAME, FDD);
		FederationExecutionRemote federationExecution2 = crcRemote.getFederationExecution(TEST_FEDERATION_1_EXECUTION_NAME);
		assertSame(federationExecution1, federationExecution2);
	}

	/**
	 * Test method for
	 * {@link org.eodisp.hla.crc.Crc#createFederationExecution(java.lang.String, byte[])}.
	 */
	public void testCreateFederationExecution_FederationExecutionAlreadyExists() throws Exception {
		try {
			crcRemote.createFederationExecution(TEST_FEDERATION_1_EXECUTION_NAME, FDD);
			crcRemote.createFederationExecution(TEST_FEDERATION_1_EXECUTION_NAME, FDD);
			fail("Expected FederationExecutionAlreadyExists exception");
		} catch (FederationExecutionAlreadyExists expected) {
			assertTrue(true);
		}
	}

	/**
	 * Test method for
	 * {@link org.eodisp.hla.crc.Crc#createFederationExecution(java.lang.String, byte[])}.
	 */

	public void testCreateFederation_NullPointerException() throws Exception {
		try {
			crcRemote.createFederationExecution(null, FDD);
			fail("Expected NullPointerException exception");
		} catch (NullPointerException expected) {
			assertTrue(true);
		}
	}

	/**
	 * Test method for
	 * {@link org.eodisp.hla.crc.Crc#createFederationExecution(java.lang.String, byte[])}.
	 */
	public void testCreateFederation_NullPointerException1() throws Exception {
		try {
			crcRemote.createFederationExecution(TEST_FEDERATION_1_EXECUTION_NAME, null);
			fail("Expected NullPointerException exception");
		} catch (NullPointerException expected) {
			assertTrue(true);
		}
	}

	public void testDestroyFederationExecution() throws Exception {
		crcRemote.createFederationExecution(TEST_FEDERATION_1_EXECUTION_NAME, FDD);
		crcRemote.destroyFederationExecution(TEST_FEDERATION_1_EXECUTION_NAME);
		assertTrue(crcRemote.getFederationExecution(TEST_FEDERATION_1_EXECUTION_NAME) == null);
	}

	public void testDestroyFederationExecution_FederationExecutionDoesNotExist() throws Exception {
		try {
			crcRemote.destroyFederationExecution(TEST_FEDERATION_1_EXECUTION_NAME);
			fail("Expected FederationExecutionDoesNotExist exception");
		} catch (FederationExecutionDoesNotExist expected) {
			assertTrue(true);
		}
	}
	
	public void testDestroyFederationExecution_FederatesCurrentlyJoined() throws Exception {
		try {
			FederationExecutionRemote federationExecution = crcRemote.createFederationExecution(TEST_FEDERATION_1_EXECUTION_NAME, FDD);
			crcRemote.joinFederationExecution(TEST_FEDERATION_1_EXECUTION_NAME, "type", crcRemote.registerLrc(new TestLrcRemote()), null);
			crcRemote.destroyFederationExecution(TEST_FEDERATION_1_EXECUTION_NAME);
			fail("Expected FederatesCurrentlyJoined exception");
		} catch (FederatesCurrentlyJoined expected) {
			assertTrue(true);
		}
	}

	/**
	 * Test method for {@link Crc#getFederationExecution(String)}
	 */
	public void testGetFederationExecution() throws Exception {
		FederationExecutionRemote federationExecution1 = crcRemote.createFederationExecution(TEST_FEDERATION_1_EXECUTION_NAME, FDD);
		FederationExecutionRemote federationExecution2 = crcRemote.createFederationExecution(TEST_FEDERATION_2_EXECUTION_NAME, FDD);
		assertEquals(crcRemote.getFederationExecution(TEST_FEDERATION_1_EXECUTION_NAME), federationExecution1);
		assertEquals(crcRemote.getFederationExecution(TEST_FEDERATION_2_EXECUTION_NAME), federationExecution2);
	}

}
