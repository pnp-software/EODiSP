/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.hla;

import hla.rti1516.*;

/**
 * @author ibirrer
 * @version $Id:$
 *
 */
public class TestFederateAmbassador implements FederateAmbassador {

	/**
	 * 
	 */
	public TestFederateAmbassador() {
		super();
		// TODO Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#synchronizationPointRegistrationSucceeded(java.lang.String)
	 */
	public void synchronizationPointRegistrationSucceeded(String synchronizationPointLabel)
			throws FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#synchronizationPointRegistrationFailed(java.lang.String, hla.rti1516.SynchronizationPointFailureReason)
	 */
	public void synchronizationPointRegistrationFailed(String synchronizationPointLabel,
			SynchronizationPointFailureReason reason) throws FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#announceSynchronizationPoint(java.lang.String, byte[])
	 */
	public void announceSynchronizationPoint(String synchronizationPointLabel, byte[] userSuppliedTag)
			throws FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#federationSynchronized(java.lang.String)
	 */
	public void federationSynchronized(String synchronizationPointLabel) throws FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#initiateFederateSave(java.lang.String)
	 */
	public void initiateFederateSave(String label) throws UnableToPerformSave, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#initiateFederateSave(java.lang.String, hla.rti1516.LogicalTime)
	 */
	public void initiateFederateSave(String label, LogicalTime time) throws InvalidLogicalTime, UnableToPerformSave,
			FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#federationSaved()
	 */
	public void federationSaved() throws FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#federationNotSaved(hla.rti1516.SaveFailureReason)
	 */
	public void federationNotSaved(SaveFailureReason reason) throws FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#federationSaveStatusResponse(hla.rti1516.FederateHandleSaveStatusPair[])
	 */
	public void federationSaveStatusResponse(FederateHandleSaveStatusPair[] response) throws FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#requestFederationRestoreSucceeded(java.lang.String)
	 */
	public void requestFederationRestoreSucceeded(String label) throws FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#requestFederationRestoreFailed(java.lang.String)
	 */
	public void requestFederationRestoreFailed(String label) throws FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#federationRestoreBegun()
	 */
	public void federationRestoreBegun() throws FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#initiateFederateRestore(java.lang.String, hla.rti1516.FederateHandle)
	 */
	public void initiateFederateRestore(String label, FederateHandle federateHandle)
			throws SpecifiedSaveLabelDoesNotExist, CouldNotInitiateRestore, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#federationRestored()
	 */
	public void federationRestored() throws FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#federationNotRestored(hla.rti1516.RestoreFailureReason)
	 */
	public void federationNotRestored(RestoreFailureReason reason) throws FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#federationRestoreStatusResponse(hla.rti1516.FederateHandleRestoreStatusPair[])
	 */
	public void federationRestoreStatusResponse(FederateHandleRestoreStatusPair[] response)
			throws FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#startRegistrationForObjectClass(hla.rti1516.ObjectClassHandle)
	 */
	public void startRegistrationForObjectClass(ObjectClassHandle theClass) throws ObjectClassNotPublished,
			FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#stopRegistrationForObjectClass(hla.rti1516.ObjectClassHandle)
	 */
	public void stopRegistrationForObjectClass(ObjectClassHandle theClass) throws ObjectClassNotPublished,
			FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#turnInteractionsOn(hla.rti1516.InteractionClassHandle)
	 */
	public void turnInteractionsOn(InteractionClassHandle theHandle) throws InteractionClassNotPublished,
			FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#turnInteractionsOff(hla.rti1516.InteractionClassHandle)
	 */
	public void turnInteractionsOff(InteractionClassHandle theHandle) throws InteractionClassNotPublished,
			FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#objectInstanceNameReservationSucceeded(java.lang.String)
	 */
	public void objectInstanceNameReservationSucceeded(String objectName) throws UnknownName, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#objectInstanceNameReservationFailed(java.lang.String)
	 */
	public void objectInstanceNameReservationFailed(String objectName) throws UnknownName, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#discoverObjectInstance(hla.rti1516.ObjectInstanceHandle, hla.rti1516.ObjectClassHandle, java.lang.String)
	 */
	public void discoverObjectInstance(ObjectInstanceHandle theObject, ObjectClassHandle theObjectClass,
			String objectName) throws CouldNotDiscover, ObjectClassNotRecognized, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#reflectAttributeValues(hla.rti1516.ObjectInstanceHandle, hla.rti1516.AttributeHandleValueMap, byte[], hla.rti1516.OrderType, hla.rti1516.TransportationType)
	 */
	public void reflectAttributeValues(ObjectInstanceHandle theObject, AttributeHandleValueMap theAttributes,
			byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport)
			throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotSubscribed, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#reflectAttributeValues(hla.rti1516.ObjectInstanceHandle, hla.rti1516.AttributeHandleValueMap, byte[], hla.rti1516.OrderType, hla.rti1516.TransportationType, hla.rti1516.RegionHandleSet)
	 */
	public void reflectAttributeValues(ObjectInstanceHandle theObject, AttributeHandleValueMap theAttributes,
			byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport, RegionHandleSet sentRegions)
			throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotSubscribed, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#reflectAttributeValues(hla.rti1516.ObjectInstanceHandle, hla.rti1516.AttributeHandleValueMap, byte[], hla.rti1516.OrderType, hla.rti1516.TransportationType, hla.rti1516.LogicalTime, hla.rti1516.OrderType)
	 */
	public void reflectAttributeValues(ObjectInstanceHandle theObject, AttributeHandleValueMap theAttributes,
			byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport, LogicalTime theTime,
			OrderType receivedOrdering) throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotSubscribed,
			FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#reflectAttributeValues(hla.rti1516.ObjectInstanceHandle, hla.rti1516.AttributeHandleValueMap, byte[], hla.rti1516.OrderType, hla.rti1516.TransportationType, hla.rti1516.LogicalTime, hla.rti1516.OrderType, hla.rti1516.RegionHandleSet)
	 */
	public void reflectAttributeValues(ObjectInstanceHandle theObject, AttributeHandleValueMap theAttributes,
			byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport, LogicalTime theTime,
			OrderType receivedOrdering, RegionHandleSet sentRegions) throws ObjectInstanceNotKnown,
			AttributeNotRecognized, AttributeNotSubscribed, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#reflectAttributeValues(hla.rti1516.ObjectInstanceHandle, hla.rti1516.AttributeHandleValueMap, byte[], hla.rti1516.OrderType, hla.rti1516.TransportationType, hla.rti1516.LogicalTime, hla.rti1516.OrderType, hla.rti1516.MessageRetractionHandle)
	 */
	public void reflectAttributeValues(ObjectInstanceHandle theObject, AttributeHandleValueMap theAttributes,
			byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport, LogicalTime theTime,
			OrderType receivedOrdering, MessageRetractionHandle retractionHandle) throws ObjectInstanceNotKnown,
			AttributeNotRecognized, AttributeNotSubscribed, InvalidLogicalTime, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#reflectAttributeValues(hla.rti1516.ObjectInstanceHandle, hla.rti1516.AttributeHandleValueMap, byte[], hla.rti1516.OrderType, hla.rti1516.TransportationType, hla.rti1516.LogicalTime, hla.rti1516.OrderType, hla.rti1516.MessageRetractionHandle, hla.rti1516.RegionHandleSet)
	 */
	public void reflectAttributeValues(ObjectInstanceHandle theObject, AttributeHandleValueMap theAttributes,
			byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport, LogicalTime theTime,
			OrderType receivedOrdering, MessageRetractionHandle retractionHandle, RegionHandleSet sentRegions)
			throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotSubscribed, InvalidLogicalTime,
			FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#receiveInteraction(hla.rti1516.InteractionClassHandle, hla.rti1516.ParameterHandleValueMap, byte[], hla.rti1516.OrderType, hla.rti1516.TransportationType)
	 */
	public void receiveInteraction(InteractionClassHandle interactionClass, ParameterHandleValueMap theParameters,
			byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport)
			throws InteractionClassNotRecognized, InteractionParameterNotRecognized, InteractionClassNotSubscribed,
			FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#receiveInteraction(hla.rti1516.InteractionClassHandle, hla.rti1516.ParameterHandleValueMap, byte[], hla.rti1516.OrderType, hla.rti1516.TransportationType, hla.rti1516.RegionHandleSet)
	 */
	public void receiveInteraction(InteractionClassHandle interactionClass, ParameterHandleValueMap theParameters,
			byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport, RegionHandleSet sentRegions)
			throws InteractionClassNotRecognized, InteractionParameterNotRecognized, InteractionClassNotSubscribed,
			FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#receiveInteraction(hla.rti1516.InteractionClassHandle, hla.rti1516.ParameterHandleValueMap, byte[], hla.rti1516.OrderType, hla.rti1516.TransportationType, hla.rti1516.LogicalTime, hla.rti1516.OrderType)
	 */
	public void receiveInteraction(InteractionClassHandle interactionClass, ParameterHandleValueMap theParameters,
			byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport, LogicalTime theTime,
			OrderType receivedOrdering) throws InteractionClassNotRecognized, InteractionParameterNotRecognized,
			InteractionClassNotSubscribed, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#receiveInteraction(hla.rti1516.InteractionClassHandle, hla.rti1516.ParameterHandleValueMap, byte[], hla.rti1516.OrderType, hla.rti1516.TransportationType, hla.rti1516.LogicalTime, hla.rti1516.OrderType, hla.rti1516.RegionHandleSet)
	 */
	public void receiveInteraction(InteractionClassHandle interactionClass, ParameterHandleValueMap theParameters,
			byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport, LogicalTime theTime,
			OrderType receivedOrdering, RegionHandleSet regions) throws InteractionClassNotRecognized,
			InteractionParameterNotRecognized, InteractionClassNotSubscribed, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#receiveInteraction(hla.rti1516.InteractionClassHandle, hla.rti1516.ParameterHandleValueMap, byte[], hla.rti1516.OrderType, hla.rti1516.TransportationType, hla.rti1516.LogicalTime, hla.rti1516.OrderType, hla.rti1516.MessageRetractionHandle)
	 */
	public void receiveInteraction(InteractionClassHandle interactionClass, ParameterHandleValueMap theParameters,
			byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport, LogicalTime theTime,
			OrderType receivedOrdering, MessageRetractionHandle messageRetractionHandle)
			throws InteractionClassNotRecognized, InteractionParameterNotRecognized, InteractionClassNotSubscribed,
			InvalidLogicalTime, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#receiveInteraction(hla.rti1516.InteractionClassHandle, hla.rti1516.ParameterHandleValueMap, byte[], hla.rti1516.OrderType, hla.rti1516.TransportationType, hla.rti1516.LogicalTime, hla.rti1516.OrderType, hla.rti1516.MessageRetractionHandle, hla.rti1516.RegionHandleSet)
	 */
	public void receiveInteraction(InteractionClassHandle interactionClass, ParameterHandleValueMap theParameters,
			byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport, LogicalTime theTime,
			OrderType receivedOrdering, MessageRetractionHandle messageRetractionHandle, RegionHandleSet sentRegions)
			throws InteractionClassNotRecognized, InteractionParameterNotRecognized, InteractionClassNotSubscribed,
			InvalidLogicalTime, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#removeObjectInstance(hla.rti1516.ObjectInstanceHandle, byte[], hla.rti1516.OrderType)
	 */
	public void removeObjectInstance(ObjectInstanceHandle theObject, byte[] userSuppliedTag, OrderType sentOrdering)
			throws ObjectInstanceNotKnown, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#removeObjectInstance(hla.rti1516.ObjectInstanceHandle, byte[], hla.rti1516.OrderType, hla.rti1516.LogicalTime, hla.rti1516.OrderType)
	 */
	public void removeObjectInstance(ObjectInstanceHandle theObject, byte[] userSuppliedTag, OrderType sentOrdering,
			LogicalTime theTime, OrderType receivedOrdering) throws ObjectInstanceNotKnown, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#removeObjectInstance(hla.rti1516.ObjectInstanceHandle, byte[], hla.rti1516.OrderType, hla.rti1516.LogicalTime, hla.rti1516.OrderType, hla.rti1516.MessageRetractionHandle)
	 */
	public void removeObjectInstance(ObjectInstanceHandle theObject, byte[] userSuppliedTag, OrderType sentOrdering,
			LogicalTime theTime, OrderType receivedOrdering, MessageRetractionHandle retractionHandle)
			throws ObjectInstanceNotKnown, InvalidLogicalTime, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#attributesInScope(hla.rti1516.ObjectInstanceHandle, hla.rti1516.AttributeHandleSet)
	 */
	public void attributesInScope(ObjectInstanceHandle theObject, AttributeHandleSet theAttributes)
			throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotSubscribed, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#attributesOutOfScope(hla.rti1516.ObjectInstanceHandle, hla.rti1516.AttributeHandleSet)
	 */
	public void attributesOutOfScope(ObjectInstanceHandle theObject, AttributeHandleSet theAttributes)
			throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotSubscribed, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#provideAttributeValueUpdate(hla.rti1516.ObjectInstanceHandle, hla.rti1516.AttributeHandleSet, byte[])
	 */
	public void provideAttributeValueUpdate(ObjectInstanceHandle theObject, AttributeHandleSet theAttributes,
			byte[] userSuppliedTag) throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotOwned,
			FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#turnUpdatesOnForObjectInstance(hla.rti1516.ObjectInstanceHandle, hla.rti1516.AttributeHandleSet)
	 */
	public void turnUpdatesOnForObjectInstance(ObjectInstanceHandle theObject, AttributeHandleSet theAttributes)
			throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotOwned, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#turnUpdatesOffForObjectInstance(hla.rti1516.ObjectInstanceHandle, hla.rti1516.AttributeHandleSet)
	 */
	public void turnUpdatesOffForObjectInstance(ObjectInstanceHandle theObject, AttributeHandleSet theAttributes)
			throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotOwned, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#requestAttributeOwnershipAssumption(hla.rti1516.ObjectInstanceHandle, hla.rti1516.AttributeHandleSet, byte[])
	 */
	public void requestAttributeOwnershipAssumption(ObjectInstanceHandle theObject,
			AttributeHandleSet offeredAttributes, byte[] userSuppliedTag) throws ObjectInstanceNotKnown,
			AttributeNotRecognized, AttributeAlreadyOwned, AttributeNotPublished, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#requestDivestitureConfirmation(hla.rti1516.ObjectInstanceHandle, hla.rti1516.AttributeHandleSet)
	 */
	public void requestDivestitureConfirmation(ObjectInstanceHandle theObject, AttributeHandleSet offeredAttributes)
			throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotOwned,
			AttributeDivestitureWasNotRequested, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#attributeOwnershipAcquisitionNotification(hla.rti1516.ObjectInstanceHandle, hla.rti1516.AttributeHandleSet, byte[])
	 */
	public void attributeOwnershipAcquisitionNotification(ObjectInstanceHandle theObject,
			AttributeHandleSet securedAttributes, byte[] userSuppliedTag) throws ObjectInstanceNotKnown,
			AttributeNotRecognized, AttributeAcquisitionWasNotRequested, AttributeAlreadyOwned, AttributeNotPublished,
			FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#attributeOwnershipUnavailable(hla.rti1516.ObjectInstanceHandle, hla.rti1516.AttributeHandleSet)
	 */
	public void attributeOwnershipUnavailable(ObjectInstanceHandle theObject, AttributeHandleSet theAttributes)
			throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeAlreadyOwned,
			AttributeAcquisitionWasNotRequested, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#requestAttributeOwnershipRelease(hla.rti1516.ObjectInstanceHandle, hla.rti1516.AttributeHandleSet, byte[])
	 */
	public void requestAttributeOwnershipRelease(ObjectInstanceHandle theObject,
			AttributeHandleSet candidateAttributes, byte[] userSuppliedTag) throws ObjectInstanceNotKnown,
			AttributeNotRecognized, AttributeNotOwned, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#confirmAttributeOwnershipAcquisitionCancellation(hla.rti1516.ObjectInstanceHandle, hla.rti1516.AttributeHandleSet)
	 */
	public void confirmAttributeOwnershipAcquisitionCancellation(ObjectInstanceHandle theObject,
			AttributeHandleSet theAttributes) throws ObjectInstanceNotKnown, AttributeNotRecognized,
			AttributeAlreadyOwned, AttributeAcquisitionWasNotCanceled, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#informAttributeOwnership(hla.rti1516.ObjectInstanceHandle, hla.rti1516.AttributeHandle, hla.rti1516.FederateHandle)
	 */
	public void informAttributeOwnership(ObjectInstanceHandle theObject, AttributeHandle theAttribute,
			FederateHandle theOwner) throws ObjectInstanceNotKnown, AttributeNotRecognized, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#attributeIsNotOwned(hla.rti1516.ObjectInstanceHandle, hla.rti1516.AttributeHandle)
	 */
	public void attributeIsNotOwned(ObjectInstanceHandle theObject, AttributeHandle theAttribute)
			throws ObjectInstanceNotKnown, AttributeNotRecognized, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#attributeIsOwnedByRTI(hla.rti1516.ObjectInstanceHandle, hla.rti1516.AttributeHandle)
	 */
	public void attributeIsOwnedByRTI(ObjectInstanceHandle theObject, AttributeHandle theAttribute)
			throws ObjectInstanceNotKnown, AttributeNotRecognized, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#timeRegulationEnabled(hla.rti1516.LogicalTime)
	 */
	public void timeRegulationEnabled(LogicalTime time) throws InvalidLogicalTime,
			NoRequestToEnableTimeRegulationWasPending, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#timeConstrainedEnabled(hla.rti1516.LogicalTime)
	 */
	public void timeConstrainedEnabled(LogicalTime time) throws InvalidLogicalTime,
			NoRequestToEnableTimeConstrainedWasPending, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#timeAdvanceGrant(hla.rti1516.LogicalTime)
	 */
	public void timeAdvanceGrant(LogicalTime theTime) throws InvalidLogicalTime,
			JoinedFederateIsNotInTimeAdvancingState, FederateInternalError {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see hla.rti1516.FederateAmbassador#requestRetraction(hla.rti1516.MessageRetractionHandle)
	 */
	public void requestRetraction(MessageRetractionHandle theHandle) throws FederateInternalError {
		// TODO Auto-generated method stub

	}

}
