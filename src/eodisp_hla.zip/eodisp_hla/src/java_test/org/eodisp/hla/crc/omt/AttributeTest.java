package org.eodisp.hla.crc.omt;

import junit.framework.TestCase;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;

public class AttributeTest extends TestCase {

	/**
	 * the test model
	 */
	private TestOMTModel testOmtModel;

	/**
	 * Sets the logger and creates a test model.
	 * 
	 * @see TestOMTModel
	 */
	@Override
	protected void setUp() {
		Logger.getRootLogger().addAppender(
				new ConsoleAppender(new PatternLayout("%r [%t] %p %l %x - %m%n"), "System.out"));
		
		testOmtModel = new TestOMTModel();
	}

	/**
	 * Tests the getObjectClass of each attribute defined in the TestOMTModel
	 * 
	 * @throws Exception
	 */
	public void testGetObjectClass() {
		assertSame(testOmtModel.hlaObjectRoot, testOmtModel.hlaPrivilegeToDeleteObject.getObjectClass());
		assertSame(testOmtModel.a1, testOmtModel.x.getObjectClass());
		assertSame(testOmtModel.a1, testOmtModel.y.getObjectClass());
		assertSame(testOmtModel.b1, testOmtModel.z.getObjectClass());
		assertSame(testOmtModel.b2, testOmtModel.q.getObjectClass());
	}
	
	public void testIsAvailableFrom() throws Exception {
		assertTrue( testOmtModel.x.isAvailableFrom(testOmtModel.a1) );
		assertTrue( testOmtModel.x.isAvailableFrom(testOmtModel.b1) );
		assertTrue( testOmtModel.x.isAvailableFrom(testOmtModel.b2) );
		assertTrue( testOmtModel.x.isAvailableFrom(testOmtModel.c1) );
		assertFalse( testOmtModel.x.isAvailableFrom(testOmtModel.hlaObjectRoot) );
	}

}
