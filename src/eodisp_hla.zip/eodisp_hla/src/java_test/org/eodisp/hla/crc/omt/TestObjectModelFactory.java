/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.hla.crc.omt;

import org.eodisp.hla.crc.omt.util.ObjectModelIndexer;
import org.eodisp.hla.crc.omt.util.Util;

/**
 * An OMT model for testing purposes. The model has the following structure:
 * 
 * <pre>
 *                                      HLAobjectRoot
 *                                          _|_________
 *                                         |           |
 *                                        A_1         A_2
 *                                       (x,y)       
 *                                        _|___
 *                                       |     |
 *                                      B_1   B_2
 *                                      (z)   (q)
 *                                       |     | 
 *                                      C_1   C_2
 *                                            _|__
 *                                           |    |
 *                                          D_1  D_2
 *                                              
 *                                      
 *                                      HLAinteractionRoot
 *                                         |
 *                                        I_1
 *                                      (p1,p2)
 *                                        _|___
 *                                       |     |
 *                                      J_1   J_2
 *                                      (p3)  (p4)
 *                                       |
 *                                      K_1
 *                                      
 * </pre>
 * 
 * The following attributes are defined for the given object classes:
 * <ul>
 * <li>HLAobjectRoot: HLAprivilegeToDeleteObject</li>
 * <li>A_1: x,y</li>
 * <li>B_1: z</li>
 * <li>B_2: q</li>
 * <li>C_1: none</li>
 * </ul>
 * 
 * The following parameters are defined for the given interaction classes:
 * <ul>
 * <li>HLAobjectRoot: HLAprivilegeToDeleteObject</li>
 * <li>I_1: p1,p2</li>
 * <li>J_1: p3</li>
 * <li>J_2: p4</li>
 * <li>K_1: none</li>
 * </ul>
 * 
 * @author ibirrer
 * @version $Id:$
 */
public class TestObjectModelFactory {
	private TestObjectModelFactory() {

	}

	public static DocumentRoot newEmptySom() {
		DocumentRoot documentRoot = OmtFactory.eINSTANCE.createDocumentRoot();
		ObjectModel objectModel = OmtFactory.eINSTANCE.createObjectModel();
		objectModel.setName("TestSOM");
		objectModel.setType(ObjectModelTypeEnum.SOM_LITERAL);
		documentRoot.setObjectModel(objectModel);

		// Object classes
		Objects objects = OmtFactory.eINSTANCE.createObjects();
		objectModel.setObjects(objects);
		ObjectClass hlaObjectRoot = OmtFactory.eINSTANCE.createObjectClass();
		objects.getObjectClass().add(hlaObjectRoot);
		hlaObjectRoot.setName(ObjectClass.HLA_OBJECT_ROOT_NAME);
		
		// Interaction classes
		Interactions interactions = OmtFactory.eINSTANCE.createInteractions();
		objectModel.setInteractions(interactions);
		InteractionClass rootInteraction = OmtFactory.eINSTANCE.createInteractionClass();
		rootInteraction.setName(InteractionClass.HLA_INTERACTION_ROOT_NAME);
		interactions.getInteractionClass().add(rootInteraction);
		
		
		return documentRoot;
	}

	public static DocumentRoot newSom_1() {
		DocumentRoot documentRoot = newEmptySom();
		ObjectModelIndexer somIndex = new ObjectModelIndexer(documentRoot.getObjectModel());

		// object classes
		ObjectClass objectRoot = somIndex.getObjectClass(ObjectClass.HLA_OBJECT_ROOT_NAME);
		ObjectClass a1 = OmtFactory.eINSTANCE.createObjectClass();
		a1.setName("A_1");
		objectRoot.getSubClasses().add(a1);

		// interaction classes
		InteractionClass interactionRoot = somIndex.getInteractionClass(InteractionClass.HLA_INTERACTION_ROOT_NAME);
		InteractionClass i1 = OmtFactory.eINSTANCE.createInteractionClass();
		i1.setName("I_1");
		interactionRoot.getSubClasses().add(i1);

		return documentRoot;

	}

	public static DocumentRoot newSom_2() {
		DocumentRoot documentRoot = newSom_1();
		ObjectModelIndexer somIndex = new ObjectModelIndexer(documentRoot.getObjectModel());
		ObjectClass a1 = somIndex.getObjectClass("A_1");
		Attribute x = OmtFactory.eINSTANCE.createAttribute();
		x.setName("x");
		a1.getAttributes().add(x);		
		
		
		
		InteractionClass i1 = somIndex.getInteractionClass("I_1");
		Parameter p1 = OmtFactory.eINSTANCE.createParameter();
		p1.setName("p1");
		i1.getParameters().add(p1);
		return documentRoot;
		
		
	}
	
	public static DocumentRoot newSom_3() {
		DocumentRoot documentRoot = newSom_1();
		ObjectModelIndexer somIndex = new ObjectModelIndexer(documentRoot.getObjectModel());
		ObjectClass a1 = somIndex.getObjectClass("A_1");
		Attribute y = OmtFactory.eINSTANCE.createAttribute();
		y.setName("y");
		a1.getAttributes().add(y);		
		
		InteractionClass i1 = somIndex.getInteractionClass("I_1");
		Parameter p2 = OmtFactory.eINSTANCE.createParameter();
		p2.setName("p2");
		i1.getParameters().add(p2);
		return documentRoot;
	}
	
	public static DocumentRoot newSom_4() {
		DocumentRoot documentRoot = newSom_2();
		ObjectModelIndexer somIndex = new ObjectModelIndexer(documentRoot.getObjectModel());
		
		ObjectClass a1 = somIndex.getObjectClass("A_1");
		ObjectClass b1 = OmtFactory.eINSTANCE.createObjectClass();
		b1.setName("B_1");
		a1.getSubClasses().add(b1);
		
		
		InteractionClass i1 = somIndex.getInteractionClass("I_1");
		InteractionClass j1 = OmtFactory.eINSTANCE.createInteractionClass();
		j1.setName("J_1");
		i1.getSubClasses().add(j1);

		return documentRoot;

	}

	

	public static DocumentRoot newObjectModel_3() {
		TestOMTModel testOMTModel = new TestOMTModel();

		ObjectModel objectModel = testOMTModel.getObjectModel();
		ObjectModelIndexer objectModelIndex = new ObjectModelIndexer(objectModel);

		ObjectClass root = objectModelIndex.getObjectClass("HLAobjectRoot");
		ObjectClass a2 = OmtFactory.eINSTANCE.createObjectClass();
		a2.setName("A_2");
		root.getSubClasses().add(a2);

		ObjectClass b2 = objectModelIndex.getObjectClass("A_1.B_2");

		ObjectClass c2 = OmtFactory.eINSTANCE.createObjectClass();
		c2.setName("C_2");
		b2.getSubClasses().add(c2);

		ObjectClass c3 = OmtFactory.eINSTANCE.createObjectClass();
		c3.setName("C_3");
		b2.getSubClasses().add(c3);

		ObjectClass d1 = OmtFactory.eINSTANCE.createObjectClass();
		d1.setName("D_1");
		c2.getSubClasses().add(d1);

		ObjectClass d2 = OmtFactory.eINSTANCE.createObjectClass();
		d2.setName("D_2");
		c2.getSubClasses().add(d2);

		ObjectClass e1 = OmtFactory.eINSTANCE.createObjectClass();
		e1.setName("E_1");
		d2.getSubClasses().add(e1);

		ObjectClass e2 = OmtFactory.eINSTANCE.createObjectClass();
		e2.setName("E_2");
		d2.getSubClasses().add(e2);

		InteractionClass i1 = objectModelIndex.getInteractionClass("I_1");
		Parameter param = OmtFactory.eINSTANCE.createParameter();
		param.setName("wrong");
		i1.getParameters().add(param);

		return testOMTModel.getDocumentRoot();
	}
}
