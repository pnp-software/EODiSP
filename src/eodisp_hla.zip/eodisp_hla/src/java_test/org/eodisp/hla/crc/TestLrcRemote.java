/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.hla.crc;

import hla.rti1516.*;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;

import org.eodisp.hla.common.lrc.LrcRemote;

final class TestLrcRemote implements LrcRemote, Serializable {

	public void announceSynchronizationPoint(String synchronizationPointLabel, byte[] userSuppliedTag, FederateHandle[] federateHandles, String fedreationExecutionName) throws FederateInternalError, RemoteException {
		// TODO Auto-generated method stub
		
	}

	public void discoverObjectInstance(ObjectInstanceHandle theObject, ObjectClassHandle theObjectClass, String objectName, FederateHandle[] federateHandles, String federationExecutionName) throws CouldNotDiscover, ObjectClassNotRecognized, FederateInternalError, RemoteException {
		// TODO Auto-generated method stub
		
	}

	public void federationSynchronized(String synchronizationPointLabel, FederateHandle[] federateHandles, String federationExecutionName, byte[] userSuppliedTag) throws FederateInternalError, RemoteException {
		// TODO Auto-generated method stub
		
	}

	public void provideAttributeValueUpdate(ObjectInstanceHandle theObject, AttributeHandleSet theAttributes, byte[] userSuppliedTag, FederateHandle[] federateHandles, String federationExecutionName) throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotOwned, FederateInternalError, RemoteException {
		// TODO Auto-generated method stub
		
	}

	public void receiveInteraction(InteractionClassHandle interactionClass, ParameterHandleValueMap theParameters, byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport, FederateHandle[] federateHandles, String federationExecutionName) throws InteractionClassNotRecognized, InteractionParameterNotRecognized, InteractionClassNotSubscribed, FederateInternalError, RemoteException {
		// TODO Auto-generated method stub
		
	}

	public void reflectAttributeValues(ObjectInstanceHandle objectInstanceHandle, HashMap<AttributeHandle, byte[]> values, byte[] userSuppliedTag, HashMap<FederateHandle, AttributeHandle[]> federateSubscriptions, String federationExecutionName) throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotSubscribed, FederateInternalError, RemoteException {
		// TODO Auto-generated method stub
		
	}

	public void startRegistrationForObjectClass(String federationExecutionName, ObjectClassHandle objectClassHandle, FederateHandle[] federateHandles) throws RemoteException, ObjectClassNotPublished, FederateInternalError {
		// TODO Auto-generated method stub
		
	}

	public void synchronizationPointRegistrationFailed(String synchronizationPointLabel, SynchronizationPointFailureReason reason, FederateHandle federateHandle, String federationExecutionName) throws FederateInternalError, RemoteException {
		// TODO Auto-generated method stub
		
	}

	public void synchronizationPointRegistrationSucceeded(String synchronizationPointLabel, FederateHandle federateHandle, String federationExecutionName) throws FederateInternalError, RemoteException {
		// TODO Auto-generated method stub
		
	}

	public void reflectAttributeValues(ObjectInstanceHandle objectInstanceHandle, Map<AttributeHandle, byte[]> values, byte[] userSuppliedTag, Map<FederateHandle, AttributeHandle[]> federateSubscriptions, String federationExecutionName) throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotSubscribed, FederateInternalError, RemoteException {
		// TODO Auto-generated method stub
		
	}

	
}