/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.hla.lrc;

import java.net.URI;
import java.rmi.NotBoundException;

import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.remote.config.RemoteConfiguration;
import org.eodisp.remote.config.RemoteConfiguration.TransportType;
import org.eodisp.remote.launcher.TestRootApp;
import org.eodisp.remote.registry.JeriRegistry;
import org.eodisp.util.FileUtil;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class StartCrcs {
	private static final String FEDERATION_EXECUTION_NAME = "LrcRtiAmbassadorTest Federation Execution";

	/**
	 * @param args
	 * @throws NotBoundException
	 * @throws
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		TransportType transportType = TransportType.JXTA;

		System.setProperty("org.eodisp.working-dir", FileUtil
				.createTempDir("TestConnections", "", null)
				.getAbsolutePath());
		System.setProperty("org.eodisp.log-level", "debug");
		System.setProperty("org.eodisp.remote.transport", transportType.toString());

		TestRootApp testRootApp = new TestRootApp();
		testRootApp.execute(new String[] {});

		RemoteConfiguration remoteConfiguration = (RemoteConfiguration) testRootApp
				.getConfiguration(RemoteConfiguration.ID);
		remoteConfiguration.setJeriConnectionTimeout(60 * 1000);
		// Get launch server
		RemoteAppModule remoteAppModule = (RemoteAppModule) testRootApp.getAppModule(RemoteAppModule.ID);
		// local
		// Registry launchServerRegistry = remoteAppModule.getRegistry(URI
		// .create("urn:jxta:uuid-59616261646162614E5047205032503375A27074EDCB4BCAA2B9D2D0868DE40203"));

		// local tcp
		// Registry launchServerRegistry =
		// remoteAppModule.getRegistry(URI.create("tcp://localhost:22000"));
		
		// local jxta
		JeriRegistry launchServerRegistry = remoteAppModule.getRegistry(URI
				.create("urn:jxta:uuid-59616261646162614E5047205032503375A27074EDCB4BCAA2B9D2D0868DE40203"));
		// windows

//		JeriRegistry launchServerRegistry = remoteAppModule.getRegistry(URI
//				.create("urn:jxta:uuid-59616261646162614E504720503250334F74944E00F44BCCA5DFE08BD766FE5703"));

		System.out.println("Connected to: " + launchServerRegistry.getUri(transportType)
				+ ". Wait for 60 seconds to go on...");
		Thread.sleep(60000);
		System.out.println("Start now:");
		int count = 0;
		long now = System.currentTimeMillis();
		while (true) {
			final URI uri = launchServerRegistry.getUri(transportType);
			if (count++ % 10 == 0) {
				long duration = System.currentTimeMillis() - now;
				
				int durationInSecons = (int) (duration / 1000);
				if (durationInSecons == 0) {
					durationInSecons = 1;
					System.out.println("duration set to 1");
				}
				System.out.printf(
						"%d: [%d ms, %d c/s] Call method on: %s%n",
						count,
						duration,
						count / durationInSecons,
						uri);
			}
		}

		// eodisp.org
		// Registry launchServerRegistry = remoteAppModule.getRegistry(URI
		// .create("urn:jxta:uuid-59616261646162614E504720503250335C331BF7D2AB45719BA7C9ED0E0615E903"));

		//		
		//		
		// LaunchServerRemote launchServerRemote = (LaunchServerRemote)
		// launchServerRegistry
		// .lookup(LaunchServerRemoteImpl.REGISTRY_NAME);
		// System.out.println(launchServerRemote);
		// CrcProcessFactoryRemote crcProcessFactoryRemote =
		// (CrcProcessFactoryRemote) launchServerRemote
		// .newProcessFactory(CrcProcessFactoryRemote.FACTORY_ID);
		//
		// crcProcessFactoryRemote.setTransports(EnumSet.of(transportType));
		// List<CrcRemote> crcs = new ArrayList<CrcRemote>();
		// for (int i = 0; i < 10; i++) {
		//
		// RootAppProcessRemote crcProcessRemote = (RootAppProcessRemote)
		// crcProcessFactoryRemote.newProcess();
		//
		// Map<TransportType, JeriRegistry> crcRegistries;
		// System.out.println("JUnit: Starting CRC ...");
		// if ((crcRegistries = crcProcessRemote.launchBlocking(120,
		// TimeUnit.SECONDS)) == null) {
		// System.err.println("Could not start crcRemote Process");
		// }
		//
		// final JeriRegistry crcJeriRegistry =
		// crcRegistries.get(transportType);
		// CrcRemote crcRemote = (CrcRemote)
		// crcJeriRegistry.lookup(CrcRemote.REGISTRY_NAME);
		// crcs.add(crcRemote);
		// System.out.println(String.format("JUnit: Started CRC at %s",
		// crcJeriRegistry.getUri(transportType)));
		// }

		// for (CrcRemote remote : crcs) {
		// System.out.println(String.format("Exit %s", remote));
		// remote.shutdownAndExit();
		// }
		// AppRegistry.getRootApp().shutdown();
	}
}
