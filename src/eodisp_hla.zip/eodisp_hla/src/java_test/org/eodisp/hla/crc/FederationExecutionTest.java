package org.eodisp.hla.crc;

import hla.rti1516.*;

import java.util.*;

import junit.framework.TestCase;

import org.eodisp.hla.common.lrc.LrcHandle;
import org.eodisp.hla.crc.data.Federate;
import org.eodisp.hla.crc.omt.Attribute;

public class FederationExecutionTest extends TestCase {

	public void testPublishObjectClassAttributes() throws Exception {
		TestFederationExecution testFederationExecution = new TestFederationExecution();
		FederationExecution federationExecution = testFederationExecution.getFederationExecution();
		FederateHandle federateHandle = federationExecution.join("type", new LrcHandle(0), null);
		
		federationExecution.publishObjectClassAttributes(
				testFederationExecution.B1,
				testFederationExecution.ARRAY_XYZ,
				federateHandle);

		Federate federate = federationExecution.getFederate(federateHandle);
		assertEquals(3, federate.getPublishedAttributes().size());

		Federate publishingFederate1 = (Federate) federationExecution.getAttribute(
				testFederationExecution.B1,
				testFederationExecution.X).getPublishingFederates().get(0);
		Federate publishingFederate2 = (Federate) federationExecution.getAttribute(
				testFederationExecution.B1,
				testFederationExecution.Y).getPublishingFederates().get(0);
		Federate publishingFederate3 = (Federate) federationExecution.getAttribute(
				testFederationExecution.B1,
				testFederationExecution.Z).getPublishingFederates().get(0);
		assertSame(federateHandle, publishingFederate1.getHandle());
		assertSame(federateHandle, publishingFederate2.getHandle());
		assertSame(federateHandle, publishingFederate3.getHandle());
		
		federationExecution.publishObjectClassAttributes(
				testFederationExecution.B2,
				testFederationExecution.ARRAY_Q,
				federateHandle);
		
		federationExecution.publishObjectClassAttributes(
				testFederationExecution.B2,
				testFederationExecution.ARRAY_Q,
				federateHandle);
		System.out.println(federate.getPublishedAttributes());

		assertEquals(4, federate.getPublishedAttributes().size());
	}
	
	public void testUnpublishObjectClassAttributes() throws Exception {
		TestFederationExecution testFederationExecution = new TestFederationExecution();
		FederationExecution federationExecution = testFederationExecution.getFederationExecution();
		FederateHandle federateHandle = federationExecution.join("type", new LrcHandle(0), null);
		
		federationExecution.publishObjectClassAttributes(
				testFederationExecution.B1,
				testFederationExecution.ARRAY_XYZ,
				federateHandle);
		
		federationExecution.unpublishObjectClassAttributes(testFederationExecution.B1, testFederationExecution.ARRAY_X, federateHandle);

		Federate federate = federationExecution.getFederate(federateHandle);
		assertEquals(2, federate.getPublishedAttributes().size());

		Federate publishingFederate2 = (Federate) federationExecution.getAttribute(
				testFederationExecution.B1,
				testFederationExecution.Y).getPublishingFederates().get(0);
		Federate publishingFederate3 = (Federate) federationExecution.getAttribute(
				testFederationExecution.B1,
				testFederationExecution.Z).getPublishingFederates().get(0);
		assertSame(federateHandle, publishingFederate2.getHandle());
		assertSame(federateHandle, publishingFederate3.getHandle());
	}

	public void testPublishObjectClassAttributes_AttributeNotDefined() throws Exception {
		TestFederationExecution testFederationExecution = new TestFederationExecution();
		FederationExecution federationExecution = testFederationExecution.getFederationExecution();
		FederateHandle federateHandle = federationExecution.join("type", new LrcHandle(0), null);

		try {
			federationExecution.publishObjectClassAttributes(
					testFederationExecution.A1,
					testFederationExecution.ARRAY_XYZQ,
					federateHandle);
			fail("Expected AttributeNotDefined exception");
		} catch (AttributeNotDefined expected) {
			assertTrue(true);
		}
	}

	public void testGetAttribute() throws Exception {
		TestFederationExecution testFederationExecution = new TestFederationExecution();
		FederationExecution federationExecution = testFederationExecution.getFederationExecution();
		assertEquals("A_1.x", federationExecution
				.getAttribute(testFederationExecution.B1, testFederationExecution.X)
				.getQualifiedName(true));
	}

	public void testGetAttributes() throws Exception {
		TestFederationExecution testFederationExecution = new TestFederationExecution();
		FederationExecution federationExecution = testFederationExecution.getFederationExecution();
		Set<Attribute> attributes = federationExecution.getAttributes(
				testFederationExecution.B1,
				testFederationExecution.ARRAY_XYZ);

		List<Attribute> sortedList = new ArrayList<Attribute>();
		sortedList.addAll(attributes);
		Collections.sort(sortedList, new Comparator<Attribute>() {
			public int compare(Attribute o1, Attribute o2) {
				return o1.getQualifiedName(true).compareTo(o2.getQualifiedName(true));
			}
		});

		assertEquals(3, attributes.size());
		assertEquals(sortedList.get(0).getQualifiedName(true), "A_1.B_1.z");
		assertEquals(sortedList.get(1).getQualifiedName(true), "A_1.x");
		assertEquals(sortedList.get(2).getQualifiedName(true), "A_1.y");
	}

	public void testGetAttributes1() throws Exception {
		TestFederationExecution testFederationExecution = new TestFederationExecution();
		FederationExecution federationExecution = testFederationExecution.getFederationExecution();
		Set<Attribute> attributes = federationExecution
				.getAttributes(testFederationExecution.B1, new AttributeHandle[] { testFederationExecution.X,
						testFederationExecution.Y, testFederationExecution.Z });

		List<Attribute> sortedList = new ArrayList<Attribute>();
		sortedList.addAll(attributes);
		Collections.sort(sortedList, new Comparator<Attribute>() {
			public int compare(Attribute o1, Attribute o2) {
				return o1.getQualifiedName(true).compareTo(o2.getQualifiedName(true));
			}
		});

		assertEquals(3, attributes.size());
		assertEquals(sortedList.get(0).getQualifiedName(true), "A_1.B_1.z");
		assertEquals(sortedList.get(1).getQualifiedName(true), "A_1.x");
		assertEquals(sortedList.get(2).getQualifiedName(true), "A_1.y");
	}
	
}
