package org.eodisp.hla.lrc;

import hla.rti1516.*;
import hla.rti1516.jlc.NullFederateAmbassador;
import hla.rti1516.jlc.RtiFactoryFactory;

import java.net.URI;
import java.rmi.registry.Registry;
import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

import org.eodisp.hla.TestFederateAmbassador;
import org.eodisp.hla.common.crc.CrcRemote;
import org.eodisp.hla.common.handles.AttributeHandleSetImpl;
import org.eodisp.hla.common.handles.AttributeHandleValueMapImpl;
import org.eodisp.hla.crc.launcher.CrcProcessFactoryRemote;
import org.eodisp.hla.crc.omt.TestOMTModel;
import org.eodisp.hla.lrc.application.LrcAppModule;
import org.eodisp.hla.lrc.application.LrcApplication;
import org.eodisp.hla.lrc.application.LrcConfiguration;
import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.remote.config.RemoteConfiguration;
import org.eodisp.remote.config.RemoteConfiguration.TransportType;
import org.eodisp.remote.launcher.RootAppProcessRemote;
import org.eodisp.remote.launcher.server.LaunchServerRemote;
import org.eodisp.remote.launcher.server.LaunchServerRemoteImpl;
import org.eodisp.remote.registry.JeriRegistry;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.FileUtil;
import org.eodisp.util.junit.FixtureTestCase;

public class LrcRtiAmbassadorTest extends FixtureTestCase {
	private static final String SYNC_POINT_1 = "syncPoint_1";

	private static final String FEDERATION_EXECUTION_NAME = "LrcRtiAmbassadorTest Federation Execution";

	private RTIambassador rtiAmbassador1;

	private volatile boolean errorFlag = true;

	private AtomicLong totalBytesTransferred = new AtomicLong(0);

	private static CrcRemote crcRemote;

	@Override
	protected void setUpFixture() throws Exception {
		TransportType transportType = TransportType.JXTA;

		System.setProperty("org.eodisp.working-dir", FileUtil.createTempDir("LrcTmp", "", null).getAbsolutePath());
		System.setProperty("org.eodisp.log-level", "debug");
		System.setProperty("org.eodisp.remote.transport", transportType.toString());

		LrcApplication lrcApplication = new LrcApplication();
		lrcApplication.execute(new String[] {});

		RemoteConfiguration remoteConfiguration = (RemoteConfiguration) lrcApplication
				.getConfiguration(RemoteConfiguration.ID);
		remoteConfiguration.setJeriConnectionTimeout(120 * 1000);
		// Get launch server
		RemoteAppModule remoteAppModule = (RemoteAppModule) AppRegistry.getRootApp().getAppModule(RemoteAppModule.ID);
//		 local
		 Registry launchServerRegistry = remoteAppModule.getRegistry(URI
		 .create("urn:jxta:uuid-59616261646162614E50472050325033E4F4490AC8384450BF4DF165652238C603"));
		

		// local tcp
//		 Registry launchServerRegistry =
//		 remoteAppModule.getRegistry(URI.create("tcp://localhost:22000"));

		// windows
//		Registry launchServerRegistry = remoteAppModule.getRegistry(URI
//				.create("urn:jxta:uuid-59616261646162614E50472050325033247A95847C204CD0A0909CA94A88D7AE03"));
		 
		// eodisp.org
		// Registry launchServerRegistry = remoteAppModule.getRegistry(URI
		// .create("urn:jxta:uuid-59616261646162614E504720503250335C331BF7D2AB45719BA7C9ED0E0615E903"));

		LaunchServerRemote launchServerRemote = (LaunchServerRemote) launchServerRegistry
				.lookup(LaunchServerRemoteImpl.REGISTRY_NAME);
		System.out.println(launchServerRemote);
		CrcProcessFactoryRemote crcProcessFactoryRemote = (CrcProcessFactoryRemote) launchServerRemote
				.newProcessFactory(CrcProcessFactoryRemote.FACTORY_ID);

		crcProcessFactoryRemote.setTransports(EnumSet.of(transportType));

		RootAppProcessRemote crcProcessRemote = (RootAppProcessRemote) crcProcessFactoryRemote.newProcess();

		Map<TransportType, JeriRegistry> crcRegistries;
		System.out.println("JUnit: Starting CRC ...");
		if ((crcRegistries = crcProcessRemote.launchBlocking(120, TimeUnit.SECONDS)) == null) {
			fail("Could not start crcRemote Process");
		}

		final JeriRegistry crcJeriRegistry = crcRegistries.get(transportType);
		crcRemote = (CrcRemote) crcJeriRegistry.lookup(CrcRemote.REGISTRY_NAME);
		LrcConfiguration lrcConfig = (LrcConfiguration) AppRegistry.getRootApp().getConfiguration(LrcConfiguration.ID);
		lrcConfig.setCrcUri(crcJeriRegistry.getUri(transportType));
		System.out.println("JUnit: Started LRC and CRC Remote Process. Now start testing ...");
	}

	@Override
	protected void tearDownFixture() throws Exception {
		crcRemote.shutdownAndExit();
	}

	@Override
	protected void setUp() throws Exception {
		totalBytesTransferred.set(0);
		errorFlag = true;
		rtiAmbassador1 = RtiFactoryFactory.getRtiFactory().getRtiAmbassador();
	}

	@Override
	protected void tearDown() throws Exception {
		LrcAppModule lrcAppModule = (LrcAppModule) AppRegistry.getRootApp().getAppModule(LrcAppModule.ID);
		Lrc lrc = lrcAppModule.getLrc();
		crcRemote.reset();
		lrc.reset();
	}

	public void testJoin_FederationExecutionDoesNotExist() throws Exception {
		try {
			rtiAmbassador1.joinFederationExecution(
					"type",
					FEDERATION_EXECUTION_NAME,
					new TestFederateAmbassador(),
					null);
			fail("A federates must be able to join a non-existent federation execution");
		} catch (FederationExecutionDoesNotExist expected) {
			assertTrue(true);
		}
	}

	public void testCreateFederationExecution_FederationExecutionAlreadyExists() throws Exception {
		rtiAmbassador1.createFederationExecution(FEDERATION_EXECUTION_NAME, TestOMTModel.getURL());
		try {
			rtiAmbassador1.createFederationExecution(FEDERATION_EXECUTION_NAME, TestOMTModel.getURL());
			fail("Creating a federation execution that has the same name as an already existing one must throw a 'FederationExecutionAlreadyExists' exception.");
		} catch (FederationExecutionAlreadyExists e) {
			assertTrue(true);
		}
	}

	public void testDestroyFederationExecution_FederatesCurrentlyJoined() throws Exception {
		rtiAmbassador1.createFederationExecution(FEDERATION_EXECUTION_NAME, TestOMTModel.getURL());
		rtiAmbassador1.joinFederationExecution("type", FEDERATION_EXECUTION_NAME, new NullFederateAmbassador(), null);
		try {
			rtiAmbassador1.destroyFederationExecution(FEDERATION_EXECUTION_NAME);
			fail("Destroying a federation execution that has federates joins must throw a 'FederatesCurrentlyJoined' exception");
		} catch (FederatesCurrentlyJoined e) {
			assertTrue(true);
		}
	}

	public void testResignFederationExecution_FederateNotExecutionMember() throws Exception {
		rtiAmbassador1.createFederationExecution(FEDERATION_EXECUTION_NAME, TestOMTModel.getURL());
		rtiAmbassador1.joinFederationExecution("type", FEDERATION_EXECUTION_NAME, new NullFederateAmbassador(), null);
		rtiAmbassador1.resignFederationExecution(null);
		try {
			rtiAmbassador1.resignFederationExecution(null);
			fail("Resigning from a federation execution if not joined must throw a 'FederateNotExecutionMember' exception");
		} catch (FederateNotExecutionMember e) {
			assertTrue(true);
		}
	}

	/**
	 * @param theAttributes
	 */
	private void updateTransferredData(AttributeHandleValueMap theAttributes) {
		Collection datas = theAttributes.values();
		for (Object object : datas) {
			byte[] data = (byte[]) object;
			totalBytesTransferred.addAndGet(data.length);
		}
	}

	public void testUpdateAttributeValues() throws Exception {
		int nrOfUpdates = 3;

		final CountDownLatch countDownLatch = new CountDownLatch(nrOfUpdates * 2);

		RTIambassador publishingFederate = RtiFactoryFactory.getRtiFactory().getRtiAmbassador();
		RTIambassador subscribingFederate1 = RtiFactoryFactory.getRtiFactory().getRtiAmbassador();
		RTIambassador subscribingFederate2 = RtiFactoryFactory.getRtiFactory().getRtiAmbassador();

		// Create Federation Execution
		publishingFederate.createFederationExecution(FEDERATION_EXECUTION_NAME, TestOMTModel.getURL());

		// Join
		publishingFederate.joinFederationExecution("type", FEDERATION_EXECUTION_NAME, new NullFederateAmbassador() {
			@Override
			public void reflectAttributeValues(ObjectInstanceHandle theObject, AttributeHandleValueMap theAttributes,
					byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport)
					throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotSubscribed,
					FederateInternalError {
				fail("An updated invoked by a certain federate must not cause reflectAttributeValues to be invoked on the same federate");
			}

		},
				null);

		// Getting Handles
		ObjectClassHandle a1 = publishingFederate.getObjectClassHandle(TestOMTModel.A_1);
		ObjectClassHandle b1 = publishingFederate.getObjectClassHandle(TestOMTModel.B_1_ABS);
		final AttributeHandle x = publishingFederate.getAttributeHandle(b1, TestOMTModel.X);
		final AttributeHandle y = publishingFederate.getAttributeHandle(b1, TestOMTModel.Y);
		final AttributeHandle z = publishingFederate.getAttributeHandle(b1, TestOMTModel.Z);
		AttributeHandleSet xy = new AttributeHandleSetImpl();
		xy.add(x);
		xy.add(y);
		AttributeHandleSet xyz = new AttributeHandleSetImpl();
		xyz.add(x);
		xyz.add(y);
		xyz.add(z);
		AttributeHandleValueMap xyzValues = new AttributeHandleValueMapImpl();
		final byte[] dataX = new byte[1024 * 1024 * 10];
		Arrays.fill(dataX, (byte) 3);
		xyzValues.put(x, dataX);
		final byte[] dataY = new byte[] { 1, 1, 1 };
		xyzValues.put(y, dataY);
		final byte[] dataZ = new byte[] { 2, 2, 2 };
		xyzValues.put(z, dataZ);

		subscribingFederate1.joinFederationExecution("type", FEDERATION_EXECUTION_NAME, new NullFederateAmbassador() {
			@Override
			public void reflectAttributeValues(ObjectInstanceHandle theObject, AttributeHandleValueMap theAttributes,
					byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport)
					throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotSubscribed,
					FederateInternalError {
				updateTransferredData(theAttributes);

				countDownLatch.countDown();
				assertEquals(2, theAttributes.size());
				assertTrue(Arrays.equals((byte[]) theAttributes.get(x), dataX));
				assertTrue(Arrays.equals((byte[]) theAttributes.get(y), dataY));
				System.out.println(String.format("Reflect F1: %d", countDownLatch.getCount()));
			}

		}, null);
		subscribingFederate2.joinFederationExecution("type", FEDERATION_EXECUTION_NAME, new NullFederateAmbassador() {
			@Override
			public void reflectAttributeValues(ObjectInstanceHandle theObject, AttributeHandleValueMap theAttributes,
					byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport)
					throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotSubscribed,
					FederateInternalError {
				updateTransferredData(theAttributes);
				countDownLatch.countDown();
				assertEquals(3, theAttributes.size());
				assertTrue(Arrays.equals((byte[]) theAttributes.get(x), dataX));
				assertTrue(Arrays.equals((byte[]) theAttributes.get(y), dataY));
				assertTrue(Arrays.equals((byte[]) theAttributes.get(z), dataZ));

				System.out.println(String.format("Reflect F2: %d", countDownLatch.getCount()));
				System.out.println(countDownLatch.getCount());
			}
		}, null);

		// Publish and Register
		publishingFederate.publishObjectClassAttributes(b1, xyz);
		ObjectInstanceHandle b1Inst = publishingFederate.registerObjectInstance(b1);

		// Subscriptions
		publishingFederate.subscribeObjectClassAttributes(a1, xy);
		subscribingFederate1.subscribeObjectClassAttributes(a1, xy);
		subscribingFederate2.subscribeObjectClassAttributes(b1, xyz);

		// Create Update Attribute Values

		long now = System.currentTimeMillis();
		for (int i = 0; i < nrOfUpdates; i++) {
			System.out.printf("Update: %d%n", nrOfUpdates - i);
			publishingFederate.updateAttributeValues(b1Inst, xyzValues, null);
		}
		countDownLatch.await(300, TimeUnit.SECONDS);
		System.out.println(String.format("Updating %d times (%dMB of data): %dms", nrOfUpdates, totalBytesTransferred
				.get()
				/ (1024 * 1024), System.currentTimeMillis() - now));

	}

	public void testRegisterSynchronizationPoint_SynchronizationPointRegistrationSuceeded() {

	}

	public void testRegisterSynchronizationPoint_SYNCHRONIZATION_POINT_LABEL_NOT_UNIQUE() throws Exception {
		final CountDownLatch countDownLatch = new CountDownLatch(1);
		RTIambassador registeringFederate = RtiFactoryFactory.getRtiFactory().getRtiAmbassador();
		// Create Federation Execution
		registeringFederate.createFederationExecution(FEDERATION_EXECUTION_NAME, TestOMTModel.getURL());

		// Join
		registeringFederate.joinFederationExecution("type", FEDERATION_EXECUTION_NAME, new NullFederateAmbassador() {
			@Override
			public void synchronizationPointRegistrationFailed(String synchronizationPointLabel,
					SynchronizationPointFailureReason reason) throws FederateInternalError {
				if (synchronizationPointLabel.equals(SYNC_POINT_1)
						&& reason.equals(SynchronizationPointFailureReason.SYNCHRONIZATION_POINT_LABEL_NOT_UNIQUE)) {
					errorFlag = false;
					countDownLatch.countDown();
				} else {
					errorFlag = true;
				}
			}
		}, null);

		registeringFederate.registerFederationSynchronizationPoint(SYNC_POINT_1, null);
		registeringFederate.registerFederationSynchronizationPoint(SYNC_POINT_1, null);
		if (!countDownLatch.await(5, TimeUnit.SECONDS) && errorFlag) {
			fail("Registering a synchronization point with twice must cause a synchronizationPointRegistrationFailed callback from the RTI");
		}
	}

	public void testRegisterSynchronizationPoint_SYNCHRONIZATION_SET_MEMBER_NOT_JOINED() throws Exception {
		final CountDownLatch countDownLatch = new CountDownLatch(1);
		RTIambassador registeringFederate = RtiFactoryFactory.getRtiFactory().getRtiAmbassador();
		RTIambassador unjoinedFederate = RtiFactoryFactory.getRtiFactory().getRtiAmbassador();
		// Create Federation Execution
		registeringFederate.createFederationExecution(FEDERATION_EXECUTION_NAME, TestOMTModel.getURL());

		FederateHandle unjoinedFederateHandle = unjoinedFederate.joinFederationExecution(
				"type",
				FEDERATION_EXECUTION_NAME,
				new NullFederateAmbassador(),
				null);

		// Join
		registeringFederate.joinFederationExecution("type", FEDERATION_EXECUTION_NAME, new NullFederateAmbassador() {
			@Override
			public void synchronizationPointRegistrationFailed(String synchronizationPointLabel,
					SynchronizationPointFailureReason reason) throws FederateInternalError {
				if (synchronizationPointLabel.equals(SYNC_POINT_1)
						&& reason.equals(SynchronizationPointFailureReason.SYNCHRONIZATION_SET_MEMBER_NOT_JOINED)) {
					errorFlag = false;
					countDownLatch.countDown();
				} else {
					errorFlag = true;
				}
			}
		}, null);

		FederateHandleSet federateHandleSet = registeringFederate.getFederateHandleSetFactory().create();
		federateHandleSet.add(unjoinedFederateHandle);
		unjoinedFederate.resignFederationExecution(null);
		registeringFederate.registerFederationSynchronizationPoint(SYNC_POINT_1, null, federateHandleSet);
		if (!countDownLatch.await(5, TimeUnit.SECONDS) && errorFlag) {
			fail("A federate that is part of a synchronization set but but not joined to the RTI must cause a SYNCHRONIZATION_SET_MEMBER_NOT_JOINED callback");
		}
	}

	public void testRegisterSynchronizationPoint() throws Exception {
		final CountDownLatch announceLatch = new CountDownLatch(3);
		final CountDownLatch announceNewlyJoinedLatch = new CountDownLatch(1);
		final CountDownLatch federationSynchronizedLatch = new CountDownLatch(3);
		RTIambassador registeringFederate = RtiFactoryFactory.getRtiFactory().getRtiAmbassador();
		RTIambassador federate1 = RtiFactoryFactory.getRtiFactory().getRtiAmbassador();
		RTIambassador federate2 = RtiFactoryFactory.getRtiFactory().getRtiAmbassador();
		RTIambassador federate3 = RtiFactoryFactory.getRtiFactory().getRtiAmbassador();
		// Create Federation Execution
		registeringFederate.createFederationExecution(FEDERATION_EXECUTION_NAME, TestOMTModel.getURL());

		federate1.joinFederationExecution("type", FEDERATION_EXECUTION_NAME, new NullFederateAmbassador() {
			@Override
			public void announceSynchronizationPoint(String synchronizationPointLabel, byte[] userSuppliedTag)
					throws FederateInternalError {
				announceLatch.countDown();
			}

			@Override
			public void federationSynchronized(String synchronizationPointLabel) throws FederateInternalError {
				federationSynchronizedLatch.countDown();
			}
		}, null);

		federate2.joinFederationExecution("type", FEDERATION_EXECUTION_NAME, new NullFederateAmbassador() {
			@Override
			public void announceSynchronizationPoint(String synchronizationPointLabel, byte[] userSuppliedTag)
					throws FederateInternalError {
				announceLatch.countDown();
			}

			@Override
			public void federationSynchronized(String synchronizationPointLabel) throws FederateInternalError {
				federationSynchronizedLatch.countDown();
			}
		}, null);

		// Join
		registeringFederate.joinFederationExecution("type", FEDERATION_EXECUTION_NAME, new NullFederateAmbassador() {
			@Override
			public void announceSynchronizationPoint(String synchronizationPointLabel, byte[] userSuppliedTag)
					throws FederateInternalError {
				announceLatch.countDown();
			}

			@Override
			public void federationSynchronized(String synchronizationPointLabel) throws FederateInternalError {
				federationSynchronizedLatch.countDown();
			}
		}, null);

		registeringFederate.registerFederationSynchronizationPoint(SYNC_POINT_1, null);

		if (!announceLatch.await(5, TimeUnit.SECONDS)) {
			fail("Registering a synchronization point with the RTI must announce it to the joined federates");
		}

		federate3.joinFederationExecution("type", FEDERATION_EXECUTION_NAME, new NullFederateAmbassador() {
			@Override
			public void announceSynchronizationPoint(String synchronizationPointLabel, byte[] userSuppliedTag)
					throws FederateInternalError {
				announceNewlyJoinedLatch.countDown();
			}
		}, null);
		if (!announceNewlyJoinedLatch.await(5, TimeUnit.SECONDS)) {
			fail("A federate that is joining must be announced of any pending synchronizations");
		}

		registeringFederate.synchronizationPointAchieved(SYNC_POINT_1);
		federate1.synchronizationPointAchieved(SYNC_POINT_1);
		federate2.synchronizationPointAchieved(SYNC_POINT_1);
		// should cause the same as sync point achieved
		federate3.resignFederationExecution(null);
		if (!federationSynchronizedLatch.await(5, TimeUnit.SECONDS)) {
			fail("When all federates have achieved the synchronization point is must cause a federationSynchronized() callback on all participating federates");
		}
	}

	public void testRegisterSynchronizationPointFixedSet() throws Exception {
		final CountDownLatch announceLatch = new CountDownLatch(3);
		final CountDownLatch announceNewlyJoinedLatch = new CountDownLatch(1);
		final CountDownLatch federationSynchronizedLatch = new CountDownLatch(2);
		RTIambassador registeringFederate = RtiFactoryFactory.getRtiFactory().getRtiAmbassador();
		RTIambassador federate1 = RtiFactoryFactory.getRtiFactory().getRtiAmbassador();
		RTIambassador federate2 = RtiFactoryFactory.getRtiFactory().getRtiAmbassador();
		RTIambassador federate3 = RtiFactoryFactory.getRtiFactory().getRtiAmbassador();
		// Create Federation Execution
		registeringFederate.createFederationExecution(FEDERATION_EXECUTION_NAME, TestOMTModel.getURL());

		FederateHandle federateHandle1 = federate1.joinFederationExecution(
				"type",
				FEDERATION_EXECUTION_NAME,
				new NullFederateAmbassador() {
					@Override
					public void announceSynchronizationPoint(String synchronizationPointLabel, byte[] userSuppliedTag)
							throws FederateInternalError {
						announceLatch.countDown();
					}

					@Override
					public void federationSynchronized(String synchronizationPointLabel) throws FederateInternalError {
						federationSynchronizedLatch.countDown();
					}
				},
				null);

		federate2.joinFederationExecution("type", FEDERATION_EXECUTION_NAME, new NullFederateAmbassador() {
			@Override
			public void announceSynchronizationPoint(String synchronizationPointLabel, byte[] userSuppliedTag)
					throws FederateInternalError {
				announceLatch.countDown();
			}

			@Override
			public void federationSynchronized(String synchronizationPointLabel) throws FederateInternalError {
				federationSynchronizedLatch.countDown();
			}
		}, null);

		// Join
		FederateHandle registeringFederateHandle = registeringFederate.joinFederationExecution(
				"type",
				FEDERATION_EXECUTION_NAME,
				new NullFederateAmbassador() {
					@Override
					public void announceSynchronizationPoint(String synchronizationPointLabel, byte[] userSuppliedTag)
							throws FederateInternalError {
						announceLatch.countDown();
					}

					@Override
					public void federationSynchronized(String synchronizationPointLabel) throws FederateInternalError {
						federationSynchronizedLatch.countDown();
					}
				},
				null);

		FederateHandleSet syncFederates = registeringFederate.getFederateHandleSetFactory().create();
		syncFederates.add(registeringFederateHandle);
		syncFederates.add(federateHandle1);

		registeringFederate.registerFederationSynchronizationPoint(SYNC_POINT_1, null, syncFederates);

		// Wait for 2 seconds
		if (announceLatch.await(2, TimeUnit.SECONDS)) {
			fail("Synchronization points must only be announced to federates in the sync list");
		} else {
			assertEquals(1, announceLatch.getCount());
		}

		federate3.joinFederationExecution("type", FEDERATION_EXECUTION_NAME, new NullFederateAmbassador() {
			@Override
			public void announceSynchronizationPoint(String synchronizationPointLabel, byte[] userSuppliedTag)
					throws FederateInternalError {
				announceNewlyJoinedLatch.countDown();
			}
		}, null);
		if (announceNewlyJoinedLatch.await(2, TimeUnit.SECONDS)) {
			fail("Newly joined federates must not be added to the synchronization point if a fixed set of federates was registered for a synchronization point");
		} else {
			assertEquals(1, announceNewlyJoinedLatch.getCount());
		}

		registeringFederate.synchronizationPointAchieved(SYNC_POINT_1);
		federate1.synchronizationPointAchieved(SYNC_POINT_1);
		federate2.resignFederationExecution(null);
		if (!federationSynchronizedLatch.await(5, TimeUnit.SECONDS)) {
			fail("When all federates have achieved the synchronization point is must cause a federationSynchronized() callback on all participating federates");
		}
	}

	public void testRegisterSynchronizationPoint_FederateNotExecutionMember() throws Exception {
		RTIambassador registeringFederate = RtiFactoryFactory.getRtiFactory().getRtiAmbassador();
		try {
			registeringFederate.registerFederationSynchronizationPoint(SYNC_POINT_1, null);
			fail("Expected FederateNotExecutionMember exception");
		} catch (FederateNotExecutionMember expected) {
			assertTrue(true);
		}
	}

	public void testSendInteraction() throws Exception {
		final AtomicReference<String> errorMessage = new AtomicReference<String>();

		final CountDownLatch receiveInteractionLatch = new CountDownLatch(2);
		final byte[] data = new byte[1024];
		Arrays.fill(data, (byte) 3);
		RTIambassador federate1 = RtiFactoryFactory.getRtiFactory().getRtiAmbassador();
		RTIambassador federate2 = RtiFactoryFactory.getRtiFactory().getRtiAmbassador();
		RTIambassador federate3 = RtiFactoryFactory.getRtiFactory().getRtiAmbassador();

		federate1.createFederationExecution(FEDERATION_EXECUTION_NAME, TestOMTModel.getURL());

		// Join
		FederateHandle federateHandle1 = federate1.joinFederationExecution(
				"type",
				FEDERATION_EXECUTION_NAME,
				new NullFederateAmbassador(),
				null);

		final InteractionClassHandle i1 = federate1.getInteractionClassHandle(TestOMTModel.I_1);
		final ParameterHandle p1 = federate1.getParameterHandle(i1, TestOMTModel.P1);
		final ParameterHandleValueMap parameters = federate1.getParameterHandleValueMapFactory().create(3);

		FederateHandle federateHandle2 = federate2.joinFederationExecution(
				"type",
				FEDERATION_EXECUTION_NAME,
				new NullFederateAmbassador() {
					@Override
					public void receiveInteraction(InteractionClassHandle interactionClass,
							ParameterHandleValueMap theParameters, byte[] userSuppliedTag, OrderType sentOrdering,
							TransportationType theTransport) throws InteractionClassNotRecognized,
							InteractionParameterNotRecognized, InteractionClassNotSubscribed, FederateInternalError {
						byte[] receivedData = (byte[]) theParameters.get(p1);
						if (!Arrays.equals(data, receivedData)) {
							errorMessage.set("The received parameter is not equal to the one that was sent");
						}

						receiveInteractionLatch.countDown();
					}
				},
				null);

		FederateHandle federateHandle3 = federate3.joinFederationExecution(
				"type",
				FEDERATION_EXECUTION_NAME,
				new NullFederateAmbassador() {
					@Override
					public void receiveInteraction(InteractionClassHandle interactionClass,
							ParameterHandleValueMap theParameters, byte[] userSuppliedTag, OrderType sentOrdering,
							TransportationType theTransport) throws InteractionClassNotRecognized,
							InteractionParameterNotRecognized, InteractionClassNotSubscribed, FederateInternalError {
						byte[] receivedData = (byte[]) theParameters.get(p1);
						if (!Arrays.equals(data, receivedData)) {
							errorMessage.set("The received parameter is not equal to the one that was sent");
						}
						receiveInteractionLatch.countDown();
					}
				},
				null);

		parameters.put(p1, data);
		federate1.publishInteractionClass(i1);
		federate1.subscribeInteractionClass(i1);
		federate2.subscribeInteractionClass(i1);
		federate3.subscribeInteractionClass(i1);
		federate1.sendInteraction(i1, parameters, new byte[0]);

		if (!receiveInteractionLatch.await(5, TimeUnit.SECONDS)) {
			fail("send interaction did not cause receive interaction to be invoked on subscribing federates");
		}

		if (errorMessage.get() != null) {
			fail(errorMessage.get());
		}
	}

	public void testStartRegistration() throws Exception {
		rtiAmbassador1.createFederationExecution(FEDERATION_EXECUTION_NAME, TestOMTModel.getURL());
		rtiAmbassador1.joinFederationExecution("type", FEDERATION_EXECUTION_NAME, new NullFederateAmbassador() {
			@Override
			public void startRegistrationForObjectClass(ObjectClassHandle theClass) throws ObjectClassNotPublished,
					FederateInternalError {
				System.out.println("startReg for: " + theClass);
				synchronized (LrcRtiAmbassadorTest.this) {
					LrcRtiAmbassadorTest.this.notifyAll();
					errorFlag = false;
				}

			}
		}, null);
		ObjectClassHandle a1 = rtiAmbassador1.getObjectClassHandle(TestOMTModel.A_1);
		AttributeHandle x = rtiAmbassador1.getAttributeHandle(a1, TestOMTModel.X);
		AttributeHandle y = rtiAmbassador1.getAttributeHandle(a1, TestOMTModel.Y);
		AttributeHandleSet xy = new AttributeHandleSetImpl();
		xy.addAll(Arrays.asList(new AttributeHandle[] { x, y }));
		rtiAmbassador1.publishObjectClassAttributes(a1, xy);

		RTIambassador rtiAmbassador2 = RtiFactoryFactory.getRtiFactory().getRtiAmbassador();
		rtiAmbassador2.joinFederationExecution("type", FEDERATION_EXECUTION_NAME, new NullFederateAmbassador(), null);
		rtiAmbassador2.subscribeObjectClassAttributes(a1, xy);
		synchronized (this) {
			long now = System.currentTimeMillis();

			if (errorFlag) {
				wait(5 * 1000);
			}
			System.out.println("Waited for: " + (System.currentTimeMillis() - now));
		}

		if (errorFlag) {
			fail("Subscribing to a published attribute did not invoke startRegistrationForObjectClass(...) on the federate that publishes this attribute");
		} else {
			assertTrue(true);
		}
	}
}
