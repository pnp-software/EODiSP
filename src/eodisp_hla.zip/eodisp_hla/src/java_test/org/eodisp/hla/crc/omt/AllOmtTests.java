package org.eodisp.hla.crc.omt;

import junit.framework.Test;
import junit.framework.TestSuite;

public class AllOmtTests {

	public static void main(String[] args) {
		junit.swingui.TestRunner.run(AllOmtTests.class);
	}

	public static Test suite() {
		TestSuite suite = new TestSuite("Test for org.eodisp.hla.crc.omt");
		//$JUnit-BEGIN$
		suite.addTestSuite(AttributeTest.class);
		suite.addTestSuite(ObjectClassTest.class);
		//$JUnit-END$
		return suite;
	}
}
