package org.eodisp.hla.crc.omt;

import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;

/**
 * Tests the non-emf generated methods of
 * {@link org.eodisp.hla.crc.omt.ObjectClass}
 * 
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class ObjectClassTest extends TestCase {

	/**
	 * the test model
	 */
	private TestOMTModel testOmtModel;

	/**
	 * Sets the logger and creates a test model.
	 * 
	 * @see TestOMTModel
	 */
	@Override
	protected void setUp() {
		Logger.getRootLogger().addAppender(
				new ConsoleAppender(new PatternLayout("%r [%t] %p %l %x - %m%n"), "System.out"));

		testOmtModel = new TestOMTModel();
	}

	/**
	 * Tests getAllAttributes() for each object class defined in the TestOMTModel
	 * 
	 * @see #setUp()
	 */
	@SuppressWarnings("unchecked")
	public void testGetAllAttributes() {
		List attributesA1 = new ArrayList();
		attributesA1.add(testOmtModel.hlaPrivilegeToDeleteObject);
		attributesA1.add(testOmtModel.x);
		attributesA1.add(testOmtModel.y);

		List attributesB2 = new ArrayList();
		attributesB2.add(testOmtModel.hlaPrivilegeToDeleteObject);
		attributesB2.add(testOmtModel.x);
		attributesB2.add(testOmtModel.y);
		attributesB2.add(testOmtModel.q);

		List attributesC1 = new ArrayList();
		attributesC1.add(testOmtModel.hlaPrivilegeToDeleteObject);
		attributesC1.add(testOmtModel.x);
		attributesC1.add(testOmtModel.y);
		attributesC1.add(testOmtModel.z);

		assertTrue(testOmtModel.a1.getAllAttributes().containsAll(testOmtModel.a1.getAttributes()));

		assertTrue(attributesA1.containsAll(testOmtModel.a1.getAllAttributes()));
		assertTrue(attributesC1.containsAll(testOmtModel.b1.getAllAttributes()));
		assertTrue(attributesB2.containsAll(testOmtModel.b2.getAllAttributes()));
		assertTrue(attributesC1.containsAll(testOmtModel.c1.getAllAttributes()));
	}

	/**
	 * Tests getSuperClass() for each object class defined in the TestOMTModel.
	 * 
	 * @see #setUp()
	 */
	public void testGetSuperClass() {
		assertSame(testOmtModel.c1.getSuperClass(), testOmtModel.b1);
		assertSame(testOmtModel.b1.getSuperClass(), testOmtModel.a1);
		assertSame(testOmtModel.b2.getSuperClass(), testOmtModel.a1);
		assertSame(testOmtModel.a1.getSuperClass(), testOmtModel.hlaObjectRoot);
		assertNull(testOmtModel.hlaObjectRoot.getSuperClass());
	}

	/**
	 * Tests all qualified names in the TestOMTModel.
	 */
	public void testGetQualifiedName() {
		assertEquals("HLAobjectRoot", testOmtModel.hlaObjectRoot.getQualifiedName(false));
		assertEquals("HLAobjectRoot.A_1", testOmtModel.a1.getQualifiedName(false));
		assertEquals("HLAobjectRoot.A_1.B_1", testOmtModel.b1.getQualifiedName(false));
		assertEquals("HLAobjectRoot.A_1.B_2", testOmtModel.b2.getQualifiedName(false));
		assertEquals("HLAobjectRoot.A_1.B_1.C_1", testOmtModel.c1.getQualifiedName(false));

		assertEquals("", testOmtModel.hlaObjectRoot.getQualifiedName(true));
		assertEquals("A_1", testOmtModel.a1.getQualifiedName(true));
		assertEquals("A_1.B_1", testOmtModel.b1.getQualifiedName(true));
		assertEquals("A_1.B_2", testOmtModel.b2.getQualifiedName(true));
		assertEquals("A_1.B_1.C_1", testOmtModel.c1.getQualifiedName(true));
	}

	/**
	 * Tests the number of super classes only. Does not test the type of each
	 * super class.
	 */
	public void testGetAllSuperClasses() {
		assertTrue(testOmtModel.hlaObjectRoot.getAllSuperClasses().isEmpty());
		assertEquals(testOmtModel.a1.getAllSuperClasses().size(), 1);
		assertEquals(testOmtModel.b1.getAllSuperClasses().size(), 2);
		assertEquals(testOmtModel.b2.getAllSuperClasses().size(), 2);
		assertEquals(testOmtModel.c1.getAllSuperClasses().size(), 3);
	}

}
