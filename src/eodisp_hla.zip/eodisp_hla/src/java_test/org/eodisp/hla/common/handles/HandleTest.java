package org.eodisp.hla.common.handles;

import java.io.*;

import org.eodisp.hla.common.handles.HandleImpl;

import junit.framework.TestCase;

public class HandleTest extends TestCase {
	/**
	 * Tests serialization and deserialization of the {@link HandleImpl}}
	 * 
	 * @throws Exception
	 *             should never be thrown
	 */
	public void testSerialization() throws Exception {
		HandleImpl handle1 = new HandleImpl(3);

		ByteArrayOutputStream baos = new ByteArrayOutputStream();

		ObjectOutputStream oos = new ObjectOutputStream(baos);
		oos.writeObject(handle1);

		ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());

		ObjectInputStream objectInputStream = new ObjectInputStream(bais);

		HandleImpl handle2 = (HandleImpl) objectInputStream.readObject();

		assertEquals(handle1, handle2);
	}
}
