package org.eodisp.hla.crc;

import hla.rti1516.*;

import java.util.*;

import junit.framework.Assert;
import junit.framework.TestCase;

import org.eodisp.hla.common.crc.FederationExecutionRemote;
import org.eodisp.hla.common.handles.FederateHandleImpl;
import org.eodisp.hla.common.handles.InteractionClassHandleImpl;
import org.eodisp.hla.common.handles.ObjectClassHandleImpl;
import org.eodisp.hla.common.lrc.LrcHandle;
import org.eodisp.hla.common.lrc.LrcRemote;
import org.eodisp.hla.crc.omt.TestOMTModel;

public class FederationExecutionRemoteTest extends TestCase {

	private static final String UNKNOWN_OBJECT_CLASS = "UnknownObjectClass";

	private static final String UNKNOWN_INTERACTION_CLASS = "UnknownInteractionClass";

	private FederationExecutionRemote federationExecution;

	private TestFederationExecution testFederationExecution;

	private ObjectClassHandle invalidObjectClassHandle = new ObjectClassHandleImpl(-1);

	private InteractionClassHandle invalidInteractionClassHandle = new InteractionClassHandleImpl(-1);

	private FederationExecution federationExecutionImpl;

	@Override
	protected void setUp() throws Exception {
		testFederationExecution = new TestFederationExecution();
		federationExecutionImpl = testFederationExecution.getFederationExecution();
		federationExecution = federationExecutionImpl.getRemoteInterface();
	}

	public void testJoin() throws Exception {
		LrcHandle lrcHandle = new LrcHandle(0);
		FederateHandle federateHandle1 = federationExecutionImpl.join("type", lrcHandle, null);
		assertEquals(1, federationExecution.getJoinedFederates());
		FederateHandle federateHandle2 = federationExecutionImpl.join("type", lrcHandle, null);
		assertEquals(2, federationExecution.getJoinedFederates());
		assertNotSame(federateHandle1, federateHandle2);
	}

	public void testResign() throws Exception {
		LrcHandle lrcHandle = new LrcHandle(0);
		FederateHandle federateHandle1 = federationExecutionImpl.join("type", lrcHandle, null);
		federationExecution.resign(null, federateHandle1);
		Assert.assertEquals(0, federationExecution.getJoinedFederates());
	}

	public void testResign_FederateNotExecutionMember() throws Exception {
		FederateHandle federateHandle = new FederateHandleImpl(1);
		try {
			federationExecution.resign(null, federateHandle);
			fail("Resigning a federate with an unknown handle must throw a FederateNotExecutionMember exception");
		} catch (FederateNotExecutionMember expected) {
			assertTrue(true);
		}
	}

	public void testGetObjectClassHandle() throws Exception {
		assertEquals(testFederationExecution.B1, federationExecution.getObjectClassHandle(TestOMTModel.B_1_ABS));
	}

	public void testGetObjectClassHandle_NameNotFound() throws Exception {
		try {
			federationExecution.getObjectClassHandle(UNKNOWN_OBJECT_CLASS);
			fail("Expected NameNotFound exception");
		} catch (NameNotFound e) {
			assertTrue(true);
		}
	}

	public void testGetObjectClassName() throws Exception {
		String name = federationExecution.getObjectClassName(testFederationExecution.B1);
		assertEquals(name, "HLAobjectRoot" + "." + TestOMTModel.A_1 + "." + TestOMTModel.B_1);
	}

	public void testGetObjectClassName_ObjectClassNotDefined() throws Exception {
		try {
			federationExecution.getObjectClassName(invalidObjectClassHandle);
			fail("Expected ObjectClassNotDefined exception");
		} catch (ObjectClassNotDefined expected) {
			assertTrue(true);
		}
	}

	public void testGetAttributeHandle() throws Exception {
		assertEquals(testFederationExecution.Z, federationExecution.getAttributeHandle(
				testFederationExecution.B1,
				TestOMTModel.Z));
		assertEquals(testFederationExecution.X, federationExecution.getAttributeHandle(
				testFederationExecution.B1,
				TestOMTModel.X));
	}

	public void testGetAttributeHandle_ObjectClassNotDefined() throws Exception {
		try {
			federationExecution.getAttributeHandle(invalidObjectClassHandle, TestOMTModel.Z);
			fail("Expected ObjectClassNotDefined exception");
		} catch (ObjectClassNotDefined e) {
			assertTrue(true);
		}
	}

	public void testGetAttributeHandle_NameNotFound() throws Exception {
		try {
			federationExecution.getAttributeHandle(testFederationExecution.B1, TestOMTModel.Q);
			fail("Expected NameNotFound exception");
		} catch (NameNotFound expected) {
			assertTrue(true);
		}
	}

	public void testGetAttributeName() throws Exception {
		String name = federationExecution.getAttributeName(testFederationExecution.B1, testFederationExecution.Z);
		assertEquals(name, TestOMTModel.Z);
	}

	public void testGetInteractionClassHandle() throws Exception {
		assertEquals(testFederationExecution.J1, federationExecution.getInteractionClassHandle(TestOMTModel.I_1 + "."
				+ TestOMTModel.J_1));

	}

	public void testGetInteractionClassHandle_NameNotFound() throws Exception {
		try {
			federationExecution.getInteractionClassHandle(UNKNOWN_INTERACTION_CLASS);
			fail("Expected NameNotFound exception");
		} catch (NameNotFound e) {
			assertTrue(true);
		}
	}

	public void testGetInteractionClassName() throws Exception {
		assertEquals("HLAinteractionRoot" + "." + TestOMTModel.I_1 + "." + TestOMTModel.J_1, federationExecution
				.getInteractionClassName(testFederationExecution.J1));
	}

	public void testGetInteractionClassName_InteractionClassNotDefined() throws Exception {
		try {
			federationExecution.getInteractionClassName(invalidInteractionClassHandle);
			fail("Expected InvalidInteractionClassHandle exception");
		} catch (InteractionClassNotDefined expected) {
			assertTrue(true);
		}
	}

	public void testGetParameterHandle() throws Exception {
		assertEquals(testFederationExecution.P1, federationExecution.getParameterHandle(
				testFederationExecution.I1,
				TestOMTModel.P1));
	}

	public void testGetParameterHandle_InteractionClassNotDefined() throws Exception {
		try {
			federationExecution.getParameterHandle(invalidInteractionClassHandle, TestOMTModel.P3);
			fail("Expected InvalidInteractionClassHandle");
		} catch (InteractionClassNotDefined expected) {
			assertTrue(true);
		}
	}

	public void testGetParameterHandle_NameNotFound() throws Exception {
		try {
			federationExecution.getParameterHandle(testFederationExecution.J1, TestOMTModel.P4);
			fail("Expected NameNotFound");
		} catch (NameNotFound expected) {
			assertTrue(true);
		}
	}

	public void testGetParameterName() throws Exception {
		assertEquals(TestOMTModel.P3, federationExecution.getParameterName(
				testFederationExecution.J1,
				testFederationExecution.P3));
	}

	public void testgetObjectInstanceHandle() throws Exception {
		LrcHandle lrcHandle = TestFederationExecution.getCrc().registerLrc(new TestLrcRemote());
		FederateHandle federateHandle = federationExecutionImpl.join("type", lrcHandle, null);
		federationExecution.publishObjectClassAttributes(
				testFederationExecution.B1,
				testFederationExecution.ARRAY_XYZ,
				federateHandle);

		ObjectInstanceHandle objectInstanceHandle1 = federationExecution.registerObjectInstance(
				testFederationExecution.B1,
				federateHandle);
		ObjectInstanceHandle objectInstanceHandle2 = federationExecution.registerObjectInstance(
				testFederationExecution.B1,
				federateHandle);
		ObjectInstanceHandle objectInstanceHandle1Test = federationExecution.getObjectInstanceHandle("HLA_1");
		ObjectInstanceHandle objectInstanceHandle2Test = federationExecution.getObjectInstanceHandle("HLA_2");
		assertEquals(objectInstanceHandle1, objectInstanceHandle1Test);
		assertEquals(objectInstanceHandle2, objectInstanceHandle2Test);
	}

	public void testgetObjectInstanceName() throws Exception {
		LrcHandle lrcHandle = new LrcHandle(0);
		FederateHandle federateHandle = federationExecutionImpl.join("type", lrcHandle, null);
		federationExecution.publishObjectClassAttributes(
				testFederationExecution.B1,
				testFederationExecution.ARRAY_XYZ,
				federateHandle);

		ObjectInstanceHandle objectInstanceHandle1 = federationExecution.registerObjectInstance(
				testFederationExecution.B1,
				federateHandle);
		ObjectInstanceHandle objectInstanceHandle2 = federationExecution.registerObjectInstance(
				testFederationExecution.B1,
				federateHandle);
		String instanceName1 = federationExecution.getObjectInstanceName(objectInstanceHandle1);
		String instanceName2 = federationExecution.getObjectInstanceName(objectInstanceHandle2);
		assertEquals(instanceName1, "HLA_1");
		assertEquals(instanceName2, "HLA_2");
	}

	public void testUnpublishObjectClassAttributes() throws Exception {
		LrcHandle lrcHandle = new LrcHandle(0);
		FederateHandle federateHandle = federationExecutionImpl.join("type", lrcHandle, null);
		federationExecution.publishObjectClassAttributes(
				testFederationExecution.B1,
				testFederationExecution.ARRAY_XYZ,
				federateHandle);

		federationExecution.unpublishObjectClassAttributes(
				testFederationExecution.B1,
				testFederationExecution.ARRAY_XYZ,
				federateHandle);

		try {
			federationExecution.registerObjectInstance(testFederationExecution.B1, federateHandle);
			fail("Object class B1 has been unpublished and therefore registering an instance of this object class should throw an ObjectClassNotPublished but it didn't.");
		} catch (ObjectClassNotPublished expected) {
			assertTrue(true);
		}
	}

	public void testRegisterObjectInstance() throws Exception {
		LrcHandle lrcHandle = new LrcHandle(0);
		FederateHandle federateHandle = federationExecutionImpl.join("type", lrcHandle, null);
		federationExecution.publishObjectClassAttributes(
				testFederationExecution.B1,
				testFederationExecution.ARRAY_XYZ,
				federateHandle);

		ObjectInstanceHandle objectInstanceHandle1 = federationExecution.registerObjectInstance(
				testFederationExecution.B1,
				federateHandle);
		assertNotNull(objectInstanceHandle1);

		ObjectInstanceHandle objectInstanceHandle2 = federationExecution.registerObjectInstance(
				testFederationExecution.B1,
				federateHandle);
		assertNotNull(objectInstanceHandle2);

		assertTrue(
				"Registering two instances must not return the same object instance handle twice",
				!objectInstanceHandle1.equals(objectInstanceHandle2));
	}

	public void testRegisterObjectInstance_ObjectClassNotPublished() throws Exception {
		LrcHandle lrcHandle = new LrcHandle(0);
		FederateHandle federateHandle = federationExecutionImpl.join("type", lrcHandle, null);

		// Publish an arbitrary object class, but not B1
		federationExecution.publishObjectClassAttributes(
				testFederationExecution.A1,
				testFederationExecution.ARRAY_X,
				federateHandle);
		try {
			federationExecution.registerObjectInstance(testFederationExecution.B1, federateHandle);
			fail("Expected ObjectClassNotPublished exception");
		} catch (ObjectClassNotPublished expected) {
			assertTrue(true);
		}
	}

	public void testUnsubscribeObjectClassAttributes() throws Exception {
		LrcHandle lrcHandle = TestFederationExecution.getCrc().registerLrc(new TestLrcRemote());

		FederateHandle publishingFederate = federationExecutionImpl.join("type", lrcHandle, null);
		FederateHandle subscribingFederate = federationExecutionImpl.join("type", lrcHandle, null);

		federationExecution.publishObjectClassAttributes(
				testFederationExecution.B1,
				testFederationExecution.ARRAY_XYZ,
				publishingFederate);

		federationExecution.subscribeObjectClassAttributes(
				testFederationExecution.A1,
				testFederationExecution.ARRAY_XY,
				subscribingFederate);

		ObjectInstanceHandle objectInstanceHandle = federationExecution.registerObjectInstance(
				testFederationExecution.B1,
				publishingFederate);

		federationExecution.unsubscribeObjectClassAttributes(
				testFederationExecution.A1,
				testFederationExecution.ARRAY_X,
				subscribingFederate);

		assertEquals(0, federationExecution.getSubscriptions(
				objectInstanceHandle,
				testFederationExecution.ARRAY_X,
				publishingFederate).size());

		assertEquals(1, federationExecution.getSubscriptions(
				objectInstanceHandle,
				testFederationExecution.ARRAY_Y,
				publishingFederate).size());
	}

	public void testGetSubscriptions_ObjectClasses() throws Exception {
		LrcHandle lrcHandle = TestFederationExecution.getCrc().registerLrc(new TestLrcRemote());
		FederateHandle federateHandle1 = federationExecutionImpl.join("type", lrcHandle, null);

		// f1 publishes x, y and z
		federationExecution.publishObjectClassAttributes(
				testFederationExecution.B1,
				testFederationExecution.ARRAY_XYZ,
				federateHandle1);

		// f1 registers an object instance of B1
		ObjectInstanceHandle objectInstanceHandle = federationExecution.registerObjectInstance(
				testFederationExecution.B1,
				federateHandle1);

		FederateHandle federateHandle2 = federationExecutionImpl.join("type", lrcHandle, null);

		// f1 subscribes to xy (to test that getSubscriptions does not return
		// subscriptions of the asking federate)
		federationExecution.subscribeObjectClassAttributes(
				testFederationExecution.A1,
				testFederationExecution.ARRAY_XY,
				federateHandle1);

		// f2 subscribes to xy
		federationExecution.subscribeObjectClassAttributes(
				testFederationExecution.A1,
				testFederationExecution.ARRAY_XY,
				federateHandle2);

		FederateHandle federateHandle3 = federationExecutionImpl.join("type", lrcHandle, null);

		// f3 subscribes to x, y, and q
		federationExecution.subscribeObjectClassAttributes(
				testFederationExecution.B2,
				testFederationExecution.ARRAY_XYQ,
				federateHandle3);

		// f1 updates x, y and z
		Map<LrcRemote, Map<FederateHandle, AttributeHandle[]>> lrcs = federationExecution.getSubscriptions(
				objectInstanceHandle,
				testFederationExecution.ARRAY_XYZ,
				federateHandle1);

		assertEquals(1, lrcs.values().size());

		Map<FederateHandle, AttributeHandle[]> federatesMap = lrcs.values().iterator().next();
		assertEquals("federate handle 1 should be removed from result", 2, federatesMap.size());

		AttributeHandle[] subscriptionFederate2 = federatesMap.get(federateHandle2);

		// Federate 2 has subscribed to x and y and Federate 1 publishes to
		// x y and z. We should get x and y.
		assertEquals(new HashSet(Arrays.asList(testFederationExecution.ARRAY_XY)), new HashSet(Arrays
				.asList(subscriptionFederate2)));

		// Federate 3 has subscribed to x, y and q. Federate 1 publishes x, y
		// and z. We should
		// get x and y.
		AttributeHandle[] subscriptionFederate3 = federatesMap.get(federateHandle3);
		assertEquals(new HashSet(Arrays.asList(testFederationExecution.ARRAY_XY)), new HashSet(Arrays
				.asList(subscriptionFederate3)));
	}

	public void testGetSubscribedFederates_ObjectClasses_AttributeNotOwned() throws Exception {
		LrcHandle lrcHandle = TestFederationExecution.getCrc().registerLrc(new TestLrcRemote());
		FederateHandle federateHandle = federationExecutionImpl.join("type", lrcHandle, null);

		federationExecution.publishObjectClassAttributes(
				testFederationExecution.A1,
				testFederationExecution.ARRAY_X,
				federateHandle);

		ObjectInstanceHandle objectInstanceHandle = federationExecution.registerObjectInstance(
				testFederationExecution.A1,
				federateHandle);

		FederateHandle federateHandle1 = federationExecutionImpl.join("type", lrcHandle, null);
		try {
			federationExecution
					.getSubscriptions(objectInstanceHandle, testFederationExecution.ARRAY_X, federateHandle1);
			fail("Expected AttributeNotOwned exception");
		} catch (AttributeNotOwned expected) {
			assertTrue(true);
		}
	}

	public void testGetSubscriptions_InteractionClasses() throws Exception {
		LrcHandle lrcHandle = TestFederationExecution.getCrc().registerLrc(new TestLrcRemote());
		FederateHandle askingFederate = federationExecutionImpl.join("type", lrcHandle, null);
		FederateHandle federateHandle = federationExecutionImpl.join("type", lrcHandle, null);

		federationExecution.publishInteractionClass(testFederationExecution.I1, askingFederate);

		assertEquals(0, federationExecution.getSubscriptions(testFederationExecution.I1, askingFederate).size());

		federationExecution.subscribeInteractionClass(testFederationExecution.I1, federateHandle);
		System.out.println(federationExecution.getSubscriptions(testFederationExecution.I1, askingFederate));
		assertEquals(1, federationExecution.getSubscriptions(testFederationExecution.I1, askingFederate).values().iterator().next().size());

		FederateHandle federateHandle1 = federationExecutionImpl.join("type", lrcHandle, null);
		federationExecution.subscribeInteractionClass(testFederationExecution.I1, federateHandle1);
		assertEquals(2, federationExecution.getSubscriptions(testFederationExecution.I1, askingFederate).values().iterator().next().size());

		// Test that the asking federate is not included in the result of
		// subscribing federates
		federationExecution.subscribeInteractionClass(testFederationExecution.I1, askingFederate);
		assertEquals(
				"the asking federate must not be included in the result of subscribing federates",
				2,
				federationExecution.getSubscriptions(testFederationExecution.I1, askingFederate).values().iterator().next().size());
	}

	public void testUnsubscribeInteractionClass() throws Exception {
		LrcHandle lrcHandle = TestFederationExecution.getCrc().registerLrc(new TestLrcRemote());
		FederateHandle federateHandle = federationExecutionImpl.join("type", lrcHandle, null);
		federationExecution.publishInteractionClass(testFederationExecution.I1, federateHandle);
		federationExecution.subscribeInteractionClass(testFederationExecution.I1, federateHandle);
		federationExecution.unsubscribeInteractionClass(testFederationExecution.I1, federateHandle);
		assertEquals(0, federationExecution.getSubscriptions(testFederationExecution.I1, federateHandle).size());
	}

}
