/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.hla.launcher;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.rmi.NotBoundException;
import java.rmi.registry.Registry;
import java.util.EnumSet;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.eodisp.hla.common.crc.CrcRemote;
import org.eodisp.hla.crc.launcher.CrcProcessFactoryRemote;
import org.eodisp.hla.lrc.application.LrcConfiguration;
import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.remote.config.RemoteConfiguration.TransportType;
import org.eodisp.remote.launcher.RootAppProcessRemote;
import org.eodisp.remote.launcher.server.LaunchServerRemote;
import org.eodisp.remote.launcher.server.LaunchServerRemoteImpl;
import org.eodisp.remote.registry.JeriRegistry;
import org.eodisp.util.AppRegistry;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class CrcLauncher {
	private CrcRemote crcRemote;

	private RootAppProcessRemote processRemote;

	private RemoteAppModule remoteAppModule;

	private TransportType transportType;

	private URI launchServerUri;
	
	private URI uri;
	
	/**
	 * @param remoteAppModule
	 * @param transportType
	 * @param launchServerUri
	 */
	public CrcLauncher(RemoteAppModule remoteAppModule, TransportType transportType, URI launchServerUri) {
		this.remoteAppModule = remoteAppModule;
		this.transportType = transportType;
		this.launchServerUri = launchServerUri;
	}

	public CrcRemote getCrcRemote() {
		return crcRemote;
	}
	
	public RootAppProcessRemote getProcessRemote() {
		return processRemote;
	}
	
	/**
	 * @return the URI of the newly started CRC.
	 */
	public URI getUri() {
		return uri;
	}

	public boolean launch(long timeout, TimeUnit unit) throws URISyntaxException, NotBoundException,
			InstantiationException, IllegalAccessException, IOException, InterruptedException {
		Registry launchServerRegistry = remoteAppModule.getRegistry(launchServerUri);
		LaunchServerRemote launchServerRemote = (LaunchServerRemote) launchServerRegistry
				.lookup(LaunchServerRemoteImpl.REGISTRY_NAME);
		CrcProcessFactoryRemote crcProcessFactoryRemote = (CrcProcessFactoryRemote) launchServerRemote
				.newProcessFactory(CrcProcessFactoryRemote.FACTORY_ID);

		crcProcessFactoryRemote.setTransports(EnumSet.of(transportType));

		processRemote = (RootAppProcessRemote) crcProcessFactoryRemote.newProcess();

		Map<TransportType, JeriRegistry> crcRegistries;
		if ((crcRegistries = processRemote.launchBlocking(timeout, unit)) == null) {
			processRemote.kill(0);
			return false;
		}

		JeriRegistry crcJeriRegistry = crcRegistries.get(transportType);
		crcRemote = (CrcRemote) crcJeriRegistry.lookup(CrcRemote.REGISTRY_NAME);
		uri = crcJeriRegistry.getUri(transportType);
		return true;
	}

}
