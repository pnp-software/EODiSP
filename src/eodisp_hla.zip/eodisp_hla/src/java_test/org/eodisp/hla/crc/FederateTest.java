/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.hla.crc;

import java.util.Arrays;
import java.util.HashSet;

import hla.rti1516.*;

import org.eodisp.hla.common.lrc.LrcHandle;
import org.eodisp.hla.crc.data.Federate;
import org.eodisp.hla.crc.omt.ObjectClass;

import junit.framework.TestCase;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class FederateTest extends TestCase {

	@Override
	protected void setUp() throws Exception {
		// TODO Auto-generated method stub
		super.setUp();
	}

	/**
	 * Test method for
	 * {@link org.eodisp.hla.crc.data.impl.FederateImpl#checkPublication(org.eodisp.hla.crc.omt.ObjectClass)}.
	 * 
	 * @throws Exception
	 */
	public void testCheckPublicationObjectClass() throws Exception {
		TestFederationExecution testFederationExecution = new TestFederationExecution();
		FederationExecution federationExecution = testFederationExecution.getFederationExecution();
		FederateHandle federateHandle = federationExecution.join("type", new LrcHandle(0), null);
		federationExecution.publishObjectClassAttributes(
				testFederationExecution.B1,
				testFederationExecution.ARRAY_XYZ,
				federateHandle);

		Federate federate = federationExecution.getFederate(federateHandle);
		try {
			federate.checkPublication(federationExecution.getObjectClass(testFederationExecution.B1));
		} catch (ObjectClassNotPublished e) {
			fail("Unexpected Exception: " + e.toString());
		}
		assertTrue(true);
	}

	/**
	 * Test method for
	 * {@link org.eodisp.hla.crc.data.impl.FederateImpl#checkPublication(org.eodisp.hla.crc.omt.ObjectClass)}.
	 * 
	 * @throws Exception
	 */
	public void testCheckPublicationObjectClass_ObjectClassNotPublished() throws Exception {
		TestFederationExecution testFederationExecution = new TestFederationExecution();
		FederationExecution federationExecution = testFederationExecution.getFederationExecution();
		FederateHandle federateHandle = federationExecution.join("type",  new LrcHandle(0), null);
		federationExecution.publishObjectClassAttributes(
				testFederationExecution.B1,
				testFederationExecution.ARRAY_XYZ,
				federateHandle);

		Federate federate = federationExecution.getFederate(federateHandle);
		try {
			federate.checkPublication(federationExecution.getObjectClass(testFederationExecution.B2));
			fail("Expected exception ObjectClassNotPublished not thrown");
		} catch (ObjectClassNotPublished e) {
			assertTrue(true);
		}
	}

	/**
	 * Test method for
	 * {@link org.eodisp.hla.crc.data.impl.FederateImpl#checkPublication(java.util.Set)}.
	 * 
	 * @throws Exception
	 */
	public void testCheckPublicationSetOfAttribute() throws Exception {
		TestFederationExecution testFederationExecution = new TestFederationExecution();
		FederationExecution federationExecution = testFederationExecution.getFederationExecution();
		FederateHandle federateHandle = federationExecution.join("type",  new LrcHandle(0), null);
		federationExecution.publishObjectClassAttributes(
				testFederationExecution.B1,
				testFederationExecution.ARRAY_XYZ,
				federateHandle);

		Federate federate = federationExecution.getFederate(federateHandle);
		try {
			federate.checkPublication(federationExecution.getAttributes(
					testFederationExecution.B1,
					testFederationExecution.ARRAY_XYZ));
		} catch (AttributeNotPublished e) {
			fail("Unexpected Exception: " + e.toString());
		}
		assertTrue(true);
	}

	/**
	 * Test method for
	 * {@link org.eodisp.hla.crc.data.impl.FederateImpl#checkPublication(java.util.Set)}.
	 * 
	 * @throws Exception
	 */
	public void testCheckPublicationSetOfAttribute_AttributeNotPublished() throws Exception {
		TestFederationExecution testFederationExecution = new TestFederationExecution();
		FederationExecution federationExecution = testFederationExecution.getFederationExecution();
		FederateHandle federateHandle = federationExecution.join("type",  new LrcHandle(0), null);
		federationExecution.publishObjectClassAttributes(
				testFederationExecution.A1,
				testFederationExecution.ARRAY_XY,
				federateHandle);

		Federate federate = federationExecution.getFederate(federateHandle);
		try {
			federate.checkPublication(federationExecution.getAttributes(
					testFederationExecution.B1,
					testFederationExecution.ARRAY_XYZ));
			fail("Expected exception AttributeNotPublished not thrown");
		} catch (AttributeNotPublished e) {
			assertTrue(true);
		}
	}

	public void testGetPublishedObjectClasses() throws Exception {
		TestFederationExecution testFederationExecution = new TestFederationExecution();
		FederationExecution federationExecution = testFederationExecution.getFederationExecution();
		FederateHandle federateHandle = federationExecution.join("type",  new LrcHandle(0), null);
		federationExecution.publishObjectClassAttributes(
				testFederationExecution.B1,
				testFederationExecution.ARRAY_XYZ,
				federateHandle);

		federationExecution.publishObjectClassAttributes(
				testFederationExecution.A1,
				testFederationExecution.ARRAY_XY,
				federateHandle);

		Federate federate = federationExecution.getFederate(federateHandle);

		assertEquals(new HashSet<ObjectClass>(Arrays.asList(new ObjectClass[] {
				federationExecution.getObjectClass(testFederationExecution.B1),
				federationExecution.getObjectClass(testFederationExecution.A1) })), new HashSet<ObjectClass>(federate
				.getPublishedObjectClasses()));
	}

}
