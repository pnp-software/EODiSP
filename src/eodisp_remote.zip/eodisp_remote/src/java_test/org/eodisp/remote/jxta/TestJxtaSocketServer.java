package org.eodisp.remote.jxta;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URI;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import net.jxta.id.IDFactory;
import net.jxta.peer.PeerID;
import net.jxta.protocol.ConfigParams;
import net.jxta.socket.JxtaServerSocket;

import org.eodisp.remote.config.RemoteConfiguration;
import org.eodisp.remote.util.JXTAUtil;
import org.eodisp.remote.util.JxtaNetworkManager;
import org.eodisp.remote.util.NetworkConfigurator;
import org.eodisp.util.FileUtil;

public class TestJxtaSocketServer {

	private static final URI DEFAULT_EODISP_TCP_RENDEZVOUS = URI.create("tcp://rdv.eodisp.org:14301");

	private static final URI DEFAULT_EODISP_HTTP_RENDEZVOUS = URI.create("http://rdv.eodisp.org:80");

	private static final URI DEFAULT_EODISP_TCP_RELAY = URI.create("tcp://rdv.eodisp.org:14301");

	private static final URI DEFAULT_EODISP_HTTP_RELAY = URI.create("http://rdv.eodisp.org:80");

	public static ServerSocket getJxtaServerSocket() throws Exception {
		PeerID serverPeerID = (PeerID) IDFactory.fromURI(new URI(JeriServer.SERVER_PEER_ID));

		NetworkConfigurator networkConfigurator = NetworkConfigurator.newNetworkConfiguratorEdge();
		networkConfigurator.setPeerID(serverPeerID);
		networkConfigurator.setTcpPort(0);
		networkConfigurator.setTcpStartPort(-1);
		networkConfigurator.setTcpEndPort(-1);
		networkConfigurator.setUseMulticast(false);
		networkConfigurator.setName("TestJxtaSocketServer " + JXTAUtil.getComputerName());
		networkConfigurator.setDescription("TestJxtaSocketServer");
		networkConfigurator.addSeedRendezvous(DEFAULT_EODISP_TCP_RENDEZVOUS);
		networkConfigurator.addSeedRendezvous(DEFAULT_EODISP_HTTP_RENDEZVOUS);
		networkConfigurator.addSeedRelay(DEFAULT_EODISP_TCP_RELAY);
		networkConfigurator.addSeedRelay(DEFAULT_EODISP_HTTP_RELAY);


		JxtaNetworkManager networkManager = new JxtaNetworkManager(
				networkConfigurator.getPlatformConfig(),
				null,
				URI.create(RemoteConfiguration.DEFAULT_JXTA_NPG_URI));
		networkManager.start();

		final JxtaServerSocket jxtaServerSocket = new JxtaServerSocket(networkManager.getNetPeerGroup(), JeriUtil.getPipeAdvertisement(networkManager
						.getNetPeerGroup()));
		jxtaServerSocket.setSoTimeout(0);
		return jxtaServerSocket;
	}

	public static ServerSocket getTcpServerSocket(int port) throws Exception {
		return new ServerSocket(port);
	}

	private static class ClientConnection implements Runnable {

		private final Socket socket;

		public ClientConnection(Socket socket) {
			this.socket = socket;
		}

		public void run() {
			InputStream in;
			try {
				in = socket.getInputStream();
				long start = System.currentTimeMillis();
				long startDataPacket = System.currentTimeMillis();
				int dataPacketNr = 0;
				while (true) {
					byte[] received = getDataPacket();
					int packetLength = received.length;
					int bytesReceived = 0;
					do {
						System.out.println("read");
						bytesReceived += in.read(received, bytesReceived, packetLength - bytesReceived);
						System.out.println("read finished");
					} while (bytesReceived < packetLength);
					long duration = System.currentTimeMillis() - startDataPacket;
//					if (dataPacketNr % 100 == 0) {
						System.out.printf("%d: %,d bytes in %d ms (%dms)%n", dataPacketNr, (dataPacketNr + 1)
								* packetLength, System.currentTimeMillis() - start, duration);
//					}
					startDataPacket = System.currentTimeMillis();
					dataPacketNr++;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			System.out.println("got all data...");
		}
	}

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		ServerSocket serverSocket = null;
		String socketType = args[0];
		if (socketType.equals("jxta")) {
			serverSocket = getJxtaServerSocket();
		} else {
			int port = Integer.parseInt(args[1]);
			serverSocket = getTcpServerSocket(port);
		}

		serverSocket.setSoTimeout(0);
		ExecutorService threadPool = Executors.newCachedThreadPool();
		while (true) {
			System.out.println("Wait for accept");
			Socket socket = serverSocket.accept();
			threadPool.execute(new ClientConnection(socket));
			System.out.println("accepted");
		}

	}

	public static byte[] getDataPacket() {
		byte[] controlData = new byte[1024 * 1024 * 1];
		Arrays.fill(controlData, (byte) 3);
		controlData[0] = 0;
		controlData[1023] = 1;
		return controlData;
	}
}
