package org.eodisp.remote.local;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Hi extends Remote {
	void hi(Hello hello) throws RemoteException;
}
