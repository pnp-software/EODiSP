/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.remote.launcher;

import java.io.File;
import java.io.IOException;

import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.remote.launcher.server.application.RootAppStartedCallbackAppModule;
import org.eodisp.util.*;
import org.eodisp.util.configuration.CommandlineMapper;
import org.eodisp.util.configuration.ConfigurationImpl;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class TestRootApp extends RootApp implements TestRootAppRemote {
	public TestRootApp() throws IOException {
		super("TestRootApp", "TestRootApp", FileUtil.createTempDir("TestRootApp", "", null), TestRootApp.class);

		RemoteAppModule remoteAppModule = new RemoteAppModule(0);
		registerAppModule(remoteAppModule);

		AppModule testAppModule = new AppModule() {

			public String getId() {
				return "TestAppModule";
			}

			public void postShutdown(RootApp rootApp) throws Exception {

			}

			public void preStartup(RootApp rootApp) throws Exception {

			}

			public void registerConfiguration(RootApp rootApp) throws Exception {
				ConfigurationImpl testConfig = new ConfigurationImpl(
						"TestRootAppConfig",
						"TestRootAppConfig",
						"TestRootAppConfig",
						new File(rootApp.getConfigurationDir(), "testRootApp.conf"));
				testConfig.createIntEntry("id", -1, "test app id");
				rootApp.registerConfiguration(testConfig, CommandlineMapper.BASIC_COMMAND_LINE_MAPPER);
			}

			public void shutdown(RootApp rootApp) throws Exception {

			}

			public void startup(RootApp rootApp) throws Exception {
				RemoteAppModule remoteAppModule = (RemoteAppModule) AppRegistry.getRootApp().getAppModule(
						RemoteAppModule.ID);
				remoteAppModule.exportAndRegister(TestRootApp.this, "TestRootApp");
			}

		};

		registerAppModule(testAppModule);

		AppModule callbackAppModule = new RootAppStartedCallbackAppModule();
		registerAppModule(callbackAppModule);
	}

	public static void main(String[] args) throws IOException {
		TestRootApp testRootApp = new TestRootApp();
		testRootApp.execute(args);
	}

	public int getId() {
		return AppRegistry.getRootApp().getConfiguration("TestRootAppConfig").getEntry("id").getInt();
	}
}
