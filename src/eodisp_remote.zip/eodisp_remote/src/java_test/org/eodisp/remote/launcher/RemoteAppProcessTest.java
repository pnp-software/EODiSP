/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.remote.launcher;

import static java.util.concurrent.TimeUnit.SECONDS;

import java.io.IOException;
import java.util.EnumSet;
import java.util.Map;
import java.util.concurrent.CountDownLatch;

import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.remote.config.RemoteConfiguration.TransportType;
import org.eodisp.remote.registry.JeriRegistry;
import org.eodisp.util.FileUtil;
import org.eodisp.util.RootApp;
import org.eodisp.util.junit.FixtureTestCase;
import org.eodisp.util.launcher.ProcessListener;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class RemoteAppProcessTest extends FixtureTestCase {
	private static RemoteAppModule remoteAppModule;

	private RootAppProcess process;

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void setUpFixture() throws Exception {
		RootApp rootApp = new RootApp("RemoteAppProcessTest", "RemoteAppProcessTest", FileUtil.createTempDir(
				"TestRemoteRootApp",
				"",
				null), RemoteAppProcessTest.class);

		remoteAppModule = new RemoteAppModule(0);
		rootApp.registerAppModule(remoteAppModule);
		rootApp.execute(new String[] { "--log-level", "debug", "--transport", "jxta,tcp" });
	}

	@Override
	protected void tearDown() throws Exception {
		process.kill(1000);
	}

	static RootAppProcess newTestRemoteRootApp(TransportType transportType) throws IOException {
		RootAppProcess remoteAppProcess = new RootAppProcessImpl(TestRootApp.class.getName(), FileUtil.createTempDir(
				"TestRemoteRootApp",
				"",
				null), EnumSet.of(transportType), 0, transportType, null);
		return remoteAppProcess;
	}

	/**
	 * Test method for
	 * {@link org.eodisp.remote.launcher.RootAppProcess#addRemoteAppStateListener(org.eodisp.remote.launcher.RootAppStateListener)}.
	 */
	public void testAddRemoteAppStateListenerJxta() throws Exception {
		process = newTestRemoteRootApp(TransportType.JXTA);
		final CountDownLatch countDownLatch1 = new CountDownLatch(1);
		process.addRemoteAppStateListener(new RootAppStateListener() {
			public void started(Map<TransportType, JeriRegistry> registryProxies) {
				System.out.println(registryProxies);
				countDownLatch1.countDown();
			}
		});

		process.launch();
		assertTrue(countDownLatch1.await(20, SECONDS));
	}

	public void testAddRemoteAppStateListenerTcp() throws Exception {
		process = newTestRemoteRootApp(TransportType.TCP);
		final CountDownLatch countDownLatch1 = new CountDownLatch(1);
		process.addRemoteAppStateListener(new RootAppStateListener() {
			public void started(Map<TransportType, JeriRegistry> registryProxies) {
				System.out.println(registryProxies);
				countDownLatch1.countDown();
			}
		});

		process.launch();
		assertTrue(countDownLatch1.await(20, SECONDS));
	}

	/**
	 * Test method for {@link org.eodisp.util.launcher.Process#launch()}.
	 * 
	 * @throws IOException
	 */
	public void testLaunch() throws Exception {
		process = newTestRemoteRootApp(TransportType.TCP);
		final CountDownLatch countDownLatch1 = new CountDownLatch(1);
		final CountDownLatch countDownLatch2 = new CountDownLatch(1);
		process.addListener(new ProcessListener() {
			public void processStarted() {
				countDownLatch1.countDown();
			}

			public void processTerminated(int exitCode) {
				countDownLatch2.countDown();
			}
		});
		process.launch();
		assertTrue(countDownLatch1.await(1, SECONDS));
		process.kill(5000);
		assertTrue(countDownLatch2.await(1, SECONDS));
	}

	public void testLauchBlocking() throws Exception {
		long now = System.currentTimeMillis();
		process = newTestRemoteRootApp(TransportType.TCP);
		process.launchBlocking(100, SECONDS);
		long livedFor = System.currentTimeMillis() - now;
		assertTrue(String.format("Lived for: %d", livedFor), livedFor < SECONDS.toMillis(100));
	}

}
