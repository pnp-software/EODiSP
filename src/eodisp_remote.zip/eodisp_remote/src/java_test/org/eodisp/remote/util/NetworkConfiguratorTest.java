package org.eodisp.remote.util;

import java.io.File;
import java.io.IOException;

import junit.framework.TestCase;

public class NetworkConfiguratorTest extends TestCase {

	public void testNewNetworkConfiguratorEdge() throws IOException {
		NetworkConfigurator networkConfigurator = NetworkConfigurator.newNetworkConfiguratorEdge();
		networkConfigurator.setProxyEnabled(true);
		networkConfigurator.setHttpEnabled(false);
		networkConfigurator.setRelayEnabled(false);

		File tmpOutFile = File.createTempFile("PlatfromConfig", "");
		networkConfigurator.save(tmpOutFile);
		System.out.println(tmpOutFile.getAbsolutePath());

		NetworkConfigurator networkConfiguratorLoaded = NetworkConfigurator.loadPlatformConfig(tmpOutFile.toURI());
		networkConfiguratorLoaded.savePlatformConfig(System.out);
		assertEquals(true, networkConfiguratorLoaded.isProxyEnabled());
		assertEquals(false, networkConfiguratorLoaded.isHttpEnabled());
		assertEquals(false, networkConfiguratorLoaded.isRelayEnabled());
	}
}
