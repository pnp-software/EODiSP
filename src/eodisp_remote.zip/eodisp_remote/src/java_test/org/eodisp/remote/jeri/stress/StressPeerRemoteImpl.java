/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.remote.jeri.stress;

import java.rmi.RemoteException;

import net.jcip.annotations.ThreadSafe;

import org.apache.log4j.Logger;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
@ThreadSafe
public class StressPeerRemoteImpl implements StressPeerRemote {
	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	private final static Logger logger = Logger.getLogger(StressPeerRemoteImpl.class);

	/**
	 * {@inheritDoc}
	 */
	public void stressOther(final StressPeerRemote peerToBeStressed, final int numberOfCalls,
			final long pauseBetweenCalls, final long computationTimePerCall, final int numberOfBytesPerCall)
			throws RemoteException {
		if (numberOfCalls < 0) {
			throw new IllegalArgumentException("numberOfCalls must be >= 0");
		}
		Runnable stressTask = new Runnable() {
			public void run() {
				byte[] data = new byte[numberOfBytesPerCall];
				int i = 0;
				if (numberOfCalls == 0) {
					i = -1;
				}
				while (i < numberOfCalls) {
					try {
//						logger.debug(String.format("%d: stress %s",i, peerToBeStressed));
						peerToBeStressed.stress(data, computationTimePerCall);
						if (pauseBetweenCalls > 0) {
							Thread.sleep(pauseBetweenCalls);
						}
					} catch (InterruptedException e) {
						Thread.currentThread().interrupt();
					} catch (RemoteException e) {
						e.printStackTrace();
					}
					if (numberOfCalls != 0) {
						i++;
					}
				}
			}
		};
		Thread t = new Thread(stressTask);
		t.start();
	}

	/**
	 * {@inheritDoc}
	 */
	public void stress(byte[] data, long computationTime) {
		try {
			Thread.sleep(computationTime);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
