package org.eodisp.remote.local;

import java.io.Serializable;


public class HelloImpl implements Hello, Serializable {
	
	private transient final String who;

	public HelloImpl(String what) {
		this.who = what;
	}

	public void hello() {
//		System.out.println("Hello " + who);
	}

}
