package org.eodisp.remote.local;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Hello extends Remote {
	void hello() throws RemoteException;
}
