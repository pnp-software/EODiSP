/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.remote.jeri.stress;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public interface StressPeerRemote extends Remote {
	public final static String REGISTRY_KEY = "org.eodisp.remote.jeri.stress.StressPeerRemote";

	/**
	 * Stresses a peer by invoking
	 * {@link StressServerRemote#stress(byte[], long)} on that peer. This method
	 * returns immediately and does not wait for the stress to be carried out.
	 * 
	 * @param peerToBeStressed
	 *            the peer on which the <code>stress(...)</code> method is
	 *            being called
	 * @param numberOfCalls
	 *            the number of calls made on the stress server. <code>0</code>
	 *            means no limit on the number of calls and so, continues
	 *            forever.
	 * @param pauseBetweenCalls
	 *            the number of milliseconds between each call to
	 *            <code>stress()</code>
	 * @param computationTimePerCall
	 *            the computation time that is handed to the
	 *            <code>stress()</code> method. Determines how long it takes
	 *            the <code>stress()</code> method to return.
	 * @param numberOfBytesPerCall
	 *            the number of bytes that is handed to the
	 *            <code>stress()</code> method.
	 * @throws RemoteException
	 *             RMI remote exception
	 */
	public void stressOther(StressPeerRemote peerToBeStressed, int numberOfCalls, long pauseBetweenCalls,
			long computationTimePerCall, int numberOfBytesPerCall) throws RemoteException;

	/**
	 * This method does not to anything but sleep for the given
	 * <code>computationTime</code>.
	 * 
	 * @param data
	 *            only used to simulate the transfer of a certain amount of
	 *            data. The parameter is not used in the method implementation.
	 * @param computationTime
	 *            The time this method shall sleep until it returns.
	 *            <code>0</code> means to sleep forever, <code>-1</code> to
	 *            immediately return.
	 */
	void stress(byte[] data, long computationTime) throws RemoteException;
}
