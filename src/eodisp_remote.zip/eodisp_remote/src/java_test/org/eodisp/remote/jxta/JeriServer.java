package org.eodisp.remote.jxta;

import java.io.IOException;
import java.net.URI;
import java.rmi.RemoteException;

import net.jini.jeri.ServerEndpoint;
import net.jini.jeri.ssl.SslServerEndpoint;
import net.jini.jeri.tcp.TcpServerEndpoint;
import net.jxta.id.IDFactory;
import net.jxta.peer.PeerID;

import org.eodisp.remote.config.RemoteConfiguration;
import org.eodisp.remote.jeri.internal.nomux.TcpServerEndpointNoMux;
import org.eodisp.remote.jeri.jxta.JxtaNetwork;
import org.eodisp.remote.jeri.jxta.JxtaServerEndpoint;
import org.eodisp.remote.jeri.tcp.fastmux.TcpServerEndpointFastMux;
import org.eodisp.remote.util.JXTAUtil;
import org.eodisp.remote.util.JxtaNetworkManager;
import org.eodisp.remote.util.NetworkConfigurator;

public class JeriServer {
	private static final URI DEFAULT_EODISP_TCP_RENDEZVOUS = URI.create("tcp://rdv.eodisp.org:14301");

	private static final URI DEFAULT_EODISP_HTTP_RENDEZVOUS = URI.create("http://rdv.eodisp.org:80");

	private static final URI DEFAULT_EODISP_TCP_RELAY = URI.create("tcp://rdv.eodisp.org:14301");

	private static final URI DEFAULT_EODISP_HTTP_RELAY = URI.create("http://rdv.eodisp.org:80");

	public static final String SERVER_PEER_ID = "urn:jxta:uuid-59616261646162614A78746150325033DAA3E257D6C240278409F581EBCB844C03";

	public static void main(String[] args) throws IOException {
		if (args[0].equals("jxta")) {
			jxtaSockets();
		} else if (args[0].equals("tcp")) {
			normalSockets(Integer.parseInt(args[1]));
		} else if (args[0].equals("ssl")) {
			sslSockets(Integer.parseInt(args[1]));
		} else if (args[0].equals("tcpnomux")) {
			tcpnomuxSockets(Integer.parseInt(args[1]));
		} else if (args[0].equals("tcpfastmux")) {
			tcpFastMux(Integer.parseInt(args[1]));
		}

		System.out.println("Press key to exit...");
		System.in.read();

	}

	public static void sslSockets(int port) {
		ServerEndpoint serverEndpoint = SslServerEndpoint.getInstance(port);
		try {
			JeriUtil.startServer(serverEndpoint);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	public static void tcpFastMux(int port) {
		ServerEndpoint serverEndpoint = TcpServerEndpointFastMux.getInstance(port);
		try {
			JeriUtil.startServer(serverEndpoint);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	public static void tcpnomuxSockets(int port) {
		ServerEndpoint serverEndpoint = TcpServerEndpointNoMux.getInstance(port);
		try {
			JeriUtil.startServer(serverEndpoint);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	public static void normalSockets(int port) {
		ServerEndpoint serverEndpoint = TcpServerEndpoint.getInstance(port);
		try {
			JeriUtil.startServer(serverEndpoint);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	public static void jxtaSockets() {
		try {
			PeerID serverPeerID = (PeerID) IDFactory.fromURI(new URI(SERVER_PEER_ID));

			NetworkConfigurator networkConfigurator = NetworkConfigurator.newNetworkConfiguratorEdge();
			networkConfigurator.setPeerID(serverPeerID);
			networkConfigurator.setTcpPort(0);
			networkConfigurator.setTcpStartPort(-1);
			networkConfigurator.setTcpEndPort(-1);
			networkConfigurator.setUseMulticast(false);
			networkConfigurator.setName("TestJxtaSocketClient " + JXTAUtil.getComputerName());
			networkConfigurator.setDescription("TestJxtaSocketClient");
			networkConfigurator.addSeedRendezvous(DEFAULT_EODISP_TCP_RENDEZVOUS);
			networkConfigurator.addSeedRendezvous(DEFAULT_EODISP_HTTP_RENDEZVOUS);
			networkConfigurator.addSeedRelay(DEFAULT_EODISP_TCP_RELAY);
			networkConfigurator.addSeedRelay(DEFAULT_EODISP_HTTP_RELAY);

			JxtaNetworkManager networkManager = new JxtaNetworkManager(
					networkConfigurator.getPlatformConfig(),
					null,
					URI.create(RemoteConfiguration.DEFAULT_JXTA_NPG_URI));
			networkManager.start();

			JxtaNetwork.registerJeriPeerGroup(networkManager.getNetPeerGroup());
			ServerEndpoint serverEndpoint = JxtaServerEndpoint.getInstance();
			JeriUtil.startServer(serverEndpoint);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
