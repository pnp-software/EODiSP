package org.eodisp.remote.jxta;

import java.io.File;
import java.io.OutputStream;
import java.net.Socket;
import java.net.URI;

import net.jxta.id.IDFactory;
import net.jxta.impl.protocol.PlatformConfig;
import net.jxta.impl.protocol.RdvConfigAdv.RendezVousConfiguration;
import net.jxta.peer.PeerID;
import net.jxta.protocol.ConfigParams;
import net.jxta.socket.JxtaSocket;

import org.eodisp.remote.config.RemoteConfiguration;
import org.eodisp.remote.util.*;
import org.eodisp.util.FileUtil;

public class TestJxtaSocketClient {

	private static final URI DEFAULT_EODISP_TCP_RENDEZVOUS = URI.create("tcp://rdv.eodisp.org:14301");

	private static final URI DEFAULT_EODISP_HTTP_RENDEZVOUS = URI.create("http://rdv.eodisp.org:80");

	private static final URI DEFAULT_EODISP_TCP_RELAY = URI.create("tcp://rdv.eodisp.org:14301");

	private static final URI DEFAULT_EODISP_HTTP_RELAY = URI.create("http://rdv.eodisp.org:80");

	public static Socket getJxtaSocket(int buffer) throws Exception {
		NetworkConfigurator networkConfigurator = NetworkConfigurator.newNetworkConfiguratorEdge();
		networkConfigurator.setTcpPort(0);
		networkConfigurator.setTcpStartPort(-1);
		networkConfigurator.setTcpEndPort(-1);
		networkConfigurator.setUseMulticast(false);
		networkConfigurator.setName("TestJxtaSocketClient " + JXTAUtil.getComputerName());
		networkConfigurator.setDescription("TestJxtaSocketClient");
		networkConfigurator.addSeedRendezvous(DEFAULT_EODISP_TCP_RENDEZVOUS);
		networkConfigurator.addSeedRendezvous(DEFAULT_EODISP_HTTP_RENDEZVOUS);
		networkConfigurator.addSeedRelay(DEFAULT_EODISP_TCP_RELAY);
		networkConfigurator.addSeedRelay(DEFAULT_EODISP_HTTP_RELAY);

		ConfigParams platformConfig = networkConfigurator.getPlatformConfig();
		
		JxtaNetworkManager networkManager = new JxtaNetworkManager(
				networkConfigurator.getPlatformConfig(),
				null,
				URI.create(RemoteConfiguration.DEFAULT_JXTA_NPG_URI));
		networkManager.start();

		PeerID serverPeerID = (PeerID) IDFactory.fromURI(new URI(JeriServer.SERVER_PEER_ID));

		JxtaSocket socket = new JxtaSocket(networkManager.getNetPeerGroup(), serverPeerID, JeriUtil
				.getPipeAdvertisement(networkManager.getNetPeerGroup()), 30000, true);
		socket.setOutputStreamBufferSize(buffer);
		socket.setSendBufferSize(buffer);
		return socket;
	}

	public static Socket getTcpSocket(String host, int port) throws Exception {
		return new Socket(host, port);
	}

	public static void sendData(Socket socket) throws Exception {
		OutputStream out = socket.getOutputStream();

		byte[] dataToSend = TestJxtaSocketServer.getDataPacket();
		int times = 1;
		long now = System.currentTimeMillis();
		for (int i = 0; i < times; i++) {
			out.write(dataToSend);
			System.out.printf("Sent %,d Kb%n", dataToSend.length / 1024);
		}
		System.out.printf("Sent %,d bytes of data in %dms%n", times * dataToSend.length, System.currentTimeMillis()
				- now);
		out.close();
	}

	public static void main(String[] args) {
		long now = 0;
		try {
			Socket socket = null;
			String socketType = args[0];
			now = System.currentTimeMillis();
			if (socketType.equals("jxta")) {
				int buffer = Integer.parseInt(args[1]);
				socket = getJxtaSocket(buffer);
			} else {
				String host = args[1];
				int port = Integer.parseInt(args[2]);
				socket = getTcpSocket(host, port);
			}

			sendData(socket);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			System.out.printf("Time: %d%n", System.currentTimeMillis() - now);
		}
	}
}
