/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.remote.launcher;

import java.net.URI;
import java.rmi.registry.Registry;

import org.apache.log4j.Level;
import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.remote.launcher.server.LaunchServerRemote;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class StartStressPeer {

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
//		Logger.getLogger("net.jini").setLevel(Level.ALL);
//		final ConsoleHandler consoleHandler = new ConsoleHandler();
//		consoleHandler.setLevel(Level.ALL);
//		Logger.getLogger("net.jini").addHandler(consoleHandler);
		
	
		
		TestRootApp testRootApp = new TestRootApp();
		testRootApp.execute(args);
		System.out.println("Application started");
		org.apache.log4j.Logger.getLogger("net.jxta.socket").setLevel(Level.ALL);
//		org.apache.log4j.Logger.getLogger("net.jxta.impl.pipe").setLevel(Level.ALL);
		
		
		

		RemoteAppModule remoteAppModule = (RemoteAppModule) testRootApp.getAppModule(RemoteAppModule.ID);
		// local
//		 Registry launchServerRegistry = remoteAppModule.getRegistry(URI
//		 .create("urn:jxta:uuid-59616261646162614E50472050325033B21F73B089634ED3A92A84A8E36C94F303"));
		// rdv.eodisp.org
		Registry launchServerRegistry = remoteAppModule.getRegistry(URI
				.create("urn:jxta:uuid-59616261646162614E5047205032503366B3E244549145D49D09D148DEDFBF2B03"));

		System.out.println("Received launch server registry");
		LaunchServerRemote launchServer = (LaunchServerRemote) launchServerRegistry
				.lookup(LaunchServerRemote.REGISTRY_NAME);
		System.out.println("received launch server proxy from registry");
		System.out.println("OK");
		// RootAppProcessFactoryRemote processFactory =
		// (RootAppProcessFactoryRemote) launchServer
		// .newProcessFactory("org.eodisp.remote.jeri.stress.StressPeerProcessFactory");
		// System.out.println("received process factory");
		//
		// RootAppProcessRemote process = (RootAppProcessRemote)
		// processFactory.newProcess();
		//
		// System.out.println("Created new process, try to start new process for
		// 60 seconds");
		// Map<TransportType, JeriRegistry> stressPeerRegistries =
		// process.launchBlocking(60, TimeUnit.SECONDS);
		// System.out.println("Process started");
		//
		// if (stressPeerRegistries == null) {
		// System.err.println(String.format("Could not start stress peer on %s",
		// launchServer));
		// }
		// JeriRegistry stressPeerRegistry =
		// stressPeerRegistries.get(TransportType.JXTA);
		// System.out.println("received jxta registry from stress peer");
		// StressPeerRemote stressPeer = (StressPeerRemote)
		// stressPeerRegistry.lookup(StressPeerRemote.REGISTRY_KEY);
		// System.out.println("received stress peer proxy from stress peer
		// registry");
		//		
		// System.out.printf("Starting OK of %s, kill it and exit%n",
		// stressPeer);
		// process.kill(60000);
		System.exit(0);
	}

}
