/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.remote.launcher;

import static java.util.concurrent.TimeUnit.SECONDS;

import java.net.URI;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.*;
import java.util.concurrent.CountDownLatch;

import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.remote.config.RemoteConfiguration.TransportType;
import org.eodisp.remote.launcher.server.LaunchServerRemote;
import org.eodisp.remote.registry.JeriRegistry;
import org.eodisp.util.FileUtil;
import org.eodisp.util.RootApp;
import org.eodisp.util.junit.FixtureTestCase;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class LaunchServerTest extends FixtureTestCase {

	private static RemoteAppModule remoteAppModule;

	private static RootAppProcessImpl testLaunchServerProcess;

	private static LaunchServerRemote launchServerRemote;

	/**
	 * {@inheritDoc}
	 * 
	 * Starts a TestLaunchServer.
	 */
	@Override
	protected void setUpFixture() throws Exception {
		RootApp rootApp = new RootApp("RemoteAppProcessTest", "RemoteAppProcessTest", FileUtil.createTempDir(
				"TestRemoteRootApp",
				"",
				null), LaunchServerTest.class);

		remoteAppModule = new RemoteAppModule(0);
		rootApp.registerAppModule(remoteAppModule);
		rootApp.execute(new String[] { "--log-level", "debug", "--transport", "jxta,tcp" });

		testLaunchServerProcess = new RootAppProcessImpl(TestLaunchServer.class.getName(), FileUtil.createTempDir(
				"TestLaunchServer",
				"",
				null), EnumSet.of(TransportType.TCP), 22222, TransportType.TCP, "");
		// Wait until it is launched
		testLaunchServerProcess.launchBlocking(30, SECONDS);
		JeriRegistry launchServerRegistry = remoteAppModule.getRegistry(URI.create("tcp://localhost:22222"));
		launchServerRemote = (LaunchServerRemote) launchServerRegistry.lookup(
				LaunchServerRemote.REGISTRY_NAME,
				TransportType.TCP);
	}

	@Override
	protected void tearDownFixture() throws Exception {
		testLaunchServerProcess.kill(1000);
	}

	/**
	 * Starts several remote processes and tests if they are properly started
	 * and terminated.
	 */
	public void testRemoteApp() throws Exception {

		final CountDownLatch countDownLatch = new CountDownLatch(10);
		TestProcessFactoryRemote processFactory = (TestProcessFactoryRemote) launchServerRemote
				.newProcessFactory("org.eodisp.remote.launcher.TestProcessFactoryRemoteImpl");
		processFactory.setRunningTime(1);
		for (int i = 0; i < 5; i++) {

			ProcessRemote processRemote = processFactory.newProcess();

			ProcessListenerRemote processListenerRemote = new ProcessListenerRemote() {
				public void processStarted() throws RemoteException {
					countDownLatch.countDown();
				}

				public void processTerminated(int exitCode) throws RemoteException {
					countDownLatch.countDown();
				}
			};

			final ProcessListenerRemote remoteProcessListener = (ProcessListenerRemote) remoteAppModule.export(
					processListenerRemote,
					TransportType.TCP);
			processRemote.addListener(remoteProcessListener);
			processRemote.launch();
		}

		assertTrue(countDownLatch.await(10, SECONDS));
	}

	public void testRemoteRootApp() throws Exception {
		List<ProcessRemote> remoteProcesses = new ArrayList<ProcessRemote>();
		try {
			final int nrOfTests = 3;
			final Set<Integer> startedApps = new HashSet<Integer>();

			final CountDownLatch countDownLatch = new CountDownLatch(nrOfTests);
			TestRootAppProcessFactoryRemote processFactoryRemote = (TestRootAppProcessFactoryRemote) launchServerRemote
					.newProcessFactory("org.eodisp.remote.launcher.TestRootAppProcessFactoryImpl");
			processFactoryRemote.setTransports(EnumSet.of(TransportType.JXTA, TransportType.TCP));

			for (int i = 0; i < nrOfTests; i++) {
				processFactoryRemote.setId(i);
				RootAppProcessRemote process = (RootAppProcessRemote) processFactoryRemote.newProcess();
				remoteProcesses.add(process);
				final RootAppStateListenerRemote stateListenerImpl = new RootAppStateListenerRemote() {
					public void started(Map<TransportType, JeriRegistry> registryProxies) throws RemoteException {
						System.out.println("STARTED: " + registryProxies);
						try {
							TestRootAppRemote remoteRootApp = (TestRootAppRemote) registryProxies.get(
									TransportType.JXTA).lookup("TestRootApp");
							final int appId = remoteRootApp.getId();
							System.out.println(String.format("Started app with id: %s", appId));
							startedApps.add(new Integer(appId));
							countDownLatch.countDown();
						} catch (NotBoundException e) {
							e.printStackTrace();
						}
					}
				};
				final RootAppStateListenerRemote stateListener = (RootAppStateListenerRemote) remoteAppModule.export(
						stateListenerImpl,
						TransportType.TCP);
				process.addRemoteAppStateListener(stateListener);
				process.launch();
			}
			assertTrue(countDownLatch.await(120, SECONDS));
			assertEquals("Not all applications returned a unique id", nrOfTests, startedApps.size());
		} finally {
			for (ProcessRemote remote : remoteProcesses) {
				if (!remote.kill(60 * 1000)) {
					System.err.println("Could not kill remote process");
				}
			}
		}
	}

}
