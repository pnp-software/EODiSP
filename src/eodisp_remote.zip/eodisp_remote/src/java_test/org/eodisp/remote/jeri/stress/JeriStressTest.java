/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.remote.jeri.stress;

import java.net.URI;
import java.rmi.RemoteException;
import java.rmi.registry.Registry;
import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.remote.config.RemoteConfiguration.TransportType;
import org.eodisp.remote.launcher.RootAppProcessFactoryRemote;
import org.eodisp.remote.launcher.RootAppProcessRemote;
import org.eodisp.remote.launcher.TestRootApp;
import org.eodisp.remote.launcher.server.LaunchServerRemote;
import org.eodisp.remote.registry.JeriRegistry;
import org.eodisp.util.junit.FixtureTestCase;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class JeriStressTest extends FixtureTestCase {

	private final class StressedPeer implements StressPeerRemote {
		private final CountDownLatch[] latches;

		private final long[] times;

		private final int[] counts;

		private StressedPeer(CountDownLatch[] latches) {
			this.latches = latches;
			this.counts = new int[latches.length];
			this.times = new long[latches.length];
		}

		public void stress(byte[] data, long computationTime) {
			latches[data.length].countDown();
			counts[data.length]++;
			if (counts[data.length] % 100 == 0) {
				final long now = System.currentTimeMillis();
				System.out.println(String.format("Received 100 calls from stress peer %d in %dms", data.length, now
						- times[data.length]));
				times[data.length] = now;
			}
		}

		public void stressOther(StressPeerRemote peerToBeStressed, int numberOfCalls, long pauseBetweenCalls,
				long computationTimePerCall, int numberOfBytesPerCall) throws RemoteException {
			System.out.println("stressOther should neve be called on the test instance");
		}
	}

	private static LaunchServerRemote launchServer1;

	private static LaunchServerRemote launchServer2;

	private static RemoteAppModule remoteAppModule;

	@Override
	protected void setUpFixture() throws Exception {
		TestRootApp testRootApp = new TestRootApp();
		testRootApp.execute(new String[] { "--log-level", "debug" });

		remoteAppModule = (RemoteAppModule) testRootApp.getAppModule(RemoteAppModule.ID);

		// Registry launchServerRegistry =
		// remoteAppModule.getRegistry(URI.create("tcp://localhost:14355"));
		// Registry launchServerRegistry = remoteAppModule.getRegistry(URI
		// .create("urn:jxta:uuid-59616261646162614E50472050325033B21F73B089634ED3A92A84A8E36C94F303"));
		// windows
		Registry launchServerRegistry = remoteAppModule.getRegistry(URI
				.create("urn:jxta:uuid-59616261646162614E50472050325033E98D0F7B428E4758B724B6E216663ECE03"));
		launchServer1 = (LaunchServerRemote) launchServerRegistry.lookup(LaunchServerRemote.REGISTRY_NAME);
		
	}

	public void testStress1() throws Exception {
		// must be even!
		final int nrOfProcesses = 5;
		final int nrOfTasksPerThread = 1000;
		final CountDownLatch[] countDownLatchs = new CountDownLatch[nrOfProcesses];
		for (int i = 0; i < nrOfProcesses; i++) {
			countDownLatchs[i] = new CountDownLatch(nrOfTasksPerThread);
		}

		RootAppProcessFactoryRemote processFactory = (RootAppProcessFactoryRemote) launchServer1
				.newProcessFactory("org.eodisp.remote.jeri.stress.StressPeerProcessFactory");
		processFactory.setTransports(EnumSet.of(TransportType.JXTA));
		System.out.println(processFactory);
		// create stress peer processes
		List<RootAppProcessRemote> processes = new ArrayList<RootAppProcessRemote>();
		for (int i = 0; i < nrOfProcesses; i++) {
			processes.add((RootAppProcessRemote) processFactory.newProcess());
		}
		try {

			List<StressPeerRemote> stressPeers = new ArrayList<StressPeerRemote>();
			// start processes
			for (RootAppProcessRemote process : processes) {
				System.out.println("JUnit: Start stress Peer...");
				Map<TransportType, JeriRegistry> stressPeerRegistries = process.launchBlocking(60, TimeUnit.SECONDS);
				JeriRegistry stressPeerRegistry = stressPeerRegistries.get(TransportType.JXTA);
				if (stressPeerRegistries == null) {
					fail(String.format("Could not start stress peer on %s", launchServer1));
				}
				stressPeers.add((StressPeerRemote) stressPeerRegistry.lookup(StressPeerRemote.REGISTRY_KEY));
			}

			StressPeerRemote[] stressedPeers = new StressPeerRemote[nrOfProcesses];
			for (int i = 0; i < stressedPeers.length; i++) {
				final StressedPeer stressedPeer = new StressedPeer(countDownLatchs);
				stressedPeers[i] = (StressPeerRemote) remoteAppModule.export(stressedPeer);
			}

			// Stress from 10 threads by stressPeer 1
			for (int i = 0; i < nrOfProcesses; i++) {
				System.out.println(String.format("Start stress on peer %d", i));
				StressPeerRemote stressPeerRemote = stressPeers.get(i);
				stressPeerRemote.stressOther(stressedPeers[i], nrOfTasksPerThread, 0, 0, i);
			}

			System.out.println("All stress jobs started");
			for (CountDownLatch countDownLatch : countDownLatchs) {
				countDownLatch.await(60 * 60, TimeUnit.SECONDS);
			}

		} finally {
			for (RootAppProcessRemote process : processes) {
				process.kill(60 * 1000);
			}

		}
	}
}
