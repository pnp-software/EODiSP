package org.eodisp.remote.launcher;

import java.rmi.RemoteException;

public interface TestRootAppProcessFactoryRemote extends RootAppProcessFactoryRemote {
	public abstract void setId(int id) throws RemoteException;
}