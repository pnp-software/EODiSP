/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.remote.local;

import java.rmi.RemoteException;
import java.rmi.server.ExportException;
import java.rmi.server.UnicastRemoteObject;

import net.jini.jeri.BasicILFactory;
import net.jini.jeri.BasicJeriExporter;
import net.jini.jeri.tcp.TcpServerEndpoint;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class LocalRmiTest {
	public static void main(String[] args) {
		HelloImpl iwan = new HelloImpl("Iwan");
		HiImpl hiIwan = new HiImpl();
		System.out.println("Iwan Local");
		testPerf(iwan);
		hiIwan.hi(iwan);

		try {
			Hello iwanRemote = (Hello) UnicastRemoteObject.exportObject(iwan, 22000);
			Hi hiIwanRemote  = (Hi) UnicastRemoteObject.exportObject(hiIwan, 22000);
			hiIwanRemote.hi(iwanRemote);
			System.out.println(iwanRemote);
			System.out.println("Iwan Remote");
			testPerf(iwanRemote);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// The same but with Jeri
		HelloImpl elch = new HelloImpl("elch");
		HiImpl hiElch  = new HiImpl();
		System.out.println("Elch Local");
		testPerf(elch);
		
		System.setProperty("com.sun.jini.jeri.tcp.useNIO", "true");

		BasicJeriExporter basicJeriExporter1 = new BasicJeriExporter(
				TcpServerEndpoint.getInstance(21000),
				new BasicILFactory(),false, false);
		BasicJeriExporter basicJeriExporter2 = new BasicJeriExporter(
				TcpServerEndpoint.getInstance(21000),
				new BasicILFactory(),false, false);
		try {
			Hello elchRemote = (Hello) basicJeriExporter1.export(elch);
			Hi hiRemote      = (Hi)    basicJeriExporter2.export(hiElch);
			hiRemote.hi(elchRemote);			
			System.out.println("Elch Remote");
			System.out.println(elchRemote);
			testPerf(elchRemote);
		} catch (ExportException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

	public static void testPerf(Hello hello) {
		long now = System.currentTimeMillis();
		for (int i = 0; i < 10; i++) {
			try {
				hello.hello();
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println(System.currentTimeMillis() - now);
	}
}
