/*
 *  Copyright (c) 2006 Sun Microsystems, Inc.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  2. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  3. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Sun Microsystems, Inc. for Project JXTA."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  4. The names "Sun", "Sun Microsystems, Inc.", "JXTA" and "Project JXTA" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact Project JXTA at http://www.jxta.org.
 *
 *  5. Products derived from this software may not be called "JXTA",
 *  nor may "JXTA" appear in their name, without prior written
 *  permission of Sun.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL SUN MICROSYSTEMS OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 *  ====================================================================
 *
 *  This software consists of voluntary contributions made by many
 *  individuals on behalf of Project JXTA.  For more
 *  information on Project JXTA, please see
 *  <http://www.jxta.org/>.
 *
 *  This license is based on the BSD license adopted by the Apache Foundation.
 *
 *  $Id: NetworkManager.java,v 1.9 2006/07/13 20:30:12 hamada Exp $
 */
package org.eodisp.remote.jxta;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.util.Calendar;

import net.jxta.credential.AuthenticationCredential;
import net.jxta.credential.Credential;
import net.jxta.exception.PeerGroupException;
import net.jxta.id.IDFactory;
import net.jxta.impl.membership.pse.StringAuthenticator;
import net.jxta.membership.InteractiveAuthenticator;
import net.jxta.membership.MembershipService;
import net.jxta.peergroup.NetPeerGroupFactory;
import net.jxta.peergroup.PeerGroup;
import net.jxta.peergroup.PeerGroupID;
import net.jxta.platform.NetworkConfigurator;
import net.jxta.rendezvous.RendezVousService;
import net.jxta.rendezvous.RendezvousEvent;
import net.jxta.rendezvous.RendezvousListener;

import org.apache.log4j.*;

/**
 * A simple and re-usable exmaple of starting and stopping a JXTA platform
 * 
 * @author Mohamed Abdelaziz (hamada)
 * @created December 17, 2005
 */

public class NetworkManager implements RendezvousListener {

	private PeerGroup netPeerGroup = null;

	private boolean started = false;

	private boolean stopped = false;

	private RendezVousService rendezvous;

	private final static String connectLock = new String("connectLock");

	private String instanceName = "NA";

	private final static String RDV_EVENT_TYPES[] = { "RDVCONNECT", "RDVRECONNECT", "CLIENTCONNECT", "CLIENTRECONNECT",
			"RDVDISCONNECT", "RDVFAILED", "CLIENTDISCONNECT", "CLIENTFAILED", "BECAMERDV", "BECAMEEDGE" };

	/**
	 * A simple and re-usable exmaple of starting and stopping a JXTA platform
	 * 
	 * @param instanceName
	 *            Node name
	 * @param home
	 *            Cache storage home directory
	 */
	public NetworkManager(String instanceName) {
		this.instanceName = instanceName;
	}

	/**
	 * Creates and starts the JXTA NetPeerGroup using a platform configuration
	 * template. This class also registers a listener for rendezvous events
	 * 
	 * @param principal
	 *            principal used the generate the self signed peer root cert
	 * @param password
	 *            the root cert password
	 * @throws IOException
	 */
	public synchronized void start(String principal, String password) {
		if (started) {
			return;
		}
		try {
			NetworkConfigurator config = new NetworkConfigurator();
			config.setPeerID(IDFactory.newPeerID(PeerGroupID.defaultNetPeerGroupID));
			config.setName(instanceName);
			config.setDescription("Created by Network Manager");
			config.setMode(NetworkConfigurator.EDGE_NODE);
			config.setPrincipal(principal);
			config.setPassword(password);
			config.setUseMulticast(true);
			
			try {
				config.addRdvSeedingURI(new URI("http://rdv.jxtahosts.net/cgi-bin/rendezvous.cgi?2"));
				config.addRelaySeedingURI(new URI("http://rdv.jxtahosts.net/cgi-bin/relays.cgi?2"));
			} catch (java.net.URISyntaxException use) {
				use.printStackTrace();
			}

			// create, and Start the default jxta NetPeerGroup
			File f;
			try {
				f = File.createTempFile("testJXTA", "", null);

				f.delete();
				File tmpDir = f.getAbsoluteFile();

				NetPeerGroupFactory factory = new NetPeerGroupFactory(config.getPlatformConfig(), tmpDir.toURI());
				netPeerGroup = factory.getInterface();
				System.out.println("Node PeerID :" + netPeerGroup.getPeerID().getUniqueValue().toString());
				rendezvous = netPeerGroup.getRendezVousService();
				rendezvous.addListener(this);
				started = true;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (PeerGroupException e) {
			// could not instantiate the group, print the stack and exit
			System.out.println("fatal error : group creation failure");
			e.printStackTrace();
			System.exit(1);
		}
	}

	/**
	 * Establishes group credential. This is a required step when planning to to
	 * utilize TLS messegers or secure pipes
	 * 
	 * @param group
	 *            peer group to establish credentials in
	 * @param principal
	 *            the principal
	 * @param password
	 *            pass word
	 */
	public static void login(PeerGroup group, String principal, String password) {
		try {
			StringAuthenticator auth = null;
			MembershipService membership = group.getMembershipService();
			Credential cred = membership.getDefaultCredential();
			if (cred == null) {
				AuthenticationCredential authCred = new AuthenticationCredential(group, "StringAuthentication", null);
				try {
					auth = (StringAuthenticator) membership.apply(authCred);
				} catch (Exception failed) {
					;
				}

				if (auth != null) {
					auth.setAuth1_KeyStorePassword(password.toCharArray());
					auth.setAuth2Identity(group.getPeerID());
					auth.setAuth3_IdentityPassword(principal.toCharArray());
					if (auth.isReadyForJoin()) {
						membership.join(auth);
					}
				}
			}

			cred = membership.getDefaultCredential();
			if (null == cred) {
				AuthenticationCredential authCred = new AuthenticationCredential(
						group,
						"InteractiveAuthentication",
						null);
				InteractiveAuthenticator iAuth = (InteractiveAuthenticator) membership.apply(authCred);
				if (iAuth.interact() && iAuth.isReadyForJoin()) {
					membership.join(iAuth);
				}
			}
		} catch (Throwable e) {
			// make sure output buffering doesn't wreck console display.
			System.err.println("Uncaught Throwable caught by 'main':");
			e.printStackTrace();
			System.exit(1);
		} finally {
			System.err.flush();
			System.out.flush();
		}
	}

	/**
	 * Stops and unrefrences the NetPeerGroup
	 */
	public synchronized void stop() {
		if (stopped && !started) {
			return;
		}
		rendezvous.removeListener(this);
		netPeerGroup.stopApp();
		netPeerGroup.unref();
		netPeerGroup = null;
		stopped = true;
	}

	/**
	 * Gets the netPeerGroup object
	 * 
	 * @return The netPeerGroup value
	 */
	public PeerGroup getNetPeerGroup() {
		return netPeerGroup;
	}

	/**
	 * Blocks if not connected to a rendezvous, or until a connection to
	 * rendezvous node occurs
	 * 
	 * @param timeout
	 *            timeout in milliseconds
	 */
	public void waitForRendezvousConncection(long timeout) {
		if (!rendezvous.isConnectedToRendezVous() || !rendezvous.isRendezVous()) {
			System.out.println("Waiting for Rendezvous Connection");
			try {
				if (!rendezvous.isConnectedToRendezVous()) {
					synchronized (connectLock) {
						connectLock.wait(timeout);
					}
				}
				System.out.println("Connected to Rendezvous");
			} catch (InterruptedException e) {
			}
		}
	}

	/**
	 * rendezvousEvent the rendezvous event
	 * 
	 * @param event
	 *            rendezvousEvent
	 */
	public void rendezvousEvent(RendezvousEvent event) {
		System.out.printf("[%tT]: %s: %s%n", Calendar.getInstance(), RDV_EVENT_TYPES[event.getType()], event.getPeerID());
	}

	/**
	 * Main method
	 * 
	 * @param args
	 *            none defined
	 */
	public static void main(String args[]) {
		Logger.getRootLogger().removeAllAppenders();
		Logger.getRootLogger().addAppender(new ConsoleAppender(new PatternLayout("%-5p [%d{HH:mm:ss}] - %m%n"), "System.err"));
		Logger.getRootLogger().setLevel(Level.ERROR);
		Logger.getLogger("net.jxta.impl.rendezvous.rpv").setLevel(Level.DEBUG);
		NetworkManager manager = new NetworkManager("rdv-failed-test " + args[0]);
		System.out.println("Starting NetworkManager ....");
		manager.start("principal", "password");
	}
}
