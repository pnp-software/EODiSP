package org.eodisp.remote.local;

import java.rmi.RemoteException;

/**
 * @author ibirrer
 * @version $Id:$
 *
 */
public class HiImpl implements Hi {

	/** 
	 * {@inheritDoc}
	 */
	public void hi(Hello hello) {
		System.out.println("Reply: " + hello);
	}

}
