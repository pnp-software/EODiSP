package org.eodisp.remote.jxta;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;

import junit.framework.TestCase;

import net.jxta.impl.endpoint.IPUtils;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.types.CommandlineJava;
import org.apache.tools.ant.types.Path;
import org.apache.tools.ant.types.Commandline.Argument;
import org.eodisp.util.ProgramExecution;

public class PlatformConfigTest extends TestCase {
	public void testRendezvous() throws Exception {
		CommandlineJava commandlineJava = new CommandlineJava();
		commandlineJava.setClassname( "" );
		commandlineJava.createClasspath(null);
		commandlineJava.getClasspath().add(Path.systemClasspath);
		
		Argument arg0 = commandlineJava.createArgument();
		arg0.setValue("RDV_1");
		
		Argument arg1 = commandlineJava.createArgument();
		arg1.setValue("8001");
		
		InetAddress addr = (InetAddress) IPUtils.getAllLocalAddresses().next();
		String rdvAddress = "tcp://" + addr.getHostAddress() + ":" + 8001;
		Argument arg2 = commandlineJava.createArgument();
		arg2.setValue(rdvAddress);
		
		Argument arg3 = commandlineJava.createArgument();
		arg3.setValue("RDV");
		
		Thread t = new Thread( new Runnable() {
			public void run() {
				try {
					CommandlineJava commandlineJava = new CommandlineJava();
					commandlineJava.setClassname( "" );
					commandlineJava.createClasspath(null);
					commandlineJava.getClasspath().add(Path.systemClasspath);
					
					Argument arg0 = commandlineJava.createArgument();
					arg0.setValue("EDGE_1");
					
					Argument arg1 = commandlineJava.createArgument();
					arg1.setValue("0");
					
					InetAddress addr = (InetAddress) IPUtils.getAllLocalAddresses().next();
					String rdvAddress = "tcp://" + addr.getHostAddress() + ":" + 8001;
					Argument arg2 = commandlineJava.createArgument();
					arg2.setValue(rdvAddress);
					
					Argument arg3 = commandlineJava.createArgument();
					arg3.setValue("EDGE");
					ProgramExecution.executeJava(commandlineJava, null, new File("/"));
				} catch (BuildException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			
		} );
		t.start();		
		ProgramExecution.executeJava(commandlineJava, null, new File("/"));
	}
}