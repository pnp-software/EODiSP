package org.eodisp.remote.jxta;

import java.net.URI;
import java.rmi.RemoteException;

import net.jini.jeri.Endpoint;
import net.jini.jeri.ServerEndpoint;
import net.jini.jeri.ssl.SslEndpoint;
import net.jini.jeri.ssl.SslServerEndpoint;
import net.jini.jeri.tcp.TcpEndpoint;
import net.jini.jeri.tcp.TcpServerEndpoint;
import net.jxta.id.IDFactory;
import net.jxta.impl.protocol.PlatformConfig;
import net.jxta.impl.protocol.RdvConfigAdv.RendezVousConfiguration;
import net.jxta.peer.PeerID;
import net.jxta.peergroup.PeerGroupID;

import org.eodisp.remote.config.RemoteConfiguration;
import org.eodisp.remote.jeri.internal.nomux.TcpEndpointNoMux;
import org.eodisp.remote.jeri.internal.nomux.TcpServerEndpointNoMux;
import org.eodisp.remote.jeri.jxta.JxtaEndpoint;
import org.eodisp.remote.jeri.jxta.JxtaNetwork;
import org.eodisp.remote.jeri.jxta.JxtaServerEndpoint;
import org.eodisp.remote.jeri.tcp.fastmux.TcpEndpointFastMux;
import org.eodisp.remote.jeri.tcp.fastmux.TcpServerEndpointFastMux;
import org.eodisp.remote.util.*;

public class JeriClient {

	private static final URI DEFAULT_EODISP_TCP_RENDEZVOUS = URI.create("tcp://rdv.eodisp.org:14301");

	private static final URI DEFAULT_EODISP_HTTP_RENDEZVOUS = URI.create("http://rdv.eodisp.org:80");

	private static final URI DEFAULT_EODISP_TCP_RELAY = URI.create("tcp://rdv.eodisp.org:14301");

	private static final URI DEFAULT_EODISP_HTTP_RELAY = URI.create("http://rdv.eodisp.org:80");

	public static void main(String[] args) {
		if (args[0].equals("jxta")) {
			jxtaSockets(Integer.MAX_VALUE, 1024 * 1024 * 3, 1);
		} else if (args[0].equals("tcp")) {
			normalSockets(args[1], Integer.parseInt(args[2]), 1, 1024 * 1024 * 1, 1);
		} else if (args[0].equals("ssl")) {
			sslSockets(args[1], Integer.parseInt(args[2]), 26, 1, 2);
		} else if (args[0].equals("tcpnomux")) {
			tcpNoMuxSockets(args[1], Integer.parseInt(args[2]), 26, 1, 2);
		} else if (args[0].equals("tcpfastmux")) {
			tcpFastMux(args[1], Integer.parseInt(args[2]), 1, 1024 * 1024 * 50, 1);
		}
	}

	public static void sslSockets(String host, int port, int times, int nrOfBytes, int scale) {
		Endpoint endpoint = SslEndpoint.getInstance(host, port);
		ServerEndpoint serverEndpoint = SslServerEndpoint.getInstance(0);
		try {
			JeriUtil.startClient(endpoint, serverEndpoint, times, nrOfBytes, scale);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	public static void tcpFastMux(String host, int port, int times, int nrOfBytes, int scale) {
		Endpoint endpoint = TcpEndpointFastMux.getInstance(host, port);
		ServerEndpoint serverEndpoint = TcpServerEndpointFastMux.getInstance(0);
		try {
			JeriUtil.startClient(endpoint, serverEndpoint, times, nrOfBytes, scale);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	public static void tcpNoMuxSockets(String host, int port, int times, int nrOfBytes, int scale) {
		Endpoint endpoint = TcpEndpointNoMux.getInstance(host, port);
		ServerEndpoint serverEndpoint = TcpServerEndpointNoMux.getInstance(0);
		try {
			JeriUtil.startClient(endpoint, serverEndpoint, times, nrOfBytes, scale);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	public static void normalSockets(String host, int port, int times, int nrOfBytes, int scale) {
		Endpoint endpoint = TcpEndpoint.getInstance(host, port);
		ServerEndpoint serverEndpoint = TcpServerEndpoint.getInstance(0);
		try {
			JeriUtil.startClient(endpoint, serverEndpoint, times, nrOfBytes, scale);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	public static void jxtaSockets(int times, int nrOfBytes, int scale) {
		try {
			NetworkConfigurator networkConfigurator = NetworkConfigurator.newNetworkConfiguratorEdge();
			networkConfigurator.setTcpPort(0);
			networkConfigurator.setTcpStartPort(-1);
			networkConfigurator.setTcpEndPort(-1);
			networkConfigurator.setUseMulticast(false);
			networkConfigurator.setName("TestJxtaSocketClient " + JXTAUtil.getComputerName());
			networkConfigurator.setDescription("TestJxtaSocketClient");
			networkConfigurator.addSeedRendezvous(DEFAULT_EODISP_TCP_RENDEZVOUS);
			networkConfigurator.addSeedRendezvous(DEFAULT_EODISP_HTTP_RENDEZVOUS);
			networkConfigurator.addSeedRelay(DEFAULT_EODISP_TCP_RELAY);
			networkConfigurator.addSeedRelay(DEFAULT_EODISP_HTTP_RELAY);

			JxtaNetworkManager networkManager = new JxtaNetworkManager(
					networkConfigurator.getPlatformConfig(),
					null,
					URI.create(RemoteConfiguration.DEFAULT_JXTA_NPG_URI));
			networkManager.start();

			PeerID serverPeerID = (PeerID) IDFactory.fromURI(new URI(JeriServer.SERVER_PEER_ID));

			JxtaNetwork.registerJeriPeerGroup(networkManager.getNetPeerGroup());

			Endpoint endpoint = JxtaEndpoint.getInstance(serverPeerID);

			ServerEndpoint serverEndpoint = JxtaServerEndpoint.getInstance();

			JeriUtil.startClient(endpoint, serverEndpoint, times, nrOfBytes, scale);

		} catch (Exception e) {
			e.printStackTrace();
		}
		System.exit(0);
	}
}
