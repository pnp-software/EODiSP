package org.eodisp.remote.jxta;

import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.server.ExportException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.Principal;
import java.util.Arrays;

import javax.rmi.CORBA.Tie;

import com.sun.jini.config.KeyStores;

import net.jini.constraint.BasicMethodConstraints;
import net.jini.core.constraint.*;
import net.jini.export.Exporter;
import net.jini.id.Uuid;
import net.jini.id.UuidFactory;
import net.jini.jeri.*;
import net.jini.security.AccessPermission;
import net.jxta.document.AdvertisementFactory;
import net.jxta.impl.id.binaryID.DigestTool;
import net.jxta.impl.id.binaryID.PipeBinaryID;
import net.jxta.peergroup.PeerGroup;
import net.jxta.pipe.PipeService;
import net.jxta.protocol.PipeAdvertisement;

public class JeriUtil {

	private static final String HELLO_ID = "c9ee653d-4551-4d80-9659-9ca20e1ac340";

	private static final Uuid helloUuid = UuidFactory.create(HELLO_ID);

	private static HelloImpl helloImpl;

	private static Callback callback = new CallbackImpl();

	public interface Hello extends Remote {
		void hello(String helloString) throws RemoteException;

		public void sendData(byte[] data) throws RemoteException;

		public void doCallback(Callback callback) throws RemoteException;
	}

	public interface Callback extends Remote {
		public void callback() throws RemoteException;
	}

	public static class HelloImpl implements Hello, Serializable {

		private static final long serialVersionUID = 1L;

		private int times = 0;

		private long now = System.currentTimeMillis();

		public synchronized void hello(String helloString) {
			System.out.println(helloString + times++);
		}

		public void sendData(byte[] arg0) {
			System.out.println("Wait for 30 minutes");
			try {
				Thread.sleep(60000 * 30);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.printf("Received %,d bytes%n", arg0.length);
//			System.out.printf("Received %,d bytes in %d ms%n", arg0.length, System.currentTimeMillis() - now);
//			now = System.currentTimeMillis();
		}

		public void doCallback(Callback callback) throws RemoteException {
			System.out.println("doCallback");
			callback.callback();
		}
	}

	public static class CallbackImpl implements Callback, Serializable {
		private static final long serialVersionUID = 1L;

		private int times = 0;

		public synchronized void callback() {
			System.out.println("Callback " + times++);
		}
	}

	public static void startServer(ServerEndpoint serverEndpoint) throws ExportException {

		// try {
		// System.out.println(KeyStore.getDefaultType());
		// System.out.println(KeyStore.getInstance(KeyStore.getDefaultType()).getCertificate("ibirrer"));
		// } catch (KeyStoreException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }

		Exporter exporter = new BasicJeriExporter(serverEndpoint, new BasicILFactory(
		/* Require integrity for all methods */
		// new BasicMethodConstraints(
				// new InvocationConstraints(
				// new InvocationConstraint[] {
				// ClientAuthentication.YES,
				// new ClientMinPrincipal((Principal)null)
				// },
				// (InvocationConstraint[]) null)),
				// /* No Permission */
				// null
				),
				true,
				true,
				helloUuid);
		// helloImpl must be a field otherwise it will be garbage collected!
		helloImpl = new HelloImpl();
		exporter.export(helloImpl);
		System.out.println("Successfully exported 'Hello' on" + serverEndpoint);
	}

	public static void startClient(Endpoint endpoint, ServerEndpoint serverEndpoint, int times, int initialNrOfBytes,
			int scale) throws RemoteException {
		System.out.println("Create object endpoint");
		BasicObjectEndpoint objectEndpoint = new BasicObjectEndpoint(endpoint, helloUuid, false);
		System.out.println("object endpoint created");

		InvocationConstraints invocationConstraints = new InvocationConstraints(new ConnectionRelativeTime(10000), null);
		MethodConstraints methodConstraints = new BasicMethodConstraints(invocationConstraints);

//		System.out.println(invocationConstraints);
//		System.out.println(methodConstraints);

		BasicInvocationHandler basicInvocationHandler = new BasicInvocationHandler(objectEndpoint, null);
		InvocationHandler invocationHandler = new BasicInvocationHandler( basicInvocationHandler, methodConstraints );
//		InvocationHandler invocationHandler = new BasicInvocationHandler(objectEndpoint, null);

		// Exporter exporter = new BasicJeriExporter(serverEndpoint, new
		// BasicILFactory());

		// final Callback callbackProxy = (Callback) exporter.export(callback);

		Class[] interfaces = { Hello.class, RemoteMethodControl.class };
		Hello helloProxy = (Hello) Proxy.newProxyInstance(
				Thread.currentThread().getContextClassLoader(),
				interfaces,
				invocationHandler);

		// StringBuilder stringBuilder = new StringBuilder();
		int nrOfBytes = initialNrOfBytes;
		byte[] data = getDataPacket(nrOfBytes);
		for (int i = 0; i < times; i++) {
			System.out.printf("%d: Writing %,d bytes: %n", i, nrOfBytes);
			long totalTime = 0;
			long totalBytes = 0;
			for (int j = 0; j < 10; j++) {
				long now = System.currentTimeMillis();
//				if( i == 0 && j == 1 ) {
//					long timeout = 10;
//					System.out.printf("Set timeout to %dms%n", timeout);
//					RemoteMethodControl remoteMethodControl = (RemoteMethodControl) helloProxy;
//					InvocationConstraints ic = new InvocationConstraints(new ConnectionRelativeTime(timeout), null);
//					MethodConstraints mc = new BasicMethodConstraints(ic);
//					Hello helloProxyTimeout = (Hello) remoteMethodControl.setConstraints(mc);
//					helloProxy = helloProxyTimeout;
//					System.out.println(helloProxy);
//
//				}
				helloProxy.sendData(data);
				long time = System.currentTimeMillis() - now;
				totalBytes = totalBytes + data.length;
				totalTime = totalTime + time;
				System.out.printf("%d: %,d bytes: %dms%n", i, data.length, time);

			}
			System.out.printf("Total: %,d bytes: %dms%n", totalBytes, totalTime);
			nrOfBytes = nrOfBytes * scale;
			// long now = System.currentTimeMillis();
			// String message = "Gruss von " + endpoint;
			// helloProxy.hello(message);
			// System.out.printf("%d: %,d bytes: %dms%n", i,
			// message.getBytes().length, System.currentTimeMillis() - now);
			// Thread t = new Thread() {
			// @Override
			// public void run() {
			// try {
			//                        
			// } catch (Exception e) {
			// // TODO Auto-generated catch block
			// e.printStackTrace();
			// }
			// }
			// };
			// long now = System.currentTimeMillis();
			// helloProxy.doCallback(callbackProxy);
			// stringBuilder.append("Sali");
			// helloProxy.hello(stringBuilder.toString());
			// System.out.printf("%d: %dms%n", i, System.currentTimeMillis() -
			// now);

			// t.start();
		}
		// try {
		// Thread.sleep(1000 * 1000);
		// } catch (InterruptedException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
	}

	public static byte[] getDataPacket(int nrOfBytes) {
		byte[] data = new byte[nrOfBytes];
		Arrays.fill(data, (byte) 3);
		data[0] = 1;
		data[nrOfBytes - 1] = 1;
		return data;
	}

	/**
	 * Returns the pipe advertisement for the server component.
	 * 
	 * @param ertiPeerGroup
	 *            the peer group the created pipe belongs to.
	 * @return the pipe advertisements for the server component of the network.
	 */
	public static PipeAdvertisement getPipeAdvertisement(PeerGroup ertiPeerGroup) {
		// Create pipe id from clear test string
		DigestTool digestTool = new DigestTool();
		PipeBinaryID pipeId = digestTool.createPipeID(
				ertiPeerGroup.getPeerGroupID(),
				"org.edoisp.erti.server.ERTIPipeAdvertisement",
				null);

		// Create pipe advertisement
		PipeAdvertisement pipeAd = (PipeAdvertisement) AdvertisementFactory.newAdvertisement(PipeAdvertisement
				.getAdvertisementType());

		pipeAd.setPipeID(pipeId);
		pipeAd.setType(PipeService.UnicastType);
		pipeAd.setName("org.eodisp.erti.net.jxta.ClientConnectionPipe");
		pipeAd.setDescription("Pipe that a ");

		try {
			ertiPeerGroup.getDiscoveryService().flushAdvertisement(pipeAd);
			ertiPeerGroup.getDiscoveryService().publish(pipeAd);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pipeAd;
	}
}
