/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.remote.util;

import java.io.IOException;
import java.io.InputStream;

/**
 * @author ibirrer
 * @version $Id:$
 *
 */
public class LoggedInputStream extends InputStream {
	
	private InputStream in;
	
	public LoggedInputStream( InputStream in ) {
		this.in = in;
	}



	public int available() throws IOException {
		return in.available();
	}



	public void close() throws IOException {
		in.close();
	}



	public boolean equals(Object obj) {
		return in.equals(obj);
	}



	public int hashCode() {
		return in.hashCode();
	}



	public void mark(int readlimit) {
		in.mark(readlimit);
	}



	public boolean markSupported() {
		return in.markSupported();
	}



	public int read() throws IOException {
		return in.read();
	}



	public int read(byte[] b, int off, int len) throws IOException {
		System.out.printf("InputStreamLogger: in.read(%d, %d, %d)", b.length, off, len);
		return in.read(b, off, len);
	}



	public int read(byte[] b) throws IOException {
		return in.read(b);
	}



	public void reset() throws IOException {
		in.reset();
	}

	public long skip(long n) throws IOException {
		return in.skip(n);
	}

	public String toString() {
		return in.toString();
	}
}
