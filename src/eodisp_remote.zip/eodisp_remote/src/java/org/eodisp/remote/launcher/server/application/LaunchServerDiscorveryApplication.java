/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.remote.launcher.server.application;

import java.io.File;
import java.net.URI;
import java.util.EnumSet;

import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.remote.config.RemoteConfiguration.TransportType;
import org.eodisp.remote.util.JXTAUtil;
import org.eodisp.remote.util.NetworkConfigurator;
import org.eodisp.util.RootApp;

/**
 * A simple rendezvous server for the EODiSP simulation platform. The rendezvous
 * server listens per default on port 14301.
 * 
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class LaunchServerDiscorveryApplication extends RootApp {
	public static final String APP_NAME = "EODiSP LaunchServerDiscovery";

	public static final File DEFAULT_WORKING_DIR = new File(
			new File(System.getProperty("user.home"), ".eodisp"),
			"launch-server-discovery");

	private RemoteAppModule remoteAppModule;

	public LaunchServerDiscorveryApplication() {
		super(APP_NAME, "Discovers Launch servers", DEFAULT_WORKING_DIR, LaunchServerApplication.class);
		remoteAppModule = new RemoteAppModule(0);
		registerAppModule(remoteAppModule);

		registerAppModule(new LaunchServerDiscoveryAppModule());
	}

	public RemoteAppModule getRemoteAppModule() {
		return remoteAppModule;
	}

	public static void main(String[] args) {
		LaunchServerDiscorveryApplication app = new LaunchServerDiscorveryApplication();
		app.execute(args);
	}
}
