package org.eodisp.remote.launcher;

import java.util.EnumSet;

import org.eodisp.remote.config.RemoteConfiguration.TransportType;

public abstract class RootAppProcessFactoryRemoteImpl implements RootAppProcessFactoryRemote {

	private EnumSet<TransportType> transports = EnumSet.of(TransportType.JXTA);

	public void setTransports(EnumSet<TransportType> transports) {
		this.transports = transports;
	}
	
	public EnumSet<TransportType> getTransports() {
		return transports;
	}
}