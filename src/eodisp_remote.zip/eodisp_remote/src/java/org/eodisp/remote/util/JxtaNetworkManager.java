package org.eodisp.remote.util;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import net.jxta.document.MimeMediaType;
import net.jxta.document.StructuredDocumentFactory;
import net.jxta.document.XMLElement;
import net.jxta.exception.PeerGroupException;
import net.jxta.id.IDFactory;
import net.jxta.peergroup.NetPeerGroupFactory;
import net.jxta.peergroup.PeerGroup;
import net.jxta.peergroup.PeerGroupID;
import net.jxta.protocol.ConfigParams;
import net.jxta.rendezvous.RendezVousService;
import net.jxta.rendezvous.RendezvousEvent;
import net.jxta.rendezvous.RendezvousListener;

import org.apache.log4j.Logger;
import org.eodisp.util.FileUtil;

/**
 * Manages the JXTA Network infrastructure lifetime.
 * 
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class JxtaNetworkManager {
	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	static Logger logger = Logger.getLogger(JxtaNetworkManager.class);

	private PeerGroup netPeerGroup = null;

	private URI netPeerGroupUri;

	private boolean started = false;

	private boolean stopped = false;

	private ConfigParams platformConfig;

	private URI storeHome;

	private RendezVousService rendezVousService;

	private RendezvousListener rendezvousListener;

	public JxtaNetworkManager(ConfigParams platformConfig,
			URI storeHome,
			URI netPeerGroupUri) {
		this.platformConfig = platformConfig;
		if (storeHome == null) {
			try {
				storeHome = FileUtil.createTempDir("jxtaStoreHome_", "", FileUtil.getTempDir()).toURI();
			} catch (IOException e) {
				logger.warn(String.format("Could not create temporary store home", e));
				File tmpDir = FileUtil.getTempDir();
				storeHome = tmpDir.toURI();
			}
		}
		this.storeHome = storeHome;
		this.netPeerGroupUri = netPeerGroupUri;
	}

	/**
	 * Creates and starts the JXTA NetPeerGroup using a platform configuration
	 * template. This class also registers a listener for rendezvous events
	 * 
	 * @throws PeerGroupException
	 * 
	 */
	public synchronized void start() throws PeerGroupException {
		if (started) {
			logger.warn("Cannot start JXTA Network twice");
			return;
		}

		PeerGroupID netPeerGroupID = null;
		try {
			netPeerGroupID = (PeerGroupID) IDFactory.fromURI(netPeerGroupUri);
		} catch (URISyntaxException e) {
			// ignore
			logger.fatal("This should never happen. Hardcoded URI must never be wrong...", e);
		}

		XMLElement netPeerGroupDescriptionElement = (XMLElement) StructuredDocumentFactory.newStructuredDocument(
				MimeMediaType.XMLUTF8,
				"desc",
				"EODiSP Net-Peer-Group");

		NetPeerGroupFactory netPeerGroupFactory = new NetPeerGroupFactory(
				platformConfig,
				storeHome,
				netPeerGroupID,
				"EODiSP Net-Peer-Group",
				netPeerGroupDescriptionElement);
		netPeerGroup = netPeerGroupFactory.getInterface();

		rendezVousService = netPeerGroup.getRendezVousService();
		rendezvousListener = new RendezvousListener() {
			public void rendezvousEvent(RendezvousEvent event) {
				logger.debug(String.format("%s: [%s]", RDV_EVENT_TYPES[event.getType()], event.getPeerID()));
			}
		};
		rendezVousService.addListener(rendezvousListener);
		logger.debug(String.format("JXTA network has been started. Connected with rendezvous: %s", rendezVousService
				.isConnectedToRendezVous()));
		started = true;
	}

	private final static String RDV_EVENT_TYPES[] = { "RDVCONNECT", "RDVRECONNECT", "CLIENTCONNECT", "CLIENTRECONNECT",
			"RDVDISCONNECT", "RDVFAILED", "CLIENTDISCONNECT", "CLIENTFAILED", "BECAMERDV", "BECAMEEDGE" };

	public boolean isStarted() {
		return started;
	}

	public boolean isConnected() {
		return rendezVousService.isConnectedToRendezVous();
	}

	public synchronized void waitForRendeyvousConnection(long timeout) {
		JXTAUtil.connectToRendezvous(netPeerGroup, timeout);
	}

	/**
	 * Stops and dereference the NetPeerGroup
	 */
	public synchronized void stop() {
		if (stopped && !started) {
			return;
		}
		rendezVousService.removeListener(rendezvousListener);
		netPeerGroup.stopApp();
		netPeerGroup.unref();
		netPeerGroup = null;
		stopped = true;
	}

	/**
	 * Gets the netPeerGroup object
	 * 
	 * @return The netPeerGroup value
	 */
	public PeerGroup getNetPeerGroup() {
		return netPeerGroup;
	}
}