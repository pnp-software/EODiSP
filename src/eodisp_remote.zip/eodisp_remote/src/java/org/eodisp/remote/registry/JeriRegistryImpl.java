/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.remote.registry;

import java.net.URI;
import java.rmi.*;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.remote.config.RemoteConfiguration.TransportType;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.RootApp;

/**
 * A simple implementation of the RMI registry interface for Jeri
 * 
 * @author ibirrer
 * @version $Id:$
 */
public class JeriRegistryImpl implements JeriRegistry {

	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	static Logger logger = Logger.getLogger(JeriRegistryImpl.class);

	private Map<String, Map<TransportType, Remote>> registeredObjects = new HashMap<String, Map<TransportType, Remote>>();

	private final TransportType favoriteTransport;

	private final EnumSet<TransportType> availableTransports;

	public JeriRegistryImpl(EnumSet<TransportType> availableTransports, TransportType favoriteTransport) {
		this.availableTransports = availableTransports;
		this.favoriteTransport = favoriteTransport;
		if (!availableTransports.contains(favoriteTransport)) {
			throw new IllegalArgumentException("Favorite transport must be in available transports");
		}
	}

	public synchronized Remote lookup(String name) throws RemoteException, NotBoundException, AccessException {
		return lookup(name, favoriteTransport);
	}

	/**
	 * {@inheritDoc}
	 */
	public synchronized Remote lookup(String name, TransportType transportType) throws NotBoundException {
		Map<TransportType, Remote> instances = registeredObjects.get(name);
		if (instances == null) {
			throw new NotBoundException(String.format("No object bound with name '%s'", name));
		}

		Remote proxy = instances.get(transportType);

		if (proxy == null) {
			throw new NotBoundException(String.format(
					"Object bound under '%s' is not available in registry for transport '%s'",
					name,
					transportType));
		}
		return proxy;
	}

	public synchronized void bind(String name, Remote obj) throws RemoteException, AlreadyBoundException,
			AccessException {
		bind(name, obj, favoriteTransport);
	}

	/**
	 * {@inheritDoc}
	 */
	public synchronized void bind(String name, Remote obj, TransportType transportType) throws AlreadyBoundException {
		if (registeredObjects.containsKey(name)) {
			throw new AlreadyBoundException(String.format("An object with name '%s' is already bound", name));
		}

		Map<TransportType, Remote> instances = new HashMap<TransportType, Remote>();
		if (instances.containsKey(transportType)) {
			throw new AlreadyBoundException(String.format(
					"An object with name '%s' is already bound for transport '%s'",
					name,
					transportType));
		}

		instances.put(transportType, obj);
	}

	/**
	 * {@inheritDoc}
	 */
	public synchronized void rebind(String name, Map<TransportType, Remote> proxies) {
		for (Entry<TransportType, Remote> entry : proxies.entrySet()) {
			TransportType transportType = entry.getKey();
			Remote remote = entry.getValue();
			rebind(name, remote, transportType);
		}
	}

	public synchronized void unbind(String name) throws RemoteException, NotBoundException, AccessException {
		if (!registeredObjects.containsKey(name)) {
			throw new NotBoundException(String.format("No object bound with name '%s'", name));
		}
		registeredObjects.remove(name);
	}

	/**
	 * {@inheritDoc}
	 */
	public synchronized void rebind(String name, Remote obj, TransportType transportType) {
		Map<TransportType, Remote> instances = registeredObjects.get(name);
		if (instances == null) {
			instances = new HashMap<TransportType, Remote>();
			registeredObjects.put(name, instances);
		}
		instances.put(transportType, obj);
	}

	public void rebind(String name, Remote obj) throws RemoteException, AccessException {
		rebind(name, obj, favoriteTransport);
	}

	public synchronized String[] list() throws RemoteException, AccessException {
		return registeredObjects.keySet().toArray(new String[0]);
	}

	public URI getUri(TransportType transportType) throws RemoteException {
		RemoteAppModule remoteAppModule = (RemoteAppModule) AppRegistry.getRootApp().getAppModule(RemoteAppModule.ID);
		return remoteAppModule.getLocalUri(transportType);
	}
}
