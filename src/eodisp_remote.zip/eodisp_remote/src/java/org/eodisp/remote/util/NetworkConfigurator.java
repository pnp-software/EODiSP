/*
 *  Copyright (c) 2006 Sun Microsystems, Inc.  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  2. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  3. the end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Sun Microsystems, Inc. for Project JXTA."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  4. the names "Sun", "Sun Microsystems, Inc.", "JXTA" and "Project JXTA"
 *  must not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact Project JXTA at http://www.jxta.org.
 *
 *  5. Products derived from this software may not be called "JXTA",
 *  nor may "JXTA" appear in their name, without prior written
 *  permission of Sun.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL SUN MICROSYSTEMS OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 *  ====================================================================
 *
 *  This software consists of voluntary contributions made by many
 *  individuals on behalf of Project JXTA.  For more
 *  information on Project JXTA, please see
 *  <http://www.jxta.org/.
 *
 *  This license is based on the BSD license adopted by the Apache Foundation.
 *
 *  $Id: NetworkConfigurator.java,v 1.1 2006/06/12 15:08:06 hamada Exp $
 */
package org.eodisp.remote.util;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.util.*;

import javax.security.cert.CertificateException;

import net.jxta.document.*;
import net.jxta.id.ID;
import net.jxta.id.IDFactory;
import net.jxta.impl.membership.pse.PSEUtils;
import net.jxta.impl.membership.pse.PSEUtils.IssuerInfo;
import net.jxta.impl.protocol.*;
import net.jxta.impl.protocol.RdvConfigAdv.RendezVousConfiguration;
import net.jxta.peer.PeerID;
import net.jxta.peergroup.*;
import net.jxta.protocol.ConfigParams;
import net.jxta.protocol.TransportAdvertisement;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

/**
 * NetworkConfigurator provides a simple programmatic interface to the JXTA
 * configuration (i.e. the PlatformConfig). It provides factory methods to
 * create a NetworkConfiguration instance from an existing PlatfromConfig or to
 * create a typical EDGE, RENDEZVOUS or AD_HOC peer configuration from scratch.
 * (edge, rendezvous, ad hoc etc.).
 * 
 * <p>
 * Read the following for an overview of typical types of peers:
 * 
 * <p>
 * <b>1. Edge Peer</b><br>
 * 
 * A peer which may or may not be behind a firewall or NAT (i.e. Directly
 * addressable or not). It is recommended that this class of peer should always
 * be configured with TCP/IP enabled (both incoming/outgoing, multicast on), and
 * HTTP enabled outgoing only, it should also use a relay, and a rendezvous. It
 * is important to note that the JXTAplatform automatically determines whether
 * directs routes exists between peers, and will prefer such routes over relayed
 * ones (hence the recommended configuration)
 * 
 * <p>
 * <b>2. Rendezvous/Relay Peer</b><br>
 * 
 * This class of peers is expected to provide infrastructure services and
 * typically is directly reachable on the Internet. It is recommended that this
 * class of peer should always be configured with TCP/IP enabled (both
 * incoming/outgoing, multicast on), and HTTP enabled incoming only, act as a
 * relay, and rendezvous.
 * 
 * <p>
 * 
 * <b>3. Ad hoc peer</b><br>
 * 
 * FIXME:
 * 
 * <p>
 * <b>Important Note:</b> <br>
 * NetworkConfigurator makes use of classes from the
 * <code>net.jxta.impl.*</code> packages. Applications are very strongly
 * encouraged to avoid importing these classes as their interfaces may change
 * without notice in future JXTA releases. The NetworkConfigurator API abstracts
 * the configuration implementation details and will provide continuity and
 * stability i.e. the NetworkConfigurator API won't change and it will
 * automatically accommodate changes to service configuration.
 * 
 */
public class NetworkConfigurator {
	private static final String PROPERTY_NAME = "name";

	private static final String PROPERTY_DESCRIPTION = "description";

	private static final String PROPERTY_TCP_ENABLED = "tcpEnabled";

	private static final String PROPERTY_TCP_INCOMING = "tcpIncoming";

	private static final String PROPERTY_TCP_OUTGOING = "tcpOutgoing";

	private static final String PROPERTY_TCP_PORT = "tcpPort";

	private static final String PROPERTY_TCP_START_PORT = "tcpStartPort";

	private static final String PROPERTY_TCP_END_PORT = "tcpEndPort";

	private static final String PROPERTY_TCP_INTERFACE_ADDRESS = "tcpInterfaceAddress";

	private static final String PROPERTY_TCP_PUBLIC_ADDRESS = "tcpPublicAddress";

	private static final String PROPERTY_TCP_PUBLIC_ADDRESS_EXCLUSIVE = "tcpPublicAddressExclusive";

	private static final String PROPERTY_USE_MULTICAST = "useMulticast";

	private static final String PROPERTY_MULTICAST_ADDRESS = "multicastAddress";

	private static final String PROPERTY_MULTICAST_PORT = "multicastPort";

	private static final String PROPERTY_MULTICAST_SIZE = "multicastSize";

	private static final String PROPERTY_HTTP_ENABLED = "httpEnabled";

	private static final String PROPERTY_HTTP_INCOMING = "httpIncoming";

	private static final String PROPERTY_HTTP_OUTGOING = "httpOutgoing";

	private static final String PROPERTY_HTTP_PORT = "httpPort";

	private static final String PROPERTY_HTTP_PUBLIC_ADDRESS = "httpPublicAddress";

	private static final String PROPERTY_HTTP_PUBLIC_ADDRESS_EXCLUSIVE = "httpPublicAddressExclusive";

	private static final String PROPERTY_HTTP_INTERFACE_ADDRESS = "httpInterfaceAddress";

	private static final String PROPERTY_RELAY_ENABLED = "relayEnabled";

	private static final String PROPERTY_RELAY_SERVER = "relayServer";

	private static final String PROPERTY_RELAY_CLIENT = "relayClient";

	private static final String PROPERTY_RELAY_MAX_CLIENTS = "relayMaxClients";

	private static final String PROPERTY_USE_ONLY_RELAY_SEEDS = "useOnlyRelaySeeds";

	private static final String PROPERTY_RENDEZVOUS_ENABLED = "rendezvousEnabled";

	private static final String PROPERTY_RENDEZVOUS_MAX_CLIENTS = "rendezvousMaxClients";

	private static final String PROPERTY_USE_ONLY_RENDEZVOUS_SEEDS = "useOnlyRendezvousSeeds";

	// private static final String PROPERTY_RDV_SEEDING_URI = "rdvSeedingURI";

	private static final String PROPERTY_PRINCIPAL = "principal";

	private static final String PROPERTY_PASSWORD = "password";

	private static final String PROPERTY_PROXY_ENABLED = "proxyEnabled";

	// private static final String PROPERTY_HOME = "home";

	private PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this) {

		@Override
		public void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
			super.firePropertyChange(propertyName, oldValue, newValue);
			isDirty = true;
		}

		@Override
		public void firePropertyChange(String propertyName, int oldValue, int newValue) {
			super.firePropertyChange(propertyName, oldValue, newValue);
			isDirty = true;
		}

		@Override
		public void firePropertyChange(String propertyName, boolean oldValue, boolean newValue) {
			super.firePropertyChange(propertyName, oldValue, newValue);
			isDirty = true;
		}

		@Override
		public void firePropertyChange(PropertyChangeEvent evt) {
			super.firePropertyChange(evt);
			isDirty = true;
		}

	};

	private boolean isDirty = false;

	/**
	 * Relay client Mode
	 * 
	 * @deprecated use the <code>newXXX</code> static factory method and the
	 *             setXXX methods instead
	 */
	public final static int RELAY_OFF = 1 << 2;

	/**
	 * Relay client Mode
	 * 
	 * @deprecated use the <code>newXXX</code> static factory method and the
	 *             setXXX methods instead
	 */
	public final static int RELAY_CLIENT = 1 << 3;

	/**
	 * Relay client Mode
	 * 
	 * @deprecated use the <code>newXXX</code> static factory method and the
	 *             setXXX methods instead
	 */
	public final static int RELAY_SERVER = 1 << 4;

	/**
	 * Proxy Server Mode
	 * 
	 * @deprecated use the <code>newXXX</code> static factory method and the
	 *             setXXX methods instead
	 */
	public final static int PROXY_SERVER = 1 << 5;

	/**
	 * TCP transport client state
	 * 
	 * @deprecated use the <code>newXXX</code> static factory method and the
	 *             setXXX methods instead
	 */
	public final static int TCP_CLIENT = 1 << 6;

	/**
	 * TCP transport state
	 * 
	 * @deprecated use the <code>newXXX</code> static factory method and the
	 *             setXXX methods instead
	 */
	public final static int TCP_SERVER = 1 << 7;

	/**
	 * HTTP transport client state
	 */
	public final static int HTTP_CLIENT = 1 << 8;

	/**
	 * HTTP transport server state
	 * 
	 * @deprecated use the <code>newXXX</code> static factory method and the
	 *             setXXX methods instead
	 */
	public final static int HTTP_SERVER = 1 << 9;

	/**
	 * IP multicast transport state
	 * 
	 * @deprecated use the <code>newXXX</code> static factory method and the
	 *             setXXX methods instead
	 */
	public final static int IP_MULTICAST = 1 << 10;

	/**
	 * Rendezvous Mode
	 * 
	 * @deprecated use the <code>newXXX</code> static factory method and the
	 *             setXXX methods instead
	 */
	public final static int RDV_SERVER = 1 << 11;

	/**
	 * RendezVousService Client
	 * 
	 * @deprecated use the <code>newXXX</code> static factory method and the
	 *             setXXX methods instead
	 */
	public final static int RDV_CLIENT = 1 << 12;

	/**
	 * RendezVousService Ad-Hoc mode
	 * 
	 * @deprecated use the <code>newXXX</code> static factory method and the
	 *             setXXX methods instead
	 */
	public final static int RDV_AD_HOC = 1 << 13;

	/**
	 * Default AD-HOC configuration
	 * 
	 * @deprecated use the <code>newXXX</code> static factory method and the
	 *             setXXX methods instead
	 */
	public final static int ADHOC_NODE = TCP_CLIENT | TCP_SERVER | IP_MULTICAST | RDV_AD_HOC | RELAY_OFF;

	/**
	 * Default Edge configuration
	 * 
	 * @deprecated use the <code>newXXX</code> static factory method and the
	 *             setXXX methods instead
	 */
	public final static int EDGE_NODE = TCP_CLIENT | TCP_SERVER | HTTP_CLIENT | IP_MULTICAST | RDV_CLIENT
			| RELAY_CLIENT;

	/**
	 * Default Rendezvous configuration
	 * 
	 * @deprecated use the <code>newXXX</code> static factory method and the
	 *             setXXX methods instead
	 */
	public final static int RDV_NODE = RDV_SERVER | TCP_CLIENT | TCP_SERVER | HTTP_SERVER;

	/**
	 * Default Relay configuration
	 * 
	 * @deprecated use the <code>newXXX</code> static factory method and the
	 *             setXXX methods instead
	 */
	public final static int RELAY_NODE = RELAY_SERVER | TCP_CLIENT | TCP_SERVER | HTTP_SERVER;

	/**
	 * Default Proxy configuration
	 * 
	 * @deprecated use the <code>newXXX</code> static factory method and the
	 *             setXXX methods instead
	 */
	public final static int PROXY_NODE = PROXY_SERVER | RELAY_NODE;

	/**
	 * Default Rendezvous/Relay/Proxy configuration
	 * 
	 * @deprecated use the <code>newXXX</code> static factory method and the
	 *             setXXX methods instead
	 */
	public final static int RDV_RELAY_PROXY_NODE = RDV_NODE | PROXY_NODE;

	private static final String DEFAULT_PEER_NAME = "unknown";

	private static final String DEFAULT_PEER_DESCRIPTION = "Default Platform Config Advertisement created by: "
			+ NetworkConfigurator.class.getName();

	private static final int DEFAULT_MULTICAST_SIZE = 16384;

	private static final int DEFAULT_MULTICAST_PORT = 1234;

	private static final String DEFAULT_MULTICAST_IP = "224.0.1.85";

	private static final int DEFAULT_TCP_PORT = 9701;

	private static final int DEFAULT_TCP_START_PORT = 9701;

	private static final int DEFAULT_TCP_END_PORT = 9799;

	private static final int DEFAULT_HTTP_PORT = 9700;

	private static final int DEFAULT_RENDEZVOUS_MAX_CLIENTS = -1;

	private final static Logger LOG = Logger.getLogger(NetworkConfigurator.class.getName());

	/**
	 * Contains ID, name, description
	 */
	private PlatformConfig peerConfig;

	/**
	 * TCP Config Advertisement
	 */
	private TCPAdv tcpConfig;

	/**
	 * TCP Advertisement enabled/disabled
	 */
	private boolean tcpConfigEnabled;

	/**
	 * HTTP Config Advertisement
	 */
	private HTTPAdv httpConfig;

	/**
	 * HTTP Advertisement enabled/disabled
	 */
	private boolean httpConfigEnabled;

	/**
	 * Rendezvous Config Advertisement
	 */
	private RdvConfigAdv rdvConfig;

	/**
	 * Rendezvous Advertisement enabled/disabled
	 */
	private boolean rdvConfigEnabled;

	/**
	 * Relay Config Advertisement
	 */
	private RelayConfigAdv relayConfig;

	/**
	 * Relay Advertisement enabled/disabled
	 */
	private boolean relayConfigEnabled;

	/**
	 * Proxy Service Document
	 */
	private XMLDocument proxyConfig;

	/**
	 * Proxy Advertisement enabled/disabled
	 */
	private boolean proxyConfigEnabled;

	/**
	 * Personal Security Environment Config Advertisement
	 * 
	 * @see net.jxta.impl.membership.pse.PSEConfig
	 */
	private PSEConfigAdv pseConfig;

	/**
	 * Principal value used to generate root certificate
	 */
	private String principal = null;

	/**
	 * Password value used to generate root certificate
	 */
	private String password = null;

	protected transient Properties configProps = null;

	public static enum RendezvousConfig {
		EDGE, RENDEZVOUS, AD_HOC
	}

	/**
	 * @see #newNetworkConfiguratorEdge()
	 * @deprecated use {@link #newNetworkConfiguratorEdge()} instead.
	 */
	public NetworkConfigurator() {
		resetToDefaultEdge();
	}

	/**
	 * Creates a NetworkConfigurator with the default configuration of the
	 * specified mode. <p/>Valid modes include ADHOC_NODE, EDGE_NODE, RDV_NODE
	 * PROXY_NODE, RELAY_NODE, RDV_RELAY_PROXY_NODE, or any combination of
	 * specific configuration.<p/> e.g. RDV_NODE | HTTP_CLIENT
	 * 
	 * @see #setMode
	 * @param mode
	 *            the new configuration mode
	 * @param storeHome
	 *            the URI to persistent store
	 * @deprecated use the <code>newXXX</code> static factory methods instead
	 */
	public NetworkConfigurator(int mode, URI storeHome) {
		setMode(mode);
		// FIXME: What if it is not file URI???
		setHome(new File(storeHome));
	}

	/**
	 * Does not initialize (reset) anything! Don't forget to call any of the
	 * resetXXX methods if you create a new instance with this constructor.
	 * 
	 * @param dummy
	 *            Just to differ from the parameterless public constructor
	 *            (backwards compatibility)
	 */
	private NetworkConfigurator(boolean dummy) {
	}

	private void reset() {
		reset(null, null, false, null, false, null, false, null, false, null, false, null);
	}

	/**
	 * Makes sure that all configuration advertisements are initialized to a non
	 * <code>null</code> value.
	 */
	private void reset(PlatformConfig peerConfig, TCPAdv tcpConfig, boolean tcpConfigEnabled, HTTPAdv httpConfig,
			boolean httpConfigEnabled, RdvConfigAdv rdvConfig, boolean rdvConfigEnabled, RelayConfigAdv relayConfig,
			boolean relayConfigEnabled, XMLDocument proxyConfig, boolean proxyConfigEnabled, PSEConfigAdv pseConfig) {
		this.tcpConfigEnabled = tcpConfigEnabled;
		this.httpConfigEnabled = httpConfigEnabled;
		this.rdvConfigEnabled = rdvConfigEnabled;
		this.relayConfigEnabled = relayConfigEnabled;
		this.proxyConfigEnabled = proxyConfigEnabled;
		this.pseConfig = pseConfig;

		this.peerConfig = peerConfig != null ? peerConfig : (PlatformConfig) AdvertisementFactory
				.newAdvertisement(PlatformConfig.getAdvertisementType());
		// FIXME:
		this.peerConfig.setDebugLevel("OFF");

		this.tcpConfig = tcpConfig;
		if (this.tcpConfig == null) {
			this.tcpConfig = tcpConfig != null ? tcpConfig : (TCPAdv) AdvertisementFactory.newAdvertisement(TCPAdv
					.getAdvertisementType());
			this.tcpConfig.setProtocol("tcp");
		}

		this.httpConfig = httpConfig;
		if (this.httpConfig == null) {
			this.httpConfig = (HTTPAdv) AdvertisementFactory.newAdvertisement(HTTPAdv.getAdvertisementType());
			this.httpConfig.setProtocol("http");
		}

		this.rdvConfig = rdvConfig != null ? rdvConfig : (RdvConfigAdv) AdvertisementFactory
				.newAdvertisement(RdvConfigAdv.getAdvertisementType());

		this.relayConfig = relayConfig != null ? relayConfig : (RelayConfigAdv) AdvertisementFactory
				.newAdvertisement(RelayConfigAdv.getAdvertisementType());

		/*
		 * The state of the PSE is actually hold by the fields principal and
		 * password. But if the network configurator is loaded from an already
		 * existing Platform config, the original username and password can't be
		 * recovered anymore. But because we still want to be able to save a
		 * Platform config that was loaded from a platform config again, we need
		 * to set the pseConfig at the time the PlatfromConfig is loaded.
		 */
		this.pseConfig = pseConfig;

		this.proxyConfig = proxyConfig != null ? proxyConfig : (XMLDocument) StructuredDocumentFactory
				.newStructuredDocument(MimeMediaType.XMLUTF8, "Parm");
		configProps = null;

	}

	/**
	 * Sets the current node configuration mode.
	 * <p>
	 * The default mode is EDGE, unless modified at construction time. A node
	 * configuration mode defined a preset configuration parameters based on a
	 * operating mode. i.e. an EDGE mode, enable client/server side tcp,
	 * multicast, client side http, RelayService client mode. <p/> Valid modes
	 * include EDGE, RDV_SERVER, RELAY_OFF, RELAY_CLIENT, RELAY_SERVER,
	 * PROXY_SERVER, or any combination of which.<p/> e.g. RDV_SERVER +
	 * RELAY_SERVER
	 * 
	 * @see #getMode
	 * @param mode
	 *            the new configuration mode
	 * 
	 * @deprecated Use the setter methods instead.
	 */
	public void setMode(int mode) {
		resetToDefaultEdge();

		setRelayEnabled((mode & RELAY_OFF) == RELAY_OFF);
		setRelayClient((mode & RELAY_CLIENT) == RELAY_CLIENT);
		setRelayServer((mode & RELAY_SERVER) == RELAY_SERVER);
		setProxyEnabled((mode & PROXY_SERVER) == PROXY_SERVER);
		setTcpIncoming((mode & TCP_CLIENT) == TCP_CLIENT);
		setTcpOutgoing((mode & TCP_SERVER) == TCP_SERVER);
		setHttpIncoming((mode & HTTP_CLIENT) == HTTP_CLIENT);
		setHttpOutgoing((mode & HTTP_SERVER) == HTTP_SERVER);
		setUseMulticast((mode & IP_MULTICAST) == IP_MULTICAST);
		if ((mode & RDV_SERVER) == RDV_SERVER) {
			setRendezvousConfig(RendezvousConfig.RENDEZVOUS);
		}
		if ((mode & RDV_CLIENT) == RDV_CLIENT) {
			setRendezvousConfig(RendezvousConfig.EDGE);
		}
		if ((mode & RDV_AD_HOC) == RDV_AD_HOC) {
			setRendezvousConfig(RendezvousConfig.AD_HOC);
		}
	}

	/**
	 * Returns the current configuration mode
	 * <p>
	 * The default mode is EDGE, unless modified at construction time or through
	 * Method {@link NetworkConfigurator#setMode}. A node configuration mode
	 * defined a preset configuration parameters based on a operating mode. i.e.
	 * an EDGE mode, enable client/server side tcp, multicast, client side http,
	 * RelayService client mode.
	 * 
	 * @see #setMode
	 * @return mode the current mode value
	 * @deprecated Use getter methods instead (e.g. {@link #isHttpEnabled()}).
	 */
	public int getMode() {
		int mode = 0;
		mode = mode | (!isRelayEnabled() ? RELAY_OFF : 0);
		mode = mode | (isRelayClient() ? RELAY_CLIENT : 0);
		mode = mode | (isRelayServer() ? RELAY_SERVER : 0);
		mode = mode | (isProxyEnabled() ? PROXY_SERVER : 0);
		mode = mode | (isTcpIncoming() ? TCP_CLIENT : 0);
		mode = mode | (isTcpOutgoing() ? TCP_SERVER : 0);
		mode = mode | (isHttpIncoming() ? HTTP_SERVER : 0);
		mode = mode | (isHttpOutgoing() ? HTTP_CLIENT : 0);
		mode = mode | (isUseMulticast() ? IP_MULTICAST : 0);

		switch (getRendezvousConfig()) {
		case EDGE:
			mode = mode | RDV_CLIENT;
			break;
		case RENDEZVOUS:
			mode = mode | RDV_SERVER;
			break;
		case AD_HOC:
			mode = mode | RDV_AD_HOC;
			break;
		}

		return mode;
	}

	/**
	 * Creates a new <code>NetworkConfigurator</code> instance that is
	 * suitable to create a PlatformConfig for an EDGE peer. The configuration
	 * is provided in detail below:
	 * 
	 * <table>
	 * <tr>
	 * <th>Peer ID</th>
	 * <td><code>IDFactory.newPeerID(PeerGroupID.defaultNetPeerGroupID)</code></td>
	 * </tr>
	 * <tr>
	 * <th>Name</th>
	 * <td>&quot;unknown&quot;</td>
	 * </tr>
	 * <tr>
	 * <th>Description</th>
	 * <td>&quot;Default Platform Config Advertisement created by
	 * NetworkConfigurator&quot;</td>
	 * </tr>
	 * <tr>
	 * <th>Tcp enabled</th>
	 * <td><code>true</code></td>
	 * </tr>
	 * <tr>
	 * <th>Tcp incoming</th>
	 * <td><code>true</code></td>
	 * </tr>
	 * <tr>
	 * <th>Tcp outgoing</th>
	 * <td><code>true</code></td>
	 * </tr>
	 * <tr>
	 * <th>Tcp Interface Address</th>
	 * <td><code>null</code></td>
	 * </tr>
	 * <tr>
	 * <th>Tcp Port</th>
	 * <td><code>9701</code></td>
	 * </tr>
	 * <tr>
	 * <th>Tcp Start Port</th>
	 * <td><code>9701</code></td>
	 * </tr>
	 * <tr>
	 * <th>Tcp End Port</th>
	 * <td><code>9799</code></td>
	 * </tr>
	 * <tr>
	 * <th>Use multicast</th>
	 * <td><code>true</code></td>
	 * </tr>
	 * <tr>
	 * <th>Multicast address</th>
	 * <td><code>&quot;224.0.1.85&quot;</code></td>
	 * </tr>
	 * <tr>
	 * <th>Multicast port</th>
	 * <td><code>1234</code></td>
	 * </tr>
	 * <tr>
	 * <th>Multicast size</th>
	 * <td><code>16384</code></td>
	 * </tr>
	 * <tr>
	 * <th>Tcp public address</th>
	 * <td><code>null</code></td>
	 * </tr>
	 * <tr>
	 * <th>Tcp public address exclusive</th>
	 * <td><code>false</code></td>
	 * </tr>
	 * <tr>
	 * <th>Http enabled</th>
	 * <td><code>true</code></td>
	 * </tr>
	 * <tr>
	 * <th>Http incoming</th>
	 * <td><code>false</code></td>
	 * </tr>
	 * <tr>
	 * <th>Http outgoing</th>
	 * <td><code>true</code></td>
	 * </tr>
	 * <tr>
	 * <th>Http port</th>
	 * <td><code>9700</code></td>
	 * </tr>
	 * <tr>
	 * <th>Http public address</th>
	 * <td><code>null</code></td>
	 * </tr>
	 * <tr>
	 * <th>Http public address exclusive</th>
	 * <td><code>false</code></td>
	 * </tr>
	 * <tr>
	 * <th>Rendezvous enabled</th>
	 * <td><code>true</code></td>
	 * </tr>
	 * <tr>
	 * <th>Rendezvous config</th>
	 * <td><code>RendezvousConfig.EDGE</code></td>
	 * </tr>
	 * <tr>
	 * <th>Rendezvous seeds</th>
	 * <td>none are configured by default</td>
	 * </tr>
	 * <tr>
	 * <th>Use Only Rendezvous Seeds</th>
	 * <td><code>false</code></td>
	 * </tr>
	 * <tr>
	 * <th>Rendezvous max clients</th>
	 * <td><code>-1</code></td>
	 * </tr>
	 * <tr>
	 * <th>Relay enabled</th>
	 * <td><code>true</code></td>
	 * </tr>
	 * <tr>
	 * <th>Relay client</th>
	 * <td><code>true</code></td>
	 * </tr>
	 * <tr>
	 * <th>Relay server</th>
	 * <td><code>false</code></td>
	 * </tr>
	 * <tr>
	 * <th>Relay seeds</th>
	 * <td>none are configured by default</td>
	 * </tr>
	 * <tr>
	 * <th>Use Only Relay Seeds</th>
	 * <td><code>false</code></td>
	 * </tr>
	 * <tr>
	 * <th>Proxy enabled</th>
	 * <td><code>false</code></td>
	 * </tr>
	 * <tr>
	 * <th>Principal</th>
	 * <td><code>null</code></td>
	 * </tr>
	 * <tr>
	 * <th>Password</th>
	 * <td><code>null</code></td>
	 * </tr>
	 * </table>
	 * 
	 * @return
	 */
	public static NetworkConfigurator newNetworkConfiguratorEdge() {
		NetworkConfigurator networkConfigurator = new NetworkConfigurator(true);
		networkConfigurator.resetToDefaultEdge();
		return networkConfigurator;
	}

	private void resetToDefaultEdge() {
		reset();
		// Peer configuration advertisement
		setPeerID(IDFactory.newPeerID(PeerGroupID.defaultNetPeerGroupID));
		setName(DEFAULT_PEER_NAME);
		setDescription(DEFAULT_PEER_DESCRIPTION);

		// TCP configuration advertisement
		setTcpEnabled(true);
		setTcpIncoming(true);
		setTcpOutgoing(true);
		setTcpInterfaceAddress(null);
		setTcpPort(DEFAULT_TCP_PORT);
		setTcpStartPort(DEFAULT_TCP_START_PORT);
		setTcpEndPort(DEFAULT_TCP_END_PORT);
		setMulticastAddress(DEFAULT_MULTICAST_IP);
		setMulticastPort(DEFAULT_MULTICAST_PORT);
		setMulticastSize(DEFAULT_MULTICAST_SIZE);
		setUseMulticast(true);
		setTcpPublicAddress(null);
		setTcpPublicAddressExclusive(false);

		// HTTP configuration advertisement
		setHttpEnabled(true);
		setHttpIncoming(false);
		setHttpOutgoing(true);
		setHttpPort(DEFAULT_HTTP_PORT);
		setHttpPublicAddress(null);
		setHttpPublicAddressExclusive(false);

		// Rendezvous configuration advertisement
		setRendezvousEnabled(true);
		setUseOnlyRendezvousSeeds(false);
		setRendezvousConfig(RendezvousConfig.EDGE);
		setRendezvousMaxClients(DEFAULT_RENDEZVOUS_MAX_CLIENTS);

		// Relay configuration advertisement
		setRelayEnabled(true);
		setRelayClient(true);
		setRelayServer(false);
		setUseOnlyRelaySeeds(false);

		// Proxy configuration advertisement
		setProxyEnabled(false);
	}

	/**
	 * Creates a new <code>NetworkConfigurator</code> instance that is
	 * suitable to create a PlatformConfig for a RENDEZVOUS peer. The
	 * configuration is the same as the one created for an EDGE peer ({@link #newNetworkConfiguratorEdge()})
	 * with the following changes:
	 * 
	 * <table>
	 * <tr>
	 * <th>Rendezvous config</th>
	 * <td><code>RendezvousConfig.RENDEZVOUS</code></td>
	 * </tr>
	 * <tr>
	 * <th>Http incoming</th>
	 * <td><code>true</code></td>
	 * </tr>
	 * <tr>
	 * <th>Http outgoing</th>
	 * <td><code>false</code></td>
	 * </tr>
	 * <tr>
	 * <th>Relay server</th>
	 * <td><code>true</code></td>
	 * </tr>
	 * </table>
	 * 
	 * @return
	 */
	public static NetworkConfigurator newNetworkConfiguratorRendezvous() {
		NetworkConfigurator networkConfigurator = new NetworkConfigurator(true);
		networkConfigurator.resetToDefaultRendezvous();
		return networkConfigurator;
	}

	private void resetToDefaultRendezvous() {
		resetToDefaultEdge();
		setRendezvousConfig(RendezvousConfig.RENDEZVOUS);
		setHttpIncoming(true);
		setHttpOutgoing(false);
		setRelayServer(true);
	}

	/**
	 * Creates a new <code>NetworkConfigurator</code> instance that is
	 * suitable to create a PlatformConfig for a AD_HOC peer. The configuration
	 * is the same as the one created for an EDGE peer ({@link #newNetworkConfiguratorEdge()})
	 * with the following changes (FIXME: Is that configuration suitable for an
	 * AD_HOC client?):
	 * 
	 * <table>
	 * <tr>
	 * <th>Rendezvous config</th>
	 * <td><code>RendezvousConfig.AD_HOC</code></td>
	 * <tr>
	 * <tr>
	 * <th>Relay client</th>
	 * <td><code>false</code></td>
	 * </tr>
	 * </table>
	 * 
	 * @return
	 */
	public static NetworkConfigurator newNetworkConfiguratorAdHoc() {
		NetworkConfigurator networkConfigurator = new NetworkConfigurator(true);
		networkConfigurator.resetToDefaultAdHoc();
		return networkConfigurator;
	}

	private void resetToDefaultAdHoc() {
		resetToDefaultEdge();
		setRendezvousConfig(RendezvousConfig.AD_HOC);
		setRelayClient(false);
	}

	/**
	 * Sets the peer ID of this peer.
	 * 
	 * @param peerid
	 *            the ID of the peer
	 */
	public void setPeerID(PeerID peerID) {
		peerConfig.setPeerID(peerID);
	}

	/**
	 * Sets the peer ID of this peer. Convenience method to be able to set the
	 * peer with a string. Equivalent to:
	 * <code>setPeerID((PeerID) ID.create(URI.create(peerID)))</code>
	 * 
	 * @param peerid
	 *            the ID of the peer
	 */
	public void setPeerId(String peerID) {
		setPeerID((PeerID) ID.create(URI.create(peerID)));
	}

	/**
	 * Returns the peer ID of this peer.
	 * 
	 * @return
	 */
	public PeerID getPeerID() {
		return peerConfig.getPeerID();
	}

	/**
	 * Sets the name of the peer (default <code>&quot;unknown&quot;</code>).
	 * The name of a peer does not to be unique.
	 * 
	 * @param name
	 *            the name of the peer
	 */
	public void setName(String name) {
		String oldValue = getName();
		peerConfig.setName(name);
		propertyChangeSupport.firePropertyChange(PROPERTY_NAME, oldValue, name);

	}

	/**
	 * Returns the name of the peer.
	 * 
	 * @return the name of the peer.
	 */
	public String getName() {
		return peerConfig.getName();
	}

	/**
	 * Sets PlaformConfig Peer Description element. Default: &quot;Platform
	 * Config Advertisement generated by NetworkConfigurator&quot;.
	 * 
	 * @param description
	 *            Description of the peer.
	 */
	public void setDescription(String description) {
		String oldValue = getDescription();
		peerConfig.setDescription(description);
		propertyChangeSupport.firePropertyChange(PROPERTY_DESCRIPTION, oldValue, description);
	}

	/**
	 * Returns the description of the peer.
	 * 
	 * @return the description of the peer.
	 */
	public String getDescription() {
		return peerConfig.getDescription();
	}

	/**
	 * Enables or disables the TCP support.
	 * 
	 * @param enabled
	 *            <code>true</code> to enable TCP support
	 */
	public void setTcpEnabled(boolean enabled) {
		tcpConfigEnabled = enabled;
		propertyChangeSupport.firePropertyChange(PROPERTY_TCP_ENABLED, !enabled, enabled);
	}

	/**
	 * Returns if TCP support is enabled
	 * 
	 * @return <code>true</code> if TCP support is enabled
	 */
	public boolean isTcpEnabled() {
		return tcpConfigEnabled;
	}

	/**
	 * Toggles the support to receive messages over the TCP transport (default
	 * is enabled).
	 * 
	 * @param enabled
	 *            if <code>true</code>, the peer will listen for TCP requests
	 *            on the port given by {@link #setTcpPort(int)}, otherwise
	 *            incoming TCP is disabled and the peer does not listen to
	 *            request from the TCP transport.
	 */
	public void setTcpIncoming(boolean enabled) {
		tcpConfig.setServerEnabled(enabled);
		propertyChangeSupport.firePropertyChange(PROPERTY_TCP_INCOMING, !enabled, enabled);
	}

	/**
	 * Returns if the TCP transport is listening for messages or not.
	 * 
	 * @return <code>true</code> if the TCP transport is configured to listen
	 *         for messages.
	 */
	public boolean isTcpIncoming() {
		return tcpConfig.isServerEnabled();
	}

	/**
	 * Toggles the support to send messages over TCP.
	 * 
	 * @param enabled
	 *            if <code>true</code>, the peer can use TCP to send messages
	 *            to other peers. Other peers must have enabled
	 *            <code>tcpIncoming</code> to receive data through TCP.
	 */
	public void setTcpOutgoing(boolean enabled) {
		tcpConfig.setClientEnabled(enabled);
		propertyChangeSupport.firePropertyChange(PROPERTY_TCP_OUTGOING, !enabled, enabled);
	}

	/**
	 * Returns if the TCP transport is configured to send messages.
	 * 
	 * @return <code>true</code> if the TCP transport is configured to send
	 *         messages.
	 */
	public boolean isTcpOutgoing() {
		return tcpConfig.isServerEnabled();
	}

	/**
	 * Sets the TCP listening port (default 9701). This is meaningful only if
	 * {@link #setTcpIncoming(boolean)} is enabled. To set the port of the HTTP
	 * transport use {@link #setHttpPort(int)}.
	 * 
	 * @param port
	 *            the tcp socket port the peer is listening on for request from
	 *            the TCP transport
	 */
	public void setTcpPort(int port) {
		int oldValue = getTcpPort();
		tcpConfig.setPort(port);
		propertyChangeSupport.firePropertyChange(PROPERTY_TCP_PORT, oldValue, port);
	}

	/**
	 * Returns the port the TCP transport is listening.
	 * 
	 * @return the port the TCP transport is listening.
	 * 
	 * @see #isTcpIncoming()
	 */
	public int getTcpPort() {
		return tcpConfig.getPort();
	}

	/**
	 * Sets the lowest port on which the TCP Transport will listen if configured
	 * to do so {@link #setTcpIncoming(boolean)} is set to <code>true</code>.
	 * Valid values are <code>-1</code>, <code>0</code> and
	 * <code>1-65535</code>. The <code>-1</code> value is used to signify
	 * that the port range feature should be disabled. The <code>0</code>
	 * specifies that the Socket API dynamic port allocation should be used. For
	 * values <code>1-65535</code> the value must be equal to or less than the
	 * value used for end port. If the start port is set to <code>-1</code>
	 * the end port must be set to <code>-1</code> too.
	 * 
	 * @param start
	 *            the lowest port on which to listen.
	 * 
	 * @see #setTcpEndPort(int)
	 */
	public void setTcpStartPort(int start) {
		int oldValue = getTcpStartPort();
		tcpConfig.setStartPort(start);
		propertyChangeSupport.firePropertyChange(PROPERTY_TCP_START_PORT, oldValue, start);
	}

	/**
	 * Returns the start port on which the TCP transport is configured to listen
	 * for messages.
	 * 
	 * @return the start port on which the TCP transport is configured to listen
	 *         for messages.
	 * @see #setTcpStartPort(int)
	 */
	public int getTcpStartPort() {
		return tcpConfig.getStartPort();
	}

	/**
	 * Sets the highest port on which the TCP Transport will listen if
	 * configured to do so. Valid values are <code>-1</code>, <code>0</code>
	 * and <code>1-65535</code>. The <code>-1</code> value is used to
	 * signify that the port range feature should be disabled. The
	 * <code>0</code> specifies that the Socket API dynamic port allocation
	 * should be used. For values <code>1-65535</code> the value must be equal
	 * to or greater than the value used for start port. If the start port is
	 * set to <code>-1</code> the end port must be set to <code>-1</code>
	 * too.
	 * 
	 * @param end
	 *            the highest port on which to listen
	 * 
	 * @see #setTcpStartPort(int)
	 */
	public void setTcpEndPort(int end) {
		int oldValue = getTcpEndPort();
		tcpConfig.setEndPort(end);
		propertyChangeSupport.firePropertyChange(PROPERTY_TCP_END_PORT, oldValue, end);
	}

	/**
	 * Returns the end port on which the TCP transport is configured to listen
	 * for messages.
	 * 
	 * @return the end port on which the TCP transport is configured to listen
	 *         for messages.
	 * @see #setTcpEndPort(int)
	 */
	public int getTcpEndPort() {
		return tcpConfig.getEndPort();
	}

	/**
	 * Sets the TCP interface Address on which the peer listens for incoming
	 * requests from the TCP transport. Only meaningful if
	 * {@link #setTcpIncoming(boolean)} is enabled. Please see
	 * {@link #setTcpPublicAddress(String, boolean)} if the peer is not
	 * reachable through this address from the public network.
	 * 
	 * @param address
	 *            An IP address (e.g. <code>&quot;192.168.1.1&quot;</code>).
	 */
	public void setTcpInterfaceAddress(String address) {
		String oldValue = getTcpInterfaceAddress();
		tcpConfig.setInterfaceAddress(address);
		propertyChangeSupport.firePropertyChange(PROPERTY_TCP_INTERFACE_ADDRESS, oldValue, address);
	}

	/**
	 * Returns the address on which the TCP transport is listening for incoming
	 * messages.
	 * 
	 * @return a TCP address or <code>null</code> if the interface address is
	 *         not set. If the interface address is not set, a peer listens on
	 *         all interfaces it can find on the computer (FIXME: is that
	 *         true?).
	 */
	public String getTcpInterfaceAddress() {
		return tcpConfig.getInterfaceAddress();
	}

	/**
	 * Sets the node public address <p/>e.g. "192.168.1.1:9701" <p/>This address
	 * is the physical address defined in a node's AccessPointAdvertisement.
	 * This often required for NAT'd/FW nodes
	 * 
	 * @param address
	 *            the TCP transport public address
	 * @param exclusive
	 *            public address advertised exclusively
	 * 
	 * @deprecated use {@link #setTcpPublicAddress(String)} and
	 *             {@link #setTcpPublicAddressExclusive(boolean)} instead.
	 */
	public void setTcpPublicAddress(String address, boolean exclusive) {
		setTcpPublicAddress(address);
		setTcpPublicAddressExclusive(exclusive);
	}

	/**
	 * Sets the node public address <p/>e.g. "192.168.1.1:9701" <p/>This address
	 * is the physical address defined in a node's AccessPointAdvertisement.
	 * This often required for NAT'd/FW nodes
	 * 
	 * @param address
	 *            the TCP transport public address
	 */
	public void setTcpPublicAddress(String address) {
		String oldValue = getTcpPublicAddress();
		tcpConfig.setServer(address);
		propertyChangeSupport.firePropertyChange(PROPERTY_TCP_PUBLIC_ADDRESS, oldValue, address);
	}

	/**
	 * Returns the public address under which the peer is reachable by peers
	 * from the public network. This can differ from the interface the peer is
	 * listening for messages. Most of the time this will be the address of the
	 * public address of a NAT server, that forwards TCP requests to a peer in
	 * the local network.
	 * 
	 * @return a TCP address or <code>null</code> if this address is not
	 *         explicitely set, that means it is set to the same value as the
	 *         TCP interface address ({@link #getTcpInterfaceAddress()}).
	 *         FIXME: Correct?
	 */
	public String getTcpPublicAddress() {
		return tcpConfig.getServer();
	}

	/**
	 * Sets whether the public address is exclusive FIXME: Better description of
	 * what this means in practice.
	 * 
	 * @param exclusive
	 *            True, if the address is exclusive, false otherwise.
	 */
	public void setTcpPublicAddressExclusive(boolean exclusive) {
		tcpConfig.setPublicAddressOnly(exclusive);
		propertyChangeSupport.firePropertyChange(PROPERTY_TCP_PUBLIC_ADDRESS_EXCLUSIVE, !exclusive, exclusive);
	}

	/**
	 * Returns if the public address is exclusive FIXME: Better description of
	 * what this means in practice.
	 * 
	 * @return if the public address is exclusive
	 */
	public boolean isTcpPublicAddressExclusive() {
		return tcpConfig.getPublicAddressOnly();
	}

	/**
	 * Toggles whether to use IP group multicast (default is <code>true</code>).
	 * 
	 * @param enable
	 *            <code>true</code> to enable multicast for this peer.
	 */
	public void setUseMulticast(boolean enable) {
		tcpConfig.setMulticastState(enable);
		propertyChangeSupport.firePropertyChange(PROPERTY_USE_MULTICAST, !enable, enable);
	}

	/**
	 * Returns if the peer uses multicast to find other peers (FIXME: Is it
	 * really just used to find other peers or is it used to send normal data
	 * messages too?)
	 * 
	 * @return <code>true</code> if the peer uses multicast.
	 */
	public boolean isUseMulticast() {
		return tcpConfig.getMulticastState();
	}

	/**
	 * Sets the IP group multicast address (default:
	 * <code>&quot;224.0.1.85&quot;</code>).
	 * 
	 * @see #setMulticastPort(int)
	 * @param mcastAddress
	 *            the new multicast group address
	 */
	public void setMulticastAddress(String mcastAddress) {
		String oldValue = getMulticastAddress();
		tcpConfig.setMulticastAddr(mcastAddress);
		propertyChangeSupport.firePropertyChange(PROPERTY_MULTICAST_ADDRESS, oldValue, mcastAddress);
	}

	/**
	 * Returns the IP group multicast address.
	 * 
	 * @return the TCP multicast address or <code>null</code> if not set.
	 */
	public String getMulticastAddress() {
		return tcpConfig.getMulticastAddr();
	}

	/**
	 * Sets the IP group multicast port (default 1234).
	 * 
	 * @see #setMulticastAddress
	 * @param port
	 *            the new IP group multicast port
	 */
	public void setMulticastPort(int port) {
		int oldValue = getMulticastPort();
		tcpConfig.setMulticastPort(port);
		propertyChangeSupport.firePropertyChange(PROPERTY_MULTICAST_PORT, oldValue, port);
	}

	/**
	 * Returns the multicast port.
	 * 
	 * @return the multicast port.
	 */
	public int getMulticastPort() {
		return tcpConfig.getMulticastPort();
	}

	/**
	 * Sets the multicast size.
	 * 
	 * @param size
	 *            the multicast size.
	 */
	public void setMulticastSize(int size) {
		int oldValue = getMulticastSize();
		tcpConfig.setMulticastSize(size);
		propertyChangeSupport.firePropertyChange(PROPERTY_MULTICAST_SIZE, oldValue, size);
	}

	/**
	 * Returns the multicast size
	 * 
	 * @return the multicast size
	 */
	public int getMulticastSize() {
		return tcpConfig.getMulticastSize();
	}

	/**
	 * Enables or disables the HTTP support.
	 * 
	 * @param enabled
	 *            <code>true</code> to enable HTTP support
	 */
	public void setHttpEnabled(boolean enabled) {
		httpConfigEnabled = enabled;
		propertyChangeSupport.firePropertyChange(PROPERTY_HTTP_ENABLED, !enabled, enabled);
	}

	/**
	 * Returns if HTTP support is enabled
	 * 
	 * @return <code>true</code> if HTTP support is enabled
	 */
	public boolean isHttpEnabled() {
		return httpConfigEnabled;
	}

	/**
	 * Toggles the support to receive messages over HTTP.
	 * 
	 * @param incoming
	 *            if <code>true</code>, the peer will listen for HTTP
	 *            requests on the port given by {@link #setHttpPort(int)},
	 *            otherwise incoming HTTP is disabled.
	 */
	public void setHttpIncoming(boolean incoming) {
		httpConfig.setServerEnabled(incoming);
		propertyChangeSupport.firePropertyChange(PROPERTY_HTTP_INCOMING, !incoming, incoming);
	}

	/**
	 * Returns if the HTTP transport is listening for messages or not.
	 * 
	 * @return <code>true</code> if the HTTP transport is configured to listen
	 *         for messages.
	 */
	public boolean isHttpIncoming() {
		return httpConfig.isServerEnabled();
	}

	/**
	 * Toggles the support to send messages over HTTP.
	 * 
	 * @param outgoing
	 *            if <code>true</code>, the peer can use HTTP to send
	 *            messages to other peers. Other peers must have enabled
	 *            <code>httpIncoming</code> to receive data through HTTP. Most
	 *            of the time, the receiving federate will be a relay peer.
	 */
	public void setHttpOutgoing(boolean outgoing) {
		httpConfig.setClientEnabled(outgoing);
		propertyChangeSupport.firePropertyChange(PROPERTY_HTTP_OUTGOING, !outgoing, outgoing);
	}

	/**
	 * Returns if the HTTP transport is configured to send messages.
	 * 
	 * @return <code>true</code> if the HTTP transport is configured to send
	 *         messages.
	 */
	public boolean isHttpOutgoing() {
		return httpConfig.isClientEnabled();
	}

	/**
	 * Sets the HTTP listening port (default 9901). This is meaningful only if
	 * {@link #setHttpIncoming(boolean)} is enabled.
	 * 
	 * @param port
	 *            the port the peer is listening for HTTP requests.
	 */
	public void setHttpPort(int port) {
		int oldValue = getHttpPort();
		httpConfig.setPort(port);
		propertyChangeSupport.firePropertyChange(PROPERTY_HTTP_PORT, oldValue, port);
	}

	/**
	 * Returns the port the HTTP transport is configured to listen on.
	 * 
	 * @return the port the HTTP transport is configured to listen on.
	 * 
	 * @see #isTcpIncoming()
	 */
	public int getHttpPort() {
		return httpConfig.getPort();
	}

	/**
	 * Sets the HTTP interface Address on which the peer listens for incoming
	 * HTTP requests. Only meaningful if {@link #setHttpIncoming(boolean)} is
	 * enabled. See {@link #setHttpPublicAddress(String, boolean)} if the peer
	 * is not reachable from the public network by this address.
	 * 
	 * @param address
	 *            An IP address (e.g. <code>&quot;192.168.1.1&quot;</code>).
	 */
	public void setHttpInterfaceAddress(String address) {
		String oldValue = getHttpInterfaceAddress();
		httpConfig.setInterfaceAddress(address);
		propertyChangeSupport.firePropertyChange(PROPERTY_HTTP_INTERFACE_ADDRESS, oldValue, address);
	}

	/**
	 * Returns the address on which the HTTP transport is listening for incoming
	 * messages.
	 * 
	 * @return a TCP address or <code>null</code> if the interface address is
	 *         not set. If the interface address is not set, a peer listens on
	 *         all interfaces it can find on the computer (FIXME: is that
	 *         true?).
	 */
	public String getHttpInterfaceAddress() {
		return httpConfig.getInterfaceAddress();
	}

	/**
	 * Sets the HTTP address the peer is reachable from the public network. This
	 * is needed if the peer is not directly reachable on its own address from
	 * the public network but is behind a NAT. It is the address that other
	 * peers can use to reach the peer configured by this config. The value is
	 * in the form <code>host:port</code>, e.g.
	 * <code>&quot;209.128.126.120:9700&quot;</code>. The NAT servers needs
	 * to be configured properly for this to work.
	 * 
	 * @param address
	 *            the address this peer is reachable from the public network
	 * @param exclusive
	 *            FIXME: What does this do exactly?
	 * 
	 * @deprecated use {@link #setHttpPublicAddress(String)} and
	 *             {@link #setHttpPublicAddressExclusive(boolean)} instead.
	 */
	public void setHttpPublicAddress(String address, boolean exclusive) {
		setHttpPublicAddress(address);
		setHttpPublicAddressExclusive(exclusive);
	}

	/**
	 * Sets the HTTP address the peer is reachable from the public network. This
	 * is needed if the peer is not directly reachable on its own address from
	 * the public network but is behind a NAT. It is the address that other
	 * peers can use to reach the peer configured by this config. The value is
	 * in the form <code>host:port</code>, e.g.
	 * <code>&quot;209.128.126.120:9700&quot;</code>. The NAT servers needs
	 * to be configured properly for this to work.
	 * 
	 * @param address
	 *            the address this peer is reachable from the public network
	 */
	public void setHttpPublicAddress(String address) {
		String oldValue = getHttpPublicAddress();
		httpConfig.setServer(address);
		propertyChangeSupport.firePropertyChange(PROPERTY_HTTP_PUBLIC_ADDRESS, oldValue, address);
	}

	/**
	 * Returns the public address under which the peer is reachable by peers
	 * from the public network. This can differ from the interface the peer is
	 * listening for messages. Most of the time this will be the address of the
	 * public address of a NAT server, that forwards requests to a peer in the
	 * local network.
	 * 
	 * @return a TCP address or <code>null</code> if this address is not
	 *         explicitely set, that means it is set to the same value as the
	 *         HTTP interface address (see {@link #getHttpInterfaceAddress()}).
	 *         FIXME: Correct?
	 */
	public String getHttpPublicAddress() {
		return httpConfig.getServer();
	}

	/**
	 * FIXME documentation
	 * 
	 * @param exclusive
	 */
	public void setHttpPublicAddressExclusive(boolean exclusive) {
		httpConfig.setPublicAddressOnly(exclusive);
		propertyChangeSupport.firePropertyChange(PROPERTY_HTTP_PUBLIC_ADDRESS_EXCLUSIVE, !exclusive, exclusive);
	}

	/**
	 * FIXME documentation
	 * 
	 * @return
	 */
	public boolean isHttpPublicAddressExclusive() {
		return httpConfig.getPublicAddressOnly();
	}

	/**
	 * Enables or disables Relay support.
	 * 
	 * @param enabled
	 *            <code>true</code> to enable Relay support
	 */
	public void setRelayEnabled(boolean enabled) {
		relayConfigEnabled = enabled;
		propertyChangeSupport.firePropertyChange(PROPERTY_RELAY_ENABLED, !enabled, enabled);
	}

	/**
	 * Returns if Relay support is enabled
	 * 
	 * @return <code>true</code> if Relay support is enabled
	 */
	public boolean isRelayEnabled() {
		XMLDocument rdvDoc = (XMLDocument) rdvConfig.getDocument(MimeMediaType.XMLUTF8);
		rdvDoc.appendChild(rdvDoc.createElement("isOff"));

		return relayConfigEnabled;
	}

	/**
	 * If <code>true</code> then this peer will act as a relay server.
	 * 
	 * @param enabled
	 *            If true then this peer will act as a relay server.
	 */
	public void setRelayServer(boolean enabled) {
		relayConfig.setServerEnabled(enabled);
		propertyChangeSupport.firePropertyChange(PROPERTY_RELAY_SERVER, !enabled, enabled);
	}

	/**
	 * Returns if the peer acts as a relay server.
	 * 
	 * @return <code>true</code> if the peer shall act as a relay server.
	 */
	public boolean isRelayServer() {
		return relayConfig.isServerEnabled();
	}

	/**
	 * If true then this peer will act as a relay client.
	 * 
	 * @param enabled
	 *            If true then this peer will act as a relay client.
	 */
	public void setRelayClient(boolean enabled) {
		relayConfig.setClientEnabled(enabled);
		propertyChangeSupport.firePropertyChange(PROPERTY_RELAY_CLIENT, !enabled, enabled);
	}

	/**
	 * Returns if the peer acts as a relay client.
	 * 
	 * @return <code>true</code> if the peer shall act as a relay client, that
	 *         means if it can send messages to other peers through a relay
	 *         server.
	 */
	public boolean isRelayClient() {
		return relayConfig.isClientEnabled();
	}

	/**
	 * Adds a relay seeding URI. The URI should return a list of relay peers
	 * endpoint addresses separated by line breaks. For an example try <a
	 * href="http://rdv.jxtahosts.net/cgi-bin/relays.cgi?2">http://rdv.jxtahosts.net/cgi-bin/relays.cgi?2</a>
	 * 
	 * 
	 * @param seedURI
	 *            relay service seeding URI
	 * 
	 * @throws IllegalArgumentException
	 *             if parameter <code>seedURI</code> is <code>null</code>
	 */
	public void addRelaySeedingURI(URI seedURI) {
		relayConfig.addSeedingURI(seedURI);
	}

	/**
	 * Sets the maximum number of relay clients of this peer.
	 * 
	 * @see FIXME
	 * 
	 * @param relayMaxClients
	 *            <code>-1</code> means the default maximum of relay client is
	 *            used, which currently is set to <code>150</code>.
	 * 
	 * @throws IllegalArgumentException
	 *             if
	 *             <code>(relayMaxClients != -1) && (relayMaxClients <= 0)</code>.
	 */
	public int getRelayMaxClients() {
		return relayConfig.getMaxClients();
	}

	/**
	 * Sets the maximum number of relay clients of this peer.
	 * 
	 * @see FIXME
	 * 
	 * @param relayMaxClients
	 *            <code>-1</code> means the default maximum of relay client is
	 *            used, which currently is set to <code>150</code>.
	 * 
	 * @throws IllegalArgumentException
	 *             if
	 *             <code>(relayMaxClients != -1) && (relayMaxClients <= 0)</code>.
	 */
	public void setRelayMaxClients(int relayMaxClients) {
		if ((relayMaxClients != DEFAULT_RENDEZVOUS_MAX_CLIENTS) && (relayMaxClients <= 0)) {
			throw new IllegalArgumentException("Relay Max Clients : " + relayMaxClients + " must be > 0");
		}
		int oldValue = getRelayMaxClients();
		relayConfig.setMaxClients(relayMaxClients);
		propertyChangeSupport.firePropertyChange(PROPERTY_RELAY_MAX_CLIENTS, oldValue, relayMaxClients);
	}

	/**
	 * Sets the new RelayService seeding URI as a string. <p/>A seeding URI
	 * (when read) is expected to provide a list of physical endpoint address to
	 * relay peers
	 * 
	 * @param seedURIStr
	 *            the new RelayService seed URI as a string
	 */
	public void addRelaySeedingURI(String seedURIStr) {
		relayConfig.addSeedingURI(URI.create(seedURIStr));
	}

	/**
	 * Adds a relay service peer seed address <p/>A relay service seed is
	 * defined as a physical endpoint address. Examples are
	 * <code>http://192.168.1.1:9700</code> or
	 * <code>tcp://192.168.1.1:9701</code>).
	 * 
	 * @param seedURI
	 *            the relay seed URI to be added to the list of peer seen
	 *            endpoints.
	 */
	public void addSeedRelay(URI seedURI) {
		relayConfig.addSeedRelay(seedURI.toString());
	}

	/**
	 * FIXME documentation
	 * 
	 */
	public boolean isUseOnlyRelaySeeds() {
		return relayConfig.getUseOnlySeeds();
	}

	/**
	 * Determines whether to restrict RelayService leases to those defined in
	 * the seed list that was set by {@link #addRelaySeedingURI(String)} or
	 * {@link #addSeedRelay(URI)}.
	 * 
	 * <p>
	 * FIXME: Is this correct? See Javadoc of relayConfig.setUseOnlySeeds(...).
	 * 
	 * @param useOnlyRelaySeeds
	 *            restrict RelayService lease to seed list
	 */
	public void setUseOnlyRelaySeeds(boolean useOnlyRelaySeeds) {
		relayConfig.setUseOnlySeeds(useOnlyRelaySeeds);
		propertyChangeSupport.firePropertyChange(PROPERTY_USE_ONLY_RELAY_SEEDS, !useOnlyRelaySeeds, useOnlyRelaySeeds);
	}

	/**
	 * Enables or disables the Rendezvous support.
	 * 
	 * @param enabled
	 *            <code>true</code> to enable Rendezvous support
	 */
	public void setRendezvousEnabled(boolean enabled) {
		rdvConfigEnabled = enabled;
		propertyChangeSupport.firePropertyChange(PROPERTY_RENDEZVOUS_ENABLED, !enabled, enabled);
	}

	/**
	 * Returns if Rendezvous support is enabled
	 * 
	 * @return <code>true</code> if Rendezvous support is enabled
	 */
	public boolean isRendezvousEnabled() {
		return rdvConfigEnabled;
	}

	public void setRendezvousConfig(RendezvousConfig rendezvousConfig) {
		switch (rendezvousConfig) {
		case EDGE:
			rdvConfig.setConfiguration(RendezVousConfiguration.EDGE);
			break;
		case RENDEZVOUS:
			rdvConfig.setConfiguration(RendezVousConfiguration.RENDEZVOUS);
			break;
		case AD_HOC:
			rdvConfig.setConfiguration(RendezVousConfiguration.AD_HOC);
		default:
			break;
		}
	}

	public RendezvousConfig getRendezvousConfig() {
		RendezVousConfiguration rendezVousConfiguration = rdvConfig.getConfiguration();
		if (rendezVousConfiguration == RendezVousConfiguration.EDGE) {
			return RendezvousConfig.EDGE;
		} else if (rendezVousConfiguration == RendezVousConfiguration.RENDEZVOUS) {
			return RendezvousConfig.RENDEZVOUS;
		} else if (rendezVousConfiguration == RendezVousConfiguration.AD_HOC) {
			return RendezvousConfig.AD_HOC;
		}
		throw new IllegalStateException(
				"RendezVousConfiguration should never be anything else than EDGE, RENDEZVOU or AD_HOC");
	}

	/**
	 * FIXME documentation
	 * 
	 * @return
	 */
	public int getRendezvousMaxClients() {
		return rdvConfig.getMaxClients();
	}

	/**
	 * Sets the maximum number of rendezvous clients of this peer.
	 * 
	 * @see FIXME:
	 * 
	 * @param rdvMaxClients
	 *            <code>-1</code> means the default maximum of rendezvous
	 *            client is used, which currently is set to <code>150</code>.
	 * 
	 * @throws IllegalArgumentException
	 *             if
	 *             <code>(relayMaxClients != -1) && (relayMaxClients <= 0)</code>.
	 */
	public void setRendezvousMaxClients(int rdvMaxClients) {
		if ((rdvMaxClients != DEFAULT_RENDEZVOUS_MAX_CLIENTS) && (rdvMaxClients <= 0)) {
			throw new IllegalArgumentException("Rendezvous Max Clients : " + rdvMaxClients + " must be > 0");
		}
		int oldValue = getRendezvousMaxClients();
		rdvConfig.setMaxClients(rdvMaxClients);
		propertyChangeSupport.firePropertyChange(PROPERTY_RENDEZVOUS_MAX_CLIENTS, oldValue, rdvMaxClients);
	}

	/**
	 * FIXME documentation
	 * 
	 * @return
	 */
	public boolean isUseOnlyRendezvousSeeds() {
		return rdvConfig.getUseOnlySeeds();
	}

	/**
	 * Determines whether to restrict RendezvousService leases to those defined
	 * in the seed list that was set by {@link #addRendezvousSeedingURI(URI)} or
	 * {@link #addSeedRendezvous(URI)}.
	 * 
	 * <p>
	 * FIXME: Is this correct? See Javadoc of rdvConfig.setUseOnlySeeds(...).
	 * 
	 * @param useOnlyRendezvouSeeds
	 *            restrict RendezvousService lease to seed list
	 */
	public void setUseOnlyRendezvousSeeds(boolean useOnlyRendezvouSeeds) {
		rdvConfig.setUseOnlySeeds(useOnlyRendezvouSeeds);
		propertyChangeSupport.firePropertyChange(
				PROPERTY_USE_ONLY_RENDEZVOUS_SEEDS,
				!useOnlyRendezvouSeeds,
				useOnlyRendezvouSeeds);
	}

	/**
	 * Adds rendezvous peer seed, physical endpoint address <p/>A
	 * RendezVousService seed is defined as a physical endpoint address Examples
	 * are <code>http://192.168.1.1:9700</code> or
	 * <code>tcp://192.168.1.1:9701</code>).
	 * 
	 * @param seedURI
	 *            the rendezvous seed URI to add to the list of peer seed
	 *            endpoints.
	 */
	public void addSeedRendezvous(URI seedURI) {
		rdvConfig.addSeedRendezvous(seedURI);
	}

	/**
	 * Adds a rendezvous seeding URI. Equivalent to:
	 * <code>addRdvSeedingURI(URI.create(seedURIStr))</code>. The URI should
	 * return a list of rendezvous peer endpoint addresses in the form of an URI
	 * separated by line breaks. For an example try <a
	 * href="http://rdv.jxtahosts.net/cgi-bin/rendezvous.cgi?2">http://rdv.jxtahosts.net/cgi-bin/rendezvous.cgi?2</a>
	 * 
	 * 
	 * @param seedURI
	 *            rendezvous service seeding URI
	 * 
	 * @throws IllegalArgumentException
	 *             if parameter <code>seedURI</code> is <code>null</code>
	 */
	public void addRdvSeedingURI(String seedURIStr) {
		addRdvSeedingURI(URI.create(seedURIStr));
	}

	/**
	 * Adds a rendezvous seeding URI. The URI should return a list of rendezvous
	 * peer endpoint addresses in the form of an URI separated by line breaks.
	 * For an example try <a
	 * href="http://rdv.jxtahosts.net/cgi-bin/rendezvous.cgi?2">http://rdv.jxtahosts.net/cgi-bin/rendezvous.cgi?2</a>
	 * 
	 * 
	 * @param seedURI
	 *            rendezvous service seeding URI
	 * 
	 * @throws IllegalArgumentException
	 *             if parameter <code>seedURI</code> is <code>null</code>
	 */
	public void addRdvSeedingURI(URI seedURI) {
		rdvConfig.addSeedingURI(seedURI);
	}

	/**
	 * Sets the List relaySeeds represented as Strings <p/>A RelayService seed
	 * is defined as a physical endpoint address <p/>e.g.
	 * http://192.168.1.1:9700, or tcp://192.168.1.1:9701
	 * 
	 * @param seedURIs
	 *            the List relaySeeds represented as Strings
	 */
	public void setRelaySeedURIs(List<String> seedURIs) {
		relayConfig.clearSeedingURIs();
		for (String seedStr : seedURIs) {
			relayConfig.addSeedingURI(URI.create(seedStr));
		}
	}

	/**
	 * Sets the List of RendezVousService seeds represented as Strings <p/>A
	 * RendezvousService seed is defined as a physical endpoint address <p/>e.g.
	 * http://192.168.1.1:9700, or tcp://192.168.1.1:9701
	 * 
	 * @param seedURIs
	 *            the List rendezvousSeeds represented as Strings
	 */
	public void setRendezvousSeedURIs(List<String> seedURIs) {
		rdvConfig.clearSeedingURIs();
		for (String seedStr : seedURIs) {
			rdvConfig.addSeedingURI(URI.create(seedStr));
		}
	}

	/**
	 * Sets the Principal for the peer root certificate. If principal or
	 * password is set to <code>null</code>, no new PSE advertisement will be
	 * created.
	 * 
	 * @param principal
	 *            the new principal value
	 */
	public void setPrincipal(String principal) {
		String oldValue = getPrincipal();
		this.principal = principal;
		propertyChangeSupport.firePropertyChange(PROPERTY_PRINCIPAL, oldValue, principal);
	}

	/**
	 * Gets the Principal for the peer root certificate. Note that if this
	 * NetworkConfigurator instance was created by loading it from a
	 * PlatfromConfig this will return <code>null</code>, even if the
	 * PlatfromConfig contained a PSE configuration.
	 * 
	 * @return principal if a principal is set, <code>null</code> otherwise
	 */
	public String getPrincipal() {
		return principal;
	}

	/**
	 * Sets the password used to sign the private key of the root certificate.
	 * If principal or password is set to <code>null</code>, no new PSE
	 * advertisement will be created.
	 * 
	 * @param password
	 *            the new password value
	 */
	public void setPassword(String password) {
		String oldValue = getPassword();
		this.password = password;
		propertyChangeSupport.firePropertyChange(PROPERTY_PASSWORD, oldValue, password);
	}

	/**
	 * Gets the password used to sign the private key of the root certificate.
	 * Note that if this NetworkConfigurator instance was created by loading it
	 * from a PaltfromConfig this will return <code>null</code>, even if the
	 * PlatfromConfig contained a PSE configuration (The password can't be read
	 * once it was set).
	 * 
	 * @return password if a password is set, null otherwise
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Enables or disables the Proxy support.
	 * 
	 * @param enabled
	 *            <code>true</code> to enable Proxy support
	 */
	public void setProxyEnabled(boolean enable) {
		proxyConfigEnabled = enable;
		propertyChangeSupport.firePropertyChange(PROPERTY_PROXY_ENABLED, !enable, enable);
	}

	/**
	 * Returns if Proxy support is enabled
	 * 
	 * @return <code>true</code> if Proxy support is enabled
	 */
	public boolean isProxyEnabled() {
		return proxyConfigEnabled;
	}

	/**
	 * Set the current directory for configuration and cache persistent store
	 * <p/>(default is $CWD/.jxta)
	 * 
	 * <dt>Simple example :</dt>
	 * 
	 * <pre>
	 *  <code>
	 * //Create an application home
	 * File appHome = new File(System.getProperty(&quot;JXTA_HOME&quot;, &quot;.cache&quot;));
	 * //Create an instance home under the application home
	 * File instanceHome = new File(appHome, instanceName);
	 * jxtaConfig.setHome(instanceHome);
	 * </code>
	 * </pre>
	 * 
	 * @see #getHome
	 * @param home
	 *            the new home value
	 * @deprecated use
	 *             {@link NetPeerGroupFactory#NetPeerGroupFactory(ConfigParams, URI)}
	 *             instead.
	 */
	public void setHome(File home) {
		System.setProperty("JXTA_HOME", home.getAbsolutePath());
	}

	/**
	 * Returns the current directory for configuration and cache persistent
	 * store
	 * 
	 * @see #setHome
	 * @return Returns the current home directory
	 */
	public File getHome() {
		// Copied from NetPeerGroupFactory
		// Establish the default store location via long established hackery.
		String jxta_home = System.getProperty("JXTA_HOME", ".jxta/");
		return new File(jxta_home);
	}

	/**
	 * Returns the location which will serve as the parent for all stored items
	 * used by JXTA. This method is intended for use by PeerGroup
	 * implementations and is not intended for use by applications. Applications
	 * and services should use the PeerGroup method with the same name.
	 * 
	 * @see net.jxta.peergroup.PeerGroup#getStoreHome()
	 * 
	 * @return The location which will serve as the parent for all stored items
	 *         used by JXTA.
	 */
	public static URI getStoreHome() {
		// FIXME:
		String jxta_home = System.getProperty("JXTA_HOME", ".jxta/");
		return new File(jxta_home).toURI();
	}

	/**
	 * Sets the ID which will be used for new net peer group instances.
	 * 
	 * <p/>By Setting an alternate infrastructure PeerGroup ID (aka
	 * NetPeerGroup), it prevents heterogeneous infrstructure PeerGroups from
	 * intersecting. <p/>This is highly recommended practice foapplicaiton
	 * deployment
	 * 
	 * @see net.jxta.peergroup.PeerGroupFactory#setNetPGID
	 * @param id
	 *            the new infrastructure PeerGroupID as a string
	 * @deprecated
	 */
	public void setInfrastructureID(ID id) {
		if (id == null || id.equals(ID.nullID)) {
			throw new IllegalArgumentException("PeerGroupID can not be null");
		}
		setInfrastructureID(id.toString());
	}

	/**
	 * Sets the ID which will be used for new net peer group instances.
	 * 
	 * <p/>By Setting an alternate infrastructure PeerGroup ID (aka
	 * NetPeerGroup), it prevents heterogeneous infrstructure PeerGroups from
	 * intersecting. <p/>This is highly recommended practice foapplicaiton
	 * deployment
	 * 
	 * @see net.jxta.peergroup.PeerGroupFactory#setNetPGID
	 * @param idStr
	 *            the new infrastructure PeerGroupID as a string
	 * @deprecated
	 */
	public void setInfrastructureID(String idStr) {
		if (idStr == null || idStr.length() == 0) {
			throw new IllegalArgumentException("PeerGroupID string can not be empty or null");
		}

		PeerGroupID pgid = (PeerGroupID) ID.create(URI.create(idStr));
		PeerGroupFactory.setNetPGID(pgid);
		configProps = new Properties();
		configProps.setProperty("NetPeerGroupID", pgid.getUniqueValue().toString());
	}

	/**
	 * Sets the infrastructure PeerGroup name meta-data
	 * 
	 * @see net.jxta.peergroup.PeerGroupFactory#setNetPGName
	 * @param name
	 *            the Infrastructure PeerGroup name
	 * @deprecated
	 */
	public void setInfrastructureName(String name) {
		PeerGroupFactory.setNetPGName(name);
		if (configProps == null) {
			configProps = new Properties();
		}
		configProps.setProperty("NetPeerGroupName", name);
	}

	/**
	 * Sets the infrastructure PeerGroup description meta-data
	 * 
	 * @see net.jxta.peergroup.PeerGroupFactory#setNetPGDesc
	 * @param description
	 *            the infrastructure PeerGroup description
	 * @deprecated
	 */
	public void setInfrastructureDescription(String description) {
		PeerGroupFactory.setNetPGDesc(description);
		if (configProps == null) {
			configProps = new Properties();
		}
		configProps.setProperty("NetPeerGroupDesc", description);
	}

	/**
	 * Convenience method to load a PlatformConfig from disk and transform it
	 * into a NetworkCongigurator directly. Equivalent to:
	 * 
	 * <pre>
	 *                      ConfigParams platfromConfig = .... // load PlatfromConfig from disk
	 *                      networkConfigurator.load(platfromConfig);
	 * </pre>
	 * 
	 * @param uri
	 *            the URI to PlatformConfig file
	 * @throws IOException
	 *             If the PlatformConfig file could not be loaded
	 * @throws IllegalArgumentException
	 *             if the URI is <code>null</code> . As of now it also throws
	 *             an exception if the URI can't be transformed into an URL. But
	 *             this is probably stupid (FIXME)
	 * @deprecated use te static {@link #loadPlatformConfig(URI)} instead
	 * 
	 */
	public void load(URI uri) throws IOException {
		ConfigParams configParams = loadPlatfromConfigFromURI(uri);
		load(configParams);
	}

	/**
	 * Load a configuration from the specified store home uri <p/> e.g.
	 * file:/export/dist/EdgeConfig.xml, e.g.
	 * http://configserver.net/configservice?Edge
	 * 
	 * @exception IOException
	 *                if an i/o error occurs
	 * @exception CertificateException
	 *                if the MemebershipService is invalid
	 * @deprecated Use the static method {@link #loadPlatformConfig(URI)}
	 *             instead
	 */
	public void load() throws IOException, CertificateException {
		File platformFile = getPlatfromConfigFile();
		load(platformFile.toURI());
	}

	/**
	 * Returns true if a PlatformConfig file exist under
	 * <code>getHome()/PlatfromConfig</code>
	 * 
	 * @return true if a PlatformConfig file exist under store home
	 * @deprecated
	 */
	public boolean exists() {
		return getPlatfromConfigFile().exists();
	}

	/**
	 * Creates a NetworkConfgurator instance that takes the values from the
	 * given platform configuration.
	 * 
	 * @see #loadPlatfromConfig(URI)
	 * 
	 * @param platformConfig
	 *            the platform config that shall be wrapped by this network
	 *            configurator
	 * @return the network configurator instance that represents the values
	 *         loaded from the platform config. This new instance can be used to
	 *         modify the loaded PlatfromConfig and to save it again later.
	 */
	public static NetworkConfigurator loadPlatformConfig(ConfigParams platformConfig) {
		NetworkConfigurator networkConfigurator = new NetworkConfigurator(true);
		networkConfigurator.load(platformConfig);
		return networkConfigurator;
	}

	/**
	 * Creates a NetworkConfgurator instance that takes the values from the
	 * given platform configuration.
	 * 
	 * @see #loadPlatfromConfig(ConfigParams)
	 * 
	 * @param platformConfig
	 *            the platform config file that shall be wrapped by this network
	 *            configurator
	 * @return the network configurator instance that represents the values
	 *         loaded from the platform config. This new instance can be used to
	 *         modify the loaded PlatfromConfig and to save it again later.
	 */
	public static NetworkConfigurator loadPlatformConfig(URI platfromConfig) throws IOException {
		NetworkConfigurator networkConfigurator = new NetworkConfigurator(true);
		networkConfigurator.load(platfromConfig);
		return networkConfigurator;
	}

	/**
	 * Resets this NetworkConfgurator instance to the values of the given
	 * platform configuration.
	 * 
	 * @see #load(URI)
	 * 
	 * @param platformConfig
	 *            the platform config that shall be loaded
	 * @deprecated use static load methos
	 *             {@link #loadPlatfromConfig(ConfigParams)} instead
	 */
	public void load(ConfigParams platformConfig) {
		reset();
		PlatformConfig platformConfigInput = (PlatformConfig) platformConfig;

		// Peer configuration advertisement
		peerConfig = (PlatformConfig) AdvertisementFactory.newAdvertisement(PlatformConfig.getAdvertisementType());
		peerConfig.setPeerID(platformConfigInput.getPeerID());
		peerConfig.setName(platformConfigInput.getName());
		peerConfig.setDescription(platformConfigInput.getDescription());
		peerConfig.setDebugLevel(platformConfigInput.getDebugLevel());

		// TCP configuration advertisement
		XMLElement param = (XMLElement) platformConfigInput.getServiceParam(PeerGroup.tcpProtoClassID);
		tcpConfigEnabled = isEnabled(param);
		Enumeration tcpChilds = param.getChildren(TransportAdvertisement.getAdvertisementType());
		// get the TransportAdv from either TransportAdv or
		// tcpCnetworkConfigurator.config
		if (tcpChilds.hasMoreElements()) {
			param = (XMLElement) tcpChilds.nextElement();
			tcpConfig = (TCPAdv) AdvertisementFactory.newAdvertisement(param);
		} else {
			// FIXME: Why should we not allow a platform config without a TCP
			// advertisement?
			// throw new IllegalStateException("Missing TCP Advertisement");
		}

		// HTTP configuration advertisement
		param = (XMLElement) platformConfigInput.getServiceParam(PeerGroup.httpProtoClassID);
		httpConfigEnabled = isEnabled(param);
		Enumeration httpChilds = param.getChildren(TransportAdvertisement.getAdvertisementType());
		// get the TransportAdv from either TransportAdv
		if (httpChilds.hasMoreElements()) {
			param = (XMLElement) httpChilds.nextElement();
			httpConfig = (HTTPAdv) AdvertisementFactory.newAdvertisement(param);
		} else {
			// FIXME: Why should we not allow a platform config without a HTTP
			// advertisement?
			// throw new IllegalStateException("Missing HTTP Advertisement");
		}

		// Rendezvous configuration advertisement
		param = (XMLElement) platformConfigInput.getServiceParam(PeerGroup.rendezvousClassID);
		// backwards compatibility
		param.addAttribute("type", RdvConfigAdv.getAdvertisementType());
		rdvConfigEnabled = isEnabled(param);
		rdvConfig = (RdvConfigAdv) AdvertisementFactory.newAdvertisement(param);

		// Relay configuration advertisement
		param = (XMLElement) platformConfigInput.getServiceParam(PeerGroup.relayProtoClassID);
		// backwards compatibility
		param.addAttribute("type", RelayConfigAdv.getAdvertisementType());
		relayConfigEnabled = isEnabled(param);
		relayConfig = (RelayConfigAdv) AdvertisementFactory.newAdvertisement(param);

		// PSE configuration advertisement
		pseConfig = null;
		param = (XMLElement) platformConfigInput.getServiceParam(PeerGroup.membershipClassID);
		if (param != null) {
			Advertisement adv = null;
			try {
				adv = AdvertisementFactory.newAdvertisement(param);
			} catch (NoSuchElementException notAnAdv) {
				CertificateException cnfe = new CertificateException("No membership advertisement found");
				cnfe.initCause(notAnAdv);
			} catch (IllegalArgumentException invalidAdv) {
				CertificateException cnfe = new CertificateException("Invalid membership advertisement");
				cnfe.initCause(invalidAdv);
			}
			if (adv instanceof PSEConfigAdv) {
				pseConfig = (PSEConfigAdv) adv;
			} else {
				// FIXME: It would be nice if we didn't need to declare any
				// exception in this method. As of now, the PSE advertisement is
				// just ignored if it can't be loaded.
				// throw new CertificateException("Unexpected membership
				// advertisement " + adv.getAdvertisementType());
			}
		}

		// Proxy configuration advertisement
		proxyConfig = (XMLDocument) platformConfigInput.getServiceParam(PeerGroup.proxyClassID);
		proxyConfigEnabled = isEnabled(proxyConfig);
		// Make sure to have no null values
		reset(
				peerConfig,
				tcpConfig,
				tcpConfigEnabled,
				httpConfig,
				httpConfigEnabled,
				rdvConfig,
				rdvConfigEnabled,
				relayConfig,
				relayConfigEnabled,
				proxyConfig,
				proxyConfigEnabled,
				pseConfig);
	}

	/**
	 * Generates a PlatformConfig (with {@link #getPlatformConfig()}) and saves
	 * it in the file given by parameter <code>file</code>.
	 * 
	 * @param file
	 *            the file the PlatfromConfig should be saved to.
	 * @see #getPlatformConfig()
	 * @see #load(URI)
	 * @exception IOException
	 *                If the file could not be saved to the given file (This
	 *                also happens if the the path does not yet exist).
	 */
	public void save(File file) throws IOException {
		FileOutputStream out = null;
		out = new FileOutputStream(file);
		savePlatformConfig(out);

		isDirty = false;
	}

	/**
	 * Persists a PlatformConfig advertisement under getHome()+"/PlaformConfig"
	 * <p/> Home may be overridden by a call to setHome()
	 * 
	 * @see #load
	 * @exception IOException
	 *                if an i/o error occurs
	 * @deprecated use {@link #save(File)} instead.
	 */
	public void save() throws IOException {
		save(getPlatfromConfigFile());
	}

	/**
	 * 
	 * 
	 * @param file
	 *            the file the PlatfromConfig should be saved to.
	 * @see #getPlatformConfig()
	 * @see #load(URI)
	 * @exception IOException
	 *                If the file could not be saved to the given file (This
	 *                also happens if the the path does not yet exist).
	 */
	/**
	 * Generates a PlatformConfig (with {@link #getPlatformConfig()}) and
	 * streams it to the given output stream. UTF-8 is used for the encoding.
	 * 
	 * @param out
	 *            the output stream to stream the platform config file to.
	 * @throws IOException
	 */
	public void savePlatformConfig(OutputStream out) throws IOException {
		ConfigParams advertisement = getPlatformConfig();
		XMLDocument aDoc = (XMLDocument) advertisement.getDocument(MimeMediaType.XMLUTF8);
		OutputStreamWriter os = new OutputStreamWriter(out, "UTF-8");
		aDoc.sendToWriter(os);
		os.flush();
		if (null != out) {
			out.close();
		}
	}

	/**
	 * Returns the PlatformConfig (as <code>ConfigParams</code>) that can be
	 * used in one of the {@link NetPeerGroupFactory} constructors.
	 * 
	 * 
	 * 
	 * @return a configuration for the JXTA network infrastructure.
	 */
	public ConfigParams getPlatformConfig() {
		PlatformConfig result = (PlatformConfig) AdvertisementFactory.newAdvertisement(PlatformConfig
				.getAdvertisementType());

		result.setPeerID(peerConfig.getPeerID());
		result.setName(peerConfig.getName());
		result.setDescription(peerConfig.getDescription());
		result.setDebugLevel(peerConfig.getDebugLevel());

		result.putServiceParam(PeerGroup.tcpProtoClassID, getParmDoc(isTcpEnabled(), tcpConfig));
		result.putServiceParam(PeerGroup.httpProtoClassID, getParmDoc(isHttpEnabled(), httpConfig));
		result.putServiceParam(PeerGroup.proxyClassID, getParmDoc(isProxyEnabled(), proxyConfig));

		XMLDocument rdvDoc = (XMLDocument) rdvConfig.getDocument(MimeMediaType.XMLUTF8);
		result.putServiceParam(PeerGroup.rendezvousClassID, getParmDoc(isRendezvousEnabled(), rdvDoc));

		XMLDocument relayDoc = (XMLDocument) relayConfig.getDocument(MimeMediaType.XMLUTF8);
		result.putServiceParam(PeerGroup.relayProtoClassID, getParmDoc(isRelayEnabled(), relayDoc));

		// PSE configuration advertisement
		/*
		 * Creates Personal Security Environment Config Advertisement <p/>The
		 * configuration advertisement can include an optional seed certificate
		 * chain and encrypted private key. If this seed information is present
		 * the PSE Membership Service will require an initial authentication to
		 * unlock the encrypted private key before creating the PSE keystore.
		 * The newly created PSE keystore will be "seeded" with the certificate
		 * chain and the private key.
		 */
		if (principal != null && password != null) {
			/*
			 * Create a new certificate only if password or principal are set.
			 * Not that loading the PlatformConfig from a file does not set
			 * principal and password
			 */
			PSEConfigAdv localPSEConfigAdv = (PSEConfigAdv) AdvertisementFactory.newAdvertisement(PSEConfigAdv
					.getAdvertisementType());
			IssuerInfo info = PSEUtils.genCert(principal, null);
			localPSEConfigAdv.setCertificate(info.cert);
			localPSEConfigAdv.setPrivateKey(info.subjectPkey, password.toCharArray());
			XMLDocument pseDoc = (XMLDocument) localPSEConfigAdv.getDocument(MimeMediaType.XMLUTF8);
			result.putServiceParam(PeerGroup.membershipClassID, pseDoc);
		} else if (pseConfig != null) {
			/*
			 * This is only called if the PlatfromConfig has been loaded from a
			 * file. It makes sure that the certificate is not regenerated.
			 */
			XMLDocument pseDoc = (XMLDocument) pseConfig.getDocument(MimeMediaType.XMLUTF8);
			result.putServiceParam(PeerGroup.membershipClassID, pseDoc);
		}

		return result;
	}

	/**
	 * Returns a StructuredDocument representation of an Advertisement
	 * 
	 * @param enabled
	 *            whether the param doc is enabled, adds a "isOff" element if
	 *            disabled
	 * @param adv
	 *            the Advertisement to retrieve the param doc from
	 * @return the parmDoc value
	 */
	private static StructuredDocument getParmDoc(boolean enabled, Advertisement adv) {
		StructuredDocument parmDoc = StructuredDocumentFactory.newStructuredDocument(MimeMediaType.XMLUTF8, "Parm");
		StructuredDocument doc = (StructuredDocument) adv.getDocument(MimeMediaType.XMLUTF8);
		StructuredDocumentUtils.copyElements(parmDoc, parmDoc, doc);
		if (!enabled) {
			parmDoc.appendChild(parmDoc.createElement("isOff"));
		}
		return parmDoc;
	}

	private static StructuredDocument getParmDoc(boolean enable, XMLDocument param) {
		if (!enable && !param.getChildren("isOff").hasMoreElements()) {
			param.appendChild(param.createElement("isOff"));
		}
		return param;
	}

	private static boolean isEnabled(XMLElement param) {
		if (param == null) {
			return false;
		}
		return param.getChildren("isOff").hasMoreElements() ? false : true;
	}

	/**
	 * Loads a PlatformConfig file from the given file location.
	 * 
	 * @param uri
	 *            the URI to PlatformConfig file
	 * @return a ConfigParams instance containing the PlatfromConfig file
	 *         configurations.
	 * @throws IOException
	 *             If the PlatformConfig file could not be loaded
	 * @throws IllegalArgumentException
	 *             if the URI is <code>null</code>. As of now it also throws
	 *             an exception if the URI can't be transformed into an URL. But
	 *             this is probably stupid (FIXME)
	 * 
	 */
	private static ConfigParams loadPlatfromConfigFromURI(URI uri) throws IOException {
		if (uri == null) {
			throw new IllegalArgumentException("URI can not be null");
		}
		if (LOG.isEnabledFor(Level.DEBUG)) {
			LOG.debug("Loading PlatformConfig from : " + uri.toString());
		}

		URL url = null;
		try {
			url = uri.toURL();
		} catch (MalformedURLException mue) {
			throw new IllegalArgumentException("Failed to convert URI to URL", mue);
		}

		InputStream input = url.openStream();
		try {
			XMLDocument document = (XMLDocument) StructuredDocumentFactory.newStructuredDocument(
					MimeMediaType.XMLUTF8,
					input);
			return (ConfigParams) AdvertisementFactory.newAdvertisement(document);
		} finally {
			input.close();
		}
	}

	private File getPlatfromConfigFile() {
		return new File(getHome(), "PlatformConfig");
	}

	// Bean support below
	/**
	 * Adds a PropertyChangeListener to the listener list. The listener is
	 * registered for all bound properties of this class.
	 * <p>
	 * 
	 * If listener is <code>null</code>, no exception is thrown and no action
	 * is performed.
	 * 
	 * @param listener
	 *            the PropertyChangeListener to be added
	 */
	public final synchronized void addPropertyChangeListener(PropertyChangeListener listener) {
		if (listener == null || propertyChangeSupport == null) {
			return;
		}

		propertyChangeSupport.addPropertyChangeListener(listener);
	}

	/**
	 * Removes a PropertyChangeListener from the listener list. This method
	 * should be used to remove PropertyChangeListeners that were registered for
	 * all bound properties of this class.
	 * <p>
	 * 
	 * If listener is <code>null</code>, no exception is thrown and no action
	 * is performed.
	 * 
	 * @param listener
	 *            the PropertyChangeListener to be removed
	 */
	public final synchronized void removePropertyChangeListener(PropertyChangeListener listener) {
		if (listener == null || propertyChangeSupport == null) {
			return;
		}
		propertyChangeSupport.removePropertyChangeListener(listener);
	}

	/**
	 * Adds a PropertyChangeListener to the listener list for a specific
	 * property. The specified property may be user-defined.
	 * <p>
	 * 
	 * @param propertyName
	 *            one of the property names listed above
	 * @param listener
	 *            the PropertyChangeListener to be added
	 * 
	 */
	public final synchronized void addPropertyChangeListener(String propertyName, PropertyChangeListener listener) {
		if (listener == null || propertyChangeSupport == null) {
			return;
		}

		propertyChangeSupport.addPropertyChangeListener(propertyName, listener);
	}

	/**
	 * Removes a PropertyChangeListener from the listener list. This method
	 * should be used to remove PropertyChangeListeners that were registered for
	 * all bound properties of this class.
	 * <p>
	 * 
	 * If listener is <code>null</code>, no exception is thrown and no action
	 * is performed.
	 * 
	 * @param propertyName
	 *            a valid property name
	 * @param listener
	 *            the PropertyChangeListener to be removed
	 */
	public final synchronized void removePropertyChangeListener(String propertyName, PropertyChangeListener listener) {
		if (listener == null || propertyChangeSupport == null) {
			return;
		}
		propertyChangeSupport.removePropertyChangeListener(propertyName, listener);
	}

	/**
	 * Returns a boolean value indicating whether one or more values (fields)
	 * have been changed since either loading or the last save.
	 * 
	 * @return True, if there are changes, otherwise false.
	 */
	public boolean hasChanges() {
		return isDirty;
	}

}
