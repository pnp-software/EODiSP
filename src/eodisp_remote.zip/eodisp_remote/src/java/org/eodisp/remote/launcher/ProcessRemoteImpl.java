/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.remote.launcher;

import java.io.IOException;
import java.rmi.RemoteException;

import org.apache.log4j.Logger;
import org.eodisp.util.launcher.Process;
import org.eodisp.util.launcher.ProcessListener;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class ProcessRemoteImpl implements ProcessRemote {
	public static final class ProcessListenerRemoteImpl implements ProcessListener {
		private final ProcessListenerRemote remote;

		public ProcessListenerRemoteImpl(ProcessListenerRemote remote) {
			this.remote = remote;
		}

		public void processStarted() {
			try {
				remote.processStarted();
			} catch (RemoteException e) {
				logger.error(e);
			}
		}

		public void processTerminated(int exitCode) {
			try {
				remote.processTerminated(exitCode);
			} catch (RemoteException e) {
				logger.error(e);
			}
		}
	}

	private Process process;

	public ProcessRemoteImpl(Process process) {
		this.process = process;
	}

	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	static Logger logger = Logger.getLogger(ProcessRemoteImpl.class);

	/**
	 * @param processListener
	 * @see org.eodisp.util.launcher.Process#addListener(org.eodisp.util.launcher.ProcessListener)
	 */
	public void addListener(ProcessListener processListener) {
		process.addListener(processListener);
	}


	/** 
	 * {@inheritDoc}
	 */
	public boolean kill(long timeoutInMillis) {
		return process.kill(timeoutInMillis);
	}

	/**
	 * @throws IOException
	 * @see org.eodisp.util.launcher.Process#launch()
	 */
	public void launch() throws IOException {
		process.launch();
	}

	public void addListener(final ProcessListenerRemote processListenerRemote) throws RemoteException {
		process.addListener(new ProcessListenerRemoteImpl(processListenerRemote));
	}

}
