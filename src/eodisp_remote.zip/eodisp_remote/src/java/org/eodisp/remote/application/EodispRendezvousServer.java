/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.remote.application;

import java.io.File;
import java.util.EnumSet;
import java.util.Enumeration;

import net.jxta.discovery.DiscoveryEvent;
import net.jxta.discovery.DiscoveryListener;
import net.jxta.discovery.DiscoveryService;
import net.jxta.peer.PeerID;
import net.jxta.peergroup.PeerGroup;
import net.jxta.rendezvous.RendezVousService;
import net.jxta.rendezvous.RendezvousEvent;
import net.jxta.rendezvous.RendezvousListener;

import org.eodisp.remote.config.RemoteConfiguration.TransportType;
import org.eodisp.remote.util.JXTAUtil;
import org.eodisp.remote.util.NetworkConfigurator;
import org.eodisp.util.AppModule;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.RootApp;

/**
 * A simple rendezvous server for the EODiSP simulation platform. The rendezvous
 * server listens per default on port 14301.
 * 
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class EodispRendezvousServer extends RootApp {
	public static final String APP_NAME = "EODiSP RENDEZVOUS SERVER";
	public static final String APP_DESCRIPTION = "EODiSP RENDEZVOUS SERVER";

	private static final int DEFAULT_JXTA_TCP_PORT = 14301;
	private static final int DEFAULT_JXTA_HTTP_PORT = 80;

	public static final File DEFAULT_WORKING_DIR = new File(
			new File(System.getProperty("user.home"), ".eodisp"),
			"rdv-server");

	private RemoteAppModule remoteAppModule;

	public EodispRendezvousServer() {
		super(APP_NAME, APP_DESCRIPTION, DEFAULT_WORKING_DIR, EodispRendezvousServer.class);

		remoteAppModule = new RemoteAppModule(0) {
			
			@Override
			protected NetworkConfigurator newDefaultJxtaConfiguration() {
				NetworkConfigurator defaultJxtaConfiguration = NetworkConfigurator.newNetworkConfiguratorEdge();
				defaultJxtaConfiguration.setHttpPort(DEFAULT_JXTA_HTTP_PORT);
				defaultJxtaConfiguration.setTcpPort(DEFAULT_JXTA_TCP_PORT);
				defaultJxtaConfiguration.setTcpStartPort(-1);
				defaultJxtaConfiguration.setTcpEndPort(-1);
				return defaultJxtaConfiguration;
			}
		};

		registerAppModule(remoteAppModule);
	}

	/**
	 * @param args
	 * @throws InterruptedException
	 */
	public static void main(String[] args) {
		new EodispRendezvousServer().execute(args);
		synchronized (EodispRendezvousServer.class) {
			while (true) {
				try {
					EodispRendezvousServer.class.wait();
				} catch (InterruptedException e) {
					Thread.interrupted();
				}
			}
		}
	}
}
