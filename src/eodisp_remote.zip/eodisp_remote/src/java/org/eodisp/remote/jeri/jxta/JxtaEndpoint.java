/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com
 *  mail: info@pnp-software.com
 */

package org.eodisp.remote.jeri.jxta;

import java.io.*;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketTimeoutException;
import java.nio.channels.SocketChannel;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.jini.core.constraint.InvocationConstraints;
import net.jini.io.UnsupportedConstraintException;
import net.jini.jeri.Endpoint;
import net.jini.jeri.OutboundRequest;
import net.jini.jeri.OutboundRequestIterator;
import net.jini.jeri.connection.Connection;
import net.jini.jeri.connection.ConnectionEndpoint;
import net.jini.jeri.connection.OutboundRequestHandle;
import net.jini.security.proxytrust.TrustEquivalence;
import net.jxta.peer.PeerID;
import net.jxta.socket.JxtaSocket;
import net.jxta.socket.JxtaSocketAddress;

import org.eodisp.remote.jeri.connection.fastmux.ConnectionManagerFastMux;

import com.sun.jini.logging.Levels;
import com.sun.jini.logging.LogUtil;

/**
 * An implementation of the {@link Endpoint} abstraction that uses JXTA sockets
 * (instances of {@link net.jxta.socket.JxtaSocket}) for the underlying
 * communication mechanism.
 * 
 * <p>
 * Most of the implementation was copied from the the
 * {@link net.jini.jeri.tcp.TcpEndpoint} class.
 * 
 * <p>
 * All <code>TcpEndpoint</code> instances in the same JVM use the same peer
 * and peer group advertisement. This information is statically received from
 * {@link org.eodisp.remote.jeri.jxta.JxtaNetwork}.
 * 
 * <p>
 * <code>JxtaEndpoint</code> uses the <a
 * href="../connection/doc-files/mux.html">Jini(TM) extensible remote invocation
 * (Jini ERI) multiplexing protocol</a> to map incoming requests to socket
 * connections.
 * 
 * 
 * @author ibirrer
 * @see org.eodisp.remote.jeri.jxta.JxtaServerEndpoint
 */
public final class JxtaEndpoint implements Endpoint, TrustEquivalence, Serializable {

	private static final long serialVersionUID = -2023617609849456103L;

	/**
	 * weak set of canonical instances; in order to use WeakHashMap, maps
	 * canonical instances to weak references to themselves
	 */
	private static final Map<JxtaEndpoint, WeakReference> internTable = new WeakHashMap<JxtaEndpoint, WeakReference>();

	/** client transport logger */
	private static final Logger logger = Logger.getLogger("net.jini.jeri.jxta.client");

	/**
	 * The id of the peer this JXTA endpoint connects to
	 */
	private PeerID peerID;

	private transient ConnectionManagerFastMux connectionManager;

	/**
	 * Returns a <code>JxtaEndpoint</code> instance for the given peer id.
	 * 
	 * @param peerID
	 *            the peer id for the endpoint to connect to.
	 * @return a <code>JxtaEndpoint</code> instance
	 */
	public static JxtaEndpoint getInstance(PeerID peerID) {
		return intern(new JxtaEndpoint(peerID));
	}

	/**
	 * Returns canonical instance equivalent to given instance.
	 */
	private static JxtaEndpoint intern(JxtaEndpoint endpoint) {
		synchronized (internTable) {
			Reference ref = internTable.get(endpoint);
			if (ref != null) {
				JxtaEndpoint canonical = (JxtaEndpoint) ref.get();
				if (canonical != null) {
					return canonical;
				}
			}
			endpoint.connectionManager = new ConnectionManagerFastMux(endpoint.new ConnectionEndpointImpl());
			internTable.put(endpoint, new WeakReference<JxtaEndpoint>(endpoint));
			return endpoint;
		}
	}

	/**
	 * Constructs a new instance.
	 * 
	 * @see #getInstance(PeerID)
	 */
	private JxtaEndpoint(PeerID peerID) {
		this.peerID = peerID;
	}

	/*
	 * [This is not a doc comment to prevent its appearance in TcpEndpoint's
	 * serialized form specification.]
	 * 
	 * Resolves deserialized instance to equivalent canonical instance.
	 */
	private Object readResolve() {
		return intern(this);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * <p>
	 * The returned <code>OutboundRequestIterator</code>'s {@link
	 * OutboundRequestIterator#next next} method behaves as follows:
	 * 
	 * <blockquote>
	 * 
	 * Initiates an attempt to communicate the request to this remote endpoint.
	 * 
	 * 
	 * <p>
	 * When the implementation needs to connect a <code>Socket</code> it
	 * connects to it by using this endpoint's peer id and the peer group and
	 * pipe advertisements given by {@link JxtaNetwork#getJeriPeerGroup()} and
	 * {@link JxtaNetwork#getJeriPipeAdvertisement()}.
	 * 
	 * 
	 * <p>
	 * Throws {@link NoSuchElementException} if this iterator does not support
	 * making another attempt to communicate the request (that is, if
	 * <code>hasNext</code> would return <code>false</code>).
	 * 
	 * <p>
	 * Throws {@link IOException} if an I/O exception occurs while performing
	 * this operation, such as if a connection attempt timed out or was refused.
	 * 
	 * 
	 * </blockquote>
	 * 
	 * @throws NullPointerException
	 *             {@inheritDoc}
	 */
	public OutboundRequestIterator newRequest(final InvocationConstraints constraints) {
		if (constraints == null) {
			throw new NullPointerException();
		}

		try {
			Constraints.Distilled distilled = Constraints.distill(constraints, false);
			return connectionManager.newRequest(new Handle(distilled));

		} catch (final UnsupportedConstraintException e) {
			return new OutboundRequestIterator() {
				private boolean nextCalled = false;

				public boolean hasNext() {
					return !nextCalled;
				}

				public OutboundRequest next() throws IOException {
					if (!hasNext()) {
						throw new NoSuchElementException();
					}
					nextCalled = true;
					e.fillInStackTrace(); // REMIND: is this cool?
					throw e;
				}
			};
		}
	}

	/**
	 * Returns the hash code value for this <code>JxtaEndpoint</code>.
	 * 
	 * @return the hash code value for this <code>JxtaEndpoint</code>
	 */
	@Override
	public int hashCode() {
		return peerID.hashCode();
	}

	/**
	 * Compares the specified object with this <code>JxtaEndpoint</code> for
	 * equality.
	 * 
	 * <p>
	 * This method returns <code>true</code> if and only if
	 * 
	 * <ul>
	 * <li>the specified object is also a <code>JxtaEndpoint</code>,
	 * 
	 * <li>the peer id in the specified object are equal to the peer id in this
	 * object
	 * 
	 * </ul>
	 * 
	 * @param obj
	 *            the object to compare with
	 * 
	 * @return <code>true</code> if <code>obj</code> is equivalent to this
	 *         object; <code>false</code> otherwise
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj == this) {
			return true;
		} else if (!(obj instanceof JxtaEndpoint)) {
			return false;
		}
		JxtaEndpoint other = (JxtaEndpoint) obj;
		return peerID.equals(other.peerID);
	}

	/**
	 * Returns <code>this.equals(obj)</code>.
	 * 
	 * @return <code>this.equals(obj)</code>
	 */
	public boolean checkTrustEquivalence(Object obj) {
		return equals(obj);
	}

	/**
	 * Returns a string representation of this <code>JxtaEndpoint</code>.
	 * 
	 * @return a string representation of this <code>JxtaEndpoint</code>
	 */
	@Override
	public String toString() {
		return "JxtaEndpoint[" + peerID + "]";
	}

	/**
	 * @throws InvalidObjectException
	 *             if the host name is <code>null</code> or if the port number
	 *             is out of the range <code>1</code> to <code>65535</code>
	 *             (inclusive)
	 */
	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		in.defaultReadObject();
		// TODO: throw InvalidObjectException if the peerID is not a peer id.
	}

	/**
	 * OutboundRequestHandle implementation.
	 */
	private class Handle implements OutboundRequestHandle {

		private final Constraints.Distilled distilled;

		Handle(Constraints.Distilled distilled) {
			this.distilled = distilled;
		}

		Constraints.Distilled getDistilledConstraints() {
			return distilled;
		}

		InvocationConstraints getUnfulfilledConstraints() {
			return distilled.getUnfulfilledConstraints();
		}
	}

	/**
	 * ConnectionEndpoint implementation.
	 * 
	 * Instances of this class should never get exposed to anything other than
	 * our ConnectionManager, which we trust to operate correctly, so we do not
	 * bother to validate request handles and connections passed in.
	 */
	private class ConnectionEndpointImpl implements ConnectionEndpoint {

		ConnectionEndpointImpl() {
		}

		/**
		 * Invoked by ConnectionManager to create a new connection.
		 */
		public Connection connect(OutboundRequestHandle handle) throws IOException {
			Handle h = (Handle) handle;
			Constraints.Distilled distilled = h.getDistilledConstraints();

			Socket socket = connectToHost(distilled);

			if (logger.isLoggable(Level.FINE)) {
				logger.log(Level.FINE, "connected socket {0}", socket);
			}

			return new ConnectionImpl(socket);
		}

		/**
		 * Returns a socket connected to this endpoint's peer id, according the
		 * specified constraints.
		 */
		private Socket connectToHost(Constraints.Distilled distilled) throws IOException {
			JxtaSocketAddress jxtaSocketAddress = new JxtaSocketAddress(JxtaNetwork.getJeriPeerGroup(), JxtaNetwork
					.getJeriPipeAdvertisement(), peerID);
			return connectToSocketAddress(jxtaSocketAddress, distilled);
		}

		/**
		 * Returns a socket connected to the specified address, with a timeout
		 * governed by the specified constraints.
		 * 
		 * <p>
		 * There's no way to set invocation constraints for the DGCClient proxy.
		 * The DGCClient proxy tries to reach it's server already at the time
		 * when the BasicObjectEndpoint is created. If the server is not
		 * reachable it stops there forever if the timeout is set to 0. This is
		 * why we should not set the default timeout to 0 as it is with the
		 * TCPEndpoint implementation, but set it to a value greater than cero.
		 */
		private Socket connectToSocketAddress(SocketAddress socketAddress, Constraints.Distilled distilled)
				throws IOException {
			int timeout;
			if (distilled.hasConnectDeadline()) {
				long now = System.currentTimeMillis();
				long deadline = distilled.getConnectDeadline();
				if (deadline <= now) {
					throw new SocketTimeoutException("deadline past before connect attempt");
				}
				assert now > 0; // if not, we could overflow
				long delta = deadline - now;
				// assume that no socket connect will last over 24 days
				timeout = (delta > Integer.MAX_VALUE ? 0 : (int) delta);
			} else {
				timeout = 0;
			}

			Socket socket = newSocket();
			boolean ok = false;
			try {
				// This sync is needed. Probably a bug in the JXTA socket
				// implementation

				synchronized (this) {
					if (logger.isLoggable(Level.FINEST)) {
						logger.log(Level.FINEST, ("Trying to connect to socket {0} with a timeout of {1}ms"), new Object[] { socket,
								Integer.valueOf(timeout) });
					}
					socket.connect(socketAddress, timeout);
				}

				logger.log(Level.FINE, ("connected socket {0}"), new Object[] { socket });
				ok = true;
				return socket;
			} finally {
				if (!ok) {
					// TODO: Closing a socket can take very loing with JXTA. So
					// we just don't do it for now.
					// try {
					// socket.close();
					// } catch (IOException e) {
					// }
				}
			}
		}

		/**
		 * Returns a new unconnected socket
		 */
		private Socket newSocket() throws IOException {
			JxtaSocket socket = new JxtaSocket();
			socket.setOutputStreamBufferSize(65536);
			// Set reliable mode
			socket.create(true);
			if (logger.isLoggable(Level.FINE)) {
				logger.log(Level.FINE, ("created socket {0}"), new Object[] { socket });
			}
			return socket;
		}

		/**
		 * Invoked by ConnectionManager to reuse an existing connection.
		 */
		public Connection connect(OutboundRequestHandle handle, Collection active, Collection idle) {
			if (active == null || idle == null) {
				throw new NullPointerException();
			}

			/*
			 * The transport level aspects of all constraints supported by this
			 * transport provider are always satisfied by all open connections,
			 * so we don't need to consider constraints here.
			 */
			boolean checkedResolvePermission = false;
			for (Iterator i = active.iterator(); i.hasNext();) {
				ConnectionImpl c = (ConnectionImpl) i.next();
				if (!checkedResolvePermission) {
					try {
						checkResolvePermission();
					} catch (SecurityException e) {
						if (logger.isLoggable(Levels.FAILED)) {
							LogUtil.logThrow(
									logger,
									Levels.FAILED,
									ConnectionEndpointImpl.class,
									"connect",
									"exception resolving peer {0}",
									new Object[] { peerID },
									e);
						}
						throw e;
					}
					checkedResolvePermission = true;
				}
				try {
					c.checkConnectPermission();
					if (logger.isLoggable(Level.FINE)) {
						logger.log(Level.FINE, "reusing connection {0}", c.getSocket());
					}
					return c;
				} catch (SecurityException e) {
					if (logger.isLoggable(Levels.HANDLED)) {
						LogUtil.logThrow(
								logger,
								Levels.HANDLED,
								ConnectionEndpointImpl.class,
								"connect",
								"access to reuse connection {0} denied",
								new Object[] { c.getSocket() },
								e);
					}
				}
			}
			for (Iterator i = idle.iterator(); i.hasNext();) {
				ConnectionImpl c = (ConnectionImpl) i.next();
				if (!checkedResolvePermission) {
					try {
						checkResolvePermission();
					} catch (SecurityException e) {
						if (logger.isLoggable(Levels.FAILED)) {
							LogUtil.logThrow(
									logger,
									Levels.FAILED,
									ConnectionEndpointImpl.class,
									"connect",
									"exception resolving peer {0}",
									new Object[] { peerID },
									e);
						}
						throw e;
					}
					checkedResolvePermission = true;
				}
				try {
					c.checkConnectPermission();
					if (logger.isLoggable(Level.FINE)) {
						logger.log(Level.FINE, "reusing connection {0}", c.getSocket());
					}
					return c;
				} catch (SecurityException e) {
					if (logger.isLoggable(Levels.HANDLED)) {
						LogUtil.logThrow(
								logger,
								Levels.HANDLED,
								ConnectionEndpointImpl.class,
								"connect",
								"access to reuse connection {0} denied",
								new Object[] { c.getSocket() },
								e);
					}
				}
			}
			return null;
		}

		private void checkResolvePermission() {
		}
	}

	/**
	 * Connection implementation.
	 * 
	 * Instances of this class should never get exposed to anything other than
	 * our ConnectionManager, which we trust to operate correctly, so we do not
	 * bother to validate request handles passed in.
	 */
	private static class ConnectionImpl implements Connection {

		private final Socket socket;

		ConnectionImpl(Socket socket) {
			this.socket = socket;
		}

		Socket getSocket() {
			return socket;
		}

		public InputStream getInputStream() throws IOException {
			return  socket.getInputStream();
		}

		public OutputStream getOutputStream() throws IOException {
			return socket.getOutputStream(); //new LoggedOutputStream( socket.getOutputStream() );
		}

		/**
		 * Always returns null as JXTA sockets do not support channels
		 */
		public SocketChannel getChannel() {
			return null;
		}

		public void populateContext(OutboundRequestHandle handle, Collection context) {
			if (context == null) {
				throw new NullPointerException();
			}
		}

		public InvocationConstraints getUnfulfilledConstraints(OutboundRequestHandle handle) {
			Handle h = (Handle) handle;
			return h.getUnfulfilledConstraints();
		}

		public void writeRequestData(OutboundRequestHandle handle, OutputStream out) {
			if (out == null) {
				throw new NullPointerException();
			}
		}

		public IOException readResponseData(OutboundRequestHandle handle, InputStream in) {
			if (in == null) {
				throw new NullPointerException();
			}
			return null;
		}

		public void close() {
			try {
				socket.close();
			} catch (Exception e) {
				if (logger.isLoggable(Level.FINEST)) {
					logger.log(Level.FINE, "Exception while closing Jxta socket {0}", socket);
				}
			}

			if (logger.isLoggable(Level.FINE)) {
				logger.log(Level.FINE, "closed socket {0}", socket);
			}
		}

		void checkConnectPermission() {
		}
	}
}
