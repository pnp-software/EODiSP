/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.remote.launcher.server;

import java.io.IOException;
import java.util.*;

import net.jxta.discovery.DiscoveryEvent;
import net.jxta.discovery.DiscoveryListener;
import net.jxta.discovery.DiscoveryService;
import net.jxta.document.Advertisement;
import net.jxta.protocol.PeerAdvertisement;
import net.jxta.protocol.RouteAdvertisement;

import org.apache.log4j.Logger;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public final class LaunchServerDiscovery {

	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	static Logger logger = Logger.getLogger(LaunchServerDiscovery.class);

	private LaunchServerDiscovery() {
	}

	public static PeerAdvertisement[] discoverLaunchServers(long timeout, DiscoveryService discoveryService) {
		final Set<PeerAdvertisement> peerAdvs = Collections.synchronizedSet(new HashSet<PeerAdvertisement>());

		// Flushing all local peer advertisements first:
		try {
			Enumeration en = discoveryService.getLocalAdvertisements(DiscoveryService.PEER, null, null);
			while (en.hasMoreElements()) {
				discoveryService.flushAdvertisement((Advertisement) en.nextElement());
			}
		} catch (IOException io) {
			io.printStackTrace();
		}
		DiscoveryListener eodispDiscoveryListener = new DiscoveryListener() {
			public void discoveryEvent(DiscoveryEvent event) {
				logger.debug(String.format("Got event from discovery service: %s", event));

				Enumeration enumeration = event.getSearchResults();
				while (enumeration.hasMoreElements()) {

					Advertisement adv = (Advertisement) enumeration.nextElement();
					if (adv.getAdvType().equals(RouteAdvertisement.getAdvertisementType())) {
						RouteAdvertisement routeAdvertisement = (RouteAdvertisement) adv;
						logger.debug(String.format("Discovered Route Advertisement for peer: %s", routeAdvertisement
								.getDestPeerID()));
					} else {
						logger.debug(String.format("Discovered Advertisement: %s", adv.getAdvType()));
					}
					// logger.debug(String.format("Discovered Peer: %s",
					// adv.getName()));
					// peerAdvs.add(adv);
				}
			}
		};
		
		

		
		discoveryService.addDiscoveryListener(eodispDiscoveryListener);
		boolean test = true;
		while(test) {
			System.out.println("Send new request...");
			discoveryService.getRemoteAdvertisements(null, DiscoveryService.ADV, null, null, 5);
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		try {
			logger.debug("Wait for discovery messages ...");
			Thread.sleep(timeout);
		} catch (InterruptedException e) {
			logger.warn(e);
		} finally {
			if (!discoveryService.removeDiscoveryListener(eodispDiscoveryListener)) {
				logger.warn("Could not remove listener from discovery service");
			}
		}

		PeerAdvertisement[] result = peerAdvs.toArray(new PeerAdvertisement[0]);
		return result;
	}
}
