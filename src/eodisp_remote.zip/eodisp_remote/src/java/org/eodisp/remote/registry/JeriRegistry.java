package org.eodisp.remote.registry;

import java.net.URI;
import java.rmi.*;
import java.rmi.registry.Registry;
import java.util.Map;

import net.jini.id.Uuid;
import net.jini.id.UuidFactory;

import org.eodisp.remote.config.RemoteConfiguration.TransportType;

public interface JeriRegistry extends Registry {

	public static final Uuid REGISTRY_UUID = UuidFactory.create("3d37a612-c73d-4284-9097-85ea4a905dde");

	public abstract Remote lookup(String name, TransportType transportType) throws NotBoundException, RemoteException;

	public abstract void bind(String name, Remote obj, TransportType transportType) throws AlreadyBoundException, RemoteException;

	public abstract void rebind(String name, Map<TransportType, Remote> proxies) throws RemoteException;

	public abstract void rebind(String name, Remote obj, TransportType transportType) throws RemoteException;
	
	public abstract URI getUri(TransportType transportType) throws RemoteException;

}