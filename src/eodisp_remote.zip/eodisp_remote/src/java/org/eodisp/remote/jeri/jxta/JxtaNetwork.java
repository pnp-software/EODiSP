/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com
 *  mail: info@pnp-software.com
 */
package org.eodisp.remote.jeri.jxta;

import java.util.logging.Level;
import java.util.logging.Logger;

import net.jxta.document.AdvertisementFactory;
import net.jxta.impl.id.binaryID.DigestTool;
import net.jxta.impl.id.binaryID.PipeBinaryID;
import net.jxta.peergroup.PeerGroup;
import net.jxta.pipe.PipeService;
import net.jxta.protocol.PipeAdvertisement;

/**
 * Static configuration of the JXTA transport layer for Jeri. Before the JXTA
 * transport can work this class' {@link #registerJeriPeerGroup(PeerGroup)} must
 * be invoked to register the JXTA peer group that shall be used to do the
 * communication upon.
 * 
 * @author ibirrer
 * @version $Id:$
 */
public class JxtaNetwork {

	/** JXTA transport logger */
	private static final Logger logger = Logger.getLogger("net.jini.jeri.jxta");

	private static PeerGroup jeriPeerGroup;

	private static PipeAdvertisement cachedJeriPipeAdvertisement;

	/**
	 * Registers the JXTA peer group that is used in the JXTA transport layer
	 * for Jeri.
	 * 
	 * @param peerGroup
	 *            the peer group that is used for communication on the JXTA
	 *            layer.
	 * 
	 * @throws AssertionError
	 *             if the peer group has been registered already
	 */
	public static void registerJeriPeerGroup(PeerGroup peerGroup) {
		assert (JxtaNetwork.jeriPeerGroup == null);
		JxtaNetwork.jeriPeerGroup = peerGroup;
	}

	/**
	 * Returns the peer group that has been registered with the
	 * {@link #registerJeriPeerGroup(PeerGroup)} method.
	 * 
	 * @return the peer group that has been registered with the
	 *         {@link #registerJeriPeerGroup(PeerGroup)} method.
	 */
	static PeerGroup getJeriPeerGroup() {
		if (jeriPeerGroup == null) {
			if (logger.isLoggable(Level.SEVERE)) {
				logger.log(
						Level.SEVERE,
						"NetPeerGroup has not been registered with JxtaNetwork.registerNetPeerGroup(...)");
				Thread.dumpStack();
			}
		}
		return jeriPeerGroup;
	}

	/**
	 * Returns the pipe advertisement of the Jeri pipe.
	 * 
	 * @return the pipe advertisement of the Jeri pipe.
	 */
	static PipeAdvertisement getJeriPipeAdvertisement() {
		if (cachedJeriPipeAdvertisement == null) {
			DigestTool digestTool = new DigestTool();
			PipeBinaryID pipeId = digestTool.createPipeID(
					getJeriPeerGroup().getPeerGroupID(),
					"net.jini.jeri.jxta.JeriPipeAdvertisment",
					null);

			cachedJeriPipeAdvertisement = (PipeAdvertisement) AdvertisementFactory.newAdvertisement(PipeAdvertisement
					.getAdvertisementType());

			cachedJeriPipeAdvertisement.setPipeID(pipeId);
			cachedJeriPipeAdvertisement.setType(PipeService.UnicastType);
			cachedJeriPipeAdvertisement.setName("JeriPipeAdvertisment");
			cachedJeriPipeAdvertisement.setDescription("The pipe advertisement of the JXTA Jeri transport layer");
		}
		return cachedJeriPipeAdvertisement;
	}
}
