/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.remote.application;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Proxy;
import java.net.ServerSocket;
import java.net.URI;
import java.net.URISyntaxException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.server.ExportException;
import java.util.*;

import net.jini.constraint.BasicMethodConstraints;
import net.jini.core.constraint.*;
import net.jini.export.Exporter;
import net.jini.id.Uuid;
import net.jini.jeri.BasicILFactory;
import net.jini.jeri.BasicJeriExporter;
import net.jini.jeri.ServerEndpoint;
import net.jini.jeri.tcp.TcpServerEndpoint;
import net.jxta.exception.PeerGroupException;
import net.jxta.id.IDFactory;
import net.jxta.peer.PeerID;

import org.apache.log4j.*;
import org.eodisp.remote.config.RemoteConfiguration;
import org.eodisp.remote.config.RemoteConfiguration.TransportType;
import org.eodisp.remote.jeri.jxta.JxtaNetwork;
import org.eodisp.remote.jeri.jxta.JxtaServerEndpoint;
import org.eodisp.remote.registry.JeriRegistry;
import org.eodisp.remote.registry.JeriRegistryImpl;
import org.eodisp.remote.registry.LocateJeriRegistry;
import org.eodisp.remote.util.JXTAUtil;
import org.eodisp.remote.util.JxtaNetworkManager;
import org.eodisp.remote.util.NetworkConfigurator;
import org.eodisp.util.AppModule;
import org.eodisp.util.RootApp;
import org.eodisp.util.configuration.BasicSystemPropertyMapper;
import org.eodisp.util.configuration.CommandlineMapper;
import org.eodisp.util.configuration.ConfigurationException;

/**
 * An application module implementation that configures, starts up and shuts
 * down the network infrastructure of a Java application. So far, it supports
 * TCP and JXTA transport. The JXTA transport is specifically configured for
 * EODiSP applications (see {@link #newDefaultJxtaConfiguration()}).
 * 
 * @author ibirrer
 * @version $Id:$
 */
public class RemoteAppModule implements AppModule {

	private static final URI DEFAULT_EODISP_TCP_RENDEZVOUS = URI.create("tcp://rdv.eodisp.org:80");

	// private static final URI DEFAULT_EODISP_HTTP_RENDEZVOUS =
	// URI.create("http://rdv.eodisp.org:80");

	private static final URI DEFAULT_EODISP_TCP_RELAY = URI.create("tcp://rdv.eodisp.org:80");

	// private static final URI DEFAULT_EODISP_HTTP_RELAY =
	// URI.create("http://rdv.eodisp.org:80");

	/**
	 * The Id of this Application Module.
	 */
	public static final String ID = RemoteAppModule.class.getName();

	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	static Logger logger = Logger.getLogger(RemoteAppModule.class);

	private RemoteConfiguration remoteConfiguration;

	private int defaultTcpPort;

	private JxtaNetworkManager jxtaNetworkManager;

	private ServerEndpoint tcpServerEndpoint;

	private ServerEndpoint jxtaServerEndpoint;

	private Map<TransportType, JeriRegistry> registryProxies = new HashMap<TransportType, JeriRegistry>();

	private Map<Remote, Map<TransportType, Exporter>> jeriExporters = new IdentityHashMap<Remote, Map<TransportType, Exporter>>();

	private Map<TransportType, URI> endpointUris = new HashMap<TransportType, URI>();

	private JeriRegistryImpl registry;

	private NetworkConfigurator networkConfigurator;

	private Thread tcpKeepAliveThread;

	public RemoteAppModule(int defaultTcpListeningPort) {
		this.defaultTcpPort = defaultTcpListeningPort;
	}

	public String getId() {
		return ID;
	}

	/**
	 * {@inheritDoc}
	 */
	public synchronized void registerConfiguration(RootApp rootApp) throws Exception {
		remoteConfiguration = new RemoteConfiguration(new File(rootApp.getConfigurationDir(), "remote.conf"));
		remoteConfiguration.setTcpPort(defaultTcpPort);
		rootApp.registerConfiguration(remoteConfiguration, CommandlineMapper.BASIC_COMMAND_LINE_MAPPER,
				new BasicSystemPropertyMapper("org.eodisp.remote."));
	}

	/**
	 * {@inheritDoc}
	 * <p>
	 * Sets JXTA logger to only log <code>ERROR</code> message unless set
	 * otherwise before
	 */
	public synchronized void preStartup(RootApp rootApp) throws Exception {
		if (remoteConfiguration.isJxtaLogEverything()) {
			File logFile = new File(rootApp.getDataDir(), "jxta.log");
			Logger.getLogger("net.jxta").setLevel(Level.TRACE);
			Logger.getLogger("net.jxta").setAdditivity(false);
			Logger.getLogger("net.jxta").addAppender(
					new FileAppender(new PatternLayout("%5p %d{ISO8601} - %m%x --- [%t] %C.%M(%F:%L) %n"), logFile
							.getAbsolutePath()));
			logger.info(String.format("Logging jxta in %s", logFile.getAbsolutePath()));
		}

		if (Logger.getLogger("net.jxta").getLevel() == null) {
			Logger.getLogger("net.jxta").setLevel(Level.ERROR);
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @throws PeerGroupException
	 * @throws IOException
	 * @throws ConfigurationException
	 */
	public synchronized void startup(RootApp rootApp) throws PeerGroupException, IOException, ConfigurationException {
		registry = new JeriRegistryImpl(remoteConfiguration.getTransport(), getFavoriteTransport());
		for (TransportType transportType : remoteConfiguration.getTransport()) {
			switch (transportType) {
			case JXTA:
				if (!remoteConfiguration.getJxtaPlatformConfig().exists()) {
					remoteConfiguration.getJxtaPlatformConfig().getParentFile().mkdirs();
					networkConfigurator = newDefaultJxtaConfiguration();
					networkConfigurator.setName(rootApp.getName() + " " + JXTAUtil.getComputerName());
					networkConfigurator.setDescription(rootApp.getDescription());
					networkConfigurator.save(remoteConfiguration.getJxtaPlatformConfig());
				} else {
					networkConfigurator = NetworkConfigurator.loadPlatformConfig(remoteConfiguration
							.getJxtaPlatformConfig().toURI());
					if (remoteConfiguration.isJxtaResetConfig()) {
						PeerID peerID = networkConfigurator.getPeerID();
						String name = networkConfigurator.getName();
						String description = networkConfigurator.getDescription();
						/*
						 * Use the default platform config with the peer ID,
						 * name and description replaced from the existing
						 * config.
						 */
						networkConfigurator = newDefaultJxtaConfiguration();
						networkConfigurator.setPeerID(peerID);
						networkConfigurator.setName(name);
						networkConfigurator.setDescription(description);
						networkConfigurator.save(remoteConfiguration.getJxtaPlatformConfig());
					}
				}

				URI npgUri = remoteConfiguration.getJxtaNpgUri();
				// File jxtaCacheDir = new File( rootApp.getDataDir(), "cm" );
				// logger.debug(String.format("Cleanup jxta cache: %s",
				// jxtaCacheDir.getAbsolutePath()));
				// FileUtil.deleteDir(jxtaCacheDir);

				jxtaNetworkManager = new JxtaNetworkManager(networkConfigurator.getPlatformConfig(), rootApp
						.getDataDir().toURI(), npgUri);
				jxtaNetworkManager.start();

				// Configure Jeri with correct JXTA net peer group
				JxtaNetwork.registerJeriPeerGroup(jxtaNetworkManager.getNetPeerGroup());

				jxtaServerEndpoint = JxtaServerEndpoint.getInstance();
				JeriRegistry jxtaRegistryProxy = (JeriRegistry) export(registry, JeriRegistryImpl.REGISTRY_UUID,
						transportType);
				registryProxies.put(transportType, jxtaRegistryProxy);
				endpointUris.put(transportType, jxtaNetworkManager.getNetPeerGroup().getPeerID().toURI());
				logger.info("JXTA Peer ID: " + jxtaNetworkManager.getNetPeerGroup().getPeerID());
				break;
			case TCP:
				tcpKeepAliveThread = new Thread() {
					@Override
					public void run() {
						synchronized (this) {
							try {
								this.wait();
							} catch (InterruptedException e) {
								logger.debug("Interrupted thread that keeps Jeri TCP connected");
							}
						}
					}
				};
				tcpKeepAliveThread.start();

				int port = remoteConfiguration.getTcpPort();
				// If port is 0, we find a free port. If 0 is directly used as a
				// parameter to TcpServerEndpoint, there seems to be no
				// possibility to get the port number later.
				if (remoteConfiguration.getTcpPort() == 0) {
					ServerSocket serverSocket = new ServerSocket(0);
					port = serverSocket.getLocalPort();
					serverSocket.close();
				}
				tcpServerEndpoint = TcpServerEndpoint.getInstance(port);
				JeriRegistry tcpRegistryProxy = (JeriRegistry) export(registry, JeriRegistryImpl.REGISTRY_UUID,
						transportType);
				registryProxies.put(transportType, tcpRegistryProxy);
				URI localUri = URI.create("tcp://localhost:" + port);
				endpointUris.put(transportType, localUri);
				logger.info("Started JERI at: " + localUri);
				break;
			default:
				logger.error(String.format("Transport '%s' is not supported", remoteConfiguration.getTransport()));
			}

		}

	}

	/**
	 * Returns a pre-configured JXTA network configurator that is suitable for
	 * most EODiSP applications that do not act as a rendezvous or relay. The
	 * following changes are made to the standard edge network configurator (see
	 * {@link NetworkConfigurator#newNetworkConfiguratorEdge()}):
	 * <p>
	 * The relay and rendezvous seeds are configured as follows:
	 * <ul>
	 * <li>Rendezvous: <code>tcp://rdv.eodisp.org:14301</code></li>
	 * <li>Rendezvous: <code>http://rdv.eodisp.org:80</code></li>
	 * <li>Relay: <code>tcp://rdv.eodisp.org:14301</code></li>
	 * <li>Relay: <code>http://rdv.eodisp.org:80</code></li>
	 * </ul>
	 * <p>
	 * The tcp configuration is changed as follows: <table>
	 * <tr>
	 * <th>Tcp Port</th>
	 * <td><code>0</code></td>
	 * </tr>
	 * <tr>
	 * <th>Tcp Start Port</th>
	 * <td><code>-1</code> (Disables port range feature)</td>
	 * </tr>
	 * <tr>
	 * <th>Tcp End Port</th>
	 * <td><code>-1</code> (Disables port range feature)</td>
	 * </tr>
	 * </table>
	 * <p>
	 * Note that the returned configurator can not be readily used. At least the
	 * name and description should be set before using it.
	 * 
	 * @return A pre-configured network configurator suitable for EODiSP
	 *         applications.
	 */
	protected NetworkConfigurator newDefaultJxtaConfiguration() {
		NetworkConfigurator defaultJxtaConfiguration = NetworkConfigurator.newNetworkConfiguratorEdge();
		defaultJxtaConfiguration.setTcpPort(0);
		defaultJxtaConfiguration.setTcpStartPort(-1);
		defaultJxtaConfiguration.setTcpEndPort(-1);
		defaultJxtaConfiguration.addSeedRendezvous(DEFAULT_EODISP_TCP_RENDEZVOUS);
		// defaultJxtaConfiguration.addSeedRendezvous(DEFAULT_EODISP_HTTP_RENDEZVOUS);
		defaultJxtaConfiguration.addSeedRelay(DEFAULT_EODISP_TCP_RELAY);
		// defaultJxtaConfiguration.addSeedRelay(DEFAULT_EODISP_HTTP_RELAY);
		return defaultJxtaConfiguration;
	}

	public TransportType getFavoriteTransport() {
		return remoteConfiguration.getTransport().contains(TransportType.JXTA) ? TransportType.JXTA
				: remoteConfiguration.getTransport().iterator().next();
	}

	/**
	 * {@inheritDoc}
	 */
	public void postShutdown(RootApp rootApp) throws Exception {
	}

	/**
	 * {@inheritDoc}
	 */
	public void shutdown(RootApp rootApp) throws Exception {
		// Un-export remote objects which have not been un-exported by the
		// applications
		// Remote[] stillExportedObjects = jeriExporters.keySet().toArray(new
		// Remote[0]);
		// for (Remote remote : stillExportedObjects) {
		// logger.warn(String.format("Remote object %s has not been unexported.
		// Do it now...", remote));
		// unexportAll(remote, true);
		// }
		for (TransportType transportType : remoteConfiguration.getTransport()) {
			switch (transportType) {
			case JXTA:
				jxtaNetworkManager.stop();
				break;
			case TCP:
				tcpKeepAliveThread.interrupt();
				break;
			default:
				logger.error(String.format("Transport '%s' is not supported", remoteConfiguration.getTransport()));
			}
		}

	}

	private Exporter newExporter(Uuid remoteObjectId, TransportType transportType) {
		Exporter exporter = null;

		switch (transportType) {
		case JXTA:
			exporter = new BasicJeriExporter(jxtaServerEndpoint, new BasicILFactory(), false, false, remoteObjectId);
			break;
		case TCP:
			exporter = new BasicJeriExporter(tcpServerEndpoint, new BasicILFactory(), false, false, remoteObjectId);
			break;
		default:
			logger.error(String.format("Transport '%s' is not supported", remoteConfiguration.getTransport()));
			throw new AssertionError(String.format("Transport '%s' is not supported", remoteConfiguration
					.getTransport()));
		}
		return exporter;
	}

	private synchronized Map<TransportType, Remote> exportAll(Remote objectToExport, Uuid remoteObjectId) {
		Map<TransportType, Remote> proxies = new HashMap<TransportType, Remote>();
		for (TransportType transportType : remoteConfiguration.getTransport()) {
			Remote proxy;
			try {
				proxy = export(objectToExport, remoteObjectId, transportType);
				proxies.put(transportType, proxy);
			} catch (ExportException e) {
				logger.error(String.format("Could not export %s", objectToExport), e);
			}
		}
		return proxies;
	}

	/**
	 * Exports the given remote object with the specified object id and
	 * transport. This method doesn't hold a reference to the remote object but
	 * just to its exporter so it can be unexported
	 * 
	 * @param objectToExport
	 *            object to be exported
	 * @param remoteObjectId
	 * @param transportType
	 * @return
	 * @throws ExportException
	 *             if the <code>objectToExport</code> could not be exported or
	 *             is of type {@link Proxy}
	 * @throws NullPointerException
	 *             if the <code>objectToExport</code> is <code>null</code>
	 */
	private synchronized Remote export(Remote objectToExport, Uuid remoteObjectId, TransportType transportType)
			throws ExportException {
		if (objectToExport instanceof Proxy) {
			throw new ExportException(String.format("Cannot export object [%s] because it is of type [Proxy]",
					objectToExport));
		}

		if (objectToExport == null) {
			throw new NullPointerException("Object to be exported must no be null");
		}

		Map<TransportType, Exporter> exporters = jeriExporters.get(objectToExport);
		if (exporters == null) {
			exporters = new HashMap<TransportType, Exporter>();
			jeriExporters.put(objectToExport, exporters);
		}

		if (exporters.containsKey(transportType)) {
			// TODO: We could allow this and just return a proxy of the already
			// exported instance
			throw new ExportException(String.format(
					"Cannot export object [%s] because it is already exported on transport [%s]", objectToExport,
					transportType));
		}

		Exporter exporter = newExporter(remoteObjectId, transportType);
		logger.debug(String.format("Export %s with exporter: %s", objectToExport, exporter));
		Remote proxy = exporter.export(objectToExport);
		InvocationConstraints invocationConstraints = new InvocationConstraints(new ConnectionRelativeTime(
				remoteConfiguration.getJeriConnectionTimeout()), null);
		MethodConstraints methodConstraints = new BasicMethodConstraints(invocationConstraints);
		((RemoteMethodControl) proxy).setConstraints(methodConstraints);

		exporters.put(transportType, exporter);
		return proxy;
	}

	/**
	 * @param objectToUnexport
	 *            the object that shall be unexported
	 * @param force
	 *            if <code>true</code>, the remote object will be unexported
	 *            even if there are remote calls pending or in progress; if
	 *            <code>false</code>, the remote object may only be
	 *            unexported if there are no known remote calls pending or in
	 *            progress
	 * @return <code>true</code> if the remote object is unexported when this
	 *         method returns and <code>false</code> otherwise
	 * @throws IllegalStateException
	 *             if an object has not been exported with this
	 *             <code>Exporter</code> instance
	 */
	public synchronized boolean unexport(Remote objectToUnexport, TransportType transportType, boolean force) {
		Map<TransportType, Exporter> exporters = jeriExporters.get(objectToUnexport);
		if (exporters == null) {
			throw new IllegalStateException("Cannot unexport an object that was never exported before");
		}

		Exporter exporter = exporters.get(transportType);
		if (exporter == null) {
			throw new IllegalStateException(String.format(
					"Cannot unexport object [%s] on transport [%s] because it was never exported on this transport",
					objectToUnexport, transportType));
		}

		// Cleanup
		if (exporter.unexport(force)) {
			exporters.remove(transportType);
			if (exporters.isEmpty()) {
				jeriExporters.remove(objectToUnexport);
			}
			logger.debug(String.format("Unexport [%s] with exporter: [%s]", objectToUnexport, exporter));
			return true;
		}

		return false;
	}

	public synchronized boolean unexportAll(Remote objectToUnexport, boolean force) {
		EnumSet<TransportType> tranportTypes = EnumSet.noneOf(TransportType.class);
		Map<TransportType, Exporter> exporters = jeriExporters.get(objectToUnexport);
		if (exporters == null) {
			throw new IllegalStateException("Cannot unexport an object that was never exported before");
		}
		tranportTypes.addAll(exporters.keySet());

		boolean success = true;
		for (TransportType transportType : tranportTypes) {
			success = unexport(objectToUnexport, transportType, force);
		}
		return success;
	}

	/**
	 * Exports the given remote object on all transports defined in the
	 * configuration (so far JXTA and/or TCP).
	 * 
	 * @param remote
	 *            the remote object to export
	 * @return A proxy that can to the exported remote object. If more than one
	 *         transport is given, the remote proxy is always a proxy that uses
	 *         the JXTA transport. If JXTA transport is not present a proxy fro
	 *         an arbitrary transport is returned. Returns <code>null</code>
	 *         if export failed for all transports.
	 */
	public synchronized Remote export(Remote objectToExport) {
		return export(objectToExport, getFavoriteTransport());
	}

	/**
	 * Exports the given remote object on all transports defined in the
	 * configuration (so far JXTA and/or TCP).
	 * 
	 * @param objectToExport
	 *            the remote object to export
	 * @param transportType
	 *            the transport that shall be used for the returned proxy
	 * @return The proxy of the exported object for the transport given by
	 *         <code>transportType</code>
	 */
	public synchronized Remote export(Remote objectToExport, TransportType transportType) {
		Map<TransportType, Remote> proxies = exportAll(objectToExport, null);
		if (proxies.isEmpty()) {
			return null;
		}

		return proxies.get(transportType);
	}

	/**
	 * Exports the given remote object on all transports defined in the
	 * configuration (so far JXTA and/or TCP).
	 * 
	 * @param remote
	 *            the remote object to export
	 * @return A proxy that can to the exported remote object. If more than one
	 *         transport is given, the remote proxy is always a proxy that uses
	 *         the JXTA transport. If JXTA transport is not present a proxy fro
	 *         an arbitrary transport is returned. Returns <code>null</code>
	 *         if export failed for all transports.
	 * @throws RemoteException
	 */
	public synchronized Remote exportAndRegister(Remote objectToExport, String registryKey) {
		Map<TransportType, Remote> proxies = exportAll(objectToExport, null);
		if (proxies.isEmpty()) {
			return null;
		}
		registry.rebind(registryKey, proxies);
		return proxies.get(getFavoriteTransport());
	}

	/**
	 * Returns the (single) registry on which remote objects can be registered
	 * for this application.
	 * 
	 * @return A proxy to the registry.
	 */
	public synchronized JeriRegistry getRegistry() {
		if (registryProxies.isEmpty()) {
			return null;
		}
		if (registryProxies.containsKey(TransportType.JXTA)) {
			return registryProxies.get(TransportType.JXTA);
		}
		return registryProxies.values().iterator().next();
	}

	public synchronized Map<TransportType, JeriRegistry> getRegistryProxies() {
		return Collections.unmodifiableMap(registryProxies);
	}

	/**
	 * Returns the (single) registry on which remote objects can be registered
	 * for this application.
	 * 
	 * @return A proxy to the registry.
	 */
	public synchronized JeriRegistry getRegistry(TransportType transportType) {
		if (registryProxies.isEmpty()) {
			return null;
		}
		return registryProxies.get(transportType);
	}

	/**
	 * Returns the registry of the JVM at the given location. A timeout method
	 * constraint is added to the returned proxy. The timeout can be configured
	 * by {@link RemoteConfiguration#getJeriConnecionTimeout()}.
	 * 
	 * @param uri
	 *            the URI where registry is exported. E.g:
	 *            <code>tcp://examplehost.org:7900</code>.
	 * @return the the registry of the JVM at the given location.
	 * @throws URISyntaxException
	 *             Thrown if any of the following is true:
	 *             <ul>
	 *             <li>The scheme of the given URI is not supported. Supported
	 *             schemes are: <code>tcp</code> and <code>urn:jxta</code></li>
	 *             <li>If no port or no host is given for a tcp URI</li>
	 *             <li>If the given peer id URI is not a valid peer id. See
	 *             {@link IDFactory#fromURI(java.net.URI)}</li>
	 *             </ul>
	 */
	public synchronized JeriRegistry getRegistry(URI uri) throws URISyntaxException {
		MethodConstraints methodConstraints = new BasicMethodConstraints(new InvocationConstraints(
				new ConnectionRelativeTime(remoteConfiguration.getJeriConnectionTimeout()), new ConnectionRelativeTime(
						remoteConfiguration.getJeriConnectionTimeout())));
		return LocateJeriRegistry.getRegistry(uri, methodConstraints);
	}

	public synchronized URI getLocalUri(TransportType transportType) {
		return endpointUris.get(transportType);
	}

	public synchronized Map<TransportType, URI> getEndpointUris() {
		return Collections.unmodifiableMap(endpointUris);
	}

	public synchronized JxtaNetworkManager getJxtaNetworkManager() {
		return jxtaNetworkManager;
	}
}
