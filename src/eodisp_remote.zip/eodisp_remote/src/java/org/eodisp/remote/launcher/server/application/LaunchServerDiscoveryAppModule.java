/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.remote.launcher.server.application;

import java.util.Arrays;

import net.jxta.endpoint.EndpointAddress;
import net.jxta.impl.protocol.TCPAdv;
import net.jxta.peergroup.PeerGroup;
import net.jxta.protocol.PeerAdvertisement;
import net.jxta.protocol.ResolverQueryMsg;
import net.jxta.protocol.ResolverResponseMsg;
import net.jxta.resolver.QueryHandler;

import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.remote.launcher.server.LaunchServerDiscovery;
import org.eodisp.remote.util.JXTAUtil;
import org.eodisp.util.AppModule;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.RootApp;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class LaunchServerDiscoveryAppModule implements AppModule {

	/**
	 * {@inheritDoc}
	 */
	public String getId() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public void postShutdown(RootApp rootApp) throws Exception {
		// TODO Auto-generated method stub

	}

	/**
	 * {@inheritDoc}
	 */
	public void preStartup(RootApp rootApp) throws Exception {
		// TODO Auto-generated method stub

	}

	/**
	 * {@inheritDoc}
	 */
	public void registerConfiguration(RootApp rootApp) throws Exception {
		// TODO Auto-generated method stub

	}

	/**
	 * {@inheritDoc}
	 */
	public void shutdown(RootApp rootApp) throws Exception {
		// TODO Auto-generated method stub

	}

	/**
	 * {@inheritDoc}
	 */
	public void startup(RootApp rootApp) throws Exception {
		RemoteAppModule remoteAppModule = (RemoteAppModule) AppRegistry.getRootApp().getAppModule(RemoteAppModule.ID);
		// Start JXTA Shell
		remoteAppModule.getJxtaNetworkManager().getNetPeerGroup().startApp(new String[0]);
		while(true) {
			remoteAppModule.getJxtaNetworkManager().getNetPeerGroup().getRendezVousService().connectToRendezVous(new EndpointAddress("http://rdv.eodisp.org:80"));
			Thread.sleep(5000);
		}
//		PeerAdvertisement[] peerAdvertisements = LaunchServerDiscovery.discoverLaunchServers(10000000, remoteAppModule
//				.getJxtaNetworkManager()
//				.getNetPeerGroup()
//				.getDiscoveryService());
//		for (PeerAdvertisement advertisement : peerAdvertisements) {
//			System.out.println(advertisement);
//		}
	}
}
