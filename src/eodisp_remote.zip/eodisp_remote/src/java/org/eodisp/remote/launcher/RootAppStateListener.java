package org.eodisp.remote.launcher;

import java.util.EventListener;
import java.util.Map;

import org.eodisp.remote.config.RemoteConfiguration.TransportType;
import org.eodisp.remote.registry.JeriRegistry;

public interface RootAppStateListener extends EventListener {
	/**
	 * If this callback is invoked it means that the application is started and
	 * can be accessed from remote now. The RMI registries by which the
	 * application is reachable are available as the parameter
	 * <code>registryProxies</code>.
	 * 
	 * @param registryProxies
	 *            For each transport on which the application can be reached a
	 *            proxy of the RMI registry is being provided.
	 */
	void started(Map<TransportType, JeriRegistry> registryProxies);
}
