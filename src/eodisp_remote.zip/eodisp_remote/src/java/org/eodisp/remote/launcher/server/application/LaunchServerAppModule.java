/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.remote.launcher.server.application;

import java.util.Set;

import org.apache.log4j.Logger;
import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.remote.config.RemoteConfiguration;
import org.eodisp.remote.launcher.*;
import org.eodisp.remote.launcher.server.LaunchServerRemote;
import org.eodisp.remote.launcher.server.LaunchServerRemoteImpl;
import org.eodisp.remote.util.JxtaNetworkManager;
import org.eodisp.util.AppModule;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.RootApp;
import org.eodisp.util.configuration.Configuration;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class LaunchServerAppModule implements AppModule {

	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	static Logger logger = Logger.getLogger(LaunchServerAppModule.class);

	private LaunchServerRemoteImpl launchServer;

	private RemoteAppModule remoteAppModule;

	public static final String ID = LaunchServerAppModule.class.getName();

	/**
	 * 
	 */
	public LaunchServerAppModule() {
		launchServer = new LaunchServerRemoteImpl();
	}

	/**
	 * {@inheritDoc}
	 */
	public String getId() {
		return ID;
	}

	/**
	 * {@inheritDoc}
	 */
	public void postShutdown(RootApp rootApp) throws Exception {
		// TODO Auto-generated method stub

	}

	/**
	 * {@inheritDoc}
	 */
	public void preStartup(RootApp rootApp) throws Exception {
		remoteAppModule = (RemoteAppModule) rootApp.getAppModule(RemoteAppModule.ID);

	}

	/**
	 * {@inheritDoc}
	 */
	public void registerConfiguration(RootApp rootApp) throws Exception {
		// TODO Auto-generated method stub

	}

	/**
	 * {@inheritDoc}
	 */
	public void shutdown(RootApp rootApp) throws Exception {
		remoteAppModule.unexportAll(launchServer, true);
	}

	public <E extends ProcessFactoryRemote> void registerProcessFactory(String processFactoryId,
			Class<? extends ProcessFactoryRemote> processFactoryImpl) {
		launchServer.registerProcessFactory(processFactoryId, processFactoryImpl);
	}

	/**
	 * {@inheritDoc}
	 * <p>
	 * Prints a warning if the peer name of the launch server does not start
	 * with &quot;EODiSP Launch Server&quot;.
	 */
	public void startup(RootApp rootApp) throws Exception {
		remoteAppModule.exportAndRegister(launchServer, LaunchServerRemote.REGISTRY_NAME);
	}
}
