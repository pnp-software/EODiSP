/*
 *  Copyright (c) 2001 Sun Microsystems, Inc.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  2. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following discalimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  3. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Sun Microsystems, Inc. for Project JXTA."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  4. The names "Sun", "Sun Microsystems, Inc.", "JXTA" and "Project JXTA"
 *  must not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact Project JXTA at http://www.jxta.org.
 *
 *  5. Products derived from this software may not be called "JXTA",
 *  nor may "JXTA" appear in their name, without prior written
 *  permission of Sun.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 *  ====================================================================
 *
 *  This software consists of voluntary contributions made by many
 *  individuals on behalf of Project JXTA.  For more
 *  information on Project JXTA, please see
 *  <http://www.jxta.org/>.
 *
 *  This license is based on the BSD license adopted by the Apache Foundation.
 *
 *  $Id: PipeUtil.java 2013 2006-01-30 15:41:50Z ibirrer $
 */

package org.eodisp.remote.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import net.jxta.discovery.DiscoveryListener;
import net.jxta.discovery.DiscoveryService;
import net.jxta.document.AdvertisementFactory;
import net.jxta.id.IDFactory;
import net.jxta.peergroup.PeerGroup;
import net.jxta.pipe.PipeID;
import net.jxta.protocol.PipeAdvertisement;

/**
 * Overtaken from myJXTA project without any modification. Only used for testing
 * purposes and left undocumented.
 * 
 * @version $Id: PipeUtil.java 2013 2006-01-30 15:41:50Z ibirrer $
 * 
 * @author james todd [gonzo at jxta dot org]
 */

public class PipeUtil {

	public static PipeAdvertisement getAdv(PeerGroup pg, String name, String type, byte[] pipeId) {
		return getAdv(pg, name, type, pipeId, false);
	}

	public static PipeAdvertisement getAdv(PeerGroup pg, String name, String type, byte[] pipeId, boolean remote) {
		PipeAdvertisement pa = searchLocal(pg, name);

		if (pa == null) {
			pa = createAdv(pg, name, type, pipeId);

			publish(pg, pa, remote);
		}

		return pa;
	}

	public static List getAdvs(PeerGroup pg, String name) {
		List p = new ArrayList();

		try {
			for (Enumeration pas = pg.getDiscoveryService().getLocalAdvertisements(
					DiscoveryService.ADV,
					PipeAdvertisement.NameTag,
					name); pas.hasMoreElements();) {
				Object o = pas.nextElement();

				if (o instanceof PipeAdvertisement) {
					p.add((PipeAdvertisement) o);
				}
			}
		} catch (IOException ioe) {
		}

		return p;
	}

	public static PipeAdvertisement searchLocal(PeerGroup pg, String name) {
		PipeAdvertisement pa = null;

		try {
			for (Enumeration pas = pg.getDiscoveryService().getLocalAdvertisements(
					DiscoveryService.ADV,
					PipeAdvertisement.NameTag,
					name); pas.hasMoreElements();) {
				pa = (PipeAdvertisement) pas.nextElement();

				if (pa.getName().equals(name)) {
					break;
				} else {
					pa = null;
				}
			}
		} catch (IOException ioe) {
		}

		return pa;
	}

	public static void discoverAdvs(PeerGroup pg, String name, DiscoveryListener listener) {
		DiscoveryService s = pg.getDiscoveryService();

		s.getRemoteAdvertisements(
				null,
				DiscoveryService.ADV,
				name != null ? PipeAdvertisement.NameTag : null,
				name,
				10,
				listener);
	}

	public static PipeAdvertisement createAdv(PeerGroup pg, String name, String type) {
		return createAdv(pg, name, type, null);
	}

	public static PipeAdvertisement createAdv(PeerGroup pg, String name, String type, byte[] id) {
		PipeAdvertisement pa = (PipeAdvertisement) AdvertisementFactory.newAdvertisement(PipeAdvertisement
				.getAdvertisementType());

		pa.setPipeID(id != null ? (PipeID) IDFactory.newPipeID(pg.getPeerGroupID(), id) : (PipeID) IDFactory
				.newPipeID(pg.getPeerGroupID()));
		pa.setName(name);
		pa.setType(type);

		return pa;
	}

	public static void publish(PeerGroup pg, PipeAdvertisement pa) {
		publish(pg, pa, false);
	}

	public static void publish(PeerGroup pg, PipeAdvertisement pa, boolean remote) {
		DiscoveryService ds = pg.getDiscoveryService();

		try {
			ds.publish(pa);
		} catch (IOException ioe) {
		}

		if (remote) {
			// xxx: no remote publishing
			// ds.remotePublish(pa, DiscoveryService.ADV);
		}
	}
}
