/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.remote.launcher;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.tools.ant.types.CommandlineJava;
import org.apache.tools.ant.types.Environment;
import org.apache.tools.ant.types.Path;
import org.apache.tools.ant.types.Commandline.Argument;
import org.apache.tools.ant.types.CommandlineJava.SysProperties;
import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.remote.config.RemoteConfiguration.TransportType;
import org.eodisp.remote.registry.JeriRegistry;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.ArrayUtil;
import org.eodisp.util.FileUtil;
import org.eodisp.util.launcher.ProcessImpl;
import org.eodisp.util.launcher.ProcessListener;

/**
 * @author ibirrer
 * @version $Id:$
 */
public class RootAppProcessImpl implements RootAppProcess {
	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	static Logger logger = Logger.getLogger(RootAppProcessImpl.class);

	private static final class RemoteAppProcessCallbackImpl implements RootAppProcessCallback {
		Map<Integer, RootAppProcessImpl> registeredRemoteApps = Collections
				.synchronizedMap(new HashMap<Integer, RootAppProcessImpl>());

		/**
		 * {@inheritDoc}
		 */
		public void started(int id, Map<TransportType, JeriRegistry> registryProxies) {
			logger.debug("Root App with ID %s has notified the controlling application that it has started");
			RootAppProcessImpl remoteAppProcessImpl = registeredRemoteApps.get(Integer.valueOf(id));
			remoteAppProcessImpl.fireRemoteAppStarted(registryProxies);
			registeredRemoteApps.remove(Integer.valueOf(id));
		}

		void registerRemoteAppProcess(int id, RootAppProcessImpl remoteAppProcess) {
			registeredRemoteApps.put(Integer.valueOf(id), remoteAppProcess);
		}
	}

	private static RemoteAppProcessCallbackImpl remoteAppProcessCallbackImpl;

	private static int nextId = 0;

	private final int id;

	private final Set<RootAppStateListener> remoteAppStateListeners = Collections
			.synchronizedSet(new HashSet<RootAppStateListener>());

	private ProcessImpl processImpl;

	public RootAppProcessImpl(String className, EnumSet<TransportType> transports, int tcpPort) {
		this(className, null, transports, tcpPort, null, null, null);
	}

	private static File getTmpWorkingDir(String appName) {
		try {
			return FileUtil.createTempDir(appName, "", null);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public RootAppProcessImpl(String className, File workingDir, EnumSet<TransportType> transports, int tcpPort) {
		this(className, workingDir, transports, tcpPort, null, null, null);
	}

	public RootAppProcessImpl(String className, File workingDir, EnumSet<TransportType> transports, int tcpPort,
			TransportType callbackTransport, String args) {
		this(className, workingDir, transports, tcpPort, callbackTransport, args, null);
	}

	public RootAppProcessImpl(String className, File workingDir, EnumSet<TransportType> transports, int tcpPort,
			TransportType callbackTransport, String args, Map<String, String> systemProperties) {
		RemoteAppModule remoteAppModule = (RemoteAppModule) AppRegistry.getRootApp().getAppModule(RemoteAppModule.ID);
		if (callbackTransport == null) {
			if (transports.contains(remoteAppModule.getFavoriteTransport())) {
				callbackTransport = remoteAppModule.getFavoriteTransport();
			} else {
				callbackTransport = transports.iterator().next();
			}
		}

		if (transports == null || transports.isEmpty()) {
			throw new IllegalArgumentException("Transports may not be null or empty");
		}

		if (!transports.contains(callbackTransport)) {
			throw new IllegalArgumentException("Callback transport must be available in transports");
		}

		if (workingDir == null) {
			workingDir = getTmpWorkingDir(className);
		}

		this.id = nextId();

		if (remoteAppProcessCallbackImpl == null) {
			remoteAppProcessCallbackImpl = new RemoteAppProcessCallbackImpl();
			remoteAppModule.exportAndRegister(remoteAppProcessCallbackImpl, RootAppProcessCallback.REGISTRY_KEY);
		}

		CommandlineJava commandlineJava = new CommandlineJava();
		commandlineJava.setClassname(className);
		commandlineJava.createClasspath(null);
		commandlineJava.getClasspath().add(Path.systemClasspath);
		SysProperties sysProperties = new SysProperties();

		Environment.Variable var1 = new Environment.Variable();
		var1.setKey(ProcessRemote.CALLBACK_REGISTRY_URI_SYSTEM_PROPERTY_KEY);
		var1.setValue(remoteAppModule.getEndpointUris().get(callbackTransport).toString());
		sysProperties.addVariable(var1);

		Environment.Variable var2 = new Environment.Variable();
		var2.setKey(ProcessRemote.CALLBACK_ID_SYSTEM_PROPERTY_KEY);
		var2.setValue(String.valueOf(id));
		sysProperties.addVariable(var2);
		if (systemProperties != null) {
			for (Map.Entry<String, String> entry : systemProperties.entrySet()) {
				Environment.Variable envVar = new Environment.Variable();
				envVar.setKey(entry.getKey());
				envVar.setValue(entry.getValue());
				sysProperties.addVariable(envVar);
			}
		}

		logger.debug(String.format("Setting callback to: %s/", var1.getValue(), var2.getValue()));

		commandlineJava.addSysproperties(sysProperties);

		Argument transport = commandlineJava.createArgument();
		transport.setLine("--transport " + ArrayUtil.enumSetToString(transports));

		Argument portArg = commandlineJava.createArgument();
		portArg.setLine("--tcp.port " + tcpPort);

		Argument workingDirArg = commandlineJava.createArgument();
		workingDirArg.setLine("--working-dir \"" + workingDir.getAbsolutePath() + "\"");

		Argument debug = commandlineJava.createArgument();
		debug.setLine("--log-level debug");

		if (args != null && !args.trim().equals("")) {
			Argument argsLine = commandlineJava.createArgument();
			argsLine.setLine(args);
		}

		processImpl = new ProcessImpl(commandlineJava);
	}

	private static synchronized int nextId() {
		return nextId++;
	}

	void fireRemoteAppStarted(Map<TransportType, JeriRegistry> registryProxies) {
		synchronized (remoteAppStateListeners) {
			for (RootAppStateListener stateListener : remoteAppStateListeners) {
				stateListener.started(registryProxies);
			}
		}
	}

	public void launch() throws IOException {
		remoteAppProcessCallbackImpl.registerRemoteAppProcess(id, this);
		processImpl.launch();
	}

	public Map<TransportType, JeriRegistry> launchBlocking(long timeout, TimeUnit timeUnit) throws IOException,
			InterruptedException {
		final CountDownLatch countDownLatch = new CountDownLatch(1);
		final Map<TransportType, JeriRegistry> result = new HashMap<TransportType, JeriRegistry>();
		addRemoteAppStateListener(new RootAppStateListener() {
			public void started(Map<TransportType, JeriRegistry> registryProxies) {
				result.putAll(registryProxies);
				countDownLatch.countDown();
			}
		});
		launch();
		if (!countDownLatch.await(timeout, timeUnit)) {
			return null;
		}
		return result;

	}

	// Forwarding methods
	public void addRemoteAppStateListener(RootAppStateListener remoteAppStateListener) {
		remoteAppStateListeners.add(remoteAppStateListener);
	}

	public void addListener(ProcessListener processListener) {
		processImpl.addListener(processListener);
	}

	public boolean kill(long timeoutInMillis) {
		return processImpl.kill(timeoutInMillis);
	}

	public int launchBlocking() throws IOException {
		return processImpl.launchBlocking();
	}

	public void addEnvVar(String key, String value) {
		processImpl.addEnvVar(key, value);

	}
}
