/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com
 *  mail: info@pnp-software.com
 */
package org.eodisp.remote.util;

import java.io.*;
import java.net.InetAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;

import net.jxta.credential.AuthenticationCredential;
import net.jxta.document.*;
import net.jxta.endpoint.EndpointAddress;
import net.jxta.exception.PeerGroupException;
import net.jxta.exception.ProtocolNotSupportedException;
import net.jxta.id.IDFactory;
import net.jxta.impl.id.binaryID.DigestTool;
import net.jxta.impl.id.binaryID.PipeBinaryID;
import net.jxta.membership.Authenticator;
import net.jxta.membership.MembershipService;
import net.jxta.peergroup.PeerGroup;
import net.jxta.peergroup.PeerGroupID;
import net.jxta.pipe.PipeService;
import net.jxta.protocol.PeerAdvertisement;
import net.jxta.protocol.PipeAdvertisement;
import net.jxta.protocol.RouteAdvertisement;
import net.jxta.rendezvous.RendezVousService;
import net.jxta.rendezvous.RendezvousEvent;
import net.jxta.rendezvous.RendezvousListener;

import org.apache.log4j.Logger;

/**
 * Some utility methods for common JXTA tasks.
 * 
 * @author ibirrer
 * @version $Id: JXTAUtil.java 2013 2006-01-30 15:41:50Z ibirrer $
 */
public class JXTAUtil {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(JXTAUtil.class);

	private static final String ERTI_PEER_GROUP_DESCRIPTION = "The ERTI peer group to which all ERTI peers belong to";

	private static final String ERTI_PEER_GROUP_NAME = "org.eodisp.erti.ertiPeerGroup";

	/**
	 * Returns the endpoint address of a peer advertisement.
	 * 
	 * @param peerAdv
	 *            the peer advertisement for which the endpoint address shall be
	 *            delivered
	 * @return the endpoint address
	 */
	public static Collection<EndpointAddress> getEndpointAddresses(PeerAdvertisement peerAdv) {

		// Get its EndpointService advertisement
		TextElement endpParam = (TextElement) peerAdv.getServiceParam(PeerGroup.endpointClassID);

		if (endpParam == null) {
			return null;
		}

		RouteAdvertisement route = null;
		try {
			Enumeration paramChilds = endpParam.getChildren(RouteAdvertisement.getAdvertisementType());
			Element param = null;

			if (paramChilds.hasMoreElements()) {
				param = (Element) paramChilds.nextElement();
			}
			route = (RouteAdvertisement) AdvertisementFactory.newAdvertisement((TextElement) param);
		} catch (Exception ex) {
			return null;
		}

		if (route == null) {
			return null;
		}

		Collection<EndpointAddress> addrs = new ArrayList<EndpointAddress>();
		try {
			for (Enumeration e = route.getDest().getEndpointAddresses(); e.hasMoreElements();) {
				addrs.add(new EndpointAddress((String) e.nextElement()));
			}
		} catch (Exception e) {
			return null;
		}

		if (addrs.size() == 0) {
			return null;
		}

		return addrs;
	}

	/**
	 * Does a simple group join without any authentication.
	 * 
	 * @param peerGroup
	 *            the peer group that shall be joined
	 * @throws PeerGroupException
	 * @throws ProtocolNotSupportedException
	 */
	public static void simpleGroupJoin(PeerGroup peerGroup) throws PeerGroupException, ProtocolNotSupportedException {
		AuthenticationCredential authCred = new AuthenticationCredential(peerGroup, null, null);
		MembershipService membershipService = peerGroup.getMembershipService();
		Authenticator authenticator = membershipService.apply(authCred);

		if (authenticator.isReadyForJoin()) {
			logger.debug("Join ertiPeerGroup");
			membershipService.join(authenticator);
			logger.debug("Successfully joined ertiPeerGroup");
		} else {
			logger.error("Unable to join Group");
		}
	}

	/**
	 * Instantiates and returns the ERTI peer group. The erti peer group name
	 * is: &quot;org.eodisp.erti.ertiPeerGroup&quot;. The peer group description
	 * is: &quot;The ERTI peer group to which all ERTI peers belong to&quot;
	 * 
	 * @param netPeerGroup
	 *            the parent group
	 * @param ertiGroupId
	 *            the group id of the new ERTI peer group
	 * @return the ERTI peer group
	 * @throws PeerGroupException
	 *             If something went wrong during the group instantiation
	 * @throws URISyntaxException
	 *             If the given ertiGroupId is not a valid URI.
	 */
	public static PeerGroup instantiateERTIPeerGroup(PeerGroup netPeerGroup, String ertiGroupId)
			throws PeerGroupException, URISyntaxException, Exception {
		logger.debug("Instantiate SimulationManagerApp peer group");
		PeerGroup ertiPeerGroup = netPeerGroup.newGroup(
				(PeerGroupID) IDFactory.fromURI(new URI(ertiGroupId)),
				netPeerGroup.getAllPurposePeerGroupImplAdvertisement(),
				ERTI_PEER_GROUP_NAME,
				ERTI_PEER_GROUP_DESCRIPTION);
		logger.debug("SimulationManagerApp peer group instantiated successfully");
		return ertiPeerGroup;
	}

	// /**
	// * For testing purposes only.
	// * Returns a
	// * @param ertiPeerGroup
	// * @param logger
	// * @return
	// */
	// public static PipeAdvertisement getERTITestPipeAdvertisement(PeerGroup
	// ertiPeerGroup) {
	// // Create pipe id from clear test string
	// DigestTool digestTool = new DigestTool();
	// PipeBinaryID pipeId = digestTool.createPipeID(
	// ertiPeerGroup.getPeerGroupID(),
	// "org.edoisp.erti.server.ERTITestPipe",
	// null);
	// // PipeID pipeId = IDFactory.newPipeID( ertiPeerGroup.getPeerGroupID(),
	// // ERTI_INCOMING_PIPE_ID );
	//
	// // Create pipe advertisement
	// PipeAdvertisement pipeAd = (PipeAdvertisement)
	// AdvertisementFactory.newAdvertisement(PipeAdvertisement
	// .getAdvertisementType());
	//
	// pipeAd.setPipeID(pipeId);
	// pipeAd.setType(PipeService.UnicastType);
	// pipeAd.setName("org.eodisp.erti.net.jxta.TestPipe");
	// pipeAd.setDescription("A test pipe ad");
	// try {
	// ertiPeerGroup.getDiscoveryService().flushAdvertisement(pipeAd);
	// ertiPeerGroup.getDiscoveryService().publish(pipeAd);
	// } catch (IOException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	// return pipeAd;
	// }

	/**
	 * Use for tests only! Does not throw any exceptions for convenience.
	 * 
	 * @param adv
	 *            the advertisement
	 * @param file
	 *            the file the advertisement should be saved to
	 */
	public static void saveAdvertisement(Advertisement adv, File file) {
		try {
			adv.getDocument(MimeMediaType.XMLUTF8).sendToStream(new FileOutputStream(file));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// public static String printMessage(Message message) {
	// if (message == null) {
	// return "Empty Message";
	// }
	//
	// Collection<MessageElement> c = new ArrayList<MessageElement>();
	// Iterator it = message.getMessageElements();
	// while (it.hasNext()) {
	// c.add((MessageElement) it.next());
	// }
	//
	// return Arrays.toString(c.toArray(new MessageElement[0]));
	// }

	/**
	 * Creates a JXTA configuration in the system's temp directory (<code>System.getProperty("java.io.tmpdir")</code>).
	 * The directory name for the configuration is taken from the peer name. So
	 * if the peerName is "peer1" the configuration directory on linux is set to
	 * <code>/tmp/peer1</code>. The JXTA_HOME directory is also set to this
	 * directory.
	 * 
	 * @param peerName
	 *            peer name
	 * @param principal
	 *            peer principal
	 * @param password
	 *            the desired password
	 * @param profile
	 *            a profile (e.g {@link Profile#EDGE})
	 * @param clean
	 *            delete the home directory if set to true
	 * @throws ConfiguratorException
	 *             if JXTA configurator could not be created.
	 */
	// public static void createJXTATempConfiguration(String peerName, String
	// principal, String password, Profile profile,
	// boolean clean) throws ConfiguratorException {
	// // make sure that we really only work in the temp directory (because of
	// // delete)
	// assert (!peerName.contains(".."));
	// assert (!(new File(peerName).isAbsolute()));
	//
	// File jxtaHomeDir = new File(new
	// File(System.getProperty("java.io.tmpdir")), peerName);
	//
	// if (clean) {
	// FileUtil.deleteDir(jxtaHomeDir);
	// }
	//
	// System.setProperty("JXTA_HOME", jxtaHomeDir.getAbsolutePath());
	// Configurator configurator = new Configurator(jxtaHomeDir.toURI(),
	// profile);
	// configurator.setName(peerName);
	// configurator.setSecurity(principal, password);
	// configurator.save();
	// logger.info("temp configuration saved in " + configurator.getJxtaHome());
	// }
	/**
	 * Returns the local computer name.
	 * 
	 * @return the name of the computer the JVM is running on or unknown if
	 *         can't be determined.
	 */
	public static String getComputerName() {
		try {
			return InetAddress.getLocalHost().getHostName();
		} catch (Exception e) {
			return "unknown";
		}
	}

	/**
	 * Returns the pipe advertisement for the server component.
	 * 
	 * @param ertiPeerGroup
	 *            the peer group the created pipe belongs to.
	 * @return the pipe advertisements for the server component of the network.
	 */
	public static PipeAdvertisement getERTISocketPipeAdvertisement(PeerGroup ertiPeerGroup) {
		// Create pipe id from clear test string
		DigestTool digestTool = new DigestTool();
		PipeBinaryID pipeId = digestTool.createPipeID(
				ertiPeerGroup.getPeerGroupID(),
				"org.edoisp.erti.server.ERTIPipeAdvertisement",
				null);

		// Create pipe advertisement
		PipeAdvertisement pipeAd = (PipeAdvertisement) AdvertisementFactory.newAdvertisement(PipeAdvertisement
				.getAdvertisementType());

		pipeAd.setPipeID(pipeId);
		logger.debug("ERTI Incoming Pipe: " + pipeId);
		pipeAd.setType(PipeService.UnicastType);
		pipeAd.setName("org.eodisp.erti.net.jxta.ClientConnectionPipe");
		pipeAd.setDescription("Pipe that a ");

		try {
			ertiPeerGroup.getDiscoveryService().flushAdvertisement(pipeAd);
			ertiPeerGroup.getDiscoveryService().publish(pipeAd);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pipeAd;
	}

	/**
	 * Returns the ERTI Net Peer Group.
	 * 
	 * @return the ERTI Net Peer Group
	 */
	public static PeerGroupID getERTINetPeerGroupID() {
		DigestTool digestTool = new DigestTool();
		return digestTool.createPeerGroupID(PeerGroupID.worldPeerGroupID, "org.eodisp.erti.ERTINetPeerGroup", null);
	}

	public static void connectToRendezvous(PeerGroup peerGroup, long timeout) {
		final Object lock = new Object();

		class UtilRendezvousListener implements RendezvousListener {

			private RendezVousService rendezVousService;

			public UtilRendezvousListener(RendezVousService rendezVousService) {
				this.rendezVousService = rendezVousService;
			}

			private boolean abort = false;

			/**
			 * Indicates that nobody is interested in the search result anymore
			 * (timeout reached).
			 */
			public void abort() {
				this.abort = true;
			}
			
			public void rendezvousEvent(RendezvousEvent event) {
				synchronized (lock) {
					if (abort) {
						logger
								.warn("Connected to rendezvous, but too late. Timeout has been reached before. Consider to increase the timeout. Remove listener");
						rendezVousService.removeListener(this);
						return;
					}

					logger.debug(String.format("Received rendezvous event: %s", event.toString()));
					if (event.getType() == event.RDVCONNECT || event.getType() == event.RDVRECONNECT
							|| event.getType() == event.BECAMERDV) {
						lock.notify();
					}
				}
			}
		}

		RendezVousService rendezVousService = peerGroup.getRendezVousService();
		UtilRendezvousListener utilRendezvousListener = new UtilRendezvousListener(rendezVousService);
		rendezVousService.addListener(utilRendezvousListener);

		synchronized (lock) {
			logger.debug("Wait for rendezvous ...");
			try {
				lock.wait(timeout);
			} catch (InterruptedException e) {
				logger.warn("Thread was interrupted while waiting for rendezvous connection.");
			}
			logger.debug("Finished waiting for rendezvous connection, probably because of timeout");
			utilRendezvousListener.abort();
			rendezVousService.removeListener(utilRendezvousListener);
		}
	}

}
