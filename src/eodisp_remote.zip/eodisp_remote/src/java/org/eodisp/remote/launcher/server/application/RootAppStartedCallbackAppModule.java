/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.remote.launcher.server.application;

import java.net.URI;

import org.apache.log4j.Logger;
import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.remote.launcher.ProcessRemote;
import org.eodisp.remote.launcher.RootAppProcessCallback;
import org.eodisp.remote.registry.JeriRegistry;
import org.eodisp.remote.registry.LocateJeriRegistry;
import org.eodisp.util.AppModule;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.RootApp;

/**
 * An application module that invokes a callback on the launch server that
 * started the root application. This application module should always be
 * registered as the last application module in a root application. The callback
 * is done during the <code>startup</code> phase ({@link AppModule#startup(RootApp)}
 * and is only invoked if the two system properties
 * <code>ProcessRemote.CALLBACK_REGISTRY_KEY_SYSTEM_PROPERTY_KEY</code> and
 * <code>ProcessRemote.CALLBACK_REGISTRY_URI_SYSTEM_PROPERTY_KEY</code> are
 * set. This application modules assumes that the {@link RemoteAppModule} was
 * registered earlier.
 * 
 * @author ibirrer
 * @version $Id:$
 */
public class RootAppStartedCallbackAppModule implements AppModule {

	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	static Logger logger = Logger.getLogger(RootAppStartedCallbackAppModule.class);

	public RootAppStartedCallbackAppModule() {
	}

	public String getId() {
		return this.getClass().getName();
	}

	public void postShutdown(RootApp rootApp) throws Exception {
	}

	public void preStartup(RootApp rootApp) throws Exception {
	}

	public void registerConfiguration(RootApp rootApp) throws Exception {
	}

	public void shutdown(RootApp rootApp) throws Exception {
	}

	public void startup(RootApp rootApp) throws Exception {
		String callbackIdString = System.getProperty(ProcessRemote.CALLBACK_ID_SYSTEM_PROPERTY_KEY);
		String callbackUri = System.getProperty(ProcessRemote.CALLBACK_REGISTRY_URI_SYSTEM_PROPERTY_KEY);
		if (callbackIdString != null && callbackUri != null) {
			logger.debug(String.format(
					"Notify application on %s(%s) that '%s' has been started",
					callbackUri,
					callbackIdString,
					rootApp.getName()));
			int callbackId = Integer.valueOf(callbackIdString).intValue();
			RemoteAppModule remoteAppModule = (RemoteAppModule) AppRegistry.getRootApp().getAppModule(
					RemoteAppModule.ID);
			JeriRegistry callbackRegistry = remoteAppModule.getRegistry(new URI(callbackUri));

			RootAppProcessCallback processCallback = (RootAppProcessCallback) callbackRegistry.lookup(
					RootAppProcessCallback.REGISTRY_KEY,
					LocateJeriRegistry.getTransportType(URI.create(callbackUri)));
			processCallback.started(callbackId, remoteAppModule.getRegistryProxies());
		}
	}
}