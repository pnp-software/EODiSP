package org.eodisp.remote.launcher;

import java.rmi.RemoteException;
import java.util.EnumSet;

import org.eodisp.remote.config.RemoteConfiguration.TransportType;

public interface RootAppProcessFactoryRemote extends ProcessFactoryRemote {
	public abstract void setTransports(EnumSet<TransportType> transports) throws RemoteException;
}
