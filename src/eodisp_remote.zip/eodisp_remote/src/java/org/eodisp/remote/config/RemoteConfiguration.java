/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.remote.config;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.EnumSet;

import org.eodisp.util.configuration.ConfigurationException;
import org.eodisp.util.configuration.ConfigurationImpl;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class RemoteConfiguration extends ConfigurationImpl {

	public static final String TRANSPORT = "transport";

	public static final String TCP_PORT = "tcp.port";

	public static final String JERI_CONNECTION_TIMEOUT = "jeri-connection-timeout";

	public static final String JXTA_PLATFORM_CONFIG = "jxta.platform-config";

	public static final String ID = "org.eodisp.remote.config.RemoteConfiguration";

	public static final String JXTA_NPG_URI = "jxta.npg-uri";

	public static final String DEFAULT_JXTA_NPG_URI = "urn:jxta:uuid-37AB0CEE1A5444728150BB2E14082E7A02";

	public static final String JXTA_RESET_CONFIG = "jxta.reset-config";

	public static final String JXTA_LOG_EVERYTHING = "jxta.log-everything";

	public static enum TransportType {
		JXTA, TCP
	}

	/**
	 * @param file
	 */
	public RemoteConfiguration(File file) {
		super(ID, "Network Configuration", "Configures the EODiSP network infrastructure", file);
		createEnumSetEntry(
				TRANSPORT,
				EnumSet.of(TransportType.JXTA),
				TransportType.class,
				"The transport type that this application shall support");
		createFileEntry(
				JXTA_PLATFORM_CONFIG,
				new File("jxta", "PlatformConfig"),
				"The PlatfromConfig file used to configure the JXTA network");
		createIntEntry(TCP_PORT, 0, "The port on which the TCP transport is listening on");
		createEntry(
				JXTA_NPG_URI,
				DEFAULT_JXTA_NPG_URI,
				"The net-peer-group URI of that is used for JXTA communication.");
		createIntEntry(
				JERI_CONNECTION_TIMEOUT,
				60000,
				"The connection timeout of a remote method call in milliseconds.");
		createBooleanEntry(
				JXTA_RESET_CONFIG,
				false,
				"Resets the JXTA Configuration if set to true. The Peer ID is not cleared but kept");

		createBooleanEntry(JXTA_LOG_EVERYTHING, false, "If set to true, logs all messages from JXTA in data/jxta.log");
	}

	/**
	 * Returns the location of the JXTA PlatfromConfig file. If the path is not
	 * an absolute path it is resolved against the location of the
	 * configuration's file.
	 * 
	 * @return location of the JXTA PlatfromConfig file.
	 */
	public File getJxtaPlatformConfig() {
		return ((EntryImpl) getEntry(JXTA_PLATFORM_CONFIG)).getFileResolved();
	}

	public boolean isJxtaLogEverything() {
		return getEntry(JXTA_LOG_EVERYTHING).getBoolean();
	}

	public void setJxtaLogEverything(boolean jxtaLogEverything) {
		getEntry(JXTA_LOG_EVERYTHING).setBoolean(jxtaLogEverything);
	}

	public void setJxtaPlatformConfig(File jxtaPlatformConfig) {
		getEntry(JXTA_PLATFORM_CONFIG).setFile(jxtaPlatformConfig);
	}

	public int getTcpPort() {
		return getEntry(TCP_PORT).getInt();
	}

	public void setTcpPort(int tcpPort) {
		getEntry(TCP_PORT).setInt(tcpPort);
	}

	public URI getJxtaNpgUri() throws ConfigurationException {
		final Entry entry = getEntry(JXTA_NPG_URI);
		final String value = entry.getValue();
		try {
			return new URI(value);
		} catch (URISyntaxException e) {
			throw new ConfigurationException(String.format("Syntax exception in URI: %s", value), entry, e);
		}
	}

	public void setJxtaNpgUri(String jxtaNpgUri) {
		getEntry(JXTA_NPG_URI).setValue(jxtaNpgUri);
	}

	public EnumSet<TransportType> getTransport() {
		return getEntry(TRANSPORT).getEnumSet();
	}

	public void setTransport(EnumSet<TransportType> transports) {
		getEntry(TRANSPORT).setEnumSet(transports);
	}

	public boolean isJxtaResetConfig() {
		return getEntry(JXTA_RESET_CONFIG).getBoolean();
	}

	public void setJxtaResetConfig(boolean jxtaResetConfig) {
		getEntry(JXTA_RESET_CONFIG).setBoolean(jxtaResetConfig);
	}

	public int getJeriConnectionTimeout() {
		return getEntry(JERI_CONNECTION_TIMEOUT).getInt();
	}

	public void setJeriConnectionTimeout(int jeriConnectionTimeout) {
		getEntry(JERI_CONNECTION_TIMEOUT).setInt(jeriConnectionTimeout);
	}

	public static void main(String[] args) {
		System.out.println(new RemoteConfiguration(null).getCode());
	}
}
