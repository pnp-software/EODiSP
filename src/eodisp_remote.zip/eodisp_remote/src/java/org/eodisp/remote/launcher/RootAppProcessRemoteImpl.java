/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.remote.launcher;

import java.io.IOException;
import java.rmi.RemoteException;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.eodisp.remote.config.RemoteConfiguration.TransportType;
import org.eodisp.remote.launcher.ProcessRemoteImpl.ProcessListenerRemoteImpl;
import org.eodisp.remote.registry.JeriRegistry;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class RootAppProcessRemoteImpl implements RootAppProcessRemote {

	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	static Logger logger = Logger.getLogger(RootAppProcessRemoteImpl.class);

	private final RootAppProcess rootAppProcess;

	public RootAppProcessRemoteImpl(RootAppProcess rootAppProcess) {
		this.rootAppProcess = rootAppProcess;
	}

	/**
	 * {@inheritDoc}
	 */
	public void addRemoteAppStateListener(final RootAppStateListenerRemote rootAppStateListenerRemote) {
		rootAppProcess.addRemoteAppStateListener(new RootAppStateListener() {
			public void started(Map<TransportType, JeriRegistry> registryProxies) {
				try {
					System.out.println("!!! Received notification");
					rootAppStateListenerRemote.started(registryProxies);
				} catch (RemoteException e) {
					logger.error(e);
				}
			}
		});
	}

	/**
	 * {@inheritDoc}
	 */
	public Map<TransportType, JeriRegistry> launchBlocking(long timeout, TimeUnit timeUnit) throws IOException,
			InterruptedException, RemoteException {
		return rootAppProcess.launchBlocking(timeout, timeUnit);
	}

	// Forwarded methods
	public void addListener(ProcessListenerRemote processListenerRemote) {
		rootAppProcess.addListener(new ProcessListenerRemoteImpl(processListenerRemote));
	}

	public boolean kill(long timeoutInMillis) {
		return rootAppProcess.kill(timeoutInMillis);
	}

	public void launch() throws IOException {
		rootAppProcess.launch();
	}
}
