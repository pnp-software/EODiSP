/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com
 *  mail: info@pnp-software.com
 */
package org.eodisp.remote.jeri.jxta;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.channels.SocketChannel;
import java.security.AccessControlContext;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.eodisp.remote.jeri.connection.fastmux.ServerConnectionManagerFastMux;

import net.jini.core.constraint.InvocationConstraints;
import net.jini.io.UnsupportedConstraintException;
import net.jini.io.context.ClientHost;
import net.jini.jeri.*;
import net.jini.jeri.connection.InboundRequestHandle;
import net.jini.jeri.connection.ServerConnection;
import net.jini.security.Security;
import net.jini.security.SecurityContext;
import net.jxta.socket.JxtaServerSocket;

import com.sun.jini.jeri.internal.runtime.Util;
import com.sun.jini.logging.LogUtil;
import com.sun.jini.thread.Executor;
import com.sun.jini.thread.GetThreadPoolAction;

/**
 * An implementation of the {@link ServerEndpoint} abstraction that uses JXTA
 * sockets (instances of {@link net.jxta.socket.JxtaServerSocket}) for the
 * underlying communication mechanism.
 * 
 * <p>
 * Most of the implementation was copied from the the
 * {@link net.jini.jeri.tcp.TcpServerEndpoint} class.
 * 
 * <p>
 * All <code>TcpServerEndpoint</code> instances in the same JVM use the same
 * peer and peer group advertisement. This information is statically received from
 * {@link org.eodisp.remote.jeri.jxta.JxtaNetwork}.
 * 
 * <p>
 * <code>JxtaServerEndpoint</code> uses the <a
 * href="../connection/doc-files/mux.html">Jini(TM) extensible remote invocation
 * (Jini ERI) multiplexing protocol</a> to map incoming requests to socket
 * connections.
 * 
 * 
 * @author ibirrer
 * @see JxtaEndpoint
 */
public final class JxtaServerEndpoint implements ServerEndpoint {

	/**
	 * pool of threads for executing tasks in system thread group: used for JXTA
	 * accept threads
	 */
	@SuppressWarnings("unchecked")
	private static final Executor systemThreadPool = (Executor) AccessController.doPrivileged(new GetThreadPoolAction(
			false));

	/** server connection manager */
	private static final ServerConnectionManagerFastMux serverConnectionManager = new ServerConnectionManagerFastMux();

	/** server transport logger */
	private static final Logger logger = Logger.getLogger("net.jini.jeri.tcp.server");

	/**
	 * Returns a <code>JxtaServerEndpoint</code> instance. All information
	 * about the peer and peer group is obtained statically from the
	 * {@link JxtaNetwork} class.
	 * 
	 * @return a <code>JxtaServerEndpoint</code> instance
	 */
	public static JxtaServerEndpoint getInstance() {
		return new JxtaServerEndpoint();
	}

	/**
	 * Constructs a new instance.
	 * 
	 * @see #getInstance()
	 */
	private JxtaServerEndpoint() {
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @throws NullPointerException
	 *             {@inheritDoc}
	 */
	public InvocationConstraints checkConstraints(InvocationConstraints constraints)
			throws UnsupportedConstraintException {
		return Constraints.check(constraints, true);
	}

	/**
	 * Passes the {@link net.jini.jeri.ServerEndpoint.ListenEndpoint
	 * ListenEndpoint} for this <code>JxtaServerEndpoint</code> to
	 * <code>listenContext</code>, which will ensure an active listen
	 * operation on the endpoint, and returns a <code>JxtaEndpoint</code>
	 * instance corresponding to the listen operation chosen by
	 * <code>listenContext</code>.
	 * 
	 * <p>
	 * This method invokes <code>addListenEndpoint</code> on
	 * <code>listenContext</code> once, passing a <code>ListenEndpoint</code>
	 * as described below. If <code>addListenEndpoint</code> throws an
	 * exception, then this method throws that exception. Otherwise, this method
	 * returns a <code>JxtaEndpoint</code> instance.
	 * 
	 * <p>
	 * The <code>ListenEndpoint</code> passed to
	 * <code>addListenEndpoint</code> behaves as follows:
	 * 
	 * <p>
	 * {@link net.jini.jeri.ServerEndpoint.ListenEndpoint#listen ListenHandle
	 * listen(RequestDispatcher)}:
	 * 
	 * <blockquote>
	 * 
	 * Listens for requests received on this endpoint, dispatching them to the
	 * supplied <code>RequestDispatcher</code> in the form of
	 * {@link InboundRequest} instances.
	 * 
	 * <p>
	 * When the implementation of this method needs to create a new
	 * <code>ServerSocket</code>, it will do so by creating a new
	 * JxtaServerSocket with the following arguments:
	 * {@link JxtaNetwork#getJeriPeerGroup()} and
	 * {@link JxtaNetwork#getJeriPipeAdvertisement()}.
	 * 
	 * <p>
	 * Requests will be dispatched in a {@link PrivilegedAction} wrapped by a
	 * {@link SecurityContext} obtained when this method was invoked, with the
	 * {@link AccessControlContext} of that <code>SecurityContext</code> in
	 * effect.
	 * 
	 * <p>
	 * Dispatched requests will implement {@link InboundRequest#populateContext
	 * populateContext} to populate the given collection with an element that
	 * implements the {@link ClientHost} interface. That <code>ClientHost</code>
	 * element implements {@link ClientHost#getClientHost getClientHost} to
	 * return the IP address of the <code>Socket</code> that the request was
	 * received over (see {@link Socket#getInetAddress}).
	 * 
	 * <p>
	 * Throws {@link IOException} if an I/O exception occurs while performing
	 * this operation.
	 * 
	 * <p>
	 * Throws {@link NullPointerException} if <code>requestDispatcher</code>
	 * is <code>null</code>
	 * 
	 * </blockquote>
	 * 
	 * <p>
	 * {@link net.jini.jeri.ServerEndpoint.ListenEndpoint#checkPermissions void
	 * checkPermissions()}:
	 * 
	 * <blockquote> Does not do any checks at all. </blockquote>
	 * 
	 * <p>
	 * {@link Object#equals boolean equals(Object)}:
	 * 
	 * <blockquote>
	 * 
	 * Compares the specified object with this <code>ListenEndpoint</code> for
	 * equality.
	 * 
	 * <p>
	 * This method returns <code>true</code> if and only if the specified
	 * object is also a <code>ListenEndpoint</code> produced by a
	 * <code>JxtaServerEndpoint</code> and is not null.
	 * 
	 * </blockquote>
	 * 
	 * @param listenContext
	 *            the <code>ListenContext</code> to pass this
	 *            <code>JxtaServerEndpoint</code>'s
	 *            <code>ListenEndpoint</code> to
	 * 
	 * @return the <code>JxtaEndpoint</code> instance for sending requests to
	 *         this <code>JxtaServerEndpoint</code>'s endpoint being listened
	 *         on
	 * 
	 * 
	 * @throws IOException
	 *             if an I/O exception occurs while performing this operation
	 * 
	 * 
	 * @throws IllegalArgumentException
	 *             {@inheritDoc}
	 * 
	 * @throws NullPointerException
	 *             {@inheritDoc}
	 */
	public Endpoint enumerateListenEndpoints(ListenContext listenContext) throws IOException {
		if (listenContext == null) {
			throw new NullPointerException();
		}

		LE listenEndpoint = new LE();
		ListenCookie listenCookie = listenContext.addListenEndpoint(listenEndpoint);

		if (!(listenCookie instanceof LE.Cookie)) {
			throw new IllegalArgumentException();
		}
		LE.Cookie cookie = (LE.Cookie) listenCookie;
		if (!listenEndpoint.equals(cookie.getLE())) {
			throw new IllegalArgumentException();
		}

		return JxtaEndpoint.getInstance(JxtaNetwork.getJeriPeerGroup().getPeerID());
	}

	/**
	 * Returns the hash code value for this <code>JxtaServerEndpoint</code>.
	 * Always returns the same value, because all JxtaServerEndpoints are the
	 * same.
	 * 
	 * @return the hash code value for this <code>JxtaServerEndpoint</code>.
	 *         Always returns <code>1</code>.
	 */
	@Override
	public int hashCode() {
		return 1;
	}

	/**
	 * Compares the specified object with this <code>JxtaServerEndpoint</code>
	 * for equality.
	 * 
	 * <p>
	 * This method returns <code>true</code> if and only if the specified
	 * object is also a <code>JxtaServerEndpoint</code> and is not null.
	 * 
	 * @param obj
	 *            the object to compare with
	 * 
	 * @return <code>true</code> if <code>obj</code> is equivalent to this
	 *         object; <code>false</code> otherwise
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj == this) {
			return true;
		} else if (!(obj instanceof JxtaServerEndpoint)) {
			return false;
		}
		return obj == null ? false : true;
	}

	/**
	 * Returns a string representation of this <code>JxtaServerEndpoint</code>.
	 * 
	 * @return a string representation of this <code>JxtaServerEndpoint</code>
	 */
	@Override
	public String toString() {
		return String.format("JxtaServerEndpoint[%s]", JxtaNetwork.getJeriPeerGroup().getPeerID());
	}

	/**
	 * ListenEndpoint implementation.
	 */
	private class LE implements ListenEndpoint {

		LE() {
		}

		public void checkPermissions() {
		}

		public ListenHandle listen(RequestDispatcher requestDispatcher) throws IOException {
			if (requestDispatcher == null) {
				throw new NullPointerException();
			}

			ServerSocket serverSocket = null;

			serverSocket = new JxtaServerSocket(JxtaNetwork.getJeriPeerGroup(), JxtaNetwork.getJeriPipeAdvertisement());
			serverSocket.setSoTimeout(0);

			if (logger.isLoggable(Level.FINE)) {
				logger.log(Level.FINE, ("created server socket {0}"), new Object[] { serverSocket });
			}

			Cookie cookie = new Cookie();
			final LH listenHandle = new LH(requestDispatcher, serverSocket, Security.getContext(), cookie);
			listenHandle.startAccepting();
			return listenHandle;
		}

		@Override
		public int hashCode() {
			return JxtaServerEndpoint.this.hashCode();
		}

		@Override
		public boolean equals(Object obj) {
			if (obj == this) {
				return true;
			} else if (!(obj instanceof LE)) {
				return false;
			}
			return obj == null ? false : true;
		}

		@Override
		public String toString() {
			return "JxtaServerEndpoint.LE[" + JxtaNetwork.getJeriPeerGroup().getPeerName() + "]";
		}

		/** ListenCookie implementation */
		private class Cookie implements ListenCookie {

			Cookie() {
			}

			LE getLE() {
				return LE.this;
			}

			@Override
			public String toString() {
				return "JxtaServerEndpoint.LE.Cookie[" + JxtaNetwork.getJeriPeerGroup().getPeerName() + "]";
			}
		}
	}

	/**
	 * ListenHandle implementation: represents a listen operation.
	 */
	private static class LH implements ListenHandle {

		private final RequestDispatcher requestDispatcher;

		private final ServerSocket serverSocket;

		private final SecurityContext securityContext;

		private final ListenCookie cookie;

		private long acceptFailureTime = 0L; // local to accept thread

		private int acceptFailureCount; // local to accept thread

		private final Object lock = new Object();

		private boolean closed = false;

		private final Set<ServerConnectionImpl> connections = new HashSet<ServerConnectionImpl>();

		LH(RequestDispatcher requestDispatcher,
				ServerSocket serverSocket,
				SecurityContext securityContext,
				ListenCookie cookie) {
			this.requestDispatcher = requestDispatcher;
			this.serverSocket = serverSocket;
			this.securityContext = securityContext;
			this.cookie = cookie;
		}

		/**
		 * Starts the accept loop.
		 */
		void startAccepting() {
			systemThreadPool.execute(new Runnable() {
				public void run() {
					try {
						executeAcceptLoop();
					} finally {
						/*
						 * The accept loop is only started once, so after no
						 * more socket accepts will occur, ensure that the
						 * server socket is no longer listening.
						 */
						try {
							serverSocket.close();
						} catch (IOException e) {
						}
					}
				}
			}, toString() + " accept loop");
		}

		/**
		 * Executes the accept loop.
		 */
		@SuppressWarnings("unchecked")
		private void executeAcceptLoop() {

			while (true) {
				Socket socket = null;
				try {

					socket = serverSocket.accept();
					if (logger.isLoggable(Level.FINE)) {
						logger.log(Level.FINE, "accepted socket {0} from server socket {1}", new Object[] { socket,
								serverSocket });
					}
					
					
					

					final ServerConnection serverConnection = new ServerConnectionImpl(socket);

					AccessController.doPrivileged(securityContext.wrap(new PrivilegedAction() {
						public Object run() {
							serverConnectionManager.handleConnection(serverConnection, requestDispatcher);
							return null;
						}
					}), securityContext.getAccessControlContext());

				} catch (Throwable t) {
					try {
						/*
						 * If this listen operation has been stopped, then we
						 * expect the socket accept to throw an exception, so
						 * just terminate normally.
						 */
						synchronized (lock) {
							if (closed) {
								break;
							}
						}

						try {
							if (logger.isLoggable(Level.WARNING)) {
								LogUtil.logThrow(
										logger,
										Level.WARNING,
										JxtaServerEndpoint.class,
										"executeAcceptLoop",
										"accept loop for {0} throws",
										new Object[] { serverSocket },
										t);
							}
						} catch (Throwable tt) {
						}
					} finally {
						/*
						 * Always close the accepted socket (if any) if an
						 * exception occurs, but only after logging an
						 * unexpected exception.
						 */
						if (socket != null) {
							try {
								socket.close();
							} catch (IOException e) {
							}
						}
					}

					if (!(t instanceof SecurityException)) {
						try {
							// NYI: shed idle connections
						} catch (OutOfMemoryError e) {
						} catch (Exception e) {
						}
					}

					/*
					 * A NoClassDefFoundError can occur if no file descriptors
					 * are available, in which case this loop should not
					 * terminate.
					 */
					boolean knownFailure = t instanceof Exception || t instanceof OutOfMemoryError
							|| t instanceof NoClassDefFoundError;
					if (knownFailure) {
						if (continueAfterAcceptFailure()) {
							continue;
						}
						return;
					}

					throw (Error) t;
				}
			}
		}

		/**
		 * Stops this listen operation.
		 */
		public void close() {
			synchronized (lock) {
				if (closed) {
					return;
				}
				closed = true;
			}

			try {
				serverSocket.close();
			} catch (IOException e) {
			}
			if (logger.isLoggable(Level.FINE)) {
				logger.log(Level.FINE, "closed server socket {0}", serverSocket);
			}

			/*
			 * Iterating over connections without synchronization is safe at
			 * this point because no other thread will access it without
			 * verifying that closed is false in a synchronized block first.
			 */
			for (Iterator i = connections.iterator(); i.hasNext();) {
				((ServerConnectionImpl) i.next()).close();
			}
		}

		/**
		 * Returns a cookie to identify this listen operation.
		 */
		public ListenCookie getCookie() {
			return cookie;
		}

		@Override
		public String toString() {
			return "JxtaServerEndpoint.LH[" + serverSocket + "]";
		}

		/**
		 * Throttles the accept loop after ServerSocket.accept throws an
		 * exception, and decides whether to continue at all. The current code
		 * is borrowed from the JRMP implementation; it always continues, but it
		 * delays the loop after bursts of failed accepts.
		 */
		private boolean continueAfterAcceptFailure() {
			/*
			 * If we get a burst of NFAIL failures in NMSEC milliseconds, then
			 * wait for ten seconds. This is to ensure that individual failures
			 * don't cause hiccups, but sustained failures don't hog the CPU in
			 * futile accept-fail-retry looping.
			 */
			final int NFAIL = 10;
			final int NMSEC = 5000;
			long now = System.currentTimeMillis();
			if (acceptFailureTime == 0L || (now - acceptFailureTime) > NMSEC) {
				// failure time is very old, or this is first failure
				acceptFailureTime = now;
				acceptFailureCount = 0;
			} else {
				// failure window was started recently
				acceptFailureCount++;
				if (acceptFailureCount >= NFAIL) {
					try {
						Thread.sleep(10000);
					} catch (InterruptedException ignore) {
					}
					// no need to reset counter/timer
				}
			}
			return true;
		}

		/**
		 * ServerConnection implementation.
		 * 
		 * Instances of this class should never get exposed to anything other
		 * than our ServerConnectionManager, which we trust to operate
		 * correctly, so we do not bother to validate request handles passed in.
		 */
		private class ServerConnectionImpl implements ServerConnection {

			private final Socket socket;

			// socket attributes cached to work around 4720952:
			private final InetAddress socketInetAddress;

			ServerConnectionImpl(Socket socket) {
				this.socket = socket;
				socketInetAddress = socket.getInetAddress();
				addToConnectionSet();
			}

			public InputStream getInputStream() throws IOException {
				return socket.getInputStream();
			}

			public OutputStream getOutputStream() throws IOException {
				return socket.getOutputStream();
			}

			public SocketChannel getChannel() {
				return socket.getChannel();
			}

			public InboundRequestHandle processRequestData(InputStream in, OutputStream out) {
				return new InboundRequestHandle() {
				};
			}

			public void checkPermissions(InboundRequestHandle handle) {

			}

			public InvocationConstraints checkConstraints(InboundRequestHandle handle, InvocationConstraints constraints)
					throws UnsupportedConstraintException {
				/*
				 * The transport layer aspects of all constraints supported by
				 * this transport provider are always satisfied by all requests
				 * on the server side, so this method can have the same static
				 * behavior as ServerCapabilities.checkConstraints does.
				 * (Otherwise, this operation would need to be parameterized by
				 * this connection or the request.)
				 */
				return Constraints.check(constraints, true);
			}

			public void populateContext(InboundRequestHandle handle, Collection context) {
				Util.populateContext(context, socketInetAddress);
			}

			public void close() {
				try {
					socket.close(); // this will bring multiplexer down too
				} catch (IOException e) {
				}
				if (logger.isLoggable(Level.FINE)) {
					logger.log(Level.FINE, "closed socket {0}", socket);
				}

				synchronized (lock) {
					if (!closed) { // must not mutate set after closed
						connections.remove(this);
					}
				}
			}

			private void addToConnectionSet() {
				boolean needClose = false;
				synchronized (lock) {
					if (closed) {
						needClose = true; // close after releasing lock
					} else {
						connections.add(this);
					}
				}
				if (needClose) {
					close();
				}
			}
		}
	}
}
