/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
/*
 * 
 * Copyright 2005 Sun Microsystems, Inc.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * 	http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */

package org.eodisp.remote.jeri.connection.nomux;

import java.io.*;
import java.security.AccessController;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import sun.security.util.PendingException;

import net.jini.core.constraint.InvocationConstraint;
import net.jini.core.constraint.InvocationConstraints;
import net.jini.jeri.Endpoint;
import net.jini.jeri.OutboundRequest;
import net.jini.jeri.OutboundRequestIterator;
import net.jini.jeri.connection.Connection;
import net.jini.jeri.connection.ConnectionEndpoint;
import net.jini.jeri.connection.OutboundRequestHandle;

import com.sun.jini.action.GetLongAction;
import com.sun.jini.jeri.internal.mux.MuxClient;
import com.sun.jini.logging.Levels;
import com.sun.jini.thread.Executor;
import com.sun.jini.thread.GetThreadPoolAction;

/**
 * Provides client-side connection management using the <a href="{@docRoot}/net/jini/jeri/connection/doc-files/mux.html">Jini(TM)
 * extensible remote invocation (Jini ERI) multiplexing protocol</a> to frame
 * and multiplex requests and responses over connections.
 * 
 * <p>
 * A <code>ConnectionManager</code> is created by a connection-based
 * {@link Endpoint} implemention to manage connections to a particular
 * {@link ConnectionEndpoint}. The {@link #newRequest newRequest} method is
 * used to send a request to the connection endpoint.
 * 
 * <p>
 * Each request attempt is mapped to a new <i>session</i> of the Jini ERI
 * multiplexing protocol on an established connection chosen by the
 * <code>ConnectionEndpoint</code>. Request data is written as the data sent
 * for the session, and response data is read as the data recdeived for the
 * session.
 * 
 * @author Sun Microsystems, Inc.
 * @since 2.0
 * 
 * @com.sun.jini.impl
 * 
 * This implementation uses the {@link Logger} named
 * <code>net.jini.jeri.connection.ConnectionManager</code> to log information
 * at the following levels:
 * 
 * <p>
 * <table summary="Describes what is logged by ConnectionManager to its logger
 * at various logging levels" border=1 cellpadding=5>
 * 
 * <tr>
 * <th> Level
 * <th> Description
 * 
 * <tr>
 * <td> {@link Level#FINEST FINEST}
 * <td> connection opened or reused
 * 
 * </table>
 * 
 * <p>
 * This implementation uses the {@link Logger} named
 * <code>net.jini.jeri.connection.mux</code> to log information at the
 * following levels:
 * 
 * <p>
 * <table summary="Describes what is logged by ConnectionManager to the mux
 * logger at various logging levels" border=1 cellpadding=5>
 * 
 * <tr>
 * <th> Level
 * <th> Description
 * 
 * <tr>
 * <td> {@link Level#WARNING WARNING}
 * <td> unexpected exception during asynchronous I/O processing, or thread
 * creation failure
 * 
 * <tr>
 * <td> {@link Levels#HANDLED HANDLED}
 * <td> I/O exception during asynchronous I/O processing
 * 
 * <tr>
 * <td> {@link Level#FINEST FINEST}
 * <td> detailed implementation activity
 * 
 * </table>
 * 
 * <p>
 * This implementation recognizes the following system properties:
 * 
 * <p>
 * <ul>
 * 
 * <li><code>com.sun.jini.jeri.connectionTimeout</code> - Time in
 * milliseconds to leave idle client-side connections around before closing
 * them. The default value is 15000 milliseconds (15 seconds).
 * 
 * </ul>
 */
public final class ConnectionManagerNoMux {
	/**
	 * How long to leave idle muxes around before closing them.
	 */
	private static final long TIMEOUT = ((Long) AccessController.doPrivileged(new GetLongAction(
			"com.sun.jini.jeri.connectionTimeout",
			15000))).longValue();

	/**
	 * ConnectionManager logger.
	 */
	private static final Logger logger = Logger.getLogger("net.jini.jeri.connection.ConnectionManager");

	/**
	 * Executor that executes tasks in pooled system threads.
	 */
	private static final Executor systemThreadPool = (Executor) AccessController.doPrivileged(new GetThreadPoolAction(
			false));

	/**
	 * The endpoint.
	 */
	private final ConnectionEndpoint ep;

	/**
	 * The OutboundMuxes.
	 */
	private final List connectionWrappers = new ArrayList(1);

	/**
	 * The active connections (during connect).
	 */
	private final List active = new ArrayList(1);

	/**
	 * Unmodifiable view of active.
	 */
	private final Collection roactive = Collections.unmodifiableCollection(active);

	/**
	 * The idle connections (during connect).
	 */
	private final List idle = new ArrayList(1);

	/**
	 * Unmodifiable view of idle.
	 */
	private final Collection roidle = Collections.unmodifiableCollection(idle);

	/**
	 * Number of pending connect calls.
	 */
	private int pendingConnects = 0; // REMIND: no longer necessary?

	// private Reaper reaper = null; // non-null if reaper running

	/**
	 * Creates a new <code>ConnectionManager</code> that manages client-side
	 * connections to the specified connection endpoint.
	 * 
	 * @param ep
	 *            the connection endpoint
	 */
	public ConnectionManagerNoMux(ConnectionEndpoint ep) {
		this.ep = ep;
	}

	/**
	 * Registers a pending connect call.
	 */
	synchronized void connectPending() {
		pendingConnects++;
	}

	/**
	 * Calls connect on the connection endpoint with the active and idle muxes
	 * and the specified handle. If no connection is returned, calls connect
	 * with the handle. In either case, if a new connection is returned, creates
	 * and adds a mux for it. In all cases, bumps the newRequest count for the
	 * mux and returns it. Removes any dead muxes along the way.
	 */
	ConnectionWrapper connect(OutboundRequestHandle handle) throws IOException {
		try {
			synchronized (this) {
				active.clear();
				idle.clear();
				for (int i = connectionWrappers.size(); --i >= 0;) {
					ConnectionWrapper mux = (ConnectionWrapper) connectionWrappers.get(i);
					if (mux.isIdle()) {
						idle.add(mux.getConnection());
					}
				}
				Connection c = ep.connect(handle, roactive, roidle);
				if (c != null) {
					for (int i = connectionWrappers.size(); --i >= 0;) {
						ConnectionWrapper connectionWrapper = (ConnectionWrapper) connectionWrappers.get(i);
						if (c == connectionWrapper.getConnection()) {
							if (logger.isLoggable(Level.FINEST)) {
								logger.log(Level.FINEST, "using {0}", c);
							}
							// connectionWrapper.newRequestPending();
							return connectionWrapper;
						}
					}
					ConnectionWrapper connectionWrapper = ConnectionWrapper.create(c);
					// connectionWrapper.newRequestPending();
					// if (reaper == null) {
					// reaper = new Reaper();
					// systemThreadPool.execute(reaper, "ConnectionManager[" +
					// ep + "].Reaper");
					// }
					connectionWrappers.add(connectionWrapper);
					return connectionWrapper;
				}
			}
			Connection c = ep.connect(handle);
			ConnectionWrapper connectionWrapper = ConnectionWrapper.create(c);
			// connectionWrapper.newRequestPending();
			synchronized (this) {
				// if (reaper == null) {
				// reaper = new Reaper();
				// systemThreadPool.execute(reaper, "ConnectionManager[" + ep +
				// "].Reaper");
				// }
				connectionWrappers.add(connectionWrapper);
			}
			return connectionWrapper;
		} finally {
			synchronized (this) {
				assert pendingConnects > 0;
				pendingConnects--;
			}
		}
	}

	// /**
	// * For each mux, calls checkIdle on the mux, and if checkIdle returns
	// true,
	// * removes the mux and adds it to the idle list. Returns true if no
	// connects
	// * are pending and no muxes remain.
	// */
	// synchronized boolean checkIdle(long now, List idle) {
	// for (int i = connectionWrappers.size(); --i >= 0;) {
	// ConnectionWrapper mux = (ConnectionWrapper) connectionWrappers.get(i);
	// if (mux.checkIdle(now)) {
	// connectionWrappers.remove(i);
	// idle.add(mux);
	// }
	// }
	// return pendingConnects == 0 && connectionWrappers.isEmpty();
	// }

	/**
	 * Removes a connectionWrapper
	 */
	void remove(ConnectionWrapper connectionWrapper) {
		synchronized (this) {
			connectionWrappers.remove(connectionWrapper);
		}
	}

	/**
	 * Subclass wrapper around MuxClient for outbound connections.
	 */
	private static final class ConnectionWrapper {
		private final class OutboundRequestWrapper implements OutboundRequest {
			boolean aborted = false;

			private InputStream in = new Input();

			private OutputStream out = new Output();

			private final class Input extends InputStream {
				@Override
				public int read(byte[] b) throws IOException {
					return c.getInputStream().read(b);
				}

				@Override
				public int read(byte[] b, int off, int len) throws IOException {
					return c.getInputStream().read(b, off, len);
				}

				@Override
				public int read() throws IOException {
					return c.getInputStream().read();
				}

				@Override
				public void close() throws IOException {
					// TODO: sync
					System.out.println("close request input stream on client");
					idle = true;
				}
			}

			private final class Output extends OutputStream {
				
				OutputStream thisout = null;
				
				public Output() {
					try {
						thisout = c.getOutputStream();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
				@Override
				public void write(int b) throws IOException {
					thisout.write(b);
				}

				@Override
				public void write(byte[] b) throws IOException {
					thisout.write(b);
				}

				@Override
				public void write(byte[] b, int off, int len) throws IOException {
					thisout.write(b, off, len);
				}
				
				@Override
				public void flush() throws IOException {
					System.out.println("flush output stream on client");
					thisout.flush();
				}

				@Override
				public void close() throws IOException {
					System.out.println("close request output stream on client. no aborting yet");
					thisout.flush();
					// abort();
				}
			}

			public void populateContext(Collection context) {
				// TODO Auto-generated method stub

			}

			public InvocationConstraints getUnfulfilledConstraints() {
				// TODO Auto-generated method stub
				return new InvocationConstraints(new InvocationConstraint[] {}, new InvocationConstraint[] {});
			}

			public OutputStream getRequestOutputStream() {
				return out;
			}

			public InputStream getResponseInputStream() {
				return in;
			}

			public boolean getDeliveryStatus() {
				// TODO Auto-generated method stub
				return false;
			}

			public void abort() {
				// we need to make sure that no more data is written using this
				// outbound request
				aborted = true;
				idle = true;
			}

		}

		/**
		 * The outbound connection.
		 */
		private final Connection c;

		/**
		 * Status of the current connection
		 */
		private boolean idle = true;

		/**
		 * Constructs an instance from the connection's streams.
		 */
		private ConnectionWrapper(Connection c) {
			this.c = c;
		}

		/**
		 * Constructs an instance from the connection's channel.
		 */
		private ConnectionWrapper(Connection c, boolean ignore) {
			// TODO: not implemented, same as other constructor
			this.c = c;
		}

		/**
		 * Constructs an instance from the connection wrapper.
		 */
		static ConnectionWrapper create(Connection c) throws IOException {
			System.out.println("Create new connection wrapper");
			logger.log(Level.FINEST, "opened {0}", c);
			ConnectionWrapper connectionWrapper = null;
			try {
				connectionWrapper = (c.getChannel() == null) ? new ConnectionWrapper(c)
						: new ConnectionWrapper(c, true);
			} finally {
				if (connectionWrapper == null) {
					try {
						c.close();
					} catch (IOException e) {
					}
				}
			}
			return connectionWrapper;
		}

		public synchronized boolean isIdle() {
			return idle;
		}

		/**
		 * Returns the outbound connection.
		 */
		Connection getConnection() {
			return c;
		}

		/**
		 * Initiates a new request on the connection and returns it, and sets
		 * the idle time to zero.Decrements the pending newRequest count.
		 */
		public synchronized OutboundRequest newRequest() throws IOException {
			idle = false;
			System.out.println("New request on client");
			return new OutboundRequestWrapper();
		}

		// /**
		// * Returns true if the mux is dead, or the mux is idle and the
		// recorded
		// * idle time is more than TIMEOUT milliseconds before now, and returns
		// * false otherwise. If the mux is idle and the recorded idle time is
		// * zero, sets the recorded idle time to now.
		// */
		// synchronized boolean checkIdle(long now) {
		// try {
		// if (requestsInProgress() == 0) {
		// if (idleTime == 0) {
		// idleTime = now;
		// } else {
		// return now - idleTime > TIMEOUT;
		// }
		// }
		// return false;
		// } catch (IOException e) {
		// return true;
		// }
		// }

		/**
		 * Close the connection, so that the provider is notified.
		 */
		protected void handleDown() {
			try {
				c.close();
			} catch (IOException e) {
			}
		}

		boolean shouldRetry() {
			return false; // XXX
		}
	}

	// /**
	// * Records idle times in connectionWrappers and shuts down connection
	// wrappers that have been idle for
	// * at least TIMEOUT milliseconds.
	// *
	// * REMIND: It should be possible to have a shared reaper once again, with
	// * some care regarding GC issues.
	// */
	// private final class Reaper implements Runnable {
	// Reaper() {
	// }
	//
	// /**
	// * Sleep for TIMEOUT milliseconds. Then call checkIdle, shutdown all of
	// * idle muxes that have been collected, and if checkIdle returned true,
	// * terminate, else repeat (go back to sleep).
	// */
	// public void run() {
	// List idle = new ArrayList(1);
	// boolean done;
	// do {
	// try {
	// Thread.sleep(TIMEOUT);
	// } catch (InterruptedException e) {
	// return;
	// }
	// long now = System.currentTimeMillis();
	// synchronized (ConnectionManager.this) {
	// checkIdle(now, idle);
	// done = connectionWrappers.isEmpty();
	// if (done) {
	// reaper = null;
	// }
	// }
	// for (int i = idle.size(); --i >= 0;) {
	// ((ConnectionWrapper) idle.get(i)).shutdown("idle");
	// }
	// idle.clear();
	// } while (!done);
	// }
	// }

	/**
	 * Outbound request iterator returned by newRequest.
	 */
	private final class ReqIterator implements OutboundRequestIterator {
		/**
		 * The request handle.
		 */
		private final OutboundRequestHandle handle;

		/**
		 * True if next has not yet been called.
		 */
		private boolean first = true;

		/**
		 * The outbound mux from the last call to next, if any.
		 */
		private ConnectionWrapper connectionWrapper;

		ReqIterator(OutboundRequestHandle handle) {
			this.handle = handle;
		}

		/**
		 * Returns true if next has not yet been called or if the last mux
		 * returned had an asynchronous close.
		 */
		public synchronized boolean hasNext() {
			return first || (connectionWrapper != null && connectionWrapper.shouldRetry());
		}

		/**
		 * If hasNext returns true, finds the entry (if any) for the connection
		 * endpoint. If no entry is found, creates one and spawns a Reaper if
		 * this is the only entry. Either way, bumps the connect count for the
		 * entry. Calls connect on the entry to get a mux, then calls newRequest
		 * on the mux, calls writeRequestData on the connection, and returns a
		 * new outbound request wrapper.
		 */
		public synchronized OutboundRequest next() throws IOException {
			if (!hasNext()) {
				throw new NoSuchElementException();
			}
			first = false;
			connectionWrapper = null;
			connectPending();
			connectionWrapper = connect(handle);
			OutboundRequest req = connectionWrapper.newRequest();
			OutboundRequest sreq = null;
			try {
				Connection c = connectionWrapper.getConnection();
				c.writeRequestData(handle, req.getRequestOutputStream());
				// sreq = new Outbound(req, c, handle);
			} finally {
				// TODO ???
				// if (sreq == null) {
				// remove(mux);
				// }
			}
			return req;
		}
	}

	/**
	 * Returns an <code>OutboundRequestIterator</code> to use to send a new
	 * request for the specified handle to this connection manager's
	 * <code>ConnectionEndpoint</code>.
	 * 
	 * <p>
	 * If the <code>hasNext</code> method of the returned iterator returns
	 * <code>true</code>, the <code>next</code> method behaves as follows:
	 * 
	 * <blockquote>
	 * 
	 * The connection endpoint's {@link
	 * ConnectionEndpoint#connect(OutboundRequestHandle,Collection,Collection)
	 * connect} method is invoked with any active connections that have not
	 * reached their maximum number of in-progress requests, any idle
	 * connections, and <code>handle</code>. If that returns
	 * <code>null</code>, the endpoint's {@link
	 * ConnectionEndpoint#connect(OutboundRequestHandle) connect} method is
	 * invoked with <code>handle</code>. In either case, if a new connection
	 * is returned, the Jini ERI multiplexing protocol is started on the
	 * connection (as the client). Finally, the
	 * {@link Connection#writeRequestData writeRequestData} method of the
	 * connection is invoked with <code>handle</code> and the request output
	 * stream of the {@link OutboundRequest} that is created for the request. If
	 * any exception is thrown while obtaining a connection from the endpoint or
	 * writing the request data, that exception is thrown to the caller. The
	 * <code>OutboundRequest</code> returned by <code>next</code> will
	 * invoke the {@link Connection#readResponseData readResponseData} method of
	 * the connection with the specified handle and the response input stream
	 * before any other data is read from the response input stream. The
	 * {@link OutboundRequest#populateContext populateContext} and {@link
	 * OutboundRequest#getUnfulfilledConstraints getUnfulfilledConstraints}
	 * methods of the <code>OutboundRequest</code> are implemented by
	 * delegating to the corresponding method of the connection passing
	 * <code>handle</code> and the other arguments (if any).
	 * 
	 * </blockquote>
	 * 
	 * <p>
	 * The returned iterator might allow continued iteration if the connection
	 * used for the most recent request attempt was shut down gracefully by the
	 * server.
	 * 
	 * @param handle
	 *            a handle to identify the request in later invocations on the
	 *            connection endpoint and its connections
	 * 
	 * @return an <code>OutboundRequestIterator</code> to use to send a new
	 *         request for the specified handle to this connection manager's
	 *         <code>ConnectionEndpoint</code>
	 * 
	 * @throws NullPointerException
	 *             if <code>handle</code> is <code>null</code>
	 */
	public OutboundRequestIterator newRequest(OutboundRequestHandle handle) {
		return new ReqIterator(handle);
	}
}
