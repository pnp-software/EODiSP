/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com
 *  mail: info@pnp-software.com
 */

package org.eodisp.remote.util;

import java.io.IOException;
import java.io.OutputStream;


/**
 * 
 * 
 * @author ibirrer
 *
 */
public class LoggedOutputStream extends OutputStream {
	private OutputStream out;
//	private long timeBeforeWrite;
    int flushes = 0;

	public LoggedOutputStream(OutputStream out) {
		this.out = out;
	}

	@Override
	public void close() throws IOException {
		System.out.println("OuptutStreamLogger: out.close()");
		out.close();
	}

	@Override
	public void flush() throws IOException {
        System.out.printf("Flush: %d%n", flushes);
        flushes++;
        out.flush();
//        if( flushes % 4 == 0 ) {
//            System.out.printf("OuptutStreamLogger: out.flush(): %dms%n", System.currentTimeMillis() - timeBeforeWrite);
//            out.flush();
//        }
	}

	@Override
	public void write(byte[] b, int off, int len) throws IOException {
		System.out.printf("OuptutStreamLogger: out.write(%d, %d, %d)", b.length, off, len);
//		if( len == 4 ) {
//			timeBeforeWrite = System.currentTimeMillis();
//		}
		out.write(b, off, len);
	}

	@Override
	public void write(byte[] b) throws IOException {
		System.out.printf("OuptutStreamLogger: out.writeByte(%d)", b.length);
		out.write(b);
	}

	@Override
	public void write(int b) throws IOException {
		System.out.printf("OuptutStreamLogger: out.write(%d)", b);
		out.write(b);
	}
}
