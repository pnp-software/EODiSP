/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.remote.registry;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import java.net.URI;
import java.net.URISyntaxException;
import java.rmi.server.ExportException;
import java.util.EnumSet;

import net.jini.core.constraint.MethodConstraints;
import net.jini.export.Exporter;
import net.jini.jeri.*;
import net.jini.jeri.tcp.TcpEndpoint;
import net.jini.jeri.tcp.TcpServerEndpoint;
import net.jxta.id.IDFactory;
import net.jxta.peer.PeerID;

import org.eodisp.remote.config.RemoteConfiguration.TransportType;
import org.eodisp.remote.jeri.jxta.JxtaEndpoint;
import org.eodisp.remote.jeri.jxta.JxtaServerEndpoint;

/**
 * This is a similar class as the {@link java.rmi.registry.LocateRegistry} from
 * standard java RMI. It provides static methods to create a new JeriRegistry in
 * the current JVM and to get proxies of registries exported in other JVMs. The
 * returned registry is API compatible with the registry used in standard RMI.
 * However it is not possible to get a proxy to a registry that was exported
 * with standard RMI using this class.
 * 
 * <p>
 * A registry can be exported on different transports, but only one registry
 * implementation is being instantiated per JVM. The
 * <code>createXXXRegistry</code> methods (i.e.
 * <code>createTcpRegistry()</code>>) only create a new registry if none was
 * created before and export the registry on the given transport.
 * 
 * <p>
 * The {@link #getRegistry(URI)} method can be used to receive a proxy of a
 * remote registry. The transport to be used is encoded in the URI. See the
 * method description for more information.
 * 
 * <p>
 * 
 * 
 * @author ibirrer
 * @version $Id:$
 */
public class LocateJeriRegistry {

	private static JeriRegistry registry;

	private static JeriRegistry tcpRegistryProxy;

	private static JeriRegistry jxtaRegistryProxy;

	private static Exporter tcpExporter;

	private static Exporter jxtaExporter;

	/**
	 * Returns a reference to the the remote <code>JeriRegistry</code>
	 * exported on the given URI. Supported transports are <code>tcp</code>
	 * and <code>jxta</code>. For tcp use an URI of the form:
	 * <code>tcp://host:port</code>, e.g: <code>tcp:localhost:6789</code>.
	 * For JXTA, the peer id of the peer that exports the registry must be
	 * specified. For example:
	 * <code>urn:jxta:uuid-37AB0CEE1A5444728150BB2E14082E7AB251EEA11B984C4FA4DAD070711FBA4603</code>
	 * 
	 * <p>
	 * Distributed garbage collection is disabled on the returned proxy.
	 * 
	 * 
	 * @param uri
	 *            An URI specifying the remote location of the registry.
	 * 
	 * @param methodConstraints
	 *            Method constraint to be set for the returned proxy. This is
	 *            especially useful for JXTA proxies, to define a connection
	 *            timeout other than infinite:
	 * 
	 * <pre>
	 * InvocationConstraints invocationConstraints = new InvocationConstraints(new ConnectionRelativeTime(1000), null);
	 * 
	 * MethodConstraints methodConstraints = new BasicMethodConstraints(invocationConstraints);
	 * </pre>
	 * 
	 * @return reference (a stub) to the remote object registry
	 * 
	 * @throws URISyntaxException
	 *             Thrown if any of the following is true:
	 *             <ul>
	 *             <li>The scheme of the given URI is not supported. Supported
	 *             schemes are: <code>tcp</code> and <code>urn:jxta</code></li>
	 *             <li>If no port or no host is given for a tcp URI</li>
	 *             <li>If the given peer id URI is not a valid peer id. See
	 *             {@link IDFactory#fromURI(java.net.URI)}</li>
	 *             </ul>
	 * 
	 */
	public static JeriRegistry getRegistry(URI uri, MethodConstraints methodConstraints) throws URISyntaxException {
		Class[] registryInterface = { JeriRegistry.class };
		Endpoint endpoint;
		switch (getTransportType(uri)) {
		case JXTA:
			endpoint = JxtaEndpoint.getInstance((PeerID) IDFactory.fromURI(uri));
			break;
		case TCP:
			endpoint = TcpEndpoint.getInstance(uri.getHost(), uri.getPort());
			break;
		default:
			throw new URISyntaxException(uri.toString(), "Could not get jeri endpoint");
		}

		BasicObjectEndpoint objectEndpoint = new BasicObjectEndpoint(endpoint, JeriRegistryImpl.REGISTRY_UUID, false);
		InvocationHandler invocationHandler = new BasicInvocationHandler(objectEndpoint, methodConstraints);
		JeriRegistry registryProxy = (JeriRegistry) Proxy.newProxyInstance(Thread
				.currentThread()
				.getContextClassLoader(), registryInterface, invocationHandler);
		return registryProxy;
	}

	public static TransportType getTransportType(URI uri) throws URISyntaxException {
		String uriScheme = uri.getScheme();
		if (uriScheme == null) {
			throw new URISyntaxException(uri.toString(), "URI scheme must not be null. Use tcp or urn:jxta");
		}
		if (uriScheme.equals("urn")) {
			return TransportType.JXTA;
		} else if (uriScheme.equals("tcp")) {
			if (uri.getPort() == -1) {
				throw new URISyntaxException(uri.toString(), "No port defined in in TCP URI");
			}
			if (uri.getHost() == null) {
				throw new URISyntaxException(uri.toString(), "No host defined in in TCP URI");
			}
			return TransportType.TCP;
		} else {
			throw new URISyntaxException(uri.toString(), String.format(
					"URI scheme % is not supported. Use tcp or urn:jxta",
					uriScheme));
		}
	}

	/**
	 * Returns a reference to the the remote <code>JeriRegistry</code>
	 * exported on the given URI. Supported transports are <code>tcp</code>
	 * and <code>jxta</code>. For tcp use an URI of the form:
	 * <code>tcp://host:port</code>, e.g: <code>tcp:localhost:6789</code>.
	 * For JXTA, the peer id of the peer that exports the registry must be
	 * specified. For example:
	 * <code>urn:jxta:uuid-37AB0CEE1A5444728150BB2E14082E7AB251EEA11B984C4FA4DAD070711FBA4603</code>
	 * 
	 * <p>
	 * Distributed garbage collection is disabled on the returned proxy.
	 * 
	 * <p>
	 * No <code>MethodConstraints</code> are being defined on the returned
	 * registry proxy. Use {@link #getRegistry(URI, MethodConstraints)} to do
	 * so.
	 * 
	 * @param uri
	 *            An URI specifying the remote location of the registry.
	 * 
	 * @return reference (a stub) to the remote object registry
	 * 
	 * @throws URISyntaxException
	 *             Thrown if any of the following is true:
	 *             <ul>
	 *             <li>The scheme of the given URI is not supported. Supported
	 *             schemes are: <code>tcp</code> and <code>urn:jxta</code></li>
	 *             <li>If not port or not host is given for a tcp URI</li>
	 *             <li>If the given peer id URI is not a valid peer id. See
	 *             {@link IDFactory#fromURI(java.net.URI)}</li>
	 *             </ul>
	 * 
	 */
	public static JeriRegistry getRegistry(URI uri) throws URISyntaxException {
		return getRegistry(uri, null);
	}

	/**
	 * Exports the <code>JeriRegistry</code> instance of the this JVM on peer
	 * that is defined for this JVM. See
	 * {@link org.eodisp.remote.jeri.jxta.JxtaNetwork} to see how the peer id is
	 * registered with a JVM.
	 * 
	 * <p>
	 * Creating a registry does not keep the JVM alive.
	 * 
	 * @return the registry
	 * @deprecated use RemoteAppModule
	 * @throws ExportException
	 * @exception RemoteException
	 *                if the registry could not be exported
	 */
	public static JeriRegistry createJxtaRegistry() throws ExportException {
		if (jxtaRegistryProxy == null) {
			ServerEndpoint serverEndpoint = JxtaServerEndpoint.getInstance();
			jxtaExporter = newRegistryExporter(serverEndpoint);
			jxtaRegistryProxy = (JeriRegistry) jxtaExporter.export(createRegistry(TransportType.JXTA));
		}

		return jxtaRegistryProxy;
	}

	/**
	 * Lacy creation of the registry.
	 * 
	 * @return A reference to this JVM's registry.
	 */
	private static JeriRegistry createRegistry(TransportType favoriteTransport) {
		if (registry == null) {
			registry = new JeriRegistryImpl(EnumSet.of(favoriteTransport), favoriteTransport);
		}
		return registry;
	}

	/**
	 * Exports the <code>JeriRegistry</code> instance of the this JVM on the
	 * local host that accepts requests on the specified <code>port</code>.
	 * 
	 * <p>
	 * Creating a registry does not keep the JVM alive.
	 * 
	 * @param port
	 *            the port on which the registry accepts requests
	 * @return the registry
	 * @deprecated use RemoteAppModule
	 * @throws ExportException
	 *             if the registry could not be exported
	 */
	public static JeriRegistry createTcpRegistry(int port) throws ExportException {
		if (tcpRegistryProxy == null) {
			ServerEndpoint serverEndpoint = TcpServerEndpoint.getInstance(port);
			// Export JeriRegistry
			tcpExporter = newRegistryExporter(serverEndpoint);
			tcpRegistryProxy = (JeriRegistry) tcpExporter.export(createRegistry(TransportType.TCP));
		}

		return tcpRegistryProxy;
	}

	public static void destroyRegistry() {
		if (tcpExporter != null) {
			tcpExporter.unexport(true);
		}
		if (jxtaExporter != null) {
			jxtaExporter.unexport(true);
		}
		registry = null;
		tcpRegistryProxy = null;
		jxtaRegistryProxy = null;
	}

	/**
	 * Keep Alive and distributed garbage collection is disabled (A strong
	 * reference to the registry is defined in this class statically and is
	 * never being garbage collected).
	 */
	private static Exporter newRegistryExporter(ServerEndpoint serverEndpoint) {
		Exporter exporter = new BasicJeriExporter(
				serverEndpoint,
				new BasicILFactory(),
				false,
				false,
				JeriRegistryImpl.REGISTRY_UUID);
		return exporter;
	}
}
