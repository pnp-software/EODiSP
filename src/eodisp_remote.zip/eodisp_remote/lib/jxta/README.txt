This folder contains all jar files that are needed to run jxta. 
Jar files which are used in common, by the ERTI implementation 
and JXTA (e.g. log4j.jar), are placed in their own subdirectory 
in the lib folder and not included here.