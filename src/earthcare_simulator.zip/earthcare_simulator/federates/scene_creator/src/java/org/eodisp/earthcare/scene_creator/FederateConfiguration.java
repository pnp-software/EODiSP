/**
 * 
 */
package org.eodisp.earthcare.scene_creator;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.eodisp.util.configuration.ConfigurationImpl;

/**
 * @author ibirrer
 * 
 */
public class FederateConfiguration extends ConfigurationImpl {
	private static final String INIT_DATA = "init-data";

	/**
	 * The Id of this configuration.This id can be used to retrieve the
	 * configuration entries.
	 */
	public static final String ID = FederateConfiguration.class.getName();

	/**
	 * The name of the configuration. This will be shown on the command line.
	 */
	public static final String NAME = "Federate Configuration";

	/**
	 * Describes the configuration. This will be shown on the command line.
	 */
	public static final String DESCRIPTION = "Federate Configuration";

	private static final String FEDERATION_EXECUTION = "federation-execution";

	/**
	 * {@inheritDoc}
	 */
	public FederateConfiguration(File file) {
		super(ID, NAME, DESCRIPTION, file);
		createEntry(FEDERATION_EXECUTION, "DefaultFederationExecution",
				"The federation execution that this federate shall join");
		createFilelistEntry(INIT_DATA, new ArrayList<File>(),
				"Input files for this federate");
	}

	public static void main(String[] args) {
		System.out.println(new FederateConfiguration(null).getCode());
	}

	public String getFederationExecution() {
		return getEntry(FEDERATION_EXECUTION).getValue();
	}

	public void setFederationExecution(String federationExecution) {
		getEntry(FEDERATION_EXECUTION).setValue(federationExecution);
	}

	public List<File> getInitData() {
		return getEntry(INIT_DATA).getFilelist();
	}
}
