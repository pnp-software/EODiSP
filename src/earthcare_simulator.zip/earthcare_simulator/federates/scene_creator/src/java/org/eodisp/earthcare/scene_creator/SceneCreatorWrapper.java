/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.earthcare.scene_creator;

import java.io.File;
import java.io.IOException;

import org.apache.tools.ant.types.Commandline;
import org.eodisp.earthcare.common.util.*;
import org.eodisp.util.launcher.Process;
import org.eodisp.util.launcher.ProcessImpl;

/**
 * Wrapper wrapper for the the <code>scene_creator</code> executable of the
 * EarthCARE simulator.
 * 
 * @author ibirrer
 */
public class SceneCreatorWrapper extends AbstractEarthcareWrapper {
	private static final int XYZ_EXTENT_LINE = 5;

	private static final int HORIZONTAL_RESOLUTION_LINE = 6;

	private static final String EXECUTABLE = "scene_creator";

	private final LineEditor sceneCreatorInputEditor = new LineEditor();

	/**
	 * Sets the horizontal resolution of the scene
	 * 
	 * @param horizontalResolution
	 *            The horizontalResolution in km
	 */
	public void setHorizontalResolution(double horizontalResolution) {
		sceneCreatorInputEditor.addLineReplacement(HORIZONTAL_RESOLUTION_LINE, horizontalResolution + "");
	}

	/**
	 * Sets the x, y and z extent of the scene.
	 * 
	 * @param xExtent
	 *            the xExtent in km
	 * @param yExtent
	 *            the yExtent in km
	 * @param zExtent
	 *            the zExtent in km
	 */
	@SuppressWarnings("boxing")
	public void setExtent(double xExtent, double yExtent, double zExtent) {
		sceneCreatorInputEditor.addLineReplacement(XYZ_EXTENT_LINE, String
				.format("%f,%f,%f", xExtent, yExtent, zExtent));
	}

	/**
	 * Executes the <code>scene_creator</code> executable. The EarthCARE
	 * installation directory is determined by the environment variable
	 * <code>EARTHCARE_INSTALL_DIR</code>.
	 * <p>
	 * The file
	 * <code>$EARTHCARE_INSTALL_DIR/input/scene_creator/scene.inp</code>
	 * serves as the template input file. It is copied to a new temporary file.
	 * This temporary file is then used as the input to the executable. The
	 * output file can be set as a parameter.
	 * <p>
	 * Reacts to thread interruption with killing the process. Adds a shutdown
	 * hook, as to kill the underlying earthcare process if this java process is
	 * killed (e.g. with Ctrl-C).
	 * 
	 * @param sceneOut
	 *            the output file that is created by the scene_creator
	 * @throws IOException
	 *             if an IOException occurs when starting the
	 *             <code>scene_creator</code> process or if the
	 *             <code>EARTHCARE_INSTALL_DIR</code> environment variable is
	 *             not set.
	 */
	@SuppressWarnings("boxing")
	public void exec(File sceneOut) throws IOException {
		System.out.printf("scene_creator output scene: %s%n", sceneOut.getAbsolutePath());

		// Prepare temporary input files
		File sceneCreatorInput = File.createTempFile("scene_creator_", ".inp");
		System.out.printf("scene_creator input: %s%n", sceneCreatorInput);

		// Create input files from template
		sceneCreatorInputEditor.edit(getSceneCreatorInputTemplate(), sceneCreatorInput);

		// Prepare command line
		final Commandline commandline = new Commandline();
		commandline.setExecutable(new File(new File(EarthcareEnvironment.getEarthcareInstallDir(), "bin"), EXECUTABLE)
				.getCanonicalPath());
		commandline.createArgument().setValue(sceneCreatorInput.getCanonicalPath());
		commandline.createArgument().setValue(sceneOut.getCanonicalPath());

		// Start process
		final Process process = new ProcessImpl(commandline, EarthcareEnvironment.getEarthcareInstallDir());
		process.addEnvVar("NOXTERMFWIN", "true");
		WrapperUtil.addInterruptShutdownHook(Thread.currentThread());
		process.launchBlocking();
	}

	/**
	 * Return the scene_creator input file template.
	 * 
	 * @return the absolute path of the scene_creator input file template
	 * @throws IOException
	 *             if the environment variable
	 *             <code>$EARTHCARE_INSTALL_DIR</code> is not set.
	 */
	private static File getSceneCreatorInputTemplate() throws IOException {
		return new File(new File(new File(EarthcareEnvironment.getEarthcareInstallDir(), "input"), "scene_creator"),
				"scene.inp").getCanonicalFile();
	}

	/**
	 * Test only
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		File sceneOut = new File("/tmp/scene.out");
		try {
			SceneCreatorWrapper sceneCreatorWrapper = new SceneCreatorWrapper();
			sceneCreatorWrapper.exec(sceneOut);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
