package org.eodisp.earthcare.scene_creator.proxies;

import hla.rti1516.*;
import hla.rti1516.jlc.*;
import hla.rti1516.jlc.omt.*;
import hla.rti1516.*;

import java.io.*;
import java.util.*;
import java.util.concurrent.*;

import org.eodisp.wrapper.hla.*;

/**
 * Attributes that are common to all federates wrapping simulation models in
 * an EarthCARE simulation 
 *
 * @author org.eodisp.wrapper.hla.ProxyCompiler
 */

public class FederateInfoProxy extends EarthCAREProxy implements FederateInfo
{
    /**
     * Listeners for attributes associated with the FederateInfo class.
     */
    private final CopyOnWriteArrayList<FederateInfoListener> listeners = new CopyOnWriteArrayList<FederateInfoListener>();

    private final CopyOnWriteArrayList<FederateInfoPasselListener> passelListeners = new CopyOnWriteArrayList<FederateInfoPasselListener>();

    /**
     * The handle of the name attribute.
     */
    private AttributeHandle nameHandle;

    /**
     * Whether or not the name attribute has been set.
     */
    private boolean nameIsValid;

    /**
     * Whether or not the name attribute has changed.
     */
    private boolean nameIsDirty;

    /**
     * The name of the federate 
     */
    private String name;

    /**
     * The handle of the modelVersion attribute.
     */
    private AttributeHandle modelVersionHandle;

    /**
     * Whether or not the modelVersion attribute has been set.
     */
    private boolean modelVersionIsValid;

    /**
     * Whether or not the modelVersion attribute has changed.
     */
    private boolean modelVersionIsDirty;

    /**
     * The version of the model wrapped by the federate 
     */
    private String modelVersion;

    /**
     * The handle of the failureMode attribute.
     */
    private AttributeHandle failureModeHandle;

    /**
     * Whether or not the failureMode attribute has been set.
     */
    private boolean failureModeIsValid;

    /**
     * Whether or not the failureMode attribute has changed.
     */
    private boolean failureModeIsDirty;

    /**
     * The failure mode of the model wrapped by the federate 
     */
    private FailureMode failureMode;

    /**
     * The handle of the execStatus attribute.
     */
    private AttributeHandle execStatusHandle;

    /**
     * Whether or not the execStatus attribute has been set.
     */
    private boolean execStatusIsValid;

    /**
     * Whether or not the execStatus attribute has changed.
     */
    private boolean execStatusIsDirty;

    /**
     * The execution status of the federate 
     */
    private ExecStatus execStatus;


    /**
     * Constructor for object instance proxies created in response to
     * discovered objects.
     *
     * @param pRTIAmbassador the run-time infrastructure ambassador
     * @param pInstanceHandle the object instance handle
     * @param pClassHandle the object class handle
     * @param pName the object name
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    protected FederateInfoProxy(RTIambassador pRTIAmbassador,
                                ObjectInstanceHandle pInstanceHandle,
                                ObjectClassHandle pClassHandle,
                                String pName)
              throws RTIinternalError
    {
        super(pRTIAmbassador, pInstanceHandle, pClassHandle, pName);

        try
        {
            initializeAttributes();

            AttributeHandleSet ahs = rtiAmbassador.getAttributeHandleSetFactory().create();

            ahs.add(nameHandle);

            ahs.add(modelVersionHandle);

            ahs.add(failureModeHandle);

            ahs.add(execStatusHandle);

            rtiAmbassador.requestAttributeValueUpdate(getObjectInstanceHandle(), ahs, new byte[0]);
        }
        catch(RTIexception rtie)
        {
            throw new RTIinternalError(rtie.toString());
        }
    }

    /**
     * Constructor for object instance proxies created to represent new
     * locally owned objects.  Automatically notifies the run-time
     * infrastructure.
     *
     * @param pRTIAmbassador the run-time infrastructure ambassador
     * @param pClassHandle the object class handle
     * @exception ObjectClassNotDefined if the specified object class is not defined
     * @exception ObjectClassNotPublished if the specified object class is not published
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    protected FederateInfoProxy(RTIambassador pRTIAmbassador,
                                ObjectClassHandle pClassHandle)
              throws ObjectClassNotDefined,
                     ObjectClassNotPublished,
                     FederateNotExecutionMember,
                     SaveInProgress,
                     RestoreInProgress,
                     RTIinternalError
    {
        super(pRTIAmbassador, pClassHandle);

        try
        {
            initializeAttributes();
        }
        catch(RTIexception rtie)
        {
            throw new RTIinternalError(rtie.toString());
        }
    }

    /**
     * Constructor for object instance proxies created to represent new
     * locally owned objects.  Automatically notifies the run-time
     * infrastructure.
     *
     * @param pRTIAmbassador the run-time infrastructure ambassador
     * @param pClassHandle the object class handle
     * @param pName the object name
     * @exception ObjectClassNotDefined if the specified object class is not defined
     * @exception ObjectClassNotPublished if the specified object class is not published
     * @exception IllegalName if the instance name has is illegal
     * @exception ObjectInstanceNameInUse if the instance name is already in use
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */ 
    protected FederateInfoProxy(RTIambassador pRTIAmbassador,
                                ObjectClassHandle pClassHandle,
                                String pName)
              throws ObjectClassNotDefined,
                     ObjectClassNotPublished,
                     IllegalName,
                     ObjectInstanceNameInUse,
                     FederateNotExecutionMember,
                     SaveInProgress,
                     RestoreInProgress,
                     RTIinternalError
    {
        super(pRTIAmbassador, pClassHandle, pName);

        try
        {
            initializeAttributes();
        }
        catch(RTIexception rtie)
        {
            throw new RTIinternalError(rtie.toString());
        }
    }

    /**
     * Initializes the attributes and their handles.
     *
     * @exception InvalidObjectClassHandle if an object class handle is invalid
     * @exception NameNotFound if a name is not found
     * @exception ObjectClassNotDefined if an object class is not defined
     * @exception AttributeNotDefined if an attribute is not defined
     * @exception FederateNotExecutionMember if the federate is not an execution member
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the run-time
     * infrastructure
     */
    private void initializeAttributes()
                 throws InvalidObjectClassHandle,
                        NameNotFound,
                        ObjectClassNotDefined,
                        AttributeNotDefined,
                        FederateNotExecutionMember,
                        SaveInProgress,
                        RestoreInProgress,
                        RTIinternalError
    {
        nameHandle = rtiAmbassador.getAttributeHandle(getObjectClassHandle(), "name");
        name = new String();

        modelVersionHandle = rtiAmbassador.getAttributeHandle(getObjectClassHandle(), "modelVersion");
        modelVersion = new String();

        failureModeHandle = rtiAmbassador.getAttributeHandle(getObjectClassHandle(), "failureMode");
        failureMode = new FailureMode();

        execStatusHandle = rtiAmbassador.getAttributeHandle(getObjectClassHandle(), "execStatus");
        execStatus = new ExecStatus();
    }

    /**
     * Notifies the proxy that it should provide an update regarding a set of object
     * attributes.
     *
     * @param theAttributes the set of attribute handles identifying the attributes that
     * should be sent
     * @param userSuppliedTag the user-supplied tag associated with the request
     * @exception AttributeNotRecognized if an identified attribute was not recognized
     * @exception AttributeNotOwned if the federate did not own a specified attribute
     * @exception FederateInternalError if an error occurs in the federate
     */
    public void notifyProvideAttributeValueUpdate(AttributeHandleSet theAttributes,
                                            byte[] userSuppliedTag)
                throws AttributeNotRecognized,
                       AttributeNotOwned,
                       FederateInternalError
    {
        if(theAttributes.contains(nameHandle))
        {
            nameIsDirty = true;
        }

        if(theAttributes.contains(modelVersionHandle))
        {
            modelVersionIsDirty = true;
        }

        if(theAttributes.contains(failureModeHandle))
        {
            failureModeIsDirty = true;
        }

        if(theAttributes.contains(execStatusHandle))
        {
            execStatusIsDirty = true;
        }

        super.notifyProvideAttributeValueUpdate(
            theAttributes,
            userSuppliedTag
        );
    }

    /**
     * Places the attribute values to update into the specified map.
     *
     * @param ahvm the attribute handle value map to populate
     * @param updateAll if <code>true</code> provide updates for all attributes;
     * if <code>false</code>, only provide updates for the modified ones
     * @exception RTIinternalError if an internal error occurs in the run-time
     * infrastructure
     */
    protected void getAttributeValuesToUpdate(AttributeHandleValueMap ahvm,
                                             boolean updateAll)
                   throws RTIinternalError
    {
        if(nameIsValid && (updateAll || nameIsDirty))
        {
        HLAunicodeString encoded = OmtEncoderFactory.getInstance().createHLAunicodeString(name);

            ahvm.put(nameHandle, encoded.toByteArray());

            nameIsDirty = false;
        }

        if(modelVersionIsValid && (updateAll || modelVersionIsDirty))
        {
        HLAunicodeString encoded = OmtEncoderFactory.getInstance().createHLAunicodeString(modelVersion);

            ahvm.put(modelVersionHandle, encoded.toByteArray());

            modelVersionIsDirty = false;
        }

        if(failureModeIsValid && (updateAll || failureModeIsDirty))
        {
        DataElement encoded = failureMode.encode();

            ahvm.put(failureModeHandle, encoded.toByteArray());

            failureModeIsDirty = false;
        }

        if(execStatusIsValid && (updateAll || execStatusIsDirty))
        {
        DataElement encoded = execStatus.encode();

            ahvm.put(execStatusHandle, encoded.toByteArray());

            execStatusIsDirty = false;
        }

        super.getAttributeValuesToUpdate(ahvm, updateAll);
    }

    /**
     * Adds a listener for attributes associated with the FederateInfo class.
     *
     * @param l the listener to add
     */
    public void addFederateInfoListener(FederateInfoListener l) {
        	resetWaitForListener();
        listeners.add(l);
    }

    /**
     * Removes a listener for attributes associated with the FederateInfo class.
     *
     * @param l the listener to remove
     */
    public void removeFederateInfoListener(FederateInfoListener l) {
        listeners.remove(l);
    }

    /**
     * Adds a passel listener for attributes associated with the FederateInfo class.
     *
     * @param l the passel listener to add
     */
    public void addFederateInfoPasselListener(FederateInfoPasselListener l) {
        	resetWaitForListener();
        passelListeners.add(l);
    }

    /**
     * Removes a passel listener for attributes associated with the FederateInfo class.
     *
     * @param l the passel listener to remove
     */
    public void removeFederateInfoPasselListener(FederateInfoPasselListener l) {
        passelListeners.remove(l);
    }
    /**
     * Returns an instance of the FederateInfoPassel class.
     *
     * @param l the listener to remove
     */
    protected Object createPassel() {
        return new FederateInfoPassel();
    }
    /**
     * Sets the passel values FederateInfoPassel class.
     *
     * @param l the listener to remove
     */
    protected void setPasselValues( Object passel,  AttributeHandleValueMap attributeHandleValueMap ) {
        FederateInfoPassel localPassel = (FederateInfoPassel)passel;
        if(attributeHandleValueMap.containsKey(nameHandle)) {
            byte[] value = (byte[])attributeHandleValueMap.get(nameHandle);
            ByteWrapper byteWrapper = new ByteWrapper(value);
            HLAunicodeString dataElement =  OmtEncoderFactory.getInstance().createHLAunicodeString();
            dataElement.decode(byteWrapper);
            localPassel.name = dataElement.getValue();
            name = localPassel.name;
            localPassel.nameIsValid = true;
            nameIsValid = true;

        }
        if(attributeHandleValueMap.containsKey(modelVersionHandle)) {
            byte[] value = (byte[])attributeHandleValueMap.get(modelVersionHandle);
            ByteWrapper byteWrapper = new ByteWrapper(value);
            HLAunicodeString dataElement =  OmtEncoderFactory.getInstance().createHLAunicodeString();
            dataElement.decode(byteWrapper);
            localPassel.modelVersion = dataElement.getValue();
            modelVersion = localPassel.modelVersion;
            localPassel.modelVersionIsValid = true;
            modelVersionIsValid = true;

        }
        if(attributeHandleValueMap.containsKey(failureModeHandle)) {
            byte[] value = (byte[])attributeHandleValueMap.get(failureModeHandle);
            localPassel.failureMode = FailureMode.decode(value);
            failureMode = localPassel.failureMode;
            localPassel.failureModeIsValid = true;
            failureModeIsValid = true;

        }
        if(attributeHandleValueMap.containsKey(execStatusHandle)) {
            byte[] value = (byte[])attributeHandleValueMap.get(execStatusHandle);
            localPassel.execStatus = ExecStatus.decode(value);
            execStatus = localPassel.execStatus;
            localPassel.execStatusIsValid = true;
            execStatusIsValid = true;

        }
        super.setPasselValues( passel, attributeHandleValueMap );
    }
    /**
     * Notifies the listeners of new values
     *
     * @param passel all values that were sent in the same passel. Values were all converted from the attributeHandleValueMap
     * @param attributeHandleValueMap the original attributeHandleValueMap
     */
    protected void notifyListeners( Object passel,  AttributeHandleValueMap attributeHandleValueMap ) {
        FederateInfoPassel localPassel = (FederateInfoPassel)passel;
        if( listeners.isEmpty() && passelListeners.isEmpty() ) {
            try {
                if(! listenerLatch.await( 300, TimeUnit.SECONDS )) {
                    throw new Error("Nobody attached a listener during objectInstanceDiscovered.");
                }
            } catch (InterruptedException e) {
        	        Thread.currentThread().interrupt();
            }
        }
        if(attributeHandleValueMap.containsKey(nameHandle)) {
            for(FederateInfoListener listener : listeners) {
                listener.nameUpdated(
                    this,
                    localPassel,
                    localPassel.getName());
            }
        }
        if(attributeHandleValueMap.containsKey(modelVersionHandle)) {
            for(FederateInfoListener listener : listeners) {
                listener.modelVersionUpdated(
                    this,
                    localPassel,
                    localPassel.getModelVersion());
            }
        }
        if(attributeHandleValueMap.containsKey(failureModeHandle)) {
            for(FederateInfoListener listener : listeners) {
                listener.failureModeUpdated(
                    this,
                    localPassel,
                    localPassel.getFailureMode());
            }
        }
        if(attributeHandleValueMap.containsKey(execStatusHandle)) {
            for(FederateInfoListener listener : listeners) {
                listener.execStatusUpdated(
                    this,
                    localPassel,
                    localPassel.getExecStatus());
            }
        }
        for(FederateInfoPasselListener listener : passelListeners) {
            listener.passelUpdated(
               this,
                localPassel);
        }
        super.notifyListeners( passel, attributeHandleValueMap );
    }

    /**
     * Sets the value of the name attribute.
     *
     * @param pName the new attribute value
     * @param userSuppliedTag a user-supplied tag to associate with the action
     * run-time infrastructure
     */
    public synchronized void setName(String pName) {
        name = pName;
        nameIsValid = true;
        nameIsDirty = true;
    }


    /**
     * Sets the value of the name attribute and immediately sends the updated value to the federation.
     *
     * @param pName the new attribute value
     * @param userSuppliedTag a user-supplied tag that is used as the parameter to {@link ObjectClassInstance#updateAttributeValues(byte[])} 
     * @exception ObjectInstanceNotKnown if the object instance is unknown
     * @exception AttributeNotDefined if one of the attributes is undefined
     * @exception AttributeNotOwned if one of the attributes is not owned
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    public synchronized void setName(String pName, byte[] userSuppliedTag)
                throws ObjectInstanceNotKnown,
                       AttributeNotDefined,
                       AttributeNotOwned,
                       FederateNotExecutionMember,
                       SaveInProgress,
                       RestoreInProgress,
                       RTIinternalError {
        setName( pName );
        updateAttributeValues(userSuppliedTag);
    }

    /**
     * Returns the value of the name attribute.
     *
     * @return the current attribute value
     */
    public synchronized String getName()
    {
        return name;
    }

    /**
     * Sets the value of the modelVersion attribute.
     *
     * @param pModelVersion the new attribute value
     * @param userSuppliedTag a user-supplied tag to associate with the action
     * run-time infrastructure
     */
    public synchronized void setModelVersion(String pModelVersion) {
        modelVersion = pModelVersion;
        modelVersionIsValid = true;
        modelVersionIsDirty = true;
    }


    /**
     * Sets the value of the modelVersion attribute and immediately sends the updated value to the federation.
     *
     * @param pModelVersion the new attribute value
     * @param userSuppliedTag a user-supplied tag that is used as the parameter to {@link ObjectClassInstance#updateAttributeValues(byte[])} 
     * @exception ObjectInstanceNotKnown if the object instance is unknown
     * @exception AttributeNotDefined if one of the attributes is undefined
     * @exception AttributeNotOwned if one of the attributes is not owned
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    public synchronized void setModelVersion(String pModelVersion, byte[] userSuppliedTag)
                throws ObjectInstanceNotKnown,
                       AttributeNotDefined,
                       AttributeNotOwned,
                       FederateNotExecutionMember,
                       SaveInProgress,
                       RestoreInProgress,
                       RTIinternalError {
        setModelVersion( pModelVersion );
        updateAttributeValues(userSuppliedTag);
    }

    /**
     * Returns the value of the modelVersion attribute.
     *
     * @return the current attribute value
     */
    public synchronized String getModelVersion()
    {
        return modelVersion;
    }

    /**
     * Sets the value of the failureMode attribute.
     *
     * @param pFailureMode the new attribute value
     * @param userSuppliedTag a user-supplied tag to associate with the action
     * run-time infrastructure
     */
    public synchronized void setFailureMode(FailureMode pFailureMode) {
        failureMode = pFailureMode;
        failureModeIsValid = true;
        failureModeIsDirty = true;
    }


    /**
     * Sets the value of the failureMode attribute and immediately sends the updated value to the federation.
     *
     * @param pFailureMode the new attribute value
     * @param userSuppliedTag a user-supplied tag that is used as the parameter to {@link ObjectClassInstance#updateAttributeValues(byte[])} 
     * @exception ObjectInstanceNotKnown if the object instance is unknown
     * @exception AttributeNotDefined if one of the attributes is undefined
     * @exception AttributeNotOwned if one of the attributes is not owned
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    public synchronized void setFailureMode(FailureMode pFailureMode, byte[] userSuppliedTag)
                throws ObjectInstanceNotKnown,
                       AttributeNotDefined,
                       AttributeNotOwned,
                       FederateNotExecutionMember,
                       SaveInProgress,
                       RestoreInProgress,
                       RTIinternalError {
        setFailureMode( pFailureMode );
        updateAttributeValues(userSuppliedTag);
    }

    /**
     * Returns the value of the failureMode attribute.
     *
     * @return the current attribute value
     */
    public synchronized FailureMode getFailureMode()
    {
        return failureMode;
    }

    /**
     * Sets the value of the execStatus attribute.
     *
     * @param pExecStatus the new attribute value
     * @param userSuppliedTag a user-supplied tag to associate with the action
     * run-time infrastructure
     */
    public synchronized void setExecStatus(ExecStatus pExecStatus) {
        execStatus = pExecStatus;
        execStatusIsValid = true;
        execStatusIsDirty = true;
    }


    /**
     * Sets the value of the execStatus attribute and immediately sends the updated value to the federation.
     *
     * @param pExecStatus the new attribute value
     * @param userSuppliedTag a user-supplied tag that is used as the parameter to {@link ObjectClassInstance#updateAttributeValues(byte[])} 
     * @exception ObjectInstanceNotKnown if the object instance is unknown
     * @exception AttributeNotDefined if one of the attributes is undefined
     * @exception AttributeNotOwned if one of the attributes is not owned
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    public synchronized void setExecStatus(ExecStatus pExecStatus, byte[] userSuppliedTag)
                throws ObjectInstanceNotKnown,
                       AttributeNotDefined,
                       AttributeNotOwned,
                       FederateNotExecutionMember,
                       SaveInProgress,
                       RestoreInProgress,
                       RTIinternalError {
        setExecStatus( pExecStatus );
        updateAttributeValues(userSuppliedTag);
    }

    /**
     * Returns the value of the execStatus attribute.
     *
     * @return the current attribute value
     */
    public synchronized ExecStatus getExecStatus()
    {
        return execStatus;
    }
}
