/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005,2006  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.earthcare.scene_creator;

import java.io.File;

import org.eodisp.util.configuration.ConfigurationImpl;

/**
 * @author ibirrer
 * 
 */
public class EarthCareConfiguration extends ConfigurationImpl {
	private static final String EXEC_DIR = "exec-dir";

	private static final String INSTALL_DIR = "install-dir";

	/**
	 * The Id of this configuration.This id can be used to retrieve the
	 * configuration entries.
	 */
	public static final String ID = EarthCareConfiguration.class.getName();

	/**
	 * @param file
	 *            the file that this configuration is persisted to.
	 */
	public EarthCareConfiguration(File file) {
		super(ID, "Scene Creator Federate Configuration",
				"The configuration of the scene creator federate", file);
		createFileEntry(
				EXEC_DIR,
				new File(System.getProperty("user.dir")),
				"The working directory of the scene_creator process. Defaults to the directory that the federate was started in.");
		createFileEntry(INSTALL_DIR, new File("/usr/local/earthcare"),
				"The installation directory of the earthcare simulation package. "
						+ "This must point to a directory that contains the 'bin' folder "
						+ "with the earthcare executables (scene_creator, lid_filter etc.)");

	}

	public File getExecDir() {
		return getEntry(EXEC_DIR).getFile();
	}

	public void setExecDir(File execDir) {
		getEntry(EXEC_DIR).setFile(execDir);
	}

	public File getInstallDir() {
		return getEntry(INSTALL_DIR).getFile();

	}

	public void setInstallDir(File installDir) {
		getEntry(INSTALL_DIR).setFile(installDir);
	}

	public static void main(String[] args) {
		System.out.println(new EarthCareConfiguration(null).getCode());
	}

}
