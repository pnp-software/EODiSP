/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.earthcare.scene_creator;

import static java.util.concurrent.TimeUnit.SECONDS;
import hla.rti1516.*;
import hla.rti1516.jlc.RtiFactoryFactory;

import java.io.File;
import java.io.FileInputStream;

import org.eodisp.earthcare.common.util.EarthcareEnvironment;
import org.eodisp.earthcare.common.util.WrapperUtil;
import org.eodisp.earthcare.common.util.input.InputManager;
import org.eodisp.earthcare.common.util.input.InputManagerListener;
import org.eodisp.earthcare.common.util.input.ObjectInput;
import org.eodisp.earthcare.scene_creator.proxies.*;
import org.eodisp.util.ZipUtil;
import org.eodisp.wrapper.hla.*;

/**
 * scene_creator federate.
 * 
 * @author ibirrer
 * @version $Id:$
 */
public class SceneCreatorFederateImpl implements ObjectClassDiscoveryListener {
	private final ObjectInput<SceneCreatorPar> sceneCreatorParInput = new ObjectInput<SceneCreatorPar>();

	private final InputManager inputManager;

	private final FederateInfo federateInfo;

	private final SceneCreatorFederate federate;

	private final RTIambassador rtiAmbassador;

	private final SceneCreatorWrapper wrapper;

	/**
	 * @param sceneInputFile
	 *            directory in which received files are saved
	 * @throws FederationSynchronizationException
	 * @throws InterruptedException
	 * @throws RTIexception
	 * @throws FederationExecutionDoesNotExist
	 * @throws FederateAlreadyExecutionMember
	 */
	public SceneCreatorFederateImpl() throws FederateAlreadyExecutionMember, FederationExecutionDoesNotExist,
			RTIexception, InterruptedException, FederationSynchronizationException {
		inputManager = new InputManager();
		inputManager.addInput(sceneCreatorParInput);
		inputManager.addInputManagerListener(new InputManagerListener() {
			public void inputReady() {
				startEarthcareProcess();
			}

		});
		wrapper = new SceneCreatorWrapper();
		inputManager.start();
		rtiAmbassador = RtiFactoryFactory.getRtiFactory().getRtiAmbassador();
		federate = new SceneCreatorFederate(rtiAmbassador);
		federate.addObjectClassDiscoveryListener(this);
		WrapperUtil.eodispStart(federate);
		federateInfo = federate.newFederateInfo();
	}

	public synchronized void execute() throws RTIexception {
		federateInfo.setName("scene_creator");
		federateInfo.setModelVersion("1.0.0");
		updateExecStatus(ExecStatus.READY);
		while (true) {
			try {
				this.wait();
			} catch (InterruptedException e) {
				// ignore spurious wakeups
			}
		}
	}

	/**
	 * @param objectClassInstance
	 */
	public void objectInstanceDiscovered(ObjectClassInstance objectClassInstance) {
		if (objectClassInstance instanceof SceneCreatorPar) {
			SceneCreatorPar sceneCreatorPar = (SceneCreatorPar) objectClassInstance;
			sceneCreatorPar.addSceneCreatorParPasselListener(new SceneCreatorParPasselListener() {
				public void passelUpdated(SceneCreatorPar source, SceneCreatorParPassel passel) {
					sceneCreatorParInput.set(source);
				}
			});
		}
	}

	private void startEarthcareProcess() {
		boolean zip = false;
		System.out.println("Starting scene_creator ...");
		SceneCreatorPar sceneCreatorPar = sceneCreatorParInput.get();
		wrapper.setExtent(sceneCreatorPar.getXExtent(), sceneCreatorPar.getYExtent(), sceneCreatorPar.getZExtent());
		wrapper.setHorizontalResolution(sceneCreatorPar.getHorizontalResolution());
		try {
			federateInfo.setFailureMode(sceneCreatorPar.getFailureMode(), WrapperUtil.NULL_BYTE);
			File sceneOut = File.createTempFile("scene_creator_out_", "");
			wrapper.exec(sceneOut);
			updateExecStatus(ExecStatus.DONE);
			int chunkNr = 0;
			SceneCreatorOut sceneCreatorOut = federate.newSceneCreatorOut();
			if (zip) {
				final File zippedFile = new File(sceneOut.getParentFile(), sceneOut.getName() + ".zip");
				ZipUtil.zip(zippedFile, zippedFile.getParentFile(), sceneOut);
				sceneOut = zippedFile;
			}
			StreamChunker streamChunker = new StreamChunker(new FileInputStream(sceneOut),
					EarthcareEnvironment.DEFAULT_CHUNK_SIZE, sceneOut.length());

			sceneCreatorOut.setFilename(sceneOut.getName());
			// TODO: Use long for HLA streams
			sceneCreatorOut.setNrOfChunks((int) streamChunker.getTotalChunkCount());
			while (streamChunker.hasMoreChunks()) {
				sceneCreatorOut.setChunkNr(chunkNr++);
				sceneCreatorOut.setChunk(streamChunker.nextChunk());
				sceneCreatorOut.updateAttributeValues(WrapperUtil.NULL_BYTE);
			}

			updateExecStatus(ExecStatus.SHUTTING_DOWN);
			System.out.println("Wait for EODISP_STOP ...");
			federate.achieveSyncPointAndAwaitFederationSynchronization("EODISP_STOP", Long.MAX_VALUE, SECONDS);
			rtiAmbassador.resignFederationExecution(ResignAction.UNCONDITIONALLY_DIVEST_ATTRIBUTES);
			System.exit(0);
		} catch (Exception e) {
			e.printStackTrace();
			WrapperUtil.fatalError(e, federate);
		}
		System.exit(1);
	}

	/**
	 * Convenience method to access the federate info guarded by the lock of
	 * this class.
	 * 
	 * @param pExecStatus
	 *            the new attribute value
	 * @exception RTIexception
	 *                The new exec status could not be delivered to the
	 *                federation
	 */
	private synchronized void updateExecStatus(ExecStatus execStatus) throws RTIexception {
		federateInfo.setExecStatus(execStatus, WrapperUtil.NULL_BYTE);
	}
}
