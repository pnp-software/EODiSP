package org.eodisp.earthcare.scene_creator.proxies;


/**
 * Attributes that represent parameters that are specific to the scene_creator
 * utility 
 *
 * @author org.eodisp.wrapper.hla.ProxyCompiler
 */

public class SceneCreatorParPassel extends EarthCAREPassel {
    /**
     * The failure mode of the scene_creator utility 
     */
    FailureMode failureMode;

    /**
     * Whether or not the failureMode attribute has been set.
     */
    boolean failureModeIsValid;

    /**
     * X extend in km 
     */
    float xExtent;

    /**
     * Whether or not the xExtent attribute has been set.
     */
    boolean xExtentIsValid;

    /**
     * Y extend in km 
     */
    float yExtent;

    /**
     * Whether or not the yExtent attribute has been set.
     */
    boolean yExtentIsValid;

    /**
     * Z extend in km 
     */
    float zExtent;

    /**
     * Whether or not the zExtent attribute has been set.
     */
    boolean zExtentIsValid;

    /**
     * The horizontal resolution in km (an input parameter for the scene_creator
     * utility) 
     */
    float horizontalResolution;

    /**
     * Whether or not the horizontalResolution attribute has been set.
     */
    boolean horizontalResolutionIsValid;

    /**
     * Returns the value of the failureMode attribute.
     *
     * @return the current attribute value
     */
    public FailureMode getFailureMode() {
        return failureMode;
    }

    /**
     * Returns <code>true</code> if the attribute 'failureMode' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean failureModeIsValid() {
        return failureModeIsValid;
    }
    /**
     * Returns the value of the xExtent attribute.
     *
     * @return the current attribute value
     */
    public float getXExtent() {
        return xExtent;
    }

    /**
     * Returns <code>true</code> if the attribute 'xExtent' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean xExtentIsValid() {
        return xExtentIsValid;
    }
    /**
     * Returns the value of the yExtent attribute.
     *
     * @return the current attribute value
     */
    public float getYExtent() {
        return yExtent;
    }

    /**
     * Returns <code>true</code> if the attribute 'yExtent' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean yExtentIsValid() {
        return yExtentIsValid;
    }
    /**
     * Returns the value of the zExtent attribute.
     *
     * @return the current attribute value
     */
    public float getZExtent() {
        return zExtent;
    }

    /**
     * Returns <code>true</code> if the attribute 'zExtent' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean zExtentIsValid() {
        return zExtentIsValid;
    }
    /**
     * Returns the value of the horizontalResolution attribute.
     *
     * @return the current attribute value
     */
    public float getHorizontalResolution() {
        return horizontalResolution;
    }

    /**
     * Returns <code>true</code> if the attribute 'horizontalResolution' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean horizontalResolutionIsValid() {
        return horizontalResolutionIsValid;
    }
}
