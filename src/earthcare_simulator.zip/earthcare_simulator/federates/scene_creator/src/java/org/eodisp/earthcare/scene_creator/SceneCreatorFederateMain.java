package org.eodisp.earthcare.scene_creator;


/**
 * The main entry of the SceneCreatorFederate
 * 
 * @author ibirrer
 */
public class SceneCreatorFederateMain {

	public static void main(String[] args) {
		try {
			SceneCreatorFederateImpl sceneCreatorFederateImpl = new SceneCreatorFederateImpl();
			sceneCreatorFederateImpl.execute();
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
		System.exit(0);
	}
}
