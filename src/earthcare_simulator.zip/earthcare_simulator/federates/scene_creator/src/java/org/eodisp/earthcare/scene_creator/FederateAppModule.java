/**
 * 
 */
package org.eodisp.earthcare.scene_creator;

import java.io.File;

import org.eodisp.util.AbstractAppModule;
import org.eodisp.util.RootApp;
import org.eodisp.util.configuration.CommandlineMapper;

public class FederateAppModule extends AbstractAppModule {
	public static final String ID = FederateAppModule.class.getName();

	@Override
	public String getId() {
		return ID;
	}

	@Override
	public void registerConfiguration(RootApp rootApp) {
		rootApp.registerConfiguration(new FederateConfiguration(new File(
				rootApp.getConfigurationDir(), "federate.conf")),
				CommandlineMapper.BASIC_COMMAND_LINE_MAPPER);
	}
}
