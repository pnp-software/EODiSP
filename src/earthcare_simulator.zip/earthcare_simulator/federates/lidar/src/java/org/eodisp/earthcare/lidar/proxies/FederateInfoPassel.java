package org.eodisp.earthcare.lidar.proxies;


/**
 * Attributes that are common to all federates wrapping simulation models in
 * an EarthCARE simulation 
 *
 * @author org.eodisp.wrapper.hla.ProxyCompiler
 */

public class FederateInfoPassel extends EarthCAREPassel {
    /**
     * The name of the federate 
     */
    String name;

    /**
     * Whether or not the name attribute has been set.
     */
    boolean nameIsValid;

    /**
     * The version of the model wrapped by the federate 
     */
    String modelVersion;

    /**
     * Whether or not the modelVersion attribute has been set.
     */
    boolean modelVersionIsValid;

    /**
     * The failure mode of the model wrapped by the federate 
     */
    FailureMode failureMode;

    /**
     * Whether or not the failureMode attribute has been set.
     */
    boolean failureModeIsValid;

    /**
     * The execution status of the federate 
     */
    ExecStatus execStatus;

    /**
     * Whether or not the execStatus attribute has been set.
     */
    boolean execStatusIsValid;

    /**
     * Returns the value of the name attribute.
     *
     * @return the current attribute value
     */
    public String getName() {
        return name;
    }

    /**
     * Returns <code>true</code> if the attribute 'name' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean nameIsValid() {
        return nameIsValid;
    }
    /**
     * Returns the value of the modelVersion attribute.
     *
     * @return the current attribute value
     */
    public String getModelVersion() {
        return modelVersion;
    }

    /**
     * Returns <code>true</code> if the attribute 'modelVersion' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean modelVersionIsValid() {
        return modelVersionIsValid;
    }
    /**
     * Returns the value of the failureMode attribute.
     *
     * @return the current attribute value
     */
    public FailureMode getFailureMode() {
        return failureMode;
    }

    /**
     * Returns <code>true</code> if the attribute 'failureMode' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean failureModeIsValid() {
        return failureModeIsValid;
    }
    /**
     * Returns the value of the execStatus attribute.
     *
     * @return the current attribute value
     */
    public ExecStatus getExecStatus() {
        return execStatus;
    }

    /**
     * Returns <code>true</code> if the attribute 'execStatus' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean execStatusIsValid() {
        return execStatusIsValid;
    }
}
