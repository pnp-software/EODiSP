package org.eodisp.earthcare.lidar_ret1.proxies;

import java.io.*;
import hla.rti1516.jlc.*;
import hla.rti1516.jlc.omt.*;

import org.eodisp.wrapper.hla.*;

/**
 * The failure mode of an EarthCARE federate 
 *
 * @author org.eodisp.wrapper.hla.ProxyCompiler
 */

public class FailureMode implements Cloneable, Serializable
{
    /**
     * Enumerator #0.
     */
    public static final FailureMode NOMINAL = new FailureMode(0);

    /**
     * Enumerator #1.
     */
    public static final FailureMode LOW_SEVERITY = new FailureMode(1);

    /**
     * Enumerator #2.
     */
    public static final FailureMode HIGH_SEVERITY = new FailureMode(2);

    /**
     * Enumerator #3.
     */
    public static final FailureMode FATAL = new FailureMode(3);

    /**
     * The value of the instance.
     */
    private int value;


    /**
     * Reads and returns a FailureMode from the specified byte array
     *
     * @param value the byte array to read from
     * @return the decoded value
     */
    public static FailureMode decode(byte[] value) {
        ByteWrapper byteWrapper = new ByteWrapper(value);
        HLAinteger32BE dataElement =  OmtEncoderFactory.getInstance().createHLAinteger32BE();
        dataElement.decode(byteWrapper);
        return new FailureMode(dataElement.getValue());
    }

    /**
     * Returns a FailureMode from the integer value
     *
     * @param value the byte array to read from
     * @return the decoded value
     */
    public static FailureMode valueOf(int value) {
        switch( value ) {
            case 0:
            return NOMINAL;
            case 1:
            return LOW_SEVERITY;
            case 2:
            return HIGH_SEVERITY;
            case 3:
            return FATAL;
            default:
            throw new IllegalArgumentException();
        }
    }

    /**
     * Default constructor (NOMINAL).
     */
    public FailureMode()
    {
        value = NOMINAL.value;
    }

    /**
     * Copy constructor.
     *
     * @param other the other FailureMode to copy
     */
    public FailureMode(FailureMode other)
    {
        value = other.value;
    }

    /**
     * Private constructor.
     *
     * @param pValue the instance value
     */
    private FailureMode(int pValue)
    {
        value = pValue;
    }

    /**
     * Compares this FailureMode for equality with another.
     *
     * @param other the other FailureMode
     * @return <code>true</code> if the two enumerated types are equal,
     * <code>false</code> otherwise
     */
    public boolean equals(Object other)
    {
        try
        {
            return ( value == ((FailureMode)other).value );
        }
        catch(ClassCastException cce)
        {
            return false;
        }
    }

    /**
     * Computes and returns a hash code corresponding to this FailureMode.
     *
     * @return a hash code corresponding to this FailureMode
     */
    public int hashCode()
    {
        return value;
    }

    /**
     * Returns the HLA encoded value of thisFailureMode
     */
    public HLAinteger32BE encode() {
        HLAinteger32BE encoded = OmtEncoderFactory.getInstance().createHLAinteger32BE(value);
        return encoded;
    }

    /**
     * Returns a string representation of this FailureMode
     *
     * @return a string representation of this FailureMode
     */
    public String toString()
    {
        if( this.equals(NOMINAL) )
        {
            return "NOMINAL";
        }
        else if( this.equals(LOW_SEVERITY) )
        {
            return "LOW_SEVERITY";
        }
        else if( this.equals(HIGH_SEVERITY) )
        {
            return "HIGH_SEVERITY";
        }
        else if( this.equals(FATAL) )
        {
            return "FATAL";
        }
        else
        {
            return "FailureMode #" + value;
        }
    }
}
