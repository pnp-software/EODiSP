package org.eodisp.earthcare.lidar_ret1.proxies;


/**
 * Attributes that represent parameters that are specific to the lidar_ret1 model
 *
 * @author org.eodisp.wrapper.hla.ProxyCompiler
 */

public class LidarRet1ParPassel extends EarthCAREPassel {
    /**
     * The failure mode of the lidar_ret1 model 
     */
    FailureMode failureMode;

    /**
     * Whether or not the failureMode attribute has been set.
     */
    boolean failureModeIsValid;

    /**
     * The desired vertical resolution in km 
     */
    float verticalResolution;

    /**
     * Whether or not the verticalResolution attribute has been set.
     */
    boolean verticalResolutionIsValid;

    /**
     * The desired horizontal resolution in km 
     */
    float horizontalResolution;

    /**
     * Whether or not the horizontalResolution attribute has been set.
     */
    boolean horizontalResolutionIsValid;

    /**
     * Returns the value of the failureMode attribute.
     *
     * @return the current attribute value
     */
    public FailureMode getFailureMode() {
        return failureMode;
    }

    /**
     * Returns <code>true</code> if the attribute 'failureMode' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean failureModeIsValid() {
        return failureModeIsValid;
    }
    /**
     * Returns the value of the verticalResolution attribute.
     *
     * @return the current attribute value
     */
    public float getVerticalResolution() {
        return verticalResolution;
    }

    /**
     * Returns <code>true</code> if the attribute 'verticalResolution' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean verticalResolutionIsValid() {
        return verticalResolutionIsValid;
    }
    /**
     * Returns the value of the horizontalResolution attribute.
     *
     * @return the current attribute value
     */
    public float getHorizontalResolution() {
        return horizontalResolution;
    }

    /**
     * Returns <code>true</code> if the attribute 'horizontalResolution' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean horizontalResolutionIsValid() {
        return horizontalResolutionIsValid;
    }
}
