/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.earthcare.lidar_ret1;

import static java.util.concurrent.TimeUnit.SECONDS;
import hla.rti1516.RTIambassador;
import hla.rti1516.RTIexception;
import hla.rti1516.ResignAction;
import hla.rti1516.jlc.RtiFactoryFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import net.jcip.annotations.GuardedBy;
import net.jcip.annotations.ThreadSafe;

import org.apache.log4j.Logger;
import org.eodisp.earthcare.common.util.EarthcareEnvironment;
import org.eodisp.earthcare.common.util.WrapperUtil;
import org.eodisp.earthcare.common.util.input.*;
import org.eodisp.earthcare.lidar_ret1.proxies.*;
import org.eodisp.util.FileUtil;
import org.eodisp.wrapper.hla.*;
import org.eodisp.wrapper.hla.EodispFederate.FederationStateListener;

/**
 * lidar_ret1 federate implementation.
 * 
 * @author ibirrer
 * @version $Id:$
 */
@ThreadSafe
public class LidarRet1FederateImpl implements ObjectClassDiscoveryListener, FederationStateListener {

	private static final int LIDAR_OUTPUT_FILES_COUNT = 22;

	private final File lidarDir;

	private final MultipleFileInput lidarInput = new MultipleFileInput(LIDAR_OUTPUT_FILES_COUNT);

	private final File radarFile;

	private final FileInput radarInput = new FileInput();

	private final ObjectInput<LidarRet1Par> paramInput = new ObjectInput<LidarRet1Par>();

	private final InputManager inputManager;

	private final LidarRet1Wrapper wrapper;

	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	private final static Logger logger = Logger.getLogger(LidarRet1FederateImpl.class);

	/**
	 * Whether to skip the execution of the earthcare executable and use
	 * pre-calculated values or not
	 */
	private final boolean skipExecution;

	@GuardedBy("this")
	private FederateInfo federateInfo;

	@GuardedBy("this")
	private LidarRet1Federate federate;

	/**
	 * @param sceneInputFile
	 *            directory in which received files are saved
	 * @param skipExecution
	 *            if this is set to <code>true</code>, the EarthCARE
	 *            executable is not run but only the pre-calculated output files
	 *            in {@link EarthcareEnvironment#getEarthcareInstallDir()}/output/lw_mc
	 *            are sent to the federation
	 * @throws IOException
	 */
	public LidarRet1FederateImpl(boolean skipExecution) throws IOException {
		this.skipExecution = skipExecution;
		inputManager = new InputManager();
		inputManager.addInput(lidarInput);
		inputManager.addInput(radarInput);
		inputManager.addInput(paramInput);
		inputManager.addInputManagerListener(new InputManagerListener() {
			public void inputReady() {
				if (federate.getState() != FederationState.PAUSED) {
					startEarthcareProcess();
				} else {
					logger
							.info("All input available for radar federate, but not starting because the federation is in the PAUSED state");
				}
			}
		});

		lidarDir = FileUtil.createTempDir("lidar_ret1_lidarInput_", "", null);
		radarFile = File.createTempFile("lidar_ret1_radarInput_", "");
		wrapper = new LidarRet1Wrapper();
	}

	/**
	 * Starts this federate. Prints the stack trace and exits with an exit code
	 * of <code>1</code> if anything goes wrong.
	 */
	public synchronized void execute() {
		try {
			inputManager.start();
			RTIambassador rtiAmbassador = RtiFactoryFactory.getRtiFactory().getRtiAmbassador();
			federate = new LidarRet1Federate(rtiAmbassador);
			federate.addObjectClassDiscoveryListener(this);
			federate.addFederationStateListener(this);
			WrapperUtil.eodispStart(federate);
			federateInfo = federate.newFederateInfo();
			federateInfo.setName("lidar_ret1");
			federateInfo.setModelVersion("1.0.0");
			federateInfo.setExecStatus(ExecStatus.READY);
			federateInfo.updateAttributeValues(WrapperUtil.NULL_BYTE);
			while (true) {
				try {
					this.wait();
				} catch (InterruptedException e) {
					// ignore spurious wakeups
				}
			}
		} catch (Exception e) {
			WrapperUtil.fatalError(e, federate);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void objectInstanceDiscovered(ObjectClassInstance objectClassInstance) {
		if (objectClassInstance instanceof LidarRet1Par) {
			LidarRet1Par lidarRet1Par = (LidarRet1Par) objectClassInstance;
			lidarRet1Par.addLidarRet1ParPasselListener(new LidarRet1ParPasselListener() {
				public void passelUpdated(LidarRet1Par source, LidarRet1ParPassel passel) {
					paramInput.set(source);
				}
			});
		} else if (objectClassInstance instanceof LidarOut) {
			LidarOut lidarOut = (LidarOut) objectClassInstance;
			System.out.println("Discovered new LidarOut instance");
			lidarOut.addLidarOutPasselListener(new LidarOutPasselListener() {
				public void passelUpdated(LidarOut source, LidarOutPassel passel) {
					File file = new File(lidarDir, source.getFilename());
					try {
						lidarInput.receiveChunk(file, passel.getChunk(), passel.getChunkNr(), source.getNrOfChunks());
					} catch (IOException e) {
						WrapperUtil.fatalError(e, federate);
					}
				}
			});
		} else if (objectClassInstance instanceof RadarOut) {
			RadarOut radarOut = (RadarOut) objectClassInstance;
			System.out.println("Discovered new RadarOut instance");
			radarOut.addRadarOutPasselListener(new RadarOutPasselListener() {
				public void passelUpdated(RadarOut source, RadarOutPassel passel) {
					try {
						radarInput.receiveChunk(radarFile, passel.getChunk(), passel.getChunkNr(), source
								.getNrOfChunks());
					} catch (IOException e) {
						WrapperUtil.fatalError(e, federate);
					}
				}
			});
		}
	}

	private synchronized void startEarthcareProcess() {
		LidarRet1Par lidarRet1Par = paramInput.get();
		wrapper.setHorizontalResolution(lidarRet1Par.getHorizontalResolution());
		wrapper.setVerticalResolution(lidarRet1Par.getVerticalResolution());

		try {
			federateInfo.setFailureMode(lidarRet1Par.getFailureMode(), WrapperUtil.NULL_BYTE);
			File outputLocation = skipExecution ? LidarRet1Wrapper.getPreCalculatedOutputLocation() : FileUtil
					.createTempDir("lidar_ret_1_out_", "", null);
			System.out.println("Starting lidar_ret1 ...");
			System.out.println("lidar_ret1 output: " + outputLocation.getAbsolutePath());
			if (!skipExecution) {
				wrapper.exec(lidarDir, radarFile, outputLocation);
			}
			updateExecStatus(ExecStatus.DONE);
			int fileCount = 0;
			for (File file : outputLocation.listFiles()) {
				if (file.isDirectory()) {
					continue;
				}
				LidarRet1Out lidarRet1Out = federate.newLidarRet1Out();
				StreamChunker streamChunker = new StreamChunker(new FileInputStream(file),
						EarthcareEnvironment.DEFAULT_CHUNK_SIZE, file.length());
				lidarRet1Out.setFilename(file.getName());
				// TODO: Use long for HLA streams
				lidarRet1Out.setNrOfChunks((int) streamChunker.getTotalChunkCount());
				int chunkNr = 0;
				while (streamChunker.hasMoreChunks()) {
					lidarRet1Out.setChunkNr(chunkNr++);
					lidarRet1Out.setChunk(streamChunker.nextChunk());
					lidarRet1Out.updateAttributeValues(WrapperUtil.NULL_BYTE);
				}
				System.out.println("Sent file: " + ++fileCount);
			}
			updateExecStatus(ExecStatus.SHUTTING_DOWN);

			federate.achieveSyncPointAndAwaitFederationSynchronization("EODISP_STOP", Long.MAX_VALUE, SECONDS);
			federate.getRtiAmbassador().resignFederationExecution(ResignAction.UNCONDITIONALLY_DIVEST_ATTRIBUTES);
			System.exit(0);
		} catch (Exception e) {
			WrapperUtil.fatalError(e, federate);
		}
		System.exit(1);
	}

	/**
	 * Convenience method to access the federate info guarded by the lock of
	 * this class.
	 * 
	 * @param pExecStatus
	 *            the new attribute value
	 * @exception RTIexception
	 *                The new exec status could not be delivered to the
	 *                federation
	 */
	private synchronized void updateExecStatus(ExecStatus execStatus) throws RTIexception {
		federateInfo.setExecStatus(execStatus, WrapperUtil.NULL_BYTE);
	}

	public void stateChanged(FederationState newState) {
		if ((newState == FederationState.RESUMING || newState == FederationState.STEPPING) && inputManager.isReady()) {
			logger.info("radar federate starts processing due state change to: " + newState);
			Thread t = new Thread() {
				@Override
				public void run() {
					startEarthcareProcess();
				}
			};
			t.start();
		}

	}
}
