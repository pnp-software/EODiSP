package org.eodisp.earthcare.mc_lw_sim_main.proxies;

import hla.rti1516.*;
import hla.rti1516.jlc.*;
import hla.rti1516.jlc.omt.*;
import hla.rti1516.*;

import java.io.*;
import java.util.*;
import java.util.concurrent.*;

import org.eodisp.wrapper.hla.*;

/**
 * Attributes that represent parameters that are specific to the MC_LW_sim_main
 * utility 
 *
 * @author org.eodisp.wrapper.hla.ProxyCompiler
 */

public class McLwSimMainParProxy extends EarthCAREProxy implements McLwSimMainPar
{
    /**
     * Listeners for attributes associated with the McLwSimMainPar class.
     */
    private final CopyOnWriteArrayList<McLwSimMainParListener> listeners = new CopyOnWriteArrayList<McLwSimMainParListener>();

    private final CopyOnWriteArrayList<McLwSimMainParPasselListener> passelListeners = new CopyOnWriteArrayList<McLwSimMainParPasselListener>();

    /**
     * The handle of the failureMode attribute.
     */
    private AttributeHandle failureModeHandle;

    /**
     * Whether or not the failureMode attribute has been set.
     */
    private boolean failureModeIsValid;

    /**
     * Whether or not the failureMode attribute has changed.
     */
    private boolean failureModeIsDirty;

    /**
     * The failure mode of the MC_LW_sim_main utility 
     */
    private FailureMode failureMode;

    /**
     * The handle of the randomNumberSeed attribute.
     */
    private AttributeHandle randomNumberSeedHandle;

    /**
     * Whether or not the randomNumberSeed attribute has been set.
     */
    private boolean randomNumberSeedIsValid;

    /**
     * Whether or not the randomNumberSeed attribute has changed.
     */
    private boolean randomNumberSeedIsDirty;

    /**
     * Seed for random number generator (negative number to use time and date
     * as seed) 
     */
    private float randomNumberSeed;

    /**
     * The handle of the outputResolution attribute.
     */
    private AttributeHandle outputResolutionHandle;

    /**
     * Whether or not the outputResolution attribute has been set.
     */
    private boolean outputResolutionIsValid;

    /**
     * Whether or not the outputResolution attribute has changed.
     */
    private boolean outputResolutionIsDirty;

    /**
     * Resolution of output (km). Negative entry: Use UFF resolution 
     */
    private float outputResolution;


    /**
     * Constructor for object instance proxies created in response to
     * discovered objects.
     *
     * @param pRTIAmbassador the run-time infrastructure ambassador
     * @param pInstanceHandle the object instance handle
     * @param pClassHandle the object class handle
     * @param pName the object name
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    protected McLwSimMainParProxy(RTIambassador pRTIAmbassador,
                                  ObjectInstanceHandle pInstanceHandle,
                                  ObjectClassHandle pClassHandle,
                                  String pName)
              throws RTIinternalError
    {
        super(pRTIAmbassador, pInstanceHandle, pClassHandle, pName);

        try
        {
            initializeAttributes();

            AttributeHandleSet ahs = rtiAmbassador.getAttributeHandleSetFactory().create();

            ahs.add(failureModeHandle);

            ahs.add(randomNumberSeedHandle);

            ahs.add(outputResolutionHandle);

            rtiAmbassador.requestAttributeValueUpdate(getObjectInstanceHandle(), ahs, new byte[0]);
        }
        catch(RTIexception rtie)
        {
            throw new RTIinternalError(rtie.toString());
        }
    }

    /**
     * Constructor for object instance proxies created to represent new
     * locally owned objects.  Automatically notifies the run-time
     * infrastructure.
     *
     * @param pRTIAmbassador the run-time infrastructure ambassador
     * @param pClassHandle the object class handle
     * @exception ObjectClassNotDefined if the specified object class is not defined
     * @exception ObjectClassNotPublished if the specified object class is not published
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    protected McLwSimMainParProxy(RTIambassador pRTIAmbassador,
                                  ObjectClassHandle pClassHandle)
              throws ObjectClassNotDefined,
                     ObjectClassNotPublished,
                     FederateNotExecutionMember,
                     SaveInProgress,
                     RestoreInProgress,
                     RTIinternalError
    {
        super(pRTIAmbassador, pClassHandle);

        try
        {
            initializeAttributes();
        }
        catch(RTIexception rtie)
        {
            throw new RTIinternalError(rtie.toString());
        }
    }

    /**
     * Constructor for object instance proxies created to represent new
     * locally owned objects.  Automatically notifies the run-time
     * infrastructure.
     *
     * @param pRTIAmbassador the run-time infrastructure ambassador
     * @param pClassHandle the object class handle
     * @param pName the object name
     * @exception ObjectClassNotDefined if the specified object class is not defined
     * @exception ObjectClassNotPublished if the specified object class is not published
     * @exception IllegalName if the instance name has is illegal
     * @exception ObjectInstanceNameInUse if the instance name is already in use
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */ 
    protected McLwSimMainParProxy(RTIambassador pRTIAmbassador,
                                  ObjectClassHandle pClassHandle,
                                  String pName)
              throws ObjectClassNotDefined,
                     ObjectClassNotPublished,
                     IllegalName,
                     ObjectInstanceNameInUse,
                     FederateNotExecutionMember,
                     SaveInProgress,
                     RestoreInProgress,
                     RTIinternalError
    {
        super(pRTIAmbassador, pClassHandle, pName);

        try
        {
            initializeAttributes();
        }
        catch(RTIexception rtie)
        {
            throw new RTIinternalError(rtie.toString());
        }
    }

    /**
     * Initializes the attributes and their handles.
     *
     * @exception InvalidObjectClassHandle if an object class handle is invalid
     * @exception NameNotFound if a name is not found
     * @exception ObjectClassNotDefined if an object class is not defined
     * @exception AttributeNotDefined if an attribute is not defined
     * @exception FederateNotExecutionMember if the federate is not an execution member
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the run-time
     * infrastructure
     */
    private void initializeAttributes()
                 throws InvalidObjectClassHandle,
                        NameNotFound,
                        ObjectClassNotDefined,
                        AttributeNotDefined,
                        FederateNotExecutionMember,
                        SaveInProgress,
                        RestoreInProgress,
                        RTIinternalError
    {
        failureModeHandle = rtiAmbassador.getAttributeHandle(getObjectClassHandle(), "failureMode");
        failureMode = new FailureMode();

        randomNumberSeedHandle = rtiAmbassador.getAttributeHandle(getObjectClassHandle(), "randomNumberSeed");

        outputResolutionHandle = rtiAmbassador.getAttributeHandle(getObjectClassHandle(), "outputResolution");
    }

    /**
     * Notifies the proxy that it should provide an update regarding a set of object
     * attributes.
     *
     * @param theAttributes the set of attribute handles identifying the attributes that
     * should be sent
     * @param userSuppliedTag the user-supplied tag associated with the request
     * @exception AttributeNotRecognized if an identified attribute was not recognized
     * @exception AttributeNotOwned if the federate did not own a specified attribute
     * @exception FederateInternalError if an error occurs in the federate
     */
    public void notifyProvideAttributeValueUpdate(AttributeHandleSet theAttributes,
                                            byte[] userSuppliedTag)
                throws AttributeNotRecognized,
                       AttributeNotOwned,
                       FederateInternalError
    {
        if(theAttributes.contains(failureModeHandle))
        {
            failureModeIsDirty = true;
        }

        if(theAttributes.contains(randomNumberSeedHandle))
        {
            randomNumberSeedIsDirty = true;
        }

        if(theAttributes.contains(outputResolutionHandle))
        {
            outputResolutionIsDirty = true;
        }

        super.notifyProvideAttributeValueUpdate(
            theAttributes,
            userSuppliedTag
        );
    }

    /**
     * Places the attribute values to update into the specified map.
     *
     * @param ahvm the attribute handle value map to populate
     * @param updateAll if <code>true</code> provide updates for all attributes;
     * if <code>false</code>, only provide updates for the modified ones
     * @exception RTIinternalError if an internal error occurs in the run-time
     * infrastructure
     */
    protected void getAttributeValuesToUpdate(AttributeHandleValueMap ahvm,
                                             boolean updateAll)
                   throws RTIinternalError
    {
        if(failureModeIsValid && (updateAll || failureModeIsDirty))
        {
        DataElement encoded = failureMode.encode();

            ahvm.put(failureModeHandle, encoded.toByteArray());

            failureModeIsDirty = false;
        }

        if(randomNumberSeedIsValid && (updateAll || randomNumberSeedIsDirty))
        {
        HLAfloat32BE encoded = OmtEncoderFactory.getInstance().createHLAfloat32BE(randomNumberSeed);

            ahvm.put(randomNumberSeedHandle, encoded.toByteArray());

            randomNumberSeedIsDirty = false;
        }

        if(outputResolutionIsValid && (updateAll || outputResolutionIsDirty))
        {
        HLAfloat32BE encoded = OmtEncoderFactory.getInstance().createHLAfloat32BE(outputResolution);

            ahvm.put(outputResolutionHandle, encoded.toByteArray());

            outputResolutionIsDirty = false;
        }

        super.getAttributeValuesToUpdate(ahvm, updateAll);
    }

    /**
     * Adds a listener for attributes associated with the McLwSimMainPar class.
     *
     * @param l the listener to add
     */
    public void addMcLwSimMainParListener(McLwSimMainParListener l) {
        	resetWaitForListener();
        listeners.add(l);
    }

    /**
     * Removes a listener for attributes associated with the McLwSimMainPar class.
     *
     * @param l the listener to remove
     */
    public void removeMcLwSimMainParListener(McLwSimMainParListener l) {
        listeners.remove(l);
    }

    /**
     * Adds a passel listener for attributes associated with the McLwSimMainPar class.
     *
     * @param l the passel listener to add
     */
    public void addMcLwSimMainParPasselListener(McLwSimMainParPasselListener l) {
        	resetWaitForListener();
        passelListeners.add(l);
    }

    /**
     * Removes a passel listener for attributes associated with the McLwSimMainPar class.
     *
     * @param l the passel listener to remove
     */
    public void removeMcLwSimMainParPasselListener(McLwSimMainParPasselListener l) {
        passelListeners.remove(l);
    }
    /**
     * Returns an instance of the McLwSimMainParPassel class.
     *
     * @param l the listener to remove
     */
    protected Object createPassel() {
        return new McLwSimMainParPassel();
    }
    /**
     * Sets the passel values McLwSimMainParPassel class.
     *
     * @param l the listener to remove
     */
    protected void setPasselValues( Object passel,  AttributeHandleValueMap attributeHandleValueMap ) {
        McLwSimMainParPassel localPassel = (McLwSimMainParPassel)passel;
        if(attributeHandleValueMap.containsKey(failureModeHandle)) {
            byte[] value = (byte[])attributeHandleValueMap.get(failureModeHandle);
            localPassel.failureMode = FailureMode.decode(value);
            failureMode = localPassel.failureMode;
            localPassel.failureModeIsValid = true;
            failureModeIsValid = true;

        }
        if(attributeHandleValueMap.containsKey(randomNumberSeedHandle)) {
            byte[] value = (byte[])attributeHandleValueMap.get(randomNumberSeedHandle);
            ByteWrapper byteWrapper = new ByteWrapper(value);
            HLAfloat32BE dataElement =  OmtEncoderFactory.getInstance().createHLAfloat32BE();
            dataElement.decode(byteWrapper);
            localPassel.randomNumberSeed = dataElement.getValue();
            randomNumberSeed = localPassel.randomNumberSeed;
            localPassel.randomNumberSeedIsValid = true;
            randomNumberSeedIsValid = true;

        }
        if(attributeHandleValueMap.containsKey(outputResolutionHandle)) {
            byte[] value = (byte[])attributeHandleValueMap.get(outputResolutionHandle);
            ByteWrapper byteWrapper = new ByteWrapper(value);
            HLAfloat32BE dataElement =  OmtEncoderFactory.getInstance().createHLAfloat32BE();
            dataElement.decode(byteWrapper);
            localPassel.outputResolution = dataElement.getValue();
            outputResolution = localPassel.outputResolution;
            localPassel.outputResolutionIsValid = true;
            outputResolutionIsValid = true;

        }
        super.setPasselValues( passel, attributeHandleValueMap );
    }
    /**
     * Notifies the listeners of new values
     *
     * @param passel all values that were sent in the same passel. Values were all converted from the attributeHandleValueMap
     * @param attributeHandleValueMap the original attributeHandleValueMap
     */
    protected void notifyListeners( Object passel,  AttributeHandleValueMap attributeHandleValueMap ) {
        McLwSimMainParPassel localPassel = (McLwSimMainParPassel)passel;
        if( listeners.isEmpty() && passelListeners.isEmpty() ) {
            try {
                if(! listenerLatch.await( 300, TimeUnit.SECONDS )) {
                    throw new Error("Nobody attached a listener during objectInstanceDiscovered.");
                }
            } catch (InterruptedException e) {
        	        Thread.currentThread().interrupt();
            }
        }
        if(attributeHandleValueMap.containsKey(failureModeHandle)) {
            for(McLwSimMainParListener listener : listeners) {
                listener.failureModeUpdated(
                    this,
                    localPassel,
                    localPassel.getFailureMode());
            }
        }
        if(attributeHandleValueMap.containsKey(randomNumberSeedHandle)) {
            for(McLwSimMainParListener listener : listeners) {
                listener.randomNumberSeedUpdated(
                    this,
                    localPassel,
                    localPassel.getRandomNumberSeed());
            }
        }
        if(attributeHandleValueMap.containsKey(outputResolutionHandle)) {
            for(McLwSimMainParListener listener : listeners) {
                listener.outputResolutionUpdated(
                    this,
                    localPassel,
                    localPassel.getOutputResolution());
            }
        }
        for(McLwSimMainParPasselListener listener : passelListeners) {
            listener.passelUpdated(
               this,
                localPassel);
        }
        super.notifyListeners( passel, attributeHandleValueMap );
    }

    /**
     * Sets the value of the failureMode attribute.
     *
     * @param pFailureMode the new attribute value
     * @param userSuppliedTag a user-supplied tag to associate with the action
     * run-time infrastructure
     */
    public synchronized void setFailureMode(FailureMode pFailureMode) {
        failureMode = pFailureMode;
        failureModeIsValid = true;
        failureModeIsDirty = true;
    }


    /**
     * Sets the value of the failureMode attribute and immediately sends the updated value to the federation.
     *
     * @param pFailureMode the new attribute value
     * @param userSuppliedTag a user-supplied tag that is used as the parameter to {@link ObjectClassInstance#updateAttributeValues(byte[])} 
     * @exception ObjectInstanceNotKnown if the object instance is unknown
     * @exception AttributeNotDefined if one of the attributes is undefined
     * @exception AttributeNotOwned if one of the attributes is not owned
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    public synchronized void setFailureMode(FailureMode pFailureMode, byte[] userSuppliedTag)
                throws ObjectInstanceNotKnown,
                       AttributeNotDefined,
                       AttributeNotOwned,
                       FederateNotExecutionMember,
                       SaveInProgress,
                       RestoreInProgress,
                       RTIinternalError {
        setFailureMode( pFailureMode );
        updateAttributeValues(userSuppliedTag);
    }

    /**
     * Returns the value of the failureMode attribute.
     *
     * @return the current attribute value
     */
    public synchronized FailureMode getFailureMode()
    {
        return failureMode;
    }

    /**
     * Sets the value of the randomNumberSeed attribute.
     *
     * @param pRandomNumberSeed the new attribute value
     * @param userSuppliedTag a user-supplied tag to associate with the action
     * run-time infrastructure
     */
    public synchronized void setRandomNumberSeed(float pRandomNumberSeed) {
        randomNumberSeed = pRandomNumberSeed;
        randomNumberSeedIsValid = true;
        randomNumberSeedIsDirty = true;
    }


    /**
     * Sets the value of the randomNumberSeed attribute and immediately sends the updated value to the federation.
     *
     * @param pRandomNumberSeed the new attribute value
     * @param userSuppliedTag a user-supplied tag that is used as the parameter to {@link ObjectClassInstance#updateAttributeValues(byte[])} 
     * @exception ObjectInstanceNotKnown if the object instance is unknown
     * @exception AttributeNotDefined if one of the attributes is undefined
     * @exception AttributeNotOwned if one of the attributes is not owned
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    public synchronized void setRandomNumberSeed(float pRandomNumberSeed, byte[] userSuppliedTag)
                throws ObjectInstanceNotKnown,
                       AttributeNotDefined,
                       AttributeNotOwned,
                       FederateNotExecutionMember,
                       SaveInProgress,
                       RestoreInProgress,
                       RTIinternalError {
        setRandomNumberSeed( pRandomNumberSeed );
        updateAttributeValues(userSuppliedTag);
    }

    /**
     * Returns the value of the randomNumberSeed attribute.
     *
     * @return the current attribute value
     */
    public synchronized float getRandomNumberSeed()
    {
        return randomNumberSeed;
    }

    /**
     * Sets the value of the outputResolution attribute.
     *
     * @param pOutputResolution the new attribute value
     * @param userSuppliedTag a user-supplied tag to associate with the action
     * run-time infrastructure
     */
    public synchronized void setOutputResolution(float pOutputResolution) {
        outputResolution = pOutputResolution;
        outputResolutionIsValid = true;
        outputResolutionIsDirty = true;
    }


    /**
     * Sets the value of the outputResolution attribute and immediately sends the updated value to the federation.
     *
     * @param pOutputResolution the new attribute value
     * @param userSuppliedTag a user-supplied tag that is used as the parameter to {@link ObjectClassInstance#updateAttributeValues(byte[])} 
     * @exception ObjectInstanceNotKnown if the object instance is unknown
     * @exception AttributeNotDefined if one of the attributes is undefined
     * @exception AttributeNotOwned if one of the attributes is not owned
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    public synchronized void setOutputResolution(float pOutputResolution, byte[] userSuppliedTag)
                throws ObjectInstanceNotKnown,
                       AttributeNotDefined,
                       AttributeNotOwned,
                       FederateNotExecutionMember,
                       SaveInProgress,
                       RestoreInProgress,
                       RTIinternalError {
        setOutputResolution( pOutputResolution );
        updateAttributeValues(userSuppliedTag);
    }

    /**
     * Returns the value of the outputResolution attribute.
     *
     * @return the current attribute value
     */
    public synchronized float getOutputResolution()
    {
        return outputResolution;
    }
}
