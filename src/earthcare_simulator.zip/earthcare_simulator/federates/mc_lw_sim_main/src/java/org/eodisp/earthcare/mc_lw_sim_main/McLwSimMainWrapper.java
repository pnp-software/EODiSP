/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.earthcare.mc_lw_sim_main;

import java.io.File;
import java.io.IOException;

import org.apache.tools.ant.types.Commandline;
import org.eodisp.earthcare.common.util.*;
import org.eodisp.earthcare.scene_creator.SceneCreatorWrapper;
import org.eodisp.util.FileUtil;
import org.eodisp.util.launcher.Process;
import org.eodisp.util.launcher.ProcessImpl;

/**
 * Wrapper wrapper for the the <code>MC_LW_sim_main</code> executable of the
 * EarthCARE simulator.
 * 
 * @author ibirrer
 */
public class McLwSimMainWrapper extends AbstractEarthcareWrapper {
	private static final String EXECUTABLE = "MC_LW_sim_main";

	private static final int DOMAIN_LINE = 1;

	private static final int OUTPUT_RESOULTION_LINE = 2;

	private static final int RELATIVE_RADIANCE_ERROR_THRESHOLD_LINE = 5;

	private static final int RANDOM_NUMBER_SEED_LINE = 15;

	private final LineEditor mcLwSimMainInputEditor = new LineEditor();

	/**
	 * Sets the output resolution in km
	 * 
	 * @param value
	 *            the output resolution im km
	 */
	public void setOutputResolution(double value) {
		mcLwSimMainInputEditor.addLineReplacement(OUTPUT_RESOULTION_LINE, value + "");
	}

	/**
	 * Sets the random number generator seed (negative number to use time and
	 * date as seed)
	 * 
	 * @param value
	 *            the seed number
	 */
	public void setRandomNumberSeed(double value) {
		mcLwSimMainInputEditor.addLineReplacement(RANDOM_NUMBER_SEED_LINE, value + "");
	}

	public void setRelativeRadianceErrorThreshold(double above, double error) {
		mcLwSimMainInputEditor.addLineReplacement(RELATIVE_RADIANCE_ERROR_THRESHOLD_LINE, above + "," + error);
	}

	public void setDomain(double x1, double x2, double y1, double y2) {
		mcLwSimMainInputEditor.addLineReplacement(DOMAIN_LINE, x1 + "," + x2 + "," + y1 + "," + y2);
	}

	public static File getPreCalculatedOutputLocation() throws IOException {
		return new File(EarthcareEnvironment.getEarthcareInstallDir(), "output/lw_mc");
	}

	/**
	 * Executes the <code>MC_LW_sim_main</code> executable. The EarthCARE
	 * installation directory is determined by the environment variable
	 * <code>EARTHCARE_INSTALL_DIR</code>.
	 * <p>
	 * The file <code>$EARTHCARE_INSTALL_DIR/input/master.inp</code> serves as
	 * the template master file. It is copied to a new temporary file. This
	 * temporary file is then used as the input to the executable.
	 * <p>
	 * Reacts to thread interruption with killing the process. Adds a shutdown
	 * hook, as to kill the underlying earthcare process if this java process is
	 * killed.
	 * 
	 * @param scene
	 *            the filtered scene file (as created by the rad_filter utility)
	 * @param outputLocation
	 *            the output dir
	 * @throws IOException
	 *             if an IOException occurs when starting the
	 *             <code>MC_LW_sim_main</code> process or if the
	 *             <code>EARTHCARE_INSTALL_DIR</code> environment variable is
	 *             not set.
	 */
	public void exec(File scene, File outputLocation) throws IOException {
		System.out.printf("MC_LW_sim_main input scene: %s%n", scene.getAbsolutePath());
		System.out.printf("MC_LW_sim_main output location: %s%n", outputLocation.getAbsolutePath());

		// Prepare temporary input files
		File masterFile = File.createTempFile("master_", ".inp");
		System.out.printf("Master file: %s%n", masterFile);
		File mcLwSimMainInput = File.createTempFile("MC_LW_sim_main_", ".inp");
		System.out.printf("MC_LW_sim_main input: %s%n", mcLwSimMainInput);

		// Create input files from templates
		mcLwSimMainInputEditor.edit(getMcLwSimMainInputTemplate(), mcLwSimMainInput);
		MasterFileGenerator masterFileGenerator = new MasterFileGenerator();
		masterFileGenerator.setSceneFile(scene.getAbsolutePath());
		masterFileGenerator.setMcLwSimMainInput(mcLwSimMainInput.getAbsolutePath());
		masterFileGenerator.setMcLwSimMainOutput(outputLocation.getAbsoluteFile());
		masterFileGenerator.generate(EarthcareEnvironment.getMasterTemplate(), masterFile);

		// Prepare command line
		Commandline commandline = new Commandline();
		commandline.setExecutable(new File(new File(EarthcareEnvironment.getEarthcareInstallDir(), "bin"), EXECUTABLE)
				.getCanonicalPath());
		commandline.createArgument().setValue(masterFile.getCanonicalPath());

		// Start process
		Process process = new ProcessImpl(commandline, EarthcareEnvironment.getEarthcareInstallDir());
		process.addEnvVar("NOXTERMFWIN", "true");
		WrapperUtil.addInterruptShutdownHook(Thread.currentThread());
		process.launchBlocking();
	}

	/**
	 * Return the lidar input file template.
	 * 
	 * @return the absolute path of the lidar input file template
	 * @throws IOException
	 *             if the environment variable
	 *             <code>$EARTHCARE_INSTALL_DIR</code> is not set.
	 */
	private File getMcLwSimMainInputTemplate() throws IOException {
		File lidarInputOrig = new File(new File(new File(EarthcareEnvironment.getEarthcareInstallDir(), "input"),
				"lw_mc"), "lw_mc.inp").getCanonicalFile();
		System.out.printf("MC_LW_sim_main input template: %s%n", lidarInputOrig);
		return lidarInputOrig;
	}

	/**
	 * Test only
	 * 
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) {
		try {
			final File scene = File.createTempFile("scene_", "");
			final File mcLwOut = new File(FileUtil.createTempDir("mc_lw", "", null), "mc_lw.out");
			SceneCreatorWrapper sceneCreatorWrapper = new SceneCreatorWrapper();
			sceneCreatorWrapper.setExtent(10, 10, 100);
			sceneCreatorWrapper.exec(scene);
			McLwSimMainWrapper mcLwSimMainWrapper = new McLwSimMainWrapper();
			mcLwSimMainWrapper.setOutputResolution(0.5);
			mcLwSimMainWrapper.setRandomNumberSeed(10);
			mcLwSimMainWrapper.exec(scene, mcLwOut);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
