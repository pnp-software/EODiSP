This is the EODiSP control Federate. 
For convenience it is first developed here as part of the EarthCARE demonstrator
but will be move to eodisp_core as soon as it reached a state where it can be reused.
