/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.earthcare.radar;

import java.io.File;
import java.io.IOException;

import org.apache.tools.ant.types.Commandline;
import org.eodisp.earthcare.common.util.*;
import org.eodisp.earthcare.rad_filter.RadFilterWrapper;
import org.eodisp.earthcare.scene_creator.SceneCreatorWrapper;
import org.eodisp.util.FileUtil;
import org.eodisp.util.launcher.Process;
import org.eodisp.util.launcher.ProcessImpl;

/**
 * Wrapper wrapper for the the <code>radar</code> executable of the EarthCARE
 * simulator.
 * 
 * @author ibirrer
 */
public class RadarWrapper extends AbstractEarthcareWrapper {
	private static final String EXECUTABLE = "radar";

	private static final int PULSE_REPETITION_FREQUENCY_LINE = 4;

	private final LineEditor radarInputEditor = new LineEditor();

	public void setPulseRepetitionFrequency(double pulseRepetitionFrequency) {
		radarInputEditor.addLineReplacement(PULSE_REPETITION_FREQUENCY_LINE, pulseRepetitionFrequency + "");
	}

	public static File getPreCalculatedOutputLocation() throws IOException {
		return new File(EarthcareEnvironment.getEarthcareInstallDir(), "output/radar");
	}

	/**
	 * Executes the <code>radar</code> executable. The EarthCARE installation
	 * directory is determined by the environment variable
	 * <code>EARTHCARE_INSTALL_DIR</code>.
	 * <p>
	 * The file <code>$EARTHCARE_INSTALL_DIR/input/master.inp</code> serves as
	 * the template master file. It is copied to a new temporary file. This
	 * temporary file is then used as the input to the executable.
	 * <p>
	 * Reacts to thread interruption with killing the process. Adds a shutdown
	 * hook, as to kill the underlying earthcare process if this java process is
	 * killed.
	 * 
	 * @param filteredScene
	 *            the filtered scene file (as created by the rad_filter utility)
	 * @param outputFile
	 *            the output file
	 * @throws IOException
	 *             if an IOException occurs when starting the <code>radar</code>
	 *             process or if the <code>EARTHCARE_INSTALL_DIR</code>
	 *             environment variable is not set.
	 */
	public void exec(File filteredScene, File outputFile) throws IOException {
		System.out.printf("radar input scene: %s%n", filteredScene.getAbsolutePath());
		System.out.printf("radar output file: %s%n", outputFile.getAbsolutePath());

		// Prepare temporary input files
		File masterFile = File.createTempFile("master_", ".inp");
		System.out.printf("Master file: %s%n", masterFile);
		File radarInput = File.createTempFile("radar_", ".inp");
		System.out.printf("radar input: %s%n", radarInput);

		// Create input files from templates
		radarInputEditor.edit(getRadarInputTemplate(), radarInput);
		MasterFileGenerator masterFileGenerator = new MasterFileGenerator();
		masterFileGenerator.setRadFilterOutput(filteredScene.getAbsolutePath());
		masterFileGenerator.setRadarInput(radarInput.getAbsolutePath());
		masterFileGenerator.setRadarOutput(outputFile.getAbsolutePath());
		masterFileGenerator.generate(EarthcareEnvironment.getMasterTemplate(), masterFile);

		// Prepare command line
		Commandline commandline = new Commandline();
		commandline.setExecutable(new File(new File(EarthcareEnvironment.getEarthcareInstallDir(), "bin"), EXECUTABLE)
				.getCanonicalPath());
		commandline.createArgument().setValue(masterFile.getCanonicalPath());

		// Start process
		Process process = new ProcessImpl(commandline, EarthcareEnvironment.getEarthcareInstallDir());
		process.addEnvVar("NOXTERMFWIN", "true");
		WrapperUtil.addInterruptShutdownHook(Thread.currentThread());
		process.launchBlocking();
	}

	/**
	 * Return the lidar input file template.
	 * 
	 * @return the absolute path of the lidar input file template
	 * @throws IOException
	 *             if the environment variable
	 *             <code>$EARTHCARE_INSTALL_DIR</code> is not set.
	 */
	private File getRadarInputTemplate() throws IOException {
		File lidarInputOrig = new File(new File(new File(EarthcareEnvironment.getEarthcareInstallDir(), "input"),
				"radar"), "radar.inp").getCanonicalFile();
		System.out.printf("radar input template: %s%n", lidarInputOrig);
		return lidarInputOrig;
	}

	/**
	 * Test only
	 * 
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) {
		try {
			final File scene = File.createTempFile("scene_", "");
			final File filteredScene = File.createTempFile("filteredScene_", "");
			final File lidarOut = new File(FileUtil.createTempDir("lidarOut", "", null), "lidar.out");
			SceneCreatorWrapper sceneCreatorWrapper = new SceneCreatorWrapper();
			sceneCreatorWrapper.setExtent(10, 10, 100);
			sceneCreatorWrapper.exec(scene);
			RadFilterWrapper radFilterWrapper = new RadFilterWrapper();
			radFilterWrapper.exec(scene, filteredScene);
			RadarWrapper radarWrapper = new RadarWrapper();
			radarWrapper.exec(filteredScene, lidarOut);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
