package org.eodisp.earthcare.radar.proxies;


/**
 * Attributes that represent parameters that are specific to the radar model
 *
 * @author org.eodisp.wrapper.hla.ProxyCompiler
 */

public class RadarParPassel extends EarthCAREPassel {
    /**
     * The failure mode of the radar model 
     */
    FailureMode failureMode;

    /**
     * Whether or not the failureMode attribute has been set.
     */
    boolean failureModeIsValid;

    /**
     * The Pulse Repetition Frequency in Hz 
     */
    float pulseRepetitionFrequency;

    /**
     * Whether or not the pulseRepetitionFrequency attribute has been set.
     */
    boolean pulseRepetitionFrequencyIsValid;

    /**
     * Returns the value of the failureMode attribute.
     *
     * @return the current attribute value
     */
    public FailureMode getFailureMode() {
        return failureMode;
    }

    /**
     * Returns <code>true</code> if the attribute 'failureMode' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean failureModeIsValid() {
        return failureModeIsValid;
    }
    /**
     * Returns the value of the pulseRepetitionFrequency attribute.
     *
     * @return the current attribute value
     */
    public float getPulseRepetitionFrequency() {
        return pulseRepetitionFrequency;
    }

    /**
     * Returns <code>true</code> if the attribute 'pulseRepetitionFrequency' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean pulseRepetitionFrequencyIsValid() {
        return pulseRepetitionFrequencyIsValid;
    }
}
