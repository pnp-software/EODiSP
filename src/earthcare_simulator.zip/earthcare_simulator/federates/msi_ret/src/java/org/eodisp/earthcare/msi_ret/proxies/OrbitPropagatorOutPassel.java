package org.eodisp.earthcare.msi_ret.proxies;


/**
 * The output of the orbit propagator 
 *
 * @author org.eodisp.wrapper.hla.ProxyCompiler
 */

public class OrbitPropagatorOutPassel extends EarthCAREPassel {
    /**
     * Solar position angle in degrees 
     */
    double solarPos1;

    /**
     * Whether or not the solarPos1 attribute has been set.
     */
    boolean solarPos1IsValid;

    /**
     * Solar position angle in degrees 
     */
    double solarPos2;

    /**
     * Whether or not the solarPos2 attribute has been set.
     */
    boolean solarPos2IsValid;

    /**
     * Returns the value of the solarPos1 attribute.
     *
     * @return the current attribute value
     */
    public double getSolarPos1() {
        return solarPos1;
    }

    /**
     * Returns <code>true</code> if the attribute 'solarPos1' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean solarPos1IsValid() {
        return solarPos1IsValid;
    }
    /**
     * Returns the value of the solarPos2 attribute.
     *
     * @return the current attribute value
     */
    public double getSolarPos2() {
        return solarPos2;
    }

    /**
     * Returns <code>true</code> if the attribute 'solarPos2' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean solarPos2IsValid() {
        return solarPos2IsValid;
    }
}
