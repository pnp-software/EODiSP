/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.earthcare.msi_ret;

import static java.util.concurrent.TimeUnit.SECONDS;
import hla.rti1516.RTIambassador;
import hla.rti1516.RTIexception;
import hla.rti1516.ResignAction;
import hla.rti1516.jlc.RtiFactoryFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import net.jcip.annotations.GuardedBy;
import net.jcip.annotations.ThreadSafe;

import org.apache.log4j.Logger;
import org.eodisp.earthcare.common.util.EarthcareEnvironment;
import org.eodisp.earthcare.common.util.WrapperUtil;
import org.eodisp.earthcare.common.util.input.*;
import org.eodisp.earthcare.msi_ret.proxies.*;
import org.eodisp.util.FileUtil;
import org.eodisp.wrapper.hla.ObjectClassDiscoveryListener;
import org.eodisp.wrapper.hla.ObjectClassInstance;
import org.eodisp.wrapper.hla.StreamChunker;

/**
 * msi_ret federate implementation.
 * 
 * @author ibirrer
 * @version $Id:$
 */
@ThreadSafe
public class MsiRetFederateImpl implements ObjectClassDiscoveryListener {

	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	private final static Logger logger = Logger.getLogger(MsiRetFederateImpl.class);

	private static final int MC_SIM_MAIN_OUTPUT_FILES_COUNT = 41;

	private static final int MC_LW_SIM_MAIN_OUTPUT_FILES_COUNT = 31;

	private final File mcSimMainDir;

	private final MultipleFileInput mcSimMainInput = new MultipleFileInput(MC_SIM_MAIN_OUTPUT_FILES_COUNT);

	private final File mcLwSimMainDir;

	private final MultipleFileInput mcLwSimMainInput = new MultipleFileInput(MC_LW_SIM_MAIN_OUTPUT_FILES_COUNT);

	private final ObjectInput<MsiRetPar> paramInput = new ObjectInput<MsiRetPar>();

	private final ObjectInput<OrbitPropagatorOut> orbitPropagatorInput = new ObjectInput<OrbitPropagatorOut>();

	private final InputManager inputManager;

	private final MsiRetWrapper wrapper;

	@GuardedBy("this")
	private FederateInfo federateInfo;

	@GuardedBy("this")
	private MsiRetFederate federate;

	/**
	 * The msi_ret federate.
	 * 
	 * @throws IOException
	 */
	public MsiRetFederateImpl() throws IOException {
		inputManager = new InputManager();
		inputManager.addInput(mcSimMainInput);
		inputManager.addInput(mcLwSimMainInput);
		inputManager.addInput(paramInput);
		inputManager.addInput(orbitPropagatorInput);
		inputManager.addInputManagerListener(new InputManagerListener() {
			public void inputReady() {
				startEarthcareProcess();
			}
		});

		mcSimMainDir = FileUtil.createTempDir("msi_ret_mcSimMainInput_", "", null);
		mcLwSimMainDir = FileUtil.createTempDir("msi_ret_mcLwSimMainInput_", "", null);
		wrapper = new MsiRetWrapper();
	}

	/**
	 * Starts this federate. Prints the stack trace and exits with an exit code
	 * of <code>1</code> if anything goes wrong.
	 */
	public synchronized void execute() {
		try {
			inputManager.start();
			RTIambassador rtiAmbassador = RtiFactoryFactory.getRtiFactory().getRtiAmbassador();
			federate = new MsiRetFederate(rtiAmbassador);
			federate.addObjectClassDiscoveryListener(this);
			WrapperUtil.eodispStart(federate);
			federateInfo = federate.newFederateInfo();
			federateInfo.setName("msi_ret");
			federateInfo.setModelVersion("1.0.0");
			federateInfo.setExecStatus(ExecStatus.READY);
			federateInfo.updateAttributeValues(WrapperUtil.NULL_BYTE);
			while (true) {
				try {
					this.wait();
				} catch (InterruptedException e) {
					// ignore spurious wakeups
				}
			}
		} catch (Exception e) {
			WrapperUtil.fatalError(e, federate);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void objectInstanceDiscovered(ObjectClassInstance objectClassInstance) {
		if (objectClassInstance instanceof MsiRetPar) {
			MsiRetPar msiRetPar = (MsiRetPar) objectClassInstance;
			logger.debug("Discovered new MsiRetPar instance");
			msiRetPar.addMsiRetParPasselListener(new MsiRetParPasselListener() {
				public void passelUpdated(MsiRetPar source, MsiRetParPassel passel) {
					paramInput.set(source);
				}
			});
		} else if (objectClassInstance instanceof OrbitPropagatorOut) {
			OrbitPropagatorOut orbitPropagatorOut = (OrbitPropagatorOut) objectClassInstance;
			logger.debug("Discovered new OrbitPropagatorOut instance");
			orbitPropagatorOut.addOrbitPropagatorOutPasselListener(new OrbitPropagatorOutPasselListener() {
				public void passelUpdated(OrbitPropagatorOut source, OrbitPropagatorOutPassel passel) {
					orbitPropagatorInput.set(source);
				}
			});
		} else if (objectClassInstance instanceof McSimMainOut) {
			McSimMainOut mcSimMainOut = (McSimMainOut) objectClassInstance;
			logger.debug("Discovered new McSimMainOut instance");
			mcSimMainOut.addMcSimMainOutPasselListener(new McSimMainOutPasselListener() {
				public void passelUpdated(McSimMainOut source, McSimMainOutPassel passel) {
					File file = new File(mcSimMainDir, source.getFilename());
					try {
						mcSimMainInput.receiveChunk(file, passel.getChunk(), passel.getChunkNr(), source
								.getNrOfChunks());
					} catch (IOException e) {
						WrapperUtil.fatalError(e, federate);
					}
				}
			});
		} else if (objectClassInstance instanceof McLwSimMainOut) {
			McLwSimMainOut mcLwSimMainOut = (McLwSimMainOut) objectClassInstance;
			logger.debug("Discovered new McLwSimMainOut instance");

			mcLwSimMainOut.addMcLwSimMainOutPasselListener(new McLwSimMainOutPasselListener() {

				public void passelUpdated(McLwSimMainOut source, McLwSimMainOutPassel passel) {
					File file = new File(mcLwSimMainDir, source.getFilename());
					try {
						mcLwSimMainInput.receiveChunk(file, passel.getChunk(), passel.getChunkNr(), source
								.getNrOfChunks());
					} catch (IOException e) {
						WrapperUtil.fatalError(e, federate);
					}
				}
			});
		}
	}

	private synchronized void startEarthcareProcess() {
		MsiRetPar msiRetPar = paramInput.get();
		OrbitPropagatorOut orbitPropagatorOut = orbitPropagatorInput.get();
		wrapper.setSolarPosition(orbitPropagatorOut.getSolarPos1(), orbitPropagatorOut.getSolarPos2());

		try {
			federateInfo.setFailureMode(msiRetPar.getFailureMode(), WrapperUtil.NULL_BYTE);
			File outputLocation = FileUtil.createTempDir("msi_ret_out_", "", null);
			System.out.println("Starting msi_ret ...");
			System.out.println("msi_ret output: " + outputLocation.getAbsolutePath());
			wrapper.exec(mcSimMainDir, mcLwSimMainDir, outputLocation);
			updateExecStatus(ExecStatus.DONE);
			int fileCount = 0;
			for (File file : outputLocation.listFiles()) {
				if (file.isDirectory()) {
					continue;
				}
				MsiRetOut msiRetOut = federate.newMsiRetOut();
				StreamChunker streamChunker = new StreamChunker(new FileInputStream(file),
						EarthcareEnvironment.DEFAULT_CHUNK_SIZE, file.length());
				msiRetOut.setFilename(file.getName());
				// TODO: Use long for HLA streams
				msiRetOut.setNrOfChunks((int) streamChunker.getTotalChunkCount());
				int chunkNr = 0;
				while (streamChunker.hasMoreChunks()) {
					msiRetOut.setChunkNr(chunkNr++);
					msiRetOut.setChunk(streamChunker.nextChunk());
					msiRetOut.updateAttributeValues(WrapperUtil.NULL_BYTE);
				}
				System.out.println("Sent file: " + ++fileCount);
			}
			updateExecStatus(ExecStatus.SHUTTING_DOWN);

			federate.achieveSyncPointAndAwaitFederationSynchronization("EODISP_STOP", Long.MAX_VALUE, SECONDS);
			federate.getRtiAmbassador().resignFederationExecution(ResignAction.UNCONDITIONALLY_DIVEST_ATTRIBUTES);
			System.exit(0);
		} catch (Exception e) {
			WrapperUtil.fatalError(e, federate);
		}
		System.exit(1);
	}

	/**
	 * Convenience method to access the federate info guarded by the lock of
	 * this class.
	 * 
	 * @param pExecStatus
	 *            the new attribute value
	 * @exception RTIexception
	 *                The new exec status could not be delivered to the
	 *                federation
	 */
	private synchronized void updateExecStatus(ExecStatus execStatus) throws RTIexception {
		federateInfo.setExecStatus(execStatus, WrapperUtil.NULL_BYTE);
	}
}
