package org.eodisp.earthcare.sim_controller_test;

import org.eodisp.earthcare.sim_controller.SimControllerFederateMainOld;

/**
 * A test federate if Microsoft Excel is not availiable. Consider to use
 * {@link SimControllerFederateMainOld} otherwise.
 * 
 * @author ibirrer
 */
public class SimControllerTestFederateMain {

	public static void main(String[] args) {
		try {
			SimControllerTestImpl simControllerTestImpl = new SimControllerTestImpl();
			simControllerTestImpl.execute();
		} catch (Throwable e) {
			e.printStackTrace();
			System.exit(1);
		}
		System.exit(0);
	}
}
