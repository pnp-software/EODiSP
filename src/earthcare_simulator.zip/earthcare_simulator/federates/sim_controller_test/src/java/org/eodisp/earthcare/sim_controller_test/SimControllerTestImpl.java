/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.earthcare.sim_controller_test;

import static java.util.concurrent.TimeUnit.SECONDS;
import hla.rti1516.RTIambassador;
import hla.rti1516.ResignAction;
import hla.rti1516.jlc.RtiFactoryFactory;

import net.jcip.annotations.GuardedBy;

import org.eodisp.earthcare.common.util.WrapperUtil;
import org.eodisp.earthcare.sim_controller.proxies.*;
import org.eodisp.wrapper.hla.ObjectClassDiscoveryListener;
import org.eodisp.wrapper.hla.ObjectClassInstance;

/**
 * @author ibirrer
 * @version $Id:$
 */
public class SimControllerTestImpl implements ObjectClassDiscoveryListener {

	@GuardedBy("this")
	private SimControllerFederate federate;

	public synchronized void execute() throws Exception {
		RTIambassador rtiAmbassador = RtiFactoryFactory.getRtiFactory().getRtiAmbassador();
		federate = new SimControllerFederate(rtiAmbassador);
		federate.addObjectClassDiscoveryListener(this);
		WrapperUtil.eodispStart(federate);
		System.out.println("Setting scene_creator parameters");
		SceneCreatorPar sceneCreatorPar = federate.newSceneCreatorPar();
		sceneCreatorPar.setFailureMode(FailureMode.NOMINAL);
		sceneCreatorPar.setHorizontalResolution(0.5f);
		sceneCreatorPar.setXExtent(10.0f);
		sceneCreatorPar.setYExtent(10.0f);
		sceneCreatorPar.setZExtent(100.0f);
		sceneCreatorPar.updateAttributeValues(WrapperUtil.NULL_BYTE);

		System.out.println("Setting lid_filter parameters");
		LidFilterPar lidFilterPar = federate.newLidFilterPar();
		lidFilterPar.setFailureMode(FailureMode.NOMINAL);
		lidFilterPar.setLaserLineWidth(30);
		lidFilterPar.setLaserPulseEnergy(0.035f);
		lidFilterPar.updateAttributeValues(WrapperUtil.NULL_BYTE);

		System.out.println("Setting rad_filter parameters");
		RadFilterPar radFilterPar = federate.newRadFilterPar();
		radFilterPar.setFailureMode(FailureMode.NOMINAL);
		radFilterPar.setStartingAltitude(0.0f);
		radFilterPar.setEndingAltitude(14.0f);
		radFilterPar.updateAttributeValues(WrapperUtil.NULL_BYTE);

		System.out.println("Setting mc_lw_sim_main parameters");
		McLwSimMainPar mcLwSimMainPar = federate.newMcLwSimMainPar();
		mcLwSimMainPar.setFailureMode(FailureMode.NOMINAL);
		mcLwSimMainPar.setOutputResolution(0.5f);
		mcLwSimMainPar.setRandomNumberSeed(-1);
		mcLwSimMainPar.updateAttributeValues(WrapperUtil.NULL_BYTE);

		System.out.println("Setting mc_sim_main parameters");
		McSimMainPar mcSimMainPar = federate.newMcSimMainPar();
		mcSimMainPar.setFailureMode(FailureMode.NOMINAL);
		mcSimMainPar.setOutputResolution(0.5f);
		mcSimMainPar.setRandomNumberSeed(-1);
		mcSimMainPar.updateAttributeValues(WrapperUtil.NULL_BYTE);

		System.out.println("Setting lidar parameters");
		LidarPar lidarPar = federate.newLidarPar();
		lidarPar.setFailureMode(FailureMode.NOMINAL);
		lidarPar.setDetectorQuantumEfficiency(0.2f);
		lidarPar.setNumberOfOpticalElements(4);
		lidarPar.updateAttributeValues(WrapperUtil.NULL_BYTE);

		System.out.println("Setting radar parameters");
		RadarPar radarPar = federate.newRadarPar();
		radarPar.setFailureMode(FailureMode.NOMINAL);
		radarPar.setPulseRepetitionFrequency(6800);
		radarPar.updateAttributeValues(WrapperUtil.NULL_BYTE);

		System.out.println("Setting lidar_ret1 parameters");
		LidarRet1Par lidarRet1Par = federate.newLidarRet1Par();
		lidarRet1Par.setFailureMode(FailureMode.NOMINAL);
		lidarRet1Par.setHorizontalResolution(1.0f);
		lidarRet1Par.setVerticalResolution(0.2f);
		lidarRet1Par.updateAttributeValues(WrapperUtil.NULL_BYTE);

		System.out.println("Setting lw_msi_lidar_radar parameters");
		LwMsiLidarRadarPar lwMsiLidarRadarPar = federate.newLwMsiLidarRadarPar();
		lwMsiLidarRadarPar.setFailureMode(FailureMode.NOMINAL);
		lwMsiLidarRadarPar.setMaxIterations(5000);
		lwMsiLidarRadarPar.updateAttributeValues(WrapperUtil.NULL_BYTE);

		System.out.println("Setting msi_ret parameters");
		MsiRetPar msiRetPar = federate.newMsiRetPar();
		msiRetPar.setFailureMode(FailureMode.NOMINAL);
		msiRetPar.updateAttributeValues(WrapperUtil.NULL_BYTE);

		System.out.println("Setting orbit_propagator parameters");
		OrbitPropagatorPar orbitPropagatorPar = federate.newOrbitPropagatorPar();
		orbitPropagatorPar.setSolarPos1(0.610865238);
		orbitPropagatorPar.setSolarPos2(0.698131701);
		orbitPropagatorPar.updateAttributeValues(WrapperUtil.NULL_BYTE);

		federate.achieveSyncPointAndAwaitFederationSynchronization("EODISP_STOP", Long.MAX_VALUE, SECONDS);
		federate.getRtiAmbassador().resignFederationExecution(ResignAction.UNCONDITIONALLY_DIVEST_ATTRIBUTES);
		System.exit(0);
	}

	public void objectInstanceDiscovered(ObjectClassInstance objectClassInstance) {
		if (objectClassInstance instanceof FederateInfo) {
			FederateInfo federateInfo = (FederateInfo) objectClassInstance;
			federateInfo.addFederateInfoListener(new FederateInfoListener() {
				public void execStatusUpdated(FederateInfo source, FederateInfoPassel passel, ExecStatus newValue) {
					System.out.printf("%s: New Exec Status: %s%n", source.getName(), newValue);
				}

				public void failureModeUpdated(FederateInfo source, FederateInfoPassel passel, FailureMode newValue) {
					System.out.printf("%s: New Failure Mode: %s%n", source.getName(), newValue);
				}

				public void modelVersionUpdated(FederateInfo source, FederateInfoPassel passel, String newValue) {
					System.out.printf("%s: New Version: %s%n", source.getName(), newValue);
				}

				public void nameUpdated(FederateInfo source, FederateInfoPassel passel, String newValue) {
					System.out.printf("%s: New Name: %s%n", source.getName(), newValue);
				}
			});
		}
	}
}
