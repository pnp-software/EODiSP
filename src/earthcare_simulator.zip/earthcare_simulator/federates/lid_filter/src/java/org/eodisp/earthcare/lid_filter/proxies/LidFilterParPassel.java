package org.eodisp.earthcare.lid_filter.proxies;


/**
 * Attributes that represent parameters that are specific to the lid_filter model
 *
 * @author org.eodisp.wrapper.hla.ProxyCompiler
 */

public class LidFilterParPassel extends EarthCAREPassel {
    /**
     * The failure mode of the lid_filter model 
     */
    FailureMode failureMode;

    /**
     * Whether or not the failureMode attribute has been set.
     */
    boolean failureModeIsValid;

    /**
     * The laser pulse energy in Joules (an input parameter for the lid_filter
     * program) 
     */
    float laserPulseEnergy;

    /**
     * Whether or not the laserPulseEnergy attribute has been set.
     */
    boolean laserPulseEnergyIsValid;

    /**
     * The laser line width in MHz (an input parameter for the lid_filter program)
     */
    float laserLineWidth;

    /**
     * Whether or not the laserLineWidth attribute has been set.
     */
    boolean laserLineWidthIsValid;

    /**
     * Returns the value of the failureMode attribute.
     *
     * @return the current attribute value
     */
    public FailureMode getFailureMode() {
        return failureMode;
    }

    /**
     * Returns <code>true</code> if the attribute 'failureMode' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean failureModeIsValid() {
        return failureModeIsValid;
    }
    /**
     * Returns the value of the laserPulseEnergy attribute.
     *
     * @return the current attribute value
     */
    public float getLaserPulseEnergy() {
        return laserPulseEnergy;
    }

    /**
     * Returns <code>true</code> if the attribute 'laserPulseEnergy' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean laserPulseEnergyIsValid() {
        return laserPulseEnergyIsValid;
    }
    /**
     * Returns the value of the laserLineWidth attribute.
     *
     * @return the current attribute value
     */
    public float getLaserLineWidth() {
        return laserLineWidth;
    }

    /**
     * Returns <code>true</code> if the attribute 'laserLineWidth' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean laserLineWidthIsValid() {
        return laserLineWidthIsValid;
    }
}
