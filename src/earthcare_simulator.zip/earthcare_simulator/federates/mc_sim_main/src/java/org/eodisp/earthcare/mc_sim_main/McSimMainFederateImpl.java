/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.earthcare.mc_sim_main;

import static java.util.concurrent.TimeUnit.SECONDS;
import hla.rti1516.RTIambassador;
import hla.rti1516.RTIexception;
import hla.rti1516.ResignAction;
import hla.rti1516.jlc.RtiFactoryFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import net.jcip.annotations.GuardedBy;
import net.jcip.annotations.ThreadSafe;

import org.eodisp.earthcare.common.util.EarthcareEnvironment;
import org.eodisp.earthcare.common.util.WrapperUtil;
import org.eodisp.earthcare.common.util.input.*;
import org.eodisp.earthcare.mc_sim_main.proxies.*;
import org.eodisp.util.FileUtil;
import org.eodisp.wrapper.hla.ObjectClassDiscoveryListener;
import org.eodisp.wrapper.hla.ObjectClassInstance;
import org.eodisp.wrapper.hla.StreamChunker;


/**
 * mc_sim_main federate implementation.
 * 
 * @author ibirrer
 * @version $Id:$
 */
@ThreadSafe
public class McSimMainFederateImpl implements ObjectClassDiscoveryListener {

	private final File sceneFile;

	private final FileInput sceneFileInput = new FileInput();

	private final ObjectInput<McSimMainPar> paramInput = new ObjectInput<McSimMainPar>();

	private final InputManager inputManager;

	private final McSimMainWrapper wrapper;

	/**
	 * Whether to skip the execution of the earthcare executable and use
	 * pre-calculated values or not
	 */
	private final boolean skipExecution;

	@GuardedBy("this")
	private FederateInfo federateInfo;

	@GuardedBy("this")
	private McSimMainFederate federate;

	/**
	 * @param sceneInputFile
	 *            directory in which received files are saved
	 * @param skipExecution
	 *            if this is set to <code>true</code>, the EarthCARE
	 *            executable is not run but only the pre-calculated output files
	 *            in {@link EarthcareEnvironment#getEarthcareInstallDir()}/output/lw_mc
	 *            are sent to the federation
	 * @throws IOException
	 */
	public McSimMainFederateImpl(boolean skipExecution) throws IOException {
		this.skipExecution = skipExecution;
		inputManager = new InputManager();
		inputManager.addInput(sceneFileInput);
		inputManager.addInput(paramInput);
		inputManager.addInputManagerListener(new InputManagerListener() {
			public void inputReady() {
				startEarthcareProcess();
			}

		});

		sceneFile = File.createTempFile("mcMwSimMain_sceneInput", "");
		wrapper = new McSimMainWrapper();
	}

	/**
	 * Starts this federate. Prints the stack trace and exits with an exit code
	 * of <code>1</code> if anything goes wrong.
	 */
	public synchronized void execute() {
		try {
			inputManager.start();
			RTIambassador rtiAmbassador = RtiFactoryFactory.getRtiFactory().getRtiAmbassador();
			federate = new McSimMainFederate(rtiAmbassador);
			federate.addObjectClassDiscoveryListener(this);
			WrapperUtil.eodispStart(federate);
			federateInfo = federate.newFederateInfo();
			federateInfo.setName("mc_sim_main");
			federateInfo.setModelVersion("1.0.0");
			federateInfo.setExecStatus(ExecStatus.READY);
			federateInfo.updateAttributeValues(WrapperUtil.NULL_BYTE);
			while (true) {
				try {
					this.wait();
				} catch (InterruptedException e) {
					// ignore spurious wakeups
				}
			}
		} catch (Exception e) {
			WrapperUtil.fatalError(e, federate);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void objectInstanceDiscovered(ObjectClassInstance objectClassInstance) {
		if (objectClassInstance instanceof McSimMainPar) {
			McSimMainPar mcSimMainPar = (McSimMainPar) objectClassInstance;
			mcSimMainPar.addMcSimMainParPasselListener(new McSimMainParPasselListener() {
				public void passelUpdated(McSimMainPar source, McSimMainParPassel passel) {
					paramInput.set(source);
				}
			});
		} else if (objectClassInstance instanceof SceneCreatorOut) {
			SceneCreatorOut sceneCreatorOutInstance = (SceneCreatorOut) objectClassInstance;
			sceneCreatorOutInstance.addSceneCreatorOutPasselListener(new SceneCreatorOutPasselListener() {
				public synchronized void passelUpdated(SceneCreatorOut source, SceneCreatorOutPassel passel) {
					try {
						sceneFileInput.receiveChunk(sceneFile, passel.getChunk(), passel.getChunkNr(), source
								.getNrOfChunks());
					} catch (IOException e) {
						WrapperUtil.fatalError(e, federate);
					}
				}
			});
		}
	}

	private synchronized void startEarthcareProcess() {
		McSimMainPar mcSimMainPar = paramInput.get();
		wrapper.setOutputResolution(mcSimMainPar.getOutputResolution());
		wrapper.setRandomNumberSeed(mcSimMainPar.getRandomNumberSeed());
		
		try {
			federateInfo.setFailureMode(mcSimMainPar.getFailureMode(), WrapperUtil.NULL_BYTE);
			File outputLocation = skipExecution ? McSimMainWrapper.getPreCalculatedOutputLocation() : FileUtil
					.createTempDir("sw_mc_", "", null);
			System.out.println("Starting mc_sim_main ...");
			if (!skipExecution) {
				wrapper.exec(sceneFile, outputLocation);
			}
			updateExecStatus(ExecStatus.DONE);
			for (File file : outputLocation.listFiles()) {
				if (file.isDirectory()) {
					continue;
				}
				McSimMainOut mcSimMainOut = federate.newMcSimMainOut();
				StreamChunker streamChunker = new StreamChunker(new FileInputStream(file),
						EarthcareEnvironment.DEFAULT_CHUNK_SIZE, file.length());
				mcSimMainOut.setFilename(file.getName());
				// TODO: Use long for HLA streams
				mcSimMainOut.setNrOfChunks((int) streamChunker.getTotalChunkCount());
				int chunkNr = 0;
				while (streamChunker.hasMoreChunks()) {
					mcSimMainOut.setChunkNr(chunkNr++);
					mcSimMainOut.setChunk(streamChunker.nextChunk());
					mcSimMainOut.updateAttributeValues(WrapperUtil.NULL_BYTE);
				}
			}
			updateExecStatus(ExecStatus.SHUTTING_DOWN);

			federate.achieveSyncPointAndAwaitFederationSynchronization("EODISP_STOP", Long.MAX_VALUE, SECONDS);
			federate.getRtiAmbassador().resignFederationExecution(ResignAction.UNCONDITIONALLY_DIVEST_ATTRIBUTES);
			System.exit(0);
		} catch (Exception e) {
			WrapperUtil.fatalError(e, federate);
		}
		System.exit(1);
	}

	/**
	 * Convenience method to access the federate info guarded by the lock of
	 * this class.
	 * 
	 * @param pExecStatus
	 *            the new attribute value
	 * @exception RTIexception
	 *                The new exec status could not be delivered to the
	 *                federation
	 */
	private synchronized void updateExecStatus(ExecStatus execStatus) throws RTIexception {
		federateInfo.setExecStatus(execStatus, WrapperUtil.NULL_BYTE);
	}
}
