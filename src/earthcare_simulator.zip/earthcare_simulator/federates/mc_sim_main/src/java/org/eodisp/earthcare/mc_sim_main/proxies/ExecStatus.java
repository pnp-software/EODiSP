package org.eodisp.earthcare.mc_sim_main.proxies;

import java.io.*;
import hla.rti1516.jlc.*;
import hla.rti1516.jlc.omt.*;

import org.eodisp.wrapper.hla.*;

/**
 * The execution status of an EarthCARE federate 
 *
 * @author org.eodisp.wrapper.hla.ProxyCompiler
 */

public class ExecStatus implements Cloneable, Serializable
{
    /**
     * Enumerator #0.
     */
    public static final ExecStatus READY = new ExecStatus(0);

    /**
     * Enumerator #1.
     */
    public static final ExecStatus RUNNING = new ExecStatus(1);

    /**
     * Enumerator #2.
     */
    public static final ExecStatus DONE = new ExecStatus(2);

    /**
     * Enumerator #3.
     */
    public static final ExecStatus SHUTTING_DOWN = new ExecStatus(3);

    /**
     * The value of the instance.
     */
    private int value;


    /**
     * Reads and returns a ExecStatus from the specified byte array
     *
     * @param value the byte array to read from
     * @return the decoded value
     */
    public static ExecStatus decode(byte[] value) {
        ByteWrapper byteWrapper = new ByteWrapper(value);
        HLAinteger32BE dataElement =  OmtEncoderFactory.getInstance().createHLAinteger32BE();
        dataElement.decode(byteWrapper);
        return new ExecStatus(dataElement.getValue());
    }

    /**
     * Returns a ExecStatus from the integer value
     *
     * @param value the byte array to read from
     * @return the decoded value
     */
    public static ExecStatus valueOf(int value) {
        switch( value ) {
            case 0:
            return READY;
            case 1:
            return RUNNING;
            case 2:
            return DONE;
            case 3:
            return SHUTTING_DOWN;
            default:
            throw new IllegalArgumentException();
        }
    }

    /**
     * Default constructor (READY).
     */
    public ExecStatus()
    {
        value = READY.value;
    }

    /**
     * Copy constructor.
     *
     * @param other the other ExecStatus to copy
     */
    public ExecStatus(ExecStatus other)
    {
        value = other.value;
    }

    /**
     * Private constructor.
     *
     * @param pValue the instance value
     */
    private ExecStatus(int pValue)
    {
        value = pValue;
    }

    /**
     * Compares this ExecStatus for equality with another.
     *
     * @param other the other ExecStatus
     * @return <code>true</code> if the two enumerated types are equal,
     * <code>false</code> otherwise
     */
    public boolean equals(Object other)
    {
        try
        {
            return ( value == ((ExecStatus)other).value );
        }
        catch(ClassCastException cce)
        {
            return false;
        }
    }

    /**
     * Computes and returns a hash code corresponding to this ExecStatus.
     *
     * @return a hash code corresponding to this ExecStatus
     */
    public int hashCode()
    {
        return value;
    }

    /**
     * Returns the HLA encoded value of thisExecStatus
     */
    public HLAinteger32BE encode() {
        HLAinteger32BE encoded = OmtEncoderFactory.getInstance().createHLAinteger32BE(value);
        return encoded;
    }

    /**
     * Returns a string representation of this ExecStatus
     *
     * @return a string representation of this ExecStatus
     */
    public String toString()
    {
        if( this.equals(READY) )
        {
            return "READY";
        }
        else if( this.equals(RUNNING) )
        {
            return "RUNNING";
        }
        else if( this.equals(DONE) )
        {
            return "DONE";
        }
        else if( this.equals(SHUTTING_DOWN) )
        {
            return "SHUTTING_DOWN";
        }
        else
        {
            return "ExecStatus #" + value;
        }
    }
}
