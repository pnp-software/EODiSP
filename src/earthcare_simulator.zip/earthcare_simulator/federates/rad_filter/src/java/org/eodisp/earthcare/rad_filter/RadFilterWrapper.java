/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.earthcare.rad_filter;

import java.io.File;
import java.io.IOException;

import org.apache.tools.ant.types.Commandline;
import org.eodisp.earthcare.common.util.*;
import org.eodisp.earthcare.scene_creator.SceneCreatorWrapper;
import org.eodisp.util.launcher.Process;
import org.eodisp.util.launcher.ProcessImpl;

/**
 * Wrapper wrapper for the the <code>rad_filter</code> executable of the
 * EarthCARE simulator.
 * 
 * @author ibirrer
 */
public class RadFilterWrapper extends AbstractEarthcareWrapper {
	private static final String EXECUTABLE = "rad_filter";

	private static final int STARTING_ALTITUDE_LINE = 5;

	private static final int ENDING_ALTITIDE_LINE = 6;

	private final LineEditor radFilterInputEditor = new LineEditor();

	/**
	 * Sets the starting altitude in km
	 * 
	 * @param value
	 *            the starting altitude in km
	 */
	public void setStartingAltitude(double value) {
		radFilterInputEditor.addLineReplacement(STARTING_ALTITUDE_LINE, value + "");
	}

	/**
	 * Sets the ending altitude in km
	 * 
	 * @param value
	 *            the ending altitude in km
	 */
	public void setEndingAltitude(double value) {
		radFilterInputEditor.addLineReplacement(ENDING_ALTITIDE_LINE, value + "");
	}
	
	public static File getPreCalculatedOuput() throws IOException {
		return new File(EarthcareEnvironment.getEarthcareInstallDir(), "output/rad_filter/rad_filter.out");
	}

	/**
	 * Executes the <code>rad_filter</code> executable. The EarthCARE
	 * installation directory is determined by the environment variable
	 * <code>EARTHCARE_INSTALL_DIR</code>.
	 * <p>
	 * The file <code>$EARTHCARE_INSTALL_DIR/input/master.inp</code> serves as
	 * the template master file. It is copied to a new temporary file. This
	 * temporary file is then used as the input to the executable.
	 * <p>
	 * Reacts to thread interruption with killing the process. Adds a shutdown
	 * hook, as to kill the underlying earthcare process if this java process is
	 * killed.
	 * 
	 * @param inputScene
	 *            the input scene file (normally created by the
	 *            <code>scene_creator</code> executable)
	 * @param filteredSceneOutput
	 *            The filtered output scene created by the rad_filter executable
	 * @throws IOException
	 *             if an IOException occurs when starting the
	 *             <code>rad_filter</code> process or if the
	 *             <code>EARTHCARE_INSTALL_DIR</code> environment variable is
	 *             not set.
	 */
	public void exec(File inputScene, File filteredSceneOutput) throws IOException {
		System.out.printf("rad_filter input scene: %s%n", inputScene.getAbsolutePath());
		System.out.printf("rad_filter output scene: %s%n", filteredSceneOutput.getAbsolutePath());

		// Prepare temporary input files
		File masterFile = File.createTempFile("master_", ".inp");
		System.out.printf("Master file: %s%n", masterFile);
		File radFilterInput = File.createTempFile("rad_filter_", ".inp");
		System.out.printf("rad_filter input: %s%n", radFilterInput);

		// Create input files from templates
		radFilterInputEditor.edit(getradFilterInputTemplate(), radFilterInput);
		MasterFileGenerator masterFileGenerator = new MasterFileGenerator();
		masterFileGenerator.setRadFilterInput(radFilterInput.getAbsolutePath());
		masterFileGenerator.setSceneFile(inputScene.getAbsolutePath());
		masterFileGenerator.setRadFilterOutput(filteredSceneOutput.getAbsolutePath());
		masterFileGenerator.generate(EarthcareEnvironment.getMasterTemplate(), masterFile);

		// Prepare command line
		Commandline commandline = new Commandline();
		commandline.setExecutable(new File(new File(EarthcareEnvironment.getEarthcareInstallDir(), "bin"), EXECUTABLE)
				.getCanonicalPath());
		commandline.createArgument().setValue(masterFile.getCanonicalPath());

		// Start process
		Process process = new ProcessImpl(commandline, EarthcareEnvironment.getEarthcareInstallDir());
		process.addEnvVar("NOXTERMFWIN", "true");
		WrapperUtil.addInterruptShutdownHook(Thread.currentThread());
		process.launchBlocking();
	}

	/**
	 * Return the rad_filter input file template.
	 * 
	 * @return the absolute path of the rad_filter input file template
	 * @throws IOException
	 *             if the environment variable
	 *             <code>$EARTHCARE_INSTALL_DIR</code> is not set.
	 */
	private File getradFilterInputTemplate() throws IOException {
		File radFilterInputOrig = new File(new File(new File(EarthcareEnvironment.getEarthcareInstallDir(), "input"),
				"rad_filter"), "rad_filter.inp").getCanonicalFile();
		System.out.printf("rad_filter input template: %s%n", radFilterInputOrig);
		return radFilterInputOrig;
	}

	/**
	 * Test only
	 * 
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) {
		try {
			final File scene = File.createTempFile("scene_", "");
			final File filteredScene = File.createTempFile("radFilteredScene_", "");
			SceneCreatorWrapper sceneCreatorWrapper = new SceneCreatorWrapper();
			sceneCreatorWrapper.setExtent(1, 10, 100);
			sceneCreatorWrapper.exec(scene);
			RadFilterWrapper radFilterWrapper = new RadFilterWrapper();
			radFilterWrapper.exec(scene, filteredScene);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
