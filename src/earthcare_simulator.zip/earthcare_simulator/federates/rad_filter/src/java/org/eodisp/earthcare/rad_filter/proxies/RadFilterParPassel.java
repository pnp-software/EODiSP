package org.eodisp.earthcare.rad_filter.proxies;


/**
 * Attributes that represent parameters that are specific to the rad_filter model
 *
 * @author org.eodisp.wrapper.hla.ProxyCompiler
 */

public class RadFilterParPassel extends EarthCAREPassel {
    /**
     * The failure mode of the rad_filter model 
     */
    FailureMode failureMode;

    /**
     * Whether or not the failureMode attribute has been set.
     */
    boolean failureModeIsValid;

    /**
     * The starting altitude in km 
     */
    float startingAltitude;

    /**
     * Whether or not the startingAltitude attribute has been set.
     */
    boolean startingAltitudeIsValid;

    /**
     * The ending altitude in km 
     */
    float endingAltitude;

    /**
     * Whether or not the endingAltitude attribute has been set.
     */
    boolean endingAltitudeIsValid;

    /**
     * Returns the value of the failureMode attribute.
     *
     * @return the current attribute value
     */
    public FailureMode getFailureMode() {
        return failureMode;
    }

    /**
     * Returns <code>true</code> if the attribute 'failureMode' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean failureModeIsValid() {
        return failureModeIsValid;
    }
    /**
     * Returns the value of the startingAltitude attribute.
     *
     * @return the current attribute value
     */
    public float getStartingAltitude() {
        return startingAltitude;
    }

    /**
     * Returns <code>true</code> if the attribute 'startingAltitude' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean startingAltitudeIsValid() {
        return startingAltitudeIsValid;
    }
    /**
     * Returns the value of the endingAltitude attribute.
     *
     * @return the current attribute value
     */
    public float getEndingAltitude() {
        return endingAltitude;
    }

    /**
     * Returns <code>true</code> if the attribute 'endingAltitude' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean endingAltitudeIsValid() {
        return endingAltitudeIsValid;
    }
}
