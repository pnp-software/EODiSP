/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.earthcare.matlab_display;

import static java.util.concurrent.TimeUnit.SECONDS;
import hla.rti1516.RTIambassador;
import hla.rti1516.RTIexception;
import hla.rti1516.ResignAction;
import hla.rti1516.jlc.RtiFactoryFactory;

import java.io.*;

import jmatlink.JMatLink;
import net.jcip.annotations.GuardedBy;
import net.jcip.annotations.ThreadSafe;

import org.apache.log4j.Logger;
import org.eodisp.earthcare.common.util.EarthcareEnvironment;
import org.eodisp.earthcare.common.util.WrapperUtil;
import org.eodisp.earthcare.common.util.input.FileInput;
import org.eodisp.earthcare.common.util.input.InputManager;
import org.eodisp.earthcare.common.util.input.InputManagerListener;
import org.eodisp.earthcare.matlab_display.proxies.*;
import org.eodisp.wrapper.hla.FederationState;
import org.eodisp.wrapper.hla.ObjectClassDiscoveryListener;
import org.eodisp.wrapper.hla.ObjectClassInstance;
import org.eodisp.wrapper.hla.EodispFederate.FederationStateListener;

/**
 * matlab_display federate implementation.
 * 
 * @author ibirrer
 * @version $Id:$
 */
@ThreadSafe
public class MatlabDisplayFederateImpl implements ObjectClassDiscoveryListener, FederationStateListener {

	private static final int LIDAR_OUTPUT_FILES_COUNT = 22;

	private final File radarFile;

	private final FileInput radarInput = new FileInput();

	private final InputManager inputManager;

	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	private final static Logger logger = Logger.getLogger(MatlabDisplayFederateImpl.class);

	@GuardedBy("this")
	private FederateInfo federateInfo;

	@GuardedBy("this")
	private MatlabDisplayFederate federate;

	/**
	 * @param sceneInputFile
	 *            directory in which received files are saved
	 * @param skipExecution
	 *            if this is set to <code>true</code>, the EarthCARE
	 *            executable is not run but only the pre-calculated output files
	 *            in {@link EarthcareEnvironment#getEarthcareInstallDir()}/output/lw_mc
	 *            are sent to the federation
	 * @throws IOException
	 */
	public MatlabDisplayFederateImpl() throws IOException {
		inputManager = new InputManager();
		inputManager.addInput(radarInput);
		inputManager.addInputManagerListener(new InputManagerListener() {
			public void inputReady() {
				if (federate.getState() != FederationState.PAUSED) {
					startEarthcareProcess();
				} else {
					logger
							.info("All input available for radar federate, but not starting because the federation is in the PAUSED state");
				}
			}
		});

		radarFile = File.createTempFile("matlab_display_radarInput_", "");
	}

	/**
	 * Starts this federate. Prints the stack trace and exits with an exit code
	 * of <code>1</code> if anything goes wrong.
	 */
	public synchronized void execute() {
		try {
			inputManager.start();
			RTIambassador rtiAmbassador = RtiFactoryFactory.getRtiFactory().getRtiAmbassador();
			federate = new MatlabDisplayFederate(rtiAmbassador);
			federate.addObjectClassDiscoveryListener(this);
			federate.addFederationStateListener(this);
			WrapperUtil.eodispStart(federate);
			federateInfo = federate.newFederateInfo();
			federateInfo.setName("matlab_display");
			federateInfo.setModelVersion("1.0.0");
			federateInfo.setExecStatus(ExecStatus.READY);
			federateInfo.updateAttributeValues(WrapperUtil.NULL_BYTE);
			while (true) {
				try {
					this.wait();
				} catch (InterruptedException e) {
					// ignore spurious wakeups
				}
			}
		} catch (Exception e) {
			WrapperUtil.fatalError(e, federate);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void objectInstanceDiscovered(ObjectClassInstance objectClassInstance) {
		if (objectClassInstance instanceof RadarOut) {
			RadarOut radarOut = (RadarOut) objectClassInstance;
			System.out.println("Discovered new RadarOut instance");
			radarOut.addRadarOutPasselListener(new RadarOutPasselListener() {
				public void passelUpdated(RadarOut source, RadarOutPassel passel) {
					try {
						radarInput.receiveChunk(radarFile, passel.getChunk(), passel.getChunkNr(), source
								.getNrOfChunks());
					} catch (IOException e) {
						WrapperUtil.fatalError(e, federate);
					}
				}
			});
		}
	}

	private synchronized void startEarthcareProcess() {
		try {
			System.out.println("Starting matlab_display ...");
			File bundlePath = new File(System.getProperty("org.eodisp.bundle-path"));
			File file = new File(bundlePath, "resources/CPR_Reflectivity.m");
			if (!file.exists()) {
				throw new RuntimeException(String.format("Could not open Matlab m file: %s", file));
			}
			BufferedReader reader = new BufferedReader(new FileReader(file));
			String line = "";
			JMatLink engine = new JMatLink();
			engine.engOpen();
			engine.engEvalString("clear;");
			String fileEval = String.format("fid = fopen('%s','r');", radarFile.getAbsolutePath());
			System.out.println("Eval: " + fileEval);
			engine.engEvalString(fileEval);

			while ((line = reader.readLine()) != null) {
				System.out.println("Eval: " + line);
				engine.engEvalString(line);
			}

			federateInfo.setFailureMode(FailureMode.NOMINAL, WrapperUtil.NULL_BYTE);
			updateExecStatus(ExecStatus.DONE);
			updateExecStatus(ExecStatus.SHUTTING_DOWN);
			federate.achieveSyncPointAndAwaitFederationSynchronization("EODISP_STOP", Long.MAX_VALUE, SECONDS);
			engine.engClose();
			federate.getRtiAmbassador().resignFederationExecution(ResignAction.UNCONDITIONALLY_DIVEST_ATTRIBUTES);
			System.exit(0);
		} catch (Exception e) {
			WrapperUtil.fatalError(e, federate);
		}
		System.exit(1);
	}

	/**
	 * Convenience method to access the federate info guarded by the lock of
	 * this class.
	 * 
	 * @param pExecStatus
	 *            the new attribute value
	 * @exception RTIexception
	 *                The new exec status could not be delivered to the
	 *                federation
	 */
	private synchronized void updateExecStatus(ExecStatus execStatus) throws RTIexception {
		federateInfo.setExecStatus(execStatus, WrapperUtil.NULL_BYTE);
	}

	public void stateChanged(FederationState newState) {
		if ((newState == FederationState.RESUMING || newState == FederationState.STEPPING) && inputManager.isReady()) {
			logger.info("radar federate starts processing due state change to: " + newState);
			Thread t = new Thread() {
				@Override
				public void run() {
					startEarthcareProcess();
				}
			};
			t.start();
		}

	}
}
