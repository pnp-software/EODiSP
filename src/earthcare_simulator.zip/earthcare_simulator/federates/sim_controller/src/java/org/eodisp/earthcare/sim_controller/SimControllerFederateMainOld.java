package org.eodisp.earthcare.sim_controller;

import static java.util.concurrent.TimeUnit.SECONDS;
import hla.rti1516.*;
import hla.rti1516.jlc.RtiFactoryFactory;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.log4j.Logger;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eodisp.earthcare.scene_creator.FederateAppModule;
import org.eodisp.earthcare.scene_creator.FederateConfiguration;
import org.eodisp.earthcare.sim_controller.proxies.*;
import org.eodisp.util.RootApp;
import org.eodisp.wrapper.excel.*;
import org.eodisp.wrapper.hla.FederationSynchronizationException;
import org.eodisp.wrapper.hla.ObjectClassDiscoveryListener;
import org.eodisp.wrapper.hla.ObjectClassInstance;

/**
 * The main entry of the SceneCreatorFederate
 * 
 * @author ibirrer
 */
public class SimControllerFederateMainOld {

	private final static Logger logger = Logger.getLogger(SimControllerFederateMainOld.class);

	public static final String APP_NAME = "EarthCARE SimController Federate";

	public static final String APP_DESCRIPTION = "An HLA Federate that controls and configures an EarhCARE simulation";

	public static final File DEFAULT_WORKING_DIR = new File(new File(System
			.getProperty("user.home"), ".eodisp_earthcare"), "sim_controller");

	public static final Class MAIN_CLASS = SimControllerFederateMainOld.class;

	private static RootApp federateApplication;

	private static FederateConfiguration configuration;

	private static RTIambassador rtiAmbassador;

	private static SimController federate;

	private static final byte[] nullByte = new byte[0];

	private static Worksheet simulationOverviewWs;

	private static Worksheet modelConfigurationWs;

	private static Workbook workbook;

	private static ExcelApplication application;

	private static AtomicInteger nextRow = new AtomicInteger(3);

	private static CommandButton startSimulationButton;

	private static CommandButton quitSimulationButton;

	private static Shell shell;

	private volatile static int nrOfParticipatingFederates;

	private volatile static int nrOfFederatesDone = 0;

	private static class FederateInfoUpdater implements FederateInfoListener {
		private final int row;

		FederateInfoUpdater(int row) {
			this.row = row;
		}

		public void execStatusUpdated(FederateInfo source, FederateInfoPassel passel,
				final ExecStatus newValue) {
			logger.debug(String.format("Updated Execution status of %s to %s", source.getName(),
					newValue));
			Display.getDefault().asyncExec(new Runnable() {
				public void run() {
					simulationOverviewWs.getRange("D" + row).setValue(newValue.toString());
					if (newValue.equals(ExecStatus.DONE)) {
						nrOfFederatesDone++;
						if (nrOfFederatesDone == nrOfParticipatingFederates) {

							System.out.println("ENABLE QUIT BUTTON");
							quitSimulationButton.setEnabled(true);

						}
					}
				}
			});
		}

		public void failureModeUpdated(FederateInfo source, FederateInfoPassel passel,
				final FailureMode newValue) {
			logger.debug(String.format("Updated Failure Mode of %s to %s", source.getName(),
					newValue));
			Display.getDefault().asyncExec(new Runnable() {
				public void run() {
					simulationOverviewWs.getRange("E" + row).setValue(newValue.toString());
				}
			});

		}

		public void modelVersionUpdated(FederateInfo source, FederateInfoPassel passel,
				final String newValue) {
			logger.debug(String.format("Updated Version of %s to %s", source.getName(), newValue));

			Display.getDefault().asyncExec(new Runnable() {
				public void run() {
					simulationOverviewWs.getRange("C" + row).setValue(newValue.toString());
				}
			});

		}

		public void nameUpdated(FederateInfo source, FederateInfoPassel passel,
				final String newValue) {
			logger.debug(String.format("Updated Name of %s to %s", source.getName(), newValue));
			Display.getDefault().asyncExec(new Runnable() {
				public void run() {
					simulationOverviewWs.getRange("B" + row).setValue(newValue.toString());
				}
			});

		}
	}

	/**
	 * Creates the {@link RootApp} instance and starts the federate. Not that
	 * the main thread is used as the SWT GUI thread. This means that no other
	 * tasks should be done on that thread tahn UI updates.
	 * 
	 * @param args
	 *            command line arguments
	 */
	public static void main(String[] args) throws Exception {
		try {
			initApplication(args);
			initRti();
			federate = new SimController(rtiAmbassador);
			federate.addObjectClassDiscoveryListener(new ObjectClassDiscoveryListener() {
				public void objectInstanceDiscovered(ObjectClassInstance objectClassInstance) {
					if (objectClassInstance instanceof FederateInfo) {
						FederateInfo federateInfo = (FederateInfo) objectClassInstance;

						federateInfo.addFederateInfoListener(new FederateInfoUpdater(nextRow
								.incrementAndGet()));
						nrOfParticipatingFederates++;
					} else {
						logger.warn("Discovered unknown object instance: " + objectClassInstance);
					}
				}
			});
			eodispInit();
			openWorkbook();
		} catch (Throwable e) {
			logger.fatal("The Sim Controller Federate could not complete its task", e);
		}
	}

	/**
	 * Blocks until closed
	 * 
	 * @throws IOException
	 */
	private static void openWorkbook() throws IOException {
		logger.debug("Open Workbook ...");
		Display display = new Display();
		shell = new Shell(display);
		application = new ExcelApplication(shell);
		application.setVisible(true);
		File bundlePath = new File(System.getProperty("org.eodisp.bundle-path"));
		File file = new File(bundlePath, "resources/sim_controller.xls");
		if (!file.exists()) {
			throw new RuntimeException(String.format("Could not open Excel workbook: %s", file));
		}
		workbook = application.openWorkbook(file, ExcelApplication.NEVER_UPDATE_LINKS, true);
		workbook.setWindowState(Workbook.WINDOW_XL_MAXIMIZED);
		simulationOverviewWs = workbook.getWorksheet("Simulation_Overview");
		modelConfigurationWs = workbook.getWorksheet("Model_Configuration");
		startSimulationButton = simulationOverviewWs.getCommandButton("StartSimulationButton");
		quitSimulationButton = simulationOverviewWs.getCommandButton("QuitSimulationButton");
		workbook.addSheetChangeListener(new SheetChangeListener() {
			public void sheetChanged(Range range) {
				if (range.getAddress().equals("$Z$1")) {
					startSimulation();
				} else if (range.getAddress().equals("$Z$2")) {
					quitSimulation();
				}
			}
		});

		Thread t = new Thread() {
			@Override
			public void run() {
				try {
					eodispStart();
				} catch (RTIexception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (FederationSynchronizationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		};
		t.start();

		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

	private static void startSimulation() {
		startSimulationButton.setEnabled(false);
		Thread t = new Thread() {
			@Override
			public void run() {
				updateSceneCreatorPar();
			}
		};
		t.start();
	}

	private static void quitSimulation() {
		quitSimulationButton.setEnabled(false);
		Thread t = new Thread() {
			@Override
			public void run() {
				try {
					eodispStop();
					shutdown();
				} catch (Exception e) {
					logger.debug("Error while waiting for sync point EODISP_STOP");
				} finally {
					Display.getDefault().asyncExec(new Runnable() {
						public void run() {
							logger.debug(String.format("Close workbook: %s", workbook));
							workbook.close();

							// Close Excel if only one workbook is
							// left
							if (application.getNrOfWorkbooks() == 0) {
								logger.debug("Exit Excel Application");
								application.quit();
							}
							shell.dispose();
						}
					});
				}
			}
		};
		t.start();
	}

	private static void updateSceneCreatorPar() {
		try {
			final SceneCreatorPar sceneCreatorPar = federate.newSceneCreatorPar();
			Display.getDefault().syncExec(new Runnable() {
				public void run() {
					int scene_creator_failure_mode = modelConfigurationWs.getRange(
							"scene_creator_failure_mode").getIntValue();
					float scene_creator_horizontal_resolution = modelConfigurationWs.getRange(
							"scene_creator_horizontal_resolution").getFloatValue();
					float scene_creator_x_extent = modelConfigurationWs.getRange(
							"scene_creator_x_extent").getFloatValue();
					float scene_creator_y_extent = modelConfigurationWs.getRange(
							"scene_creator_y_extent").getFloatValue();
					float scene_creator_z_extent = modelConfigurationWs.getRange(
							"scene_creator_z_extent").getFloatValue();

					
				}
			});
			sceneCreatorPar.updateAttributeValues(nullByte);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void initApplication(String[] args) {
		federateApplication = new RootApp(APP_NAME, APP_DESCRIPTION, DEFAULT_WORKING_DIR,
				MAIN_CLASS);
		federateApplication.registerAppModule(new FederateAppModule());
		federateApplication.execute(args);
		configuration = (FederateConfiguration) federateApplication
				.getConfiguration(FederateConfiguration.ID);
	}

	private static void initRti() throws RTIexception {
		rtiAmbassador = RtiFactoryFactory.getRtiFactory().getRtiAmbassador();
		rtiAmbassador.enableCallbacks();
	}

	private static void eodispInit() throws RTIexception, InterruptedException {
		federate.joinFederationExecution("Sim Controller Federate", configuration
				.getFederationExecution(), null, 20, SECONDS);
		federate.awaitSynchronizationPointAnnouncement("EODISP_INIT", 120, SECONDS);

		federate.publishInteractionClasses();
		federate.subscribeInteractionClasses();
		federate.publishObjectClassAttributes();
		federate.subscribeObjectClassAttributes();

		byte[] federateHandleEncoded = new byte[federate.getFederatHandle().encodedLength()];
		federate.getFederatHandle().encode(federateHandleEncoded, 0);
		federate.sendRegisterFederate(federateHandleEncoded, nullByte);
	}

	private static void eodispStart() throws RTIexception, InterruptedException,
			FederationSynchronizationException {
		federate.achieveSyncPointAndAwaitFederationSynchronization("EODISP_START", 120, SECONDS);
	}

	private static void eodispStop() throws RTIexception, InterruptedException,
			FederationSynchronizationException {
		federate.achieveSyncPointAndAwaitFederationSynchronization("EODISP_STOP", Long.MAX_VALUE,
				SECONDS);
		rtiAmbassador.resignFederationExecution(ResignAction.UNCONDITIONALLY_DIVEST_ATTRIBUTES);
	}

	private static void shutdown() throws ObjectInstanceNotKnown, AttributeNotDefined,
			FederateNotExecutionMember, RTIinternalError, OwnershipAcquisitionPending, FederateOwnsAttributes {
		rtiAmbassador.resignFederationExecution(ResignAction.UNCONDITIONALLY_DIVEST_ATTRIBUTES);
		federateApplication.shutdown();
		System.exit(1);
	}
}
