package org.eodisp.earthcare.sim_controller.proxies;


/**
 * Attributes that represent parameters that are specific to the lw_msi_lidar_radar
 * model 
 *
 * @author org.eodisp.wrapper.hla.ProxyCompiler
 */

public class LwMsiLidarRadarParPassel extends EarthCAREPassel {
    /**
     * The failure mode of the lw_msi_lidar_radar model 
     */
    FailureMode failureMode;

    /**
     * Whether or not the failureMode attribute has been set.
     */
    boolean failureModeIsValid;

    /**
     * Maximum number of iterations 
     */
    int maxIterations;

    /**
     * Whether or not the maxIterations attribute has been set.
     */
    boolean maxIterationsIsValid;

    /**
     * Returns the value of the failureMode attribute.
     *
     * @return the current attribute value
     */
    public FailureMode getFailureMode() {
        return failureMode;
    }

    /**
     * Returns <code>true</code> if the attribute 'failureMode' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean failureModeIsValid() {
        return failureModeIsValid;
    }
    /**
     * Returns the value of the maxIterations attribute.
     *
     * @return the current attribute value
     */
    public int getMaxIterations() {
        return maxIterations;
    }

    /**
     * Returns <code>true</code> if the attribute 'maxIterations' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean maxIterationsIsValid() {
        return maxIterationsIsValid;
    }
}
