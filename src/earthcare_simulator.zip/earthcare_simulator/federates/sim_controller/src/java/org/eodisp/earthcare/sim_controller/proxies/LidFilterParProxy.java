package org.eodisp.earthcare.sim_controller.proxies;

import hla.rti1516.*;
import hla.rti1516.jlc.*;
import hla.rti1516.jlc.omt.*;
import hla.rti1516.*;

import java.io.*;
import java.util.*;
import java.util.concurrent.*;

import org.eodisp.wrapper.hla.*;

/**
 * Attributes that represent parameters that are specific to the lid_filter model
 *
 * @author org.eodisp.wrapper.hla.ProxyCompiler
 */

public class LidFilterParProxy extends EarthCAREProxy implements LidFilterPar
{
    /**
     * Listeners for attributes associated with the LidFilterPar class.
     */
    private final CopyOnWriteArrayList<LidFilterParListener> listeners = new CopyOnWriteArrayList<LidFilterParListener>();

    private final CopyOnWriteArrayList<LidFilterParPasselListener> passelListeners = new CopyOnWriteArrayList<LidFilterParPasselListener>();

    /**
     * The handle of the failureMode attribute.
     */
    private AttributeHandle failureModeHandle;

    /**
     * Whether or not the failureMode attribute has been set.
     */
    private boolean failureModeIsValid;

    /**
     * Whether or not the failureMode attribute has changed.
     */
    private boolean failureModeIsDirty;

    /**
     * The failure mode of the lid_filter model 
     */
    private FailureMode failureMode;

    /**
     * The handle of the laserPulseEnergy attribute.
     */
    private AttributeHandle laserPulseEnergyHandle;

    /**
     * Whether or not the laserPulseEnergy attribute has been set.
     */
    private boolean laserPulseEnergyIsValid;

    /**
     * Whether or not the laserPulseEnergy attribute has changed.
     */
    private boolean laserPulseEnergyIsDirty;

    /**
     * The laser pulse energy in Joules (an input parameter for the lid_filter
     * program) 
     */
    private float laserPulseEnergy;

    /**
     * The handle of the laserLineWidth attribute.
     */
    private AttributeHandle laserLineWidthHandle;

    /**
     * Whether or not the laserLineWidth attribute has been set.
     */
    private boolean laserLineWidthIsValid;

    /**
     * Whether or not the laserLineWidth attribute has changed.
     */
    private boolean laserLineWidthIsDirty;

    /**
     * The laser line width in MHz (an input parameter for the lid_filter program)
     */
    private float laserLineWidth;


    /**
     * Constructor for object instance proxies created in response to
     * discovered objects.
     *
     * @param pRTIAmbassador the run-time infrastructure ambassador
     * @param pInstanceHandle the object instance handle
     * @param pClassHandle the object class handle
     * @param pName the object name
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    protected LidFilterParProxy(RTIambassador pRTIAmbassador,
                                ObjectInstanceHandle pInstanceHandle,
                                ObjectClassHandle pClassHandle,
                                String pName)
              throws RTIinternalError
    {
        super(pRTIAmbassador, pInstanceHandle, pClassHandle, pName);

        try
        {
            initializeAttributes();

            AttributeHandleSet ahs = rtiAmbassador.getAttributeHandleSetFactory().create();

            ahs.add(failureModeHandle);

            ahs.add(laserPulseEnergyHandle);

            ahs.add(laserLineWidthHandle);

            rtiAmbassador.requestAttributeValueUpdate(getObjectInstanceHandle(), ahs, new byte[0]);
        }
        catch(RTIexception rtie)
        {
            throw new RTIinternalError(rtie.toString());
        }
    }

    /**
     * Constructor for object instance proxies created to represent new
     * locally owned objects.  Automatically notifies the run-time
     * infrastructure.
     *
     * @param pRTIAmbassador the run-time infrastructure ambassador
     * @param pClassHandle the object class handle
     * @exception ObjectClassNotDefined if the specified object class is not defined
     * @exception ObjectClassNotPublished if the specified object class is not published
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    protected LidFilterParProxy(RTIambassador pRTIAmbassador,
                                ObjectClassHandle pClassHandle)
              throws ObjectClassNotDefined,
                     ObjectClassNotPublished,
                     FederateNotExecutionMember,
                     SaveInProgress,
                     RestoreInProgress,
                     RTIinternalError
    {
        super(pRTIAmbassador, pClassHandle);

        try
        {
            initializeAttributes();
        }
        catch(RTIexception rtie)
        {
            throw new RTIinternalError(rtie.toString());
        }
    }

    /**
     * Constructor for object instance proxies created to represent new
     * locally owned objects.  Automatically notifies the run-time
     * infrastructure.
     *
     * @param pRTIAmbassador the run-time infrastructure ambassador
     * @param pClassHandle the object class handle
     * @param pName the object name
     * @exception ObjectClassNotDefined if the specified object class is not defined
     * @exception ObjectClassNotPublished if the specified object class is not published
     * @exception IllegalName if the instance name has is illegal
     * @exception ObjectInstanceNameInUse if the instance name is already in use
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */ 
    protected LidFilterParProxy(RTIambassador pRTIAmbassador,
                                ObjectClassHandle pClassHandle,
                                String pName)
              throws ObjectClassNotDefined,
                     ObjectClassNotPublished,
                     IllegalName,
                     ObjectInstanceNameInUse,
                     FederateNotExecutionMember,
                     SaveInProgress,
                     RestoreInProgress,
                     RTIinternalError
    {
        super(pRTIAmbassador, pClassHandle, pName);

        try
        {
            initializeAttributes();
        }
        catch(RTIexception rtie)
        {
            throw new RTIinternalError(rtie.toString());
        }
    }

    /**
     * Initializes the attributes and their handles.
     *
     * @exception InvalidObjectClassHandle if an object class handle is invalid
     * @exception NameNotFound if a name is not found
     * @exception ObjectClassNotDefined if an object class is not defined
     * @exception AttributeNotDefined if an attribute is not defined
     * @exception FederateNotExecutionMember if the federate is not an execution member
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the run-time
     * infrastructure
     */
    private void initializeAttributes()
                 throws InvalidObjectClassHandle,
                        NameNotFound,
                        ObjectClassNotDefined,
                        AttributeNotDefined,
                        FederateNotExecutionMember,
                        SaveInProgress,
                        RestoreInProgress,
                        RTIinternalError
    {
        failureModeHandle = rtiAmbassador.getAttributeHandle(getObjectClassHandle(), "failureMode");
        failureMode = new FailureMode();

        laserPulseEnergyHandle = rtiAmbassador.getAttributeHandle(getObjectClassHandle(), "laserPulseEnergy");

        laserLineWidthHandle = rtiAmbassador.getAttributeHandle(getObjectClassHandle(), "laserLineWidth");
    }

    /**
     * Notifies the proxy that it should provide an update regarding a set of object
     * attributes.
     *
     * @param theAttributes the set of attribute handles identifying the attributes that
     * should be sent
     * @param userSuppliedTag the user-supplied tag associated with the request
     * @exception AttributeNotRecognized if an identified attribute was not recognized
     * @exception AttributeNotOwned if the federate did not own a specified attribute
     * @exception FederateInternalError if an error occurs in the federate
     */
    public void notifyProvideAttributeValueUpdate(AttributeHandleSet theAttributes,
                                            byte[] userSuppliedTag)
                throws AttributeNotRecognized,
                       AttributeNotOwned,
                       FederateInternalError
    {
        if(theAttributes.contains(failureModeHandle))
        {
            failureModeIsDirty = true;
        }

        if(theAttributes.contains(laserPulseEnergyHandle))
        {
            laserPulseEnergyIsDirty = true;
        }

        if(theAttributes.contains(laserLineWidthHandle))
        {
            laserLineWidthIsDirty = true;
        }

        super.notifyProvideAttributeValueUpdate(
            theAttributes,
            userSuppliedTag
        );
    }

    /**
     * Places the attribute values to update into the specified map.
     *
     * @param ahvm the attribute handle value map to populate
     * @param updateAll if <code>true</code> provide updates for all attributes;
     * if <code>false</code>, only provide updates for the modified ones
     * @exception RTIinternalError if an internal error occurs in the run-time
     * infrastructure
     */
    protected void getAttributeValuesToUpdate(AttributeHandleValueMap ahvm,
                                             boolean updateAll)
                   throws RTIinternalError
    {
        if(failureModeIsValid && (updateAll || failureModeIsDirty))
        {
        DataElement encoded = failureMode.encode();

            ahvm.put(failureModeHandle, encoded.toByteArray());

            failureModeIsDirty = false;
        }

        if(laserPulseEnergyIsValid && (updateAll || laserPulseEnergyIsDirty))
        {
        HLAfloat32BE encoded = OmtEncoderFactory.getInstance().createHLAfloat32BE(laserPulseEnergy);

            ahvm.put(laserPulseEnergyHandle, encoded.toByteArray());

            laserPulseEnergyIsDirty = false;
        }

        if(laserLineWidthIsValid && (updateAll || laserLineWidthIsDirty))
        {
        HLAfloat32BE encoded = OmtEncoderFactory.getInstance().createHLAfloat32BE(laserLineWidth);

            ahvm.put(laserLineWidthHandle, encoded.toByteArray());

            laserLineWidthIsDirty = false;
        }

        super.getAttributeValuesToUpdate(ahvm, updateAll);
    }

    /**
     * Adds a listener for attributes associated with the LidFilterPar class.
     *
     * @param l the listener to add
     */
    public void addLidFilterParListener(LidFilterParListener l) {
        	resetWaitForListener();
        listeners.add(l);
    }

    /**
     * Removes a listener for attributes associated with the LidFilterPar class.
     *
     * @param l the listener to remove
     */
    public void removeLidFilterParListener(LidFilterParListener l) {
        listeners.remove(l);
    }

    /**
     * Adds a passel listener for attributes associated with the LidFilterPar class.
     *
     * @param l the passel listener to add
     */
    public void addLidFilterParPasselListener(LidFilterParPasselListener l) {
        	resetWaitForListener();
        passelListeners.add(l);
    }

    /**
     * Removes a passel listener for attributes associated with the LidFilterPar class.
     *
     * @param l the passel listener to remove
     */
    public void removeLidFilterParPasselListener(LidFilterParPasselListener l) {
        passelListeners.remove(l);
    }
    /**
     * Returns an instance of the LidFilterParPassel class.
     *
     * @param l the listener to remove
     */
    protected Object createPassel() {
        return new LidFilterParPassel();
    }
    /**
     * Sets the passel values LidFilterParPassel class.
     *
     * @param l the listener to remove
     */
    protected void setPasselValues( Object passel,  AttributeHandleValueMap attributeHandleValueMap ) {
        LidFilterParPassel localPassel = (LidFilterParPassel)passel;
        if(attributeHandleValueMap.containsKey(failureModeHandle)) {
            byte[] value = (byte[])attributeHandleValueMap.get(failureModeHandle);
            localPassel.failureMode = FailureMode.decode(value);
            failureMode = localPassel.failureMode;
            localPassel.failureModeIsValid = true;
            failureModeIsValid = true;

        }
        if(attributeHandleValueMap.containsKey(laserPulseEnergyHandle)) {
            byte[] value = (byte[])attributeHandleValueMap.get(laserPulseEnergyHandle);
            ByteWrapper byteWrapper = new ByteWrapper(value);
            HLAfloat32BE dataElement =  OmtEncoderFactory.getInstance().createHLAfloat32BE();
            dataElement.decode(byteWrapper);
            localPassel.laserPulseEnergy = dataElement.getValue();
            laserPulseEnergy = localPassel.laserPulseEnergy;
            localPassel.laserPulseEnergyIsValid = true;
            laserPulseEnergyIsValid = true;

        }
        if(attributeHandleValueMap.containsKey(laserLineWidthHandle)) {
            byte[] value = (byte[])attributeHandleValueMap.get(laserLineWidthHandle);
            ByteWrapper byteWrapper = new ByteWrapper(value);
            HLAfloat32BE dataElement =  OmtEncoderFactory.getInstance().createHLAfloat32BE();
            dataElement.decode(byteWrapper);
            localPassel.laserLineWidth = dataElement.getValue();
            laserLineWidth = localPassel.laserLineWidth;
            localPassel.laserLineWidthIsValid = true;
            laserLineWidthIsValid = true;

        }
        super.setPasselValues( passel, attributeHandleValueMap );
    }
    /**
     * Notifies the listeners of new values
     *
     * @param passel all values that were sent in the same passel. Values were all converted from the attributeHandleValueMap
     * @param attributeHandleValueMap the original attributeHandleValueMap
     */
    protected void notifyListeners( Object passel,  AttributeHandleValueMap attributeHandleValueMap ) {
        LidFilterParPassel localPassel = (LidFilterParPassel)passel;
        if( listeners.isEmpty() && passelListeners.isEmpty() ) {
            try {
                if(! listenerLatch.await( 300, TimeUnit.SECONDS )) {
                    throw new Error("Nobody attached a listener during objectInstanceDiscovered.");
                }
            } catch (InterruptedException e) {
        	        Thread.currentThread().interrupt();
            }
        }
        if(attributeHandleValueMap.containsKey(failureModeHandle)) {
            for(LidFilterParListener listener : listeners) {
                listener.failureModeUpdated(
                    this,
                    localPassel,
                    localPassel.getFailureMode());
            }
        }
        if(attributeHandleValueMap.containsKey(laserPulseEnergyHandle)) {
            for(LidFilterParListener listener : listeners) {
                listener.laserPulseEnergyUpdated(
                    this,
                    localPassel,
                    localPassel.getLaserPulseEnergy());
            }
        }
        if(attributeHandleValueMap.containsKey(laserLineWidthHandle)) {
            for(LidFilterParListener listener : listeners) {
                listener.laserLineWidthUpdated(
                    this,
                    localPassel,
                    localPassel.getLaserLineWidth());
            }
        }
        for(LidFilterParPasselListener listener : passelListeners) {
            listener.passelUpdated(
               this,
                localPassel);
        }
        super.notifyListeners( passel, attributeHandleValueMap );
    }

    /**
     * Sets the value of the failureMode attribute.
     *
     * @param pFailureMode the new attribute value
     * @param userSuppliedTag a user-supplied tag to associate with the action
     * run-time infrastructure
     */
    public synchronized void setFailureMode(FailureMode pFailureMode) {
        failureMode = pFailureMode;
        failureModeIsValid = true;
        failureModeIsDirty = true;
    }


    /**
     * Sets the value of the failureMode attribute and immediately sends the updated value to the federation.
     *
     * @param pFailureMode the new attribute value
     * @param userSuppliedTag a user-supplied tag that is used as the parameter to {@link ObjectClassInstance#updateAttributeValues(byte[])} 
     * @exception ObjectInstanceNotKnown if the object instance is unknown
     * @exception AttributeNotDefined if one of the attributes is undefined
     * @exception AttributeNotOwned if one of the attributes is not owned
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    public synchronized void setFailureMode(FailureMode pFailureMode, byte[] userSuppliedTag)
                throws ObjectInstanceNotKnown,
                       AttributeNotDefined,
                       AttributeNotOwned,
                       FederateNotExecutionMember,
                       SaveInProgress,
                       RestoreInProgress,
                       RTIinternalError {
        setFailureMode( pFailureMode );
        updateAttributeValues(userSuppliedTag);
    }

    /**
     * Returns the value of the failureMode attribute.
     *
     * @return the current attribute value
     */
    public synchronized FailureMode getFailureMode()
    {
        return failureMode;
    }

    /**
     * Sets the value of the laserPulseEnergy attribute.
     *
     * @param pLaserPulseEnergy the new attribute value
     * @param userSuppliedTag a user-supplied tag to associate with the action
     * run-time infrastructure
     */
    public synchronized void setLaserPulseEnergy(float pLaserPulseEnergy) {
        laserPulseEnergy = pLaserPulseEnergy;
        laserPulseEnergyIsValid = true;
        laserPulseEnergyIsDirty = true;
    }


    /**
     * Sets the value of the laserPulseEnergy attribute and immediately sends the updated value to the federation.
     *
     * @param pLaserPulseEnergy the new attribute value
     * @param userSuppliedTag a user-supplied tag that is used as the parameter to {@link ObjectClassInstance#updateAttributeValues(byte[])} 
     * @exception ObjectInstanceNotKnown if the object instance is unknown
     * @exception AttributeNotDefined if one of the attributes is undefined
     * @exception AttributeNotOwned if one of the attributes is not owned
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    public synchronized void setLaserPulseEnergy(float pLaserPulseEnergy, byte[] userSuppliedTag)
                throws ObjectInstanceNotKnown,
                       AttributeNotDefined,
                       AttributeNotOwned,
                       FederateNotExecutionMember,
                       SaveInProgress,
                       RestoreInProgress,
                       RTIinternalError {
        setLaserPulseEnergy( pLaserPulseEnergy );
        updateAttributeValues(userSuppliedTag);
    }

    /**
     * Returns the value of the laserPulseEnergy attribute.
     *
     * @return the current attribute value
     */
    public synchronized float getLaserPulseEnergy()
    {
        return laserPulseEnergy;
    }

    /**
     * Sets the value of the laserLineWidth attribute.
     *
     * @param pLaserLineWidth the new attribute value
     * @param userSuppliedTag a user-supplied tag to associate with the action
     * run-time infrastructure
     */
    public synchronized void setLaserLineWidth(float pLaserLineWidth) {
        laserLineWidth = pLaserLineWidth;
        laserLineWidthIsValid = true;
        laserLineWidthIsDirty = true;
    }


    /**
     * Sets the value of the laserLineWidth attribute and immediately sends the updated value to the federation.
     *
     * @param pLaserLineWidth the new attribute value
     * @param userSuppliedTag a user-supplied tag that is used as the parameter to {@link ObjectClassInstance#updateAttributeValues(byte[])} 
     * @exception ObjectInstanceNotKnown if the object instance is unknown
     * @exception AttributeNotDefined if one of the attributes is undefined
     * @exception AttributeNotOwned if one of the attributes is not owned
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    public synchronized void setLaserLineWidth(float pLaserLineWidth, byte[] userSuppliedTag)
                throws ObjectInstanceNotKnown,
                       AttributeNotDefined,
                       AttributeNotOwned,
                       FederateNotExecutionMember,
                       SaveInProgress,
                       RestoreInProgress,
                       RTIinternalError {
        setLaserLineWidth( pLaserLineWidth );
        updateAttributeValues(userSuppliedTag);
    }

    /**
     * Returns the value of the laserLineWidth attribute.
     *
     * @return the current attribute value
     */
    public synchronized float getLaserLineWidth()
    {
        return laserLineWidth;
    }
}
