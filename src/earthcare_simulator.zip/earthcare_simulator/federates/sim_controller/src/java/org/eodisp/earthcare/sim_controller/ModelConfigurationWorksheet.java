package org.eodisp.earthcare.sim_controller;
import org.eodisp.wrapper.excel.*;
import org.eclipse.swt.ole.win32.*;
import java.util.concurrent.CopyOnWriteArrayList;
public class ModelConfigurationWorksheet {
    private Worksheet worksheet;
    private CopyOnWriteArrayList<ModelConfigurationWorksheetButtonListener> buttonPressedListeners = new CopyOnWriteArrayList<ModelConfigurationWorksheetButtonListener>();

    public ModelConfigurationWorksheet(Worksheet worksheet) {
        this.worksheet = worksheet;
        worksheet.getWorkbook().addSheetChangeListener(new SheetChangeListener() {
            public void sheetChanged(Range range) {
            String rangeName = range.getName();
                if (rangeName != null && rangeName.equals("BUTTON_ACTION")) {
                    String buttonId = range.getStringValue();
                    CommandButton commandButton = ModelConfigurationWorksheet.this.worksheet.getCommandButton(buttonId);
                if(buttonId.equals("UpdateSceneCreatorButton")) {
                    for (ModelConfigurationWorksheetButtonListener listener : buttonPressedListeners) {
                        listener.updateSceneCreatorButtonPressed(commandButton);
                    }
                }
                else if(buttonId.equals("UpdateOrbitPropagatorButton")) {
                    for (ModelConfigurationWorksheetButtonListener listener : buttonPressedListeners) {
                        listener.updateOrbitPropagatorButtonPressed(commandButton);
                    }
                }
                else if(buttonId.equals("UpdateLidFilterButton")) {
                    for (ModelConfigurationWorksheetButtonListener listener : buttonPressedListeners) {
                        listener.updateLidFilterButtonPressed(commandButton);
                    }
                }
                else if(buttonId.equals("UpdateLidarButton")) {
                    for (ModelConfigurationWorksheetButtonListener listener : buttonPressedListeners) {
                        listener.updateLidarButtonPressed(commandButton);
                    }
                }
                else if(buttonId.equals("UpdateRadFilterButton")) {
                    for (ModelConfigurationWorksheetButtonListener listener : buttonPressedListeners) {
                        listener.updateRadFilterButtonPressed(commandButton);
                    }
                }
                else if(buttonId.equals("UpdateRadarButton")) {
                    for (ModelConfigurationWorksheetButtonListener listener : buttonPressedListeners) {
                        listener.updateRadarButtonPressed(commandButton);
                    }
                }
                else if(buttonId.equals("UpdateMcSimMainButton")) {
                    for (ModelConfigurationWorksheetButtonListener listener : buttonPressedListeners) {
                        listener.updateMcSimMainButtonPressed(commandButton);
                    }
                }
                else if(buttonId.equals("UpdateMcLwSimMainButton")) {
                    for (ModelConfigurationWorksheetButtonListener listener : buttonPressedListeners) {
                        listener.updateMcLwSimMainButtonPressed(commandButton);
                    }
                }
                else if(buttonId.equals("UpdateLidarRet1Button")) {
                    for (ModelConfigurationWorksheetButtonListener listener : buttonPressedListeners) {
                        listener.updateLidarRet1ButtonPressed(commandButton);
                    }
                }
                else if(buttonId.equals("UpdateLwMsiLidarRadarButton")) {
                    for (ModelConfigurationWorksheetButtonListener listener : buttonPressedListeners) {
                        listener.updateLwMsiLidarRadarButtonPressed(commandButton);
                    }
                }
                else if(buttonId.equals("UpdateMsiRetButton")) {
                    for (ModelConfigurationWorksheetButtonListener listener : buttonPressedListeners) {
                        listener.updateMsiRetButtonPressed(commandButton);
                    }
                }
                }
            }
        });
    }
    public void addButtonPressedListener(ModelConfigurationWorksheetButtonListener listener) {
        buttonPressedListeners.add(listener);
    }
    public Range getBUTTON_ACTION(){
        return worksheet.getRange("BUTTON_ACTION");
    }
    public Range getLidarDetectorQuantumEfficiency(){
        return worksheet.getRange("lidarDetectorQuantumEfficiency");
    }
    public Range getLidarFailureMode(){
        return worksheet.getRange("lidarFailureMode");
    }
    public Range getLidarNumberOfOpticalElements(){
        return worksheet.getRange("lidarNumberOfOpticalElements");
    }
    public Range getLidarRet1FailureMode(){
        return worksheet.getRange("lidarRet1FailureMode");
    }
    public Range getLidarRet1HorizontalResolution(){
        return worksheet.getRange("lidarRet1HorizontalResolution");
    }
    public Range getLidarRet1VerticalResolution(){
        return worksheet.getRange("lidarRet1VerticalResolution");
    }
    public Range getLidFilterFailureMode(){
        return worksheet.getRange("lidFilterFailureMode");
    }
    public Range getLidFilterLaserLineWidth(){
        return worksheet.getRange("lidFilterLaserLineWidth");
    }
    public Range getLidFilterLaserPulseEnergy(){
        return worksheet.getRange("lidFilterLaserPulseEnergy");
    }
    public Range getLwMsiLidarRadarFailureMode(){
        return worksheet.getRange("lwMsiLidarRadarFailureMode");
    }
    public Range getLwMsiLidarRadarMaxIterations(){
        return worksheet.getRange("lwMsiLidarRadarMaxIterations");
    }
    public Range getMcLwSimMainFailureMode(){
        return worksheet.getRange("mcLwSimMainFailureMode");
    }
    public Range getMcLwSimMainOutputResolution(){
        return worksheet.getRange("mcLwSimMainOutputResolution");
    }
    public Range getMcLwSimMainRandomNumberSeed(){
        return worksheet.getRange("mcLwSimMainRandomNumberSeed");
    }
    public Range getMcSimMainFailureMode(){
        return worksheet.getRange("mcSimMainFailureMode");
    }
    public Range getMcSimMainOutputResolution(){
        return worksheet.getRange("mcSimMainOutputResolution");
    }
    public Range getMcSimMainRandomNumberSeed(){
        return worksheet.getRange("mcSimMainRandomNumberSeed");
    }
    public Range getMsiRetFailureMode(){
        return worksheet.getRange("msiRetFailureMode");
    }
    public Range getOrbitPropagatorFailureMode(){
        return worksheet.getRange("orbitPropagatorFailureMode");
    }
    public Range getOrbitPropagatorSolarPos1(){
        return worksheet.getRange("orbitPropagatorSolarPos1");
    }
    public Range getOrbitPropagatorSolarPos2(){
        return worksheet.getRange("orbitPropagatorSolarPos2");
    }
    public Range getRadarFailureMode(){
        return worksheet.getRange("radarFailureMode");
    }
    public Range getRadarPulseRepetitionFrequency(){
        return worksheet.getRange("radarPulseRepetitionFrequency");
    }
    public Range getRadFilterEndingAltitude(){
        return worksheet.getRange("radFilterEndingAltitude");
    }
    public Range getRadFilterFailureMode(){
        return worksheet.getRange("radFilterFailureMode");
    }
    public Range getRadFilterStartingAltitude(){
        return worksheet.getRange("radFilterStartingAltitude");
    }
    public Range getSceneCreatorFailureMode(){
        return worksheet.getRange("sceneCreatorFailureMode");
    }
    public Range getSceneCreatorHorizontalResolution(){
        return worksheet.getRange("sceneCreatorHorizontalResolution");
    }
    public Range getSceneCreatorXExtent(){
        return worksheet.getRange("sceneCreatorXExtent");
    }
    public Range getSceneCreatorYExtent(){
        return worksheet.getRange("sceneCreatorYExtent");
    }
    public Range getSceneCreatorZExtent(){
        return worksheet.getRange("sceneCreatorZExtent");
    }
    public CommandButton getUpdateSceneCreatorButton(){
        return worksheet.getCommandButton("UpdateSceneCreatorButton");
    }
    public CommandButton getUpdateOrbitPropagatorButton(){
        return worksheet.getCommandButton("UpdateOrbitPropagatorButton");
    }
    public CommandButton getUpdateLidFilterButton(){
        return worksheet.getCommandButton("UpdateLidFilterButton");
    }
    public CommandButton getUpdateLidarButton(){
        return worksheet.getCommandButton("UpdateLidarButton");
    }
    public CommandButton getUpdateRadFilterButton(){
        return worksheet.getCommandButton("UpdateRadFilterButton");
    }
    public CommandButton getUpdateRadarButton(){
        return worksheet.getCommandButton("UpdateRadarButton");
    }
    public CommandButton getUpdateMcSimMainButton(){
        return worksheet.getCommandButton("UpdateMcSimMainButton");
    }
    public CommandButton getUpdateMcLwSimMainButton(){
        return worksheet.getCommandButton("UpdateMcLwSimMainButton");
    }
    public CommandButton getUpdateLidarRet1Button(){
        return worksheet.getCommandButton("UpdateLidarRet1Button");
    }
    public CommandButton getUpdateLwMsiLidarRadarButton(){
        return worksheet.getCommandButton("UpdateLwMsiLidarRadarButton");
    }
    public CommandButton getUpdateMsiRetButton(){
        return worksheet.getCommandButton("UpdateMsiRetButton");
    }
    public Range getRange(String range) {
        return worksheet.getRange(range);
    }
}
