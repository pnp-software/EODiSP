package org.eodisp.earthcare.sim_controller.proxies;

import hla.rti1516.*;
import hla.rti1516.jlc.*;
import hla.rti1516.jlc.omt.*;
import hla.rti1516.*;

import java.io.*;
import java.util.*;
import java.util.concurrent.*;

import org.eodisp.wrapper.hla.*;

/**
 * Attributes that represent parameters that are specific to the lidar model
 *
 * @author org.eodisp.wrapper.hla.ProxyCompiler
 */

public class LidarParProxy extends EarthCAREProxy implements LidarPar
{
    /**
     * Listeners for attributes associated with the LidarPar class.
     */
    private final CopyOnWriteArrayList<LidarParListener> listeners = new CopyOnWriteArrayList<LidarParListener>();

    private final CopyOnWriteArrayList<LidarParPasselListener> passelListeners = new CopyOnWriteArrayList<LidarParPasselListener>();

    /**
     * The handle of the failureMode attribute.
     */
    private AttributeHandle failureModeHandle;

    /**
     * Whether or not the failureMode attribute has been set.
     */
    private boolean failureModeIsValid;

    /**
     * Whether or not the failureMode attribute has changed.
     */
    private boolean failureModeIsDirty;

    /**
     * The failure mode of the lid_filter model 
     */
    private FailureMode failureMode;

    /**
     * The handle of the detectorQuantumEfficiency attribute.
     */
    private AttributeHandle detectorQuantumEfficiencyHandle;

    /**
     * Whether or not the detectorQuantumEfficiency attribute has been set.
     */
    private boolean detectorQuantumEfficiencyIsValid;

    /**
     * Whether or not the detectorQuantumEfficiency attribute has changed.
     */
    private boolean detectorQuantumEfficiencyIsDirty;

    /**
     * Quantum efficiency of the detector in channel 1 
     */
    private float detectorQuantumEfficiency;

    /**
     * The handle of the numberOfOpticalElements attribute.
     */
    private AttributeHandle numberOfOpticalElementsHandle;

    /**
     * Whether or not the numberOfOpticalElements attribute has been set.
     */
    private boolean numberOfOpticalElementsIsValid;

    /**
     * Whether or not the numberOfOpticalElements attribute has changed.
     */
    private boolean numberOfOpticalElementsIsDirty;

    /**
     * The number of optical elements in channel 1 
     */
    private int numberOfOpticalElements;


    /**
     * Constructor for object instance proxies created in response to
     * discovered objects.
     *
     * @param pRTIAmbassador the run-time infrastructure ambassador
     * @param pInstanceHandle the object instance handle
     * @param pClassHandle the object class handle
     * @param pName the object name
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    protected LidarParProxy(RTIambassador pRTIAmbassador,
                            ObjectInstanceHandle pInstanceHandle,
                            ObjectClassHandle pClassHandle,
                            String pName)
              throws RTIinternalError
    {
        super(pRTIAmbassador, pInstanceHandle, pClassHandle, pName);

        try
        {
            initializeAttributes();

            AttributeHandleSet ahs = rtiAmbassador.getAttributeHandleSetFactory().create();

            ahs.add(failureModeHandle);

            ahs.add(detectorQuantumEfficiencyHandle);

            ahs.add(numberOfOpticalElementsHandle);

            rtiAmbassador.requestAttributeValueUpdate(getObjectInstanceHandle(), ahs, new byte[0]);
        }
        catch(RTIexception rtie)
        {
            throw new RTIinternalError(rtie.toString());
        }
    }

    /**
     * Constructor for object instance proxies created to represent new
     * locally owned objects.  Automatically notifies the run-time
     * infrastructure.
     *
     * @param pRTIAmbassador the run-time infrastructure ambassador
     * @param pClassHandle the object class handle
     * @exception ObjectClassNotDefined if the specified object class is not defined
     * @exception ObjectClassNotPublished if the specified object class is not published
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    protected LidarParProxy(RTIambassador pRTIAmbassador,
                            ObjectClassHandle pClassHandle)
              throws ObjectClassNotDefined,
                     ObjectClassNotPublished,
                     FederateNotExecutionMember,
                     SaveInProgress,
                     RestoreInProgress,
                     RTIinternalError
    {
        super(pRTIAmbassador, pClassHandle);

        try
        {
            initializeAttributes();
        }
        catch(RTIexception rtie)
        {
            throw new RTIinternalError(rtie.toString());
        }
    }

    /**
     * Constructor for object instance proxies created to represent new
     * locally owned objects.  Automatically notifies the run-time
     * infrastructure.
     *
     * @param pRTIAmbassador the run-time infrastructure ambassador
     * @param pClassHandle the object class handle
     * @param pName the object name
     * @exception ObjectClassNotDefined if the specified object class is not defined
     * @exception ObjectClassNotPublished if the specified object class is not published
     * @exception IllegalName if the instance name has is illegal
     * @exception ObjectInstanceNameInUse if the instance name is already in use
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */ 
    protected LidarParProxy(RTIambassador pRTIAmbassador,
                            ObjectClassHandle pClassHandle,
                            String pName)
              throws ObjectClassNotDefined,
                     ObjectClassNotPublished,
                     IllegalName,
                     ObjectInstanceNameInUse,
                     FederateNotExecutionMember,
                     SaveInProgress,
                     RestoreInProgress,
                     RTIinternalError
    {
        super(pRTIAmbassador, pClassHandle, pName);

        try
        {
            initializeAttributes();
        }
        catch(RTIexception rtie)
        {
            throw new RTIinternalError(rtie.toString());
        }
    }

    /**
     * Initializes the attributes and their handles.
     *
     * @exception InvalidObjectClassHandle if an object class handle is invalid
     * @exception NameNotFound if a name is not found
     * @exception ObjectClassNotDefined if an object class is not defined
     * @exception AttributeNotDefined if an attribute is not defined
     * @exception FederateNotExecutionMember if the federate is not an execution member
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the run-time
     * infrastructure
     */
    private void initializeAttributes()
                 throws InvalidObjectClassHandle,
                        NameNotFound,
                        ObjectClassNotDefined,
                        AttributeNotDefined,
                        FederateNotExecutionMember,
                        SaveInProgress,
                        RestoreInProgress,
                        RTIinternalError
    {
        failureModeHandle = rtiAmbassador.getAttributeHandle(getObjectClassHandle(), "failureMode");
        failureMode = new FailureMode();

        detectorQuantumEfficiencyHandle = rtiAmbassador.getAttributeHandle(getObjectClassHandle(), "detectorQuantumEfficiency");

        numberOfOpticalElementsHandle = rtiAmbassador.getAttributeHandle(getObjectClassHandle(), "numberOfOpticalElements");
    }

    /**
     * Notifies the proxy that it should provide an update regarding a set of object
     * attributes.
     *
     * @param theAttributes the set of attribute handles identifying the attributes that
     * should be sent
     * @param userSuppliedTag the user-supplied tag associated with the request
     * @exception AttributeNotRecognized if an identified attribute was not recognized
     * @exception AttributeNotOwned if the federate did not own a specified attribute
     * @exception FederateInternalError if an error occurs in the federate
     */
    public void notifyProvideAttributeValueUpdate(AttributeHandleSet theAttributes,
                                            byte[] userSuppliedTag)
                throws AttributeNotRecognized,
                       AttributeNotOwned,
                       FederateInternalError
    {
        if(theAttributes.contains(failureModeHandle))
        {
            failureModeIsDirty = true;
        }

        if(theAttributes.contains(detectorQuantumEfficiencyHandle))
        {
            detectorQuantumEfficiencyIsDirty = true;
        }

        if(theAttributes.contains(numberOfOpticalElementsHandle))
        {
            numberOfOpticalElementsIsDirty = true;
        }

        super.notifyProvideAttributeValueUpdate(
            theAttributes,
            userSuppliedTag
        );
    }

    /**
     * Places the attribute values to update into the specified map.
     *
     * @param ahvm the attribute handle value map to populate
     * @param updateAll if <code>true</code> provide updates for all attributes;
     * if <code>false</code>, only provide updates for the modified ones
     * @exception RTIinternalError if an internal error occurs in the run-time
     * infrastructure
     */
    protected void getAttributeValuesToUpdate(AttributeHandleValueMap ahvm,
                                             boolean updateAll)
                   throws RTIinternalError
    {
        if(failureModeIsValid && (updateAll || failureModeIsDirty))
        {
        DataElement encoded = failureMode.encode();

            ahvm.put(failureModeHandle, encoded.toByteArray());

            failureModeIsDirty = false;
        }

        if(detectorQuantumEfficiencyIsValid && (updateAll || detectorQuantumEfficiencyIsDirty))
        {
        HLAfloat32BE encoded = OmtEncoderFactory.getInstance().createHLAfloat32BE(detectorQuantumEfficiency);

            ahvm.put(detectorQuantumEfficiencyHandle, encoded.toByteArray());

            detectorQuantumEfficiencyIsDirty = false;
        }

        if(numberOfOpticalElementsIsValid && (updateAll || numberOfOpticalElementsIsDirty))
        {
        HLAinteger32BE encoded = OmtEncoderFactory.getInstance().createHLAinteger32BE(numberOfOpticalElements);

            ahvm.put(numberOfOpticalElementsHandle, encoded.toByteArray());

            numberOfOpticalElementsIsDirty = false;
        }

        super.getAttributeValuesToUpdate(ahvm, updateAll);
    }

    /**
     * Adds a listener for attributes associated with the LidarPar class.
     *
     * @param l the listener to add
     */
    public void addLidarParListener(LidarParListener l) {
        	resetWaitForListener();
        listeners.add(l);
    }

    /**
     * Removes a listener for attributes associated with the LidarPar class.
     *
     * @param l the listener to remove
     */
    public void removeLidarParListener(LidarParListener l) {
        listeners.remove(l);
    }

    /**
     * Adds a passel listener for attributes associated with the LidarPar class.
     *
     * @param l the passel listener to add
     */
    public void addLidarParPasselListener(LidarParPasselListener l) {
        	resetWaitForListener();
        passelListeners.add(l);
    }

    /**
     * Removes a passel listener for attributes associated with the LidarPar class.
     *
     * @param l the passel listener to remove
     */
    public void removeLidarParPasselListener(LidarParPasselListener l) {
        passelListeners.remove(l);
    }
    /**
     * Returns an instance of the LidarParPassel class.
     *
     * @param l the listener to remove
     */
    protected Object createPassel() {
        return new LidarParPassel();
    }
    /**
     * Sets the passel values LidarParPassel class.
     *
     * @param l the listener to remove
     */
    protected void setPasselValues( Object passel,  AttributeHandleValueMap attributeHandleValueMap ) {
        LidarParPassel localPassel = (LidarParPassel)passel;
        if(attributeHandleValueMap.containsKey(failureModeHandle)) {
            byte[] value = (byte[])attributeHandleValueMap.get(failureModeHandle);
            localPassel.failureMode = FailureMode.decode(value);
            failureMode = localPassel.failureMode;
            localPassel.failureModeIsValid = true;
            failureModeIsValid = true;

        }
        if(attributeHandleValueMap.containsKey(detectorQuantumEfficiencyHandle)) {
            byte[] value = (byte[])attributeHandleValueMap.get(detectorQuantumEfficiencyHandle);
            ByteWrapper byteWrapper = new ByteWrapper(value);
            HLAfloat32BE dataElement =  OmtEncoderFactory.getInstance().createHLAfloat32BE();
            dataElement.decode(byteWrapper);
            localPassel.detectorQuantumEfficiency = dataElement.getValue();
            detectorQuantumEfficiency = localPassel.detectorQuantumEfficiency;
            localPassel.detectorQuantumEfficiencyIsValid = true;
            detectorQuantumEfficiencyIsValid = true;

        }
        if(attributeHandleValueMap.containsKey(numberOfOpticalElementsHandle)) {
            byte[] value = (byte[])attributeHandleValueMap.get(numberOfOpticalElementsHandle);
            ByteWrapper byteWrapper = new ByteWrapper(value);
            HLAinteger32BE dataElement =  OmtEncoderFactory.getInstance().createHLAinteger32BE();
            dataElement.decode(byteWrapper);
            localPassel.numberOfOpticalElements = dataElement.getValue();
            numberOfOpticalElements = localPassel.numberOfOpticalElements;
            localPassel.numberOfOpticalElementsIsValid = true;
            numberOfOpticalElementsIsValid = true;

        }
        super.setPasselValues( passel, attributeHandleValueMap );
    }
    /**
     * Notifies the listeners of new values
     *
     * @param passel all values that were sent in the same passel. Values were all converted from the attributeHandleValueMap
     * @param attributeHandleValueMap the original attributeHandleValueMap
     */
    protected void notifyListeners( Object passel,  AttributeHandleValueMap attributeHandleValueMap ) {
        LidarParPassel localPassel = (LidarParPassel)passel;
        if( listeners.isEmpty() && passelListeners.isEmpty() ) {
            try {
                if(! listenerLatch.await( 300, TimeUnit.SECONDS )) {
                    throw new Error("Nobody attached a listener during objectInstanceDiscovered.");
                }
            } catch (InterruptedException e) {
        	        Thread.currentThread().interrupt();
            }
        }
        if(attributeHandleValueMap.containsKey(failureModeHandle)) {
            for(LidarParListener listener : listeners) {
                listener.failureModeUpdated(
                    this,
                    localPassel,
                    localPassel.getFailureMode());
            }
        }
        if(attributeHandleValueMap.containsKey(detectorQuantumEfficiencyHandle)) {
            for(LidarParListener listener : listeners) {
                listener.detectorQuantumEfficiencyUpdated(
                    this,
                    localPassel,
                    localPassel.getDetectorQuantumEfficiency());
            }
        }
        if(attributeHandleValueMap.containsKey(numberOfOpticalElementsHandle)) {
            for(LidarParListener listener : listeners) {
                listener.numberOfOpticalElementsUpdated(
                    this,
                    localPassel,
                    localPassel.getNumberOfOpticalElements());
            }
        }
        for(LidarParPasselListener listener : passelListeners) {
            listener.passelUpdated(
               this,
                localPassel);
        }
        super.notifyListeners( passel, attributeHandleValueMap );
    }

    /**
     * Sets the value of the failureMode attribute.
     *
     * @param pFailureMode the new attribute value
     * @param userSuppliedTag a user-supplied tag to associate with the action
     * run-time infrastructure
     */
    public synchronized void setFailureMode(FailureMode pFailureMode) {
        failureMode = pFailureMode;
        failureModeIsValid = true;
        failureModeIsDirty = true;
    }


    /**
     * Sets the value of the failureMode attribute and immediately sends the updated value to the federation.
     *
     * @param pFailureMode the new attribute value
     * @param userSuppliedTag a user-supplied tag that is used as the parameter to {@link ObjectClassInstance#updateAttributeValues(byte[])} 
     * @exception ObjectInstanceNotKnown if the object instance is unknown
     * @exception AttributeNotDefined if one of the attributes is undefined
     * @exception AttributeNotOwned if one of the attributes is not owned
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    public synchronized void setFailureMode(FailureMode pFailureMode, byte[] userSuppliedTag)
                throws ObjectInstanceNotKnown,
                       AttributeNotDefined,
                       AttributeNotOwned,
                       FederateNotExecutionMember,
                       SaveInProgress,
                       RestoreInProgress,
                       RTIinternalError {
        setFailureMode( pFailureMode );
        updateAttributeValues(userSuppliedTag);
    }

    /**
     * Returns the value of the failureMode attribute.
     *
     * @return the current attribute value
     */
    public synchronized FailureMode getFailureMode()
    {
        return failureMode;
    }

    /**
     * Sets the value of the detectorQuantumEfficiency attribute.
     *
     * @param pDetectorQuantumEfficiency the new attribute value
     * @param userSuppliedTag a user-supplied tag to associate with the action
     * run-time infrastructure
     */
    public synchronized void setDetectorQuantumEfficiency(float pDetectorQuantumEfficiency) {
        detectorQuantumEfficiency = pDetectorQuantumEfficiency;
        detectorQuantumEfficiencyIsValid = true;
        detectorQuantumEfficiencyIsDirty = true;
    }


    /**
     * Sets the value of the detectorQuantumEfficiency attribute and immediately sends the updated value to the federation.
     *
     * @param pDetectorQuantumEfficiency the new attribute value
     * @param userSuppliedTag a user-supplied tag that is used as the parameter to {@link ObjectClassInstance#updateAttributeValues(byte[])} 
     * @exception ObjectInstanceNotKnown if the object instance is unknown
     * @exception AttributeNotDefined if one of the attributes is undefined
     * @exception AttributeNotOwned if one of the attributes is not owned
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    public synchronized void setDetectorQuantumEfficiency(float pDetectorQuantumEfficiency, byte[] userSuppliedTag)
                throws ObjectInstanceNotKnown,
                       AttributeNotDefined,
                       AttributeNotOwned,
                       FederateNotExecutionMember,
                       SaveInProgress,
                       RestoreInProgress,
                       RTIinternalError {
        setDetectorQuantumEfficiency( pDetectorQuantumEfficiency );
        updateAttributeValues(userSuppliedTag);
    }

    /**
     * Returns the value of the detectorQuantumEfficiency attribute.
     *
     * @return the current attribute value
     */
    public synchronized float getDetectorQuantumEfficiency()
    {
        return detectorQuantumEfficiency;
    }

    /**
     * Sets the value of the numberOfOpticalElements attribute.
     *
     * @param pNumberOfOpticalElements the new attribute value
     * @param userSuppliedTag a user-supplied tag to associate with the action
     * run-time infrastructure
     */
    public synchronized void setNumberOfOpticalElements(int pNumberOfOpticalElements) {
        numberOfOpticalElements = pNumberOfOpticalElements;
        numberOfOpticalElementsIsValid = true;
        numberOfOpticalElementsIsDirty = true;
    }


    /**
     * Sets the value of the numberOfOpticalElements attribute and immediately sends the updated value to the federation.
     *
     * @param pNumberOfOpticalElements the new attribute value
     * @param userSuppliedTag a user-supplied tag that is used as the parameter to {@link ObjectClassInstance#updateAttributeValues(byte[])} 
     * @exception ObjectInstanceNotKnown if the object instance is unknown
     * @exception AttributeNotDefined if one of the attributes is undefined
     * @exception AttributeNotOwned if one of the attributes is not owned
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    public synchronized void setNumberOfOpticalElements(int pNumberOfOpticalElements, byte[] userSuppliedTag)
                throws ObjectInstanceNotKnown,
                       AttributeNotDefined,
                       AttributeNotOwned,
                       FederateNotExecutionMember,
                       SaveInProgress,
                       RestoreInProgress,
                       RTIinternalError {
        setNumberOfOpticalElements( pNumberOfOpticalElements );
        updateAttributeValues(userSuppliedTag);
    }

    /**
     * Returns the value of the numberOfOpticalElements attribute.
     *
     * @return the current attribute value
     */
    public synchronized int getNumberOfOpticalElements()
    {
        return numberOfOpticalElements;
    }
}
