package org.eodisp.earthcare.sim_controller.proxies;

import hla.rti1516.*;
import hla.rti1516.jlc.*;
import hla.rti1516.jlc.omt.*;
import hla.rti1516.*;

import java.io.*;
import java.util.*;
import java.util.concurrent.*;

import org.eodisp.wrapper.hla.*;

/**
 * Orbit Propagator input parameter 
 *
 * @author org.eodisp.wrapper.hla.ProxyCompiler
 */

public class OrbitPropagatorParProxy extends EarthCAREProxy implements OrbitPropagatorPar
{
    /**
     * Listeners for attributes associated with the OrbitPropagatorPar class.
     */
    private final CopyOnWriteArrayList<OrbitPropagatorParListener> listeners = new CopyOnWriteArrayList<OrbitPropagatorParListener>();

    private final CopyOnWriteArrayList<OrbitPropagatorParPasselListener> passelListeners = new CopyOnWriteArrayList<OrbitPropagatorParPasselListener>();

    /**
     * The handle of the solarPos1 attribute.
     */
    private AttributeHandle solarPos1Handle;

    /**
     * Whether or not the solarPos1 attribute has been set.
     */
    private boolean solarPos1IsValid;

    /**
     * Whether or not the solarPos1 attribute has changed.
     */
    private boolean solarPos1IsDirty;

    /**
     * Solar position angle in radians 
     */
    private double solarPos1;

    /**
     * The handle of the solarPos2 attribute.
     */
    private AttributeHandle solarPos2Handle;

    /**
     * Whether or not the solarPos2 attribute has been set.
     */
    private boolean solarPos2IsValid;

    /**
     * Whether or not the solarPos2 attribute has changed.
     */
    private boolean solarPos2IsDirty;

    /**
     * Solar position angle in radians 
     */
    private double solarPos2;


    /**
     * Constructor for object instance proxies created in response to
     * discovered objects.
     *
     * @param pRTIAmbassador the run-time infrastructure ambassador
     * @param pInstanceHandle the object instance handle
     * @param pClassHandle the object class handle
     * @param pName the object name
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    protected OrbitPropagatorParProxy(RTIambassador pRTIAmbassador,
                                      ObjectInstanceHandle pInstanceHandle,
                                      ObjectClassHandle pClassHandle,
                                      String pName)
              throws RTIinternalError
    {
        super(pRTIAmbassador, pInstanceHandle, pClassHandle, pName);

        try
        {
            initializeAttributes();

            AttributeHandleSet ahs = rtiAmbassador.getAttributeHandleSetFactory().create();

            ahs.add(solarPos1Handle);

            ahs.add(solarPos2Handle);

            rtiAmbassador.requestAttributeValueUpdate(getObjectInstanceHandle(), ahs, new byte[0]);
        }
        catch(RTIexception rtie)
        {
            throw new RTIinternalError(rtie.toString());
        }
    }

    /**
     * Constructor for object instance proxies created to represent new
     * locally owned objects.  Automatically notifies the run-time
     * infrastructure.
     *
     * @param pRTIAmbassador the run-time infrastructure ambassador
     * @param pClassHandle the object class handle
     * @exception ObjectClassNotDefined if the specified object class is not defined
     * @exception ObjectClassNotPublished if the specified object class is not published
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    protected OrbitPropagatorParProxy(RTIambassador pRTIAmbassador,
                                      ObjectClassHandle pClassHandle)
              throws ObjectClassNotDefined,
                     ObjectClassNotPublished,
                     FederateNotExecutionMember,
                     SaveInProgress,
                     RestoreInProgress,
                     RTIinternalError
    {
        super(pRTIAmbassador, pClassHandle);

        try
        {
            initializeAttributes();
        }
        catch(RTIexception rtie)
        {
            throw new RTIinternalError(rtie.toString());
        }
    }

    /**
     * Constructor for object instance proxies created to represent new
     * locally owned objects.  Automatically notifies the run-time
     * infrastructure.
     *
     * @param pRTIAmbassador the run-time infrastructure ambassador
     * @param pClassHandle the object class handle
     * @param pName the object name
     * @exception ObjectClassNotDefined if the specified object class is not defined
     * @exception ObjectClassNotPublished if the specified object class is not published
     * @exception IllegalName if the instance name has is illegal
     * @exception ObjectInstanceNameInUse if the instance name is already in use
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */ 
    protected OrbitPropagatorParProxy(RTIambassador pRTIAmbassador,
                                      ObjectClassHandle pClassHandle,
                                      String pName)
              throws ObjectClassNotDefined,
                     ObjectClassNotPublished,
                     IllegalName,
                     ObjectInstanceNameInUse,
                     FederateNotExecutionMember,
                     SaveInProgress,
                     RestoreInProgress,
                     RTIinternalError
    {
        super(pRTIAmbassador, pClassHandle, pName);

        try
        {
            initializeAttributes();
        }
        catch(RTIexception rtie)
        {
            throw new RTIinternalError(rtie.toString());
        }
    }

    /**
     * Initializes the attributes and their handles.
     *
     * @exception InvalidObjectClassHandle if an object class handle is invalid
     * @exception NameNotFound if a name is not found
     * @exception ObjectClassNotDefined if an object class is not defined
     * @exception AttributeNotDefined if an attribute is not defined
     * @exception FederateNotExecutionMember if the federate is not an execution member
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the run-time
     * infrastructure
     */
    private void initializeAttributes()
                 throws InvalidObjectClassHandle,
                        NameNotFound,
                        ObjectClassNotDefined,
                        AttributeNotDefined,
                        FederateNotExecutionMember,
                        SaveInProgress,
                        RestoreInProgress,
                        RTIinternalError
    {
        solarPos1Handle = rtiAmbassador.getAttributeHandle(getObjectClassHandle(), "solarPos1");

        solarPos2Handle = rtiAmbassador.getAttributeHandle(getObjectClassHandle(), "solarPos2");
    }

    /**
     * Notifies the proxy that it should provide an update regarding a set of object
     * attributes.
     *
     * @param theAttributes the set of attribute handles identifying the attributes that
     * should be sent
     * @param userSuppliedTag the user-supplied tag associated with the request
     * @exception AttributeNotRecognized if an identified attribute was not recognized
     * @exception AttributeNotOwned if the federate did not own a specified attribute
     * @exception FederateInternalError if an error occurs in the federate
     */
    public void notifyProvideAttributeValueUpdate(AttributeHandleSet theAttributes,
                                            byte[] userSuppliedTag)
                throws AttributeNotRecognized,
                       AttributeNotOwned,
                       FederateInternalError
    {
        if(theAttributes.contains(solarPos1Handle))
        {
            solarPos1IsDirty = true;
        }

        if(theAttributes.contains(solarPos2Handle))
        {
            solarPos2IsDirty = true;
        }

        super.notifyProvideAttributeValueUpdate(
            theAttributes,
            userSuppliedTag
        );
    }

    /**
     * Places the attribute values to update into the specified map.
     *
     * @param ahvm the attribute handle value map to populate
     * @param updateAll if <code>true</code> provide updates for all attributes;
     * if <code>false</code>, only provide updates for the modified ones
     * @exception RTIinternalError if an internal error occurs in the run-time
     * infrastructure
     */
    protected void getAttributeValuesToUpdate(AttributeHandleValueMap ahvm,
                                             boolean updateAll)
                   throws RTIinternalError
    {
        if(solarPos1IsValid && (updateAll || solarPos1IsDirty))
        {
        HLAfloat64BE encoded = OmtEncoderFactory.getInstance().createHLAfloat64BE(solarPos1);

            ahvm.put(solarPos1Handle, encoded.toByteArray());

            solarPos1IsDirty = false;
        }

        if(solarPos2IsValid && (updateAll || solarPos2IsDirty))
        {
        HLAfloat64BE encoded = OmtEncoderFactory.getInstance().createHLAfloat64BE(solarPos2);

            ahvm.put(solarPos2Handle, encoded.toByteArray());

            solarPos2IsDirty = false;
        }

        super.getAttributeValuesToUpdate(ahvm, updateAll);
    }

    /**
     * Adds a listener for attributes associated with the OrbitPropagatorPar class.
     *
     * @param l the listener to add
     */
    public void addOrbitPropagatorParListener(OrbitPropagatorParListener l) {
        	resetWaitForListener();
        listeners.add(l);
    }

    /**
     * Removes a listener for attributes associated with the OrbitPropagatorPar class.
     *
     * @param l the listener to remove
     */
    public void removeOrbitPropagatorParListener(OrbitPropagatorParListener l) {
        listeners.remove(l);
    }

    /**
     * Adds a passel listener for attributes associated with the OrbitPropagatorPar class.
     *
     * @param l the passel listener to add
     */
    public void addOrbitPropagatorParPasselListener(OrbitPropagatorParPasselListener l) {
        	resetWaitForListener();
        passelListeners.add(l);
    }

    /**
     * Removes a passel listener for attributes associated with the OrbitPropagatorPar class.
     *
     * @param l the passel listener to remove
     */
    public void removeOrbitPropagatorParPasselListener(OrbitPropagatorParPasselListener l) {
        passelListeners.remove(l);
    }
    /**
     * Returns an instance of the OrbitPropagatorParPassel class.
     *
     * @param l the listener to remove
     */
    protected Object createPassel() {
        return new OrbitPropagatorParPassel();
    }
    /**
     * Sets the passel values OrbitPropagatorParPassel class.
     *
     * @param l the listener to remove
     */
    protected void setPasselValues( Object passel,  AttributeHandleValueMap attributeHandleValueMap ) {
        OrbitPropagatorParPassel localPassel = (OrbitPropagatorParPassel)passel;
        if(attributeHandleValueMap.containsKey(solarPos1Handle)) {
            byte[] value = (byte[])attributeHandleValueMap.get(solarPos1Handle);
            ByteWrapper byteWrapper = new ByteWrapper(value);
            HLAfloat64BE dataElement =  OmtEncoderFactory.getInstance().createHLAfloat64BE();
            dataElement.decode(byteWrapper);
            localPassel.solarPos1 = dataElement.getValue();
            solarPos1 = localPassel.solarPos1;
            localPassel.solarPos1IsValid = true;
            solarPos1IsValid = true;

        }
        if(attributeHandleValueMap.containsKey(solarPos2Handle)) {
            byte[] value = (byte[])attributeHandleValueMap.get(solarPos2Handle);
            ByteWrapper byteWrapper = new ByteWrapper(value);
            HLAfloat64BE dataElement =  OmtEncoderFactory.getInstance().createHLAfloat64BE();
            dataElement.decode(byteWrapper);
            localPassel.solarPos2 = dataElement.getValue();
            solarPos2 = localPassel.solarPos2;
            localPassel.solarPos2IsValid = true;
            solarPos2IsValid = true;

        }
        super.setPasselValues( passel, attributeHandleValueMap );
    }
    /**
     * Notifies the listeners of new values
     *
     * @param passel all values that were sent in the same passel. Values were all converted from the attributeHandleValueMap
     * @param attributeHandleValueMap the original attributeHandleValueMap
     */
    protected void notifyListeners( Object passel,  AttributeHandleValueMap attributeHandleValueMap ) {
        OrbitPropagatorParPassel localPassel = (OrbitPropagatorParPassel)passel;
        if( listeners.isEmpty() && passelListeners.isEmpty() ) {
            try {
                if(! listenerLatch.await( 300, TimeUnit.SECONDS )) {
                    throw new Error("Nobody attached a listener during objectInstanceDiscovered.");
                }
            } catch (InterruptedException e) {
        	        Thread.currentThread().interrupt();
            }
        }
        if(attributeHandleValueMap.containsKey(solarPos1Handle)) {
            for(OrbitPropagatorParListener listener : listeners) {
                listener.solarPos1Updated(
                    this,
                    localPassel,
                    localPassel.getSolarPos1());
            }
        }
        if(attributeHandleValueMap.containsKey(solarPos2Handle)) {
            for(OrbitPropagatorParListener listener : listeners) {
                listener.solarPos2Updated(
                    this,
                    localPassel,
                    localPassel.getSolarPos2());
            }
        }
        for(OrbitPropagatorParPasselListener listener : passelListeners) {
            listener.passelUpdated(
               this,
                localPassel);
        }
        super.notifyListeners( passel, attributeHandleValueMap );
    }

    /**
     * Sets the value of the solarPos1 attribute.
     *
     * @param pSolarPos1 the new attribute value
     * @param userSuppliedTag a user-supplied tag to associate with the action
     * run-time infrastructure
     */
    public synchronized void setSolarPos1(double pSolarPos1) {
        solarPos1 = pSolarPos1;
        solarPos1IsValid = true;
        solarPos1IsDirty = true;
    }


    /**
     * Sets the value of the solarPos1 attribute and immediately sends the updated value to the federation.
     *
     * @param pSolarPos1 the new attribute value
     * @param userSuppliedTag a user-supplied tag that is used as the parameter to {@link ObjectClassInstance#updateAttributeValues(byte[])} 
     * @exception ObjectInstanceNotKnown if the object instance is unknown
     * @exception AttributeNotDefined if one of the attributes is undefined
     * @exception AttributeNotOwned if one of the attributes is not owned
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    public synchronized void setSolarPos1(double pSolarPos1, byte[] userSuppliedTag)
                throws ObjectInstanceNotKnown,
                       AttributeNotDefined,
                       AttributeNotOwned,
                       FederateNotExecutionMember,
                       SaveInProgress,
                       RestoreInProgress,
                       RTIinternalError {
        setSolarPos1( pSolarPos1 );
        updateAttributeValues(userSuppliedTag);
    }

    /**
     * Returns the value of the solarPos1 attribute.
     *
     * @return the current attribute value
     */
    public synchronized double getSolarPos1()
    {
        return solarPos1;
    }

    /**
     * Sets the value of the solarPos2 attribute.
     *
     * @param pSolarPos2 the new attribute value
     * @param userSuppliedTag a user-supplied tag to associate with the action
     * run-time infrastructure
     */
    public synchronized void setSolarPos2(double pSolarPos2) {
        solarPos2 = pSolarPos2;
        solarPos2IsValid = true;
        solarPos2IsDirty = true;
    }


    /**
     * Sets the value of the solarPos2 attribute and immediately sends the updated value to the federation.
     *
     * @param pSolarPos2 the new attribute value
     * @param userSuppliedTag a user-supplied tag that is used as the parameter to {@link ObjectClassInstance#updateAttributeValues(byte[])} 
     * @exception ObjectInstanceNotKnown if the object instance is unknown
     * @exception AttributeNotDefined if one of the attributes is undefined
     * @exception AttributeNotOwned if one of the attributes is not owned
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    public synchronized void setSolarPos2(double pSolarPos2, byte[] userSuppliedTag)
                throws ObjectInstanceNotKnown,
                       AttributeNotDefined,
                       AttributeNotOwned,
                       FederateNotExecutionMember,
                       SaveInProgress,
                       RestoreInProgress,
                       RTIinternalError {
        setSolarPos2( pSolarPos2 );
        updateAttributeValues(userSuppliedTag);
    }

    /**
     * Returns the value of the solarPos2 attribute.
     *
     * @return the current attribute value
     */
    public synchronized double getSolarPos2()
    {
        return solarPos2;
    }
}
