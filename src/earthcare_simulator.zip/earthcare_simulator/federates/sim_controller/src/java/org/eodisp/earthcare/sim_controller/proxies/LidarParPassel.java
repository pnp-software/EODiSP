package org.eodisp.earthcare.sim_controller.proxies;


/**
 * Attributes that represent parameters that are specific to the lidar model
 *
 * @author org.eodisp.wrapper.hla.ProxyCompiler
 */

public class LidarParPassel extends EarthCAREPassel {
    /**
     * The failure mode of the lid_filter model 
     */
    FailureMode failureMode;

    /**
     * Whether or not the failureMode attribute has been set.
     */
    boolean failureModeIsValid;

    /**
     * Quantum efficiency of the detector in channel 1 
     */
    float detectorQuantumEfficiency;

    /**
     * Whether or not the detectorQuantumEfficiency attribute has been set.
     */
    boolean detectorQuantumEfficiencyIsValid;

    /**
     * The number of optical elements in channel 1 
     */
    int numberOfOpticalElements;

    /**
     * Whether or not the numberOfOpticalElements attribute has been set.
     */
    boolean numberOfOpticalElementsIsValid;

    /**
     * Returns the value of the failureMode attribute.
     *
     * @return the current attribute value
     */
    public FailureMode getFailureMode() {
        return failureMode;
    }

    /**
     * Returns <code>true</code> if the attribute 'failureMode' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean failureModeIsValid() {
        return failureModeIsValid;
    }
    /**
     * Returns the value of the detectorQuantumEfficiency attribute.
     *
     * @return the current attribute value
     */
    public float getDetectorQuantumEfficiency() {
        return detectorQuantumEfficiency;
    }

    /**
     * Returns <code>true</code> if the attribute 'detectorQuantumEfficiency' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean detectorQuantumEfficiencyIsValid() {
        return detectorQuantumEfficiencyIsValid;
    }
    /**
     * Returns the value of the numberOfOpticalElements attribute.
     *
     * @return the current attribute value
     */
    public int getNumberOfOpticalElements() {
        return numberOfOpticalElements;
    }

    /**
     * Returns <code>true</code> if the attribute 'numberOfOpticalElements' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean numberOfOpticalElementsIsValid() {
        return numberOfOpticalElementsIsValid;
    }
}
