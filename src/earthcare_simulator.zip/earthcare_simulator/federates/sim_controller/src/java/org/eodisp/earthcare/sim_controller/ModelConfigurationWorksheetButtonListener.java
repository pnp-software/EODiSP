package org.eodisp.earthcare.sim_controller;
import org.eodisp.wrapper.excel.CommandButton;
public interface ModelConfigurationWorksheetButtonListener {
    public void updateSceneCreatorButtonPressed(CommandButton commandButton);
    public void updateOrbitPropagatorButtonPressed(CommandButton commandButton);
    public void updateLidFilterButtonPressed(CommandButton commandButton);
    public void updateLidarButtonPressed(CommandButton commandButton);
    public void updateRadFilterButtonPressed(CommandButton commandButton);
    public void updateRadarButtonPressed(CommandButton commandButton);
    public void updateMcSimMainButtonPressed(CommandButton commandButton);
    public void updateMcLwSimMainButtonPressed(CommandButton commandButton);
    public void updateLidarRet1ButtonPressed(CommandButton commandButton);
    public void updateLwMsiLidarRadarButtonPressed(CommandButton commandButton);
    public void updateMsiRetButtonPressed(CommandButton commandButton);
}
