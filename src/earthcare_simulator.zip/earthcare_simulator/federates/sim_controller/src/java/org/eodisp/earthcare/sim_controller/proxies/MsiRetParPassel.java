package org.eodisp.earthcare.sim_controller.proxies;


/**
 * Attributes that represent parameters that are specific to the msi_ret model
 *
 * @author org.eodisp.wrapper.hla.ProxyCompiler
 */

public class MsiRetParPassel extends EarthCAREPassel {
    /**
     * The failure mode of the msi_ret model 
     */
    FailureMode failureMode;

    /**
     * Whether or not the failureMode attribute has been set.
     */
    boolean failureModeIsValid;

    /**
     * Returns the value of the failureMode attribute.
     *
     * @return the current attribute value
     */
    public FailureMode getFailureMode() {
        return failureMode;
    }

    /**
     * Returns <code>true</code> if the attribute 'failureMode' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean failureModeIsValid() {
        return failureModeIsValid;
    }
}
