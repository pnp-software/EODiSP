package org.eodisp.earthcare.sim_controller.proxies;


/**
 * Attributes that represent parameters that are specific to the MC_LW_sim_main
 * utility 
 *
 * @author org.eodisp.wrapper.hla.ProxyCompiler
 */

public class McLwSimMainParPassel extends EarthCAREPassel {
    /**
     * The failure mode of the MC_LW_sim_main utility 
     */
    FailureMode failureMode;

    /**
     * Whether or not the failureMode attribute has been set.
     */
    boolean failureModeIsValid;

    /**
     * Seed for random number generator (negative number to use time and date
     * as seed) 
     */
    float randomNumberSeed;

    /**
     * Whether or not the randomNumberSeed attribute has been set.
     */
    boolean randomNumberSeedIsValid;

    /**
     * Resolution of output (km). Negative entry: Use UFF resolution 
     */
    float outputResolution;

    /**
     * Whether or not the outputResolution attribute has been set.
     */
    boolean outputResolutionIsValid;

    /**
     * Returns the value of the failureMode attribute.
     *
     * @return the current attribute value
     */
    public FailureMode getFailureMode() {
        return failureMode;
    }

    /**
     * Returns <code>true</code> if the attribute 'failureMode' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean failureModeIsValid() {
        return failureModeIsValid;
    }
    /**
     * Returns the value of the randomNumberSeed attribute.
     *
     * @return the current attribute value
     */
    public float getRandomNumberSeed() {
        return randomNumberSeed;
    }

    /**
     * Returns <code>true</code> if the attribute 'randomNumberSeed' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean randomNumberSeedIsValid() {
        return randomNumberSeedIsValid;
    }
    /**
     * Returns the value of the outputResolution attribute.
     *
     * @return the current attribute value
     */
    public float getOutputResolution() {
        return outputResolution;
    }

    /**
     * Returns <code>true</code> if the attribute 'outputResolution' has been updated for this passel.
     *
     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise
     */
    public boolean outputResolutionIsValid() {
        return outputResolutionIsValid;
    }
}
