package org.eodisp.earthcare.sim_controller.proxies;

import hla.rti1516.*;
import hla.rti1516.jlc.*;
import hla.rti1516.jlc.omt.*;
import hla.rti1516.*;

import java.io.*;
import java.util.*;
import java.util.concurrent.*;

import org.eodisp.wrapper.hla.*;

/**
 * Attributes that represent parameters that are specific to the lidar_ret1 model
 *
 * @author org.eodisp.wrapper.hla.ProxyCompiler
 */

public class LidarRet1ParProxy extends EarthCAREProxy implements LidarRet1Par
{
    /**
     * Listeners for attributes associated with the LidarRet1Par class.
     */
    private final CopyOnWriteArrayList<LidarRet1ParListener> listeners = new CopyOnWriteArrayList<LidarRet1ParListener>();

    private final CopyOnWriteArrayList<LidarRet1ParPasselListener> passelListeners = new CopyOnWriteArrayList<LidarRet1ParPasselListener>();

    /**
     * The handle of the failureMode attribute.
     */
    private AttributeHandle failureModeHandle;

    /**
     * Whether or not the failureMode attribute has been set.
     */
    private boolean failureModeIsValid;

    /**
     * Whether or not the failureMode attribute has changed.
     */
    private boolean failureModeIsDirty;

    /**
     * The failure mode of the lidar_ret1 model 
     */
    private FailureMode failureMode;

    /**
     * The handle of the verticalResolution attribute.
     */
    private AttributeHandle verticalResolutionHandle;

    /**
     * Whether or not the verticalResolution attribute has been set.
     */
    private boolean verticalResolutionIsValid;

    /**
     * Whether or not the verticalResolution attribute has changed.
     */
    private boolean verticalResolutionIsDirty;

    /**
     * The desired vertical resolution in km 
     */
    private float verticalResolution;

    /**
     * The handle of the horizontalResolution attribute.
     */
    private AttributeHandle horizontalResolutionHandle;

    /**
     * Whether or not the horizontalResolution attribute has been set.
     */
    private boolean horizontalResolutionIsValid;

    /**
     * Whether or not the horizontalResolution attribute has changed.
     */
    private boolean horizontalResolutionIsDirty;

    /**
     * The desired horizontal resolution in km 
     */
    private float horizontalResolution;


    /**
     * Constructor for object instance proxies created in response to
     * discovered objects.
     *
     * @param pRTIAmbassador the run-time infrastructure ambassador
     * @param pInstanceHandle the object instance handle
     * @param pClassHandle the object class handle
     * @param pName the object name
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    protected LidarRet1ParProxy(RTIambassador pRTIAmbassador,
                                ObjectInstanceHandle pInstanceHandle,
                                ObjectClassHandle pClassHandle,
                                String pName)
              throws RTIinternalError
    {
        super(pRTIAmbassador, pInstanceHandle, pClassHandle, pName);

        try
        {
            initializeAttributes();

            AttributeHandleSet ahs = rtiAmbassador.getAttributeHandleSetFactory().create();

            ahs.add(failureModeHandle);

            ahs.add(verticalResolutionHandle);

            ahs.add(horizontalResolutionHandle);

            rtiAmbassador.requestAttributeValueUpdate(getObjectInstanceHandle(), ahs, new byte[0]);
        }
        catch(RTIexception rtie)
        {
            throw new RTIinternalError(rtie.toString());
        }
    }

    /**
     * Constructor for object instance proxies created to represent new
     * locally owned objects.  Automatically notifies the run-time
     * infrastructure.
     *
     * @param pRTIAmbassador the run-time infrastructure ambassador
     * @param pClassHandle the object class handle
     * @exception ObjectClassNotDefined if the specified object class is not defined
     * @exception ObjectClassNotPublished if the specified object class is not published
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    protected LidarRet1ParProxy(RTIambassador pRTIAmbassador,
                                ObjectClassHandle pClassHandle)
              throws ObjectClassNotDefined,
                     ObjectClassNotPublished,
                     FederateNotExecutionMember,
                     SaveInProgress,
                     RestoreInProgress,
                     RTIinternalError
    {
        super(pRTIAmbassador, pClassHandle);

        try
        {
            initializeAttributes();
        }
        catch(RTIexception rtie)
        {
            throw new RTIinternalError(rtie.toString());
        }
    }

    /**
     * Constructor for object instance proxies created to represent new
     * locally owned objects.  Automatically notifies the run-time
     * infrastructure.
     *
     * @param pRTIAmbassador the run-time infrastructure ambassador
     * @param pClassHandle the object class handle
     * @param pName the object name
     * @exception ObjectClassNotDefined if the specified object class is not defined
     * @exception ObjectClassNotPublished if the specified object class is not published
     * @exception IllegalName if the instance name has is illegal
     * @exception ObjectInstanceNameInUse if the instance name is already in use
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */ 
    protected LidarRet1ParProxy(RTIambassador pRTIAmbassador,
                                ObjectClassHandle pClassHandle,
                                String pName)
              throws ObjectClassNotDefined,
                     ObjectClassNotPublished,
                     IllegalName,
                     ObjectInstanceNameInUse,
                     FederateNotExecutionMember,
                     SaveInProgress,
                     RestoreInProgress,
                     RTIinternalError
    {
        super(pRTIAmbassador, pClassHandle, pName);

        try
        {
            initializeAttributes();
        }
        catch(RTIexception rtie)
        {
            throw new RTIinternalError(rtie.toString());
        }
    }

    /**
     * Initializes the attributes and their handles.
     *
     * @exception InvalidObjectClassHandle if an object class handle is invalid
     * @exception NameNotFound if a name is not found
     * @exception ObjectClassNotDefined if an object class is not defined
     * @exception AttributeNotDefined if an attribute is not defined
     * @exception FederateNotExecutionMember if the federate is not an execution member
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the run-time
     * infrastructure
     */
    private void initializeAttributes()
                 throws InvalidObjectClassHandle,
                        NameNotFound,
                        ObjectClassNotDefined,
                        AttributeNotDefined,
                        FederateNotExecutionMember,
                        SaveInProgress,
                        RestoreInProgress,
                        RTIinternalError
    {
        failureModeHandle = rtiAmbassador.getAttributeHandle(getObjectClassHandle(), "failureMode");
        failureMode = new FailureMode();

        verticalResolutionHandle = rtiAmbassador.getAttributeHandle(getObjectClassHandle(), "verticalResolution");

        horizontalResolutionHandle = rtiAmbassador.getAttributeHandle(getObjectClassHandle(), "horizontalResolution");
    }

    /**
     * Notifies the proxy that it should provide an update regarding a set of object
     * attributes.
     *
     * @param theAttributes the set of attribute handles identifying the attributes that
     * should be sent
     * @param userSuppliedTag the user-supplied tag associated with the request
     * @exception AttributeNotRecognized if an identified attribute was not recognized
     * @exception AttributeNotOwned if the federate did not own a specified attribute
     * @exception FederateInternalError if an error occurs in the federate
     */
    public void notifyProvideAttributeValueUpdate(AttributeHandleSet theAttributes,
                                            byte[] userSuppliedTag)
                throws AttributeNotRecognized,
                       AttributeNotOwned,
                       FederateInternalError
    {
        if(theAttributes.contains(failureModeHandle))
        {
            failureModeIsDirty = true;
        }

        if(theAttributes.contains(verticalResolutionHandle))
        {
            verticalResolutionIsDirty = true;
        }

        if(theAttributes.contains(horizontalResolutionHandle))
        {
            horizontalResolutionIsDirty = true;
        }

        super.notifyProvideAttributeValueUpdate(
            theAttributes,
            userSuppliedTag
        );
    }

    /**
     * Places the attribute values to update into the specified map.
     *
     * @param ahvm the attribute handle value map to populate
     * @param updateAll if <code>true</code> provide updates for all attributes;
     * if <code>false</code>, only provide updates for the modified ones
     * @exception RTIinternalError if an internal error occurs in the run-time
     * infrastructure
     */
    protected void getAttributeValuesToUpdate(AttributeHandleValueMap ahvm,
                                             boolean updateAll)
                   throws RTIinternalError
    {
        if(failureModeIsValid && (updateAll || failureModeIsDirty))
        {
        DataElement encoded = failureMode.encode();

            ahvm.put(failureModeHandle, encoded.toByteArray());

            failureModeIsDirty = false;
        }

        if(verticalResolutionIsValid && (updateAll || verticalResolutionIsDirty))
        {
        HLAfloat32BE encoded = OmtEncoderFactory.getInstance().createHLAfloat32BE(verticalResolution);

            ahvm.put(verticalResolutionHandle, encoded.toByteArray());

            verticalResolutionIsDirty = false;
        }

        if(horizontalResolutionIsValid && (updateAll || horizontalResolutionIsDirty))
        {
        HLAfloat32BE encoded = OmtEncoderFactory.getInstance().createHLAfloat32BE(horizontalResolution);

            ahvm.put(horizontalResolutionHandle, encoded.toByteArray());

            horizontalResolutionIsDirty = false;
        }

        super.getAttributeValuesToUpdate(ahvm, updateAll);
    }

    /**
     * Adds a listener for attributes associated with the LidarRet1Par class.
     *
     * @param l the listener to add
     */
    public void addLidarRet1ParListener(LidarRet1ParListener l) {
        	resetWaitForListener();
        listeners.add(l);
    }

    /**
     * Removes a listener for attributes associated with the LidarRet1Par class.
     *
     * @param l the listener to remove
     */
    public void removeLidarRet1ParListener(LidarRet1ParListener l) {
        listeners.remove(l);
    }

    /**
     * Adds a passel listener for attributes associated with the LidarRet1Par class.
     *
     * @param l the passel listener to add
     */
    public void addLidarRet1ParPasselListener(LidarRet1ParPasselListener l) {
        	resetWaitForListener();
        passelListeners.add(l);
    }

    /**
     * Removes a passel listener for attributes associated with the LidarRet1Par class.
     *
     * @param l the passel listener to remove
     */
    public void removeLidarRet1ParPasselListener(LidarRet1ParPasselListener l) {
        passelListeners.remove(l);
    }
    /**
     * Returns an instance of the LidarRet1ParPassel class.
     *
     * @param l the listener to remove
     */
    protected Object createPassel() {
        return new LidarRet1ParPassel();
    }
    /**
     * Sets the passel values LidarRet1ParPassel class.
     *
     * @param l the listener to remove
     */
    protected void setPasselValues( Object passel,  AttributeHandleValueMap attributeHandleValueMap ) {
        LidarRet1ParPassel localPassel = (LidarRet1ParPassel)passel;
        if(attributeHandleValueMap.containsKey(failureModeHandle)) {
            byte[] value = (byte[])attributeHandleValueMap.get(failureModeHandle);
            localPassel.failureMode = FailureMode.decode(value);
            failureMode = localPassel.failureMode;
            localPassel.failureModeIsValid = true;
            failureModeIsValid = true;

        }
        if(attributeHandleValueMap.containsKey(verticalResolutionHandle)) {
            byte[] value = (byte[])attributeHandleValueMap.get(verticalResolutionHandle);
            ByteWrapper byteWrapper = new ByteWrapper(value);
            HLAfloat32BE dataElement =  OmtEncoderFactory.getInstance().createHLAfloat32BE();
            dataElement.decode(byteWrapper);
            localPassel.verticalResolution = dataElement.getValue();
            verticalResolution = localPassel.verticalResolution;
            localPassel.verticalResolutionIsValid = true;
            verticalResolutionIsValid = true;

        }
        if(attributeHandleValueMap.containsKey(horizontalResolutionHandle)) {
            byte[] value = (byte[])attributeHandleValueMap.get(horizontalResolutionHandle);
            ByteWrapper byteWrapper = new ByteWrapper(value);
            HLAfloat32BE dataElement =  OmtEncoderFactory.getInstance().createHLAfloat32BE();
            dataElement.decode(byteWrapper);
            localPassel.horizontalResolution = dataElement.getValue();
            horizontalResolution = localPassel.horizontalResolution;
            localPassel.horizontalResolutionIsValid = true;
            horizontalResolutionIsValid = true;

        }
        super.setPasselValues( passel, attributeHandleValueMap );
    }
    /**
     * Notifies the listeners of new values
     *
     * @param passel all values that were sent in the same passel. Values were all converted from the attributeHandleValueMap
     * @param attributeHandleValueMap the original attributeHandleValueMap
     */
    protected void notifyListeners( Object passel,  AttributeHandleValueMap attributeHandleValueMap ) {
        LidarRet1ParPassel localPassel = (LidarRet1ParPassel)passel;
        if( listeners.isEmpty() && passelListeners.isEmpty() ) {
            try {
                if(! listenerLatch.await( 300, TimeUnit.SECONDS )) {
                    throw new Error("Nobody attached a listener during objectInstanceDiscovered.");
                }
            } catch (InterruptedException e) {
        	        Thread.currentThread().interrupt();
            }
        }
        if(attributeHandleValueMap.containsKey(failureModeHandle)) {
            for(LidarRet1ParListener listener : listeners) {
                listener.failureModeUpdated(
                    this,
                    localPassel,
                    localPassel.getFailureMode());
            }
        }
        if(attributeHandleValueMap.containsKey(verticalResolutionHandle)) {
            for(LidarRet1ParListener listener : listeners) {
                listener.verticalResolutionUpdated(
                    this,
                    localPassel,
                    localPassel.getVerticalResolution());
            }
        }
        if(attributeHandleValueMap.containsKey(horizontalResolutionHandle)) {
            for(LidarRet1ParListener listener : listeners) {
                listener.horizontalResolutionUpdated(
                    this,
                    localPassel,
                    localPassel.getHorizontalResolution());
            }
        }
        for(LidarRet1ParPasselListener listener : passelListeners) {
            listener.passelUpdated(
               this,
                localPassel);
        }
        super.notifyListeners( passel, attributeHandleValueMap );
    }

    /**
     * Sets the value of the failureMode attribute.
     *
     * @param pFailureMode the new attribute value
     * @param userSuppliedTag a user-supplied tag to associate with the action
     * run-time infrastructure
     */
    public synchronized void setFailureMode(FailureMode pFailureMode) {
        failureMode = pFailureMode;
        failureModeIsValid = true;
        failureModeIsDirty = true;
    }


    /**
     * Sets the value of the failureMode attribute and immediately sends the updated value to the federation.
     *
     * @param pFailureMode the new attribute value
     * @param userSuppliedTag a user-supplied tag that is used as the parameter to {@link ObjectClassInstance#updateAttributeValues(byte[])} 
     * @exception ObjectInstanceNotKnown if the object instance is unknown
     * @exception AttributeNotDefined if one of the attributes is undefined
     * @exception AttributeNotOwned if one of the attributes is not owned
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    public synchronized void setFailureMode(FailureMode pFailureMode, byte[] userSuppliedTag)
                throws ObjectInstanceNotKnown,
                       AttributeNotDefined,
                       AttributeNotOwned,
                       FederateNotExecutionMember,
                       SaveInProgress,
                       RestoreInProgress,
                       RTIinternalError {
        setFailureMode( pFailureMode );
        updateAttributeValues(userSuppliedTag);
    }

    /**
     * Returns the value of the failureMode attribute.
     *
     * @return the current attribute value
     */
    public synchronized FailureMode getFailureMode()
    {
        return failureMode;
    }

    /**
     * Sets the value of the verticalResolution attribute.
     *
     * @param pVerticalResolution the new attribute value
     * @param userSuppliedTag a user-supplied tag to associate with the action
     * run-time infrastructure
     */
    public synchronized void setVerticalResolution(float pVerticalResolution) {
        verticalResolution = pVerticalResolution;
        verticalResolutionIsValid = true;
        verticalResolutionIsDirty = true;
    }


    /**
     * Sets the value of the verticalResolution attribute and immediately sends the updated value to the federation.
     *
     * @param pVerticalResolution the new attribute value
     * @param userSuppliedTag a user-supplied tag that is used as the parameter to {@link ObjectClassInstance#updateAttributeValues(byte[])} 
     * @exception ObjectInstanceNotKnown if the object instance is unknown
     * @exception AttributeNotDefined if one of the attributes is undefined
     * @exception AttributeNotOwned if one of the attributes is not owned
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    public synchronized void setVerticalResolution(float pVerticalResolution, byte[] userSuppliedTag)
                throws ObjectInstanceNotKnown,
                       AttributeNotDefined,
                       AttributeNotOwned,
                       FederateNotExecutionMember,
                       SaveInProgress,
                       RestoreInProgress,
                       RTIinternalError {
        setVerticalResolution( pVerticalResolution );
        updateAttributeValues(userSuppliedTag);
    }

    /**
     * Returns the value of the verticalResolution attribute.
     *
     * @return the current attribute value
     */
    public synchronized float getVerticalResolution()
    {
        return verticalResolution;
    }

    /**
     * Sets the value of the horizontalResolution attribute.
     *
     * @param pHorizontalResolution the new attribute value
     * @param userSuppliedTag a user-supplied tag to associate with the action
     * run-time infrastructure
     */
    public synchronized void setHorizontalResolution(float pHorizontalResolution) {
        horizontalResolution = pHorizontalResolution;
        horizontalResolutionIsValid = true;
        horizontalResolutionIsDirty = true;
    }


    /**
     * Sets the value of the horizontalResolution attribute and immediately sends the updated value to the federation.
     *
     * @param pHorizontalResolution the new attribute value
     * @param userSuppliedTag a user-supplied tag that is used as the parameter to {@link ObjectClassInstance#updateAttributeValues(byte[])} 
     * @exception ObjectInstanceNotKnown if the object instance is unknown
     * @exception AttributeNotDefined if one of the attributes is undefined
     * @exception AttributeNotOwned if one of the attributes is not owned
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    public synchronized void setHorizontalResolution(float pHorizontalResolution, byte[] userSuppliedTag)
                throws ObjectInstanceNotKnown,
                       AttributeNotDefined,
                       AttributeNotOwned,
                       FederateNotExecutionMember,
                       SaveInProgress,
                       RestoreInProgress,
                       RTIinternalError {
        setHorizontalResolution( pHorizontalResolution );
        updateAttributeValues(userSuppliedTag);
    }

    /**
     * Returns the value of the horizontalResolution attribute.
     *
     * @return the current attribute value
     */
    public synchronized float getHorizontalResolution()
    {
        return horizontalResolution;
    }
}
