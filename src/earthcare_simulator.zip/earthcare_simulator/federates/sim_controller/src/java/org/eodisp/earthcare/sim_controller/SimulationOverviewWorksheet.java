package org.eodisp.earthcare.sim_controller;
import org.eodisp.wrapper.excel.*;
import org.eclipse.swt.ole.win32.*;
import java.util.concurrent.CopyOnWriteArrayList;
public class SimulationOverviewWorksheet {
    private Worksheet worksheet;
    private CopyOnWriteArrayList<SimulationOverviewWorksheetButtonListener> buttonPressedListeners = new CopyOnWriteArrayList<SimulationOverviewWorksheetButtonListener>();

    public SimulationOverviewWorksheet(Worksheet worksheet) {
        this.worksheet = worksheet;
        worksheet.getWorkbook().addSheetChangeListener(new SheetChangeListener() {
            public void sheetChanged(Range range) {
            String rangeName = range.getName();
                if (rangeName != null && rangeName.equals("BUTTON_ACTION")) {
                    String buttonId = range.getStringValue();
                    CommandButton commandButton = SimulationOverviewWorksheet.this.worksheet.getCommandButton(buttonId);
                if(buttonId.equals("StartSimulationButton")) {
                    for (SimulationOverviewWorksheetButtonListener listener : buttonPressedListeners) {
                        listener.startSimulationButtonPressed(commandButton);
                    }
                }
                else if(buttonId.equals("QuitSimulationButton")) {
                    for (SimulationOverviewWorksheetButtonListener listener : buttonPressedListeners) {
                        listener.quitSimulationButtonPressed(commandButton);
                    }
                }
                }
            }
        });
    }
    public void addButtonPressedListener(SimulationOverviewWorksheetButtonListener listener) {
        buttonPressedListeners.add(listener);
    }
    public Range getHELLO_ACTION(){
        return worksheet.getRange("HELLO_ACTION");
    }
    public Range getTest(){
        return worksheet.getRange("test");
    }
    public CommandButton getStartSimulationButton(){
        return worksheet.getCommandButton("StartSimulationButton");
    }
    public CommandButton getQuitSimulationButton(){
        return worksheet.getCommandButton("QuitSimulationButton");
    }
    public Range getRange(String range) {
        return worksheet.getRange(range);
    }
}
