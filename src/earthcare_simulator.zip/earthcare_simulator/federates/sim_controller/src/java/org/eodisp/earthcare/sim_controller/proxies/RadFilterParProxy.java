package org.eodisp.earthcare.sim_controller.proxies;

import hla.rti1516.*;
import hla.rti1516.jlc.*;
import hla.rti1516.jlc.omt.*;
import hla.rti1516.*;

import java.io.*;
import java.util.*;
import java.util.concurrent.*;

import org.eodisp.wrapper.hla.*;

/**
 * Attributes that represent parameters that are specific to the rad_filter model
 *
 * @author org.eodisp.wrapper.hla.ProxyCompiler
 */

public class RadFilterParProxy extends EarthCAREProxy implements RadFilterPar
{
    /**
     * Listeners for attributes associated with the RadFilterPar class.
     */
    private final CopyOnWriteArrayList<RadFilterParListener> listeners = new CopyOnWriteArrayList<RadFilterParListener>();

    private final CopyOnWriteArrayList<RadFilterParPasselListener> passelListeners = new CopyOnWriteArrayList<RadFilterParPasselListener>();

    /**
     * The handle of the failureMode attribute.
     */
    private AttributeHandle failureModeHandle;

    /**
     * Whether or not the failureMode attribute has been set.
     */
    private boolean failureModeIsValid;

    /**
     * Whether or not the failureMode attribute has changed.
     */
    private boolean failureModeIsDirty;

    /**
     * The failure mode of the rad_filter model 
     */
    private FailureMode failureMode;

    /**
     * The handle of the startingAltitude attribute.
     */
    private AttributeHandle startingAltitudeHandle;

    /**
     * Whether or not the startingAltitude attribute has been set.
     */
    private boolean startingAltitudeIsValid;

    /**
     * Whether or not the startingAltitude attribute has changed.
     */
    private boolean startingAltitudeIsDirty;

    /**
     * The starting altitude in km 
     */
    private float startingAltitude;

    /**
     * The handle of the endingAltitude attribute.
     */
    private AttributeHandle endingAltitudeHandle;

    /**
     * Whether or not the endingAltitude attribute has been set.
     */
    private boolean endingAltitudeIsValid;

    /**
     * Whether or not the endingAltitude attribute has changed.
     */
    private boolean endingAltitudeIsDirty;

    /**
     * The ending altitude in km 
     */
    private float endingAltitude;


    /**
     * Constructor for object instance proxies created in response to
     * discovered objects.
     *
     * @param pRTIAmbassador the run-time infrastructure ambassador
     * @param pInstanceHandle the object instance handle
     * @param pClassHandle the object class handle
     * @param pName the object name
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    protected RadFilterParProxy(RTIambassador pRTIAmbassador,
                                ObjectInstanceHandle pInstanceHandle,
                                ObjectClassHandle pClassHandle,
                                String pName)
              throws RTIinternalError
    {
        super(pRTIAmbassador, pInstanceHandle, pClassHandle, pName);

        try
        {
            initializeAttributes();

            AttributeHandleSet ahs = rtiAmbassador.getAttributeHandleSetFactory().create();

            ahs.add(failureModeHandle);

            ahs.add(startingAltitudeHandle);

            ahs.add(endingAltitudeHandle);

            rtiAmbassador.requestAttributeValueUpdate(getObjectInstanceHandle(), ahs, new byte[0]);
        }
        catch(RTIexception rtie)
        {
            throw new RTIinternalError(rtie.toString());
        }
    }

    /**
     * Constructor for object instance proxies created to represent new
     * locally owned objects.  Automatically notifies the run-time
     * infrastructure.
     *
     * @param pRTIAmbassador the run-time infrastructure ambassador
     * @param pClassHandle the object class handle
     * @exception ObjectClassNotDefined if the specified object class is not defined
     * @exception ObjectClassNotPublished if the specified object class is not published
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    protected RadFilterParProxy(RTIambassador pRTIAmbassador,
                                ObjectClassHandle pClassHandle)
              throws ObjectClassNotDefined,
                     ObjectClassNotPublished,
                     FederateNotExecutionMember,
                     SaveInProgress,
                     RestoreInProgress,
                     RTIinternalError
    {
        super(pRTIAmbassador, pClassHandle);

        try
        {
            initializeAttributes();
        }
        catch(RTIexception rtie)
        {
            throw new RTIinternalError(rtie.toString());
        }
    }

    /**
     * Constructor for object instance proxies created to represent new
     * locally owned objects.  Automatically notifies the run-time
     * infrastructure.
     *
     * @param pRTIAmbassador the run-time infrastructure ambassador
     * @param pClassHandle the object class handle
     * @param pName the object name
     * @exception ObjectClassNotDefined if the specified object class is not defined
     * @exception ObjectClassNotPublished if the specified object class is not published
     * @exception IllegalName if the instance name has is illegal
     * @exception ObjectInstanceNameInUse if the instance name is already in use
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */ 
    protected RadFilterParProxy(RTIambassador pRTIAmbassador,
                                ObjectClassHandle pClassHandle,
                                String pName)
              throws ObjectClassNotDefined,
                     ObjectClassNotPublished,
                     IllegalName,
                     ObjectInstanceNameInUse,
                     FederateNotExecutionMember,
                     SaveInProgress,
                     RestoreInProgress,
                     RTIinternalError
    {
        super(pRTIAmbassador, pClassHandle, pName);

        try
        {
            initializeAttributes();
        }
        catch(RTIexception rtie)
        {
            throw new RTIinternalError(rtie.toString());
        }
    }

    /**
     * Initializes the attributes and their handles.
     *
     * @exception InvalidObjectClassHandle if an object class handle is invalid
     * @exception NameNotFound if a name is not found
     * @exception ObjectClassNotDefined if an object class is not defined
     * @exception AttributeNotDefined if an attribute is not defined
     * @exception FederateNotExecutionMember if the federate is not an execution member
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the run-time
     * infrastructure
     */
    private void initializeAttributes()
                 throws InvalidObjectClassHandle,
                        NameNotFound,
                        ObjectClassNotDefined,
                        AttributeNotDefined,
                        FederateNotExecutionMember,
                        SaveInProgress,
                        RestoreInProgress,
                        RTIinternalError
    {
        failureModeHandle = rtiAmbassador.getAttributeHandle(getObjectClassHandle(), "failureMode");
        failureMode = new FailureMode();

        startingAltitudeHandle = rtiAmbassador.getAttributeHandle(getObjectClassHandle(), "startingAltitude");

        endingAltitudeHandle = rtiAmbassador.getAttributeHandle(getObjectClassHandle(), "endingAltitude");
    }

    /**
     * Notifies the proxy that it should provide an update regarding a set of object
     * attributes.
     *
     * @param theAttributes the set of attribute handles identifying the attributes that
     * should be sent
     * @param userSuppliedTag the user-supplied tag associated with the request
     * @exception AttributeNotRecognized if an identified attribute was not recognized
     * @exception AttributeNotOwned if the federate did not own a specified attribute
     * @exception FederateInternalError if an error occurs in the federate
     */
    public void notifyProvideAttributeValueUpdate(AttributeHandleSet theAttributes,
                                            byte[] userSuppliedTag)
                throws AttributeNotRecognized,
                       AttributeNotOwned,
                       FederateInternalError
    {
        if(theAttributes.contains(failureModeHandle))
        {
            failureModeIsDirty = true;
        }

        if(theAttributes.contains(startingAltitudeHandle))
        {
            startingAltitudeIsDirty = true;
        }

        if(theAttributes.contains(endingAltitudeHandle))
        {
            endingAltitudeIsDirty = true;
        }

        super.notifyProvideAttributeValueUpdate(
            theAttributes,
            userSuppliedTag
        );
    }

    /**
     * Places the attribute values to update into the specified map.
     *
     * @param ahvm the attribute handle value map to populate
     * @param updateAll if <code>true</code> provide updates for all attributes;
     * if <code>false</code>, only provide updates for the modified ones
     * @exception RTIinternalError if an internal error occurs in the run-time
     * infrastructure
     */
    protected void getAttributeValuesToUpdate(AttributeHandleValueMap ahvm,
                                             boolean updateAll)
                   throws RTIinternalError
    {
        if(failureModeIsValid && (updateAll || failureModeIsDirty))
        {
        DataElement encoded = failureMode.encode();

            ahvm.put(failureModeHandle, encoded.toByteArray());

            failureModeIsDirty = false;
        }

        if(startingAltitudeIsValid && (updateAll || startingAltitudeIsDirty))
        {
        HLAfloat32BE encoded = OmtEncoderFactory.getInstance().createHLAfloat32BE(startingAltitude);

            ahvm.put(startingAltitudeHandle, encoded.toByteArray());

            startingAltitudeIsDirty = false;
        }

        if(endingAltitudeIsValid && (updateAll || endingAltitudeIsDirty))
        {
        HLAfloat32BE encoded = OmtEncoderFactory.getInstance().createHLAfloat32BE(endingAltitude);

            ahvm.put(endingAltitudeHandle, encoded.toByteArray());

            endingAltitudeIsDirty = false;
        }

        super.getAttributeValuesToUpdate(ahvm, updateAll);
    }

    /**
     * Adds a listener for attributes associated with the RadFilterPar class.
     *
     * @param l the listener to add
     */
    public void addRadFilterParListener(RadFilterParListener l) {
        	resetWaitForListener();
        listeners.add(l);
    }

    /**
     * Removes a listener for attributes associated with the RadFilterPar class.
     *
     * @param l the listener to remove
     */
    public void removeRadFilterParListener(RadFilterParListener l) {
        listeners.remove(l);
    }

    /**
     * Adds a passel listener for attributes associated with the RadFilterPar class.
     *
     * @param l the passel listener to add
     */
    public void addRadFilterParPasselListener(RadFilterParPasselListener l) {
        	resetWaitForListener();
        passelListeners.add(l);
    }

    /**
     * Removes a passel listener for attributes associated with the RadFilterPar class.
     *
     * @param l the passel listener to remove
     */
    public void removeRadFilterParPasselListener(RadFilterParPasselListener l) {
        passelListeners.remove(l);
    }
    /**
     * Returns an instance of the RadFilterParPassel class.
     *
     * @param l the listener to remove
     */
    protected Object createPassel() {
        return new RadFilterParPassel();
    }
    /**
     * Sets the passel values RadFilterParPassel class.
     *
     * @param l the listener to remove
     */
    protected void setPasselValues( Object passel,  AttributeHandleValueMap attributeHandleValueMap ) {
        RadFilterParPassel localPassel = (RadFilterParPassel)passel;
        if(attributeHandleValueMap.containsKey(failureModeHandle)) {
            byte[] value = (byte[])attributeHandleValueMap.get(failureModeHandle);
            localPassel.failureMode = FailureMode.decode(value);
            failureMode = localPassel.failureMode;
            localPassel.failureModeIsValid = true;
            failureModeIsValid = true;

        }
        if(attributeHandleValueMap.containsKey(startingAltitudeHandle)) {
            byte[] value = (byte[])attributeHandleValueMap.get(startingAltitudeHandle);
            ByteWrapper byteWrapper = new ByteWrapper(value);
            HLAfloat32BE dataElement =  OmtEncoderFactory.getInstance().createHLAfloat32BE();
            dataElement.decode(byteWrapper);
            localPassel.startingAltitude = dataElement.getValue();
            startingAltitude = localPassel.startingAltitude;
            localPassel.startingAltitudeIsValid = true;
            startingAltitudeIsValid = true;

        }
        if(attributeHandleValueMap.containsKey(endingAltitudeHandle)) {
            byte[] value = (byte[])attributeHandleValueMap.get(endingAltitudeHandle);
            ByteWrapper byteWrapper = new ByteWrapper(value);
            HLAfloat32BE dataElement =  OmtEncoderFactory.getInstance().createHLAfloat32BE();
            dataElement.decode(byteWrapper);
            localPassel.endingAltitude = dataElement.getValue();
            endingAltitude = localPassel.endingAltitude;
            localPassel.endingAltitudeIsValid = true;
            endingAltitudeIsValid = true;

        }
        super.setPasselValues( passel, attributeHandleValueMap );
    }
    /**
     * Notifies the listeners of new values
     *
     * @param passel all values that were sent in the same passel. Values were all converted from the attributeHandleValueMap
     * @param attributeHandleValueMap the original attributeHandleValueMap
     */
    protected void notifyListeners( Object passel,  AttributeHandleValueMap attributeHandleValueMap ) {
        RadFilterParPassel localPassel = (RadFilterParPassel)passel;
        if( listeners.isEmpty() && passelListeners.isEmpty() ) {
            try {
                if(! listenerLatch.await( 300, TimeUnit.SECONDS )) {
                    throw new Error("Nobody attached a listener during objectInstanceDiscovered.");
                }
            } catch (InterruptedException e) {
        	        Thread.currentThread().interrupt();
            }
        }
        if(attributeHandleValueMap.containsKey(failureModeHandle)) {
            for(RadFilterParListener listener : listeners) {
                listener.failureModeUpdated(
                    this,
                    localPassel,
                    localPassel.getFailureMode());
            }
        }
        if(attributeHandleValueMap.containsKey(startingAltitudeHandle)) {
            for(RadFilterParListener listener : listeners) {
                listener.startingAltitudeUpdated(
                    this,
                    localPassel,
                    localPassel.getStartingAltitude());
            }
        }
        if(attributeHandleValueMap.containsKey(endingAltitudeHandle)) {
            for(RadFilterParListener listener : listeners) {
                listener.endingAltitudeUpdated(
                    this,
                    localPassel,
                    localPassel.getEndingAltitude());
            }
        }
        for(RadFilterParPasselListener listener : passelListeners) {
            listener.passelUpdated(
               this,
                localPassel);
        }
        super.notifyListeners( passel, attributeHandleValueMap );
    }

    /**
     * Sets the value of the failureMode attribute.
     *
     * @param pFailureMode the new attribute value
     * @param userSuppliedTag a user-supplied tag to associate with the action
     * run-time infrastructure
     */
    public synchronized void setFailureMode(FailureMode pFailureMode) {
        failureMode = pFailureMode;
        failureModeIsValid = true;
        failureModeIsDirty = true;
    }


    /**
     * Sets the value of the failureMode attribute and immediately sends the updated value to the federation.
     *
     * @param pFailureMode the new attribute value
     * @param userSuppliedTag a user-supplied tag that is used as the parameter to {@link ObjectClassInstance#updateAttributeValues(byte[])} 
     * @exception ObjectInstanceNotKnown if the object instance is unknown
     * @exception AttributeNotDefined if one of the attributes is undefined
     * @exception AttributeNotOwned if one of the attributes is not owned
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    public synchronized void setFailureMode(FailureMode pFailureMode, byte[] userSuppliedTag)
                throws ObjectInstanceNotKnown,
                       AttributeNotDefined,
                       AttributeNotOwned,
                       FederateNotExecutionMember,
                       SaveInProgress,
                       RestoreInProgress,
                       RTIinternalError {
        setFailureMode( pFailureMode );
        updateAttributeValues(userSuppliedTag);
    }

    /**
     * Returns the value of the failureMode attribute.
     *
     * @return the current attribute value
     */
    public synchronized FailureMode getFailureMode()
    {
        return failureMode;
    }

    /**
     * Sets the value of the startingAltitude attribute.
     *
     * @param pStartingAltitude the new attribute value
     * @param userSuppliedTag a user-supplied tag to associate with the action
     * run-time infrastructure
     */
    public synchronized void setStartingAltitude(float pStartingAltitude) {
        startingAltitude = pStartingAltitude;
        startingAltitudeIsValid = true;
        startingAltitudeIsDirty = true;
    }


    /**
     * Sets the value of the startingAltitude attribute and immediately sends the updated value to the federation.
     *
     * @param pStartingAltitude the new attribute value
     * @param userSuppliedTag a user-supplied tag that is used as the parameter to {@link ObjectClassInstance#updateAttributeValues(byte[])} 
     * @exception ObjectInstanceNotKnown if the object instance is unknown
     * @exception AttributeNotDefined if one of the attributes is undefined
     * @exception AttributeNotOwned if one of the attributes is not owned
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    public synchronized void setStartingAltitude(float pStartingAltitude, byte[] userSuppliedTag)
                throws ObjectInstanceNotKnown,
                       AttributeNotDefined,
                       AttributeNotOwned,
                       FederateNotExecutionMember,
                       SaveInProgress,
                       RestoreInProgress,
                       RTIinternalError {
        setStartingAltitude( pStartingAltitude );
        updateAttributeValues(userSuppliedTag);
    }

    /**
     * Returns the value of the startingAltitude attribute.
     *
     * @return the current attribute value
     */
    public synchronized float getStartingAltitude()
    {
        return startingAltitude;
    }

    /**
     * Sets the value of the endingAltitude attribute.
     *
     * @param pEndingAltitude the new attribute value
     * @param userSuppliedTag a user-supplied tag to associate with the action
     * run-time infrastructure
     */
    public synchronized void setEndingAltitude(float pEndingAltitude) {
        endingAltitude = pEndingAltitude;
        endingAltitudeIsValid = true;
        endingAltitudeIsDirty = true;
    }


    /**
     * Sets the value of the endingAltitude attribute and immediately sends the updated value to the federation.
     *
     * @param pEndingAltitude the new attribute value
     * @param userSuppliedTag a user-supplied tag that is used as the parameter to {@link ObjectClassInstance#updateAttributeValues(byte[])} 
     * @exception ObjectInstanceNotKnown if the object instance is unknown
     * @exception AttributeNotDefined if one of the attributes is undefined
     * @exception AttributeNotOwned if one of the attributes is not owned
     * @exception FederateNotExecutionMember if the federate is not a member of an execution
     * @exception SaveInProgress if a save operation is in progress
     * @exception RestoreInProgress if a restore operation is in progress
     * @exception RTIinternalError if an internal error occurred in the
     * run-time infrastructure
     */
    public synchronized void setEndingAltitude(float pEndingAltitude, byte[] userSuppliedTag)
                throws ObjectInstanceNotKnown,
                       AttributeNotDefined,
                       AttributeNotOwned,
                       FederateNotExecutionMember,
                       SaveInProgress,
                       RestoreInProgress,
                       RTIinternalError {
        setEndingAltitude( pEndingAltitude );
        updateAttributeValues(userSuppliedTag);
    }

    /**
     * Returns the value of the endingAltitude attribute.
     *
     * @return the current attribute value
     */
    public synchronized float getEndingAltitude()
    {
        return endingAltitude;
    }
}
