/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.earthcare.sim_controller;

import java.io.File;
import java.io.IOException;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eodisp.wrapper.excel.CommandButton;
import org.eodisp.wrapper.excel.ExcelApplication;
import org.eodisp.wrapper.excel.Workbook;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class TestWorkbook {

	/**
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		Display display = new Display();
		Shell shell = new Shell(display);
		ExcelApplication application = new ExcelApplication(shell);
		application.setVisible(true);
		File file = new File("federates/sim_controller/resources/sim_controller.xls");
		if (!file.exists()) {
			throw new RuntimeException(String.format("Could not open Excel workbook: %s", file));
		}
		Workbook workbook = application.openWorkbook(file, ExcelApplication.NEVER_UPDATE_LINKS, true);
		ModelConfigurationWorksheet modelConfigurationWorksheet = new ModelConfigurationWorksheet(workbook
				.getWorksheet("ModelConfiguration"));
		modelConfigurationWorksheet.addButtonPressedListener(new ModelConfigurationWorksheetButtonListener(){

			public void updateLidFilterButtonPressed(CommandButton commandButton) {
				System.out.println("Pressed " + commandButton.getName());
				
			}

			public void updateLidarButtonPressed(CommandButton commandButton) {
				System.out.println("Pressed " + commandButton.getName());
				
			}

			public void updateLidarRet1ButtonPressed(CommandButton commandButton) {
				System.out.println("Pressed " + commandButton.getName());
				
			}

			public void updateLwMsiLidarRadarButtonPressed(CommandButton commandButton) {
				System.out.println("Pressed " + commandButton.getName());
			}

			public void updateMcLwSimMainButtonPressed(CommandButton commandButton) {
				System.out.println("Pressed " + commandButton.getName());
			}

			public void updateMcSimMainButtonPressed(CommandButton commandButton) {
				System.out.println("Pressed " + commandButton.getName());
			}

			public void updateMsiRetButtonPressed(CommandButton commandButton) {
				System.out.println("Pressed " + commandButton.getName());
			}

			public void updateOrbitPropagatorButtonPressed(CommandButton commandButton) {
				System.out.println("Pressed " + commandButton.getName());
			}

			public void updateRadFilterButtonPressed(CommandButton commandButton) {
				System.out.println("Pressed " + commandButton.getName());
			}

			public void updateRadarButtonPressed(CommandButton commandButton) {
				System.out.println("Pressed " + commandButton.getName());
			}

			public void updateSceneCreatorButtonPressed(CommandButton commandButton) {
				System.out.println("Pressed " + commandButton.getName());
			}

		});
		
		SimulationOverviewWorksheet  simulationOverviewWs = new SimulationOverviewWorksheet(workbook.getWorksheet("SimulationOverview"));
		simulationOverviewWs.addButtonPressedListener( new SimulationOverviewWorksheetButtonListener() {

			public void quitSimulationButtonPressed(CommandButton commandButton) {
				System.out.println("Pressed " + commandButton.getName());
				
			}

			public void startSimulationButtonPressed(CommandButton commandButton) {
				System.out.println("Pressed " + commandButton.getName());
				
			}
			
		});

		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();

	}

}
