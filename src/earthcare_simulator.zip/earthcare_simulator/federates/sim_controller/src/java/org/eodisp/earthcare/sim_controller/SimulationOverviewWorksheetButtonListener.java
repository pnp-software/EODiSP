package org.eodisp.earthcare.sim_controller;
import org.eodisp.wrapper.excel.CommandButton;
public interface SimulationOverviewWorksheetButtonListener {
    public void startSimulationButtonPressed(CommandButton commandButton);
    public void quitSimulationButtonPressed(CommandButton commandButton);
}
