package org.eodisp.wrapper.swt;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eodisp.wrapper.hla.EodispFederate;

public class StartSwt {
	static {
		System.setProperty("java.library.path", System.getProperty("java.library.path") + ";"
				+ new File("lib/swt-3.2").getAbsolutePath());
	}

	public static class SwtClassLoader extends URLClassLoader {
		public SwtClassLoader(URL[] urls) {
			super(urls, null);
		}

		@Override
		protected String findLibrary(String libname) {
			if (libname.startsWith("swt")) {
				System.out.println("looking for: " + libname);
				return new File("lib/swt-3.2", libname + ".dll").getAbsolutePath();
			}
			return super.findLibrary(libname);
		}
	}

	public StartSwt() {
		try {
			System.out.println(getClass().getClassLoader());
			String s = "Hello";

			System.out.println(s.getClass().getClassLoader());
			System.out.println(Runtime.getRuntime().getClass().getClassLoader());
			System.out.println(System.class.getClassLoader());

			// // File awtDll = new File(bundlePath,
			// // "swt-awt-win32-3232.dll").getCanonicalFile();
			// // File swtDll = new File(bundlePath,
			// // "swt-win32-3232.dll").getCanonicalFile();
			// // File gdipDll = new File(bundlePath,
			// // "swt-gdip-win32-3232.dll").getCanonicalFile();
			// // File wglDll = new File(bundlePath,
			// // "swt-wgl-win32-3232.dll").getCanonicalFile();
			//
			System.out.println(System.getProperty("java.library.path"));

			Display display = new Display();
			Shell shell = new Shell(display);
			while (!shell.isDisposed()) {
				if (!display.readAndDispatch())
					display.sleep();
			}
			display.dispose();

		} catch (Throwable e) {
			e.printStackTrace();
		}
	}

	/**
	 * @param args
	 * @throws Throwable
	 * @throws IllegalAccessException
	 * @throws Throwable
	 */
	public static void main(String[] args) throws Throwable {
		String classpathString = System.getProperty("java.class.path");
		String[] classpath = classpathString.split(";");
		URL[] urlClasspath = new URL[classpath.length];
		for (int i = 0; i < classpath.length; i++) {
			String string = classpath[i];
			urlClasspath[i] = new File(string).toURL();
		}

		ClassLoader classLoader = new SwtClassLoader(urlClasspath);
		try {
			Class<?> clazz = classLoader.loadClass("org.eodisp.wrapper.swt.StartSwt");
			System.out.println(clazz.getClassLoader());
			Object main = clazz.newInstance();
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
