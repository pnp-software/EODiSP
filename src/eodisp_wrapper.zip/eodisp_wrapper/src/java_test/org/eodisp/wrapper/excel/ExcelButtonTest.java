package org.eodisp.wrapper.excel;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class ExcelButtonTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Display display = new Display();
		final Shell shell = new Shell(display);
		final ExcelApplication app = new ExcelApplication(shell);
		app.setVisible(true);
		try {
			Workbook workbook = app.openWorkbook(new File("resources/testBook_1.xls")
					.getAbsoluteFile());
			System.out.println(app.getNrOfWorkbooks());
			// workbook.close();
			final Worksheet worksheet = workbook.getWorksheet(1);
			worksheet.getRange("A2").setValue(22.222);
			Executors.newScheduledThreadPool(1).schedule(new Runnable() {

				public void run() {
					try {
						Display.getDefault().syncExec(new Runnable() {
							public void run() {
								worksheet.getRange("A2").setValue(33.333);
							}
						});
					} catch (Throwable e) {
						e.printStackTrace();
					}
				}
			}, 3, TimeUnit.SECONDS);

			Executors.newScheduledThreadPool(1).schedule(new Runnable() {

				public void run() {
					try {
						Display.getDefault().syncExec(new Runnable() {
							public void run() {
								System.out.println("Dispose shell ...");
								app.setVisible(false);
								System.out.println("Quit application");
								app.quit();
								/*
								 * quites the main thread (which is the UI
								 * thread)
								 */
								shell.dispose();
							}
						});
					} catch (Throwable e) {
						e.printStackTrace();
					}
				}
			}, 8, TimeUnit.SECONDS);

		} catch (IOException e) {
			e.printStackTrace();
		}

		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
