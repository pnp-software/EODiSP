package org.eodisp.wrapper.excel;

import java.io.File;
import java.io.IOException;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class ExcelApplicationTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Display display = new Display();
		final Shell shell = new Shell(display);
		final ExcelApplication app = new ExcelApplication(shell);
		app.setVisible(true);
		try {
			Workbook workbook = app.openWorkbook(new File("resources/testBook_1.xls")
					.getAbsoluteFile());

			final Worksheet worksheet = workbook.getWorksheet(1);

			workbook.addSheetChangeListener(new SheetChangeListener() {
				public void sheetChanged(Range range) {
					if (range.getAddress().equals("$Z$1")) {
						System.out.println("Clicked!");
						worksheet.getCommandButton("CommandButton1").setEnabled(false);
					}
				}
			});

		} catch (IOException e) {
			e.printStackTrace();
		}

		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
