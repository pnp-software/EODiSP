package org.eodisp.wrapper.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Arrays;

import junit.framework.TestCase;

public class ChunkedOutputStreamTest extends TestCase {

	private static final byte[] DATA = new byte[] { 0, 1, 2, 3, 4 };

	public void testWrite_CorrectSequence() throws IOException {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		ChunkedOutputStream chunkedOutputStream = new ChunkedOutputStream(out, 5);
		assertFalse(chunkedOutputStream.write(new byte[] { 0 }, 0));
		assertFalse(chunkedOutputStream.write(new byte[] { 1 }, 1));
		assertFalse(chunkedOutputStream.write(new byte[] { 2 }, 2));
		assertFalse(chunkedOutputStream.write(new byte[] { 3 }, 3));
		assertTrue(chunkedOutputStream.write(new byte[] { 4 }, 4));
		assertTrue(String.format("Expected %s but was %s", Arrays.toString(DATA), Arrays.toString(out.toByteArray())),
				Arrays.equals(DATA, out.toByteArray()));
	}

	public void testWrite_WrongSequence1() throws IOException {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		ChunkedOutputStream chunkedOutputStream = new ChunkedOutputStream(out, 5);
		assertFalse(chunkedOutputStream.write(new byte[] { 1 }, 1));
		assertFalse(chunkedOutputStream.write(new byte[] { 0 }, 0));
		assertFalse(chunkedOutputStream.write(new byte[] { 2 }, 2));
		assertFalse(chunkedOutputStream.write(new byte[] { 3 }, 3));
		assertTrue(chunkedOutputStream.write(new byte[] { 4 }, 4));
		assertTrue(String.format("Expected %s but was %s", Arrays.toString(DATA), Arrays.toString(out.toByteArray())),
				Arrays.equals(DATA, out.toByteArray()));
	}

	public void testWrite_WrongSequence2() throws IOException {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		ChunkedOutputStream chunkedOutputStream = new ChunkedOutputStream(out, 5);
		assertFalse(chunkedOutputStream.write(new byte[] { 3 }, 3));
		assertFalse(chunkedOutputStream.write(new byte[] { 1 }, 1));
		assertFalse(chunkedOutputStream.write(new byte[] { 4 }, 4));
		assertFalse(chunkedOutputStream.write(new byte[] { 0 }, 0));
		assertTrue(chunkedOutputStream.write(new byte[] { 2 }, 2));

		assertTrue(String.format("Expected %s but was %s", Arrays.toString(DATA), Arrays.toString(out.toByteArray())),
				Arrays.equals(DATA, out.toByteArray()));
	}

	public void testWrite_IllegalArgumentException() throws IOException {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		ChunkedOutputStream chunkedOutputStream = new ChunkedOutputStream(out, 5);
		chunkedOutputStream.write(new byte[] { 0 }, 0);
		try {
			chunkedOutputStream.write(new byte[] { 0 }, 0);
			fail(IllegalArgumentException.class.getName() + " expected");
		} catch (IllegalArgumentException expected) {
			assertTrue(true);
		}
	}

	public void testWrite_IndexOutOfBoundsException() throws IOException {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		ChunkedOutputStream chunkedOutputStream = new ChunkedOutputStream(out, 5);
		try {
			chunkedOutputStream.write(new byte[] { 0 }, 5);
			fail(IllegalArgumentException.class.getName() + " expected");
		} catch (IndexOutOfBoundsException expected) {
			assertTrue(true);
		}
	}

}
