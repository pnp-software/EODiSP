/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.wrapper.util;

import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import net.jcip.annotations.GuardedBy;

/**
 * An output stream that writes chunks to a stream in the correct order.
 * 
 * @author ibirrer
 * @version $Id:$
 */
public class ChunkedOutputStream {

	@GuardedBy("this")
	private final OutputStream out;

	private final Long lastChunkNr;

	@GuardedBy("this")
	private Long nextChunkToWrite = new Long(0);

	@GuardedBy("this")
	private final Map<Long, byte[]> cachedChunks = new HashMap<Long, byte[]>();

	/**
	 * @param out
	 *            the output stream to write the chunks to
	 * @param chunks
	 *            the number of chunks to be expected
	 */
	public ChunkedOutputStream(final OutputStream out, final long chunks) {
		this.out = out;
		lastChunkNr = new Long(chunks - 1);
	}

	public synchronized boolean write(byte[] data, long chunkNr) throws IOException {
		if (chunkNr > lastChunkNr.longValue()) {
			throw new IndexOutOfBoundsException("Chunk " + chunkNr + " is out of bounds");
		}
		if (chunkNr < nextChunkToWrite.longValue()) {
			throw new IllegalArgumentException("Chunk " + chunkNr + " has already been written");
		}

		cachedChunks.put(new Long(chunkNr), data);
		return writeCachedChunks();
	}

	private synchronized boolean writeCachedChunks() throws IOException {
		if (cachedChunks.containsKey(nextChunkToWrite)) {
			out.write(cachedChunks.get(nextChunkToWrite));
			if (nextChunkToWrite.equals(lastChunkNr)) {
				cachedChunks.remove(nextChunkToWrite);
				out.close();
				return true;
			}
			cachedChunks.remove(nextChunkToWrite);
			nextChunkToWrite = new Long(nextChunkToWrite.longValue() + 1);
			return writeCachedChunks();
		}
		return false;
	}

}
