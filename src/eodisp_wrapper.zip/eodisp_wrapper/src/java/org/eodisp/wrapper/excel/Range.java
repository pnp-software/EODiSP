/**
 * 
 */
package org.eodisp.wrapper.excel;

import org.eclipse.swt.ole.win32.OleAutomation;
import org.eclipse.swt.ole.win32.Variant;

/**
 * Represents a range in an excel worksheet
 * 
 * @author ibirrer
 */
public class Range {
	private static final int PROP_ADDRESS = 0x000000ec;

	private static final int PROP_COLUMN = 0x000000f0;

	private static final int PROP_ROW = 0x00000101;

	final static int PROP_WORKSHEET = 0x0000015c;

	private final OleAutomation range;

	public final static int PROP_VALUE = 0x00000006;

	private final static int RANGE_NAME = 0x0000006e;

	private final static int RANGE_NAME_NAME = 0x0000006e;

	private final static int RANGE_SELECT = 0x000000eb;

	private final Worksheet worksheet;

	public Range(OleAutomation range, Worksheet worksheet) {
		this.range = range;
		this.worksheet = worksheet;
	}

	/**
	 * Return the row index of this range
	 * 
	 * @return the row index of this range
	 */
	public long getRow() {
		return range.getProperty(PROP_ROW).getLong();
	}

	/**
	 * Returns the address of this range in the form "A1".
	 * 
	 * @return the address of this range
	 */
	public String getAddress() {
		return range.getProperty(PROP_ADDRESS).getString();
	}

	/**
	 * Returns the column index of this range
	 * 
	 * @return the column index of this range
	 */
	public long getColumn() {
		return range.getProperty(PROP_COLUMN).getLong();
	}

	/**
	 * Sets the value of this range
	 * 
	 * @param value
	 *            the value of this range
	 */
	public void setValue(int value) {
		range.setProperty(PROP_VALUE, new Variant(value));
	}

	/**
	 * Sets the value of this range
	 * 
	 * @param value
	 *            the value of this range
	 */
	public void setValue(long value) {
		range.setProperty(PROP_VALUE, new Variant(value));
	}

	/**
	 * Sets the value of this range
	 * 
	 * @param value
	 *            the value of this range
	 */
	public void setValue(String value) {
		range.setProperty(PROP_VALUE, new Variant(value));
	}

	/**
	 * Sets the value of this range
	 * 
	 * @param value
	 *            the value of this range
	 */
	public void setValue(double value) {
		range.setProperty(PROP_VALUE, new Variant(value));
	}

	/**
	 * Sets the value of this range
	 * 
	 * @param value
	 *            the value of this range
	 */
	public void setValue(float value) {
		range.setProperty(PROP_VALUE, new Variant(value));
	}

	/**
	 * Returns the int value of this range
	 * 
	 * @return the int value of this range
	 */
	public int getIntValue() {
		return range.getProperty(PROP_VALUE).getInt();
	}

	/**
	 * Returns the long value of this range
	 * 
	 * @return the long value of this range
	 */
	public long getLongValue() {
		return range.getProperty(PROP_VALUE).getLong();
	}

	/**
	 * Returns the string value of this range
	 * 
	 * @return the string value of this range
	 */
	public String getStringValue() {
		return range.getProperty(PROP_VALUE).getString();
	}

	/**
	 * Returns the double value of this range
	 * 
	 * @return the double value of this range
	 */
	public double getDoubleValue() {
		return range.getProperty(PROP_VALUE).getDouble();
	}

	/**
	 * Returns the float value of this range
	 * 
	 * @return the float value of this range
	 */
	public float getFloatValue() {
		return range.getProperty(PROP_VALUE).getFloat();
	}

	/**
	 * Selects this range in the worksheet.
	 */
	public void select() {
		System.out.println(range.invoke(RANGE_SELECT));
	}

	/**
	 * Returns the name of this range or <code>null</code> if this range
	 * doesn't have a name.
	 * 
	 * @return the name of this range or <code>null</code> if this range
	 *         doesn't have a name.
	 */
	public String getName() {
		Variant nameObjectVariant = range.getProperty(RANGE_NAME);
		if (nameObjectVariant == null) {
			return null;
		}
		OleAutomation nameObject = nameObjectVariant.getAutomation();
		Variant name = nameObject.getProperty(RANGE_NAME_NAME);
		return name == null ? null : name.getString();
	}

	/**
	 * Returns the worksheet of this range
	 * 
	 * @return the worksheet of this range
	 */
	public Worksheet getWorksheet() {
		return worksheet;
	}

	/**
	 * 
	 * Returns: Worksheet!Name[Address]
	 * 
	 * @return Worksheet!Name[Address]
	 */
	@Override
	public String toString() {
		return String.format("%s!%s[%s]", worksheet.getName(), getName() != null ? getName() : getAddress(), range
				.getProperty(PROP_VALUE));
	}

}
