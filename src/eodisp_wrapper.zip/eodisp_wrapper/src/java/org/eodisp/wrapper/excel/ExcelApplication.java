/**
 * 
 */
package org.eodisp.wrapper.excel;

import java.io.File;
import java.io.IOException;

import org.eclipse.swt.SWT;
import org.eclipse.swt.ole.win32.OLE;
import org.eclipse.swt.ole.win32.OleAutomation;
import org.eclipse.swt.ole.win32.OleControlSite;
import org.eclipse.swt.ole.win32.OleFrame;
import org.eclipse.swt.ole.win32.Variant;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

/**
 * Represents the Excel Application.
 * 
 * Usage:
 * 
 * <pre>
 * Display display = new Display();
 * Shell shell = new Shell(display);
 * ExcelApplication excelApplication = new ExcelApplication(shell);
 * excelApplication.setVisible(true);
 * while (!shell.isDisposed()) {
 *     if (!display.readAndDispatch())
 * 	display.sleep();
 * }
 * display.dispose();
 * </pre>
 * 
 * @author ibirrer
 */
public class ExcelApplication {
	private static final int WORKBOOK_APPLICATION = 0x00000094;

	private static final int WORKBOOK_CLOSE = 0x00000115;

	private static final int APPLICATION_WORKBOOKS = 0x0000023c;

	private static final int APPLICATION_QUIT = 0x0000012e;

	private static final int WORKBOOKS_OPEN = 0x00000783;

	private static final int WORKBOOKS_COUNT = 0x00000076;

	static final int APPLICATION_VISIBLE = 0x0000022e;

	public static final int USER_SPECIFIED_UPDATE_LINKS = 1;

	public static final int NEVER_UPDATE_LINKS = 2;

	public static final int ALWAYS_UPDATE_LINKS = 3;

	private final OleControlSite controlSite;

	private final OleAutomation application;

	private final OleAutomation workbooks;

	public ExcelApplication(Shell shell) {
		OleFrame frame = new OleFrame(shell, SWT.NONE);
		controlSite = new OleControlSite(frame, SWT.NONE, "Excel.Sheet");
		controlSite.doVerb(OLE.OLEIVERB_HIDE);
		OleAutomation excelSheet = new OleAutomation(controlSite);

		Variant applicationVariant = excelSheet.getProperty(WORKBOOK_APPLICATION);
		application = applicationVariant.getAutomation();

		Variant workbookInMainVariant = application.getProperty(APPLICATION_WORKBOOKS, new Variant[] { new Variant(
				"Worksheet in main") });
		if (workbookInMainVariant != null) {
			OleAutomation workbookInMain = workbookInMainVariant.getAutomation();
			workbookInMain.invoke(WORKBOOK_CLOSE, new Variant[] { new Variant(false) });
		}

		Variant workbooksVariant = application.getProperty(APPLICATION_WORKBOOKS);
		workbooks = workbooksVariant.getAutomation();
	}

	/**
	 * Returns the number of workbooks open in this Excel Application.
	 * 
	 * @return the number of workbooks open in this Excel Application.
	 */
	public long getNrOfWorkbooks() {
		Variant workbookVariant = workbooks.getProperty(WORKBOOKS_COUNT);
		return workbookVariant.getLong();
	}

	/**
	 * Opens a workbook.
	 * 
	 * @param file
	 *            the workbook to open
	 * @return the opened workbook.
	 * @throws IOException
	 *             if the workbook could not be opened
	 */
	public Workbook openWorkbook(File file) throws IOException {
		Variant[] arguments = new Variant[] { new Variant(file.getPath()) };
		return openWorkbook(arguments);
	}

	/**
	 * Opens a workbook.
	 * 
	 * @param file
	 *            the workbook to open
	 * @param updateLinks
	 *            if Excel links shall be updated at loading time
	 * @param readOnly
	 *            if the workbook shall be loaded as read-only.
	 * @return the workbook
	 * @throws IOException
	 *             if the workbook could not be opened
	 */
	public Workbook openWorkbook(File file, int updateLinks, boolean readOnly) throws IOException {
		String fileToOpen = file.getAbsolutePath();
		Variant[] arguments = new Variant[] { new Variant(fileToOpen), new Variant(updateLinks), new Variant(readOnly) };
		return openWorkbook(arguments);
	}

	private Workbook openWorkbook(Variant[] arguments) throws IOException {
		Variant workbookVariant = workbooks.invoke(WORKBOOKS_OPEN, arguments);
		if (workbookVariant == null) {
			throw new IOException(String.format("Could not open workbook '%s'", arguments[0].getString()));
		} else if (workbookVariant.getType() == OLE.VT_EMPTY) {
			throw new IOException(String.format("Could not open workbook '%s'", arguments[0].getString()));
		}
		System.out.println(workbookVariant.getType());
		OleAutomation workbook = workbookVariant.getAutomation();
		return new Workbook(workbook, this);
	}

	/**
	 * Toggle the visibility of the application's main window.
	 * 
	 * @param visible
	 *            <code>true</code> to set it visible
	 */
	public void setVisible(boolean visible) {
		application.setProperty(APPLICATION_VISIBLE, new Variant(visible));
	}

	OleControlSite getControlSite() {
		return controlSite;
	}

	/**
	 * For testing only
	 * 
	 * @param args
	 *            command line args
	 */
	public static void main(String[] args) {
		Display display = new Display();
		Shell shell = new Shell(display);
		ExcelApplication excelApplication = new ExcelApplication(shell);
		excelApplication.setVisible(true);
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

	/**
	 * Quit the Excel application.
	 */
	public void quit() {
		application.invoke(APPLICATION_QUIT);
		workbooks.dispose();
		application.dispose();
	}

	/**
	 * Returns the ole automation object of the Excel Application.
	 * 
	 * @return the ole automation object of the Excel Application.
	 */
	public OleAutomation getAutomation() {
		return application;
	}
}
