package org.eodisp.wrapper.hla;

import hla.rti1516.LogicalTimeInterval;

/**
 * An immutable long-valued logical time interval.
 * 
 * @author Andrzej Kapolka
 */

public class LongValuedLogicalTimeInterval implements LogicalTimeInterval {
	/**
	 * The value of this logical time interval.
	 */
	private long value;

	/**
	 * Creates a new <code>XRTILogicalTimeInterval</code>.
	 * 
	 * @param pValue
	 *            the value of the logical time interval
	 */
	public LongValuedLogicalTimeInterval(long pValue) {
		value = pValue;
	}

	/**
	 * Returns the value of this time interval.
	 * 
	 * @return the value of this time interval
	 */
	public long getValue() {
		return value;
	}

	/**
	 * Checks whether this logical time interval has a zero length.
	 * 
	 * @return <code>true</code> if this logical time interval has a zero
	 *         length, <code>false</code> otherwise
	 */
	public boolean isZero() {
		return (value == 0);
	}

	/**
	 * Checks whether this logical time interval has an epsilon length.
	 * 
	 * @return <code>true</code> if this logical time interval has an epsilon
	 *         length, <code>false</code> otherwise
	 */
	public boolean isEpsilon() {
		return (value == 1);
	}

	/**
	 * Subtracts the specified logical time interval from this one, returning a
	 * new <code>LogicalTimeInterval</code> representing the result.
	 * 
	 * @param subtrahend
	 *            the logical time interval to subtract from this one
	 * @return a new <code>LogicalTimeInterval</code> representing the result
	 *         of the operation
	 */
	public LogicalTimeInterval subtract(LogicalTimeInterval subtrahend) {
		return new LongValuedLogicalTimeInterval(value - ((LongValuedLogicalTimeInterval) subtrahend).value);
	}

	/**
	 * Compares this logical time interval to another.
	 * 
	 * @param other
	 *            the <code>LogicalTimeInterval</code> to compare this to
	 * @return <code>+1</code> if this logical time interval is longer than
	 *         the other, <code>-1</code> if it is shorter, or <code>0</code>
	 *         if the two intervals are the same length
	 */
	public int compareTo(Object other) {
		long otherValue = ((LongValuedLogicalTimeInterval) other).value;

		if (value > otherValue) {
			return +1;
		} else if (value < otherValue) {
			return -1;
		} else {
			return 0;
		}
	}

	/**
	 * Checks this logical time interval for equality with another.
	 * 
	 * @param other
	 *            the <code>LogicalTimeInterval</code> to compare this to
	 * @return <code>true</code> if the two intervals are equal,
	 *         <code>false</code> otherwise
	 */
	public boolean equals(Object other) {
		try {
			return (value == ((LongValuedLogicalTimeInterval) other).value);
		} catch (ClassCastException cce) {
			return false;
		}
	}

	/**
	 * Computes and returns a hash code corresponding to this logical time
	 * interval.
	 * 
	 * @return a hash code corresponding to this logical time interval
	 */
	public int hashCode() {
		return (int) value;
	}

	/**
	 * Returns a string representation of this logical time interval.
	 * 
	 * @return a string representation of this logical time interval
	 */
	public String toString() {
		return Long.toString(value);
	}

	/**
	 * Returns the encoded length of this logical time interval.
	 * 
	 * @return the encoded length of this logical time interval (in bytes)
	 */
	public int encodedLength() {
		return 8;
	}

	/**
	 * Encodes this logical time interval, placing the result into the specified
	 * buffer.
	 * 
	 * @param buffer
	 *            the buffer in which to place the encoded interval
	 * @param offset
	 *            the offset within the buffer at which to store the encoded
	 *            interval
	 */
	public void encode(byte[] buffer, int offset) {
		byte[] encodedValue = EncodingHelpers.encodeLong(value);

		System.arraycopy(encodedValue, 0, buffer, offset, encodedValue.length);
	}
}
