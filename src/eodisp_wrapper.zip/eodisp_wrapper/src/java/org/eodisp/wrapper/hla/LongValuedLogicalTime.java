package org.eodisp.wrapper.hla;

import hla.rti1516.IllegalTimeArithmetic;
import hla.rti1516.LogicalTime;
import hla.rti1516.LogicalTimeInterval;

/**
 * An immutable long-valued logical time value.
 * 
 * @author Andrzej Kapolka
 */

public class LongValuedLogicalTime implements LogicalTime {
	/**
	 * The value of this logical time.
	 */
	private long value;

	/**
	 * Creates a new <code>XRTILogicalTime</code>.
	 * 
	 * @param pValue
	 *            the value of the logical time
	 */
	public LongValuedLogicalTime(long pValue) {
		value = pValue;
	}

	/**
	 * Checks whether this represents an initial time.
	 * 
	 * @return <code>true</code> if this represents an initial time,
	 *         <code>false</code> otherwise
	 */
	public boolean isInitial() {
		return (value == 0);
	}

	/**
	 * Checks whether this represents a final time.
	 * 
	 * @return <code>true</code> if this represents a final time,
	 *         <code>false</code> otherwise
	 */
	public boolean isFinal() {
		return (value == Long.MAX_VALUE);
	}

	/**
	 * Adds the specified time interval to this logical time, returning the
	 * result as a new <code>LogicalTime</code>.
	 * 
	 * @param val
	 *            the time interval to add to this logical time
	 * @return a new <code>LogicalTime</code> that represents this logical
	 *         time plus the specified time interval
	 * @exception IllegalTimeArithmetic
	 *                if the operation cannot be performed
	 */
	public LogicalTime add(LogicalTimeInterval val) throws IllegalTimeArithmetic {
		long intervalValue = ((LongValuedLogicalTimeInterval) val).getValue(), newValue = value + intervalValue;

		if (newValue < 0) {
			throw new IllegalTimeArithmetic("attempted to create logical time greater than maximum");
		} else {
			return new LongValuedLogicalTime(newValue);
		}
	}

	/**
	 * Subtracts the specified time interval from this logical time, returning
	 * the result as a new <code>LogicalTime</code>.
	 * 
	 * @param val
	 *            the time interval to subtract from this logical time
	 * @return a new <code>LogicalTime</code> that represents this logical
	 *         time minus the specified time interval
	 * @exception IllegalTimeArithmetic
	 *                if the operation cannot be performed
	 */
	public LogicalTime subtract(LogicalTimeInterval val) throws IllegalTimeArithmetic {
		long intervalValue = ((LongValuedLogicalTimeInterval) val).getValue(), newValue = value - intervalValue;

		if (newValue < 0) {
			throw new IllegalTimeArithmetic("attempted to create logical time less than zero");
		} else {
			return new LongValuedLogicalTime(newValue);
		}
	}

	/**
	 * Computes and returns the time interval between this logical time and
	 * another one.
	 * 
	 * @param val
	 *            the other logical time
	 * @return the logical time interval between this logical time and the other
	 *         logical time
	 */
	public LogicalTimeInterval distance(LogicalTime val) {
		return new LongValuedLogicalTimeInterval(Math.abs(value - ((LongValuedLogicalTime) val).value));
	}

	/**
	 * Compares this logical time to another.
	 * 
	 * @param other
	 *            the logical time to compare this to
	 * @return <code>+1</code> if this logical time is greater than the other
	 *         one, <code>-1</code> if this logical time is less than the
	 *         other one, <code>0</code> if the two logical times are equal
	 */
	public int compareTo(Object other) {
		long otherValue = ((LongValuedLogicalTime) other).value;

		if (value > otherValue) {
			return +1;
		} else if (value < otherValue) {
			return -1;
		} else {
			return 0;
		}
	}

	/**
	 * Checks this logical time for equality with another.
	 * 
	 * @param other
	 *            the other logical time to compare this to
	 * @return <code>true</code> if the other object represents the same
	 *         logical time as this one, <code>false</code> otherwise
	 */
	public boolean equals(Object other) {
		try {
			return (value == ((LongValuedLogicalTime) other).value);
		} catch (ClassCastException cce) {
			return false;
		}
	}

	/**
	 * Computes and returns a hash code corresponding to this logical time.
	 * 
	 * @return a hash code corresponding to this logical time
	 */
	public int hashCode() {
		return (int) value;
	}

	/**
	 * Returns a string representation of this logical time.
	 * 
	 * @return a string representation of this logical time
	 */
	public String toString() {
		return Long.toString(value);
	}

	/**
	 * Returns the encoded length of this logical time.
	 * 
	 * @return the encoded length of this logical time (in bytes)
	 */
	public int encodedLength() {
		return 8;
	}

	/**
	 * Encodes this logical time, placing the result into the specified buffer.
	 * 
	 * @param buffer
	 *            the buffer in which to place the result
	 * @param offset
	 *            the offset within the buffer at which to store the encoded
	 *            value
	 */
	public void encode(byte[] buffer, int offset) {
		byte[] encodedValue = EncodingHelpers.encodeLong(value);

		System.arraycopy(encodedValue, 0, buffer, offset, encodedValue.length);
	}
}