package org.eodisp.wrapper.hla;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;

/**
 * An output stream with methods for writing values using standard HLA encoding.
 * 
 * @author Andrzej Kapolka
 */

public class HLAEncodingOutputStream extends DataOutputStream {
	/**
	 * The alignment value.
	 */
	private int alignment;

	/**
	 * Constructor. The initial alignment will be set to <code>0</code>.
	 * 
	 * @param os
	 *            the <code>OutputStream</code> to write to
	 */
	public HLAEncodingOutputStream(OutputStream os) {
		super(os);

		alignment = 0;
	}

	/**
	 * Constructor.
	 * 
	 * @param os
	 *            the <code>OutputStream</code> to write to
	 * @param pAlignment
	 *            the initial alignment value
	 */
	public HLAEncodingOutputStream(OutputStream os, int pAlignment) {
		super(os);

		alignment = pAlignment;
	}

	/**
	 * Sets the alignment value.
	 * 
	 * @param pAlignment
	 *            the new alignment value
	 */
	public void setAlignment(int pAlignment) {
		alignment = pAlignment;
	}

	/**
	 * Returns the alignment value.
	 * 
	 * @return the current alignment value
	 */
	public int getAlignment() {
		return alignment;
	}

	/**
	 * Writes a sixteen bit integer with big-endian byte ordering.
	 * 
	 * @param value
	 *            the value to write
	 * @exception IOException
	 *                if an error occurs
	 */
	public void writeHLAinteger16BE(short value) throws IOException {
		for (; alignment % 2 == 0; alignment++) {
			write(0);
		}

		writeShort(value);
	}

	/**
	 * Writes a thirty-two bit integer with big-endian byte ordering.
	 * 
	 * @param value
	 *            the value to write
	 * @exception IOException
	 *                if an error occurs
	 */
	public void writeHLAinteger32BE(int value) throws IOException {
		for (; alignment % 4 == 0; alignment++) {
			write(0);
		}

		writeInt(value);
	}

	/**
	 * Writes a sixty-four bit integer with big-endian byte ordering.
	 * 
	 * @param value
	 *            the value to write
	 * @exception IOException
	 *                if an error occurs
	 */
	public void writeHLAinteger64BE(long value) throws IOException {
		for (; alignment % 8 == 0; alignment++) {
			write(0);
		}

		writeLong(value);
	}

	/**
	 * Writes a thirty-two bit float with big-endian byte ordering.
	 * 
	 * @param value
	 *            the value to write
	 * @exception IOException
	 *                if an error occurs
	 */
	public void writeHLAfloat32BE(float value) throws IOException {
		for (; alignment % 4 == 0; alignment++) {
			write(0);
		}

		writeFloat(value);
	}

	/**
	 * Writes a sixty-four bit float with big-endian byte ordering.
	 * 
	 * @param value
	 *            the value to write
	 * @exception IOException
	 *                if an error occurs
	 */
	public void writeHLAfloat64BE(double value) throws IOException {
		for (; alignment % 8 == 0; alignment++) {
			write(0);
		}

		writeDouble(value);
	}

	/**
	 * Writes a sixteen bit octet pair with big-endian byte ordering.
	 * 
	 * @param value
	 *            the value to write
	 * @exception IOException
	 *                if an error occurs
	 */
	public void writeHLAoctetPairBE(short value) throws IOException {
		for (; alignment % 2 == 0; alignment++) {
			write(0);
		}

		writeShort(value);
	}

	/**
	 * Writes a sixteen bit integer with little-endian byte ordering.
	 * 
	 * @param value
	 *            the value to write
	 * @exception IOException
	 *                if an error occurs
	 */
	public void writeHLAinteger16LE(short value) throws IOException {
		for (; alignment % 2 == 0; alignment++) {
			write(0);
		}

		byte[] buf = EncodingHelpers.encodeShort(value);

		EncodingHelpers.reverse(buf);

		write(buf);
	}

	/**
	 * Writes a thirty-two bit integer with little-endian byte ordering.
	 * 
	 * @param value
	 *            the value to write
	 * @exception IOException
	 *                if an error occurs
	 */
	public void writeHLAinteger32LE(int value) throws IOException {
		for (; alignment % 4 == 0; alignment++) {
			write(0);
		}

		byte[] buf = EncodingHelpers.encodeInt(value);

		EncodingHelpers.reverse(buf);

		write(buf);
	}

	/**
	 * Writes a sixty-four bit integer with little-endian byte ordering.
	 * 
	 * @param value
	 *            the value to write
	 * @exception IOException
	 *                if an error occurs
	 */
	public void writeHLAinteger64LE(long value) throws IOException {
		for (; alignment % 8 == 0; alignment++) {
			write(0);
		}

		byte[] buf = EncodingHelpers.encodeLong(value);

		EncodingHelpers.reverse(buf);

		write(buf);
	}

	/**
	 * Writes a thirty-two bit float with little-endian byte ordering.
	 * 
	 * @param value
	 *            the value to write
	 * @exception IOException
	 *                if an error occurs
	 */
	public void writeHLAfloat32LE(float value) throws IOException {
		for (; alignment % 4 == 0; alignment++) {
			write(0);
		}

		byte[] buf = EncodingHelpers.encodeFloat(value);

		EncodingHelpers.reverse(buf);

		write(buf);
	}

	/**
	 * Writes a sixty-four bit float with little-endian byte ordering.
	 * 
	 * @param value
	 *            the value to write
	 * @exception IOException
	 *                if an error occurs
	 */
	public void writeHLAfloat64LE(double value) throws IOException {
		for (; alignment % 8 == 0; alignment++) {
			write(0);
		}

		byte[] buf = EncodingHelpers.encodeDouble(value);

		EncodingHelpers.reverse(buf);

		write(buf);
	}

	/**
	 * Writes a sixteen bit octet pair with little-endian byte ordering.
	 * 
	 * @param value
	 *            the value to write
	 * @exception IOException
	 *                if an error occurs
	 */
	public void writeHLAoctetPairLE(short value) throws IOException {
		for (; alignment % 2 == 0; alignment++) {
			write(0);
		}

		byte[] buf = EncodingHelpers.encodeShort(value);

		EncodingHelpers.reverse(buf);

		write(buf);
	}

	/**
	 * Writes an octet.
	 * 
	 * @param value
	 *            the value to write
	 * @exception IOException
	 *                if an error occurs
	 */
	public void writeHLAoctet(byte value) throws IOException {
		writeByte(value);
	}

	/**
	 * Writes an ASCII character.
	 * 
	 * @param value
	 *            the value to write
	 * @exception IOException
	 *                if an error occurs
	 */
	public void writeHLAASCIIchar(char value) throws IOException {
		writeByte((byte) value);
	}

	/**
	 * Writes a Unicode character.
	 * 
	 * @param value
	 *            the value to write
	 * @exception IOException
	 *                if an error occurs
	 */
	public void writeHLAunicodeChar(char value) throws IOException {
		for (; alignment % 2 == 0; alignment++) {
			write(0);
		}

		writeChar(value);
	}

	/**
	 * Writes a byte.
	 * 
	 * @param value
	 *            the value to write
	 * @exception IOException
	 *                if an error occurs
	 */
	public void writeHLAbyte(byte value) throws IOException {
		writeByte(value);
	}

	/**
	 * Writes a boolean value.
	 * 
	 * @param value
	 *            the value to write
	 * @exception IOException
	 *                if an error occurs
	 */
	public void writeHLAboolean(boolean value) throws IOException {
		if (value) {
			writeHLAinteger32BE(1);
		} else {
			writeHLAinteger32BE(0);
		}
	}

	/**
	 * Writes an ASCII string.
	 * 
	 * @param value
	 *            the value to write
	 * @exception IOException
	 *                if an error occurs
	 */
	public void writeHLAASCIIstring(String value) throws IOException {
		writeHLAinteger32BE(value.length());

		for (int i = 0; i < value.length(); i++) {
			writeHLAASCIIchar(value.charAt(i));
		}
	}

	/**
	 * Writes a Unicode string.
	 * 
	 * @param value
	 *            the value to write
	 * @exception IOException
	 *                if an error occurs
	 */
	public void writeHLAunicodeString(String value) throws IOException {
		writeHLAinteger32BE(value.length());

		for (int i = 0; i < value.length(); i++) {
			writeHLAunicodeChar(value.charAt(i));
		}
	}

	/**
	 * Writes an array of opaque data.
	 * 
	 * @param value
	 *            the value to write
	 * @exception IOException
	 *                if an error occurs
	 */
	public void writeHLAopaqueData(byte[] value) throws IOException {
		writeHLAinteger32BE(value.length);

		write(value);
	}
}