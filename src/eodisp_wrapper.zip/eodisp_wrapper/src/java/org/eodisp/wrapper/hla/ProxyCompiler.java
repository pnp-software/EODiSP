package org.eodisp.wrapper.hla;

import hla.rti1516.CouldNotOpenFDD;
import hla.rti1516.ErrorReadingFDD;

import java.io.*;
import java.util.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.*;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * Generates a set of classes suitable to implement a federate that corresponds
 * to a given HLA SOM document. May be invoked as a command line application or
 * by using the static <code>compileProxies</code> method (from within an Ant
 * task, for instance).
 * <p>
 * Adapted from the XRTI proxy compiler.
 * 
 * @author Andrzej Kapolka
 * @author Iwan Birrer
 */

public class ProxyCompiler {
	/**
	 * The target directory command line argument.
	 */
	private static final String TARGET_DIRECTORY = "targetdirectory";

	/**
	 * The package prefix command line argument.
	 */
	private static final String PACKAGE_PREFIX = "packageprefix";

	/**
	 * The proxy ambassador name command line argument.
	 */
	private static final String PROXY_AMBASSADOR_NAME = "proxyambassadorname";

	/**
	 * superclass command line argument
	 */
	private static final String PROXY_AMBASSADOR_SUPER_CLASS = "federatesuperclass";

	/**
	 * The interaction listener name command line argument.
	 */
	private static final String INTERACTION_LISTENER_NAME = "interactionlistenername";

	/**
	 * The help command line argument.
	 */
	private static final String HELP = "help";

	/**
	 * The simple data type element.
	 */
	private static final String SIMPLE_DATA = "simpleData";

	/**
	 * The array data type element.
	 */
	private static final String ARRAY_DATA = "arrayData";

	/**
	 * The enumerated data type element.
	 */
	private static final String ENUMERATED_DATA = "enumeratedData";

	/**
	 * The enumerator element.
	 */
	private static final String ENUMERATOR = "enumerator";

	/**
	 * The fixed record data type element.
	 */
	private static final String FIXED_RECORD_DATA = "fixedRecordData";

	/**
	 * The variant record data type element.
	 */
	private static final String VARIANT_RECORD_DATA = "variantRecordData";

	/**
	 * The field element.
	 */
	private static final String FIELD = "field";

	/**
	 * The alternative element.
	 */
	private static final String ALTERNATIVE = "alternative";

	/**
	 * The objects element.
	 */
	private static final String OBJECTS = "objects";

	/**
	 * The object class element.
	 */
	private static final String OBJECT_CLASS = "objectClass";

	/**
	 * The attribute element.
	 */
	private static final String ATTRIBUTE = "attribute";

	/**
	 * The interactions element.
	 */
	private static final String INTERACTIONS = "interactions";

	/**
	 * The interaction class element.
	 */
	private static final String INTERACTION_CLASS = "interactionClass";

	/**
	 * The parameter element.
	 */
	private static final String PARAMETER = "parameter";

	/**
	 * The name attribute.
	 */
	private static final String NAME = "name";

	/**
	 * The semantics attribute.
	 */
	private static final String SEMANTICS = "semantics";

	/**
	 * The representation attribute.
	 */
	private static final String REPRESENTATION = "representation";

	/**
	 * The values attribute.
	 */
	private static final String VALUES = "values";

	/**
	 * The data type attribute.
	 */
	private static final String DATA_TYPE = "dataType";

	/**
	 * The cardinality attribute.
	 */
	private static final String CARDINALITY = "cardinality";

	/**
	 * The encoding attribute.
	 */
	private static final String ENCODING = "encoding";

	/**
	 * The discriminant attribute.
	 */
	private static final String DISCRIMINANT = "discriminant";

	/**
	 * The parents attribute.
	 */
	private static final String PARENTS = "parents";

	/**
	 * The sharing attribute.
	 */
	private static final String SHARING = "sharing";

	/**
	 * The HLA fixed array encoding.
	 */
	private static final String HLA_FIXED_ARRAY = "HLAfixedArray";

	/**
	 * The HLA variable array encoding.
	 */
	private static final String HLA_VARIABLE_ARRAY = "HLAvariableArray";

	/**
	 * The HLA fixed record encoding.
	 */
	private static final String HLA_FIXED_RECORD = "HLAfixedRecord";

	/**
	 * The HLA variant record encoding.
	 */
	private static final String HLA_VARIANT_RECORD = "HLAvariantRecord";

	/**
	 * The publish type of sharing.
	 */
	private static final String PUBLISH = "Publish";

	/**
	 * The subscribe type of sharing.
	 */
	private static final String SUBSCRIBE = "Subscribe";

	/**
	 * The publish-and-subscribe type of sharing.
	 */
	private static final String PUBLISH_SUBSCRIBE = "PublishSubscribe";

	/**
	 * The neither type of sharing.
	 */
	private static final String NEITHER = "Neither";

	/**
	 * The federation description document.
	 */
	private File federationDescriptionDocument;

	/**
	 * The target directory.
	 */
	private File targetDirectory;

	/**
	 * The package prefix.
	 */
	private String packagePrefix;

	/**
	 * The superclass
	 */
	private String federateSuperClass = "ProxyAmbassador";

	/**
	 * The proxy ambassador name.
	 */
	private String proxyAmbassadorName;

	/**
	 * The interaction listener name.
	 */
	private String interactionListenerName;

	/**
	 * An internal class for information concerning array types.
	 */
	private class ArrayTypeInformation {
		/**
		 * The array data type.
		 */
		public String dataType;

		/**
		 * The array cardinality (-1 for "Dynamic").
		 */
		public int cardinality;
	}

	/**
	 * Maps simple type names to their representations.
	 */
	private HashMap<String, String> simpleTypeRepresentationMap;

	/**
	 * The set of opaque types: types that must be stored as byte arrays because
	 * their encodings are non-standard.
	 */
	private HashSet opaqueTypes;

	/**
	 * Maps array type names to <code>ArrayTypeInformation</code> objects.
	 */
	private HashMap arrayTypeInformationMap;

	/**
	 * Maps interaction classes names to their defining elements.
	 */
	private HashMap interactionClassElementMap;

	/**
	 * Maps object class names to their defining elements.
	 */
	private HashMap objectClassElementMap;

	/**
	 * The application entry point.
	 * 
	 * @param args
	 *            the command line arguments
	 */
	public static void main(String[] args) {
		ProxyCompiler pc = new ProxyCompiler();

		boolean showHelp = false;

		for (int i = 0; i < args.length; i++) {
			if (args[i].charAt(0) == '-') {
				String argument = args[i].substring(1);

				if (argument.equalsIgnoreCase(TARGET_DIRECTORY)) {
					if ((i + 1) == args.length || args[i + 1].charAt(0) == '-') {
						System.err.println("Missing parameter for -" + TARGET_DIRECTORY);
					} else {
						pc.setTargetDirectory(new File(args[i + 1]));

						i++;
					}
				} else if (argument.equalsIgnoreCase(PACKAGE_PREFIX)) {
					if ((i + 1) == args.length || args[i + 1].charAt(0) == '-') {
						System.err.println("Missing parameter for -" + PACKAGE_PREFIX);
					} else {
						pc.setPackagePrefix(args[i + 1]);

						i++;
					}
				} else if (argument.equalsIgnoreCase(PROXY_AMBASSADOR_NAME)) {
					if ((i + 1) == args.length || args[i + 1].charAt(0) == '-') {
						System.err.println("Missing parameter for -" + PROXY_AMBASSADOR_NAME);
					} else {
						pc.setProxyAmbassadorName(args[i + 1]);

						i++;
					}
				} else if (argument.equalsIgnoreCase(INTERACTION_LISTENER_NAME)) {
					if ((i + 1) == args.length || args[i + 1].charAt(0) == '-') {
						System.err.println("Missing parameter for -" + INTERACTION_LISTENER_NAME);
					} else {
						pc.setInteractionListenerName(args[i + 1]);

						i++;
					}
				} else if (argument.equalsIgnoreCase(PROXY_AMBASSADOR_SUPER_CLASS)) {
					if ((i + 1) == args.length || args[i + 1].charAt(0) == '-') {
						System.err.println("Missing parameter for -" + PROXY_AMBASSADOR_SUPER_CLASS);
					} else {
						pc.setProxyAmbassadorSuperclass(args[i + 1]);
						i++;
					}
				} else if (argument.equalsIgnoreCase(HELP)) {
					showHelp = true;
				} else {
					System.err.println("Unrecognized argument: -" + argument);
				}
			} else {
				pc.setFederationDescriptionDocument(new File(args[i]));
			}
		}

		if (showHelp || pc.getFederationDescriptionDocument() == null) {
			System.out.println("Usage: ProxyCompiler [-options] <SOM document path>");
			System.out.println("Where options include:");
			System.out.println("  -" + TARGET_DIRECTORY
					+ " <directory>     Specifies the target directory for source files");
			System.out.println("  -" + PACKAGE_PREFIX + " <prefix>          Specifies the package prefix");
			System.out.println("  -" + PROXY_AMBASSADOR_NAME + " <name>      Specifies the federate class name");
			System.out.println("  -" + PROXY_AMBASSADOR_SUPER_CLASS
					+ " <name>      Specifies the federate's super class (defaults to ProxyAmbassador)");
			System.out.println("  -" + INTERACTION_LISTENER_NAME
					+ " <name>     Specifies the interaction listener name");
			System.out.println("  -" + HELP + "                            Prints this message");

			if (pc.getFederationDescriptionDocument() == null) {
				return;
			}
		}

		try {
			pc.compileProxies();
		} catch (CouldNotOpenFDD cnof) {
			System.err.println("Couldn't open federation description document: " + cnof);
		} catch (ErrorReadingFDD erf) {
			System.err.println("Error reading federation description document: " + erf);
		} catch (TypeConflictException tce) {
			System.err.println("Error generating proxy classes: " + tce);
		}
	}

	/**
	 * Sets the location of the federation description document.
	 * 
	 * @param pFederationDescriptionDocument
	 *            the location of the federation description document
	 */
	public void setFederationDescriptionDocument(File pFederationDescriptionDocument) {
		federationDescriptionDocument = pFederationDescriptionDocument;
	}

	/**
	 * Returns the location of the federation description document.
	 * 
	 * @return the location of the federation description document
	 */
	public File getFederationDescriptionDocument() {
		return federationDescriptionDocument;
	}

	/**
	 * Sets the target directory in which to place generated source files.
	 * 
	 * @param pTargetDirectory
	 *            the target directory in which to place generated source files
	 */
	public void setTargetDirectory(File pTargetDirectory) {
		targetDirectory = pTargetDirectory;
	}

	/**
	 * Returns the target directory in which to place generated source files.
	 * 
	 * @return the target directory in which to place generated source files
	 */
	public File getTargetDirectory() {
		return targetDirectory;
	}

	/**
	 * Sets the package prefix.
	 * 
	 * @param pPackagePrefix
	 *            the package prefix
	 */
	public void setPackagePrefix(String pPackagePrefix) {
		packagePrefix = pPackagePrefix;
	}

	/**
	 * Returns the package prefix.
	 * 
	 * @return the package prefix
	 */
	public String getPackagePrefix() {
		return packagePrefix;
	}

	/**
	 * Sets the (unprefixed) name of the proxy ambassador class.
	 * 
	 * @param pProxyAmbassadorName
	 *            the (unprefixed) name of the proxy ambassador class
	 */
	public void setProxyAmbassadorName(String pProxyAmbassadorName) {
		proxyAmbassadorName = pProxyAmbassadorName;
	}

	/**
	 * Returns the (unprefixed) name of the proxy ambassador class.
	 * 
	 * @return the (unprefixed) name of the proxy ambassador class
	 */
	public String getProxyAmbassadorName() {
		return proxyAmbassadorName;
	}

	/**
	 * Sets the (unprefixed) name of the interaction listener interface.
	 * 
	 * @param pInteractionListenerName
	 *            the (unprefixed) name of the interaction listener interface
	 */
	public void setInteractionListenerName(String pInteractionListenerName) {
		interactionListenerName = pInteractionListenerName;
	}

	/**
	 * Sets the superclass or the generated federate class.
	 * 
	 * @param superclass
	 *            the superclass
	 */
	public void setProxyAmbassadorSuperclass(String superclass) {
		this.federateSuperClass = superclass;
	}

	/**
	 * Returns the (unprefixed) name of the interaction listener interface.
	 * 
	 * @return the (unprefixed) name of the interaction listener interface
	 */
	public String getInteractionListenerName() {
		return interactionListenerName;
	}

	/**
	 * Generates Java source code for a set of proxy classes corresponding to
	 * the object and interaction classes described in the federation
	 * description document. Any existing files will be overwritten.
	 * 
	 * @exception CouldNotOpenFDD
	 *                if the federation description document could not be opened
	 * @exception ErrorReadingFDD
	 *                if the federation description document is invalid
	 * @exception TypeConflictException
	 *                if a type conflict is encountered
	 */
	public void compileProxies() throws CouldNotOpenFDD, ErrorReadingFDD, TypeConflictException {
		Document fddDocument;

		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

			dbf.setNamespaceAware(true);

			DocumentBuilder db = dbf.newDocumentBuilder();

			fddDocument = db.parse(federationDescriptionDocument);
		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
			return;
		} catch (IOException ioe) {
			throw new CouldNotOpenFDD(ioe.toString());
		} catch (SAXException se) {
			throw new ErrorReadingFDD(se.toString());
		}

		if (targetDirectory == null) {
			targetDirectory = new File(".");
		}

		if (packagePrefix == null) {
			packagePrefix = "";
		} else if (!packagePrefix.endsWith(".")) {
			packagePrefix = packagePrefix + ".";
		}

		if (proxyAmbassadorName == null) {
			proxyAmbassadorName = convertToJavaClassName(fddDocument.getDocumentElement().getAttribute(NAME))
					+ "ProxyAmbassador";
		}

		if (interactionListenerName == null) {
			interactionListenerName = convertToJavaClassName(fddDocument.getDocumentElement().getAttribute(NAME))
					+ "InteractionListener";
		}

		generateDataTypes(fddDocument);

		generateProxyAmbassador(fddDocument);

		generateInteractionListener(fddDocument);

		generateObjectInstanceProxies(fddDocument);

		generatePasselClasses(fddDocument);

		generateObjectInstanceInterfaces(fddDocument);

		generateObjectInstanceListeners(fddDocument);

		generateObjectInstancePasselListeners(fddDocument);
	}

	/**
	 * Capitalizes the first letter of the specified string.
	 * 
	 * @param string
	 *            the string to capitalize
	 * @return the capitalized string
	 */
	private String capitalize(String string) {
		if (string.length() <= 1) {
			return string.toUpperCase();
		} else {
			return string.substring(0, 1).toUpperCase() + string.substring(1);
		}
	}

	/**
	 * Generates a string of the same length as the parameter, consisting only
	 * of space characters.
	 * 
	 * @param string
	 *            the string whose length is to be copied
	 * @return the space string
	 */
	private String spacer(String string) {
		int len = string.length();

		String spaces = "";

		for (int i = 0; i < len; i++) {
			spaces = spaces + " ";
		}

		return spaces;
	}

	/**
	 * Converts the specified free-form name to a reasonable Java class name by
	 * removing whitespace and illegal characters, modifying capitalization, and
	 * so on.
	 * 
	 * @param anyName
	 *            the free-form name to convert
	 * @return the converted name
	 */
	private String convertToJavaClassName(String anyName) {
		String className = "", token;
		StringTokenizer st = new StringTokenizer(anyName, "`~!@#$%^&*()-+=[{]}\\|;:'\",<.>/? \t\n\r\f");

		while (st.hasMoreTokens()) {
			className = className + capitalize(st.nextToken());
		}

		return className;
	}

	/**
	 * Converts the specified free-form name to a reasonable Java identifier by
	 * removing whitespace and illegal characters and so on.
	 * 
	 * @param anyName
	 *            the free-form name to convert
	 * @return the converted name
	 */
	private String convertToIdentifier(String anyName) {
		StringBuffer sb = new StringBuffer();

		if (anyName.length() == 0 || !Character.isJavaIdentifierStart(anyName.charAt(0))) {
			sb.append('_');
		}

		for (int i = 0; i < anyName.length(); i++) {
			char c = anyName.charAt(i);

			if (Character.isJavaIdentifierPart(c)) {
				sb.append(c);
			} else {
				sb.append('_');
			}
		}

		return sb.toString();
	}

	/**
	 * Returns the name of the package specified by the given fully qualified
	 * class name.
	 * 
	 * @param className
	 *            the fully qualified class name
	 * @return the package name, or <code>null</code> for the base package
	 */
	private String getPackageName(String className) {
		int index;

		if ((index = className.lastIndexOf('.')) == -1) {
			return null;
		} else {
			return className.substring(0, index);
		}
	}

	/**
	 * Generates an indentation string for the specified level of indentation.
	 * 
	 * @param indentLevel
	 *            the level of indentation desired
	 * @return the indentation string
	 */
	private String generateIndentString(int indentLevel) {
		String indent = "";

		for (int i = 0; i < indentLevel; i++) {
			indent = indent + "    ";
		}

		return indent;
	}

	/**
	 * Formats the body of a comment, adding asterisks at the beginning of each
	 * line.
	 * 
	 * @param indentLevel
	 *            the level of indentation required
	 * @param commentBody
	 *            the comment body to format
	 * @return the formatted body
	 */
	private String formatCommentBody(int indentLevel, String commentBody) {
		String formattedBody = "", formattedLinePrefix = generateIndentString(indentLevel) + " * ", formattedLine = formattedLinePrefix;

		StringTokenizer st = new StringTokenizer(commentBody);

		while (st.hasMoreTokens()) {
			formattedLine = formattedLine + st.nextToken();

			if (formattedLine.length() > 75) {
				formattedBody = formattedBody + formattedLine + System.getProperty("line.separator");

				formattedLine = formattedLinePrefix;
			} else {
				formattedLine = formattedLine + " ";
			}
		}

		if (formattedLine != formattedLinePrefix) {
			formattedBody = formattedBody + formattedLine + System.getProperty("line.separator");
		}

		return formattedBody;
	}

	/**
	 * Prints a Javadoc-style class comment.
	 * 
	 * @param ps
	 *            the print stream to write the comment to
	 * @param body
	 *            the body of the comment
	 */
	private void printClassComment(PrintStream ps, String body) {
		ps.println("/**");
		ps.print(formatCommentBody(0, body));
		ps.println(" *");
		ps.println(" * @author " + getClass().getName());
		ps.println(" */");
	}

	/**
	 * Prints a Javadoc-style variable comment.
	 * 
	 * @param ps
	 *            the print stream to write the comment to
	 * @param body
	 *            the body of the comment
	 */
	private void printVariableComment(PrintStream ps, String body) {
		ps.println("    /**");
		ps.print(formatCommentBody(1, body));
		ps.println("     */");
	}

	/**
	 * Returns the Java type name corresponding to the specified basic
	 * representation name.
	 * 
	 * @param basicRepresentationName
	 *            the basic representation name
	 * @return the corresponding Java type name
	 */
	private String javaTypeForBasicRepresentation(String basicRepresentationName) {
		if (basicRepresentationName == null) {
			return "byte[]";
		} else if (basicRepresentationName.equals("HLAinteger16BE") || basicRepresentationName.equals("HLAinteger16LE")) {
			return "short";
		} else if (basicRepresentationName.equals("HLAinteger32BE") || basicRepresentationName.equals("HLAinteger32LE")) {
			return "int";
		} else if (basicRepresentationName.equals("HLAinteger64BE") || basicRepresentationName.equals("HLAinteger64LE")) {
			return "long";
		} else if (basicRepresentationName.equals("HLAfloat32BE") || basicRepresentationName.equals("HLAfloat32LE")) {
			return "float";
		} else if (basicRepresentationName.equals("HLAfloat64BE") || basicRepresentationName.equals("HLAfloat64LE")) {
			return "double";
		} else if (basicRepresentationName.equals("HLAoctetPairBE") || basicRepresentationName.equals("HLAoctetPairLE")) {
			return "short";
		} else if (basicRepresentationName.equals("HLAoctet")) {
			return "byte";
		} else {
			return "byte[]";
		}
	}

	/**
	 * Returns the Java type name corresponding to the specified data type name.
	 * 
	 * @param dataTypeName
	 *            the data type name
	 * @return the corresponding Java type name
	 */
	private String javaTypeForDataType(String dataTypeName) {
		if (dataTypeName == null || dataTypeName.equals("HLAopaqueData") || opaqueTypes.contains(dataTypeName)) {
			return "byte[]";
		} else if (dataTypeName.equals("NA")) {
			return null;
		} else if (dataTypeName.equals("HLAASCIIchar") || dataTypeName.equals("HLAunicodeChar")) {
			return "char";
		} else if (dataTypeName.equals("HLAboolean")) {
			return "boolean";
		} else if (dataTypeName.equals("HLAASCIIstring") || dataTypeName.equals("HLAunicodeString")) {
			return "String";
		} else if (simpleTypeRepresentationMap.containsKey(dataTypeName)) {
			return javaTypeForBasicRepresentation((String) simpleTypeRepresentationMap.get(dataTypeName));
		} else if (arrayTypeInformationMap.containsKey(dataTypeName)) {
			ArrayTypeInformation ati = (ArrayTypeInformation) arrayTypeInformationMap.get(dataTypeName);

			return javaTypeForDataType(ati.dataType) + "[]";
		} else {
			return dataTypeName;
		}
	}

	/**
	 * Prints a code block that will serialize the specified variable to the
	 * given stream.
	 * 
	 * @param ps
	 *            the print stream to write the code block to
	 * @param indentLevel
	 *            the level of indentation to use
	 * @param iteratorVariable
	 *            the name of the iterator variable to use ('i', 'j', 'k'...)
	 * @param dataTypeName
	 *            the name of the variable's data type
	 * @param variableName
	 *            the name of the variable
	 * @param streamName
	 *            the name of the stream
	 */
	private void printSerializationBlock(PrintStream ps, int indentLevel, char iteratorVariable, String dataTypeName,
			String variableName) {
		if (simpleTypeRepresentationMap.containsKey(dataTypeName)) {
			dataTypeName = simpleTypeRepresentationMap.get(dataTypeName);
		}
		final String indentString = generateIndentString(indentLevel);
		if (dataTypeName.equals("HLAvariableArray") || dataTypeName.equals("HLAunicodeString")
				|| dataTypeName.equals("HLAunicodeChar") || dataTypeName.equals("HLAopaqueData")
				|| dataTypeName.equals("HLAoctetPairLE") || dataTypeName.equals("HLAoctetPairBE")
				|| dataTypeName.equals("HLAoctet") || dataTypeName.equals("HLAlogicalTime")
				|| dataTypeName.equals("HLAinteger64LE") || dataTypeName.equals("HLAinteger64BE")
				|| dataTypeName.equals("HLAinteger32LE") || dataTypeName.equals("HLAinteger32BE")
				|| dataTypeName.equals("HLAinteger16LE") || dataTypeName.equals("HLAinteger16BE")
				|| dataTypeName.equals("HLAhandle") || dataTypeName.equals("HLAfloat64LE")
				|| dataTypeName.equals("HLAfloat64BE") || dataTypeName.equals("HLAfloat32LE")
				|| dataTypeName.equals("HLAfloat32BE") || dataTypeName.equals("HLAfixedRecord")
				|| dataTypeName.equals("HLAbyte") || dataTypeName.equals("HLAboolean")
				|| dataTypeName.equals("HLAASCIIstring") || dataTypeName.equals("HLAASCIIchar")) {
			ps.printf("%1$s%2$s encoded = OmtEncoderFactory.getInstance().create%2$s(%3$s);%n", indentString,
					dataTypeName, variableName);
		} else {
			ps.printf("%sDataElement encoded = %s.encode();%n", indentString, variableName);
		}
	}

	/**
	 * Prints a code block that will deserialize the specified variable from the
	 * given stream.
	 * 
	 * @param ps
	 *            the print stream to write the code block to
	 * @param indentLevel
	 *            the level of indentation to use
	 * @param iteratorVariable
	 *            the name of the iterator variable to use ('i', 'j', 'k'...)
	 * @param dataTypeName
	 *            the name of the variable's data type
	 * @param variableName
	 *            the name of the variable
	 * @param streamName
	 *            the name of the stream
	 */
	private void printDeserializationBlock(PrintStream ps, int indentLevel, char iteratorVariable, String dataTypeName,
			String variableName) {

		if (simpleTypeRepresentationMap.containsKey(dataTypeName)) {
			dataTypeName = simpleTypeRepresentationMap.get(dataTypeName);
		}
		final String indentString = generateIndentString(indentLevel);
		if (dataTypeName.equals("HLAvariableArray") || dataTypeName.equals("HLAunicodeString")
				|| dataTypeName.equals("HLAunicodeChar") || dataTypeName.equals("HLAopaqueData")
				|| dataTypeName.equals("HLAoctetPairLE") || dataTypeName.equals("HLAoctetPairBE")
				|| dataTypeName.equals("HLAoctet") || dataTypeName.equals("HLAlogicalTime")
				|| dataTypeName.equals("HLAinteger64LE") || dataTypeName.equals("HLAinteger64BE")
				|| dataTypeName.equals("HLAinteger32LE") || dataTypeName.equals("HLAinteger32BE")
				|| dataTypeName.equals("HLAinteger16LE") || dataTypeName.equals("HLAinteger16BE")
				|| dataTypeName.equals("HLAhandle") || dataTypeName.equals("HLAfloat64LE")
				|| dataTypeName.equals("HLAfloat64BE") || dataTypeName.equals("HLAfloat32LE")
				|| dataTypeName.equals("HLAfloat32BE") || dataTypeName.equals("HLAfixedRecord")
				|| dataTypeName.equals("HLAbyte") || dataTypeName.equals("HLAboolean")
				|| dataTypeName.equals("HLAASCIIstring") || dataTypeName.equals("HLAASCIIchar")) {
			ps.printf("%sByteWrapper byteWrapper = new ByteWrapper(value);%n", indentString);
			ps.printf("%1$s%2$s dataElement =  OmtEncoderFactory.getInstance().create%2$s();%n", indentString,
					dataTypeName);
			ps.printf("%sdataElement.decode(byteWrapper);%n", indentString);
			ps.printf("%s%s = dataElement.getValue();%n", indentString, variableName);
		} else {
			ps.printf("%s%s = %s.decode(value);%n", indentString, variableName, dataTypeName);
			// ps.printf("%sDataElement encoded = %s.encode();%n", indentString,
			// variableName);
		}

		// if (dataTypeName == null || dataTypeName.equals("HLAopaqueData") ||
		// opaqueTypes.contains(dataTypeName)) {
		// ps.println(generateIndentString(indentLevel) + variableName + " = " +
		// streamName + ".readHLAopaqueData();");
		// } else if (dataTypeName.equals("NA")) {
		// return;
		// } else if (dataTypeName.equals("HLAASCIIchar") ||
		// dataTypeName.equals("HLAunicodeChar")
		// || dataTypeName.equals("HLAboolean") ||
		// dataTypeName.equals("HLAASCIIstring")
		// || dataTypeName.equals("HLAunicodeString")) {
		// ps.println(generateIndentString(indentLevel) + variableName + " = " +
		// streamName + ".read" + dataTypeName
		// + "();");
		// } else if (simpleTypeRepresentationMap.containsKey(dataTypeName)) {
		// String representation = (String)
		// simpleTypeRepresentationMap.get(dataTypeName);
		//
		// if (representation.equals("HLAinteger16BE") ||
		// representation.equals("HLAinteger32BE")
		// || representation.equals("HLAinteger64BE") ||
		// representation.equals("HLAfloat32BE")
		// || representation.equals("HLAfloat64BE") ||
		// representation.equals("HLAoctetPairBE")
		// || representation.equals("HLAinteger16LE") ||
		// representation.equals("HLAinteger32LE")
		// || representation.equals("HLAinteger64LE") ||
		// representation.equals("HLAfloat32LE")
		// || representation.equals("HLAfloat64LE") ||
		// representation.equals("HLAoctetPairLE")
		// || representation.equals("HLAoctet")) {
		// ps.println(generateIndentString(indentLevel) + variableName + " = " +
		// streamName + ".read"
		// + representation + "();");
		// } else {
		// ps.println(generateIndentString(indentLevel) + variableName + " = " +
		// streamName
		// + ".readHLAopaqueData();");
		// }
		// } else if (arrayTypeInformationMap.containsKey(dataTypeName)) {
		// ArrayTypeInformation ati = (ArrayTypeInformation)
		// arrayTypeInformationMap.get(dataTypeName);
		//
		// String javaType = javaTypeForDataType(dataTypeName), preBracket =
		// javaType.substring(0, javaType
		// .indexOf(']')), postBracket =
		// javaType.substring(javaType.indexOf(']'));
		//
		// if (ati.cardinality == -1) {
		// ps.println(generateIndentString(indentLevel) + variableName + " = new
		// " + preBracket + " " + streamName
		// + ".readHLAinteger32BE() " + postBracket + ";");
		//
		// ps.println();
		//
		// ps.println(generateIndentString(indentLevel) + "for(int " +
		// iteratorVariable + "=0;" + iteratorVariable
		// + "<" + variableName + ".length;" + iteratorVariable + "++)");
		// } else {
		// ps.println(generateIndentString(indentLevel) + variableName + " = new
		// " + preBracket + ati.cardinality
		// + postBracket + ";");
		//
		// ps.println();
		//
		// ps.println(generateIndentString(indentLevel) + "for(int " +
		// iteratorVariable + "=0;" + iteratorVariable
		// + "<" + ati.cardinality + ";" + iteratorVariable + "++)");
		// }
		//
		// ps.println(generateIndentString(indentLevel) + "{");
		//
		// printDeserializationBlock(ps, indentLevel + 1, (char)
		// (iteratorVariable + 1), ati.dataType, variableName
		// + "[" + iteratorVariable + "]", streamName);
		//
		// ps.println(generateIndentString(indentLevel) + "}");
		// } else {
		// ps.println(generateIndentString(indentLevel) + variableName + " = " +
		// dataTypeName + ".decode("
		// + streamName + ");");
		// }
	}

	/**
	 * Prints a code block that will initialize the specified variable to a
	 * default state.
	 * 
	 * @param ps
	 *            the print stream to write the code block to
	 * @param indentLevel
	 *            the level of indentation to use
	 * @param dataTypeName
	 *            the name of the variable's data type
	 * @param variableName
	 *            the name of the variable
	 */
	private void printInitToDefaultBlock(PrintStream ps, String dataTypeName, String variableName) {
		String javaType = javaTypeForDataType(dataTypeName);

		if (javaType != null && !javaType.equals("boolean") && !javaType.equals("byte") && !javaType.equals("char")
				&& !javaType.equals("double") && !javaType.equals("float") && !javaType.equals("int")
				&& !javaType.equals("long") && !javaType.equals("short")) {
			if (javaType.endsWith("[]")) {
				int index = javaType.indexOf('[') + 1;

				ps.println("        " + variableName + " = new " + javaType.substring(0, index) + "0"
						+ javaType.substring(index) + ";");
			} else {
				ps.println("        " + variableName + " = new " + javaType + "();");
			}
		}
	}

	/**
	 * Generates data type classes.
	 * 
	 * @param fddDocument
	 *            the parsed federation description document
	 */
	private void generateDataTypes(Document fddDocument) {
		Element rootElement = fddDocument.getDocumentElement();

		simpleTypeRepresentationMap = new HashMap();

		NodeList nl = rootElement.getElementsByTagName(SIMPLE_DATA);

		for (int i = 0; i < nl.getLength(); i++) {
			Element simpleDataElement = (Element) nl.item(i);

			simpleTypeRepresentationMap.put(simpleDataElement.getAttribute(NAME), simpleDataElement
					.getAttribute(REPRESENTATION));
		}

		opaqueTypes = new HashSet();

		arrayTypeInformationMap = new HashMap();

		nl = rootElement.getElementsByTagName(ARRAY_DATA);

		for (int i = 0; i < nl.getLength(); i++) {
			Element arrayDataElement = (Element) nl.item(i);

			if (arrayDataElement.getAttribute(ENCODING) == null
					|| arrayDataElement.getAttribute(ENCODING).equals(HLA_FIXED_ARRAY)
					|| arrayDataElement.getAttribute(ENCODING).equals(HLA_VARIABLE_ARRAY)) {
				ArrayTypeInformation ati = new ArrayTypeInformation();

				ati.dataType = arrayDataElement.getAttribute(DATA_TYPE);

				try {
					ati.cardinality = Integer.parseInt(arrayDataElement.getAttribute(CARDINALITY));
				} catch (NumberFormatException nfe) {
					ati.cardinality = -1;
				}

				arrayTypeInformationMap.put(arrayDataElement.getAttribute(NAME), ati);
			} else {
				opaqueTypes.add(arrayDataElement.getAttribute(NAME));
			}
		}

		nl = rootElement.getElementsByTagName(ENUMERATED_DATA);

		for (int i = 0; i < nl.getLength(); i++) {
			Element enumeratedDataElement = (Element) nl.item(i);

			if (!enumeratedDataElement.getAttribute(NAME).equals("HLAboolean")) {
				generateEnumeratedDataType((Element) nl.item(i));
			}
		}

		nl = rootElement.getElementsByTagName(FIXED_RECORD_DATA);

		for (int i = 0; i < nl.getLength(); i++) {
			Element fixedRecordDataElement = (Element) nl.item(i);

			if (!(fixedRecordDataElement.getAttribute(ENCODING) == null || fixedRecordDataElement
					.getAttribute(ENCODING).equals(HLA_FIXED_RECORD))) {
				opaqueTypes.add(fixedRecordDataElement.getAttribute(NAME));
			}
		}

		nl = rootElement.getElementsByTagName(VARIANT_RECORD_DATA);

		for (int i = 0; i < nl.getLength(); i++) {
			Element variantRecordDataElement = (Element) nl.item(i);

			if (!(variantRecordDataElement.getAttribute(ENCODING) == null || variantRecordDataElement.getAttribute(
					ENCODING).equals(HLA_VARIANT_RECORD))) {
				opaqueTypes.add(variantRecordDataElement.getAttribute(NAME));
			}
		}

		nl = rootElement.getElementsByTagName(FIXED_RECORD_DATA);

		for (int i = 0; i < nl.getLength(); i++) {
			Element fixedRecordDataElement = (Element) nl.item(i);

			if (fixedRecordDataElement.getAttribute(ENCODING) == null
					|| fixedRecordDataElement.getAttribute(ENCODING).equals(HLA_FIXED_RECORD)) {
				generateFixedRecordDataType(fixedRecordDataElement);
			}
		}

		nl = rootElement.getElementsByTagName(VARIANT_RECORD_DATA);

		for (int i = 0; i < nl.getLength(); i++) {
			Element variantRecordDataElement = (Element) nl.item(i);

			if (variantRecordDataElement.getAttribute(ENCODING) == null
					|| variantRecordDataElement.getAttribute(ENCODING).equals(HLA_VARIANT_RECORD)) {
				generateVariantRecordDataType(variantRecordDataElement);
			}
		}
	}

	/**
	 * Generates an enumerated data type class.
	 * 
	 * @param typeElement
	 *            the element containing the type description
	 */
	private void generateEnumeratedDataType(Element typeElement) {
		String typeName = typeElement.getAttribute(NAME), qualifiedTypeName = packagePrefix + typeName, path = qualifiedTypeName
				.replace('.', '/')
				+ ".java";

		File sourceFile = new File(targetDirectory, path);

		sourceFile.getParentFile().mkdirs();

		try {
			FileOutputStream fos = new FileOutputStream(sourceFile);
			PrintStream ps = new PrintStream(fos);

			String packageName = getPackageName(qualifiedTypeName);

			if (packageName != null) {
				ps.println("package " + packageName + ";");
				ps.println();
			}

			ps.println("import java.io.*;");
			ps.println("import hla.rti1516.jlc.*;");
			ps.println("import hla.rti1516.jlc.omt.*;");

			ps.println();
			ps.println("import org.eodisp.wrapper.hla.*;");
			ps.println();

			if (typeElement.hasAttribute(SEMANTICS)) {
				printClassComment(ps, typeElement.getAttribute(SEMANTICS));
			} else {
				printClassComment(ps, "Autogenerated enumerated data type.");
			}
			ps.println();

			ps.println("public class " + typeName + " implements Cloneable, Serializable");
			ps.println("{");

			NodeList nl = typeElement.getElementsByTagName(ENUMERATOR);

			for (int i = 0; i < nl.getLength(); i++) {
				Element enumeratorElement = (Element) nl.item(i);

				ps.println("    /**");
				ps.println("     * Enumerator #" + i + ".");
				ps.println("     */");
				ps.println("    public static final " + typeName + " "
						+ convertToIdentifier(enumeratorElement.getAttribute(NAME)) + " = new " + typeName + "("
						+ enumeratorElement.getAttribute(VALUES) + ");");
				ps.println();
			}

			String representation = typeElement.getAttribute(REPRESENTATION), javaType = javaTypeForBasicRepresentation(representation);

			ps.println("    /**");
			ps.println("     * The value of the instance.");
			ps.println("     */");
			ps.println("    private " + javaType + " value;");
			ps.println();
			ps.println();
			ps.println("    /**");
			ps.println("     * Reads and returns a " + typeName + " from the specified byte array");
			ps.println("     *");
			ps.println("     * @param value the byte array to read from");
			ps.println("     * @return the decoded value");
			ps.println("     */");
			ps.printf("    public static %s decode(byte[] value) {%n", typeName);
			ps.println("        ByteWrapper byteWrapper = new ByteWrapper(value);");
			ps.printf("        %1$s dataElement =  OmtEncoderFactory.getInstance().create%1$s();%n", representation);
			ps.println("        dataElement.decode(byteWrapper);");
			ps.printf("        return new %s(dataElement.getValue());%n", typeName);
			ps.println("    }");
			ps.println();

			if (representation.equals("HLAinteger32BE")) {
				ps.println("    /**");
				ps.println("     * Returns a " + typeName + " from the integer value");
				ps.println("     *");
				ps.println("     * @param value the byte array to read from");
				ps.println("     * @return the decoded value");
				ps.println("     */");
				ps.printf("    public static %s valueOf(int value) {%n", typeName);
				ps.println("        switch( value ) {");

				for (int i = 0; i < nl.getLength(); i++) {
					Element enumeratorElement = (Element) nl.item(i);
					ps.println("            case " + enumeratorElement.getAttribute(VALUES) + ":");
					ps.println("            return " + convertToIdentifier(enumeratorElement.getAttribute(NAME)) + ";");
				}
				ps.println("            default:");
				ps.println("            throw new IllegalArgumentException();");

				ps.println("        }");
				ps.println("    }");
				ps.println();
			}

			nl = typeElement.getElementsByTagName(ENUMERATOR);

			Element firstElement = (Element) nl.item(0);

			ps.println("    /**");
			ps.println("     * Default constructor (" + convertToIdentifier(firstElement.getAttribute(NAME)) + ").");
			ps.println("     */");
			ps.println("    public " + typeName + "()");
			ps.println("    {");
			ps.println("        value = " + convertToIdentifier(firstElement.getAttribute(NAME)) + ".value;");
			ps.println("    }");
			ps.println();

			ps.println("    /**");
			ps.println("     * Copy constructor.");
			ps.println("     *");
			ps.println("     * @param other the other " + typeName + " to copy");
			ps.println("     */");
			ps.println("    public " + typeName + "(" + typeName + " other)");
			ps.println("    {");
			ps.println("        value = other.value;");
			ps.println("    }");
			ps.println();

			ps.println("    /**");
			ps.println("     * Private constructor.");
			ps.println("     *");
			ps.println("     * @param pValue the instance value");
			ps.println("     */");
			ps.println("    private " + typeName + "(" + javaType + " pValue)");
			ps.println("    {");
			ps.println("        value = pValue;");
			ps.println("    }");
			ps.println();

			ps.println("    /**");
			ps.println("     * Compares this " + typeName + " for equality with another.");
			ps.println("     *");
			ps.println("     * @param other the other " + typeName);
			ps.println("     * @return <code>true</code> if the two enumerated types are equal,");
			ps.println("     * <code>false</code> otherwise");
			ps.println("     */");
			ps.println("    public boolean equals(Object other)");
			ps.println("    {");
			ps.println("        try");
			ps.println("        {");
			ps.println("            return ( value == ((" + typeName + ")other).value );");
			ps.println("        }");
			ps.println("        catch(ClassCastException cce)");
			ps.println("        {");
			ps.println("            return false;");
			ps.println("        }");
			ps.println("    }");
			ps.println();

			ps.println("    /**");
			ps.println("     * Computes and returns a hash code corresponding to this " + typeName + ".");
			ps.println("     *");
			ps.println("     * @return a hash code corresponding to this " + typeName);
			ps.println("     */");
			ps.println("    public int hashCode()");
			ps.println("    {");
			ps.println("        return " + (javaType.equals("int") ? "" : "(int)") + "value;");
			ps.println("    }");
			ps.println();

			ps.println("    /**");
			ps.println("     * Returns the HLA encoded value of this" + typeName + "");
			ps.println("     */");
			ps.printf("    public %s encode() {%n", representation);
			printSerializationBlock(ps, 2, 'i', representation, "value");
			ps.println("        return encoded;");
			ps.println("    }");
			ps.println();

			ps.println("    /**");
			ps.println("     * Returns a string representation of this " + typeName);
			ps.println("     *");
			ps.println("     * @return a string representation of this " + typeName);
			ps.println("     */");
			ps.println("    public String toString()");
			ps.println("    {");

			ps.println("        if( this.equals(" + convertToIdentifier(firstElement.getAttribute(NAME)) + ") )");
			ps.println("        {");
			ps.println("            return \"" + convertToIdentifier(firstElement.getAttribute(NAME)) + "\";");
			ps.println("        }");

			for (int i = 1; i < nl.getLength(); i++) {
				Element nextElement = (Element) nl.item(i);

				ps.println("        else if( this.equals(" + convertToIdentifier(nextElement.getAttribute(NAME))
						+ ") )");
				ps.println("        {");
				ps.println("            return \"" + convertToIdentifier(nextElement.getAttribute(NAME)) + "\";");
				ps.println("        }");
			}

			ps.println("        else");
			ps.println("        {");
			ps.println("            return \"" + typeName + " #\" + value;");
			ps.println("        }");
			ps.println("    }");

			ps.println("}");
		} catch (IOException ioe) {
			System.err.println("Error generating enumerated data type: " + ioe);
		}
	}

	/**
	 * Generates a fixed record data type class.
	 * 
	 * @param typeElement
	 *            the element containing the type description
	 */
	private void generateFixedRecordDataType(Element typeElement) {
		String typeName = typeElement.getAttribute(NAME), qualifiedTypeName = packagePrefix + typeName, path = qualifiedTypeName
				.replace('.', '/')
				+ ".java";

		File sourceFile = new File(targetDirectory, path);

		sourceFile.getParentFile().mkdirs();

		try {
			FileOutputStream fos = new FileOutputStream(sourceFile);
			PrintStream ps = new PrintStream(fos);

			String packageName = getPackageName(qualifiedTypeName);

			if (packageName != null) {
				ps.println("package " + packageName + ";");
				ps.println();
			}

			ps.println("import java.io.*;");
			ps.println("import hla.rti1516.jlc.*;");
			ps.println("import hla.rti1516.jlc.omt.*;");
			ps.println();
			ps.println("import org.eodisp.wrapper.hla.*;");
			ps.println();

			if (typeElement.hasAttribute(SEMANTICS)) {
				printClassComment(ps, typeElement.getAttribute(SEMANTICS));
			} else {
				printClassComment(ps, "Autogenerated fixed record data type.");
			}
			ps.println();

			ps.println("public class " + typeName + " implements Cloneable, Serializable");
			ps.println("{");

			NodeList nl = typeElement.getElementsByTagName(FIELD);

			for (int i = 0; i < nl.getLength(); i++) {
				Element fieldElement = (Element) nl.item(i);

				if (javaTypeForDataType(fieldElement.getAttribute(DATA_TYPE)) != null) {
					if (fieldElement.hasAttribute(SEMANTICS)) {
						printVariableComment(ps, fieldElement.getAttribute(SEMANTICS));
					} else {
						printVariableComment(ps, "Field #" + i + ".");
					}

					ps.println("    private " + javaTypeForDataType(fieldElement.getAttribute(DATA_TYPE)) + " "
							+ fieldElement.getAttribute(NAME) + ";");
					ps.println();
				}
			}

			ps.println();
			ps.println("    /**");
			ps.println("     * Reads and returns a " + typeName + " from the specified stream.");
			ps.println("     *");
			ps.println("     * @param hlaeis the input stream to read from");
			ps.println("     * @return the decoded value");
			ps.println("     * @exception IOException if an error occurs");
			ps.println("     */");
			ps.println("    public static " + typeName + " decode(byte[] encodedValue) throws IOException");
			ps.println("    {");
			ps.println("        " + typeName + " result = new " + typeName + "();");
			ps.println();
			ps.println("        // decoding");
			ps.println("        ByteWrapper encodedByteWrapper = new ByteWrapper(encodedValue);");
			ps
					.println("        HLAfixedRecord hlaFixedRecord = OmtEncoderFactory.getInstance().createHLAfixedRecord();");
			ps.println("        hlaFixedRecord.decode(encodedByteWrapper);");
			ps.println();

			nl = typeElement.getElementsByTagName(FIELD);

			for (int i = 0; i < nl.getLength(); i++) {
				Element field = (Element) nl.item(i);
				String fieldType = field.getAttribute(DATA_TYPE);
				final String fieldName = field.getAttribute(NAME);
				// ps.printf(" %s.%s =
				// ((%s)hlaFixedRecord.get(%d)).getValue();%n",typeName,
				// fieldName, fieldType, new Integer(i));
				printDeserializationBlock(ps, 2, 'i', fieldType, "result." + fieldName);

				// Element fieldElement = (Element) nl.item(i);
				//
				// if (javaTypeForDataType(fieldElement.getAttribute(DATA_TYPE))
				// != null) {
				// printDeserializationBlock(ps, 2, 'i',
				// fieldElement.getAttribute(DATA_TYPE), "value."
				// + fieldElement.getAttribute(NAME), "hlaeis");
				//
				// ps.println();
				// }
			}

			ps.println("        return result;");
			ps.println("    }");
			ps.println();

			ps.println("    /**");
			ps.println("     * Default constructor.");
			ps.println("     */");
			ps.println("    public " + typeName + "()");
			ps.println("    {");

			nl = typeElement.getElementsByTagName(FIELD);

			for (int i = 0; i < nl.getLength(); i++) {
				Element fieldElement = (Element) nl.item(i);

				printInitToDefaultBlock(ps, fieldElement.getAttribute(DATA_TYPE), fieldElement.getAttribute(NAME));
			}

			ps.println("    }");
			ps.println();

			ps.println("    /**");
			ps.println("     * Constructor.");
			ps.println("     *");

			for (int i = 0; i < nl.getLength(); i++) {
				Element fieldElement = (Element) nl.item(i);

				if (javaTypeForDataType(fieldElement.getAttribute(DATA_TYPE)) != null) {
					ps.println("     * @param p" + capitalize(fieldElement.getAttribute(NAME)) + " the value of the "
							+ fieldElement.getAttribute(NAME) + " field");
				}
			}

			ps.println("     */");
			ps.print("    public " + typeName + "(");

			boolean first = true;

			for (int i = 0; i < nl.getLength(); i++) {
				Element fieldElement = (Element) nl.item(i);

				String javaType = javaTypeForDataType(fieldElement.getAttribute(DATA_TYPE));

				if (javaType != null) {
					if (!first) {
						ps.print(", ");
					} else {
						first = false;
					}

					ps.print(javaType + " p" + capitalize(fieldElement.getAttribute(NAME)));
				}
			}

			ps.println(")");
			ps.println("    {");

			for (int i = 0; i < nl.getLength(); i++) {
				Element fieldElement = (Element) nl.item(i);

				String javaType = javaTypeForDataType(fieldElement.getAttribute(DATA_TYPE));

				if (javaTypeForDataType(fieldElement.getAttribute(DATA_TYPE)) != null) {
					ps.println("        " + fieldElement.getAttribute(NAME) + " = p"
							+ capitalize(fieldElement.getAttribute(NAME)) + ";");
				}
			}

			ps.println("    }");
			ps.println();

			ps.println("    /**");
			ps.println("     * Copy constructor.");
			ps.println("     *");
			ps.println("     * @param other the other " + typeName + " to copy");
			ps.println("     */");
			ps.println("    public " + typeName + "(" + typeName + " other)");
			ps.println("    {");

			for (int i = 0; i < nl.getLength(); i++) {
				Element fieldElement = (Element) nl.item(i);

				if (javaTypeForDataType(fieldElement.getAttribute(DATA_TYPE)) != null) {
					ps.println("        " + fieldElement.getAttribute(NAME) + " = other."
							+ fieldElement.getAttribute(NAME) + ";");
				}
			}

			ps.println("    }");
			ps.println();

			ps.println("    /**");
			ps.println("     * Writes this " + typeName + " to the specified stream.");
			ps.println("     *");
			ps.println("     * @param hlaeos the output stream to write to");
			ps.println("     * @exception IOException if an error occurs");
			ps.println("     */");
			ps.println("    public void encode(HLAEncodingOutputStream hlaeos) throws IOException");
			ps.print("    {");

			for (int i = 0; i < nl.getLength(); i++) {
				Element fieldElement = (Element) nl.item(i);

				if (javaTypeForDataType(fieldElement.getAttribute(DATA_TYPE)) != null) {
					ps.println();

					printSerializationBlock(ps, 2, 'i', fieldElement.getAttribute(DATA_TYPE), fieldElement
							.getAttribute(NAME));
				}
			}

			ps.println("    }");
			ps.println();

			ps.println("    /**");
			ps.println("     * Returns a string representation of this " + typeName + ".");
			ps.println("     *");
			ps.println("     * @return a string representation of this " + typeName);
			ps.println("     */");
			ps.println("    public String toString()");
			ps.println("    {");
			ps.println("        return \"[\" +");

			first = true;

			for (int i = 0; i < nl.getLength(); i++) {
				Element fieldElement = (Element) nl.item(i);

				String javaType = javaTypeForDataType(fieldElement.getAttribute(DATA_TYPE));

				if (javaType != null) {
					if (!first) {
						ps.println(" + \", \" +");
					} else {
						first = false;
					}

					ps.print("               \"" + fieldElement.getAttribute(NAME) + ": \" + "
							+ fieldElement.getAttribute(NAME));
				}
			}

			ps.println(" + ");
			ps.println("               \"]\";");
			ps.println("    }");

			for (int i = 0; i < nl.getLength(); i++) {
				Element fieldElement = (Element) nl.item(i);

				String fieldName = fieldElement.getAttribute(NAME), capitalizedFieldName = capitalize(fieldName), fieldType = fieldElement
						.getAttribute(DATA_TYPE), fieldJavaType = javaTypeForDataType(fieldType);

				if (fieldJavaType != null) {
					ps.println();
					ps.println("    /**");
					ps.println("     * Sets the value of the " + fieldName + " field.");
					ps.println("     *");
					ps.println("     * @param p" + capitalizedFieldName + " the new value for the field");
					ps.println("     */");
					ps.println("    public void set" + capitalizedFieldName + "(" + fieldJavaType + " p"
							+ capitalizedFieldName + ")");
					ps.println("    {");
					ps.println("        " + fieldName + " = p" + capitalizedFieldName + ";");
					ps.println("    }");
					ps.println();

					ps.println("    /**");
					ps.println("     * Returns the value of the " + fieldName + " field.");
					ps.println("     *");
					ps.println("     * @return the value of the " + fieldName + " field");
					ps.println("     */");
					ps.println("    public " + fieldJavaType + " get" + capitalizedFieldName + "()");
					ps.println("    {");
					ps.println("        return " + fieldName + ";");
					ps.println("    }");
				}
			}

			ps.println("}");
		} catch (IOException ioe) {
			System.err.println("Error generating fixed record data type: " + ioe);
		}
	}

	/**
	 * Generates a variant record data type class.
	 * 
	 * @param typeElement
	 *            the element containing the type description
	 */
	private void generateVariantRecordDataType(Element typeElement) {
		String typeName = typeElement.getAttribute(NAME), qualifiedTypeName = packagePrefix + typeName, path = qualifiedTypeName
				.replace('.', '/')
				+ ".java";

		File sourceFile = new File(targetDirectory, path);

		sourceFile.getParentFile().mkdirs();

		try {
			FileOutputStream fos = new FileOutputStream(sourceFile);
			PrintStream ps = new PrintStream(fos);

			String packageName = getPackageName(qualifiedTypeName);

			if (packageName != null) {
				ps.println("package " + packageName + ";");
				ps.println();
			}

			ps.println("import java.io.*;");
			ps.println("import hla.rti1516.jlc.*;");
			ps.println("import hla.rti1516.jlc.omt.*;");
			ps.println();
			ps.println("import org.eodisp.wrapper.hla.*;");
			ps.println();

			if (typeElement.hasAttribute(SEMANTICS)) {
				printClassComment(ps, typeElement.getAttribute(SEMANTICS));
			} else {
				printClassComment(ps, "Autogenerated variant record data type.");
			}
			ps.println();

			ps.println("public class " + typeName + " implements Cloneable, Serializable");
			ps.println("{");

			String discriminant = typeElement.getAttribute(DISCRIMINANT), discriminantType = typeElement
					.getAttribute(DATA_TYPE), discriminantJavaType = javaTypeForDataType(discriminantType);

			ps.println("    /**");
			ps.println("     * The discriminant.");
			ps.println("     */");
			ps.println("    private " + discriminantJavaType + " " + discriminant + ";");
			ps.println();

			NodeList nl = typeElement.getElementsByTagName(ALTERNATIVE);

			for (int i = 0; i < nl.getLength(); i++) {
				Element alternativeElement = (Element) nl.item(i);

				if (javaTypeForDataType(alternativeElement.getAttribute(DATA_TYPE)) != null) {
					if (alternativeElement.hasAttribute(SEMANTICS)) {
						printVariableComment(ps, alternativeElement.getAttribute(SEMANTICS));
					} else {
						printVariableComment(ps, "Alternative #" + i + ".");
					}

					ps.println("    private " + javaTypeForDataType(alternativeElement.getAttribute(DATA_TYPE)) + " "
							+ alternativeElement.getAttribute(NAME) + ";");
					ps.println();
				}
			}

			ps.println();
			ps.println("    /**");
			ps.println("     * Reads and returns a " + typeName + " from the specified stream.");
			ps.println("     *");
			ps.println("     * @param value the byte array to be decoded to a " + typeName);
			ps.println("     * @return the decoded value");
			ps.println("     * @exception IOException if an error occurs");
			ps.println("     */");
			ps.println("    public static " + typeName + " decode(byte[] encodedValue) {");
			ps.println("        " + typeName + " result = new " + typeName + "();");
			ps.println();
			ps.println("// decoding");
			ps.println("ByteWrapper encodedByteWrapper = new ByteWrapper(encodedValue);");
			ps.println("HLAfixedRecord hlaFixedRecord = OmtEncoderFactory.getInstance().createHLAfixedRecord();");
			ps.println("hlaFixedRecord.decode(encodedByteWrapper);");
			ps.println();
			ps.println("// Create new instance");
			ps.println("        " + discriminantJavaType + " " + discriminant + ";");
			ps.println();

			for (int i = 0; i < nl.getLength(); i++) {
				Element record = (Element) nl.item(i);
				String recordType = record.getAttribute(DATA_TYPE);
				final String recordName = record.getAttribute(NAME);
				ps.printf("%s = ((%s)hlaFixedRecord.get(%d)).getValue()", recordName, recordType, new Integer(i));
			}

			// if (discriminantJavaType.equals("int") ||
			// discriminantJavaType.equals("short")
			// || discriminantJavaType.equals("long") ||
			// discriminantJavaType.equals("char")
			// || discriminantJavaType.equals("byte")) {
			// ps.println(" switch(" + discriminant + ")");
			// ps.print(" {");
			//
			// for (int i = 0; i < nl.getLength(); i++) {
			// Element alternativeElement = (Element) nl.item(i);
			//
			// String alternativeType =
			// alternativeElement.getAttribute(DATA_TYPE), alternativeJavaType =
			// javaTypeForDataType(alternativeType);
			//
			// if (alternativeJavaType != null) {
			// ps.println();
			// ps.println(" case " + alternativeElement.getAttribute(ENUMERATOR)
			// + ":");
			//
			// printDeserializationBlock(ps, 4, 'i', alternativeJavaType,
			// "value."
			// + alternativeElement.getAttribute(NAME), "hlaeis");
			//
			// ps.println(" break;");
			// }
			// }
			//
			// ps.println(" }");
			// } else {
			// boolean first = true;
			//
			// for (int i = 0; i < nl.getLength(); i++) {
			// Element alternativeElement = (Element) nl.item(i);
			//
			// String alternativeType =
			// alternativeElement.getAttribute(DATA_TYPE), alternativeJavaType =
			// javaTypeForDataType(alternativeType);
			//
			// if (alternativeJavaType != null) {
			// if (first) {
			// ps.print(" if(" + discriminant);
			//
			// first = false;
			// } else {
			// ps.print(" else if(" + discriminant);
			// }
			//
			// if (discriminantJavaType.equals("float") ||
			// discriminantJavaType.equals("double")) {
			// ps.println(" == " + alternativeElement.getAttribute(ENUMERATOR) +
			// ")");
			// } else if (discriminantJavaType.equals("boolean")) {
			// if
			// (alternativeElement.getAttribute(ENUMERATOR).equals("HLAtrue")) {
			// ps.println(" == true)");
			// } else {
			// ps.println(" == false)");
			// }
			// } else if (discriminantJavaType.equals("String")) {
			// ps.println(".equals(\"" +
			// alternativeElement.getAttribute(ENUMERATOR) + "\"))");
			// } else // assume it's an enumerated type
			// {
			// ps.println(".equals(" + discriminantJavaType + "."
			// + alternativeElement.getAttribute(ENUMERATOR) + "))");
			// }
			//
			// ps.println(" {");
			//
			// printDeserializationBlock(ps, 3, 'i', alternativeJavaType,
			// "value."
			// + alternativeElement.getAttribute(NAME), "hlaeis");
			//
			// ps.println(" }");
			// }
			// }
			// }

			ps.println();
			ps.println("        return result;");
			ps.println("    }");
			ps.println();

			Element firstElement = (Element) nl.item(0);

			ps.println("    /**");
			ps.println("     * Default constructor.");
			ps.println("     */");
			ps.println("    public " + typeName + "()");
			ps.println("    {");
			ps.println("        " + discriminant + " = " + firstElement.getAttribute(ENUMERATOR) + ";");
			ps.println();

			for (int i = 0; i < nl.getLength(); i++) {
				Element alternativeElement = (Element) nl.item(i);

				printInitToDefaultBlock(ps, alternativeElement.getAttribute(DATA_TYPE), alternativeElement
						.getAttribute(NAME));
			}

			ps.println("    }");
			ps.println();

			String capitalizedDiscriminant = capitalize(discriminant);

			ps.println("    /**");
			ps.println("     * Constructor.");
			ps.println("     *");
			ps.println("     * @param p" + capitalizedDiscriminant + " the value of the discriminant");
			ps.println("     */");
			ps.println("    public " + typeName + "(" + discriminantJavaType + " p" + capitalizedDiscriminant + ")");
			ps.println("    {");
			ps.println("        " + discriminant + " = p" + capitalizedDiscriminant + ";");
			ps.println("    }");
			ps.println();

			ps.println("    /**");
			ps.println("     * Copy constructor.");
			ps.println("     *");
			ps.println("     * @param other the other " + typeName + " to copy");
			ps.println("     */");
			ps.println("    public " + typeName + "(" + typeName + " other)");
			ps.println("    {");

			ps.println("        " + discriminant + " = other." + discriminant + ";");

			for (int i = 0; i < nl.getLength(); i++) {
				Element alternativeElement = (Element) nl.item(i);

				if (javaTypeForDataType(alternativeElement.getAttribute(DATA_TYPE)) != null) {
					ps.println("        " + alternativeElement.getAttribute(NAME) + " = other."
							+ alternativeElement.getAttribute(NAME) + ";");
				}
			}

			ps.println("    }");
			ps.println();

			ps.println("    /**");
			ps.println("     * Writes this " + typeName + " to the specified stream.");
			ps.println("     *");
			ps.println("     * @param hlaeos the output stream to write to");
			ps.println("     * @exception IOException if an error occurs");
			ps.println("     */");
			ps.println("    public void encode(HLAEncodingOutputStream hlaeos) throws IOException");
			ps.println("    {");

			printSerializationBlock(ps, 3, 'i', discriminantType, discriminant);
			ps.println();

			if (discriminantJavaType.equals("int") || discriminantJavaType.equals("short")
					|| discriminantJavaType.equals("long") || discriminantJavaType.equals("char")
					|| discriminantJavaType.equals("byte")) {
				ps.println("        switch(" + discriminant + ")");
				ps.print("        {");

				for (int i = 0; i < nl.getLength(); i++) {
					Element alternativeElement = (Element) nl.item(i);

					String alternativeType = alternativeElement.getAttribute(DATA_TYPE), alternativeJavaType = javaTypeForDataType(alternativeType);

					if (alternativeJavaType != null) {
						ps.println();
						ps.println("            case " + alternativeElement.getAttribute(ENUMERATOR) + ":");

						printSerializationBlock(ps, 4, 'i', alternativeJavaType, alternativeElement.getAttribute(NAME));

						ps.println("                break;");
					}
				}

				ps.println("        }");
			} else {
				boolean first = true;

				for (int i = 0; i < nl.getLength(); i++) {
					Element alternativeElement = (Element) nl.item(i);

					String alternativeType = alternativeElement.getAttribute(DATA_TYPE), alternativeJavaType = javaTypeForDataType(alternativeType);

					if (alternativeJavaType != null) {
						if (first) {
							ps.print("        if(" + discriminant);

							first = false;
						} else {
							ps.print("        else if(" + discriminant);
						}

						if (discriminantJavaType.equals("float") || discriminantJavaType.equals("double")) {
							ps.println(" == " + alternativeElement.getAttribute(ENUMERATOR) + ")");
						} else if (discriminantJavaType.equals("boolean")) {
							if (alternativeElement.getAttribute(ENUMERATOR).equals("HLAtrue")) {
								ps.println(" == true)");
							} else {
								ps.println(" == false)");
							}
						} else if (discriminantJavaType.equals("String")) {
							ps.println(".equals(\"" + alternativeElement.getAttribute(ENUMERATOR) + "\"))");
						} else // assume it's an enumerated type
						{
							ps.println(".equals(" + discriminantJavaType + "."
									+ alternativeElement.getAttribute(ENUMERATOR) + "))");
						}

						ps.println("        {");

						printSerializationBlock(ps, 3, 'i', alternativeJavaType, alternativeElement.getAttribute(NAME));

						ps.println("        }");
					}
				}
			}

			ps.println("    }");
			ps.println();

			ps.println("    /**");
			ps.println("     * Returns a string representation of this " + typeName + ".");
			ps.println("     *");
			ps.println("     * @return a string representation of this " + typeName);
			ps.println("     */");
			ps.println("    public String toString()");
			ps.println("    {");

			if (discriminantJavaType.equals("int") || discriminantJavaType.equals("short")
					|| discriminantJavaType.equals("long") || discriminantJavaType.equals("char")
					|| discriminantJavaType.equals("byte")) {
				ps.println("        switch(" + discriminant + ")");
				ps.print("        {");

				for (int i = 0; i < nl.getLength(); i++) {
					Element alternativeElement = (Element) nl.item(i);

					String alternativeType = alternativeElement.getAttribute(DATA_TYPE), alternativeJavaType = javaTypeForDataType(alternativeType);

					if (alternativeJavaType != null) {
						ps.println();
						ps.println("            case " + alternativeElement.getAttribute(ENUMERATOR) + ":");

						ps.println("                return \"[" + discriminant + ": \" + " + discriminant + " + \", "
								+ alternativeElement.getAttribute(NAME) + ": \" + "
								+ alternativeElement.getAttribute(NAME) + " + \"]\";");
					}
				}

				ps.println("        }");
			} else {
				boolean first = true;

				for (int i = 0; i < nl.getLength(); i++) {
					Element alternativeElement = (Element) nl.item(i);

					String alternativeType = alternativeElement.getAttribute(DATA_TYPE), alternativeJavaType = javaTypeForDataType(alternativeType);

					if (alternativeJavaType != null) {
						if (first) {
							ps.print("        if(" + discriminant);

							first = false;
						} else {
							ps.print("        else if(" + discriminant);
						}

						if (discriminantJavaType.equals("float") || discriminantJavaType.equals("double")) {
							ps.println(" == " + alternativeElement.getAttribute(ENUMERATOR) + ")");
						} else if (discriminantJavaType.equals("boolean")) {
							if (alternativeElement.getAttribute(ENUMERATOR).equals("HLAtrue")) {
								ps.println(" == true)");
							} else {
								ps.println("==false)");
							}
						} else if (discriminantJavaType.equals("String")) {
							ps.println(".equals(\"" + alternativeElement.getAttribute(ENUMERATOR) + "\"))");
						} else // assume it's an enumerated type
						{
							ps.println(".equals(" + discriminantJavaType + "."
									+ alternativeElement.getAttribute(ENUMERATOR) + "))");
						}

						ps.println("        {");

						ps.println("            return \"[" + discriminant + ": \" + " + discriminant + " + \", "
								+ alternativeElement.getAttribute(NAME) + ": \" + "
								+ alternativeElement.getAttribute(NAME) + " + \"]\";");

						ps.println("        }");
					}
				}
			}

			ps.println();
			ps.println("        return \"[" + discriminant + ": \" + " + discriminant + " + \"]\";");
			ps.println("    }");
			ps.println();

			ps.println("    /**");
			ps.println("     * Sets the value of the discriminant.");
			ps.println("     *");
			ps.println("     * @param p" + capitalizedDiscriminant + " the new value for the discriminant");
			ps.println("     */");
			ps.println("    public void set" + capitalizedDiscriminant + "(" + discriminantJavaType + " p"
					+ capitalizedDiscriminant + ")");
			ps.println("    {");
			ps.println("        " + discriminant + " = p" + capitalizedDiscriminant + ";");
			ps.println("    }");
			ps.println();

			ps.println("    /**");
			ps.println("     * Returns the value of the discriminant.");
			ps.println("     *");
			ps.println("     * @return the value of the discriminant");
			ps.println("     */");
			ps.println("    public " + discriminantJavaType + " get" + capitalizedDiscriminant + "()");
			ps.println("    {");
			ps.println("        return " + discriminant + ";");
			ps.println("    }");

			for (int i = 0; i < nl.getLength(); i++) {
				Element alternativeElement = (Element) nl.item(i);

				String alternativeName = alternativeElement.getAttribute(NAME), capitalizedAlternativeName = capitalize(alternativeName), alternativeType = alternativeElement
						.getAttribute(DATA_TYPE), alternativeJavaType = javaTypeForDataType(alternativeType);

				if (alternativeJavaType != null) {
					ps.println();
					ps.println("    /**");
					ps.println("     * Sets the value of the " + alternativeName + " alternative.");
					ps.println("     *");
					ps.println("     * @param p" + capitalizedAlternativeName + " the new value for the alternative");
					ps.println("     */");
					ps.println("    public void set" + capitalizedAlternativeName + "(" + alternativeJavaType + " p"
							+ capitalizedAlternativeName + ")");
					ps.println("    {");
					ps.println("        " + alternativeName + " = p" + capitalizedAlternativeName + ";");
					ps.println("    }");
					ps.println();

					ps.println("    /**");
					ps.println("     * Returns the value of the " + alternativeName + " alternative.");
					ps.println("     *");
					ps.println("     * @return the value of the " + alternativeName + " alternative");
					ps.println("     */");
					ps.println("    public " + alternativeJavaType + " get" + capitalizedAlternativeName + "()");
					ps.println("    {");
					ps.println("        return " + alternativeName + ";");
					ps.println("    }");
				}
			}

			ps.println("}");
		} catch (IOException ioe) {
			System.err.println("Error generating variant record data type: " + ioe);
		}
	}

	/**
	 * Generates the proxy ambassador source file.
	 * 
	 * @param fddDocument
	 *            the parsed federation description document
	 * @exception TypeConflictException
	 *                if a type conflict is encountered
	 */
	private void generateProxyAmbassador(Document fddDocument) throws TypeConflictException {
		NodeList nl = fddDocument.getDocumentElement().getElementsByTagName(INTERACTIONS);

		Element interactionsElement = (Element) nl.item(0);

		interactionClassElementMap = new HashMap();

		NodeList interactionClassElements = fddDocument.getDocumentElement().getElementsByTagName(INTERACTION_CLASS);

		for (int i = 0; i < interactionClassElements.getLength(); i++) {
			Element interactionClassElement = (Element) interactionClassElements.item(i);

			interactionClassElementMap.put(interactionClassElement.getAttribute(NAME), interactionClassElement);
		}

		nl = fddDocument.getDocumentElement().getElementsByTagName(OBJECTS);

		Element objectsElement = (Element) nl.item(0);

		String qualifiedAmbassadorName = packagePrefix + proxyAmbassadorName, path = qualifiedAmbassadorName.replace(
				'.', '/')
				+ ".java";

		File sourceFile = new File(targetDirectory, path);

		sourceFile.getParentFile().mkdirs();

		try {
			FileOutputStream fos = new FileOutputStream(sourceFile);
			PrintStream ps = new PrintStream(fos);

			String packageName = getPackageName(qualifiedAmbassadorName);

			if (packageName != null) {
				ps.println("package " + packageName + ";");
				ps.println();
			}

			ps.println("import hla.rti1516.*;");
			ps.println("import hla.rti1516.jlc.*;");
			ps.println("import hla.rti1516.jlc.omt.*;");
			ps.println();
			ps.println("import java.io.*;");
			ps.println("import java.util.*;");
			ps.println("import java.util.concurrent.CopyOnWriteArrayList;");
			ps.println();

			ps.println("import org.eodisp.wrapper.hla.*;");
			ps.println();

			printClassComment(ps, "Autogenerated proxy ambassador.");
			ps.println();

			ps.println("public class " + proxyAmbassadorName + " extends " + federateSuperClass);
			ps.println("{");

			if (interactionsElement != null) {
				ps.println("    /**");
				ps.println("     * The list of interaction listeners.");
				ps.println("     */");
				ps
						.printf(
								"    private final CopyOnWriteArrayList<%1$s> interactionListeners = new CopyOnWriteArrayList<%1$s>();%n",
								interactionListenerName);
				ps.println();

				nl = interactionsElement.getChildNodes();

				for (int i = 0; i < nl.getLength(); i++) {
					if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(INTERACTION_CLASS)) {
						printInteractionHandleDeclarations(ps, (Element) nl.item(i));
					}
				}
			}

			if (objectsElement != null) {
				nl = objectsElement.getChildNodes();

				for (int i = 0; i < nl.getLength(); i++) {
					if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(OBJECT_CLASS)) {
						printObjectClassHandleDeclarations(ps, (Element) nl.item(i));
					}
				}
			}

			ps.println();
			ps.println("    /**");
			ps.println("     * Constructor.");
			ps.println("     *");
			ps.println("     * @param pRTIAmbassador the run-time infrastructure ambassador");
			ps.println("     * @exception InvalidInteractionClassHandle if an interaction class handle was invalid");
			ps.println("     * @exception NameNotFound if an interaction or parameter name was not found");
			ps.println("     * @exception InteractionClassNotDefined if an interaction class is not defined");
			ps
					.println("     * @exception FederateServiceInvocationsAreBeingReportedViaMOM if federate service invocations");
			ps.println("     * are being reported via the management object model");
			ps.println("     * @exception FederateNotExecutionMember if the federate is not a member of an execution");
			ps.println("     * @exception SaveInProgress if a save operation is in progress");
			ps.println("     * @exception RestoreInProgress if a restore operation is in progress");
			ps
					.println("     * @exception RTIinternalError if an internal error occurred in the run-time infrastructure");
			ps.println("     */");
			ps.println("    public " + proxyAmbassadorName + "(RTIambassador pRTIAmbassador)");
			ps.println("           throws InvalidInteractionClassHandle,");
			ps.println("                  InvalidObjectClassHandle,");
			ps.println("                  NameNotFound,");
			ps.println("                  InteractionClassNotDefined,");
			ps.println("                  FederateServiceInvocationsAreBeingReportedViaMOM,");
			ps.println("                  FederateNotExecutionMember,");
			ps.println("                  SaveInProgress,");
			ps.println("                  RestoreInProgress,");
			ps.println("                  RTIinternalError");
			ps.println("    {");
			ps.println("        super(pRTIAmbassador);");
			ps.println("    }");

			ps.println("	/**");
			ps.println("	 * This method is called from the");
			ps.println("	 * {@link #joinFederationExecution(String, String, MobileFederateServices)}");
			ps.println("	 * method just after the federate has been joined. It is made sure that no");
			ps.println("	 * callbacks from the RTI will be processed before this method has returned.");
			ps.println("	 * Therefore, this method is the a suitable place to initialize HLA handles");
			ps.println("	 * that need to be known when callbacks from the RTI are processed.");
			ps.println("	 */");
			ps.println("	protected void initAfterJoin() throws RTIexception {");

			if (interactionsElement != null) {
				ps.println();

				nl = interactionsElement.getChildNodes();

				for (int i = 0; i < nl.getLength(); i++) {
					if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(INTERACTION_CLASS)) {
						printInteractionHandleInitializations(ps, (Element) nl.item(i));
					}
				}
			}

			if (objectsElement != null) {
				nl = objectsElement.getChildNodes();

				for (int i = 0; i < nl.getLength(); i++) {
					if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(OBJECT_CLASS)) {
						printObjectClassHandleInitializations(ps, (Element) nl.item(i));
					}
				}
			}

			// set
			ps.println("        setDiscoveredObjectClassInstanceFactory(new DiscoveredObjectClassInstanceFactory() {");
			ps
					.println("            public ObjectClassInstance newDiscoveredObjectClassInstance(RTIambassador rtiAmbassador, ObjectInstanceHandle objectInstanceHandle, ObjectClassHandle objectClassHandle, String instanceName) throws RTIinternalError {");
			boolean first = true;

			for (int i = 0; i < nl.getLength(); i++) {
				if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(OBJECT_CLASS)) {
					first = printDiscoverObjectClassInstanceFactory(ps, (Element) nl.item(i), first);
				}
			}
			ps.println("                  return null;");
			ps.println("              }");
			ps.println("          });");

			ps.println("	}");

			ps.println();
			ps.println("    /**");
			ps.println("     * Publishes all supported interaction classes.");
			ps.println("     *");
			ps.println("     * @exception InvalidInteractionClassHandle if an interaction class handle is invalid");
			ps.println("     * @exception NameNotFound if a name is not found");
			ps.println("     * @exception InteractionClassNotDefined if an interaction class is undefined");
			ps.println("     * @exception FederateNotExecutionMember if the federate is not an");
			ps.println("     * execution member");
			ps.println("     * @exception SaveInProgress if a save operation is in progress");
			ps.println("     * @exception RestoreInProgress if a restore operation is in progress");
			ps.println("     * @exception RTIinternalError if an internal error occurs in the");
			ps.println("     * run-time infrastructure");
			ps.println("     */");
			ps.println("    public void publishInteractionClasses()");
			ps.println("                throws InvalidInteractionClassHandle,");
			ps.println("                       NameNotFound,");
			ps.println("                       InteractionClassNotDefined,");
			ps.println("                       FederateNotExecutionMember,");
			ps.println("                       SaveInProgress,");
			ps.println("                       RestoreInProgress,");
			ps.println("                       RTIinternalError");
			ps.println("    {");

			if (interactionsElement != null) {

				NodeList interactionElements = interactionsElement.getChildNodes();

				for (int i = 0; i < interactionElements.getLength(); i++) {
					if (interactionElements.item(i) instanceof Element
							&& interactionElements.item(i).getNodeName().equals(INTERACTION_CLASS)) {
						printInteractionClassPublications(ps, (Element) interactionElements.item(i));
					}
				}
			}

			ps.println("    }");

			ps.println();
			ps.println("    /**");
			ps.println("     * Subscribes to all supported interaction classes.");
			ps.println("     *");
			ps.println("     * @exception InvalidInteractionClassHandle if an interaction class handle is invalid");
			ps.println("     * @exception NameNotFound if a name is not found");
			ps.println("     * @exception InteractionClassNotDefined if an interaction class is undefined");
			ps.println("     * @exception FederateNotExecutionMember if the federate is not an");
			ps.println("     * execution member");
			ps.println("     * @exception SaveInProgress if a save operation is in progress");
			ps.println("     * @exception RestoreInProgress if a restore operation is in progress");
			ps
					.println("     * @exception FederateServiceInvocationsAreBeingReportedViaMOM if service invocations are being reported via MOM");
			ps.println("     * @exception RTIinternalError if an internal error occurs in the");
			ps.println("     * run-time infrastructure");
			ps.println("     */");
			ps.println("    public void subscribeInteractionClasses()");
			ps.println("                throws InvalidInteractionClassHandle,");
			ps.println("                       NameNotFound,");
			ps.println("                       InteractionClassNotDefined,");
			ps.println("                       FederateNotExecutionMember,");
			ps.println("                       SaveInProgress,");
			ps.println("                       RestoreInProgress,");
			ps.println("                       FederateServiceInvocationsAreBeingReportedViaMOM,");
			ps.println("                       RTIinternalError");
			ps.println("    {");

			if (interactionsElement != null) {

				NodeList interactionElements = interactionsElement.getChildNodes();

				for (int i = 0; i < interactionElements.getLength(); i++) {
					if (interactionElements.item(i) instanceof Element
							&& interactionElements.item(i).getNodeName().equals(INTERACTION_CLASS)) {
						printInteractionClassSubscriptions(ps, (Element) interactionElements.item(i));
					}
				}
			}

			ps.println("    }");

			ps.println();
			ps.println("    /**");
			ps.println("     * Publishes all supported object class attributes.");
			ps.println("     *");
			ps.println("     * @exception InvalidObjectClassHandle if an object class handle is invalid");
			ps.println("     * @exception NameNotFound if a name is not found");
			ps.println("     * @exception ObjectClassNotDefined if an object class is undefined");
			ps.println("     * @exception AttributeNotDefined if an attribute is undefined");
			ps.println("     * @exception FederateNotExecutionMember if the federate is not an");
			ps.println("     * execution member");
			ps.println("     * @exception SaveInProgress if a save operation is in progress");
			ps.println("     * @exception RestoreInProgress if a restore operation is in progress");
			ps.println("     * @exception RTIinternalError if an internal error occurs in the");
			ps.println("     * run-time infrastructure");
			ps.println("     */");
			ps.println("    public void publishObjectClassAttributes()");
			ps.println("                throws InvalidObjectClassHandle,");
			ps.println("                       NameNotFound,");
			ps.println("                       ObjectClassNotDefined,");
			ps.println("                       AttributeNotDefined,");
			ps.println("                       FederateNotExecutionMember,");
			ps.println("                       SaveInProgress,");
			ps.println("                       RestoreInProgress,");
			ps.println("                       RTIinternalError");
			ps.println("    {");

			if (objectsElement != null) {
				ps.println("        AttributeHandleSet ahs = rtiAmbassador.getAttributeHandleSetFactory().create();");

				nl = objectsElement.getChildNodes();

				for (int i = 0; i < nl.getLength(); i++) {
					if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(OBJECT_CLASS)) {
						printObjectClassPublications(ps, (Element) nl.item(i));
					}
				}
			}

			ps.println("    }");

			ps.println();
			ps.println("    /**");
			ps.println("     * Subscribe to all supported object class attributes.");
			ps.println("     *");
			ps.println("     * @exception InvalidObjectClassHandle if an object class handle is invalid");
			ps.println("     * @exception NameNotFound if a name is not found");
			ps.println("     * @exception ObjectClassNotDefined if an object class is undefined");
			ps.println("     * @exception AttributeNotDefined if an attribute is undefined");
			ps.println("     * @exception FederateNotExecutionMember if the federate is not an");
			ps.println("     * execution member");
			ps.println("     * @exception SaveInProgress if a save operation is in progress");
			ps.println("     * @exception RestoreInProgress if a restore operation is in progress");
			ps.println("     * @exception RTIinternalError if an internal error occurs in the");
			ps.println("     * run-time infrastructure");
			ps.println("     */");
			ps.println("    public void subscribeObjectClassAttributes()");
			ps.println("                throws InvalidObjectClassHandle,");
			ps.println("                       NameNotFound,");
			ps.println("                       ObjectClassNotDefined,");
			ps.println("                       AttributeNotDefined,");
			ps.println("                       FederateNotExecutionMember,");
			ps.println("                       SaveInProgress,");
			ps.println("                       RestoreInProgress,");
			ps.println("                       RTIinternalError");
			ps.println("    {");

			if (objectsElement != null) {
				ps.println("        AttributeHandleSet ahs = rtiAmbassador.getAttributeHandleSetFactory().create();");

				nl = objectsElement.getChildNodes();

				for (int i = 0; i < nl.getLength(); i++) {
					if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(OBJECT_CLASS)) {
						printObjectClassSubscriptions(ps, (Element) nl.item(i));
					}
				}
			}

			ps.println("    }");

			if (objectsElement != null) {
				nl = objectsElement.getChildNodes();

				for (int i = 0; i < nl.getLength(); i++) {
					if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(OBJECT_CLASS)) {
						printObjectInstanceProxyConstructors(ps, (Element) nl.item(i));
					}
				}
			}

			if (interactionsElement != null) {
				ps.println();
				ps.println("    /**");
				ps.println("     * Adds a listener for the interactions processed by this ambassador.");
				ps.println("     *");
				ps.println("     * @param il the listener object to add");
				ps.println("     */");
				ps.println("    public void addInteractionListener(" + interactionListenerName + " il)");
				ps.println("    {");
				ps.println("        interactionListeners.add(il);");
				ps.println("    }");
				ps.println();

				ps.println("    /**");
				ps.println("     * Removes a listener for the interactions processed by this ambassador.");
				ps.println("     *");
				ps.println("     * @param il the listener object to remove");
				ps.println("     */");
				ps.println("    public void removeInteractionListener(" + interactionListenerName + " il)");
				ps.println("    {");
				ps.println("        interactionListeners.remove(il);");
				ps.println("    }");
				ps.println();

				ps.println("    /**");
				ps.println("     * Notifies the federate of a received interaction.");
				ps.println("     *");
				ps.println("     * @param interactionClass the class of the received interaction");
				ps.println("     * @param theParameters the map between parameter handles and the values of");
				ps.println("     * the identified parameters");
				ps.println("     * @param userSuppliedTag a user-supplied tag associated with the interaction");
				ps.println("     * @param sentOrdering the type of ordering with which the interaction was sent");
				ps.println("     * @param theTransport the type of transport associated with the interaction");
				ps
						.println("     * @exception InteractionClassNotRecognized if the interaction class was not recognized");
				ps
						.println("     * @exception InteractionParameterNotRecognized if a parameter of the interaction was not");
				ps.println("     * recognized");
				ps.println("     * @exception InteractionClassNotSubscribed if the federate had not subscribed to the");
				ps.println("     * interaction class");
				ps.println("     * @exception FederateInternalError if an error occurs in the federate");
				ps.println("     */");
				ps.println("    public void notifyReceiveInteraction(InteractionClassHandle interactionClass,");
				ps.println("                                   ParameterHandleValueMap theParameters,");
				ps.println("                                   byte[] userSuppliedTag,");
				ps.println("                                   OrderType sentOrdering,");
				ps.println("                                   TransportationType theTransport)");
				ps.println("                throws InteractionClassNotRecognized,");
				ps.println("                       InteractionParameterNotRecognized,");
				ps.println("                       InteractionClassNotSubscribed,");
				ps.println("                       FederateInternalError {");

				nl = interactionsElement.getChildNodes();

				first = true;

				for (int i = 0; i < nl.getLength(); i++) {
					if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(INTERACTION_CLASS)) {
						first = printReceiveInteractionBlock(ps, (Element) nl.item(i), first);
					}
				}
				ps.println();

				ps.println("    }");
			}

			if (interactionsElement != null) {
				nl = interactionsElement.getChildNodes();

				for (int i = 0; i < nl.getLength(); i++) {
					if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(INTERACTION_CLASS)) {
						printSendInteractionMethods(ps, (Element) nl.item(i));
					}
				}
			}

			ps.println("}");
		} catch (IOException ioe) {
			System.err.println("Error generating proxy ambassador: " + ioe);
		}
	}

	/**
	 * Collates and returns the list of parameters for the interaction class
	 * described by the specified element, combining parameters inherited from
	 * the immediate parent, those from any other parents, and those specific to
	 * the class.
	 * 
	 * @param interactionClassElement
	 *            the element describing the interaction class
	 * @return the complete list of elements describing the interaction's
	 *         parameters
	 * @exception TypeConflictException
	 *                if a type conflict is detected
	 */
	private Vector collateParameters(Element interactionClassElement) throws TypeConflictException {
		Vector parameters = new Vector();

		if (interactionClassElement.getParentNode().getNodeName().equals(INTERACTION_CLASS)) {
			parameters.addAll(collateParameters((Element) interactionClassElement.getParentNode()));
		}

		if (interactionClassElement.hasAttribute(PARENTS)) {
			StringTokenizer st = new StringTokenizer(interactionClassElement.getAttribute(PARENTS));

			while (st.hasMoreTokens()) {
				parameters.addAll(collateParameters((Element) interactionClassElementMap.get(st.nextToken())));
			}
		}

		NodeList nl = interactionClassElement.getChildNodes();

		for (int i = 0; i < nl.getLength(); i++) {
			if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(PARAMETER)) {
				parameters.add(nl.item(i));
			}
		}

		HashMap parameterNameTypeMap = new HashMap();

		Iterator it = parameters.iterator();

		while (it.hasNext()) {
			Element parameterElement = (Element) it.next();

			String name = parameterElement.getAttribute(NAME), type = parameterElement.getAttribute(DATA_TYPE);

			if (parameterNameTypeMap.containsKey(name)) {
				if (parameterNameTypeMap.get(name).equals(type)) {
					it.remove();
				} else {
					throw new TypeConflictException(name);
				}
			} else {
				parameterNameTypeMap.put(name, type);
			}
		}

		return parameters;
	}

	/**
	 * Prints the set of interaction handle declarations for the specified
	 * interaction class element and its sub-elements.
	 * 
	 * @param ps
	 *            the stream to print to
	 * @param interactionClassElement
	 *            the interaction class element to process
	 * @exception TypeConflictException
	 *                if a type conflict is detected
	 */
	private void printInteractionHandleDeclarations(PrintStream ps, Element interactionClassElement)
			throws TypeConflictException {
		String interactionName = interactionClassElement.getAttribute(NAME);
		String interactionQName = getQualifiedInteractionClassName(interactionClassElement);

		if (!(interactionClassElement.hasAttribute(SHARING) && interactionClassElement.getAttribute(SHARING).equals(
				NEITHER))) {
			ps.println("    /**");
			ps.println("     * Handle for the " + interactionQName + " interaction.");
			ps.println("     */");
			ps.println("    private InteractionClassHandle " + interactionName + "Handle;");
			ps.println();

			Vector parameterElements = collateParameters(interactionClassElement);

			Iterator it = parameterElements.iterator();

			while (it.hasNext()) {
				String parameter = ((Element) it.next()).getAttribute(NAME);

				ps.println("    /**");
				ps.println("     * Handle for the " + parameter + " parameter of the " + interactionQName
						+ " interaction.");
				ps.println("     */");
				ps.println("    private ParameterHandle " + interactionName + "_" + parameter + "Handle;");
				ps.println();
			}
		}

		NodeList nl = interactionClassElement.getChildNodes();

		for (int i = 0; i < nl.getLength(); i++) {
			if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(INTERACTION_CLASS)) {
				printInteractionHandleDeclarations(ps, (Element) nl.item(i));
			}
		}
	}

	/**
	 * Prints the set of object class handle declarations for the specified
	 * object class element and its sub-elements.
	 * 
	 * @param ps
	 *            the stream to print to
	 * @param objectClassElement
	 *            the object class element to process
	 */
	private void printObjectClassHandleDeclarations(PrintStream ps, Element objectClassElement) {
		String objectClassName = objectClassElement.getAttribute(NAME);
		String objectClassQName = getQualifiedObjectClassName(objectClassElement);

		ps.println("    /**");
		ps.println("     * Handle for the " + objectClassQName + " object class.");
		ps.println("     */");
		ps.println("    private ObjectClassHandle " + objectClassName + "Handle;");
		ps.println();

		NodeList nl = objectClassElement.getChildNodes();

		for (int i = 0; i < nl.getLength(); i++) {
			if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(OBJECT_CLASS)) {
				printObjectClassHandleDeclarations(ps, (Element) nl.item(i));
			}
		}
	}

	/**
	 * Prints the set of interaction handle initializations for the specified
	 * interaction class element and its sub-elements.
	 * 
	 * @param ps
	 *            the stream to print to
	 * @param interactionClassElement
	 *            the interaction class element to process
	 * @exception TypeConflictException
	 *                if a type conflict is detected
	 */
	private void printInteractionHandleInitializations(PrintStream ps, Element interactionClassElement)
			throws TypeConflictException {
		String interactionName = interactionClassElement.getAttribute(NAME);
		String interactionQName = getQualifiedInteractionClassName(interactionClassElement);

		if (!(interactionClassElement.hasAttribute(SHARING) && interactionClassElement.getAttribute(SHARING).equals(
				NEITHER))) {
			ps.println();
			ps.println("        " + interactionName + "Handle =");
			ps.println("            rtiAmbassador.getInteractionClassHandle(\"" + interactionQName + "\");");

			Vector parameterElements = collateParameters(interactionClassElement);

			Iterator it = parameterElements.iterator();

			while (it.hasNext()) {
				String parameter = ((Element) it.next()).getAttribute(NAME);

				ps.println();
				ps.println("        " + interactionName + "_" + parameter + "Handle =");
				ps.println("            rtiAmbassador.getParameterHandle(" + interactionName + "Handle, \"" + parameter
						+ "\");");
			}
		}

		NodeList nl = interactionClassElement.getChildNodes();

		for (int i = 0; i < nl.getLength(); i++) {
			if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(INTERACTION_CLASS)) {
				printInteractionHandleInitializations(ps, (Element) nl.item(i));
			}
		}
	}

	/**
	 * Prints the set of interaction class publications for the specified
	 * interaction class element and its sub-elements.
	 * 
	 * @param ps
	 *            the stream to print to
	 * @param interactionClassElement
	 *            the interaction class element to process
	 * @exception TypeConflictException
	 *                if a type conflict is detected
	 */
	private void printInteractionClassPublications(PrintStream ps, Element interactionClassElement)
			throws TypeConflictException {
		String interactionName = interactionClassElement.getAttribute(NAME);

		final String sharingAttr = interactionClassElement.getAttribute(SHARING);
		if (sharingAttr.equals(PUBLISH) || sharingAttr.equals(PUBLISH_SUBSCRIBE)) {
			ps.println();
			ps.println("        rtiAmbassador.publishInteractionClass(" + interactionName + "Handle);");
		}

		NodeList nl = interactionClassElement.getChildNodes();

		for (int i = 0; i < nl.getLength(); i++) {
			if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(INTERACTION_CLASS)) {
				printInteractionClassPublications(ps, (Element) nl.item(i));
			}
		}
	}

	/**
	 * Prints the set of interaction class subscriptions for the specified
	 * interaction class element and its sub-elements.
	 * 
	 * @param ps
	 *            the stream to print to
	 * @param interactionClassElement
	 *            the interaction class element to process
	 * @exception TypeConflictException
	 *                if a type conflict is detected
	 */
	private void printInteractionClassSubscriptions(PrintStream ps, Element interactionClassElement)
			throws TypeConflictException {
		String interactionName = interactionClassElement.getAttribute(NAME);

		if ((interactionClassElement.hasAttribute(SHARING)
				&& interactionClassElement.getAttribute(SHARING).equals(SUBSCRIBE) || interactionClassElement
				.getAttribute(SHARING).equals(PUBLISH_SUBSCRIBE))) {

			ps.println();
			ps.println("        rtiAmbassador.subscribeInteractionClass(" + interactionName + "Handle);");
		}

		NodeList nl = interactionClassElement.getChildNodes();

		for (int i = 0; i < nl.getLength(); i++) {
			if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(INTERACTION_CLASS)) {
				printInteractionClassSubscriptions(ps, (Element) nl.item(i));
			}
		}
	}

	/**
	 * Prints the set of object class handle initializations for the specified
	 * object class element and its sub-elements.
	 * 
	 * @param ps
	 *            the stream to print to
	 * @param objectClassElement
	 *            the object class element to process
	 * @exception TypeConflictException
	 *                if a type conflict is detected
	 */
	private void printObjectClassHandleInitializations(PrintStream ps, Element objectClassElement)
			throws TypeConflictException {
		String objectClassName = objectClassElement.getAttribute(NAME);
		String objectClassQName = getQualifiedObjectClassName(objectClassElement);

		ps.println();
		ps.println("        " + objectClassName + "Handle =");
		ps.println("            rtiAmbassador.getObjectClassHandle(\"" + objectClassQName + "\");");

		NodeList nl = objectClassElement.getChildNodes();

		for (int i = 0; i < nl.getLength(); i++) {
			if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(OBJECT_CLASS)) {
				printObjectClassHandleInitializations(ps, (Element) nl.item(i));
			}
		}
	}

	/**
	 * Prints the set of object class publications for the specified object
	 * class element and its sub-elements.
	 * 
	 * @param ps
	 *            the stream to print to
	 * @param objectClassElement
	 *            the object class element to process
	 * @exception TypeConflictException
	 *                if a type conflict is detected
	 */
	private void printObjectClassPublications(PrintStream ps, Element objectClassElement) throws TypeConflictException {
		String objectClassName = objectClassElement.getAttribute(NAME);

		Vector publishedAttributes = collatePublishedAttributes2(objectClassElement);

		if (!publishedAttributes.isEmpty()) {
			ps.println();
			ps.println("        ahs.clear();");

			Iterator it = publishedAttributes.iterator();

			while (it.hasNext()) {
				Element attributeElement = (Element) it.next();
				final String sharingAttribute = attributeElement.getAttribute(SHARING);

				ps.println();
				ps.println("        ahs.add(");
				ps.println("            rtiAmbassador.getAttributeHandle(");
				ps.println("                " + objectClassName + "Handle,");
				ps.println("                \"" + attributeElement.getAttribute(NAME) + "\"");
				ps.println("            )");
				ps.println("        );");

			}

			ps.println();
			ps.println("        rtiAmbassador.publishObjectClassAttributes(" + objectClassName + "Handle, ahs);");
		}

		// publications of subclasses
		NodeList nl = objectClassElement.getChildNodes();

		for (int i = 0; i < nl.getLength(); i++) {
			if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(OBJECT_CLASS)) {
				printObjectClassPublications(ps, (Element) nl.item(i));
			}
		}
	}

	/**
	 * Prints the set of object class publications for the specified object
	 * class element and its sub-elements.
	 * 
	 * @param ps
	 *            the stream to print to
	 * @param objectClassElement
	 *            the object class element to process
	 * @exception TypeConflictException
	 *                if a type conflict is detected
	 */
	private void printObjectClassSubscriptions(PrintStream ps, Element objectClassElement) throws TypeConflictException {
		String objectClassName = objectClassElement.getAttribute(NAME);
		String objectClassQName = getQualifiedObjectClassName(objectClassElement);

		Vector subscribedAttributes = collateSubscribedAttributes2(objectClassElement);

		if (!subscribedAttributes.isEmpty()) {
			ps.println();
			ps.println("        ahs.clear();");

			Iterator it = subscribedAttributes.iterator();

			while (it.hasNext()) {
				Element attributeElement = (Element) it.next();
				final String sharingAttribute = attributeElement.getAttribute(SHARING);

				ps.println();
				ps.println("        ahs.add(");
				ps.println("            rtiAmbassador.getAttributeHandle(");
				ps.println("                " + objectClassName + "Handle,");
				ps.println("                \"" + attributeElement.getAttribute(NAME) + "\"");
				ps.println("            )");
				ps.println("        );");

			}

			ps.println();
			ps.println("        rtiAmbassador.subscribeObjectClassAttributes(" + objectClassName + "Handle, ahs);");
		}

		// publications of subclasses
		NodeList nl = objectClassElement.getChildNodes();

		for (int i = 0; i < nl.getLength(); i++) {
			if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(OBJECT_CLASS)) {
				printObjectClassSubscriptions(ps, (Element) nl.item(i));
			}
		}
	}

	/**
	 * Prints the set of object instance proxy constructors for the specified
	 * object class element and its sub-elements.
	 * 
	 * @param ps
	 *            the stream to print to
	 * @param objectClassElement
	 *            the object class element to process
	 */
	private void printObjectInstanceProxyConstructors(PrintStream ps, Element objectClassElement) {
		String objectClass = objectClassElement.getAttribute(NAME), objectClassProxy = objectClass + "Proxy";

		ps.println();
		ps.println("    /**");
		ps.println("     * Registers a new " + objectClass + " and returns a proxy object that may be");
		ps.println("     * used to examine and control its state.");
		ps.println("     *");
		ps.println("     * @return the newly created proxy object");
		ps.println("     * @exception ObjectClassNotDefined if the specified object class is not defined");
		ps.println("     * @exception ObjectClassNotPublished if the specified object class is not published");
		ps.println("     * @exception FederateNotExecutionMember if the federate is not a member of an execution");
		ps.println("     * @exception SaveInProgress if a save operation is in progress");
		ps.println("     * @exception RestoreInProgress if a restore operation is in progress");
		ps.println("     * @exception RTIinternalError if an internal error occurred in the");
		ps.println("     * run-time infrastructure");
		ps.println("     */");
		ps.println("    public " + objectClass + " new" + objectClass + "()");
		ps.println("           " + spacer(objectClass) + " throws ObjectClassNotDefined,");
		ps.println("           " + spacer(objectClass) + "        ObjectClassNotPublished,");
		ps.println("           " + spacer(objectClass) + "        FederateNotExecutionMember,");
		ps.println("           " + spacer(objectClass) + "        SaveInProgress,");
		ps.println("           " + spacer(objectClass) + "        RestoreInProgress,");
		ps.println("           " + spacer(objectClass) + "        RTIinternalError");
		ps.println("    {");
		ps.println("        " + objectClass + " objectClassInstance = new " + objectClassProxy + "(rtiAmbassador, "
				+ objectClass + "Handle);");
		ps.println();
		ps
				.println("        registerObjectClassInstance(objectClassInstance.getObjectInstanceHandle(), objectClassInstance);");
		ps.println();
		ps.println("        return objectClassInstance;");
		ps.println("    }");
		ps.println();

		ps.println("    /**");
		ps.println("     * Registers a new " + objectClass + " with the specified name and returns a proxy");
		ps.println("     * object that may be used to examine and control its state.");
		ps.println("     *");
		ps.println("     * @param name the name of the new object");
		ps.println("     * @return the newly created proxy object");
		ps.println("     * @exception ObjectClassNotDefined if the specified object class is not defined");
		ps.println("     * @exception ObjectClassNotPublished if the specified object class is not published");
		ps.println("     * @exception IllegalName if the instance name has is illegal");
		ps.println("     * @exception ObjectInstanceNameInUse if the instance name is already in use");
		ps.println("     * @exception FederateNotExecutionMember if the federate is not a member of an execution");
		ps.println("     * @exception SaveInProgress if a save operation is in progress");
		ps.println("     * @exception RestoreInProgress if a restore operation is in progress");
		ps.println("     * @exception RTIinternalError if an internal error occurred in the");
		ps.println("     * run-time infrastructure");
		ps.println("     */");
		ps.println("    public " + objectClass + " new" + objectClass + "(String name)");
		ps.println("           " + spacer(objectClass) + " throws ObjectClassNotDefined,");
		ps.println("           " + spacer(objectClass) + "        ObjectClassNotPublished,");
		ps.println("           " + spacer(objectClass) + "        IllegalName,");
		ps.println("           " + spacer(objectClass) + "        ObjectInstanceNameInUse,");
		ps.println("           " + spacer(objectClass) + "        FederateNotExecutionMember,");
		ps.println("           " + spacer(objectClass) + "        SaveInProgress,");
		ps.println("           " + spacer(objectClass) + "        RestoreInProgress,");
		ps.println("           " + spacer(objectClass) + "        RTIinternalError");
		ps.println("    {");
		ps.println("        " + objectClass + " objectClassInstance = new " + objectClassProxy + "(rtiAmbassador, "
				+ objectClass + "Handle, name);");
		ps.println();
		ps
				.println("        registerObjectClassInstance(objectClassInstance.getObjectInstanceHandle(), objectClassInstance);");
		ps.println();
		ps.println("        return objectClassInstance;");
		ps.println("    }");

		NodeList nl = objectClassElement.getChildNodes();

		for (int i = 0; i < nl.getLength(); i++) {
			if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(OBJECT_CLASS)) {
				printObjectInstanceProxyConstructors(ps, (Element) nl.item(i));
			}
		}
	}

	/**
	 * Prints the set of send-interaction methods for the specified interaction
	 * class element and its sub-elements.
	 * 
	 * @param ps
	 *            the stream to print to
	 * @param interactionClassElement
	 *            the interaction class element to process
	 * @exception TypeConflictException
	 *                if a type conflict is detected
	 */
	private void printSendInteractionMethods(PrintStream ps, Element interactionClassElement)
			throws TypeConflictException {
		if ((interactionClassElement.hasAttribute(SHARING) && (interactionClassElement.getAttribute(SHARING).equals(
				PUBLISH) || interactionClassElement.getAttribute(PUBLISH_SUBSCRIBE).equals(PUBLISH)))) {
			ps.println();
			ps.println("    /**");

			if (interactionClassElement.hasAttribute(SEMANTICS)) {
				ps.print(formatCommentBody(1, interactionClassElement.getAttribute(SEMANTICS)));
			} else {
				ps.println("     * Sends a " + interactionClassElement.getAttribute(NAME) + " interaction.");
			}

			ps.println("     *");

			Vector parameterElements = collateParameters(interactionClassElement);

			Iterator it = parameterElements.iterator();

			while (it.hasNext()) {
				Element parameterElement = (Element) it.next();

				if (parameterElement.getAttribute(SEMANTICS) != null) {
					ps.print(formatCommentBody(1, "@param " + parameterElement.getAttribute(NAME) + " "
							+ parameterElement.getAttribute(SEMANTICS)));
				} else {
					ps.println("     * @param " + parameterElement.getAttribute(NAME) + " The value of the "
							+ parameterElement.getAttribute(NAME) + " parameter");
				}
			}

			ps.println("     * @param userSuppliedTag a user-supplied tag to accompany the interaction");
			ps.println("     * @exception InteractionClassNotPublished if the interaction class is not published");
			ps.println("     * @exception InteractionClassNotDefined if the interaction class is not defined");
			ps.println("     * @exception InteractionParameterNotDefined if one of the parameters is not defined");
			ps.println("     * @exception FederateNotExecutionMember if the federate is not a member of an execution");
			ps.println("     * @exception SaveInProgress if a save operation is in progress");
			ps.println("     * @exception RestoreInProgress if a restore operation is in progress");
			ps.println("     * @exception RTIinternalError if an internal error occurs in the run-time infrastructure");
			ps.println("     */");

			String interaction = interactionClassElement.getAttribute(NAME);

			ps.print("    public void send" + interaction + "(");

			it = parameterElements.iterator();

			while (it.hasNext()) {
				Element parameterElement = (Element) it.next();

				String parameterName = parameterElement.getAttribute(NAME), parameterType = parameterElement
						.getAttribute(DATA_TYPE), parameterJavaType = javaTypeForDataType(parameterType);

				ps.println(parameterJavaType + " " + parameterName + ",");
				ps.print("                     " + spacer(interaction));
			}

			ps.println("byte[] userSuppliedTag)");
			ps.println("                throws InteractionClassNotPublished,");
			ps.println("                       InteractionClassNotDefined,");
			ps.println("                       InteractionParameterNotDefined,");
			ps.println("                       FederateNotExecutionMember,");
			ps.println("                       SaveInProgress,");
			ps.println("                       RestoreInProgress,");
			ps.println("                       RTIinternalError");

			ps.println("    {");
			ps.println("        ParameterHandleValueMap phvm = ");
			ps.println("            rtiAmbassador.getParameterHandleValueMapFactory().create("
					+ parameterElements.size() + ");");
			ps.println();

			if (parameterElements.size() > 0) {
				it = parameterElements.iterator();

				while (it.hasNext()) {
					Element parameterElement = (Element) it.next();

					String parameter = parameterElement.getAttribute(NAME), parameterType = parameterElement
							.getAttribute(DATA_TYPE);

					ps.println();
					printSerializationBlock(ps, 2, 'i', parameterType, parameter);
					ps.println();

					ps.println("        phvm.put(" + interaction + "_" + parameter + "Handle, encoded.toByteArray());");
				}

				ps.println();
			}

			ps.println("        rtiAmbassador.sendInteraction(" + interaction + "Handle, phvm, userSuppliedTag);");
			ps.println("    }");
		}

		NodeList nl = interactionClassElement.getChildNodes();

		for (int i = 0; i < nl.getLength(); i++) {
			if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(INTERACTION_CLASS)) {
				printSendInteractionMethods(ps, (Element) nl.item(i));
			}
		}
	}

	/**
	 * Prints the receive interaction block for the specified interaction class
	 * element and its sub-elements.
	 * 
	 * @param ps
	 *            the stream to print to
	 * @param interactionClassElement
	 *            the interaction class element to process
	 * @param first
	 *            whether or not this is the first block being printed
	 * @return the new value for <code>first</code>: <code>true</code> if
	 *         the first block has not been printed, <code>false</code> if it
	 *         has been
	 * @exception TypeConflictException
	 *                if a type conflict is detected
	 */
	private boolean printReceiveInteractionBlock(PrintStream ps, Element interactionClassElement, boolean first)
			throws TypeConflictException {
		String interactionName = interactionClassElement.getAttribute(NAME);

		if (!(interactionClassElement.hasAttribute(SHARING) && interactionClassElement.getAttribute(SHARING).equals(
				NEITHER))) {

			if (first) {
				ps.println("        if(interactionClass.equals(" + interactionName + "Handle)) {");

				first = false;
			} else {
				ps.println("        else if(interactionClass.equals(" + interactionName + "Handle)) {");
			}
			Vector parameterElements = collateParameters(interactionClassElement);

			Iterator it = parameterElements.iterator();

			while (it.hasNext()) {
				Element parameterElement = (Element) it.next();

				String parameter = parameterElement.getAttribute(NAME), parameterType = parameterElement
						.getAttribute(DATA_TYPE), parameterJavaType = javaTypeForDataType(parameterType);

				ps.println("            byte[] value = (byte[])theParameters.get(" + interactionName + "_" + parameter
						+ "Handle);");
				ps.println("            " + parameterJavaType + " " + parameter + "Parameter;");
				printDeserializationBlock(ps, 3, 'i', parameterType, parameter + "Parameter");
				ps.println();
			}

			ps.println("            Iterator it = interactionListeners.iterator();");
			ps.println("            while(it.hasNext()) {");
			ps.println("                ((" + interactionListenerName + ")it.next()).receive" + interactionName + "(");

			it = parameterElements.iterator();

			while (it.hasNext()) {
				String parameter = ((Element) it.next()).getAttribute(NAME);

				ps.println("                    " + parameter + "Parameter,");
			}

			ps.println("                    userSuppliedTag,");
			ps.println("                    sentOrdering,");
			ps.println("                    theTransport");
			ps.println("                );");
			ps.println("            }");
			ps.println("        }");
		}

		NodeList nl = interactionClassElement.getChildNodes();

		for (int i = 0; i < nl.getLength(); i++) {
			if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(INTERACTION_CLASS)) {
				first = printReceiveInteractionBlock(ps, (Element) nl.item(i), first);
			}
		}

		return first;
	}

	/**
	 * Prints the discover object instance block for the specified object class
	 * element and its sub-elements.
	 * 
	 * @param ps
	 *            the stream to print to
	 * @param objectClassElement
	 *            the object class element to process
	 * @param first
	 *            whether or not this is the first block being printed
	 * @return the new value for <code>first</code>: <code>true</code> if
	 *         the first block has not been printed, <code>false</code> if it
	 *         has been
	 */
	private boolean printDiscoverObjectClassInstanceFactory(PrintStream ps, Element objectClassElement, boolean first) {
		String objectClass = objectClassElement.getAttribute(NAME);

		if (first) {
			ps.println("            if(objectClassHandle.equals(" + objectClass + "Handle))");

			first = false;
		} else {
			ps.println("            else if(objectClassHandle.equals(" + objectClass + "Handle))");
		}

		ps.println("            {");
		ps.println("                return new " + objectClass
				+ "Proxy(rtiAmbassador, objectInstanceHandle, objectClassHandle, instanceName);");
		ps.println("            }");

		NodeList nl = objectClassElement.getChildNodes();

		for (int i = 0; i < nl.getLength(); i++) {
			if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(OBJECT_CLASS)) {
				first = printDiscoverObjectClassInstanceFactory(ps, (Element) nl.item(i), first);
			}
		}

		return first;
	}

	/**
	 * Generates the interaction listener source file.
	 * 
	 * @param fddDocument
	 *            the parsed federation description document
	 * @exception TypeConflictException
	 *                if a type conflict is detected
	 */
	private void generateInteractionListener(Document fddDocument) throws TypeConflictException {
		NodeList nl = fddDocument.getDocumentElement().getElementsByTagName(INTERACTIONS);

		if (nl.getLength() == 0)
			return;

		String qualifiedListenerName = packagePrefix + interactionListenerName, path = qualifiedListenerName.replace(
				'.', '/')
				+ ".java";

		File sourceFile = new File(targetDirectory, path);

		sourceFile.getParentFile().mkdirs();

		try {
			FileOutputStream fos = new FileOutputStream(sourceFile);
			PrintStream ps = new PrintStream(fos);

			String packageName = getPackageName(qualifiedListenerName);

			if (packageName != null) {
				ps.println("package " + packageName + ";");
				ps.println();
			}

			ps.println("import hla.rti1516.*;");
			ps.println();

			printClassComment(ps, "Autogenerated interaction listener interface.");
			ps.println();

			ps.println("public interface " + interactionListenerName);
			ps.print("{");

			Element interactionsElement = (Element) nl.item(0);

			nl = interactionsElement.getChildNodes();

			for (int i = 0; i < nl.getLength(); i++) {
				if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(INTERACTION_CLASS)) {
					printReceiveInteractionDeclarations(ps, (Element) nl.item(i));
				}
			}

			ps.println("}");
		} catch (IOException ioe) {
			System.err.println("Error generating interaction listener: " + ioe);
		}
	}

	/**
	 * Prints the set of receive-interaction declarations for the specified
	 * interaction class element and its sub-elements.
	 * 
	 * @param ps
	 *            the stream to print to
	 * @param interactionClassElement
	 *            the interaction class element to process
	 * @exception TypeConflictException
	 *                if a type conflict is detected
	 */
	private void printReceiveInteractionDeclarations(PrintStream ps, Element interactionClassElement)
			throws TypeConflictException {
		if (!(interactionClassElement.hasAttribute(SHARING) && interactionClassElement.getAttribute(SHARING).equals(
				NEITHER))) {
			ps.println();
			ps.println("    /**");

			if (interactionClassElement.hasAttribute(SEMANTICS)) {
				ps.print(formatCommentBody(1, interactionClassElement.getAttribute(SEMANTICS)));
			} else {
				ps.println("     * Receives a " + interactionClassElement.getAttribute(NAME) + " interaction.");
			}

			ps.println("     *");

			Vector parameterElements = collateParameters(interactionClassElement);

			Iterator it = parameterElements.iterator();

			while (it.hasNext()) {
				Element parameterElement = (Element) it.next();

				if (parameterElement.getAttribute(SEMANTICS) != null) {
					ps.print(formatCommentBody(1, "@param " + parameterElement.getAttribute(NAME) + " "
							+ parameterElement.getAttribute(SEMANTICS)));
				} else {
					ps.println("     * @param " + parameterElement.getAttribute(NAME) + " The value of the "
							+ parameterElement.getAttribute(NAME) + " parameter");
				}
			}

			ps.println("     * @param userSuppliedTag a user-supplied tag associated with the interaction");
			ps.println("     * @param sentOrdering the type of ordering with which the interaction was sent");
			ps.println("     * @param theTransport the type of transport associated with the interaction");
			ps.println("     * @exception InteractionClassNotRecognized if the interaction class was not recognized");
			ps.println("     * @exception InteractionParameterNotRecognized if a parameter of the interaction was not");
			ps.println("     * recognized");
			ps.println("     * @exception InteractionClassNotSubscribed if the federate had not subscribed to the");
			ps.println("     * interaction class");
			ps.println("     * @exception FederateInternalError if an error occurs in the federate");
			ps.println("     */");

			String interaction = interactionClassElement.getAttribute(NAME);

			ps.print("    public void receive" + interaction + "(");

			it = parameterElements.iterator();

			while (it.hasNext()) {
				Element parameterElement = (Element) it.next();

				String parameterName = parameterElement.getAttribute(NAME), parameterType = parameterElement
						.getAttribute(DATA_TYPE), parameterJavaType = javaTypeForDataType(parameterType);

				ps.println(parameterJavaType + " " + parameterName + ",");
				ps.print("                        " + spacer(interaction));
			}

			ps.println("byte[] userSuppliedTag,");
			ps.println("                        " + spacer(interaction) + "OrderType sentOrdering,");
			ps.println("                        " + spacer(interaction) + "TransportationType theTransport)");

			ps.println("                throws InteractionClassNotRecognized,");
			ps.println("                       InteractionParameterNotRecognized,");
			ps.println("                       InteractionClassNotSubscribed,");
			ps.println("                       FederateInternalError;");
		}

		NodeList nl = interactionClassElement.getChildNodes();

		for (int i = 0; i < nl.getLength(); i++) {
			if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(INTERACTION_CLASS)) {
				printReceiveInteractionDeclarations(ps, (Element) nl.item(i));
			}
		}
	}

	/**
	 * Generates the object instance proxy source files.
	 * 
	 * @param fddDocument
	 *            the parsed federation description document
	 * @exception TypeConflictException
	 *                if a type conflict is detected
	 */
	private void generateObjectInstanceProxies(Document fddDocument) throws TypeConflictException {
		Element rootElement = fddDocument.getDocumentElement();

		NodeList nl = rootElement.getElementsByTagName(OBJECTS);

		if (nl.getLength() > 0) {
			objectClassElementMap = new HashMap();

			NodeList objectClassElements = fddDocument.getDocumentElement().getElementsByTagName(OBJECT_CLASS);

			for (int i = 0; i < objectClassElements.getLength(); i++) {
				Element objectClassElement = (Element) objectClassElements.item(i);

				objectClassElementMap.put(objectClassElement.getAttribute(NAME), objectClassElement);
			}

			nl = nl.item(0).getChildNodes();

			for (int i = 0; i < nl.getLength(); i++) {
				if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(OBJECT_CLASS)) {
					generateObjectInstanceProxy((Element) nl.item(i), "ObjectInstanceProxy");
				}
			}
		}
	}

	/**
	 * Generates the object instance proxy source files.
	 * 
	 * @param fddDocument
	 *            the parsed federation description document
	 * @exception TypeConflictException
	 *                if a type conflict is detected
	 */
	private void generatePasselClasses(Document fddDocument) throws TypeConflictException {
		Element rootElement = fddDocument.getDocumentElement();

		NodeList nl = rootElement.getElementsByTagName(OBJECTS);

		if (nl.getLength() > 0) {
			objectClassElementMap = new HashMap();

			NodeList objectClassElements = fddDocument.getDocumentElement().getElementsByTagName(OBJECT_CLASS);

			for (int i = 0; i < objectClassElements.getLength(); i++) {
				Element objectClassElement = (Element) objectClassElements.item(i);

				objectClassElementMap.put(objectClassElement.getAttribute(NAME), objectClassElement);
			}

			nl = nl.item(0).getChildNodes();

			for (int i = 0; i < nl.getLength(); i++) {
				if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(OBJECT_CLASS)) {
					generatePasselClass((Element) nl.item(i), "Object");
				}
			}
		}
	}

	/**
	 * Generates an object instance proxy source file.
	 * 
	 * @param classElement
	 *            the object instance class element containing the relevant
	 *            information
	 * @param superClassName
	 *            the name of the proxy superclass
	 * @exception TypeConflictException
	 *                if a type conflict is detected
	 */
	private void generatePasselClass(Element classElement, String superClassName) throws TypeConflictException {
		String className = classElement.getAttribute(NAME) + "Passel";
		String qualifiedClassName = packagePrefix + className;
		String path = qualifiedClassName.replace('.', '/') + ".java";

		File sourceFile = new File(targetDirectory, path);

		sourceFile.getParentFile().mkdirs();

		try {
			FileOutputStream fos = new FileOutputStream(sourceFile);
			PrintStream ps = new PrintStream(fos);

			String packageName = getPackageName(qualifiedClassName);

			if (packageName != null) {
				ps.println("package " + packageName + ";");
				ps.println();
			}

			if (!superClassName.equals("Object")) {
				String qualifiedSuperClassName = packagePrefix + superClassName, superClassPackage = getPackageName(qualifiedSuperClassName);

				if ((packageName == null && superClassPackage != null)
						|| (packageName != null && superClassPackage == null)
						|| (packageName != null && superClassPackage != null && !packageName.equals(superClassPackage))) {
					ps.println("import " + qualifiedSuperClassName + ";");
				}
			}
			ps.println();

			if (classElement.hasAttribute(SEMANTICS)) {
				printClassComment(ps, classElement.getAttribute(SEMANTICS));
			} else {
				printClassComment(ps, "Autogenerated passel class.");
			}
			ps.println();

			ps.println("public class " + className + " extends " + superClassName + " {");

			HashMap attributeInterfaceSetMap = new HashMap();

			Vector attributeElements = collateAttributes(classElement, attributeInterfaceSetMap);

			Iterator it = attributeElements.iterator();

			for (int i = 0; it.hasNext(); i++) {
				Element attributeElement = (Element) it.next();

				if (javaTypeForDataType(attributeElement.getAttribute(DATA_TYPE)) != null) {
					if (attributeElement.hasAttribute(SEMANTICS)) {
						printVariableComment(ps, attributeElement.getAttribute(SEMANTICS));
					} else {
						printVariableComment(ps, "Attribute #" + i + ".");
					}

					if (javaTypeForDataType(attributeElement.getAttribute(DATA_TYPE)) != null) {
						ps.println("    " + javaTypeForDataType(attributeElement.getAttribute(DATA_TYPE)) + " "
								+ attributeElement.getAttribute(NAME) + ";");
						ps.println();

						ps.println("    /**");
						ps.println("     * Whether or not the " + attributeElement.getAttribute(NAME)
								+ " attribute has been set.");
						ps.println("     */");
						ps.println("    boolean " + attributeElement.getAttribute(NAME) + "IsValid;");
						ps.println();

					}

				}
			}

			it = attributeElements.iterator();

			while (it.hasNext()) {
				Element attributeElement = (Element) it.next();

				String attribute = attributeElement.getAttribute(NAME), capitalizedAttribute = capitalize(attribute), attributeType = attributeElement
						.getAttribute(DATA_TYPE), attributeJavaType = javaTypeForDataType(attributeType);

				if (attributeJavaType != null) {
					ps.println("    /**");
					ps.println("     * Returns the value of the " + attribute + " attribute.");
					ps.println("     *");
					ps.println("     * @return the current attribute value");
					ps.println("     */");
					ps.println("    public " + attributeJavaType + " get" + capitalizedAttribute + "() {");
					ps.println("        return " + attribute + ";");
					ps.println("    }");
					ps.println();

					ps.println("    /**");
					ps.println("     * Returns <code>true</code> if the attribute '" + attribute
							+ "' has been updated for this passel.");
					ps.println("     *");
					ps
							.println("     * @return <code>true</code> if this attribute has been updated with this passel, <code>false</code> otherwise");
					ps.println("     */");
					ps.println("    public boolean " + attribute + "IsValid() {");
					ps.println("        return " + attribute + "IsValid;");
					ps.println("    }");

				}
			}

			ps.println("}");
		} catch (IOException ioe) {
			System.err.println("Error generating object instance proxy: " + ioe);
		}

		NodeList nl = classElement.getChildNodes();

		for (int i = 0; i < nl.getLength(); i++) {
			if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(OBJECT_CLASS)) {
				generatePasselClass((Element) nl.item(i), className);
			}
		}
	}

	/**
	 * Generates the object instance interface source files.
	 * 
	 * @param fddDocument
	 *            the parsed federation description document
	 */
	private void generateObjectInstanceInterfaces(Document fddDocument) {
		Element rootElement = fddDocument.getDocumentElement();

		NodeList nl = rootElement.getElementsByTagName(OBJECTS);

		if (nl.getLength() > 0) {
			nl = nl.item(0).getChildNodes();

			for (int i = 0; i < nl.getLength(); i++) {
				if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(OBJECT_CLASS)) {
					generateObjectInstanceInterface((Element) nl.item(i), "ObjectClassInstance");
				}
			}
		}
	}

	/**
	 * Generates the object instance listener source files.
	 * 
	 * @param fddDocument
	 *            the parsed federation description document
	 */
	private void generateObjectInstanceListeners(Document fddDocument) {
		Element rootElement = fddDocument.getDocumentElement();

		NodeList nl = rootElement.getElementsByTagName(OBJECTS);

		if (nl.getLength() > 0) {
			nl = nl.item(0).getChildNodes();

			for (int i = 0; i < nl.getLength(); i++) {
				if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(OBJECT_CLASS)) {
					generateObjectInstanceListener((Element) nl.item(i));
				}
			}
		}
	}

	/**
	 * Generates the object instance listener source files.
	 * 
	 * @param fddDocument
	 *            the parsed federation description document
	 */
	private void generateObjectInstancePasselListeners(Document fddDocument) {
		Element rootElement = fddDocument.getDocumentElement();

		NodeList nl = rootElement.getElementsByTagName(OBJECTS);

		if (nl.getLength() > 0) {
			nl = nl.item(0).getChildNodes();

			for (int i = 0; i < nl.getLength(); i++) {
				if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(OBJECT_CLASS)) {
					generateObjectInstancePasselListener((Element) nl.item(i));
				}
			}
		}
	}

	/**
	 * Generates an object instance proxy source file.
	 * 
	 * @param classElement
	 *            the object instance class element containing the relevant
	 *            information
	 * @param superClassName
	 *            the name of the proxy superclass
	 * @exception TypeConflictException
	 *                if a type conflict is detected
	 */
	private void generateObjectInstanceProxy(Element classElement, String superClassName) throws TypeConflictException {
		String className = classElement.getAttribute(NAME) + "Proxy", qualifiedClassName = packagePrefix + className, path = qualifiedClassName
				.replace('.', '/')
				+ ".java";

		File sourceFile = new File(targetDirectory, path);

		sourceFile.getParentFile().mkdirs();

		try {
			FileOutputStream fos = new FileOutputStream(sourceFile);
			PrintStream ps = new PrintStream(fos);

			String packageName = getPackageName(qualifiedClassName);

			if (packageName != null) {
				ps.println("package " + packageName + ";");
				ps.println();
			}

			ps.println("import hla.rti1516.*;");
			ps.println("import hla.rti1516.jlc.*;");
			ps.println("import hla.rti1516.jlc.omt.*;");

			ps.println("import hla.rti1516.*;");
			ps.println();
			ps.println("import java.io.*;");
			ps.println("import java.util.*;");
			ps.println("import java.util.concurrent.*;");
			ps.println();
			ps.println("import org.eodisp.wrapper.hla.*;");

			if (!superClassName.equals("ObjectInstanceProxy")) {
				String qualifiedSuperClassName = packagePrefix + superClassName, superClassPackage = getPackageName(qualifiedSuperClassName);

				if ((packageName == null && superClassPackage != null)
						|| (packageName != null && superClassPackage == null)
						|| (packageName != null && superClassPackage != null && !packageName.equals(superClassPackage))) {
					ps.println("import " + qualifiedSuperClassName + ";");
				}
			}
			ps.println();

			if (classElement.hasAttribute(SEMANTICS)) {
				printClassComment(ps, classElement.getAttribute(SEMANTICS));
			} else {
				printClassComment(ps, "Autogenerated object instance proxy.");
			}
			ps.println();

			ps.println("public class " + className + " extends " + superClassName + " implements "
					+ classElement.getAttribute(NAME));
			ps.println("{");

			String interfaceName = classElement.getAttribute(NAME);

			ps.println("    /**");
			ps.println("     * Listeners for attributes associated with the " + interfaceName + " class.");
			ps.println("     */");
			ps
					.printf(
							"    private final CopyOnWriteArrayList<%1$sListener> listeners = new CopyOnWriteArrayList<%1$sListener>();%n",
							interfaceName);

			ps.println();

			ps
					.printf(
							"    private final CopyOnWriteArrayList<%1$sPasselListener> passelListeners = new CopyOnWriteArrayList<%1$sPasselListener>();%n",
							interfaceName);

			ps.println();

			HashMap attributeInterfaceSetMap = new HashMap();

			Vector attributeElements = collateAttributes(classElement, attributeInterfaceSetMap);

			Iterator it = attributeElements.iterator();

			for (int i = 0; it.hasNext(); i++) {
				Element attributeElement = (Element) it.next();

				String attribute = attributeElement.getAttribute(NAME);

				ps.println("    /**");
				ps.println("     * The handle of the " + attribute + " attribute.");
				ps.println("     */");
				ps.println("    private AttributeHandle " + attribute + "Handle;");
				ps.println();

				if (javaTypeForDataType(attributeElement.getAttribute(DATA_TYPE)) != null) {
					ps.println("    /**");
					ps.println("     * Whether or not the " + attribute + " attribute has been set.");
					ps.println("     */");
					ps.println("    private boolean " + attribute + "IsValid;");
					ps.println();

					ps.println("    /**");
					ps.println("     * Whether or not the " + attribute + " attribute has changed.");
					ps.println("     */");
					ps.println("    private boolean " + attribute + "IsDirty;");
					ps.println();

					if (attributeElement.hasAttribute(SEMANTICS)) {
						printVariableComment(ps, attributeElement.getAttribute(SEMANTICS));
					} else {
						printVariableComment(ps, "Attribute #" + i + ".");
					}

					ps.println("    private " + javaTypeForDataType(attributeElement.getAttribute(DATA_TYPE)) + " "
							+ attributeElement.getAttribute(NAME) + ";");
					ps.println();
				}
			}

			ps.println();
			ps.println("    /**");
			ps.println("     * Constructor for object instance proxies created in response to");
			ps.println("     * discovered objects.");
			ps.println("     *");
			ps.println("     * @param pRTIAmbassador the run-time infrastructure ambassador");
			ps.println("     * @param pInstanceHandle the object instance handle");
			ps.println("     * @param pClassHandle the object class handle");
			ps.println("     * @param pName the object name");
			ps.println("     * @exception RTIinternalError if an internal error occurred in the");
			ps.println("     * run-time infrastructure");
			ps.println("     */");
			ps.println("    protected " + className + "(RTIambassador pRTIAmbassador,");
			ps.println("              " + spacer(className) + " ObjectInstanceHandle pInstanceHandle,");
			ps.println("              " + spacer(className) + " ObjectClassHandle pClassHandle,");
			ps.println("              " + spacer(className) + " String pName)");
			ps.println("              throws RTIinternalError");
			ps.println("    {");
			ps.println("        super(pRTIAmbassador, pInstanceHandle, pClassHandle, pName);");
			ps.println();
			ps.println("        try");
			ps.println("        {");
			ps.println("            initializeAttributes();");
			ps.println();
			ps.println("            AttributeHandleSet ahs = rtiAmbassador.getAttributeHandleSetFactory().create();");
			ps.println();

			it = attributeElements.iterator();

			while (it.hasNext()) {
				Element attributeElement = (Element) it.next();

				String attribute = attributeElement.getAttribute(NAME), attributeType = attributeElement
						.getAttribute(DATA_TYPE), attributeJavaType = javaTypeForDataType(attributeType);

				if (attributeJavaType != null) {
					ps.println("            ahs.add(" + attribute + "Handle);");
					ps.println();
				}
			}

			ps
					.println("            rtiAmbassador.requestAttributeValueUpdate(getObjectInstanceHandle(), ahs, new byte[0]);");
			ps.println("        }");
			ps.println("        catch(RTIexception rtie)");
			ps.println("        {");
			ps.println("            throw new RTIinternalError(rtie.toString());");
			ps.println("        }");
			ps.println("    }");
			ps.println();

			ps.println("    /**");
			ps.println("     * Constructor for object instance proxies created to represent new");
			ps.println("     * locally owned objects.  Automatically notifies the run-time");
			ps.println("     * infrastructure.");
			ps.println("     *");
			ps.println("     * @param pRTIAmbassador the run-time infrastructure ambassador");
			ps.println("     * @param pClassHandle the object class handle");
			ps.println("     * @exception ObjectClassNotDefined if the specified object class is not defined");
			ps.println("     * @exception ObjectClassNotPublished if the specified object class is not published");
			ps.println("     * @exception FederateNotExecutionMember if the federate is not a member of an execution");
			ps.println("     * @exception SaveInProgress if a save operation is in progress");
			ps.println("     * @exception RestoreInProgress if a restore operation is in progress");
			ps.println("     * @exception RTIinternalError if an internal error occurred in the");
			ps.println("     * run-time infrastructure");
			ps.println("     */");
			ps.println("    protected " + className + "(RTIambassador pRTIAmbassador,");
			ps.println("              " + spacer(className) + " ObjectClassHandle pClassHandle)");
			ps.println("              throws ObjectClassNotDefined,");
			ps.println("                     ObjectClassNotPublished,");
			ps.println("                     FederateNotExecutionMember,");
			ps.println("                     SaveInProgress,");
			ps.println("                     RestoreInProgress,");
			ps.println("                     RTIinternalError");
			ps.println("    {");
			ps.println("        super(pRTIAmbassador, pClassHandle);");
			ps.println();
			ps.println("        try");
			ps.println("        {");
			ps.println("            initializeAttributes();");
			ps.println("        }");
			ps.println("        catch(RTIexception rtie)");
			ps.println("        {");
			ps.println("            throw new RTIinternalError(rtie.toString());");
			ps.println("        }");
			ps.println("    }");
			ps.println();

			ps.println("    /**");
			ps.println("     * Constructor for object instance proxies created to represent new");
			ps.println("     * locally owned objects.  Automatically notifies the run-time");
			ps.println("     * infrastructure.");
			ps.println("     *");
			ps.println("     * @param pRTIAmbassador the run-time infrastructure ambassador");
			ps.println("     * @param pClassHandle the object class handle");
			ps.println("     * @param pName the object name");
			ps.println("     * @exception ObjectClassNotDefined if the specified object class is not defined");
			ps.println("     * @exception ObjectClassNotPublished if the specified object class is not published");
			ps.println("     * @exception IllegalName if the instance name has is illegal");
			ps.println("     * @exception ObjectInstanceNameInUse if the instance name is already in use");
			ps.println("     * @exception FederateNotExecutionMember if the federate is not a member of an execution");
			ps.println("     * @exception SaveInProgress if a save operation is in progress");
			ps.println("     * @exception RestoreInProgress if a restore operation is in progress");
			ps.println("     * @exception RTIinternalError if an internal error occurred in the");
			ps.println("     * run-time infrastructure");
			ps.println("     */ ");
			ps.println("    protected " + className + "(RTIambassador pRTIAmbassador,");
			ps.println("              " + spacer(className) + " ObjectClassHandle pClassHandle,");
			ps.println("              " + spacer(className) + " String pName)");
			ps.println("              throws ObjectClassNotDefined,");
			ps.println("                     ObjectClassNotPublished,");
			ps.println("                     IllegalName,");
			ps.println("                     ObjectInstanceNameInUse,");
			ps.println("                     FederateNotExecutionMember,");
			ps.println("                     SaveInProgress,");
			ps.println("                     RestoreInProgress,");
			ps.println("                     RTIinternalError");
			ps.println("    {");
			ps.println("        super(pRTIAmbassador, pClassHandle, pName);");
			ps.println();
			ps.println("        try");
			ps.println("        {");
			ps.println("            initializeAttributes();");
			ps.println("        }");
			ps.println("        catch(RTIexception rtie)");
			ps.println("        {");
			ps.println("            throw new RTIinternalError(rtie.toString());");
			ps.println("        }");
			ps.println("    }");
			ps.println();

			ps.println("    /**");
			ps.println("     * Initializes the attributes and their handles.");
			ps.println("     *");
			ps.println("     * @exception InvalidObjectClassHandle if an object class handle is invalid");
			ps.println("     * @exception NameNotFound if a name is not found");
			ps.println("     * @exception ObjectClassNotDefined if an object class is not defined");
			ps.println("     * @exception AttributeNotDefined if an attribute is not defined");
			ps.println("     * @exception FederateNotExecutionMember if the federate is not an execution member");
			ps.println("     * @exception SaveInProgress if a save operation is in progress");
			ps.println("     * @exception RestoreInProgress if a restore operation is in progress");
			ps.println("     * @exception RTIinternalError if an internal error occurred in the run-time");
			ps.println("     * infrastructure");
			ps.println("     */");
			ps.println("    private void initializeAttributes()");
			ps.println("                 throws InvalidObjectClassHandle,");
			ps.println("                        NameNotFound,");
			ps.println("                        ObjectClassNotDefined,");
			ps.println("                        AttributeNotDefined,");
			ps.println("                        FederateNotExecutionMember,");
			ps.println("                        SaveInProgress,");
			ps.println("                        RestoreInProgress,");
			ps.println("                        RTIinternalError");
			ps.print("    {");

			it = attributeElements.iterator();

			while (it.hasNext()) {
				Element attributeElement = (Element) it.next();

				String attribute = attributeElement.getAttribute(NAME);

				ps.println();
				ps.println("        " + attribute
						+ "Handle = rtiAmbassador.getAttributeHandle(getObjectClassHandle(), \"" + attribute + "\");");

				printInitToDefaultBlock(ps, attributeElement.getAttribute(DATA_TYPE), attributeElement
						.getAttribute(NAME));
			}

			ps.println("    }");
			ps.println();

			ps.println("    /**");
			ps.println("     * Notifies the proxy that it should provide an update regarding a set of object");
			ps.println("     * attributes.");
			ps.println("     *");
			ps.println("     * @param theAttributes the set of attribute handles identifying the attributes that");
			ps.println("     * should be sent");
			ps.println("     * @param userSuppliedTag the user-supplied tag associated with the request");
			ps.println("     * @exception AttributeNotRecognized if an identified attribute was not recognized");
			ps.println("     * @exception AttributeNotOwned if the federate did not own a specified attribute");
			ps.println("     * @exception FederateInternalError if an error occurs in the federate");
			ps.println("     */");
			ps.println("    public void notifyProvideAttributeValueUpdate(AttributeHandleSet theAttributes,");
			ps.println("                                            byte[] userSuppliedTag)");
			ps.println("                throws AttributeNotRecognized,");
			ps.println("                       AttributeNotOwned,");
			ps.println("                       FederateInternalError");
			ps.println("    {");

			it = attributeElements.iterator();

			while (it.hasNext()) {
				Element attributeElement = (Element) it.next();

				String attribute = attributeElement.getAttribute(NAME), attributeType = attributeElement
						.getAttribute(DATA_TYPE), attributeJavaType = javaTypeForDataType(attributeType);

				if (attributeJavaType != null) {
					ps.println("        if(theAttributes.contains(" + attribute + "Handle))");
					ps.println("        {");
					ps.println("            " + attribute + "IsDirty = true;");
					ps.println("        }");
					ps.println();
				}
			}

			ps.println("        super.notifyProvideAttributeValueUpdate(");
			ps.println("            theAttributes,");
			ps.println("            userSuppliedTag");
			ps.println("        );");
			ps.println("    }");
			ps.println();

			ps.println("    /**");
			ps.println("     * Places the attribute values to update into the specified map.");
			ps.println("     *");
			ps.println("     * @param ahvm the attribute handle value map to populate");
			ps.println("     * @param updateAll if <code>true</code> provide updates for all attributes;");
			ps.println("     * if <code>false</code>, only provide updates for the modified ones");
			ps.println("     * @exception RTIinternalError if an internal error occurs in the run-time");
			ps.println("     * infrastructure");
			ps.println("     */");
			ps.println("    protected void getAttributeValuesToUpdate(AttributeHandleValueMap ahvm,");
			ps.println("                                             boolean updateAll)");
			ps.println("                   throws RTIinternalError");
			ps.println("    {");

			it = attributeElements.iterator();

			while (it.hasNext()) {
				Element attributeElement = (Element) it.next();

				String attribute = attributeElement.getAttribute(NAME), attributeType = attributeElement
						.getAttribute(DATA_TYPE), attributeJavaType = javaTypeForDataType(attributeType);

				if (attributeJavaType != null) {
					ps.println("        if(" + attribute + "IsValid && (updateAll || " + attribute + "IsDirty))");
					ps.println("        {");
					printSerializationBlock(ps, 2, 'i', attributeType, attribute);
					ps.println();
					ps.println("            ahvm.put(" + attribute + "Handle, encoded.toByteArray());");
					ps.println();
					ps.println("            " + attribute + "IsDirty = false;");
					ps.println("        }");
					ps.println();
				}
			}

			ps.println("        super.getAttributeValuesToUpdate(ahvm, updateAll);");
			ps.println("    }");
			ps.println();
			ps.println("    /**");
			ps.println("     * Adds a listener for attributes associated with the " + interfaceName + " class.");
			ps.println("     *");
			ps.println("     * @param l the listener to add");
			ps.println("     */");
			ps.println("    public void add" + interfaceName + "Listener(" + interfaceName + "Listener l) {");
			ps.println("        	resetWaitForListener();");
			ps.println("        listeners.add(l);");
			ps.println("    }");
			ps.println();

			ps.println("    /**");
			ps.println("     * Removes a listener for attributes associated with the " + interfaceName + " class.");
			ps.println("     *");
			ps.println("     * @param l the listener to remove");
			ps.println("     */");
			ps.println("    public void remove" + interfaceName + "Listener(" + interfaceName + "Listener l) {");
			ps.println("        listeners.remove(l);");
			ps.println("    }");

			ps.println();
			ps.println("    /**");
			ps.println("     * Adds a passel listener for attributes associated with the " + interfaceName + " class.");
			ps.println("     *");
			ps.println("     * @param l the passel listener to add");
			ps.println("     */");
			ps.println("    public void add" + interfaceName + "PasselListener(" + interfaceName
					+ "PasselListener l) {");
			ps.println("        	resetWaitForListener();");
			ps.println("        passelListeners.add(l);");
			ps.println("    }");
			ps.println();

			ps.println("    /**");
			ps.println("     * Removes a passel listener for attributes associated with the " + interfaceName
					+ " class.");
			ps.println("     *");
			ps.println("     * @param l the passel listener to remove");
			ps.println("     */");
			ps.println("    public void remove" + interfaceName + "PasselListener(" + interfaceName
					+ "PasselListener l) {");
			ps.println("        passelListeners.remove(l);");
			ps.println("    }");

			ps.println("    /**");
			ps.println("     * Returns an instance of the " + interfaceName + "Passel class.");
			ps.println("     *");
			ps.println("     * @param l the listener to remove");
			ps.println("     */");
			ps.println("    protected Object createPassel() {");
			ps.println("        return new " + interfaceName + "Passel();");
			ps.println("    }");

			ps.println("    /**");
			ps.println("     * Sets the passel values " + interfaceName + "Passel class.");
			ps.println("     *");
			ps.println("     * @param l the listener to remove");
			ps.println("     */");
			ps
					.println("    protected void setPasselValues( Object passel,  AttributeHandleValueMap attributeHandleValueMap ) {");

			it = attributeElements.iterator();
			ps.printf("        %1$sPassel localPassel = (%1$sPassel)passel;%n", interfaceName);
			while (it.hasNext()) {
				Element attributeElement = (Element) it.next();

				String attribute = attributeElement.getAttribute(NAME);
				String attributeType = attributeElement.getAttribute(DATA_TYPE);
				String attributeJavaType = javaTypeForDataType(attributeType);

				if (attributeJavaType != null) {
					ps.println("        if(attributeHandleValueMap.containsKey(" + attribute + "Handle)) {");
					ps.printf("            byte[] value = (byte[])attributeHandleValueMap.get(%sHandle);%n", attribute);
					printDeserializationBlock(ps, 3, 'i', attributeType, "localPassel." + attribute);
					ps.printf("            %1$s = localPassel.%1$s;%n", attribute);
					ps.println("            localPassel." + attribute + "IsValid = true;");
					ps.println("            " + attribute + "IsValid = true;");
					ps.println();

					ps.println("        }");
				}
			}
			ps.println("        super.setPasselValues( passel, attributeHandleValueMap );");
			ps.println("    }");

			// end setPasselValues

			ps.println("    /**");
			ps.println("     * Notifies the listeners of new values");
			ps.println("     *");
			ps
					.println("     * @param passel all values that were sent in the same passel. Values were all converted from the attributeHandleValueMap");
			ps.println("     * @param attributeHandleValueMap the original attributeHandleValueMap");
			ps.println("     */");
			ps
					.println("    protected void notifyListeners( Object passel,  AttributeHandleValueMap attributeHandleValueMap ) {");

			it = attributeElements.iterator();
			ps.printf("        %1$sPassel localPassel = (%1$sPassel)passel;%n", interfaceName);
			ps.println("        if( listeners.isEmpty() && passelListeners.isEmpty() ) {");
			ps.println("            try {");
			ps.println("                if(! listenerLatch.await( 300, TimeUnit.SECONDS )) {");
			ps
					.println("                    throw new Error(\"Nobody attached a listener during objectInstanceDiscovered.\");");
			ps.println("                }");
			ps.println("            } catch (InterruptedException e) {");
			ps.println("        	        Thread.currentThread().interrupt();");
			ps.println("            }");
			ps.println("        }");

			while (it.hasNext()) {
				Element attributeElement = (Element) it.next();

				String attribute = attributeElement.getAttribute(NAME);
				String attributeType = attributeElement.getAttribute(DATA_TYPE);
				String attributeJavaType = javaTypeForDataType(attributeType);

				if (attributeJavaType != null) {
					ps.println("        if(attributeHandleValueMap.containsKey(" + attribute + "Handle)) {");
					ps.printf("            for(%sListener listener : listeners) {%n", interfaceName);
					ps.println("                listener." + attribute + "Updated(");
					ps.println("                    this,");
					ps.println("                    localPassel,");
					ps.println("                    localPassel.get" + capitalize(attribute) + "());");
					ps.println("            }");
					ps.println("        }");
				}
			}
			ps.printf("        for(%sPasselListener listener : passelListeners) {%n", interfaceName);
			ps.println("            listener.passelUpdated(");
			ps.println("               this,");
			ps.println("                localPassel);");
			ps.println("        }");
			ps.println("        super.notifyListeners( passel, attributeHandleValueMap );");
			ps.println("    }");

			it = attributeElements.iterator();

			while (it.hasNext()) {
				Element attributeElement = (Element) it.next();

				String attribute = attributeElement.getAttribute(NAME), capitalizedAttribute = capitalize(attribute), attributeType = attributeElement
						.getAttribute(DATA_TYPE), attributeJavaType = javaTypeForDataType(attributeType);

				if (attributeJavaType != null) {
					ps.println();
					ps.println("    /**");
					ps.println("     * Sets the value of the " + attribute + " attribute.");
					ps.println("     *");
					ps.println("     * @param p" + capitalizedAttribute + " the new attribute value");
					ps.println("     * @param userSuppliedTag a user-supplied tag to associate with the action");
					ps.println("     * run-time infrastructure");
					ps.println("     */");
					ps.println("    public synchronized void set" + capitalizedAttribute + "(" + attributeJavaType
							+ " p" + capitalizedAttribute + ") {");
					ps.println("        " + attribute + " = p" + capitalizedAttribute + ";");
					ps.println("        " + attribute + "IsValid = true;");
					ps.println("        " + attribute + "IsDirty = true;");
					ps.println("    }");
					ps.println();

					ps.println();
					ps.println("    /**");
					ps.println("     * Sets the value of the " + attribute
							+ " attribute and immediately sends the updated value to the federation.");
					ps.println("     *");
					ps.println("     * @param p" + capitalizedAttribute + " the new attribute value");
					ps
							.println("     * @param userSuppliedTag a user-supplied tag that is used as the parameter to {@link ObjectClassInstance#updateAttributeValues(byte[])} ");
					ps.println("     * @exception ObjectInstanceNotKnown if the object instance is unknown");
					ps.println("     * @exception AttributeNotDefined if one of the attributes is undefined");
					ps.println("     * @exception AttributeNotOwned if one of the attributes is not owned");
					ps
							.println("     * @exception FederateNotExecutionMember if the federate is not a member of an execution");
					ps.println("     * @exception SaveInProgress if a save operation is in progress");
					ps.println("     * @exception RestoreInProgress if a restore operation is in progress");
					ps.println("     * @exception RTIinternalError if an internal error occurred in the");
					ps.println("     * run-time infrastructure");
					ps.println("     */");
					ps.println("    public synchronized void set" + capitalizedAttribute + "(" + attributeJavaType
							+ " p"

							+ capitalizedAttribute + ", byte[] userSuppliedTag)");
					ps.println("                throws ObjectInstanceNotKnown,");
					ps.println("                       AttributeNotDefined,");
					ps.println("                       AttributeNotOwned,");
					ps.println("                       FederateNotExecutionMember,");
					ps.println("                       SaveInProgress,");
					ps.println("                       RestoreInProgress,");
					ps.println("                       RTIinternalError {");
					ps.println("        set" + capitalizedAttribute + "( p" + capitalizedAttribute + " );");
					ps.println("        updateAttributeValues(userSuppliedTag);");
					ps.println("    }");

					ps.println();

					ps.println("    /**");
					ps.println("     * Returns the value of the " + attribute + " attribute.");
					ps.println("     *");
					ps.println("     * @return the current attribute value");
					ps.println("     */");
					ps.println("    public synchronized " + attributeJavaType + " get" + capitalizedAttribute + "()");
					ps.println("    {");
					ps.println("        return " + attribute + ";");
					ps.println("    }");
				}
			}

			ps.println("}");
		} catch (IOException ioe) {
			System.err.println("Error generating object instance proxy: " + ioe);
		}

		NodeList nl = classElement.getChildNodes();

		for (int i = 0; i < nl.getLength(); i++) {
			if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(OBJECT_CLASS)) {
				generateObjectInstanceProxy((Element) nl.item(i), className);
			}
		}
	}

	private String getQualifiedInteractionClassName(Element objectClassElement) {
		return getQualifiedName(objectClassElement, INTERACTION_CLASS);
	}

	private String getQualifiedObjectClassName(Element objectClassElement) {
		return getQualifiedName(objectClassElement, OBJECT_CLASS);
	}

	/**
	 * @param element
	 * @return
	 * @throws TypeConflictException
	 */
	private String getQualifiedName(Element element, String elementName) {
		XPath xpath = XPathFactory.newInstance().newXPath();
		String expression = "ancestor-or-self::" + elementName;
		try {
			NodeList names = (NodeList) xpath.evaluate(expression, element, XPathConstants.NODESET);
			StringBuilder builder = new StringBuilder();

			for (int i = 0; i < names.getLength(); i++) {
				if (i != 0) {
					builder.append(".");
				}
				Element interactionClass = (Element) names.item(i);
				final String className = interactionClass.getAttribute(NAME);
				builder.append(className);

			}
			return builder.toString();
		} catch (XPathExpressionException e) {
			e.printStackTrace();
			throw new IllegalStateException(e);
		}
	}

	/**
	 * Collates and returns the list of attributes for the object class
	 * described by the specified element, combining attributes inherited from
	 * any parents other than the immediate parent and those specific to the
	 * class. Also populates the specified attribute-to-interface-set map.
	 * 
	 * @param objectClassElement
	 *            the element describing the object class
	 * @param attributeInterfaceSetMap
	 *            maps attribute names to sets of interfaces that contain the
	 *            attribute
	 * @return the complete list of elements describing the object's attributes
	 * @exception TypeConflictException
	 *                if a type conflict is detected
	 */
	private Vector collateAttributes(Element objectClassElement, HashMap attributeInterfaceSetMap)
			throws TypeConflictException {
		Vector attributes = new Vector(), parentAttributes = new Vector();

		if (objectClassElement.getParentNode().getNodeName().equals(OBJECT_CLASS)) {
			parentAttributes.addAll(collateAttributes2((Element) objectClassElement.getParentNode(),
					attributeInterfaceSetMap));
		}

		if (objectClassElement.hasAttribute(PARENTS)) {
			StringTokenizer st = new StringTokenizer(objectClassElement.getAttribute(PARENTS));

			while (st.hasMoreTokens()) {
				attributes.addAll(collateAttributes2((Element) objectClassElementMap.get(st.nextToken()),
						attributeInterfaceSetMap));
			}
		}

		NodeList nl = objectClassElement.getChildNodes();

		for (int i = 0; i < nl.getLength(); i++) {
			if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(ATTRIBUTE)) {
				Element attributeElement = (Element) nl.item(i);

				attributes.add(attributeElement);

				String attribute = attributeElement.getAttribute(NAME);

				HashSet hs = (HashSet) attributeInterfaceSetMap.get(attribute);

				if (hs == null) {
					hs = new HashSet();

					attributeInterfaceSetMap.put(attribute, hs);
				}

				hs.add(objectClassElement.getAttribute(NAME));
			}
		}

		HashMap attributeNameTypeMap = new HashMap();

		Iterator it = parentAttributes.iterator();

		while (it.hasNext()) {
			Element attributeElement = (Element) it.next();

			attributeNameTypeMap.put(attributeElement.getAttribute(NAME), attributeElement.getAttribute(DATA_TYPE));
		}

		it = attributes.iterator();

		while (it.hasNext()) {
			Element attributeElement = (Element) it.next();

			String name = attributeElement.getAttribute(NAME), type = attributeElement.getAttribute(DATA_TYPE);

			if (attributeNameTypeMap.containsKey(name)) {
				if (attributeNameTypeMap.get(name).equals(type)) {
					it.remove();
				} else {
					throw new TypeConflictException(name);
				}
			} else {
				attributeNameTypeMap.put(name, type);
			}
		}

		return attributes;
	}

	/**
	 * Collates and returns the list of attributes for the object class
	 * described by the specified element, combining attributes inherited from
	 * the immediate parent, those from any other parents, and those specific to
	 * the class. Also populates the specified attribute-to-interface-set map.
	 * 
	 * @param objectClassElement
	 *            the element describing the object class
	 * @param attributeInterfaceSetMap
	 *            maps attribute names to sets of interfaces containing the
	 *            attribute
	 * @return the complete list of elements describing the object's attributes
	 * @exception TypeConflictException
	 *                if a type conflict is detected
	 */
	private Vector collateAttributes2(Element objectClassElement, HashMap attributeInterfaceSetMap)
			throws TypeConflictException {
		Vector attributes = new Vector();

		if (objectClassElement.getParentNode().getNodeName().equals(OBJECT_CLASS)) {
			attributes
					.addAll(collateAttributes2((Element) objectClassElement.getParentNode(), attributeInterfaceSetMap));
		}

		if (objectClassElement.hasAttribute(PARENTS)) {
			StringTokenizer st = new StringTokenizer(objectClassElement.getAttribute(PARENTS));

			while (st.hasMoreTokens()) {
				attributes.addAll(collateAttributes2((Element) objectClassElementMap.get(st.nextToken()),
						attributeInterfaceSetMap));
			}
		}

		NodeList nl = objectClassElement.getChildNodes();

		for (int i = 0; i < nl.getLength(); i++) {
			if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(ATTRIBUTE)) {
				Element attributeElement = (Element) nl.item(i);

				attributes.add(attributeElement);

				String attribute = attributeElement.getAttribute(NAME);

				HashSet hs = (HashSet) attributeInterfaceSetMap.get(attribute);

				if (hs == null) {
					hs = new HashSet();

					attributeInterfaceSetMap.put(attribute, hs);
				}

				hs.add(objectClassElement.getAttribute(NAME));
			}
		}

		HashMap attributeNameTypeMap = new HashMap();

		Iterator it = attributes.iterator();

		while (it.hasNext()) {
			Element attributeElement = (Element) it.next();

			String name = attributeElement.getAttribute(NAME), type = attributeElement.getAttribute(DATA_TYPE);

			if (attributeNameTypeMap.containsKey(name)) {
				if (attributeNameTypeMap.get(name).equals(type)) {
					it.remove();
				} else {
					throw new TypeConflictException(name);
				}
			} else {
				attributeNameTypeMap.put(name, type);
			}
		}

		return attributes;
	}

	public Vector collateSubscribedAttributes2(Element objectClassElement) throws TypeConflictException {
		Vector result = new Vector();
		Vector allAttributes = collateAttributes2(objectClassElement, new HashMap());

		Iterator it = allAttributes.iterator();
		while (it.hasNext()) {
			Element attributeElement = (Element) it.next();
			final String sharing = attributeElement.getAttribute(SHARING);
			if (sharing.equals(SUBSCRIBE) || sharing.equals(PUBLISH_SUBSCRIBE)) {
				result.add(attributeElement);
			}
		}
		return result;
	}

	public Vector collatePublishedAttributes2(Element objectClassElement) throws TypeConflictException {
		Vector result = new Vector();
		Vector allAttributes = collateAttributes2(objectClassElement, new HashMap());

		Iterator it = allAttributes.iterator();
		while (it.hasNext()) {
			Element attributeElement = (Element) it.next();
			final String sharing = attributeElement.getAttribute(SHARING);
			if (sharing.equals(PUBLISH) || sharing.equals(PUBLISH_SUBSCRIBE)) {
				result.add(attributeElement);
			}
		}
		return result;
	}

	/**
	 * Generates an object instance interface source file.
	 * 
	 * @param classElement
	 *            the object instance class element containing the relevant
	 *            information
	 * @param superInterfaceName
	 *            the name of the superinterface
	 */
	private void generateObjectInstanceInterface(Element classElement, String superInterfaceName) {
		String interfaceName = classElement.getAttribute(NAME), qualifiedInterfaceName = packagePrefix + interfaceName, path = qualifiedInterfaceName
				.replace('.', '/')
				+ ".java";

		File sourceFile = new File(targetDirectory, path);

		sourceFile.getParentFile().mkdirs();

		try {
			FileOutputStream fos = new FileOutputStream(sourceFile);
			PrintStream ps = new PrintStream(fos);

			String packageName = getPackageName(qualifiedInterfaceName);

			if (packageName != null) {
				ps.println("package " + packageName + ";");
				ps.println();
			}

			ps.println("import hla.rti1516.*;");
			ps.println("import org.eodisp.wrapper.hla.*;");

			ps.println();

			printClassComment(ps, "Autogenerated object instance interface.");
			ps.println();

			if (superInterfaceName != null) {
				ps.print("public interface " + interfaceName + " extends " + superInterfaceName);

				if (classElement.hasAttribute(PARENTS)) {
					StringTokenizer st = new StringTokenizer(classElement.getAttribute(PARENTS));

					while (st.hasMoreTokens()) {
						String parent = st.nextToken();

						if (!parent.equals(superInterfaceName)) {
							ps.println(",");
							ps.print("                 " + spacer(interfaceName) + "         " + parent);
						}
					}
				}
			} else {
				ps.print("public interface " + interfaceName);

				if (classElement.hasAttribute(PARENTS)) {
					ps.print(" extends ");

					StringTokenizer st = new StringTokenizer(classElement.getAttribute(PARENTS));

					while (st.hasMoreTokens()) {
						ps.print(st.nextToken());

						if (st.hasMoreTokens()) {
							ps.println(",");
							ps.print("                 " + spacer(interfaceName) + "         ");
						}
					}
				}
			}

			ps.println();
			ps.println("{");
			ps.println("    /**");
			ps.println("     * Adds a listener for the attributes associated with the " + interfaceName + " class.");
			ps.println("     *");
			ps.println("     * @param l the listener to add");
			ps.println("     */");
			ps.println("    public void add" + interfaceName + "Listener(" + interfaceName + "Listener l);");
			ps.println();
			ps.println("    /**");
			ps.println("     * Removes a listener for the attributes associated with the " + interfaceName + " class.");
			ps.println("     *");
			ps.println("     * @param l the listener to remove");
			ps.println("     */");
			ps.println("    public void remove" + interfaceName + "Listener(" + interfaceName + "Listener l);");

			ps.println();

			ps.println("    /**");
			ps.println("     * Adds a passel listener for the attributes associated with the " + interfaceName
					+ " class.");
			ps.println("     *");
			ps.println("     * @param l the listener to add");
			ps.println("     */");
			ps
					.println("    public void add" + interfaceName + "PasselListener(" + interfaceName
							+ "PasselListener l);");
			ps.println();
			ps.println("    /**");
			ps.println("     * Removes a passel listener for the attributes associated with the " + interfaceName
					+ " class.");
			ps.println("     *");
			ps.println("     * @param l the listener to remove");
			ps.println("     */");
			ps.println("    public void remove" + interfaceName + "PasselListener(" + interfaceName
					+ "PasselListener l);");
			ps.println();

			NodeList nl = classElement.getChildNodes();

			for (int i = 0; i < nl.getLength(); i++) {
				if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(ATTRIBUTE)) {
					Element attributeElement = (Element) nl.item(i);

					String attribute = attributeElement.getAttribute(NAME), capitalizedAttribute = capitalize(attribute), attributeType = attributeElement
							.getAttribute(DATA_TYPE), attributeJavaType = javaTypeForDataType(attributeType);

					if (attributeJavaType != null) {
						ps.println();
						ps.println("    /**");
						ps.println("     * Sets the value of the " + attribute + " attribute.");
						ps.println("     *");
						ps.println("     * @param p" + capitalizedAttribute + " the new attribute value");
						ps.println("     */");
						ps.println("    public void set" + capitalizedAttribute + "(" + attributeJavaType + " p"
								+ capitalizedAttribute + ");");

						ps.println();

						ps.println();
						ps.println("    /**");
						ps.println("     * Sets the value of the " + attribute
								+ " attribute and immediately sends the updated value to the federation.");
						ps.println("     *");
						ps.println("     * @param p" + capitalizedAttribute + " the new attribute value");
						ps
								.println("     * @param userSuppliedTag a user-supplied tag that is used as the parameter to {@link ObjectClassInstance#updateAttributeValues(byte[])} ");
						ps.println("     * @exception ObjectInstanceNotKnown if the object instance is unknown");
						ps.println("     * @exception AttributeNotDefined if one of the attributes is undefined");
						ps.println("     * @exception AttributeNotOwned if one of the attributes is not owned");
						ps
								.println("     * @exception FederateNotExecutionMember if the federate is not a member of an execution");
						ps.println("     * @exception SaveInProgress if a save operation is in progress");
						ps.println("     * @exception RestoreInProgress if a restore operation is in progress");
						ps.println("     * @exception RTIinternalError if an internal error occurred in the");
						ps.println("     * run-time infrastructure");
						ps.println("     */");
						ps.println("    public void set" + capitalizedAttribute + "(" + attributeJavaType + " p"

						+ capitalizedAttribute + ", byte[] userSuppliedTag)");
						ps.println("                throws ObjectInstanceNotKnown,");
						ps.println("                       AttributeNotDefined,");
						ps.println("                       AttributeNotOwned,");
						ps.println("                       FederateNotExecutionMember,");
						ps.println("                       SaveInProgress,");
						ps.println("                       RestoreInProgress,");
						ps.println("                       RTIinternalError;");

						ps.println();

						ps.println("    /**");
						ps.println("     * Returns the value of the " + attribute + " attribute.");
						ps.println("     *");
						ps.println("     * @return the current attribute value");
						ps.println("     */");
						ps.println("    public " + attributeJavaType + " get" + capitalizedAttribute + "();");
					}
				}
			}

			ps.println("}");
		} catch (IOException ioe) {
			System.err.println("Error generating object instance interface: " + ioe);
		}

		NodeList nl = classElement.getChildNodes();

		for (int i = 0; i < nl.getLength(); i++) {
			if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(OBJECT_CLASS)) {
				generateObjectInstanceInterface((Element) nl.item(i), interfaceName);
			}
		}
	}

	/**
	 * Generates an object instance listener source file.
	 * 
	 * @param classElement
	 *            the object instance class element containing the relevant
	 *            information
	 */
	private void generateObjectInstancePasselListener(Element classElement) {
		String className = classElement.getAttribute(NAME);
		String interfaceName = className + "PasselListener";
		String qualifiedInterfaceName = packagePrefix + interfaceName;
		String path = qualifiedInterfaceName.replace('.', '/') + ".java";

		File sourceFile = new File(targetDirectory, path);

		sourceFile.getParentFile().mkdirs();

		try {
			FileOutputStream fos = new FileOutputStream(sourceFile);
			PrintStream ps = new PrintStream(fos);

			String packageName = getPackageName(qualifiedInterfaceName);

			if (packageName != null) {
				ps.println("package " + packageName + ";");
				ps.println();
			}

			ps.println("import hla.rti1516.*;");
			ps.println();

			printClassComment(ps, "Autogenerated object instance listener interface.");
			ps.println();

			ps.println("public interface " + interfaceName);

			ps.print("{");

			ps.println();
			ps.println("    /**");
			ps.println("     * Notifies the listener new values have been reflected");
			ps.println("     *");
			ps.println("     * @param source the source of the notification");
			ps.println("     * @param passel all values that were sent together in one passel");
			ps.println("     */");
			ps.println("    public void passelUpdated(" + className + " source,");
			ps.println("                " + spacer(className) + "        " + className + "Passel" + " passel);");

			ps.println("}");
		} catch (IOException ioe) {
			System.err.println("Error generating object instance listener: " + ioe);
		}

		NodeList nl = classElement.getChildNodes();

		for (int i = 0; i < nl.getLength(); i++) {
			if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(OBJECT_CLASS)) {
				generateObjectInstancePasselListener((Element) nl.item(i));
			}
		}
	}

	/**
	 * Generates an object instance listener source file.
	 * 
	 * @param classElement
	 *            the object instance class element containing the relevant
	 *            information
	 */
	private void generateObjectInstanceListener(Element classElement) {
		String className = classElement.getAttribute(NAME);
		String interfaceName = className + "Listener";
		String qualifiedInterfaceName = packagePrefix + interfaceName;
		String path = qualifiedInterfaceName.replace('.', '/') + ".java";

		File sourceFile = new File(targetDirectory, path);

		sourceFile.getParentFile().mkdirs();

		try {
			FileOutputStream fos = new FileOutputStream(sourceFile);
			PrintStream ps = new PrintStream(fos);

			String packageName = getPackageName(qualifiedInterfaceName);

			if (packageName != null) {
				ps.println("package " + packageName + ";");
				ps.println();
			}

			ps.println("import hla.rti1516.*;");
			ps.println();

			printClassComment(ps, "Autogenerated object instance listener interface.");
			ps.println();

			ps.println("public interface " + interfaceName);

			ps.print("{");

			NodeList nl = classElement.getChildNodes();

			for (int i = 0; i < nl.getLength(); i++) {
				if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(ATTRIBUTE)) {
					Element attributeElement = (Element) nl.item(i);

					String attribute = attributeElement.getAttribute(NAME), capitalizedAttribute = capitalize(attribute), attributeType = attributeElement
							.getAttribute(DATA_TYPE), attributeJavaType = javaTypeForDataType(attributeType);

					if (attributeJavaType != null) {
						ps.println();
						ps.println("    /**");
						ps.println("     * Notifies the listener that the " + attribute
								+ " attribute has been updated.");
						ps.println("     *");
						ps.println("     * @param source the source of the notification");
						ps.println("     * @param passel all values that were sent together in one passel");
						ps.println("     * @param newValue the new value of the attribute");
						ps.println("     */");
						ps.println("    public void " + attribute + "Updated(" + className + " source,");
						ps.println("                " + spacer(attribute) + "        " + className + "Passel"
								+ " passel,");
						ps.println("                " + spacer(attribute) + "        " + attributeJavaType
								+ " newValue);");

					}
				}
			}

			ps.println("}");
		} catch (IOException ioe) {
			System.err.println("Error generating object instance listener: " + ioe);
		}

		NodeList nl = classElement.getChildNodes();

		for (int i = 0; i < nl.getLength(); i++) {
			if (nl.item(i) instanceof Element && nl.item(i).getNodeName().equals(OBJECT_CLASS)) {
				generateObjectInstanceListener((Element) nl.item(i));
			}
		}
	}
}