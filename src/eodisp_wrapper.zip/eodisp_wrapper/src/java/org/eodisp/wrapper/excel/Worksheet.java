/**
 * 
 */
package org.eodisp.wrapper.excel;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.swt.ole.win32.OleAutomation;
import org.eclipse.swt.ole.win32.Variant;

/**
 * Represents an Excel Worksheet.
 * 
 * @author ibirrer
 */
public class Worksheet {
	private static final int PROP_NAME = 0x0000006e;

	private final static int WORKSHEET_RANGE = 0x000000c5;

	private final static int WORKSHEET_OLE_OBJECTS = 0x0000031f;

	private final static int COMMAND_BUTTON_COUNT = 0x00000076;

	private final static int COMMAND_BUTTON_ITEM = 0x000000aa;

	private final Workbook workbook;

	private final OleAutomation worksheet;

	Worksheet(final OleAutomation worksheet, Workbook workbook) {
		this.worksheet = worksheet;
		this.workbook = workbook;
	}

	/**
	 * Returns a range of this Worksheet.
	 * 
	 * @param range
	 *            the range, either given in the form <code>A1</code> or the
	 *            name of the range.
	 * @return the range or <code>null</code> if the given string does not
	 *         name a valid range.
	 */
	public Range getRange(String range) {
		Variant rangeVariant = worksheet.getProperty(WORKSHEET_RANGE, new Variant[] { new Variant(range) });
		if (rangeVariant == null) {
			throw new IllegalArgumentException("Range " + range + " is not a valid Range.1");
		}
		OleAutomation rangeAutomation = rangeVariant.getAutomation();
		return new Range(rangeAutomation, this);
	}

	/**
	 * Returns the name of this worksheet
	 * 
	 * @return the name of this worksheet.
	 */
	public String getName() {
		return worksheet.getProperty(PROP_NAME).getString();
	}

	/**
	 * Returns the workbook that contains this worksheet.
	 * 
	 * @return the workbook that conatais this workbook.
	 */
	public Workbook getWorkbook() {
		return workbook;
	}

	/**
	 * Returns the command button with the given name.
	 * 
	 * @param name
	 *            the unique name of the command button.
	 * @return the command button or <code>null</code> if no command button
	 *         exists with the given name.
	 */
	public CommandButton getCommandButton(String name) {
		Variant variant = worksheet.getProperty(WORKSHEET_OLE_OBJECTS, new Variant[] { new Variant(name) });
		if (variant == null) {
			return null;
		}
		return new CommandButton(variant.getAutomation(), getWorkbook().getApplication().getControlSite());
	}

	/**
	 * Returns the command button by its index.
	 * 
	 * @param index
	 *            the index of the command button
	 * @return the command button or <code>null</code> if no command button
	 *         exists with the given index.
	 * @see {{@link #getCommandButton(String)}
	 */
	public CommandButton getCommandButton(int index) {
		Variant variant = worksheet.getProperty(WORKSHEET_OLE_OBJECTS, new Variant[] { new Variant(index) });
		if (variant == null) {
			return null;
		}
		return new CommandButton(variant.getAutomation(), getWorkbook().getApplication().getControlSite());
	}

	/**
	 * Returns all command buttons in this worksheet.
	 * 
	 * @return all command buttons in this worksheet.
	 */
	public List<CommandButton> getCommandButtons() {
		OleAutomation buttons = worksheet.getProperty(WORKSHEET_OLE_OBJECTS).getAutomation();
		int namesCount = buttons.getProperty(COMMAND_BUTTON_COUNT).getInt();
		List<CommandButton> result = new ArrayList<CommandButton>(namesCount);
		for (int i = 1; i < (namesCount + 1); i++) {
			result.add(getCommandButton(i));
		}
		return result;
	}
}
