package org.eodisp.wrapper.hla;

import hla.rti1516.CouldNotDecode;
import hla.rti1516.LogicalTime;
import hla.rti1516.LogicalTimeFactory;

/**
 * A factory for <code>LongValuedLogicalTime</code>s.
 * 
 * @author Andrzej Kapolka
 */

public class LongValuedLogicalTimeFactory implements LogicalTimeFactory {
	/**
	 * Decodes a logical time stored within the specified buffer, returning a
	 * <code>LogicalTime</code> object corresponding to the decoded value.
	 * 
	 * @param buffer
	 *            the buffer that contains the encoded value
	 * @param offset
	 *            the offset within the buffer at which the encoded value is
	 *            stored
	 * @return a new <code>LogicalTime</code> representing the decoded value
	 * @exception CouldNotDecode
	 *                if the value could not be decoded
	 */
	public LogicalTime decode(byte[] buffer, int offset) throws CouldNotDecode {
		byte[] buf = new byte[8];

		System.arraycopy(buffer, offset, buf, 0, 8);

		return new LongValuedLogicalTime(EncodingHelpers.decodeLong(buf));
	}

	/**
	 * Creates and returns an instance of the initial logical time.
	 * 
	 * @return an instance of the initial logical time
	 */
	public LogicalTime makeInitial() {
		return new LongValuedLogicalTime(0);
	}

	/**
	 * Creates and returns an instance of the final logical time.
	 * 
	 * @return an instance of the final logical time
	 */
	public LogicalTime makeFinal() {
		return new LongValuedLogicalTime(Long.MAX_VALUE);
	}
}
