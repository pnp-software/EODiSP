/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.wrapper.hla;


/**
 * @author ibirrer
 * @version $Id:$
 * 
 * <pre> 
 *                                                                        
 *                                                                        .---------------------------------------------------------------.
 *                                                                        |                                                               |
 *                                                                        |      .-------------------------------------------.            |
 *                                                                        |      |                       STEPPING            |            |
 *                                                                        |      |                        ^    |             |            |
 *                                                                        |      |                 step() |    |             |            |
 *                    init()                             start()          |      V    pause()             |    v  resume()   |            |
 *    NOT_INITIALIZED ---»  INITIALIZING ----» INITIALIZED ---» STARTING -|-» STARTED ---»  PAUSING  --»  PAUSED -------» RESUMING        |
 *                                                                        |                                                               |
 *                                                                        '---------------------------------------------------------------'
 *                                                                                                       |    
 *                                                                                                       |
 *                                                                                                       v      
 *                                                                                                    STOPPED       
 *                                                                           
 *                                                                            (From anywhere at anytime) ---> ERROR ---.
 *                                                                                                              A      |
 *                                                                                                              |______|
 *                                                                                      
 * </pre>
 * 
 */
public enum FederationState {
	/**
	 * The federate has not started
	 */
	NOT_INITIALIZED,
	/**
	 * The federate initializes.
	 */
	INITIALIZING,
	/**
	 * All participating federates have registered with the control federate
	 */
	INITIALIZED,
	/**
	 * The synchronization point EODISP_START is registered
	 */
	STARTING,
	/**
	 * The federation synchronized at EODISP_START or EODISP_RESUME
	 */
	STARTED,
	/**
	 * The synchronization point EODISP_PAUSE is registered
	 */
	PAUSING,
	/**
	 * The federation synchronized at EODISP_PAUSE or EODISP_STEP
	 */
	PAUSED,
	/**
	 * The synchronization point EODISP_STEP is registered
	 */
	STEPPING,
	/**
	 * The synchronization point EODISP_RESUME is registered
	 */
	RESUMING,
	/**
	 * The federation synchronized at EOSISP_STOP
	 */
	STOPPED,
	/**
	 * If an error occurred in this federate
	 */
	ERROR;

	public boolean isStateChangeAllowed(FederationState newState) {
		if (newState == ERROR) {
			return true;
		}
		switch (this) {
		case NOT_INITIALIZED:
			if (newState != INITIALIZING) {
				return false;
			}
			break;
		case INITIALIZING:
			if (newState != INITIALIZED) {
				return false;
			}
			break;
		case INITIALIZED:
			if (newState != STARTING) {
				return false;
			}
			break;
		case STARTING:
			if (newState != STARTED) {
				return false;
			}
			break;
		case STARTED:
			if (newState != PAUSING && newState != STOPPED ) {
				return false;
			}
			break;
		case PAUSING:
			if (newState != PAUSED && newState != STOPPED ) {
				return false;
			}
			break;
		case PAUSED:
			if (newState != RESUMING && newState != STEPPING && newState != STOPPED ) {
				return false;
			}
			break;
		case STEPPING:
			if (newState != PAUSED && newState != STOPPED ) {
				return false;
			}
			break;
		case RESUMING:
			if (newState != STARTED && newState != STOPPED ) {
				return false;
			}
			break;
		case ERROR:
			if (newState != ERROR) {
				return false;
			}
			break;
		case STOPPED:
			return false;

		}
		return true;
	}
}
