package org.eodisp.wrapper.hla;

/**
 * An exception thrown when a type conflict is encountered.
 * 
 * @author Andrzej Kapolka
 */

public class TypeConflictException extends Exception {
	/**
	 * Constructor.
	 */
	public TypeConflictException() {
		super();
	}

	/**
	 * Constructor.
	 * 
	 * @param message
	 *            a message describing the cause of the exception
	 */
	public TypeConflictException(String message) {
		super(message);
	}
}
