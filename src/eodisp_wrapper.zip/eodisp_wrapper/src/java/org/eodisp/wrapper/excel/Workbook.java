package org.eodisp.wrapper.excel;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.eclipse.swt.ole.win32.*;

/**
 * Represents an Excel Workbook.
 * 
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class Workbook {
	private final class SheetChangeOleListener implements OleListener {
		public void handleEvent(OleEvent event) {
			OleAutomation rangeAutomation = event.arguments[0].getAutomation();
			Range range = new Range(rangeAutomation, new Worksheet(rangeAutomation.getProperty(Range.PROP_WORKSHEET)
					.getAutomation(), Workbook.this));
			for (SheetChangeListener listener : sheetChangeListeners) {
				listener.sheetChanged(range);
			}
		}
	}

	private final class SheetSelectionChangeOleListener implements OleListener {
		public void handleEvent(OleEvent event) {
			OleAutomation rangeAutomation = event.arguments[0].getAutomation();
			Range range = new Range(rangeAutomation, new Worksheet(rangeAutomation.getProperty(Range.PROP_WORKSHEET)
					.getAutomation(), Workbook.this));
			for (SheetSelectionChangeListener listener : sheetSelectionChangeListeners) {
				listener.selectionChanged(range);
			}
		}
	}

	private static final String EVENT_GUID = "{00024412-0000-0000-C000-000000000046}";

	private final static int EVENT_SHEET_SELECTION_CHANGE = 0x00000607;

	private final static int EVENT_SHEET_CHANGE = 0x0000061c;

	private static final int WORKBOOK_SHEETS = 0x000001e5;

	private static final int WORKBOOK_WINDOWS = 0x000001ae;

	private static final int WORKBOOK_CLOSE = 0x00000115;

	public static final int WINDOW_XL_MAXIMIZED = 2;

	final static int WINDOW_WINDOWSTATE = 0x0000018c;

	private final static int WORKSHEET_NAMES = 0x000001ba;

	private final static int NAMES_COUNT = 0x00000076;

	private final static int NAMES_ITEM = 0x000000aa;

	private final static int NAME_REFERS_TO_RANGE = 0x00000488;

	private final static int RANGE_WORKSHEET = 0x0000015c;

	private final static int WORKSHEET_NAME = 0x0000006e;

	private final OleAutomation workbook;

	private final ExcelApplication excelApplication;

	private final CopyOnWriteArrayList<SheetChangeListener> sheetChangeListeners = new CopyOnWriteArrayList<SheetChangeListener>();

	private final CopyOnWriteArrayList<SheetSelectionChangeListener> sheetSelectionChangeListeners = new CopyOnWriteArrayList<SheetSelectionChangeListener>();

	private final SheetChangeOleListener sheetChangeOleListener = new SheetChangeOleListener();

	private final SheetSelectionChangeOleListener sheetSelectionChangeOleListener = new SheetSelectionChangeOleListener();

	Workbook(OleAutomation workbook, ExcelApplication excelApplication) {
		this.workbook = workbook;
		this.excelApplication = excelApplication;
	}

	/**
	 * Adds a sheet change listener to this workbook.
	 * 
	 * @param listener
	 *            the listener
	 */
	public synchronized void addSheetChangeListener(SheetChangeListener listener) {
		if (sheetChangeListeners.size() == 0) {
			getApplication().getControlSite().addEventListener(workbook, EVENT_GUID, EVENT_SHEET_CHANGE,
					sheetChangeOleListener);
		}
		sheetChangeListeners.add(listener);
	}

	/**
	 * Removes a sheet change listener from this workbook
	 * 
	 * @param listener
	 *            the listener to be removed
	 */
	public synchronized void removeSheetChangeListner(SheetChangeListener listener) {
		sheetChangeListeners.remove(listener);
		if (sheetChangeListeners.size() == 0) {
			getApplication().getControlSite().removeEventListener(workbook, EVENT_SHEET_CHANGE, sheetChangeOleListener);
		}
	}

	/**
	 * Adds a selection change listener to this workbook.
	 * 
	 * @param listener
	 *            the listener to be added
	 */
	public synchronized void addSheetSelectionChangeListener(SheetSelectionChangeListener listener) {
		if (sheetSelectionChangeListeners.size() == 0) {
			getApplication().getControlSite().addEventListener(workbook, EVENT_GUID, EVENT_SHEET_SELECTION_CHANGE,
					sheetSelectionChangeOleListener);
		}
		sheetSelectionChangeListeners.add(listener);
	}

	/**
	 * Removes a selection change listener from this workbook.
	 * 
	 * @param listener
	 *            the listener to be removed
	 */
	public synchronized void removeSheetSelectionChangeListner(SheetSelectionChangeListener listener) {
		sheetSelectionChangeListeners.remove(listener);
		if (sheetSelectionChangeListeners.size() == 0) {
			getApplication().getControlSite().removeEventListener(workbook, EVENT_SHEET_SELECTION_CHANGE,
					sheetSelectionChangeOleListener);
		}
	}

	/**
	 * Returns a Worksheet of this workbook by its name.
	 * 
	 * @param worksheetName
	 *            the name of the worksheet
	 * @return the worksheet or null if no worksheet with the given name exists
	 *         in this workbook.
	 */
	public Worksheet getWorksheet(String worksheetName) {
		Variant worksheetVariant = workbook.getProperty(WORKBOOK_SHEETS, new Variant[] { new Variant(worksheetName) });
		if (worksheetVariant == null) {
			return null;
		}
		OleAutomation excelSheet = worksheetVariant.getAutomation();
		return new Worksheet(excelSheet, this);
	}

	/**
	 * Returns the n-th worksheet of this workbook. Numbers begin at 1.
	 * 
	 * @param nr
	 *            the index of the worksheet
	 * @return the worksheet or <code>null</code> if the no worksheet with the
	 *         given index exists.
	 */
	public Worksheet getWorksheet(int nr) {
		Variant worksheetVariant = workbook.getProperty(WORKBOOK_SHEETS, new Variant[] { new Variant(nr) });
		if (worksheetVariant == null) {
			return null;
		}
		OleAutomation excelSheet = worksheetVariant.getAutomation();
		return new Worksheet(excelSheet, this);
	}

	/**
	 * Return the application object that of the application that contains this
	 * workbook.
	 * 
	 * @return the application.
	 */
	public ExcelApplication getApplication() {
		return excelApplication;
	}

	/**
	 * Set the window state to one of the following:
	 * <ul>
	 * <li>{@link #WINDOW_XL_MAXIMIZED}</li>
	 * </ul>
	 * 
	 * @param state
	 *            only possible value so far: {@link #WINDOW_XL_MAXIMIZED}
	 */
	public void setWindowState(int state) {
		OleAutomation window = workbook.getProperty(WORKBOOK_WINDOWS, new Variant[] { new Variant(1) }).getAutomation();
		window.setProperty(WINDOW_WINDOWSTATE, new Variant(state));
	}

	/**
	 * Get all ranges that have a name associated with it. Not that names are
	 * unique in respect to the whole workbook, or in other words, it is not
	 * possible to have two ranges with the same name in two different
	 * Worksheets.
	 * 
	 * @return a list of all named ranges in this workbook.
	 */
	public List<Range> getNamedRanges() {
		OleAutomation names = workbook.getProperty(WORKSHEET_NAMES).getAutomation();
		int namesCount = names.getProperty(NAMES_COUNT).getInt();
		List<Range> result = new ArrayList<Range>(namesCount);
		for (int i = 0; i < namesCount; i++) {
			Variant nameVariant = names.invoke(NAMES_ITEM, new Variant[] { new Variant(i + 1) });
			OleAutomation name = nameVariant.getAutomation();
			Variant rangeVariant = name.getProperty(NAME_REFERS_TO_RANGE);

			OleAutomation rangeAutomation = rangeVariant.getAutomation();
			OleAutomation worksheetAutomation = rangeAutomation.getProperty(RANGE_WORKSHEET).getAutomation();
			String worksheetName = worksheetAutomation.getProperty(WORKSHEET_NAME).getString();
			Worksheet worksheet = this.getWorksheet(worksheetName);

			Range range = new Range(rangeAutomation, worksheet);
			result.add(range);
		}
		return result;
	}

	/**
	 * Closes this workbook.
	 * 
	 * @param saveChanges
	 *            If there are no changes to the workbook, this argument is
	 *            ignored. If there are changes to the workbook and the workbook
	 *            appears in other open windows, this argument is ignored. If
	 *            there are changes to the workbook but the workbook does not
	 *            appear in any other open windows, this argument specifies
	 *            whether changes should be saved, as shown in the following
	 *            list.
	 *            <ul>
	 *            <li> <code>true</code>: Saves the changes to the workbook.
	 *            If there is not yet a file name associated with the workbook,
	 *            then <code>saveAs</code> is used. If <code>saveAs</code>
	 *            is <code>null</code>, the user is asked to supply a file
	 *            name. </li>
	 *            <li> <code>false</code>: Does not save the changes to the
	 *            workbook. </li>
	 *            </ul>
	 * @param file
	 *            Save changes under this file
	 */
	public void close(boolean saveChanges, File file) {
		Variant[] args = new Variant[] { new Variant(saveChanges) };
		if (file != null) {
			args = new Variant[] { new Variant(saveChanges), new Variant(file.getPath()) };
		}
		workbook.invoke(WORKBOOK_CLOSE, args);
		workbook.dispose();
	}

	/**
	 * Closes this workbook without saving any changes.
	 */
	public void close() {
		close(false, null);
	}
}
