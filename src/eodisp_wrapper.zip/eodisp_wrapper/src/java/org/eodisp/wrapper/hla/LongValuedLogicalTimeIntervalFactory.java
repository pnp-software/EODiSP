package org.eodisp.wrapper.hla;

import hla.rti1516.CouldNotDecode;
import hla.rti1516.LogicalTimeInterval;
import hla.rti1516.LogicalTimeIntervalFactory;

/**
 * A factory for <code>LongValuedLogicalTimeInterval</code>s.
 * 
 * @author Andrzej Kapolka
 */

public class LongValuedLogicalTimeIntervalFactory implements LogicalTimeIntervalFactory {
	/**
	 * Decodes a logical time interval stored within the specified buffer,
	 * returning a corresponding new <code>LogicalTimeInterval</code>.
	 * 
	 * @param buffer
	 *            the buffer containing the encoded interval
	 * @param offset
	 *            the offset within the buffer at which the encoded interval is
	 *            stored
	 * @return a new <code>LogicalTimeInterval</code> corresponding to the
	 *         encoded interval
	 * @exception CouldNotDecode
	 *                if the time interval could not be decoded
	 */
	public LogicalTimeInterval decode(byte[] buffer, int offset) throws CouldNotDecode {
		byte[] buf = new byte[8];

		System.arraycopy(buffer, offset, buf, 0, 8);

		return new LongValuedLogicalTimeInterval(EncodingHelpers.decodeLong(buf));
	}

	/**
	 * Creates and returns a zero-length logical time interval.
	 * 
	 * @return a new zero-length <code>LogicalTimeInterval</code>
	 */
	public LogicalTimeInterval makeZero() {
		return new LongValuedLogicalTimeInterval(0);
	}

	/**
	 * Creates and returns an epsilon-length logical time interval.
	 * 
	 * @return a new epsilon-length <code>LogicalTimeInterval</code>
	 */
	public LogicalTimeInterval makeEpsilon() {
		return new LongValuedLogicalTimeInterval(1);
	}
}
