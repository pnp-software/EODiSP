/**
 * 
 */
package org.eodisp.wrapper.excel;

/**
 * Listener that informs about selections on a Excel Worksheet.
 * 
 * @author ibirrer
 *
 */
public interface SheetSelectionChangeListener {
	/**
	 * If the selection has changed.
	 * 
	 * @param range the newly selected range
	 */
	void selectionChanged(Range range);
}
