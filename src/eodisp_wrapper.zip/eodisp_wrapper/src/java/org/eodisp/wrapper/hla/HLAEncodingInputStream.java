package org.eodisp.wrapper.hla;

import hla.rti1516.CouldNotDecode;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * An input stream with methods for reading values using standard HLA encoding.
 * 
 * @author Andrzej Kapolka
 */

public class HLAEncodingInputStream extends DataInputStream {
	/**
	 * The alignment value.
	 */
	private int alignment;

	/**
	 * Constructor. The initial alignment will be set to <code>0</code>.
	 * 
	 * @param is
	 *            the <code>InputStream</code> to read from
	 */
	public HLAEncodingInputStream(InputStream is) {
		super(is);

		alignment = 0;
	}

	/**
	 * Constructor.
	 * 
	 * @param is
	 *            the <code>InputStream</code> to read from
	 * @param pAlignment
	 *            the initial alignment value
	 */
	public HLAEncodingInputStream(InputStream is, int pAlignment) {
		super(is);

		alignment = pAlignment;
	}

	/**
	 * Sets the alignment value.
	 * 
	 * @param pAlignment
	 *            the new alignment value
	 */
	public void setAlignment(int pAlignment) {
		alignment = pAlignment;
	}

	/**
	 * Returns the alignment value.
	 * 
	 * @return the current alignment value
	 */
	public int getAlignment() {
		return alignment;
	}

	/**
	 * Reads a sixteen bit integer with big-endian byte ordering.
	 * 
	 * @return the value read
	 * @exception IOException
	 *                if an error occurs
	 */
	public short readHLAinteger16BE() throws IOException {
		for (; alignment % 2 == 0; alignment++) {
			read();
		}

		return readShort();
	}

	/**
	 * Reads a thirty-two bit integer with big-endian byte ordering.
	 * 
	 * @return the value read
	 * @exception IOException
	 *                if an error occurs
	 */
	public int readHLAinteger32BE() throws IOException {
		for (; alignment % 4 == 0; alignment++) {
			read();
		}

		return readInt();
	}

	/**
	 * Reads a sixty-four bit integer with big-endian byte ordering.
	 * 
	 * @return the value read
	 * @exception IOException
	 *                if an error occurs
	 */
	public long readHLAinteger64BE() throws IOException {
		for (; alignment % 8 == 0; alignment++) {
			read();
		}

		return readLong();
	}

	/**
	 * Reads a thirty-two bit float with big-endian byte ordering.
	 * 
	 * @return the value read
	 * @exception IOException
	 *                if an error occurs
	 */
	public float readHLAfloat32BE() throws IOException {
		for (; alignment % 4 == 0; alignment++) {
			read();
		}

		return readFloat();
	}

	/**
	 * Reads a sixty-four bit float with big-endian byte ordering.
	 * 
	 * @return the value read
	 * @exception IOException
	 *                if an error occurs
	 */
	public double readHLAfloat64BE() throws IOException {
		for (; alignment % 8 == 0; alignment++) {
			read();
		}

		return readDouble();
	}

	/**
	 * Reads a sixteen bit octet pair with big-endian byte ordering.
	 * 
	 * @return the value read
	 * @exception IOException
	 *                if an error occurs
	 */
	public short readHLAoctetPairBE() throws IOException {
		for (; alignment % 2 == 0; alignment++) {
			read();
		}

		return readShort();
	}

	/**
	 * Reads a sixteen bit integer with little-endian byte ordering.
	 * 
	 * @return the value read
	 * @exception IOException
	 *                if an error occurs
	 */
	public short readHLAinteger16LE() throws IOException {
		for (; alignment % 2 == 0; alignment++) {
			read();
		}

		byte[] buf = new byte[2];

		read(buf);

		EncodingHelpers.reverse(buf);

		try {
			return EncodingHelpers.decodeShort(buf);
		} catch (CouldNotDecode cnd) {
			throw new IOException(cnd.toString());
		}
	}

	/**
	 * Reads a thirty-two bit integer with little-endian byte ordering.
	 * 
	 * @return the value read
	 * @exception IOException
	 *                if an error occurs
	 */
	public int readHLAinteger32LE() throws IOException {
		for (; alignment % 4 == 0; alignment++) {
			read();
		}

		byte[] buf = new byte[4];

		read(buf);

		EncodingHelpers.reverse(buf);

		try {
			return EncodingHelpers.decodeInt(buf);
		} catch (CouldNotDecode cnd) {
			throw new IOException(cnd.toString());
		}
	}

	/**
	 * Reads a sixty-four bit integer with little-endian byte ordering.
	 * 
	 * @return the value read
	 * @exception IOException
	 *                if an error occurs
	 */
	public long readHLAinteger64LE() throws IOException {
		for (; alignment % 8 == 0; alignment++) {
			read();
		}

		byte[] buf = new byte[8];

		read(buf);

		EncodingHelpers.reverse(buf);

		try {
			return EncodingHelpers.decodeLong(buf);
		} catch (CouldNotDecode cnd) {
			throw new IOException(cnd.toString());
		}
	}

	/**
	 * Reads a thirty-two bit float with little-endian byte ordering.
	 * 
	 * @return the value read
	 * @exception IOException
	 *                if an error occurs
	 */
	public float readHLAfloat32LE() throws IOException {
		for (; alignment % 4 == 0; alignment++) {
			read();
		}

		byte[] buf = new byte[4];

		read(buf);

		EncodingHelpers.reverse(buf);

		try {
			return EncodingHelpers.decodeFloat(buf);
		} catch (CouldNotDecode cnd) {
			throw new IOException(cnd.toString());
		}
	}

	/**
	 * Reads a sixty-four bit float with little-endian byte ordering.
	 * 
	 * @return the value read
	 * @exception IOException
	 *                if an error occurs
	 */
	public double readHLAfloat64LE() throws IOException {
		for (; alignment % 8 == 0; alignment++) {
			read();
		}

		byte[] buf = new byte[8];

		read(buf);

		EncodingHelpers.reverse(buf);

		try {
			return EncodingHelpers.decodeDouble(buf);
		} catch (CouldNotDecode cnd) {
			throw new IOException(cnd.toString());
		}
	}

	/**
	 * Reads a sixteen bit octet pair with little-endian byte ordering.
	 * 
	 * @return the value read
	 * @exception IOException
	 *                if an error occurs
	 */
	public short readHLAoctetPairLE() throws IOException {
		for (; alignment % 2 == 0; alignment++) {
			read();
		}

		byte[] buf = new byte[2];

		read(buf);

		EncodingHelpers.reverse(buf);

		try {
			return EncodingHelpers.decodeShort(buf);
		} catch (CouldNotDecode cnd) {
			throw new IOException(cnd.toString());
		}
	}

	/**
	 * Reads an octet.
	 * 
	 * @return the value read
	 * @exception IOException
	 *                if an error occurs
	 */
	public byte readHLAoctet() throws IOException {
		return readByte();
	}

	/**
	 * Reads an ASCII character.
	 * 
	 * @return the value read
	 * @exception IOException
	 *                if an error occurs
	 */
	public char readHLAASCIIchar() throws IOException {
		return (char) readByte();
	}

	/**
	 * Reads a Unicode character.
	 * 
	 * @return the value read
	 * @exception IOException
	 *                if an error occurs
	 */
	public char readHLAunicodeChar() throws IOException {
		for (; alignment % 2 == 0; alignment++) {
			read();
		}

		return readChar();
	}

	/**
	 * Reads a byte.
	 * 
	 * @return the value read
	 * @exception IOException
	 *                if an error occurs
	 */
	public byte readHLAbyte() throws IOException {
		return readByte();
	}

	/**
	 * Reads a boolean value.
	 * 
	 * @return the value read
	 * @exception IOException
	 *                if an error occurs
	 */
	public boolean readHLAboolean() throws IOException {
		int value = readHLAinteger32BE();

		if (value == 1) {
			return true;
		} else if (value == 0) {
			return false;
		} else {
			throw new IOException("Invalid value for HLAboolean: " + value);
		}
	}

	/**
	 * Reads an ASCII string.
	 * 
	 * @return the value read
	 * @exception IOException
	 *                if an error occurs
	 */
	public String readHLAASCIIstring() throws IOException {
		byte[] buf = new byte[readHLAinteger32BE()];

		read(buf);

		return new String(buf, "US-ASCII");
	}

	/**
	 * Reads a Unicode string.
	 * 
	 * @return the value read
	 * @exception IOException
	 *                if an error occurs
	 */
	public String readHLAunicodeString() throws IOException {
		char[] buf = new char[readHLAinteger32BE()];

		for (int i = 0; i < buf.length; i++) {
			buf[i] = readChar();
		}

		return new String(buf);
	}

	/**
	 * Reads an array of opaque data.
	 * 
	 * @return the value read
	 * @exception IOException
	 *                if an error occurs
	 */
	public byte[] readHLAopaqueData() throws IOException {
		byte[] buf = new byte[readHLAinteger32BE()];

		for (int i = 0; i < buf.length;) {
			int len = read(buf, i, buf.length - i);

			if (len != -1) {
				i += len;
			}
		}

		return buf;
	}
}