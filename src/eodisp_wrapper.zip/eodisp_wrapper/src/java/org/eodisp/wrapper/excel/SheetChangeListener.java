package org.eodisp.wrapper.excel;

/**
 * Listener that is informed about sheet changes.
 * 
 * @author ibirrer
 * @version $Id:$
 * 
 */
public interface SheetChangeListener {
	/**
	 * If the sheet changes one of its range values.
	 * 
	 * @param range the range that has changed.
	 */
	void sheetChanged(Range range);
}
