package org.eodisp.wrapper.hla;

import hla.rti1516.CouldNotDecode;

import java.io.*;

/**
 * Utility methods for encoding and decoding basic types, modeled after those
 * supplied with the DMSO RTI.
 * 
 * @author Andrzej Kapolka
 */

public class EncodingHelpers {
	/**
	 * Encodes the specified value, returning the result as a byte array.
	 * 
	 * @param value
	 *            the value to encode
	 * @return a byte array containing the encoded value
	 */
	public static byte[] encodeBoolean(boolean value) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream(1);
		DataOutputStream dos = new DataOutputStream(baos);

		try {
			dos.writeBoolean(value);
		} catch (IOException ioe) {
		}

		return baos.toByteArray();
	}

	/**
	 * Encodes the specified value, returning the result as a byte array.
	 * 
	 * @param value
	 *            the value to encode
	 * @return a byte array containing the encoded value
	 */
	public static byte[] encodeByte(byte value) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream(1);
		DataOutputStream dos = new DataOutputStream(baos);

		try {
			dos.writeByte(value);
		} catch (IOException ioe) {
		}

		return baos.toByteArray();
	}

	/**
	 * Encodes the specified value, returning the result as a byte array.
	 * 
	 * @param value
	 *            the value to encode
	 * @return a byte array containing the encoded value
	 */
	public static byte[] encodeChar(char value) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream(2);
		DataOutputStream dos = new DataOutputStream(baos);

		try {
			dos.writeChar(value);
		} catch (IOException ioe) {
		}

		return baos.toByteArray();
	}

	/**
	 * Encodes the specified value, returning the result as a byte array.
	 * 
	 * @param value
	 *            the value to encode
	 * @return a byte array containing the encoded value
	 */
	public static byte[] encodeDouble(double value) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream(8);
		DataOutputStream dos = new DataOutputStream(baos);

		try {
			dos.writeDouble(value);
		} catch (IOException ioe) {
		}

		return baos.toByteArray();
	}

	/**
	 * Encodes the specified value, returning the result as a byte array.
	 * 
	 * @param value
	 *            the value to encode
	 * @return a byte array containing the encoded value
	 */
	public static byte[] encodeFloat(float value) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream(4);
		DataOutputStream dos = new DataOutputStream(baos);

		try {
			dos.writeFloat(value);
		} catch (IOException ioe) {
		}

		return baos.toByteArray();
	}

	/**
	 * Encodes the specified value, returning the result as a byte array.
	 * 
	 * @param value
	 *            the value to encode
	 * @return a byte array containing the encoded value
	 */
	public static byte[] encodeInt(int value) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream(4);
		DataOutputStream dos = new DataOutputStream(baos);

		try {
			dos.writeInt(value);
		} catch (IOException ioe) {
		}

		return baos.toByteArray();
	}

	/**
	 * Encodes the specified value, returning the result as a byte array.
	 * 
	 * @param value
	 *            the value to encode
	 * @return a byte array containing the encoded value
	 */
	public static byte[] encodeLong(long value) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream(8);
		DataOutputStream dos = new DataOutputStream(baos);

		try {
			dos.writeLong(value);
		} catch (IOException ioe) {
		}

		return baos.toByteArray();
	}

	/**
	 * Encodes the specified value, returning the result as a byte array.
	 * 
	 * @param value
	 *            the value to encode
	 * @return a byte array containing the encoded value
	 */
	public static byte[] encodeShort(short value) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream(2);
		DataOutputStream dos = new DataOutputStream(baos);

		try {
			dos.writeShort(value);
		} catch (IOException ioe) {
		}

		return baos.toByteArray();
	}

	/**
	 * Encodes the specified value, returning the result as a byte array.
	 * 
	 * @param value
	 *            the value to encode
	 * @return a byte array containing the encoded value
	 */
	public static byte[] encodeString(String value) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(baos);

		try {
			dos.writeUTF(value);
		} catch (IOException ioe) {
		}

		return baos.toByteArray();
	}

	/**
	 * Decodes and returns the value stored in the specified buffer.
	 * 
	 * @param buffer
	 *            the buffer containing the encoded value
	 * @return the decoded value
	 * @exception CouldNotDecode
	 *                if the value could not be decoded
	 */
	public static boolean decodeBoolean(byte[] buffer) throws CouldNotDecode {
		ByteArrayInputStream bais = new ByteArrayInputStream(buffer);
		DataInputStream dis = new DataInputStream(bais);

		try {
			return dis.readBoolean();
		} catch (IOException ioe) {
			throw new CouldNotDecode("bad boolean");
		}
	}

	/**
	 * Decodes and returns the value stored in the specified buffer.
	 * 
	 * @param buffer
	 *            the buffer containing the encoded value
	 * @return the decoded value
	 * @exception CouldNotDecode
	 *                if the value could not be decoded
	 */
	public static byte decodeByte(byte[] buffer) throws CouldNotDecode {
		ByteArrayInputStream bais = new ByteArrayInputStream(buffer);
		DataInputStream dis = new DataInputStream(bais);

		try {
			return dis.readByte();
		} catch (IOException ioe) {
			throw new CouldNotDecode("bad byte");
		}
	}

	/**
	 * Decodes and returns the value stored in the specified buffer.
	 * 
	 * @param buffer
	 *            the buffer containing the encoded value
	 * @return the decoded value
	 * @exception CouldNotDecode
	 *                if the value could not be decoded
	 */
	public static char decodeChar(byte[] buffer) throws CouldNotDecode {
		ByteArrayInputStream bais = new ByteArrayInputStream(buffer);
		DataInputStream dis = new DataInputStream(bais);

		try {
			return dis.readChar();
		} catch (IOException ioe) {
			throw new CouldNotDecode("bad char");
		}
	}

	/**
	 * Decodes and returns the value stored in the specified buffer.
	 * 
	 * @param buffer
	 *            the buffer containing the encoded value
	 * @return the decoded value
	 * @exception CouldNotDecode
	 *                if the value could not be decoded
	 */
	public static double decodeDouble(byte[] buffer) throws CouldNotDecode {
		ByteArrayInputStream bais = new ByteArrayInputStream(buffer);
		DataInputStream dis = new DataInputStream(bais);

		try {
			return dis.readDouble();
		} catch (IOException ioe) {
			throw new CouldNotDecode("bad double");
		}
	}

	/**
	 * Decodes and returns the value stored in the specified buffer.
	 * 
	 * @param buffer
	 *            the buffer containing the encoded value
	 * @return the decoded value
	 * @exception CouldNotDecode
	 *                if the value could not be decoded
	 */
	public static float decodeFloat(byte[] buffer) throws CouldNotDecode {
		ByteArrayInputStream bais = new ByteArrayInputStream(buffer);
		DataInputStream dis = new DataInputStream(bais);

		try {
			return dis.readFloat();
		} catch (IOException ioe) {
			throw new CouldNotDecode("bad float");
		}
	}

	/**
	 * Decodes and returns the value stored in the specified buffer.
	 * 
	 * @param buffer
	 *            the buffer containing the encoded value
	 * @return the decoded value
	 * @exception CouldNotDecode
	 *                if the value could not be decoded
	 */
	public static int decodeInt(byte[] buffer) throws CouldNotDecode {
		ByteArrayInputStream bais = new ByteArrayInputStream(buffer);
		DataInputStream dis = new DataInputStream(bais);

		try {
			return dis.readInt();
		} catch (IOException ioe) {
			throw new CouldNotDecode("bad int");
		}
	}

	/**
	 * Decodes and returns the value stored in the specified buffer.
	 * 
	 * @param buffer
	 *            the buffer containing the encoded value
	 * @return the decoded value
	 * @exception CouldNotDecode
	 *                if the value could not be decoded
	 */
	public static long decodeLong(byte[] buffer) throws CouldNotDecode {
		ByteArrayInputStream bais = new ByteArrayInputStream(buffer);
		DataInputStream dis = new DataInputStream(bais);

		try {
			return dis.readLong();
		} catch (IOException ioe) {
			throw new CouldNotDecode("bad long");
		}
	}

	/**
	 * Decodes and returns the value stored in the specified buffer.
	 * 
	 * @param buffer
	 *            the buffer containing the encoded value
	 * @return the decoded value
	 * @exception CouldNotDecode
	 *                if the value could not be decoded
	 */
	public static short decodeShort(byte[] buffer) throws CouldNotDecode {
		ByteArrayInputStream bais = new ByteArrayInputStream(buffer);
		DataInputStream dis = new DataInputStream(bais);

		try {
			return dis.readShort();
		} catch (IOException ioe) {
			throw new CouldNotDecode("bad short");
		}
	}

	/**
	 * Decodes and returns the value stored in the specified buffer.
	 * 
	 * @param buffer
	 *            the buffer containing the encoded value
	 * @return the decoded value
	 * @exception CouldNotDecode
	 *                if the value could not be decoded
	 */
	public static String decodeString(byte[] buffer) throws CouldNotDecode {
		ByteArrayInputStream bais = new ByteArrayInputStream(buffer);
		DataInputStream dis = new DataInputStream(bais);

		try {
			return dis.readUTF();
		} catch (IOException ioe) {
			throw new CouldNotDecode("bad string");
		}
	}

	/**
	 * Reverses the specified byte array in-place.
	 * 
	 * @param buffer
	 *            the byte array to reverse
	 */
	public static void reverse(byte[] buffer) {
		byte tmp;

		for (int i = 0, j = buffer.length - 1; i < j; i++, j--) {
			tmp = buffer[i];

			buffer[i] = buffer[j];

			buffer[j] = tmp;
		}
	}
}