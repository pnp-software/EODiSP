/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.wrapper.excel;

import org.eclipse.swt.ole.win32.*;

/**
 * Represents a CommandButton in a Excel Worksheet.
 * 
 * 
 * @author ibirrer
 * @version $Id:$
 */
public class CommandButton {

	private final static String EVENT_CLSID = "{7B020EC1-AF6C-11CE-9F46-00AA00574A4F}";

	private final static int PROPERTY_ENABLED = 0x80010258;

	private final static int PROPERTY_NAME = 0x8001006e;

	private final static int EVENT_CLICK = 0xfffffda8;

	private final OleAutomation commandButton;

	private final OleControlSite controlSite;

	CommandButton(final OleAutomation commandButton, final OleControlSite controlSite) {
		this.commandButton = commandButton;
		this.controlSite = controlSite;
	}

	// Doesn' t work. Don't know why ...
	// public void addCommandButtonListener(final CommandButtonListener
	// listener) {
	// controlSite.addEventListener(commandButton, EVENT_CLSID, EVENT_CLICK, new
	// OleListener() {
	// public void handleEvent(OleEvent event) {
	// System.out.println("Click!");
	// listener.click();
	// }
	// });
	// }

	/**
	 * Enables or disables this button.
	 * 
	 * @param enabled
	 *            <code>true</code> to ebable.
	 */
	public void setEnabled(boolean enabled) {
		commandButton.setProperty(PROPERTY_ENABLED, new Variant(enabled));
	}

	/**
	 * Returns if this button is enabled or not.
	 * 
	 * @return <code>true</code> if this button is enabled.
	 */
	public boolean isEnabled() {
		return commandButton.getProperty(PROPERTY_ENABLED).getBoolean();
	}

	/**
	 * Returns the unique name of this button.
	 * 
	 * @return the unique name of this button.
	 */
	public String getName() {
		Variant var = commandButton.getProperty(PROPERTY_NAME);
		if (var == null) {
			return null;
		}
		return var.getString();
	}
}
