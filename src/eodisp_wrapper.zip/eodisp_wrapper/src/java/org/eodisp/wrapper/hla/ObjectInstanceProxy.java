package org.eodisp.wrapper.hla;

import java.util.concurrent.CountDownLatch;

import hla.rti1516.*;

/**
 * The base class of all object instance proxies.
 * 
 * @author Andrzej Kapolka
 * @author ibirrer
 */

public class ObjectInstanceProxy implements ObjectClassInstance {
	/**
	 * The run-time infrastructure ambassador.
	 */
	protected final RTIambassador rtiAmbassador;

	/**
	 * The object instance handle.
	 */
	private final ObjectInstanceHandle instanceHandle;

	/**
	 * The object class handle.
	 */
	private final ObjectClassHandle classHandle;

	/**
	 * The object name.
	 */
	private final String name;

	/**
	 * Whether or not automatic updating has been disabled.
	 */
	protected volatile boolean autoUpdateDisabled = true;

	/**
	 * Whether or not the object instance has been deleted.
	 */
	private volatile boolean deleted;
	
	/**
	 * Latch to prevent unseen updates
	 */
	protected final CountDownLatch listenerLatch = new CountDownLatch(1);

	/**
	 * Constructor for object instance proxies created in response to discovered
	 * objects.
	 * 
	 * @param pRTIAmbassador
	 *            the run-time infrastructure ambassador
	 * @param pInstanceHandle
	 *            the object instance handle
	 * @param pClassHandle
	 *            the object class handle
	 * @param pName
	 *            the object name
	 * @exception RTIinternalError
	 *                if an internal error occurred in the run-time
	 *                infrastructure
	 */
	protected ObjectInstanceProxy(RTIambassador pRTIAmbassador, ObjectInstanceHandle pInstanceHandle,
			ObjectClassHandle pClassHandle, String pName) {
		rtiAmbassador = pRTIAmbassador;
		instanceHandle = pInstanceHandle;
		classHandle = pClassHandle;
		name = pName;
	}

	/**
	 * Constructor for object instance proxies created to represent new locally
	 * owned objects. Automatically notifies the run-time infrastructure.
	 * 
	 * @param pRTIAmbassador
	 *            the run-time infrastructure ambassador
	 * @param pClassHandle
	 *            the object class handle
	 * @exception ObjectClassNotDefined
	 *                if the specified object class is not defined
	 * @exception ObjectClassNotPublished
	 *                if the specified object class is not published
	 * @exception FederateNotExecutionMember
	 *                if the federate is not a member of an execution
	 * @exception SaveInProgress
	 *                if a save operation is in progress
	 * @exception RestoreInProgress
	 *                if a restore operation is in progress
	 * @exception RTIinternalError
	 *                if an internal error occurred in the run-time
	 *                infrastructure
	 */
	protected ObjectInstanceProxy(RTIambassador pRTIAmbassador, ObjectClassHandle pClassHandle)
			throws ObjectClassNotDefined, ObjectClassNotPublished, FederateNotExecutionMember, SaveInProgress,
			RestoreInProgress, RTIinternalError {
		rtiAmbassador = pRTIAmbassador;
		classHandle = pClassHandle;

		instanceHandle = rtiAmbassador.registerObjectInstance(classHandle);

		try {
			name = rtiAmbassador.getObjectInstanceName(instanceHandle);
		} catch (ObjectInstanceNotKnown oink) {
			throw new RTIinternalError("object instance name could not be retrieved");
		}
	}

	/**
	 * Constructor for object instance proxies created to represent new locally
	 * owned objects. Automatically notifies the run-time infrastructure.
	 * 
	 * @param pRTIAmbassador
	 *            the run-time infrastructure ambassador
	 * @param pClassHandle
	 *            the object class handle
	 * @param pName
	 *            the object name
	 * @exception ObjectClassNotDefined
	 *                if the specified object class is not defined
	 * @exception ObjectClassNotPublished
	 *                if the specified object class is not published
	 * @exception IllegalName
	 *                if the instance name has is illegal
	 * @exception ObjectInstanceNameInUse
	 *                if the instance name is already in use
	 * @exception FederateNotExecutionMember
	 *                if the federate is not a member of an execution
	 * @exception SaveInProgress
	 *                if a save operation is in progress
	 * @exception RestoreInProgress
	 *                if a restore operation is in progress
	 * @exception RTIinternalError
	 *                if an internal error occurred in the run-time
	 *                infrastructure
	 */
	protected ObjectInstanceProxy(RTIambassador pRTIAmbassador, ObjectClassHandle pClassHandle, String pName)
			throws ObjectClassNotDefined, ObjectClassNotPublished, IllegalName, ObjectInstanceNameInUse,
			FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		rtiAmbassador = pRTIAmbassador;
		classHandle = pClassHandle;
		name = pName;

		rtiAmbassador.reserveObjectInstanceName(name);

		try {
			instanceHandle = rtiAmbassador.registerObjectInstance(classHandle, name);
		} catch (ObjectInstanceNameNotReserved oinnr) {
			throw new RTIinternalError("object instance name could not be reserved");
		}
	}

	/**
	 * Notifies the proxy of changes to the state of an object instance.
	 * 
	 * @param theAttributes
	 *            the map between attribute handles and the new values of the
	 *            identified attributes
	 * @param userSuppliedTag
	 *            a user-supplied tag associated with the state change
	 * @param sentOrdering
	 *            the type of ordering with which the update was sent
	 * @param theTransport
	 *            the type of transport associated with the update
	 * @param theTime
	 *            the logical time associated with the attribute update
	 * @param receivedOrdering
	 *            the type of ordering with which the update was received
	 * @param retractionHandle
	 *            the message retraction handle
	 * @param sentRegions
	 *            the set of region handles identifying the regions associated
	 *            with the attribute update
	 * @exception AttributeNotRecognized
	 *                if the attribute was not recognized
	 * @exception AttributeNotSubscribed
	 *                if the federate had not subscribed to the attribute
	 * @exception InvalidLogicalTime
	 *                if the specified logical time was invalid
	 * @exception FederateInternalError
	 *                if an error occurs in the federate
	 */
	public void notifyReflectAttributeValues(AttributeHandleValueMap theAttributes, byte[] userSuppliedTag,
			OrderType sentOrdering, TransportationType theTransport, LogicalTime theTime, OrderType receivedOrdering,
			MessageRetractionHandle retractionHandle, RegionHandleSet sentRegions) throws AttributeNotRecognized,
			AttributeNotSubscribed, InvalidLogicalTime, FederateInternalError {
		Object passel = createPassel();
		setPasselValues(passel, theAttributes);
		notifyListeners(passel, theAttributes);
	}

	/**
	 * Send updates of all modified attribute values to the federation.
	 * 
	 * @param userSuppliedTag
	 *            the user-supplied tag to associate with the update
	 * @exception ObjectInstanceNotKnown
	 *                if the object instance is unknown
	 * @exception AttributeNotDefined
	 *                if one of the attributes is undefined
	 * @exception AttributeNotOwned
	 *                if one of the attributes is not owned
	 * @exception FederateNotExecutionMember
	 *                if the federate is not a member of an execution
	 * @exception SaveInProgress
	 *                if a save operation is in progress
	 * @exception RestoreInProgress
	 *                if a restore operation is in progress
	 * @exception RTIinternalError
	 *                if an internal error occurred in the run-time
	 *                infrastructure
	 */
	public void updateAttributeValues(byte[] userSuppliedTag) throws ObjectInstanceNotKnown, AttributeNotDefined,
			AttributeNotOwned, FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError {
		updateAttributeValues(userSuppliedTag, false);
	}

	/**
	 * Send updates of all, or all modified attribute values to the federation.
	 * 
	 * @param userSuppliedTag
	 *            the user-supplied tag to associate with the update
	 * @param updateAll
	 *            if <code>true</code> provide updates for all attributes; if
	 *            <code>false</code>, only provide updates for the modified
	 *            ones
	 * @exception ObjectInstanceNotKnown
	 *                if the object instance is unknown
	 * @exception AttributeNotDefined
	 *                if one of the attributes is undefined
	 * @exception AttributeNotOwned
	 *                if one of the attributes is not owned
	 * @exception FederateNotExecutionMember
	 *                if the federate is not a member of an execution
	 * @exception SaveInProgress
	 *                if a save operation is in progress
	 * @exception RestoreInProgress
	 *                if a restore operation is in progress
	 * @exception RTIinternalError
	 *                if an internal error occurred in the run-time
	 *                infrastructure
	 */
	public void updateAttributeValues(byte[] userSuppliedTag, boolean updateAll) throws ObjectInstanceNotKnown,
			AttributeNotDefined, AttributeNotOwned, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
			RTIinternalError {
		AttributeHandleValueMap ahvm = rtiAmbassador.getAttributeHandleValueMapFactory().create(8);

		getAttributeValuesToUpdate(ahvm, updateAll);

		rtiAmbassador.updateAttributeValues(instanceHandle, ahvm, userSuppliedTag);
	}

	/**
	 * Places the attribute values to update into the specified map.
	 * 
	 * @param ahvm
	 *            the attribute handle value map to populate
	 * @param updateAll
	 *            if <code>true</code> provide updates for all attributes; if
	 *            <code>false</code>, only provide updates for the modified
	 *            ones
	 * @exception RTIinternalError
	 *                if an internal error occurs in the run-time infrastructure
	 */
	protected void getAttributeValuesToUpdate(AttributeHandleValueMap ahvm, boolean updateAll) throws RTIinternalError {
	}

	/**
	 * Returns a string representation of this object instance proxy.
	 * 
	 * @return a string representation of this object instance proxy
	 */
	@Override
	public String toString() {
		return name;
	}

	/**
	 * Return the object instance name.
	 * 
	 * @return the object instance name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Disables or enables auto-update behavior for this proxy.
	 * 
	 * @param autoUpdateDisabled
	 *            <code>true</code> to disable auto-update, <code>false</code>
	 *            to enable it
	 */
	public void setAutoUpdateDisabled(boolean autoUpdateDisabled) {
		this.autoUpdateDisabled = autoUpdateDisabled;
	}

	/**
	 * Checks whether auto-update behavior is disabled for this proxy. Default:
	 * <code>disabled</code>.
	 * 
	 * @return <code>true</code> if auto-update is disabled,
	 *         <code>false</code> otherwise
	 */
	public boolean isAutoUpdateDisabled() {
		return autoUpdateDisabled;
	}

	/**
	 * Deletes the object instance that this proxy represents. If the instance
	 * has already been deleted, this method has no effect.
	 * 
	 * @exception DeletePrivilegeNotHeld
	 *                if the delete privilege is not held
	 * @exception FederateNotExecutionMember
	 *                if the federate is not a member of an execution
	 * @exception SaveInProgress
	 *                if a save operation is in progress
	 * @exception RestoreInProgress
	 *                if a restore operation is in progress
	 * @exception RTIinternalError
	 *                if an internal error occurred in the run-time
	 *                infrastructure
	 */
	public void delete() throws DeletePrivilegeNotHeld, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
			RTIinternalError {
		if (deleted)
			return;

		try {
			rtiAmbassador.deleteObjectInstance(instanceHandle, new byte[0]);
		} catch (ObjectInstanceNotKnown oink) {
		}

		setDeleted(true);
	}

	/**
	 * Sets whether the object instance that this proxy represents has been
	 * deleted.
	 * 
	 * @param pDeleted
	 *            whether or not the object instance has been deleted
	 */
	protected void setDeleted(boolean pDeleted) {
		deleted = pDeleted;
	}

	/**
	 * Checks whether the object instance that this proxy represents has been
	 * deleted.
	 * 
	 * @return <code>true</code> if the object instance has been deleted,
	 *         <code>false</code> otherwise
	 */
	public boolean isDeleted() {
		return deleted;
	}

	public ObjectClassHandle getObjectClassHandle() {
		return classHandle;
	}

	public ObjectInstanceHandle getObjectInstanceHandle() {
		return instanceHandle;
	}

	public void notifyProvideAttributeValueUpdate(AttributeHandleSet theAttributes, byte[] userSuppliedTag)
			throws AttributeNotRecognized, AttributeNotOwned, FederateInternalError {
		try {
			updateAttributeValues(userSuppliedTag);
		} catch (RTIexception rtie) {
			// TODO
			rtie.printStackTrace();
		}
	}

	public void notifyRemoved(byte[] userSuppliedTag, OrderType sentOrdering, LogicalTime logicalTime,
			OrderType receivedOrdering, MessageRetractionHandle messageRetractionHandle) {
		deleted = true;
	}

	protected Object createPassel() {
		return null;
	}

	protected void setPasselValues(Object passel, AttributeHandleValueMap attributeHandleValueMap) {
	}

	protected void notifyListeners(Object passel, AttributeHandleValueMap attributeHandleValueMap) {

	}

	public void resetWaitForListener() {
			listenerLatch.countDown();
	}
}