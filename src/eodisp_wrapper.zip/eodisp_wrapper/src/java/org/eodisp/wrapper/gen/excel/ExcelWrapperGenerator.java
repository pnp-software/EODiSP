/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.wrapper.gen.excel;

import java.io.*;
import java.util.*;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eodisp.wrapper.excel.*;

/**
 * A wrapper generator for an Excel Workbook. It generates a Java class for each
 * Worksheet of an Excel Workbook.
 * 
 * <p>
 * Usage:
 * <code>java ExcelWrapperGenerator &lt;excelFile&gt; &lt;dest&gt; &lt;package&gt;</code>
 * 
 * <p>
 * <ul>
 * <li><b>excelFile:</b> The workbook file</li>
 * <li><b>dest:</b> The location where the Java classes should be genrated</li>
 * <li><b>package:</b> The Java package that the generated classes should
 * reside in.</li>
 * </ul>
 * 
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class ExcelWrapperGenerator {
	private final File srcDir;

	private static class CodePrintWriter extends PrintWriter {

		public CodePrintWriter(File file, String csn) throws FileNotFoundException, UnsupportedEncodingException {
			super(file, csn);
		}

		public CodePrintWriter(File file) throws FileNotFoundException {
			super(file);
		}

		public CodePrintWriter(OutputStream out, boolean autoFlush) {
			super(out, autoFlush);
		}

		public CodePrintWriter(OutputStream out) {
			super(out);
		}

		public CodePrintWriter(String fileName, String csn) throws FileNotFoundException, UnsupportedEncodingException {
			super(fileName, csn);
		}

		public CodePrintWriter(String fileName) throws FileNotFoundException {
			super(fileName);
		}

		public CodePrintWriter(Writer out, boolean autoFlush) {
			super(out, autoFlush);
		}

		public CodePrintWriter(Writer out) {
			super(out);
		}

		public void printfn(String format, Object... args) {
			printf(format + "%n", args);
		}

	}

	private static class WorksheetInfo {
		Worksheet worksheet;

		List<Range> namedRanges = new ArrayList<Range>();
	}

	public ExcelWrapperGenerator(File srcDir) {
		this.srcDir = srcDir;
	}

	/**
	 * <p>
	 * Usage:
	 * <code>java ExcelWrapperGenerator &lt;excelFile&gt; &lt;dest&gt; &lt;package&gt;</code>
	 * 
	 * <p>
	 * <ul>
	 * <li><b>excelFile:</b> The workbook file</li>
	 * <li><b>dest:</b> The location where the Java classes should be genrated</li>
	 * <li><b>package:</b> The Java package that the generated classes should
	 * reside in.</li>
	 * </ul>
	 * 
	 * @param args
	 *            &lt;excelFile&gt; &lt;dest&gt; &lt;package&gt;
	 */
	public static void main(String[] args) {
		if (args.length != 3) {
			System.out.println("Usage: java ExcelWrapperGenerator <excelFile> <dest> <package>");
		}
		try {
			File excelFile = new File(args[0]);
			File destDir = new File(args[1]);
			String packageName = args[2];

			System.out.println("excelFile: " + excelFile.getAbsolutePath());
			System.out.println("dest: " + destDir.getAbsolutePath());
			System.out.println("package: " + packageName);

			ExcelWrapperGenerator generator = new ExcelWrapperGenerator(destDir);
			generator.generateWorkbookClass(excelFile, packageName);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void generateWorkbookClass(File excelFile, String packageName) throws FileNotFoundException, IOException {
		if (!excelFile.exists()) {
			throw new RuntimeException(String.format("Could not open Excel workbook: %s", excelFile));
		}

		Display display = new Display();
		Shell shell = new Shell(display);
		ExcelApplication application = new ExcelApplication(shell);

		Workbook workbook = application.openWorkbook(excelFile, ExcelApplication.NEVER_UPDATE_LINKS, true);
		List<Range> names = workbook.getNamedRanges();
		Map<String, WorksheetInfo> worksheets = new HashMap<String, WorksheetInfo>();
		for (Range range : names) {
			String worksheetName = range.getWorksheet().getName();
			WorksheetInfo worksheetInfo = worksheets.get(worksheetName);
			if (worksheetInfo == null) {
				worksheetInfo = new WorksheetInfo();
				worksheets.put(worksheetName, worksheetInfo);
			}
			worksheetInfo.worksheet = range.getWorksheet();
			worksheetInfo.namedRanges.add(range);
		}

		for (WorksheetInfo worksheetInfo : worksheets.values()) {
			generateWorksheetClass(worksheetInfo.worksheet, packageName, worksheetInfo.namedRanges);
			generateButtonListenerInterface(worksheetInfo.worksheet, packageName);
		}

		application.quit();
		shell.dispose();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

	private void generateWorksheetClass(Worksheet worksheet, String packageName, List<Range> ranges) throws IOException {
		String path = packageName.replace(".", File.separator);
		String className = worksheet.getName() + "Worksheet";
		File classFile = new File(new File(srcDir, path), className + ".java");
		classFile.getParentFile().mkdirs();
		System.out.printf("Generate class file %s%n", classFile.getAbsolutePath());
		CodePrintWriter ps = new CodePrintWriter(classFile, "UTF-8");
		List<CommandButton> commandButtons = worksheet.getCommandButtons();
		ps.printfn("package %s;", packageName);
		ps.printfn("import org.eodisp.wrapper.excel.*;");
		ps.printfn("import org.eclipse.swt.ole.win32.*;");
		ps.printfn("import java.util.concurrent.CopyOnWriteArrayList;");
		ps.printfn("public class %s {", className);
		ps.printfn("    private Worksheet worksheet;");
		ps
				.printfn(
						"    private CopyOnWriteArrayList<%sButtonListener> buttonPressedListeners = new CopyOnWriteArrayList<%sButtonListener>();",
						className, className);
		ps.println();
		ps.printfn("    public %s(Worksheet worksheet) {", className);
		ps.printfn("        this.worksheet = worksheet;");
		ps.printfn("        worksheet.getWorkbook().addSheetChangeListener(new SheetChangeListener() {");
		ps.printfn("            public void sheetChanged(Range range) {");
		ps.printfn("            String rangeName = range.getName();");
		ps.printfn("                if (rangeName != null && rangeName.equals(\"BUTTON_ACTION\")) {");
		ps.printfn("                    String buttonId = range.getStringValue();");
		ps.printfn("                    CommandButton commandButton = %s.this.worksheet.getCommandButton(buttonId);",
				className);
		boolean firstIteration = true;

		for (CommandButton button : commandButtons) {
			String ifString = "else if";
			if (firstIteration) {
				ifString = "if";
				firstIteration = false;
			}
			ps.printfn("                %s(buttonId.equals(\"%s\")) {", ifString, button.getName());
			ps.printfn("                    for (%sButtonListener listener : buttonPressedListeners) {", className);
			ps.printfn("                        listener.%sPressed(commandButton);", decapitalizeFirstChar(button
					.getName()));
			ps.printfn("                    }");
			ps.printfn("                }");
		}
		ps.printfn("                }");
		ps.printfn("            }");
		ps.printfn("        });");
		ps.printfn("    }");
		ps.printfn("    public void addButtonPressedListener(%sButtonListener listener) {", className);
		ps.printfn("        buttonPressedListeners.add(listener);");
		ps.printfn("    }");
		for (Range range : ranges) {
			ps.printfn("    public Range get%s(){", capitalizeFirstChar(range.getName()));
			ps.printfn("        return worksheet.getRange(\"%s\");", range.getName());
			ps.printfn("    }");
		}

		for (CommandButton button : commandButtons) {
			ps.printfn("    public CommandButton get%s(){", capitalizeFirstChar(button.getName()));
			ps.printfn("        return worksheet.getCommandButton(\"%s\");", button.getName());
			ps.printfn("    }");
		}

		ps.printfn("    public Range getRange(String range) {");
		ps.printfn("        return worksheet.getRange(range);");
		ps.printfn("    }");

		ps.printfn("}");
		ps.close();
	}

	private void generateButtonListenerInterface(Worksheet worksheet, String packageName) throws IOException {
		String path = packageName.replace(".", File.separator);
		String interfaceName = worksheet.getName() + "WorksheetButtonListener";
		File classFile = new File(new File(srcDir, path), interfaceName + ".java");
		classFile.getParentFile().mkdirs();
		System.out.printf("Generate interface file %s%n", classFile.getAbsolutePath());
		CodePrintWriter ps = new CodePrintWriter(classFile, "UTF-8");
		ps.printfn("package %s;", packageName);
		ps.printfn("import org.eodisp.wrapper.excel.CommandButton;");
		ps.printfn("public interface %s {", interfaceName);
		List<CommandButton> commandButtons = worksheet.getCommandButtons();
		for (CommandButton button : commandButtons) {
			ps.printfn("    public void %sPressed(CommandButton commandButton);", decapitalizeFirstChar(button
					.getName()));
		}
		ps.printfn("}");
		ps.close();
	}

	private static String capitalizeFirstChar(String str) {
		if (str.length() == 0) {
			return str;
		}
		if (str.length() == 1) {
			return str.toUpperCase();
		}
		return str.substring(0, 1).toUpperCase() + str.substring(1);
	}

	private static String decapitalizeFirstChar(String str) {
		if (str.length() == 0) {
			return str;
		}
		if (str.length() == 1) {
			return str.toLowerCase();
		}
		return str.substring(0, 1).toLowerCase() + str.substring(1);
	}
}
