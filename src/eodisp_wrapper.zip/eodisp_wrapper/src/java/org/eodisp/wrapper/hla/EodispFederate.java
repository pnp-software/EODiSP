/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.wrapper.hla;

import static org.eodisp.wrapper.hla.FederationState.*;
import hla.rti1516.FederateInternalError;
import hla.rti1516.RTIambassador;
import hla.rti1516.RTIexception;
import hla.rti1516.jlc.NullFederateAmbassador;

import java.io.File;
import java.util.concurrent.CopyOnWriteArrayList;

import net.jcip.annotations.GuardedBy;

import org.apache.log4j.Logger;

/**
 * 
 * 
 * An EODiSP specific Federate superclass. It can be used as the superclass of a
 * generated federate class. It has the following default behaviour:
 * 
 * <ul>
 * <li>Achieves the EODISP_STEP, EODISP_PAUSE and EODISP_RESUME synchronization
 * points immediately without doing any action. </li>
 * </ul>
 * 
 * 
 * @author ibirrer
 * @version $Id:$
 * 
 */
public abstract class EodispFederate extends ProxyAmbassador {

	public class StandardFederationStateListener implements FederationStateListener {

		public void stateChanged(FederationState newState) {

		}

	}

	public static final String EODISP_INIT = "EODISP_INIT";

	public static final String EODISP_START = "EODISP_START";

	public static final String EODISP_STOP = "EODISP_STOP";

	public static final String EODISP_PAUSE = "EODISP_PAUSE";

	public static final String EODISP_RESUME = "EODISP_RESUME";

	public static final String EODISP_STEP = "EODISP_STEP";

	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	private final static Logger logger = Logger.getLogger(EodispFederate.class);

	private final String stateLock = "federationStateLock";

	@GuardedBy(stateLock)
	private FederationState state = FederationState.STARTED;

	public interface FederationStateListener {
		void stateChanged(FederationState newState);
	}

	private CopyOnWriteArrayList<FederationStateListener> stateListeners = new CopyOnWriteArrayList<FederationStateListener>();

	public void addFederationStateListener(FederationStateListener listener) {
		stateListeners.add(listener);
	}

	public void removeFederationStateListener(FederationStateListener listener) {
		stateListeners.remove(listener);
	}

	public EodispFederate(RTIambassador rtiAmbassador) {
		super(rtiAmbassador);
		getFederateAmbassadorDelegator().registerDelegate(new NullFederateAmbassador() {
			@Override
			public void announceSynchronizationPoint(String label, byte[] userSuppliedTag) throws FederateInternalError {
				if (label.equals(EODISP_INIT) || label.equals(EODISP_START) || label.equals(EODISP_STOP)) {
					return;
				}
				synchronized (stateLock) {
					try {
						getRtiAmbassador().synchronizationPointAchieved(label);
					} catch (RTIexception e) {
						setState(ERROR);
						logger.error("Error in EodispFederate while achieving sync point", e);
						return;
					}
					if (label.equals(EODISP_PAUSE)) {
						setState(PAUSING);
					} else if (label.equals(EODISP_RESUME)) {
						setState(RESUMING);
					} else if (label.equals(EODISP_STEP)) {
						setState(STEPPING);
					}
				}
			}

			@Override
			public void federationSynchronized(String label) throws FederateInternalError {
				if (label.equals(EODISP_INIT)) {
					return;
				} else if (label.equals(EODISP_START)) {
					return;
				} else if (label.equals(EODISP_STOP)) {
					return;
				} else if (label.equals(EODISP_PAUSE)) {
					setState(PAUSED);
				} else if (label.equals(EODISP_RESUME)) {
					setState(STARTED);
				} else if (label.equals(EODISP_STEP)) {
					setState(PAUSED);
				}
			}
		});
	}

	private void setState(FederationState newState) {
		synchronized (stateLock) {
			logger.info("EodispFederate sets state to " + newState);
			if (!state.isStateChangeAllowed(newState)) {
				logger.error(String.format("State change from %s to %s is not allowed", state, newState));
				state = ERROR;
				fireFederationStateListenerChanged();
				throw new IllegalStateException();
			}
			state = newState;
			fireFederationStateListenerChanged();
		}
	}

	private void fireFederationStateListenerChanged() {
		logger.debug("Federation Stated changed to " + state);
		synchronized (stateLock) {
			for (FederationStateListener listener : stateListeners) {
				listener.stateChanged(state);
			}
		}
	}

	public FederationState getState() {
		synchronized (stateLock) {
			return state;
		}
	}

	/**
	 * Returns the bundle path of this federate. The bundle path is to where the
	 * federate is installed on the model manager.
	 * 
	 * @return the bundle path of this federate.
	 */
	public static File getBundlePath() {
		return new File(System.getProperty("org.eodisp.bundle-path"));
	}

}
