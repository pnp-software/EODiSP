package org.eodisp.wrapper.hla;

import static java.util.concurrent.TimeUnit.SECONDS;
import hla.rti1516.*;
import hla.rti1516.jlc.NullFederateAmbassador;

import java.util.Collection;
import java.util.Collections;
import java.util.concurrent.*;

import net.jcip.annotations.GuardedBy;
import net.jcip.annotations.ThreadSafe;

import org.apache.log4j.Logger;

/**
 * Provides a facade (Facade Pattern) to the HLA interfaces
 * {@link RTIambassador} and {@link FederateAmbassador}. The HLA interfaces can
 * still be accessed directly if needed (See
 * {@link #getFederateAmbassadorDelegator()}).
 * 
 * @author Andrzej Kapolka
 * @author Iwan Birrer
 */

public abstract class ProxyAmbassador {
	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	private final static Logger logger = Logger.getLogger(ProxyAmbassador.class);

	/**
	 * The run-time infrastructure ambassador.
	 */
	protected final RTIambassador rtiAmbassador;

	private final FederateAmbassadorDelegator federateAmbassadorDelegator = new FederateAmbassadorDelegator();

	private final FederateAmbassador federateAmbassador = new NullFederateAmbassador() {
		/**
		 * Notifies the federate of changes to the state of an object instance.
		 * 
		 * @param theObject
		 *            the instance handle of the modified object
		 * @param theAttributes
		 *            the map between attribute handles and the new values of
		 *            the identified attributes
		 * @param userSuppliedTag
		 *            a user-supplied tag associated with the state change
		 * @param sentOrdering
		 *            the type of ordering with which the update was sent
		 * @param theTransport
		 *            the type of transport associated with the update
		 * @exception ObjectInstanceNotKnown
		 *                if the object instance is not known
		 * @exception AttributeNotRecognized
		 *                if the attribute was not recognized
		 * @exception AttributeNotSubscribed
		 *                if the federate had not subscribed to the attribute
		 * @exception FederateInternalError
		 *                if an error occurs in the federate
		 */
		@Override
		public void reflectAttributeValues(ObjectInstanceHandle objectInstanceHandle,
				AttributeHandleValueMap theAttributes, byte[] userSuppliedTag, OrderType sentOrdering,
				TransportationType theTransport) throws ObjectInstanceNotKnown, AttributeNotRecognized,
				AttributeNotSubscribed, FederateInternalError {
			try {
				reflectAttributeValues(objectInstanceHandle, theAttributes, userSuppliedTag, sentOrdering,
						theTransport, null, null, null, null);
			} catch (InvalidLogicalTime e) {
				throw new FederateInternalError(
						"Object instance may not throw 'InvalidLogicalTime' if the logical time paramater is 'null'", e);
			}
		}

		/**
		 * Notifies the federate of changes to the state of an object instance.
		 * 
		 * @param theObject
		 *            the instance handle of the modified object
		 * @param theAttributes
		 *            the map between attribute handles and the new values of
		 *            the identified attributes
		 * @param userSuppliedTag
		 *            a user-supplied tag associated with the state change
		 * @param sentOrdering
		 *            the type of ordering with which the update was sent
		 * @param theTransport
		 *            the type of transport associated with the update
		 * @param sentRegions
		 *            the set of region handles identifying the regions
		 *            associated with the attribute update
		 * @exception ObjectInstanceNotKnown
		 *                if the object instance is not known
		 * @exception AttributeNotRecognized
		 *                if the attribute was not recognized
		 * @exception AttributeNotSubscribed
		 *                if the federate had not subscribed to the attribute
		 * @exception FederateInternalError
		 *                if an error occurs in the federate
		 */
		@Override
		public void reflectAttributeValues(ObjectInstanceHandle objectInstanceHandle,
				AttributeHandleValueMap theAttributes, byte[] userSuppliedTag, OrderType sentOrdering,
				TransportationType theTransport, RegionHandleSet sentRegions) throws ObjectInstanceNotKnown,
				AttributeNotRecognized, AttributeNotSubscribed, FederateInternalError {
			try {
				reflectAttributeValues(objectInstanceHandle, theAttributes, userSuppliedTag, sentOrdering,
						theTransport, null, null, null, sentRegions);
			} catch (InvalidLogicalTime e) {
				throw new FederateInternalError(
						"Object instance may not throw 'InvalidLogicalTime' if the logical time paramater is 'null'", e);
			}
		}

		@Override
		public void receiveInteraction(InteractionClassHandle interactionClass, ParameterHandleValueMap theParameters,
				byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport)
				throws InteractionClassNotRecognized, InteractionParameterNotRecognized, InteractionClassNotSubscribed,
				FederateInternalError {
			notifyReceiveInteraction(interactionClass, theParameters, userSuppliedTag, sentOrdering, theTransport);
		}

		/**
		 * Notifies the federate of changes to the state of an object instance.
		 * 
		 * @param theObject
		 *            the instance handle of the modified object
		 * @param theAttributes
		 *            the map between attribute handles and the new values of
		 *            the identified attributes
		 * @param userSuppliedTag
		 *            a user-supplied tag associated with the state change
		 * @param sentOrdering
		 *            the type of ordering with which the update was sent
		 * @param theTransport
		 *            the type of transport associated with the update
		 * @param theTime
		 *            the logical time associated with the attribute update
		 * @param receivedOrdering
		 *            the type of ordering with which the update was received
		 * @exception ObjectInstanceNotKnown
		 *                if the object instance is not known
		 * @exception AttributeNotRecognized
		 *                if the attribute was not recognized
		 * @exception AttributeNotSubscribed
		 *                if the federate had not subscribed to the attribute
		 * @exception FederateInternalError
		 *                if an error occurs in the federate
		 */
		@Override
		public void reflectAttributeValues(ObjectInstanceHandle objectInstanceHandle,
				AttributeHandleValueMap theAttributes, byte[] userSuppliedTag, OrderType sentOrdering,
				TransportationType theTransport, LogicalTime theTime, OrderType receivedOrdering)
				throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotSubscribed, FederateInternalError {
			try {
				reflectAttributeValues(objectInstanceHandle, theAttributes, userSuppliedTag, sentOrdering,
						theTransport, theTime, receivedOrdering, null, null);
			} catch (InvalidLogicalTime e) {
				throw new FederateInternalError(
						"Object instance may not throw 'InvalidLogicalTime' if the logical time paramater is 'null'", e);
			}
		}

		/**
		 * Notifies the federate of changes to the state of an object instance.
		 * 
		 * @param theObject
		 *            the instance handle of the modified object
		 * @param theAttributes
		 *            the map between attribute handles and the new values of
		 *            the identified attributes
		 * @param userSuppliedTag
		 *            a user-supplied tag associated with the state change
		 * @param sentOrdering
		 *            the type of ordering with which the update was sent
		 * @param theTransport
		 *            the type of transport associated with the update
		 * @param theTime
		 *            the logical time associated with the attribute update
		 * @param receivedOrdering
		 *            the type of ordering with which the update was received
		 * @param sentRegions
		 *            the set of region handles identifying the regions
		 *            associated with the attribute update
		 * @exception ObjectInstanceNotKnown
		 *                if the object instance is not known
		 * @exception AttributeNotRecognized
		 *                if the attribute was not recognized
		 * @exception AttributeNotSubscribed
		 *                if the federate had not subscribed to the attribute
		 * @exception FederateInternalError
		 *                if an error occurs in the federate
		 */
		@Override
		public void reflectAttributeValues(ObjectInstanceHandle objectInstanceHandle,
				AttributeHandleValueMap theAttributes, byte[] userSuppliedTag, OrderType sentOrdering,
				TransportationType theTransport, LogicalTime theTime, OrderType receivedOrdering,
				RegionHandleSet sentRegions) throws ObjectInstanceNotKnown, AttributeNotRecognized,
				AttributeNotSubscribed, FederateInternalError {
			try {
				reflectAttributeValues(objectInstanceHandle, theAttributes, userSuppliedTag, sentOrdering,
						theTransport, theTime, receivedOrdering, null, sentRegions);
			} catch (InvalidLogicalTime e) {
				throw new FederateInternalError(
						"Object instance may not throw 'InvalidLogicalTime' if the logical time paramater is 'null'", e);
			}
		}

		/**
		 * Notifies the federate of changes to the state of an object instance.
		 * 
		 * @param objectInstanceHandle
		 *            the instance handle of the modified object
		 * @param theAttributes
		 *            the map between attribute handles and the new values of
		 *            the identified attributes
		 * @param userSuppliedTag
		 *            a user-supplied tag associated with the state change
		 * @param sentOrdering
		 *            the type of ordering with which the update was sent
		 * @param theTransport
		 *            the type of transport associated with the update
		 * @param theTime
		 *            the logical time associated with the attribute update
		 * @param receivedOrdering
		 *            the type of ordering with which the update was received
		 * @param retractionHandle
		 *            the message retraction handle
		 * @exception ObjectInstanceNotKnown
		 *                if the object instance is not known
		 * @exception AttributeNotRecognized
		 *                if the attribute was not recognized
		 * @exception AttributeNotSubscribed
		 *                if the federate had not subscribed to the attribute
		 * @exception InvalidLogicalTime
		 *                if the specified logical time was invalid
		 * @exception FederateInternalError
		 *                if an error occurs in the federate
		 */
		@Override
		public void reflectAttributeValues(ObjectInstanceHandle objectInstanceHandle,
				AttributeHandleValueMap theAttributes, byte[] userSuppliedTag, OrderType sentOrdering,
				TransportationType theTransport, LogicalTime theTime, OrderType receivedOrdering,
				MessageRetractionHandle retractionHandle) throws ObjectInstanceNotKnown, AttributeNotRecognized,
				AttributeNotSubscribed, InvalidLogicalTime, FederateInternalError {
			reflectAttributeValues(objectInstanceHandle, theAttributes, userSuppliedTag, sentOrdering, theTransport,
					theTime, receivedOrdering, retractionHandle, null);
		}

		/**
		 * Notifies the federate of changes to the state of an object instance.
		 * 
		 * @param theObject
		 *            the instance handle of the modified object
		 * @param theAttributes
		 *            the map between attribute handles and the new values of
		 *            the identified attributes
		 * @param userSuppliedTag
		 *            a user-supplied tag associated with the state change
		 * @param sentOrdering
		 *            the type of ordering with which the update was sent
		 * @param theTransport
		 *            the type of transport associated with the update
		 * @param theTime
		 *            the logical time associated with the attribute update
		 * @param receivedOrdering
		 *            the type of ordering with which the update was received
		 * @param retractionHandle
		 *            the message retraction handle
		 * @param sentRegions
		 *            the set of region handles identifying the regions
		 *            associated with the attribute update
		 * @exception ObjectInstanceNotKnown
		 *                if the object instance is not known
		 * @exception AttributeNotRecognized
		 *                if the attribute was not recognized
		 * @exception AttributeNotSubscribed
		 *                if the federate had not subscribed to the attribute
		 * @exception InvalidLogicalTime
		 *                if the specified logical time was invalid
		 * @exception FederateInternalError
		 *                if an error occurs in the federate
		 */
		@Override
		public void reflectAttributeValues(ObjectInstanceHandle objectInstanceHandle,
				AttributeHandleValueMap theAttributes, byte[] userSuppliedTag, OrderType sentOrdering,
				TransportationType theTransport, LogicalTime theTime, OrderType receivedOrdering,
				MessageRetractionHandle retractionHandle, RegionHandleSet sentRegions) throws ObjectInstanceNotKnown,
				AttributeNotRecognized, AttributeNotSubscribed, InvalidLogicalTime, FederateInternalError {
			notifyObjectInstanceDiscovery(objectInstanceHandle, null, null);

			if (objectInstances.containsKey(objectInstanceHandle)) {
				ObjectClassInstance objectClassInstance = objectInstances.get(objectInstanceHandle);
				objectClassInstance.notifyReflectAttributeValues(theAttributes, userSuppliedTag, sentOrdering,
						theTransport, theTime, receivedOrdering, retractionHandle, sentRegions);
			} else {
				logger.error("Reflect attribute values not processed. No instance registered for handle: "
						+ objectInstanceHandle);
			}
		}

		/**
		 * Notifies the federate that an object instance has been removed.
		 * 
		 * @param theObject
		 *            the instance handle associated with the object
		 * @param userSuppliedTag
		 *            a user-supplied tag associated with the removal operation
		 * @param sentOrdering
		 *            the type of ordering with which the interaction was sent
		 * @exception ObjectInstanceNotKnown
		 *                if the object instance was unknown
		 * @exception FederateInternalError
		 *                if an error occurs in the federate
		 */
		@Override
		public void removeObjectInstance(ObjectInstanceHandle objectInstanceHandle, byte[] userSuppliedTag,
				OrderType sentOrdering) throws ObjectInstanceNotKnown, FederateInternalError {
			try {
				removeObjectInstance(objectInstanceHandle, userSuppliedTag, sentOrdering, null, null, null);
			} catch (InvalidLogicalTime e) {
				throw new FederateInternalError(
						"Object instance may not throw 'InvalidLogicalTime' if the logical time paramater is 'null'", e);
			}
		}

		/**
		 * Notifies the federate that an object instance has been removed.
		 * 
		 * @param theObject
		 *            the instance handle associated with the object
		 * @param userSuppliedTag
		 *            a user-supplied tag associated with the removal operation
		 * @param sentOrdering
		 *            the type of ordering with which the interaction was sent
		 * @param theTime
		 *            the logical time associated with the removal operation
		 * @param receivedOrdering
		 *            the type of ordering with which the interaction was
		 *            received
		 * @exception ObjectInstanceNotKnown
		 *                if the object instance was unknown
		 * @exception FederateInternalError
		 *                if an error occurs in the federate
		 */
		@Override
		public void removeObjectInstance(ObjectInstanceHandle objectInstanceHandle, byte[] userSuppliedTag,
				OrderType sentOrdering, LogicalTime theTime, OrderType receivedOrdering) throws ObjectInstanceNotKnown,
				FederateInternalError {
			try {
				removeObjectInstance(objectInstanceHandle, userSuppliedTag, sentOrdering, theTime, receivedOrdering,
						null);
			} catch (InvalidLogicalTime e) {
				throw new FederateInternalError(
						"Object instance may not throw 'InvalidLogicalTime' if the logical time paramater is 'null'", e);
			}
		}

		/**
		 * Notifies the federate that an object instance has been removed.
		 * 
		 * @param theObject
		 *            the instance handle associated with the object
		 * @param userSuppliedTag
		 *            a user-supplied tag associated with the removal operation
		 * @param sentOrdering
		 *            the type of ordering with which the interaction was sent
		 * @param theTime
		 *            the logical time associated with the removal operation
		 * @param receivedOrdering
		 *            the type of ordering with which the interaction was
		 *            received
		 * @param retractionHandle
		 *            the message retraction handle associated with the
		 *            interaction
		 * @exception ObjectInstanceNotKnown
		 *                if the object instance was unknown
		 * @exception InvalidLogicalTime
		 *                if the specified logical time was invalid
		 * @exception FederateInternalError
		 *                if an error occurs in the federate
		 */
		@Override
		public void removeObjectInstance(ObjectInstanceHandle objectInstanceHandle, byte[] userSuppliedTag,
				OrderType sentOrdering, LogicalTime theTime, OrderType receivedOrdering,
				MessageRetractionHandle retractionHandle) throws ObjectInstanceNotKnown, InvalidLogicalTime,
				FederateInternalError {
			ObjectClassInstance objectClassInstance = objectInstances.remove(objectInstanceHandle);
			if (objectClassInstance != null) {
				objectClassInstance.notifyRemoved(userSuppliedTag, sentOrdering, theTime, receivedOrdering,
						retractionHandle);
			}
		}

		/**
		 * Notifies the federate that it should provide an update regarding a
		 * set of object attributes.
		 * 
		 * @param theObject
		 *            the handle of the object instance whose attributes should
		 *            be sent
		 * @param theAttributes
		 *            the set of attribute handles identifying the attributes
		 *            that should be sent
		 * @exception ObjectInstanceNotKnown
		 *                if the object instance was unknown
		 * @exception AttributeNotRecognized
		 *                if an identified attribute was not recognized
		 * @exception AttributeNotOwned
		 *                if the federate did not own a specified attribute
		 * @exception FederateInternalError
		 *                if an error occurs in the federate
		 */
		@Override
		public void provideAttributeValueUpdate(ObjectInstanceHandle objectInstanceHandle,
				AttributeHandleSet theAttributes, byte[] userSuppliedTag) throws ObjectInstanceNotKnown,
				AttributeNotRecognized, AttributeNotOwned, FederateInternalError {
			ObjectClassInstance objectClassInstance = objectInstances.get(objectInstanceHandle);
			if (objectClassInstance != null) {
				objectClassInstance.notifyProvideAttributeValueUpdate(theAttributes, userSuppliedTag);
			}
		}

		/**
		 * Creates a new {@link ObjectClassInstance} for each object class
		 * instance discovered and adds it to the list of known instances. The
		 * implementation classes of the are determined by the registered
		 * {@link DiscoveredObjectClassInstanceFactory} factory.
		 * 
		 * @param objectInstanceHandle
		 *            the instance handle of the newly discovered object
		 * @param objectClassHandle
		 *            the class handle of the newly discovered object
		 * @param instanceName
		 *            the name of the newly discovered object class instance
		 * @exception CouldNotDiscover
		 *                if the object could not be discovered
		 * @exception ObjectClassNotRecognized
		 *                if the object class was not recognized
		 * @exception FederateInternalError
		 *                if an error occurs in the federate
		 */
		@Override
		public void discoverObjectInstance(ObjectInstanceHandle objectInstanceHandle,
				ObjectClassHandle objectClassHandle, String instanceName) throws CouldNotDiscover,
				ObjectClassNotRecognized, FederateInternalError {
			if (discoveredObjectClassInstanceFactory == null) {
				throw new IllegalStateException("DiscoveredObjectClassInstanceFactory has not been initialized!");
			}
			logger.info(String.format("Discovered %s", instanceName));
			notifyObjectInstanceDiscovery(objectInstanceHandle, objectClassHandle, instanceName);

		}

		private void notifyObjectInstanceDiscovery(ObjectInstanceHandle objectInstanceHandle,
				ObjectClassHandle objectClassHandle, String instanceName) throws FederateInternalError {

			if (objectInstances.containsKey(objectInstanceHandle)) {
				logger.debug(String.format("Object instance %s already discovered", objectInstanceHandle));
				return;
			}

			ObjectClassInstance objectClassInstance;
			try {
				try {

					if (objectClassHandle == null) {
						objectClassHandle = rtiAmbassador.getKnownObjectClassHandle(objectInstanceHandle);
					}

					if (instanceName == null) {
						instanceName = rtiAmbassador.getObjectInstanceName(objectInstanceHandle);
					}
				} catch (RTIexception e) {
					logger.error(e.getMessage(), e);
					throw new FederateInternalError(e.getMessage());
				}

				objectClassInstance = discoveredObjectClassInstanceFactory.newDiscoveredObjectClassInstance(
						rtiAmbassador, objectInstanceHandle, objectClassHandle, instanceName);
			} catch (RTIinternalError e1) {
				throw new FederateInternalError(e1.getMessage());
			}
			if (objectClassHandle != null) {

				if (objectInstances.putIfAbsent(objectInstanceHandle, objectClassInstance) == null) {
					for (ObjectClassDiscoveryListener listener : objectClassDiscoveryListeners) {
						listener.objectInstanceDiscovered(objectClassInstance);
						objectClassInstance.resetWaitForListener();
					}
				}
			} else {
				logger.warn(String.format("Discovered unknown object class instance: %s", instanceName));
			}
		}

		@Override
		public void synchronizationPointRegistrationSucceeded(String synchronizationPointLabel)
				throws FederateInternalError {
			SyncPointRegistrationState syncPointState = syncPointsWaitingForRegistration.get(synchronizationPointLabel);
			if (syncPointState == null) {
				logger.warn(String.format(
						"Received a 'synchronizationPointRegistrationSucceeded' for a synchronization point "
								+ "that has not been registered through the [%s] class. ", ProxyAmbassador.this
								.getClass()));
				return;
			}
			syncPointState.setRegistrationState(null);
		}

		@Override
		public void synchronizationPointRegistrationFailed(String synchronizationPointLabel,
				SynchronizationPointFailureReason reason) throws FederateInternalError {
			SyncPointRegistrationState syncPointState = syncPointsWaitingForRegistration.get(synchronizationPointLabel);
			if (syncPointState == null) {
				logger.warn(String.format(
						"Received a 'synchronizationPointRegistrationFailed' for a synchronization point "
								+ "that has not been registered through the [%s] class. ", ProxyAmbassador.this
								.getClass()));
				return;
			}
			syncPointState.setRegistrationState(reason);
		}

		@Override
		public void federationSynchronized(String syncPointLabel) throws FederateInternalError {
			SyncPointState syncPointState = getSyncPointState(syncPointLabel);
			syncPointState.setSynchronized();
		}

		@Override
		public void announceSynchronizationPoint(String synchronizationPointLabel, byte[] userSuppliedTag)
				throws FederateInternalError {
			logger.debug(String.format("Synchronization point %s has been announced", synchronizationPointLabel));
			final SyncPointState syncPointState = getSyncPointState(synchronizationPointLabel);
			if (syncPointState.isAnnounced()) {
				/*
				 * Wait for 2 seconds and try again. This is to wait for
				 * federateSynchronized() method call which could haven been
				 * overtaken on the network from the announce call.
				 */
				logger
						.warn(String
								.format(
										"The synchronization point %s has been announced a second time before it synchronized. Try again in 2 seconds.",
										synchronizationPointLabel));
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// restore interrupted status
					Thread.currentThread().interrupt();
				}
				if (syncPointState.isAnnounced()) {
					/*
					 * We could even wait for longer but most probably the
					 * federationSynchronized will never reach this federate. We
					 * print a fatal error and exit.
					 */
					logger
							.fatal(String
									.format(
											"The synchronization point %s has been announced a second time before it "
													+ "synchronized, even after waiting for 2 seconds. Destroy this federate and exit the Java Virtual Machine.",
											synchronizationPointLabel));
					/*
					 * We could only print the fatal error message without
					 * exiting the JVM. But then the chance that somebody who
					 * started this federate from remote will see the fatal
					 * error is less likely.
					 */
					System.exit(-1);
				}

			}
			syncPointState.setAnnounced();
		}
	};

	@ThreadSafe
	private class SyncPointState {

		@GuardedBy("this")
		private CountDownLatch federationSynchronizedLatch = new CountDownLatch(1);

		@GuardedBy("this")
		private CountDownLatch federationAnnouncedLatch = new CountDownLatch(1);

		private final String label;

		@GuardedBy("this")
		private boolean achieved;

		@GuardedBy("this")
		private boolean announced;

		public SyncPointState(String syncPointLabel) {
			this.label = syncPointLabel;
		}

		public synchronized boolean isAnnounced() {
			return announced;
		}

		public synchronized void setAnnounced() {
			if (announced) {
				throw new IllegalStateException(String.format("Tried to announce the sync point %s twice", label));
			}
			logger.debug(String.format("Announced synchronization point '%s'", label));
			announced = true;
			federationAnnouncedLatch.countDown();
		}

		public synchronized void setSynchronized() {
			if (!announced) {
				throw new IllegalStateException(String.format("Tried to set the sync point %s synchronized, "
						+ "even though the synchronization Point has never been announced", label));
			}
			logger.debug(String.format("Federation synchronized at synchronization point '%s'", label));
			federationSynchronizedLatch.countDown();
			federationSynchronizedLatch = new CountDownLatch(1);
			federationAnnouncedLatch = new CountDownLatch(1);
			achieved = false;
			announced = false;
		}

		public boolean awaitSynchronization(long timeout, TimeUnit unit) throws InterruptedException,
				SynchronizationPointLabelNotAnnounced, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
				RTIinternalError {
			awaitAnnouncement(timeout, unit);
			CountDownLatch localLatch;
			synchronized (this) {
				localLatch = federationSynchronizedLatch;
				/*
				 * achieve sync point if not yet done so, TODO: What happens if
				 * the sync point has already been achieved from outside?
				 */
				if (!achieved) {
					rtiAmbassador.synchronizationPointAchieved(label);
					achieved = true;
				}
			}

			return localLatch.await(timeout, unit);
		}

		public boolean awaitAnnouncement(long timeout, TimeUnit unit) throws InterruptedException {
			CountDownLatch localLatch;
			synchronized (this) {
				localLatch = federationAnnouncedLatch;
			}
			return localLatch.await(timeout, unit);
		}
	}

	class SyncPointRegistrationState {
		private final String label;

		private volatile SynchronizationPointFailureReason registrationState;

		private final CountDownLatch registeredCountdownLatch = new CountDownLatch(1);

		public SyncPointRegistrationState(String syncPointLabel) {
			this.label = syncPointLabel;
		}

		public void setRegistrationState(SynchronizationPointFailureReason reason) {
			this.registrationState = reason;
			registeredCountdownLatch.countDown();
		}

		/**
		 * @return <code>null</code> if registration succeeded, otherwise the
		 *         reason why it did not succeed.
		 */
		public SynchronizationPointFailureReason getRegistrationState() {
			return registrationState;
		}

		/**
		 * Waits for an answer from the RTI to the registration request.
		 * 
		 * @return <tt>true</tt> if the we got a response from the RTI and
		 *         <tt>false</tt> if the waiting time elapsed before the RTI
		 *         sent a response.
		 * @param timeout
		 *            the maximum time to wait
		 * @param unit
		 *            the time unit of the <tt>timeout</tt> argument.
		 * @throws InterruptedException
		 *             if the current thread is interrupted while waiting.
		 */
		boolean awaitRegistrationAnswer(long timeout, TimeUnit unit) throws InterruptedException {
			return registeredCountdownLatch.await(timeout, unit);
		}
	}

	/**
	 * Active synchronization points are synchronization points which have been
	 * announced by the RTI and have not yet been synchronized. i.e. the
	 * {@link FederateAmbassador#federationSynchronized(String)} has not yet
	 * been called for that synchronization point.
	 */
	private final ConcurrentHashMap<String, SyncPointState> activeSyncPoints = new ConcurrentHashMap<String, SyncPointState>();

	private final ConcurrentHashMap<String, SyncPointRegistrationState> syncPointsWaitingForRegistration = new ConcurrentHashMap<String, SyncPointRegistrationState>();

	/**
	 * The list of object class discovery listeners
	 */
	private final CopyOnWriteArrayList<ObjectClassDiscoveryListener> objectClassDiscoveryListeners = new CopyOnWriteArrayList<ObjectClassDiscoveryListener>();

	/**
	 * When discovering a new object class instance, a new java instance for
	 * that object class instance is being created. This factory determines the
	 * implementation classes of these instance.
	 * <p>
	 * If an object class is discovered that has no corresponding factory, a
	 * dynamic object class instance is being created. (TODO)
	 */
	private DiscoveredObjectClassInstanceFactory discoveredObjectClassInstanceFactory = null;

	/**
	 * Object instances known by this federate. Either by discovering or by
	 * registering.
	 */
	private final ConcurrentHashMap<ObjectInstanceHandle, ObjectClassInstance> objectInstances = new ConcurrentHashMap<ObjectInstanceHandle, ObjectClassInstance>();

	private volatile FederateHandle federatHandle;

	/**
	 * Constructor.
	 * 
	 * @param pRTIAmbassador
	 *            the run-time infrastructure ambassador
	 * @param discoveredObjectClassInstanceFactory
	 *            The factory that creates the appropriate java instances for
	 *            each object class instance discovered.
	 */
	public ProxyAmbassador(RTIambassador rtiAmbassador) {
		this.rtiAmbassador = rtiAmbassador;
		this.federateAmbassadorDelegator.registerDelegate(federateAmbassador);
	}

	protected void notifyReceiveInteraction(InteractionClassHandle interactionClass,
			ParameterHandleValueMap theParameters, byte[] userSuppliedTag, OrderType sentOrdering,
			TransportationType theTransport) throws InteractionClassNotRecognized, InteractionParameterNotRecognized,
			InteractionClassNotSubscribed, FederateInternalError {
	}

	public void setDiscoveredObjectClassInstanceFactory(
			DiscoveredObjectClassInstanceFactory discoveredObjectClassInstanceFactory) {
		this.discoveredObjectClassInstanceFactory = discoveredObjectClassInstanceFactory;
	}

	/**
	 * Returns the federate ambassador delegator that is used when joining a
	 * federation execution. This delegator already contains one federate
	 * ambassador delegate, the one that is used internally by this class.
	 * Additional federate ambassador delegates can be added to receive all the
	 * callbacks from the RTI. Just add a {@link FederateAmbassador} instance to
	 * the returned delegator with
	 * {@link FederateAmbassadorDelegator#registerDelegate(FederateAmbassador)}.
	 * This can be done at any time. If you want to receive all callbacks, add
	 * the delegate before you call
	 * {@link #joinFederationExecution(String, String, MobileFederateServices)}.
	 * 
	 * @return the federate ambassador delegator that is used when joining a
	 *         federation execution.
	 */
	public FederateAmbassadorDelegator getFederateAmbassadorDelegator() {
		return federateAmbassadorDelegator;
	}

	/**
	 * Adds an element to the list of objects interested in discovered object
	 * instances
	 * 
	 * @param objectClassDiscoveryListener
	 *            the listener to add
	 */
	public void addObjectClassDiscoveryListener(ObjectClassDiscoveryListener objectClassDiscoveryListener) {
		objectClassDiscoveryListeners.add(objectClassDiscoveryListener);
	}

	/**
	 * Removes an element from the list of objects interested in discovered
	 * object instances
	 * 
	 * @param objectClassDiscoveryListener
	 *            the listener to remove
	 */
	public void removeObjectClassDiscoveryListener(ObjectClassDiscoveryListener objectClassDiscoveryListener) {
		objectClassDiscoveryListeners.remove(objectClassDiscoveryListener);
	}

	/**
	 * Joins the given federation execution and calls {@link #initAfterJoin()}
	 * immediately after. Makes sure that callbacks from the RTI are processed
	 * only after the {@linkplain #initAfterJoin()} method has returned.
	 * <p>
	 * Callbacks that come in during the {@linkplain #initAfterJoin()} are
	 * queued; The {@link FederateAmbassadorDelegator#startProcessing() } on the
	 * internal federate ambassador delegator (that is returned by
	 * {@link #getFederateAmbassadorDelegator()}) is called just after the
	 * {@linkplain #initAfterJoin()} has returned.
	 * 
	 * @param federateType
	 *            a string describing the federate's role in the federation
	 * @param federationExecutionName
	 *            the name of the federation to join
	 * @param serviceReferences
	 *            the federate's mobile services
	 * @return the federate handle that was returned by the RTI
	 * @exception FederateAlreadyExecutionMember
	 *                if the federate is already a member of an execution
	 * @exception FederationExecutionDoesNotExist
	 *                if the federation execution does not exist
	 * @exception SaveInProgress
	 *                if a save operation is in progress
	 * @exception RestoreInProgress
	 *                if a restore operation is in progress
	 * @exception RTIinternalError
	 *                if an internal error occurred in the run-time
	 *                infrastructure
	 * @exception exceptions
	 *                thrown by {@link #initAfterJoin()}
	 */
	public final FederateHandle joinFederationExecution(String federateType, String federationExecutionName,
			MobileFederateServices serviceReferences) throws RTIexception, FederateAlreadyExecutionMember,
			FederationExecutionDoesNotExist, SaveInProgress, RestoreInProgress, RTIinternalError {
		federatHandle = rtiAmbassador.joinFederationExecution(federateType, federationExecutionName,
				federateAmbassadorDelegator, serviceReferences);
		initAfterJoin();
		federateAmbassadorDelegator.startProcessing();
		return federatHandle;
	}

	/**
	 * Convenience method to join a federation execution. Joining is retried
	 * every 2 seconds until the timeout is reached.
	 * 
	 * 
	 * @param federateType
	 * @param federationExecutionName
	 * @param serviceReferences
	 * @param timeout
	 * @param unit
	 * @throws RTIexception
	 * @throws FederateAlreadyExecutionMember
	 * @throws FederationExecutionDoesNotExist
	 * @throws SaveInProgress
	 * @throws RestoreInProgress
	 * @throws RTIinternalError
	 */
	public final FederateHandle joinFederationExecution(String federateType, String federationExecutionName,
			MobileFederateServices serviceReferences, long timeout, TimeUnit unit) throws RTIexception,
			FederateAlreadyExecutionMember, FederationExecutionDoesNotExist, SaveInProgress, RestoreInProgress,
			RTIinternalError {
		int attempts = 0;
		long endWait = System.currentTimeMillis() + unit.toMicros(timeout);
		while (true) {
			attempts++;
			try {
				FederateHandle federateHandle = joinFederationExecution(federateType, federationExecutionName,
						serviceReferences);
				return federateHandle;
			} catch (FederationExecutionDoesNotExist e) {
				// ignore exception, retry
				if (System.currentTimeMillis() > endWait) {
					throw e;
				}
				logger.debug(String.format("Retry to join Federation Execution %s", federationExecutionName));
				try {
					SECONDS.sleep(2);
				} catch (InterruptedException e1) {
					Thread.currentThread().interrupt();
				}
			}
		}
	}

	/**
	 * Returns the federate handle of this federate or <code>null</code> if
	 * this federate has not joined a federation execution.
	 * 
	 * @return the federate handle
	 */
	public FederateHandle getFederatHandle() {
		return federatHandle;
	}

	/**
	 * This method is called from the
	 * {@link #joinFederationExecution(String, String, MobileFederateServices)}
	 * method just after the federate has been joined. It is made sure that no
	 * callbacks from the RTI will be processed before this method has returned.
	 * Therefore, this method is the a suitable place to initialize HLA handles
	 * that need to be known when callbacks from the RTI are processed.
	 * 
	 * @throws RTIexception
	 */
	protected abstract void initAfterJoin() throws RTIexception;

	/**
	 * Makes all subscriptions and publications of object classes and
	 * interaction classes as defined in the SOM.
	 * 
	 * @throws InvalidInteractionClassHandle
	 * @throws NameNotFound
	 * @throws InteractionClassNotDefined
	 * @throws FederateNotExecutionMember
	 * @throws SaveInProgress
	 * @throws RestoreInProgress
	 * @throws RTIinternalError
	 * @throws FederateServiceInvocationsAreBeingReportedViaMOM
	 * @throws InvalidObjectClassHandle
	 * @throws ObjectClassNotDefined
	 * @throws AttributeNotDefined
	 */
	public void defaultPublishSubscribe() throws InvalidInteractionClassHandle, NameNotFound,
			InteractionClassNotDefined, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
			RTIinternalError, FederateServiceInvocationsAreBeingReportedViaMOM, InvalidObjectClassHandle,
			ObjectClassNotDefined, AttributeNotDefined {
		publishInteractionClasses();
		subscribeInteractionClasses();
		publishObjectClassAttributes();
		subscribeObjectClassAttributes();
	}

	/**
	 * Publishes all supported interaction classes.
	 * 
	 * @exception InvalidInteractionClassHandle
	 *                if an interaction class handle is invalid
	 * @exception NameNotFound
	 *                if a name is not found
	 * @exception InteractionClassNotDefined
	 *                if an interaction class is undefined
	 * @exception FederateNotExecutionMember
	 *                if the federate is not an execution member
	 * @exception SaveInProgress
	 *                if a save operation is in progress
	 * @exception RestoreInProgress
	 *                if a restore operation is in progress
	 * @exception RTIinternalError
	 *                if an internal error occurs in the run-time infrastructure
	 */
	public abstract void publishInteractionClasses() throws InvalidInteractionClassHandle, NameNotFound,
			InteractionClassNotDefined, FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError;

	/**
	 * Subscribes to all supported interaction classes.
	 * 
	 * @exception InvalidInteractionClassHandle
	 *                if an interaction class handle is invalid
	 * @exception NameNotFound
	 *                if a name is not found
	 * @exception InteractionClassNotDefined
	 *                if an interaction class is undefined
	 * @exception FederateNotExecutionMember
	 *                if the federate is not an execution member
	 * @exception SaveInProgress
	 *                if a save operation is in progress
	 * @exception RestoreInProgress
	 *                if a restore operation is in progress
	 * @exception FederateServiceInvocationsAreBeingReportedViaMOM
	 *                if service invocations are being reported via MOM
	 * @exception RTIinternalError
	 *                if an internal error occurs in the run-time infrastructure
	 */
	public abstract void subscribeInteractionClasses() throws InvalidInteractionClassHandle, NameNotFound,
			InteractionClassNotDefined, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
			FederateServiceInvocationsAreBeingReportedViaMOM, RTIinternalError;

	/**
	 * Publishes all supported object class attributes.
	 * 
	 * @exception InvalidObjectClassHandle
	 *                if an object class handle is invalid
	 * @exception NameNotFound
	 *                if a name is not found
	 * @exception ObjectClassNotDefined
	 *                if an object class is undefined
	 * @exception AttributeNotDefined
	 *                if an attribute is undefined
	 * @exception FederateNotExecutionMember
	 *                if the federate is not an execution member
	 * @exception SaveInProgress
	 *                if a save operation is in progress
	 * @exception RestoreInProgress
	 *                if a restore operation is in progress
	 * @exception RTIinternalError
	 *                if an internal error occurs in the run-time infrastructure
	 */
	public abstract void publishObjectClassAttributes() throws InvalidObjectClassHandle, NameNotFound,
			ObjectClassNotDefined, AttributeNotDefined, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
			RTIinternalError;

	/**
	 * Subscribe to all supported object class attributes.
	 * 
	 * @exception InvalidObjectClassHandle
	 *                if an object class handle is invalid
	 * @exception NameNotFound
	 *                if a name is not found
	 * @exception ObjectClassNotDefined
	 *                if an object class is undefined
	 * @exception AttributeNotDefined
	 *                if an attribute is undefined
	 * @exception FederateNotExecutionMember
	 *                if the federate is not an execution member
	 * @exception SaveInProgress
	 *                if a save operation is in progress
	 * @exception RestoreInProgress
	 *                if a restore operation is in progress
	 * @exception RTIinternalError
	 *                if an internal error occurs in the run-time infrastructure
	 */
	public abstract void subscribeObjectClassAttributes() throws InvalidObjectClassHandle, NameNotFound,
			ObjectClassNotDefined, AttributeNotDefined, FederateNotExecutionMember, SaveInProgress, RestoreInProgress,
			RTIinternalError;

	public void registerObjectClassInstance(ObjectInstanceHandle objectInstanceHandle,
			ObjectClassInstance objectClassInstance) {
		objectInstances.putIfAbsent(objectInstanceHandle, objectClassInstance);
	}

	/**
	 * Returns the managed object class instance with the specified handle.
	 * 
	 * @param objectInstanceHandle
	 *            the object instance handle corresponding to the desired object
	 *            class instance
	 * @return the managed object class instance with the specified handle, or
	 *         <code>null</code> if no such object instance exists
	 */
	public ObjectClassInstance getObjectInstance(ObjectInstanceHandle objectInstanceHandle) {
		return objectInstances.get(objectInstanceHandle);
	}

	/**
	 * Returns an immutable collection containing the object class instances
	 * managed by this proxy ambassador.
	 * 
	 * @return an immutable collection of all managed object class instances
	 */
	public Collection<ObjectClassInstance> getObjectClassInstances() {
		return Collections.unmodifiableCollection(objectInstances.values());
	}

	/**
	 * Registers a synchronization point and returns if the registration was
	 * successful or not. Causes the current thread to wait until the CRC
	 * returned if the registration was successful, unless the thread is
	 * {@link Thread#interrupt interrupted}, or the specified waiting time
	 * elapses.
	 * 
	 * @param syncPointLabel
	 *            the label of synchronization point to be registered, as
	 *            defined in the SOM/FOM.
	 * @param userSuppliedTag
	 *            user supplied tag
	 * @param timeout
	 *            the maximum time to wait
	 * @param unit
	 *            the time unit of the <tt>timeout</tt> argument.
	 * @return <code>true</code> it the registration of the synchronization
	 *         point was successful, <code>false</code> otherwise.
	 * @throws FederateNotExecutionMember
	 * @throws SaveInProgress
	 * @throws RestoreInProgress
	 * @throws RTIinternalError
	 * @throws TimeoutException
	 *             the timeout was reached before the RTI acknowledged the
	 *             synchronization point registration. After this exception has
	 *             been thrown the registration may still have succeeded.
	 * @throws InterruptedException
	 * @throws SynchronizationPointRegistrationException
	 */
	public void registerSynchronizationPoint(String syncPointLabel, byte[] userSuppliedTag, long timeout, TimeUnit unit)
			throws FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError,
			InterruptedException, SynchronizationPointRegistrationException {
		registerSynchronizationPoint(syncPointLabel, userSuppliedTag, null, timeout, unit);
	}

	/**
	 * Registers a synchronization point and returns if the registration was
	 * successful or not. Causes the current thread to wait until the CRC
	 * returned if the registration was successful, unless the thread is
	 * {@link Thread#interrupt interrupted}, or the specified waiting time
	 * elapses.
	 * 
	 * @param syncPointLabel
	 *            the label of synchronization point to be registered, as
	 *            defined in the SOM/FOM.
	 * @param userSuppliedTag
	 *            user supplied tag
	 * @param synchronizationSet
	 *            the set of federates that take part in the synchronization
	 * @param timeout
	 *            the maximum time to wait
	 * @param unit
	 *            the time unit of the <tt>timeout</tt> argument.
	 * @return <code>true</code> it the registration of the synchronization
	 *         point was successful, <code>false</code> otherwise.
	 * @throws FederateNotExecutionMember
	 * @throws SaveInProgress
	 * @throws RestoreInProgress
	 * @throws RTIinternalError
	 * @throws IllegalStateException
	 *             if this federate is in the process of registering a
	 *             synchronization point with the same label. This exception is
	 *             generated locally, not from the RTI
	 * @throws InterruptedException
	 *             if the thread has been interrupted
	 * @throws SynchronizationPointRegistrationException
	 *             if the synchronization failed because of one of the following
	 *             reasons:
	 *             <ul>
	 *             <li>The synchronization point label is already in use </li>
	 *             <li>At least one member of the synchronization set is not
	 *             joined to the synchronization point</li>
	 *             <li>The RTI did not acknowledge the registration within a
	 *             ceratin amount of time (see TODO)</li>
	 *             </ul>
	 */
	public void registerSynchronizationPoint(String syncPointLabel, byte[] userSuppliedTag,
			FederateHandleSet synchronizationSet, long timeout, TimeUnit unit) throws FederateNotExecutionMember,
			SaveInProgress, RestoreInProgress, RTIinternalError, SynchronizationPointRegistrationException,
			InterruptedException {

		if (syncPointsWaitingForRegistration
				.putIfAbsent(syncPointLabel, new SyncPointRegistrationState(syncPointLabel)) != null) {
			throw new IllegalStateException(String.format("Already waiting for registration of sync point %s",
					syncPointLabel));
		}

		if (synchronizationSet == null) {
			rtiAmbassador.registerFederationSynchronizationPoint(syncPointLabel, userSuppliedTag);
		} else {
			rtiAmbassador.registerFederationSynchronizationPoint(syncPointLabel, userSuppliedTag, synchronizationSet);
		}
		final SyncPointRegistrationState syncPointRegistrationState = syncPointsWaitingForRegistration
				.get(syncPointLabel);
		if (!syncPointRegistrationState.awaitRegistrationAnswer(timeout, unit)) {
			throw new SynchronizationPointRegistrationException(String.format(
					"The RTI did not acknowledge the registration of the synchronization point %s within %dms",
					syncPointLabel, new Long(unit.toMillis(timeout))));
		}
		syncPointsWaitingForRegistration.remove(syncPointLabel);
		SynchronizationPointFailureReason state = syncPointRegistrationState.getRegistrationState();
		if (state == null) {
			return;
		} else if (state.equals(SynchronizationPointFailureReason.SYNCHRONIZATION_POINT_LABEL_NOT_UNIQUE)) {
			throw new SynchronizationPointRegistrationException(String.format(
					"Synchronization Point %s label is not unique", syncPointLabel));
		} else {
			throw new SynchronizationPointRegistrationException(String.format(
					"At least one member of the synchronization set is not joined to the synchronization point '%s'",
					syncPointLabel));

		}
	}

	public boolean awaitSynchronizationPointAnnouncement(String syncPointLabel, long timeout, TimeUnit unit)
			throws InterruptedException {
		SyncPointState syncPointState = getSyncPointState(syncPointLabel);
		return syncPointState.awaitAnnouncement(timeout, unit);
	}

	/**
	 * <ol>
	 * <li>Waits until the synchronization point is announced</li>
	 * </ol> . Informs the RTI that this federate has achieved the
	 * synchronization point <code>syncPointLabel</code>.
	 * 
	 * @param syncPointLabel
	 * @param timeout
	 * @param unit
	 * @throws InterruptedException
	 * @throws RTIinternalError
	 * @throws RestoreInProgress
	 * @throws SaveInProgress
	 * @throws FederateNotExecutionMember
	 * @throws SynchronizationPointLabelNotAnnounced
	 * @throws FederationSynchronizationException
	 */
	public void achieveSyncPointAndAwaitFederationSynchronization(String syncPointLabel, long timeout, TimeUnit unit)
			throws InterruptedException, SynchronizationPointLabelNotAnnounced, FederateNotExecutionMember,
			SaveInProgress, RestoreInProgress, RTIinternalError, FederationSynchronizationException {
		logger.debug(String.format("Await for synchronization at %s", syncPointLabel));
		SyncPointState syncPointState = getSyncPointState(syncPointLabel);
		if (!syncPointState.awaitSynchronization(timeout, unit)) {
			throw new FederationSynchronizationException(String.format(
					"Federation synchronization at '%s' timed out (timeout: %dms)", syncPointLabel, new Long(unit
							.toMillis(timeout))));
		}
		logger.debug(String.format("Synchronized at %s", syncPointLabel));
	}

	/**
	 * Returns the synchronization point with the given label. Always returns
	 * the same instance for a given label.
	 */
	private SyncPointState getSyncPointState(String syncPointLabel) {
		SyncPointState syncPointState = activeSyncPoints.get(syncPointLabel);
		if (syncPointState == null) {
			syncPointState = new SyncPointState(syncPointLabel);
			if (activeSyncPoints.putIfAbsent(syncPointLabel, syncPointState) != null) {
				return activeSyncPoints.get(syncPointLabel);
			}
		}
		return syncPointState;
	}

	public RTIambassador getRtiAmbassador() {
		return rtiAmbassador;
	}
}