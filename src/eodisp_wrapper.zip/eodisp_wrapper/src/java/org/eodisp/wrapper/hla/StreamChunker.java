/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.wrapper.hla;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;

import net.jcip.annotations.GuardedBy;
import net.jcip.annotations.ThreadSafe;

@ThreadSafe
public class StreamChunker {
	private final BufferedInputStream inputStream;

	private final int maxChunkSize;

	private final long streamLength;

	private final long totalChunkCount;

	private final boolean aligned;

	private final byte[] chunk;

	@GuardedBy("this")
	private long currentChunkCount;

	/**
	 * @param inputStream
	 * @param maxChunkSize
	 * @param streamLength
	 */
	public StreamChunker(final InputStream inputStream, final int maxChunkSize, final long streamLength) {
		this.inputStream = new BufferedInputStream(inputStream);
		this.maxChunkSize = maxChunkSize;
		this.streamLength = streamLength;
		long minChunkCount = streamLength / maxChunkSize;
		if (streamLength % maxChunkSize == 0) {
			totalChunkCount = minChunkCount;
			aligned = true;
		} else {
			totalChunkCount = minChunkCount + 1;
			aligned = false;
		}
		chunk = new byte[maxChunkSize];
	}

	public synchronized boolean hasMoreChunks() {
		return currentChunkCount != totalChunkCount;
	}

	public synchronized int nextChunk(byte[] nextChunk) throws IOException {
		int currentChunkSize = maxChunkSize;
		if (!aligned && currentChunkCount == (totalChunkCount - 1)) {
			currentChunkSize = (int) (streamLength % maxChunkSize);
		}

		final int dataRead = inputStream.read(nextChunk, 0, currentChunkSize);
		if (dataRead != currentChunkSize) {
			throw new IOException(String.format("Could not read %d bytes of data", new Integer(currentChunkSize)));
		}
		currentChunkCount++;
		return dataRead;
	}

	public synchronized byte[] nextChunk() throws IOException {
		int size = nextChunk(chunk);
		if (size == chunk.length) {
			return chunk;
		}
		byte[] partChunk = new byte[size];
		System.arraycopy(chunk, 0, partChunk, 0, size);
		return partChunk;
	}

	public long getTotalChunkCount() {
		return totalChunkCount;
	}

	public int getMaxChunkSize() {
		return maxChunkSize;
	}

}