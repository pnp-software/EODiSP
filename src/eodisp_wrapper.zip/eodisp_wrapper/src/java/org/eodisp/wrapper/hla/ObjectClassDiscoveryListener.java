package org.eodisp.wrapper.hla;

/**
 * Listener interface to notify object discoveries.
 * 
 * @author Andrzej Kapolka
 * @author ibirrer
 */

public interface ObjectClassDiscoveryListener {
	/**
	 * Notifies the listener that a new object instance has been created in the
	 * federation
	 * 
	 * @param objectClassInstance
	 *            the newly created object instance proxy
	 */
	public void objectInstanceDiscovered(ObjectClassInstance objectClassInstance);
}
