/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.wrapper.hla;

import hla.rti1516.*;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public interface ObjectClassInstance {
	ObjectClassHandle getObjectClassHandle();

	ObjectInstanceHandle getObjectInstanceHandle();

	void notifyReflectAttributeValues(AttributeHandleValueMap attributeHandleValueMap, byte[] userSuppliedTag,
			OrderType sentOrdering, TransportationType transportationType, LogicalTime logicalTime,
			OrderType receivedOrdering, MessageRetractionHandle messageRetractionHandle, RegionHandleSet regionHandleSet)
			throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotSubscribed, InvalidLogicalTime,
			FederateInternalError;

	void notifyRemoved(byte[] userSuppliedTag, OrderType sentOrdering, LogicalTime logicalTime,
			OrderType receivedOrdering, MessageRetractionHandle messageRetractionHandle);

	void notifyProvideAttributeValueUpdate(AttributeHandleSet theAttributes, byte[] userSuppliedTag)
			throws AttributeNotRecognized, AttributeNotOwned, FederateInternalError;

	/**
	 * Send updates of all modified attribute values to the federation.
	 * 
	 * @param userSuppliedTag
	 *            the user-supplied tag to associate with the update
	 * @exception ObjectInstanceNotKnown
	 *                if the object instance is unknown
	 * @exception AttributeNotDefined
	 *                if one of the attributes is undefined
	 * @exception AttributeNotOwned
	 *                if one of the attributes is not owned
	 * @exception FederateNotExecutionMember
	 *                if the federate is not a member of an execution
	 * @exception SaveInProgress
	 *                if a save operation is in progress
	 * @exception RestoreInProgress
	 *                if a restore operation is in progress
	 * @exception RTIinternalError
	 *                if an internal error occurred in the run-time
	 *                infrastructure
	 */
	public void updateAttributeValues(byte[] userSuppliedTag) throws ObjectInstanceNotKnown, AttributeNotDefined, AttributeNotOwned, FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError;

	/**
	 * Send updates of all, or all modified attribute values to the federation.
	 * 
	 * @param userSuppliedTag
	 *            the user-supplied tag to associate with the update
	 * @param updateAll
	 *            if <code>true</code> provide updates for all attributes; if
	 *            <code>false</code>, only provide updates for the modified
	 *            ones
	 * @exception ObjectInstanceNotKnown
	 *                if the object instance is unknown
	 * @exception AttributeNotDefined
	 *                if one of the attributes is undefined
	 * @exception AttributeNotOwned
	 *                if one of the attributes is not owned
	 * @exception FederateNotExecutionMember
	 *                if the federate is not a member of an execution
	 * @exception SaveInProgress
	 *                if a save operation is in progress
	 * @exception RestoreInProgress
	 *                if a restore operation is in progress
	 * @exception RTIinternalError
	 *                if an internal error occurred in the run-time
	 *                infrastructure
	 */
	public void updateAttributeValues(byte[] userSuppliedTag, boolean updateAll) throws ObjectInstanceNotKnown, AttributeNotDefined, AttributeNotOwned, FederateNotExecutionMember, SaveInProgress, RestoreInProgress, RTIinternalError;

	void resetWaitForListener();
	
	
}
