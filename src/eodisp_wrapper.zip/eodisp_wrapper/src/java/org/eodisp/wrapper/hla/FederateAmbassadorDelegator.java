/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.wrapper.hla;

import hla.rti1516.*;

import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;

import net.jcip.annotations.ThreadSafe;

/**
 * This class can be used to delegate federate ambassador callbacks to more than
 * one {@link FederateAmbassador} implementations. Use the
 * {@link #registerDelegate(FederateAmbassador)} method to register a new
 * federate ambassador that shall receive the callbacks. The callbacks on the
 * registered federate ambassadors are done in the order they were registered.
 * 
 * <p>
 * After this class has been instantiated it is not beginning to delegate
 * callbacks immediately but queues all callbacks. Only after the
 * {@link #startProcessing()} method has been called it begins to process the
 * callbacks.
 * 
 * @author ibirrer
 * @version $Id:$
 * 
 */
@ThreadSafe
public class FederateAmbassadorDelegator implements FederateAmbassador {

	/**
	 * Ensures that callback processing only starts after
	 * {@link #startProcessing()} has been called.
	 */
	private final CountDownLatch waitToProcessCallbacksLatch = new CountDownLatch(1);

	/**
	 * Flag to indicate that callbacks shall be processed immediately. 
	 */
	private volatile boolean processingStarted = false;

	/*
	 * A synchronized list that allows concurrent iteration (offers better
	 * concurrency than
	 * {@link java.util.Collections#synchronizedList(java.util.List)} and we
	 * don't need to add a synchronized block around each iteration).
	 */
	private final CopyOnWriteArrayList<FederateAmbassador> delegates = new CopyOnWriteArrayList<FederateAmbassador>();

	/**
	 * Blocks until the method {@link #startProcessing()} has been called.
	 * 
	 * 
	 * @throws FederateInternalError
	 *             if the wait is interrupted. The interruption status is
	 *             retained.
	 */
	private void waitForStart() throws FederateInternalError {
		if (!processingStarted) {
			try {
				waitToProcessCallbacksLatch.await();
			} catch (InterruptedException e) {
				// restore interrupt flag
				Thread.currentThread().interrupt();
				throw new FederateInternalError(
						"Thread has been interrupted while processing a federate ambassador callback. The callback will not be processed further.");
			}
			processingStarted = true;
		}
	}

	/**
	 * Before this method is called, any federate ambassador callbacks will be
	 * queued. Just after this method is called the callbacks are being
	 * processed. It is not possible to stop/queue the processing again. if the
	 * method is called twice then nothing happens on the second call.
	 */
	public void startProcessing() {
		waitToProcessCallbacksLatch.countDown();
	}

	/**
	 * Adds the given federate ambassador instance to the list of delegates.
	 * Adding the same instance twice is not allowed and this method returns
	 * <code>false</code> in this case.
	 * 
	 * @param delegate
	 *            the federate ambassador
	 * @return <code>true</code> if added
	 */
	public boolean registerDelegate(FederateAmbassador delegate) {
		return delegates.addIfAbsent(delegate);
	}

	/**
	 * Removes the given federate ambassador instance of the list of delegates.
	 * 
	 * @param delegate
	 *            the federate ambassador
	 * @return <code>true</code> if the list contained the specified element.
	 */
	public boolean unregisterDelegate(FederateAmbassador delegate) {
		return delegates.remove(delegate);
	}

	public void announceSynchronizationPoint(String synchronizationPointLabel, byte[] userSuppliedTag)
			throws FederateInternalError {
		waitForStart();

		for (FederateAmbassador delegate : delegates) {
			delegate.announceSynchronizationPoint(synchronizationPointLabel, userSuppliedTag);
		}
	}

	public void attributeIsNotOwned(ObjectInstanceHandle theObject, AttributeHandle theAttribute)
			throws ObjectInstanceNotKnown, AttributeNotRecognized, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.attributeIsNotOwned(theObject, theAttribute);
		}
	}

	public void attributeIsOwnedByRTI(ObjectInstanceHandle theObject, AttributeHandle theAttribute)
			throws ObjectInstanceNotKnown, AttributeNotRecognized, FederateInternalError {
		waitForStart();

		for (FederateAmbassador delegate : delegates) {
			delegate.attributeIsOwnedByRTI(theObject, theAttribute);
		}
	}

	public void attributeOwnershipAcquisitionNotification(ObjectInstanceHandle theObject,
			AttributeHandleSet securedAttributes, byte[] userSuppliedTag) throws ObjectInstanceNotKnown,
			AttributeNotRecognized, AttributeAcquisitionWasNotRequested, AttributeAlreadyOwned, AttributeNotPublished,
			FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.attributeOwnershipAcquisitionNotification(theObject, securedAttributes, userSuppliedTag);
		}
	}

	public void attributeOwnershipUnavailable(ObjectInstanceHandle theObject, AttributeHandleSet theAttributes)
			throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeAlreadyOwned,
			AttributeAcquisitionWasNotRequested, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.attributeOwnershipUnavailable(theObject, theAttributes);
		}
	}

	public void attributesInScope(ObjectInstanceHandle theObject, AttributeHandleSet theAttributes)
			throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotSubscribed, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.attributesInScope(theObject, theAttributes);
		}
	}

	public void attributesOutOfScope(ObjectInstanceHandle theObject, AttributeHandleSet theAttributes)
			throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotSubscribed, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.attributesOutOfScope(theObject, theAttributes);
		}
	}

	public void confirmAttributeOwnershipAcquisitionCancellation(ObjectInstanceHandle theObject,
			AttributeHandleSet theAttributes) throws ObjectInstanceNotKnown, AttributeNotRecognized,
			AttributeAlreadyOwned, AttributeAcquisitionWasNotCanceled, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.confirmAttributeOwnershipAcquisitionCancellation(theObject, theAttributes);
		}
	}

	public void discoverObjectInstance(ObjectInstanceHandle theObject, ObjectClassHandle theObjectClass,
			String objectName) throws CouldNotDiscover, ObjectClassNotRecognized, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.discoverObjectInstance(theObject, theObjectClass, objectName);
		}
	}

	public void federationNotRestored(RestoreFailureReason reason) throws FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.federationNotRestored(reason);
		}
	}

	public void federationNotSaved(SaveFailureReason reason) throws FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.federationNotSaved(reason);
		}
	}

	public void federationRestoreBegun() throws FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.federationRestoreBegun();
		}
	}

	public void federationRestored() throws FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.federationRestored();
		}
	}

	public void federationRestoreStatusResponse(FederateHandleRestoreStatusPair[] response)
			throws FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.federationRestoreStatusResponse(response);
		}
	}

	public void federationSaved() throws FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.federationSaved();
		}
	}

	public void federationSaveStatusResponse(FederateHandleSaveStatusPair[] response) throws FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.federationSaveStatusResponse(response);
		}
	}

	public void federationSynchronized(String synchronizationPointLabel) throws FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.federationSynchronized(synchronizationPointLabel);
		}
	}

	public void informAttributeOwnership(ObjectInstanceHandle theObject, AttributeHandle theAttribute,
			FederateHandle theOwner) throws ObjectInstanceNotKnown, AttributeNotRecognized, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.informAttributeOwnership(theObject, theAttribute, theOwner);
		}
	}

	public void initiateFederateRestore(String label, FederateHandle federateHandle)
			throws SpecifiedSaveLabelDoesNotExist, CouldNotInitiateRestore, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.initiateFederateRestore(label, federateHandle);
		}
	}

	public void initiateFederateSave(String label, LogicalTime time) throws InvalidLogicalTime, UnableToPerformSave,
			FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.initiateFederateSave(label, time);
		}
	}

	public void initiateFederateSave(String label) throws UnableToPerformSave, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.initiateFederateSave(label);
		}
	}

	public void objectInstanceNameReservationFailed(String objectName) throws UnknownName, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.objectInstanceNameReservationFailed(objectName);
		}
	}

	public void objectInstanceNameReservationSucceeded(String objectName) throws UnknownName, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.objectInstanceNameReservationSucceeded(objectName);
		}
	}

	public void provideAttributeValueUpdate(ObjectInstanceHandle theObject, AttributeHandleSet theAttributes,
			byte[] userSuppliedTag) throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotOwned,
			FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.provideAttributeValueUpdate(theObject, theAttributes, userSuppliedTag);
		}
	}

	public void receiveInteraction(InteractionClassHandle interactionClass, ParameterHandleValueMap theParameters,
			byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport, LogicalTime theTime,
			OrderType receivedOrdering, MessageRetractionHandle messageRetractionHandle, RegionHandleSet sentRegions)
			throws InteractionClassNotRecognized, InteractionParameterNotRecognized, InteractionClassNotSubscribed,
			InvalidLogicalTime, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.receiveInteraction(
					interactionClass,
					theParameters,
					userSuppliedTag,
					sentOrdering,
					theTransport,
					theTime,
					receivedOrdering,
					messageRetractionHandle,
					sentRegions);
		}
	}

	public void receiveInteraction(InteractionClassHandle interactionClass, ParameterHandleValueMap theParameters,
			byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport, LogicalTime theTime,
			OrderType receivedOrdering, MessageRetractionHandle messageRetractionHandle)
			throws InteractionClassNotRecognized, InteractionParameterNotRecognized, InteractionClassNotSubscribed,
			InvalidLogicalTime, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.receiveInteraction(
					interactionClass,
					theParameters,
					userSuppliedTag,
					sentOrdering,
					theTransport,
					theTime,
					receivedOrdering,
					messageRetractionHandle);
		}
	}

	public void receiveInteraction(InteractionClassHandle interactionClass, ParameterHandleValueMap theParameters,
			byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport, LogicalTime theTime,
			OrderType receivedOrdering, RegionHandleSet regions) throws InteractionClassNotRecognized,
			InteractionParameterNotRecognized, InteractionClassNotSubscribed, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.receiveInteraction(
					interactionClass,
					theParameters,
					userSuppliedTag,
					sentOrdering,
					theTransport,
					theTime,
					receivedOrdering,
					regions);
		}
	}

	public void receiveInteraction(InteractionClassHandle interactionClass, ParameterHandleValueMap theParameters,
			byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport, LogicalTime theTime,
			OrderType receivedOrdering) throws InteractionClassNotRecognized, InteractionParameterNotRecognized,
			InteractionClassNotSubscribed, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.receiveInteraction(
					interactionClass,
					theParameters,
					userSuppliedTag,
					sentOrdering,
					theTransport,
					theTime,
					receivedOrdering);
		}
	}

	public void receiveInteraction(InteractionClassHandle interactionClass, ParameterHandleValueMap theParameters,
			byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport, RegionHandleSet sentRegions)
			throws InteractionClassNotRecognized, InteractionParameterNotRecognized, InteractionClassNotSubscribed,
			FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.receiveInteraction(
					interactionClass,
					theParameters,
					userSuppliedTag,
					sentOrdering,
					theTransport,
					sentRegions);
		}
	}

	public void receiveInteraction(InteractionClassHandle interactionClass, ParameterHandleValueMap theParameters,
			byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport)
			throws InteractionClassNotRecognized, InteractionParameterNotRecognized, InteractionClassNotSubscribed,
			FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.receiveInteraction(interactionClass, theParameters, userSuppliedTag, sentOrdering, theTransport);
		}
	}

	public void reflectAttributeValues(ObjectInstanceHandle theObject, AttributeHandleValueMap theAttributes,
			byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport, LogicalTime theTime,
			OrderType receivedOrdering, MessageRetractionHandle retractionHandle, RegionHandleSet sentRegions)
			throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotSubscribed, InvalidLogicalTime,
			FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.reflectAttributeValues(
					theObject,
					theAttributes,
					userSuppliedTag,
					sentOrdering,
					theTransport,
					theTime,
					receivedOrdering,
					retractionHandle,
					sentRegions);
		}
	}

	public void reflectAttributeValues(ObjectInstanceHandle theObject, AttributeHandleValueMap theAttributes,
			byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport, LogicalTime theTime,
			OrderType receivedOrdering, MessageRetractionHandle retractionHandle) throws ObjectInstanceNotKnown,
			AttributeNotRecognized, AttributeNotSubscribed, InvalidLogicalTime, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.reflectAttributeValues(
					theObject,
					theAttributes,
					userSuppliedTag,
					sentOrdering,
					theTransport,
					theTime,
					receivedOrdering,
					retractionHandle);
		}
	}

	public void reflectAttributeValues(ObjectInstanceHandle theObject, AttributeHandleValueMap theAttributes,
			byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport, LogicalTime theTime,
			OrderType receivedOrdering, RegionHandleSet sentRegions) throws ObjectInstanceNotKnown,
			AttributeNotRecognized, AttributeNotSubscribed, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.reflectAttributeValues(
					theObject,
					theAttributes,
					userSuppliedTag,
					sentOrdering,
					theTransport,
					theTime,
					receivedOrdering,
					sentRegions);
		}
	}

	public void reflectAttributeValues(ObjectInstanceHandle theObject, AttributeHandleValueMap theAttributes,
			byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport, LogicalTime theTime,
			OrderType receivedOrdering) throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotSubscribed,
			FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.reflectAttributeValues(
					theObject,
					theAttributes,
					userSuppliedTag,
					sentOrdering,
					theTransport,
					theTime,
					receivedOrdering);
		}
	}

	public void reflectAttributeValues(ObjectInstanceHandle theObject, AttributeHandleValueMap theAttributes,
			byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport, RegionHandleSet sentRegions)
			throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotSubscribed, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.reflectAttributeValues(
					theObject,
					theAttributes,
					userSuppliedTag,
					sentOrdering,
					theTransport,
					sentRegions);
		}
	}

	public void reflectAttributeValues(ObjectInstanceHandle theObject, AttributeHandleValueMap theAttributes,
			byte[] userSuppliedTag, OrderType sentOrdering, TransportationType theTransport)
			throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotSubscribed, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.reflectAttributeValues(theObject, theAttributes, userSuppliedTag, sentOrdering, theTransport);
		}
	}

	public void removeObjectInstance(ObjectInstanceHandle theObject, byte[] userSuppliedTag, OrderType sentOrdering,
			LogicalTime theTime, OrderType receivedOrdering, MessageRetractionHandle retractionHandle)
			throws ObjectInstanceNotKnown, InvalidLogicalTime, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.removeObjectInstance(
					theObject,
					userSuppliedTag,
					sentOrdering,
					theTime,
					receivedOrdering,
					retractionHandle);
		}
	}

	public void removeObjectInstance(ObjectInstanceHandle theObject, byte[] userSuppliedTag, OrderType sentOrdering,
			LogicalTime theTime, OrderType receivedOrdering) throws ObjectInstanceNotKnown, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.removeObjectInstance(theObject, userSuppliedTag, sentOrdering, theTime, receivedOrdering);
		}
	}

	public void removeObjectInstance(ObjectInstanceHandle theObject, byte[] userSuppliedTag, OrderType sentOrdering)
			throws ObjectInstanceNotKnown, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.removeObjectInstance(theObject, userSuppliedTag, sentOrdering);
		}
	}

	public void requestAttributeOwnershipAssumption(ObjectInstanceHandle theObject,
			AttributeHandleSet offeredAttributes, byte[] userSuppliedTag) throws ObjectInstanceNotKnown,
			AttributeNotRecognized, AttributeAlreadyOwned, AttributeNotPublished, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.requestAttributeOwnershipAssumption(theObject, offeredAttributes, userSuppliedTag);
		}
	}

	public void requestAttributeOwnershipRelease(ObjectInstanceHandle theObject,
			AttributeHandleSet candidateAttributes, byte[] userSuppliedTag) throws ObjectInstanceNotKnown,
			AttributeNotRecognized, AttributeNotOwned, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.requestAttributeOwnershipRelease(theObject, candidateAttributes, userSuppliedTag);
		}
	}

	public void requestDivestitureConfirmation(ObjectInstanceHandle theObject, AttributeHandleSet offeredAttributes)
			throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotOwned,
			AttributeDivestitureWasNotRequested, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.requestDivestitureConfirmation(theObject, offeredAttributes);
		}
	}

	public void requestFederationRestoreFailed(String label) throws FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.requestFederationRestoreFailed(label);
		}
	}

	public void requestFederationRestoreSucceeded(String label) throws FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.requestFederationRestoreSucceeded(label);
		}
	}

	public void requestRetraction(MessageRetractionHandle theHandle) throws FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.requestRetraction(theHandle);
		}
	}

	public void startRegistrationForObjectClass(ObjectClassHandle theClass) throws ObjectClassNotPublished,
			FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.startRegistrationForObjectClass(theClass);
		}
	}

	public void stopRegistrationForObjectClass(ObjectClassHandle theClass) throws ObjectClassNotPublished,
			FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.stopRegistrationForObjectClass(theClass);
		}
	}

	public void synchronizationPointRegistrationFailed(String synchronizationPointLabel,
			SynchronizationPointFailureReason reason) throws FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.synchronizationPointRegistrationFailed(synchronizationPointLabel, reason);
		}
	}

	public void synchronizationPointRegistrationSucceeded(String synchronizationPointLabel)
			throws FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.synchronizationPointRegistrationSucceeded(synchronizationPointLabel);
		}
	}

	public void timeAdvanceGrant(LogicalTime theTime) throws InvalidLogicalTime,
			JoinedFederateIsNotInTimeAdvancingState, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.timeAdvanceGrant(theTime);
		}
	}

	public void timeConstrainedEnabled(LogicalTime time) throws InvalidLogicalTime,
			NoRequestToEnableTimeConstrainedWasPending, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.timeConstrainedEnabled(time);
		}
	}

	public void timeRegulationEnabled(LogicalTime time) throws InvalidLogicalTime,
			NoRequestToEnableTimeRegulationWasPending, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.timeRegulationEnabled(time);
		}
	}

	public void turnInteractionsOff(InteractionClassHandle theHandle) throws InteractionClassNotPublished,
			FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.turnInteractionsOff(theHandle);
		}
	}

	public void turnInteractionsOn(InteractionClassHandle theHandle) throws InteractionClassNotPublished,
			FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.turnInteractionsOn(theHandle);
		}
	}

	public void turnUpdatesOffForObjectInstance(ObjectInstanceHandle theObject, AttributeHandleSet theAttributes)
			throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotOwned, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.turnUpdatesOffForObjectInstance(theObject, theAttributes);
		}
	}

	public void turnUpdatesOnForObjectInstance(ObjectInstanceHandle theObject, AttributeHandleSet theAttributes)
			throws ObjectInstanceNotKnown, AttributeNotRecognized, AttributeNotOwned, FederateInternalError {
		waitForStart();
		for (FederateAmbassador delegate : delegates) {
			delegate.turnUpdatesOnForObjectInstance(theObject, theAttributes);
		}
	}
}
