/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.examples.earthCare;

import hla.rti1516.*;
import hla.rti1516.jlc.RtiFactory;
import hla.rti1516.jlc.RtiFactoryFactory;

import java.awt.BorderLayout;
import java.io.*;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import javax.swing.*;

import org.apache.log4j.Logger;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.types.Commandline.Argument;
import org.eodisp.examples.earthCare.wrapper.ProgramExecution;
import org.eodisp.hla.common.handles.AttributeHandleSetImpl;

/**
 * Wraps the EarthCARE lid_filter executable as a federate. It is subscribed to
 * the object class Scene and begins executing as soon as the <code>data</code>
 * attribute of the scene is updated/reflected.
 * 
 * Configuration is taken from the earthCAREH installation
 * 
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class PlotterFederate extends BasicFederateAmbassador {

	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	static Logger logger = Logger.getLogger(PlotterFederate.class);

	private RTIambassador rtiAmbassador;

	private ObjectClassHandle lidarOutputObjectClass;

	private ObjectClassHandle sceneObjectClassHandle;

	private AttributeHandle sceneAttributeHandle;

	private Map<ObjectInstanceHandle, String> discoveredObjects = new HashMap<ObjectInstanceHandle, String>();

	private AttributeHandle virtualCoPolarRayleigh;

	/**
	 * @throws Exception
	 */
	public void start() throws Exception {
		RtiFactory rtiFactory = RtiFactoryFactory.getRtiFactory();
		rtiAmbassador = rtiFactory.getRtiAmbassador();
		
		URL url = new URL("file:///home/ibirrer/pnp/erti/examples/earthCAREDemo/resources/earthCAREDemo.fdd");

		try {
			rtiAmbassador.createFederationExecution(EarthCareFOM.FEDERATION_EXECUTION_NAME, url);
			logger.debug("Created federation execution: " + EarthCareFOM.FEDERATION_EXECUTION_NAME);
		} catch (FederationExecutionAlreadyExists e) {
			logger.debug(String.format(
					"Federation execution %s already exists. Don't create a new one but join it.",
					EarthCareFOM.FEDERATION_EXECUTION_NAME));
		}
		rtiAmbassador.joinFederationExecution("NA", EarthCareFOM.FEDERATION_EXECUTION_NAME, this, null);

		lidarOutputObjectClass = rtiAmbassador.getObjectClassHandle(EarthCareFOM.LIDAR_OUTPUT_OBJECT_CLASS);
		sceneObjectClassHandle = rtiAmbassador.getObjectClassHandle(EarthCareFOM.SCENE_OBJECT_CLASS);

		sceneAttributeHandle = rtiAmbassador.getAttributeHandle(sceneObjectClassHandle, "data");
		// Subscribe to scene
		AttributeHandleSet attributeHandleSet = new AttributeHandleSetImpl();
		attributeHandleSet.add(sceneAttributeHandle);
		rtiAmbassador.subscribeObjectClassAttributes(sceneObjectClassHandle, attributeHandleSet);
		logger.info(String.format("Subscribed to: " + EarthCareFOM.SCENE_OBJECT_CLASS));

		virtualCoPolarRayleigh = rtiAmbassador.getAttributeHandle(lidarOutputObjectClass, "virtualCoPolarRayleigh");
		// Subscribe to lidar out
		attributeHandleSet = new AttributeHandleSetImpl();
		attributeHandleSet.add(virtualCoPolarRayleigh);
		rtiAmbassador.subscribeObjectClassAttributes(lidarOutputObjectClass, attributeHandleSet);
		logger.info(String.format("Subscribed to: " + EarthCareFOM.LIDAR_OUTPUT_OBJECT_CLASS));
	}

	@Override
	public void discoverObjectInstance(final ObjectInstanceHandle theObject, final ObjectClassHandle theObjectClass,
			final String objectName) throws CouldNotDiscover, ObjectClassNotRecognized, FederateInternalError {
		logger.debug(String.format(
				"Plotter discovered instance %s, %s, %s ",
				theObject + "",
				theObjectClass + "",
				objectName + ""));
		String objectClassName = null;
		try {
			objectClassName = rtiAmbassador.getObjectClassName(theObjectClass);
		} catch (InvalidObjectClassHandle e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FederateNotExecutionMember e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RTIinternalError e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.debug("New instance for class " + objectClassName + " discovered");
		discoveredObjects.put(theObject, objectClassName);
	}

	/**
	 * {@inheritDoc}
	 */
	public void reflectAttributeValues(final ObjectInstanceHandle theObject,
			final AttributeHandleValueMap theAttributes, byte[] userSuppliedTag, OrderType sentOrdering,
			TransportationType theTransport) throws ObjectInstanceNotKnown, AttributeNotRecognized,
			AttributeNotSubscribed, FederateInternalError {
		Thread t = new Thread() {
			public void run() {
				// see what we got

				if (discoveredObjects.get(theObject).contains(EarthCareFOM.LIDAR_OUTPUT_OBJECT_CLASS)) {
					logger.debug("Plotter: plot virtualCoPolarRayleigh");
					plotVirtualCoPolarRayleigh(theAttributes);
				} else {
					logger.debug("Plotter: reflect scene");
					plot3dScene(theAttributes);
				}
			}

		};
		t.start();
	}

	private void plot3dScene(AttributeHandleValueMap theAttributes) {
		File workingDir = Util.getWorkingDir("plot_3d");
		byte[] sceneData = (byte[]) theAttributes.get(sceneAttributeHandle);
		File inputSceneFile = new File(workingDir, "scene");
		File extractionOutput = new File(workingDir, "extract.out");
		final File plot3dOut = new File(workingDir, "out.gif");

		try {
			Util.saveBytesToFile(sceneData, inputSceneFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// ./bin/extract_quantity_3d ./output/scene_creator/scene.out temp.dat
		// 0.0 10.0 0.0 10.0 0.0 15.0 0.1 13 0
		// EXTRACT QUANTITY
		ProgramExecution extractQuantity3d = new ProgramExecution(false);
		extractQuantity3d.setTaskName("bin/extract_quantity_3d");
		extractQuantity3d.setFailonerror(true);
		extractQuantity3d.setExecutable(new File(Util.getEarthCareInstallDir(), "bin/extract_quantity_3d")
				.getAbsolutePath());
		extractQuantity3d.setDir(Util.getEarthCareInstallDir());

		String[] arguments = { inputSceneFile.getAbsolutePath(), extractionOutput.getAbsolutePath(), "0.0", "10.0",
				"0.0", "10.0", "0.0", "15.0", "0.1", "13", "0" };
		for (String argument : arguments) {
			Argument arg = extractQuantity3d.createArg();
			arg.setValue(argument);
		}

		try {
			extractQuantity3d.execute();
		} catch (BuildException e) {
			logger.error("Could not create plot", e);
		}

		// ./bin/plot_3d temp.dat 0.0 10.0 0.0 10.0 0.0 15.0 1.0 1.0e-5 1.0e-1 1
		// 5.0e-4 1 1 scene_3d_ext.ps/vcps
		// PLOT_3D
		ProgramExecution plot_3d = new ProgramExecution(false);
		plot_3d.setTaskName("bin/plot_3d");
		plot_3d.setFailonerror(true);
		plot_3d.setExecutable(new File(Util.getEarthCareInstallDir(), "bin/plot_3d").getAbsolutePath());
		plot_3d.setDir(Util.getEarthCareInstallDir());

		String[] plot3dArgs = { extractionOutput.getAbsolutePath(), "0.0", "10.0", "0.0", "10.0", "0.0", "15.0", "1.0",
				"1.0e-5", "1.0e-1", "1", "5.0e-4", "1", "1", plot3dOut.getAbsoluteFile() + "/gif" };
		for (String argument : plot3dArgs) {
			Argument arg = plot_3d.createArg();
			arg.setValue(argument);
		}

		try {
			plot_3d.execute();
		} catch (BuildException e) {
			logger.error("Could not create plot", e);
		}

		// Show output gif in a frame;
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				// Create and set up the window.
				JFrame frame = new JFrame("LabelDemo");
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

				// Create and set up the content pane.
				JPanel newContentPane = new JPanel();
				newContentPane.setLayout(new BorderLayout());
				newContentPane.setOpaque(true); // content panes
				// must be opaque
				ImageIcon icon = new ImageIcon(plot3dOut.getAbsolutePath(), "plotting output");

				JLabel label = new JLabel(icon);
				newContentPane.add(label);

				frame.setContentPane(newContentPane);
				frame.pack();
				frame.setVisible(true);
			}
		});

	}

	/**
	 * @param theAttributes
	 */
	private void plotVirtualCoPolarRayleigh(final AttributeHandleValueMap theAttributes) {
		File workingDir = Util.getWorkingDir("plot_slice");
		File plotSliceInput = new File(workingDir, "plotInput");
		final File plotSliceOutput = new File(workingDir, "out.gif");

		// save the data in a file:

		byte[] data = (byte[]) theAttributes.get(virtualCoPolarRayleigh);

		try {
			ChannelData channelData = (ChannelData) new ObjectInputStream(new ByteArrayInputStream(data)).readObject();
			byte[] channel2 = channelData.getChannelData(2);
			Util.saveBytesToFile(channel2, plotSliceInput);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// plot lidar output
		// ./bin/plot_slice ./output/lidar/lidar.out_para_ray_02.dat
		// 0.0 10.0 0.0 12.0 0.1 1.0e+3 1 /vcps

		ProgramExecution lidarExec = new ProgramExecution(false);
		lidarExec.setTaskName("bin/plot_slice");
		lidarExec.setFailonerror(true);
		lidarExec.setExecutable(new File(Util.getEarthCareInstallDir(), "bin/plot_slice").getAbsolutePath());
		lidarExec.setDir(Util.getEarthCareInstallDir());

		Argument arg0 = lidarExec.createArg();
		arg0.setValue(plotSliceInput.getAbsolutePath());

		Argument arg1 = lidarExec.createArg();
		arg1.setValue("0.0");

		Argument arg2 = lidarExec.createArg();
		arg2.setValue("10.0");

		Argument arg3 = lidarExec.createArg();
		arg3.setValue("0.0");

		Argument arg4 = lidarExec.createArg();
		arg4.setValue("12.0");

		Argument arg5 = lidarExec.createArg();
		arg5.setValue("0.1");

		Argument arg6 = lidarExec.createArg();
		arg6.setValue("03+3");

		Argument arg7 = lidarExec.createArg();
		arg7.setValue("1");

		Argument arg8 = lidarExec.createArg();
		arg8.setValue(plotSliceOutput.getAbsolutePath() + "/gif");

		try {
			lidarExec.execute();
		} catch (BuildException e) {
			logger.error("Could not create plot", e);
		}

		// Show output gif in a frame;
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				// Create and set up the window.
				JFrame frame = new JFrame("LabelDemo");
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

				// Create and set up the content pane.
				JPanel newContentPane = new JPanel();
				newContentPane.setLayout(new BorderLayout());
				newContentPane.setOpaque(true); // content panes
				// must be opaque
				ImageIcon icon = new ImageIcon(plotSliceOutput.getAbsolutePath(), "plotting output");

				JLabel label = new JLabel(icon);
				newContentPane.add(label);

				frame.setContentPane(newContentPane);
				frame.pack();
				frame.setVisible(true);
			}
		});
	}
}
