package org.eodisp.examples.earthCare.wrapper;

import javax.swing.JFrame;

import org.apache.tools.ant.*;
import org.apache.tools.ant.taskdefs.ExecTask;
import org.apache.tools.ant.types.Environment;

public class ProgramExecution extends ExecTask {
	private JFrame frame;

	private String executableName;

	// TODO: have a look at the Execute class. It is probably better to use this
	// directly.
	public ProgramExecution(int width, int height) {
		this(true, width, height);
	}

	public ProgramExecution(boolean vt320) {
		this(vt320, 130, 50);
	}

	public ProgramExecution(boolean vt320, int width, int height) {
		BuildListener buildListener = null;

		Environment.Variable envVar = new Environment.Variable();
		envVar.setKey("NOXTERMFWIN");
		envVar.setValue("true");
		addEnv(envVar);

		DefaultLogger consoleLogger = new DefaultLogger();
		consoleLogger.setEmacsMode(true);
		consoleLogger.setErrorPrintStream(System.err);
		consoleLogger.setOutputPrintStream(System.out);
		consoleLogger.setMessageOutputLevel(Project.MSG_INFO);
		buildListener = consoleLogger;

		Project project = new Project();
		project.addBuildListener(buildListener);
		Target target = new Target();
		target.setProject(project);
		setProject(project);
		setOwningTarget(target);
		getProject().init();
	}

	@Override
	public void execute() throws BuildException {
		super.execute();
	}

	@Override
	public void setExecutable(String value) {
		this.executableName = value;
		super.setExecutable(value);
	}
}
