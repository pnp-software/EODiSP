/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.examples.earthCare;

import java.io.*;

/**
 * @author ibirrer
 * @version $Id:$
 *
 */
public class Util {

//	 Returns the contents of the file in a byte array.
    public static byte[] getBytesFromFile(File file) throws IOException {
        InputStream is = new FileInputStream(file);
    
        // Get the size of the file
        long length = file.length();
    
        // You cannot create an array using a long type.
        // It needs to be an int type.
        // Before converting to an int type, check
        // to ensure that file is not larger than Integer.MAX_VALUE.
        if (length > Integer.MAX_VALUE) {
            // File is too large
        }
    
        // Create the byte array to hold the data
        byte[] bytes = new byte[(int)length];
    
        // Read in the bytes
        int offset = 0;
        int numRead = 0;
        while (offset < bytes.length
               && (numRead=is.read(bytes, offset, bytes.length-offset)) >= 0) {
            offset += numRead;
        }
    
        // Ensure all the bytes have been read in
        if (offset < bytes.length) {
            throw new IOException("Could not completely read file "+file.getName());
        }
    
        // Close the input stream and return bytes
        is.close();
        return bytes;
    }
    
    public static void saveBytesToFile( byte[] data, File file ) throws IOException {
    		file.createNewFile();
    		FileOutputStream fileOutputStream = new FileOutputStream(file);
    		fileOutputStream.write( data );
    		fileOutputStream.close();
    }
    
    public static File getEarthCareInstallDir() {
		String home = System.getenv("EARTH_CARE_INSTALL_DIR");
		if (home == null) {
			// TODO better default value
			home = "/home/ibirrer/pnp/earthcare_sim";
		}
		File earthCareInstallDir = new File(home);
		
		return earthCareInstallDir;
	}
	
	public static File getWorkingDir(String tmpDirName) {
		File workingDir = new File(new File(System.getProperty("java.io.tmpdir")), tmpDirName);
		workingDir.mkdirs();
		return workingDir;
	}

}
