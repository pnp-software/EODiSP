/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.examples.earthCare.wrapper;

import java.io.File;
import java.io.IOException;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.types.Commandline;
import org.apache.tools.ant.types.Commandline.Argument;
import org.eodisp.examples.earthCare.Util;
import org.eodisp.util.launcher.Process;
import org.eodisp.util.launcher.ProcessImpl;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class SceneCreatorProgramWrapper {

	private static final String SCENE_FILENAME = "scene.dat";

	private static final String SCENE_CONFIG = "input/scene_creator/scene.inp";

	private static final String EXECUTABLE = "bin/scene_creator";

	private static final String TMP_DIR_PREFIX = "scene_creator_";

	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	static Logger logger = Logger.getLogger(SceneCreatorProgramWrapper.class);

	private File sceneFile;

	private File earthCareInstallDir;

	private File workingDir;

	private File executable;

	public SceneCreatorProgramWrapper(String tmpDirName) throws IOException {
		initEarthCareInstallDir();
		initWorkingDir(tmpDirName);
		sceneFile = new File(workingDir, SCENE_FILENAME);
	}

	private void initWorkingDir(String tmpDirName) {
		workingDir = new File(new File(System.getProperty("java.io.tmpdir")), TMP_DIR_PREFIX + tmpDirName);
		workingDir.mkdirs();
		logger.debug("SceneCreator working dir: " + workingDir.getAbsolutePath());
	}

	private void initEarthCareInstallDir() {
		String home = System.getenv("EARTH_CARE_INSTALL_DIR");
		if (home == null) {
			// TODO better default value
			home = "/home/ibirrer/pnp/earthcare_sim";
		}
		earthCareInstallDir = new File(home);
		executable = new File(earthCareInstallDir, EXECUTABLE);
		logger.debug("EARTH_CARE_INSTALL_DIR: " + earthCareInstallDir.getAbsolutePath());
		logger.debug("EXECUTABLE: " + executable.getAbsolutePath());
	}

	/**
	 * @return The scene file as byte array.
	 * @throws ExitStatusException
	 * @throws IOException
	 */
	public byte[] execute() throws ExitStatusException, IOException {
		final Commandline commandline = new Commandline();
		commandline.setExecutable(new File(earthCareInstallDir, EXECUTABLE).getAbsolutePath());
		// set the scene creator input file
		commandline.createArgument().setValue(new File(earthCareInstallDir, SCENE_CONFIG).getAbsolutePath());
		// set scene location of the generated scene
		commandline.createArgument().setValue(sceneFile.getAbsolutePath());

		// If there's an output available on this we just return this one
		// without computing it again.
		// TODO: this is for demo purposes only because it takes about 30 min.
		// to compute the filtered scene.
		Process process = null; //new ProcessImpl(commandline, earthCareInstallDir);
		process.launch();
		logger.info("Scene Creator has finished computing the filtered scene. Temporary file saved at "
				+ sceneFile.getAbsolutePath());
		return Util.getBytesFromFile(sceneFile);
	}

	public static void main(String[] args) throws IOException, ExitStatusException {
		Logger.getRootLogger().addAppender(new ConsoleAppender(new PatternLayout("%5p - %m%n"), "System.out"));
		SceneCreatorProgramWrapper sceneCreatorProgramWrapper = new SceneCreatorProgramWrapper("test");
		sceneCreatorProgramWrapper.execute();
	}
}
