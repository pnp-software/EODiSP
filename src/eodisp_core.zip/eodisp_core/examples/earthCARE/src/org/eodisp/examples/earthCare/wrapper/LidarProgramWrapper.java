/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.examples.earthCare.wrapper;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.tools.ant.types.Commandline.Argument;
import org.eodisp.examples.earthCare.Util;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class LidarProgramWrapper {
	private static final String LIDAR_OUT_FILE_PREFIX = "lidarOut";

	private static final String LIDAR_OUT_DIR = "lidarOut";

	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	static Logger logger = Logger.getLogger(LidarProgramWrapper.class);

	byte[] filteredSceneData;

	private File filteredSceneFile;

	private File earthCareHome;

	private File workingDir;

	private File lidarOutFile;

	public LidarProgramWrapper(byte[] data, String tmpDirName) {
		this.filteredSceneData = data;
		String home = System.getenv("EARTH_CARE_HOME");
		if (home == null) {
			// TODO better default value
			home = "/home/ibirrer/pnp/earthcare_sim";
		}

		earthCareHome = new File(home);
		logger.debug("EARTH_CARE_HOME: " + earthCareHome.getAbsolutePath());

		workingDir = new File(new File(System.getProperty("java.io.tmpdir")), "lidarWrapperTmp_" + tmpDirName);
		filteredSceneFile = new File(workingDir, "filterdScene");

		// Save the scene in a file
		try {
			filteredSceneFile.getParentFile().mkdirs();
			filteredSceneFile.createNewFile();
			FileOutputStream fileOutputStream = new FileOutputStream(filteredSceneFile);
			fileOutputStream.write(data);
			fileOutputStream.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// create appropriate master config file
		MasterConfig masterInputFile = new MasterConfig();
		// set the just saved scene file as the input scene to this lidar
		masterInputFile.setSceneFile(filteredSceneFile.getAbsolutePath());
		lidarOutFile = new File(new File(workingDir, LIDAR_OUT_DIR), LIDAR_OUT_FILE_PREFIX);

		masterInputFile.setLidarOut(lidarOutFile.getAbsolutePath());

		try {
			masterInputFile.save(new File(workingDir, "master.inp"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @return Map of the output files generate by the lidar. The key is the
	 *         filename as defined in the EarthCARE user guid on page 76 without
	 *         the OUTFILE prefix.
	 */
	public Map<String, byte[]> execute() {
		ProgramExecution lidarExec = new ProgramExecution(130, 40);
		lidarExec.setExecutable(new File(earthCareHome, "bin/lidar").getAbsolutePath());
		lidarExec.setDir(earthCareHome);
		Argument arg = lidarExec.createArg();
		arg.setValue(new File(workingDir, "master.inp").getAbsolutePath());
		lidarExec.execute();

		File[] lidarOutputFiles = lidarOutFile.getParentFile().listFiles(new FilenameFilter() {

			public boolean accept(File dir, String name) {
				return name.startsWith(LIDAR_OUT_FILE_PREFIX);
			}
		});

		Map<String, byte[]> lidarOutputData = new HashMap<String, byte[]>();

		for (File file : lidarOutputFiles) {
			try {
				lidarOutputData.put(file.getName().substring(LIDAR_OUT_FILE_PREFIX.length()), Util
						.getBytesFromFile(file));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		for (String file : lidarOutputData.keySet()) {
			System.out.println(file);
		}

		return lidarOutputData;
	}

	public static void main(String[] args) throws IOException {
		Logger.getRootLogger().addAppender(
				new ConsoleAppender(new PatternLayout("%r [%t] %p %l %x - %m%n"), "System.out"));
		byte[] data = Util.getBytesFromFile(new File("/tmp/scene"));
		LidarProgramWrapper lidarProgramWrapper = new LidarProgramWrapper(data, "test");
		lidarProgramWrapper.execute();
	}
}
