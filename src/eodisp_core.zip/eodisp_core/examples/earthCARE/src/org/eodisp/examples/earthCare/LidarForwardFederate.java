/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.examples.earthCare;

import hla.rti1516.*;
import hla.rti1516.jlc.NullFederateAmbassador;
import hla.rti1516.jlc.RtiFactory;
import hla.rti1516.jlc.RtiFactoryFactory;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.eodisp.examples.earthCare.wrapper.LidFilterProgramWrapper;
import org.eodisp.hla.common.handles.AttributeHandleSetImpl;
import org.eodisp.hla.common.handles.AttributeHandleValueMapImpl;
import org.eodisp.util.FileUtil;

/**
 * Wraps the EarthCARE lid_filter executable as a federate. It is subscribed to
 * the object class Scene and begins executing as soon as the <code>data</code>
 * attribute of the scene is updated/reflected.
 * 
 * Configuration is taken from the earthCAREH installation
 * 
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class LidarForwardFederate extends NullFederateAmbassador {

	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	static Logger logger = Logger.getLogger(LidarForwardFederate.class);

	private Map<ObjectInstanceHandle, ObjectInstanceHandle> registeredInstances = new HashMap<ObjectInstanceHandle, ObjectInstanceHandle>();

	private RTIambassador rtiAmbassador;

	private ObjectClassHandle filteredSceneObjectClassHandle;

	private ObjectClassHandle sceneObjectClassHandle;

	private ObjectInstanceHandle filteredSceneInstance;

	private AttributeHandle filteredSceneAttributeHandle;

	private AttributeHandle sceneAttributeHandle;

	/**
	 * @throws Exception
	 */
	public void start() throws Exception {
		RtiFactory rtiFactory = RtiFactoryFactory.getRtiFactory();
		rtiAmbassador = rtiFactory.getRtiAmbassador();
		URL url = new URL("file:///home/ibirrer/pnp/erti/examples/earthCAREDemo/resources/earthCAREDemo.fdd");

		try {
			rtiAmbassador.createFederationExecution(EarthCareFOM.FEDERATION_EXECUTION_NAME, url);
			logger.debug("Created federation execution: " + EarthCareFOM.FEDERATION_EXECUTION_NAME);
		} catch (FederationExecutionAlreadyExists e) {
			logger.debug(String.format(
					"Federation execution %s already exists. Don't create a new one but join it.",
					EarthCareFOM.FEDERATION_EXECUTION_NAME));
		}
		rtiAmbassador.joinFederationExecution("NA", EarthCareFOM.FEDERATION_EXECUTION_NAME, this, null);

		filteredSceneObjectClassHandle = rtiAmbassador.getObjectClassHandle(EarthCareFOM.FILTERED_SCENE_OBJECT_CLASS);
		sceneObjectClassHandle = rtiAmbassador.getObjectClassHandle(EarthCareFOM.SCENE_OBJECT_CLASS);

		AttributeHandle sceneData = rtiAmbassador.getAttributeHandle(sceneObjectClassHandle, "data");
		// Subscribe to scene
		AttributeHandleSet attributeHandleSet = new AttributeHandleSetImpl();
		attributeHandleSet.add(sceneData);
		rtiAmbassador.subscribeObjectClassAttributes(sceneObjectClassHandle, attributeHandleSet);
		logger.info(String.format("Subscribed to: " + EarthCareFOM.SCENE_OBJECT_CLASS));
		filteredSceneAttributeHandle = rtiAmbassador.getAttributeHandle(filteredSceneObjectClassHandle, "data");
		AttributeHandleSet filteredSceneAttributeHandleSet = new AttributeHandleSetImpl();
		filteredSceneAttributeHandleSet.add(filteredSceneAttributeHandle);
		rtiAmbassador.publishObjectClassAttributes(filteredSceneObjectClassHandle, filteredSceneAttributeHandleSet);
		filteredSceneInstance = rtiAmbassador.registerObjectInstance(filteredSceneObjectClassHandle);
		

		sceneAttributeHandle = rtiAmbassador.getAttributeHandle(sceneObjectClassHandle, "data");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void reflectAttributeValues(final ObjectInstanceHandle theObject,
			final AttributeHandleValueMap theAttributes, byte[] userSuppliedTag, OrderType sentOrdering,
			TransportationType theTransport) throws ObjectInstanceNotKnown, AttributeNotRecognized,
			AttributeNotSubscribed, FederateInternalError {
		System.out.println("received reflect on lidar forward federate");
		Thread t = new Thread() {
			@Override
			public void run() {
				// See if we already registered a target FilteredScene
				filteredSceneInstance = registeredInstances.get(theObject);
				if (filteredSceneInstance == null) {
					try {
						
						filteredSceneInstance = rtiAmbassador.registerObjectInstance(filteredSceneObjectClassHandle);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					registeredInstances.put(theObject, filteredSceneInstance);
					logger.debug("Forward Lidar Federate: Registered new FilteredScene instance");
				}

				// Get data from attribute
				byte[] sceneData = (byte[]) theAttributes.get(sceneAttributeHandle);
				if( sceneData == null ) {
					logger.error( "No scene data received in reflectAttributeValue. Aborting reflectAttributeValue()" );
					return;
				}

				try {
					// Run lid_filter to create filtered scene
					LidFilterProgramWrapper lidFilterProgramWrapper = new LidFilterProgramWrapper(
							sceneData,
							"test");
					byte[] filteredSceneData = lidFilterProgramWrapper.execute();
					AttributeHandleValueMap filteredSceneValueMap = new AttributeHandleValueMapImpl();
					filteredSceneValueMap.put(filteredSceneAttributeHandle, filteredSceneData);
					logger.info("Lidar Filter Federate: Updating Filtered Scene instance "
							+ filteredSceneInstance.toString());
					rtiAmbassador.updateAttributeValues(filteredSceneInstance, filteredSceneValueMap, new byte[0]);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		};
		t.start();
	}
	
	public static void main(String[] args) {
		LidarForwardFederate lidarForwardFederate = new LidarForwardFederate();
		try {
			System.setProperty("org.eodisp.hla.lrc.crc-uri", "urn:jxta:uuid-37AB0CEE1A5444728150BB2E14082E7A0B67FAF51C524A85B43DD07F293EEBFE03");
			System.setProperty("org.eodisp.working-dir", FileUtil.createTempDir("LidarForwardFederate", "", FileUtil.getTempDir()).getAbsolutePath());
			lidarForwardFederate.start();
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(-1);
		}
	}
}
