/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.examples.earthCare;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

/**
 * @author ibirrer
 * @version $Id:$
 *
 */
public class Main {
	/**
	 * Log4J logger for this class
	 * @hidden
	 */
	static Logger logger = Logger.getLogger(Main.class);
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.setProperty("org.eodisp.hla.lrc.crc-uri", "urn:jxta:uuid-37AB0CEE1A5444728150BB2E14082E7A0B67FAF51C524A85B43DD07F293EEBFE03");
		Logger.getRootLogger().setLevel(Level.INFO);
		try {
			Thread plotterFederate = new Thread() {
				public void run() {
					try {
						System.out.println("Start Plot Federate");
						new PlotterFederate().start();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			};
			
			
			Thread lidarFederate = new Thread() {
				public void run() {
					try {
						System.out.println("Start LidarFederate");
						new LidarFederate().start();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			};
			
			Thread lidarFilterFederate = new Thread() {
				public void run() {
					try {
						System.out.println("Start LidarForwardFederate");
						new LidarForwardFederate().start();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			};
			
			Thread sceneCreatorFederate = new Thread() {
				public void run() {
					try {
						System.out.println("Start Start SceneCreator");
						new SceneCreatorFederate().start();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			};
			
			plotterFederate.setName("Plotter Federate");
			plotterFederate.start();
			Thread.currentThread().sleep(5 * 1000);
			
			lidarFederate.setName("Lidar Federate");
			lidarFederate.start();
			Thread.currentThread().sleep(2 * 1000);
			
			lidarFilterFederate.setName("Lidar Filter Federate");
			lidarFilterFederate.start();
			Thread.currentThread().sleep(2 * 1000);
			
			sceneCreatorFederate.setName("Scene Creator Federate");
			sceneCreatorFederate.start();			
			
		} catch (Throwable e) {
			e.printStackTrace();
		} finally {
			
		}
	}
	
	
}
