/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.examples.earthCare;

import hla.rti1516.*;
import hla.rti1516.jlc.NullFederateAmbassador;
import hla.rti1516.jlc.RtiFactory;
import hla.rti1516.jlc.RtiFactoryFactory;

import java.io.File;
import java.net.URL;

import org.apache.log4j.Logger;
import org.eodisp.examples.earthCare.wrapper.SceneCreatorProgramWrapper;
import org.eodisp.hla.common.handles.AttributeHandleSetImpl;
import org.eodisp.hla.common.handles.AttributeHandleValueMapImpl;
import org.eodisp.util.FileUtil;

/**
 * Wraps the EarthCARE lid_filter executable as a federate. It is subscribed to
 * the object class Scene and begins executing as soon as the <code>data</code>
 * attribute of the scene is updated/reflected.
 * 
 * Configuration is taken from the earthCAREH installation
 * 
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class SceneCreatorFederate extends NullFederateAmbassador {

	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	static Logger logger = Logger.getLogger(SceneCreatorFederate.class);

	private RTIambassador rtiAmbassador;

	private ObjectClassHandle sceneObjectClassHandle;

	private AttributeHandle sceneDataAttributeHandle;

	/**
	 * @throws Exception
	 */
	public void start() throws Exception {
		RtiFactory rtiFactory = RtiFactoryFactory.getRtiFactory();
		rtiAmbassador = rtiFactory.getRtiAmbassador();
		URL url = getClass().getClassLoader().getResource("resources/earthCAREDemo.fdd");
		System.out.println(getClass().getClassLoader().getResource(""));
		System.out.println(url.getFile());

		try {
			rtiAmbassador.createFederationExecution(EarthCareFOM.FEDERATION_EXECUTION_NAME, url);
			logger.debug("Created federation execution: " + EarthCareFOM.FEDERATION_EXECUTION_NAME);
		} catch (FederationExecutionAlreadyExists e) {
			logger.debug(String.format(
					"Federation execution %s already exists. Don't create a new one but join it.",
					EarthCareFOM.FEDERATION_EXECUTION_NAME));
		}
		rtiAmbassador.joinFederationExecution("NA", EarthCareFOM.FEDERATION_EXECUTION_NAME, this, null);

		sceneObjectClassHandle = rtiAmbassador.getObjectClassHandle(EarthCareFOM.SCENE_OBJECT_CLASS);

		sceneDataAttributeHandle = rtiAmbassador.getAttributeHandle(sceneObjectClassHandle, "data");

		AttributeHandleSet attributeHandleSet = new AttributeHandleSetImpl();
		attributeHandleSet.add(sceneDataAttributeHandle);

		rtiAmbassador.publishObjectClassAttributes(sceneObjectClassHandle, attributeHandleSet);

		// Register a Scene instance
		ObjectInstanceHandle sceneInstanceHandle = rtiAmbassador.registerObjectInstance(sceneObjectClassHandle);

		// Create a new scene
		logger.info("Create new simple scene");
		SceneCreatorProgramWrapper sceneCreatorProgramWrapper = new SceneCreatorProgramWrapper("test");
		byte[] generatedScene = sceneCreatorProgramWrapper.execute();

		logger.info("Updating scene on scene object instance: " + sceneInstanceHandle);

		AttributeHandleValueMap attributeHandleValueMap = new AttributeHandleValueMapImpl();
		attributeHandleValueMap.put(sceneDataAttributeHandle, generatedScene);

		rtiAmbassador.updateAttributeValues(sceneInstanceHandle, attributeHandleValueMap, new byte[0]);
		System.out.println("Update finished...");
	}

	public static void main(String[] args) {
		SceneCreatorFederate sceneCreatorFederate = new SceneCreatorFederate();
		try {

			// local CRC
			System.setProperty(
					"org.eodisp.hla.lrc.crc-uri",
					"urn:jxta:uuid-37AB0CEE1A5444728150BB2E14082E7AB3178704BDD34772A4F5E62A57A4E2C903");

			// eodisp.org CRC
			// System.setProperty(
			// "org.eodisp.hla.lrc.crc-uri",
			// "urn:jxta:uuid-37AB0CEE1A5444728150BB2E14082E7A52339EB7CD454591A176FAF1A150CBB003");

			// windows ETLK 14.1
			// System.setProperty("org.eodisp.hla.lrc.crc-uri",
			// "urn:jxta:uuid-37AB0CEE1A5444728150BB2E14082E7A198BCBAA224D430C82A38AFB60C053A303");
			System.setProperty("org.eodisp.remote.reset-jxta-config", "true");
			System.setProperty("org.eodisp.working-dir", new File(FileUtil.getTempDir(), "SceneCreatorFederate")
					.getAbsolutePath());
			System.setProperty("org.eodisp.log-level", "debug");
			sceneCreatorFederate.start();
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(-1);
		}
	}
}
