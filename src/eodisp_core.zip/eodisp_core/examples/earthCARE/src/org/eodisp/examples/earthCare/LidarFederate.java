/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.examples.earthCare;

import hla.rti1516.*;
import hla.rti1516.jlc.RtiFactory;
import hla.rti1516.jlc.RtiFactoryFactory;

import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.eodisp.examples.earthCare.wrapper.LidarProgramWrapper;
import org.eodisp.hla.common.handles.AttributeHandleSetImpl;
import org.eodisp.hla.common.handles.AttributeHandleValueMapImpl;

/**
 * Wraps the EarthCARE lidar executable as a federate. It is subscribed to the
 * object class FilteredScene and begins executing as soon as the
 * <code>data</code> attribute of the filtered scene is updated/reflected.
 * 
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class LidarFederate extends BasicFederateAmbassador {

	Map<ObjectInstanceHandle, ObjectInstanceHandle> lidarOutputInstances = new HashMap<ObjectInstanceHandle, ObjectInstanceHandle>();

	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	static Logger logger = Logger.getLogger(LidarFederate.class);

	private RTIambassador rtiAmbassador;

	private ObjectClassHandle filteredSceneObjectClassHandle;

	private ObjectClassHandle lidarOutputObjectClassHandle;

	private AttributeHandle filteredSceneDataAttributeHandle;

	public LidarFederate() {

	}

	/**
	 * @throws Exception
	 */
	public void start() throws Exception {
		RtiFactory rtiFactory = RtiFactoryFactory.getRtiFactory();
		rtiAmbassador = rtiFactory.getRtiAmbassador();
		URL url = new URL("file:///home/ibirrer/pnp/erti/examples/earthCAREDemo/resources/earthCAREDemo.fdd");

		try {
			rtiAmbassador.createFederationExecution(EarthCareFOM.FEDERATION_EXECUTION_NAME, url);
			logger.debug("Created federation execution: " + EarthCareFOM.FEDERATION_EXECUTION_NAME);
		} catch (FederationExecutionAlreadyExists e) {
			logger.debug(String.format(
					"Federation execution %s already exists. Don't create a new one but join it.",
					EarthCareFOM.FEDERATION_EXECUTION_NAME));
		}
		rtiAmbassador.joinFederationExecution("NA", EarthCareFOM.FEDERATION_EXECUTION_NAME, this, null);

		filteredSceneObjectClassHandle = rtiAmbassador.getObjectClassHandle(EarthCareFOM.FILTERED_SCENE_OBJECT_CLASS);
		lidarOutputObjectClassHandle = rtiAmbassador.getObjectClassHandle(EarthCareFOM.LIDAR_OUTPUT_OBJECT_CLASS);

		filteredSceneDataAttributeHandle = rtiAmbassador.getAttributeHandle(filteredSceneObjectClassHandle, "data");
		// Subscribe to Filtered Scene
		AttributeHandleSet attributeHandleSet = new AttributeHandleSetImpl();
		attributeHandleSet.add(filteredSceneDataAttributeHandle);

		rtiAmbassador.subscribeObjectClassAttributes(filteredSceneObjectClassHandle, attributeHandleSet);

		logger.info(String.format("Subscribed to: " + EarthCareFOM.FILTERED_SCENE_OBJECT_CLASS));
	}

	/**
	 * {@inheritDoc}
	 */
	public void reflectAttributeValues(final ObjectInstanceHandle theObject,
			final AttributeHandleValueMap theAttributes, byte[] userSuppliedTag, OrderType sentOrdering,
			TransportationType theTransport) throws ObjectInstanceNotKnown, AttributeNotRecognized,
			AttributeNotSubscribed, FederateInternalError {
		// run in a thread for now. This thread should probably be started by
		// the LRC
		Thread t = new Thread() {
			public void run() {
				logger.debug("Lidar Federate: Reflect attribute value map");
				// We only subscribed to FilteredScene class so we are sure we
				// always get instances of this type
				ObjectInstanceHandle lidarOutputInstanceHandle = lidarOutputInstances.get(theObject);
				if (lidarOutputInstanceHandle == null) {
					try {
						lidarOutputInstanceHandle = rtiAmbassador.registerObjectInstance(lidarOutputObjectClassHandle);
					} catch (ObjectClassNotDefined e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (ObjectClassNotPublished e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (FederateNotExecutionMember e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SaveInProgress e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (RestoreInProgress e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (RTIinternalError e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					lidarOutputInstances.put(theObject, lidarOutputInstanceHandle);
					logger.debug("Lidar Federate: Registered new lidarOuput instance");
				}

				// Save the received data to disk and run the lidar executable
				// with this data
				byte[] data = (byte[]) theAttributes.get(filteredSceneDataAttributeHandle);
				if (data == null) {
					logger
							.fatal("Lidar Federate: Received wrong attributes. Expected attribute 'data' from FilteredScene");
					return;
				}

				try {
					LidarProgramWrapper lidarProgram = new LidarProgramWrapper(data, lidarOutputInstanceHandle + "");
					Map<String, byte[]> lidarOutputData = lidarProgram.execute();

					Map<AttributeHandle, ChannelData> updateData = new HashMap<AttributeHandle, ChannelData> ();

					AttributeHandle backgroundAndDarkgroundSubtracted = rtiAmbassador.getAttributeHandle(
							lidarOutputObjectClassHandle,
							"backgroundAndDarkgroundSubtracted");

					AttributeHandle noiseVariance = rtiAmbassador.getAttributeHandle(
							lidarOutputObjectClassHandle,
							"noiseVariance");

					AttributeHandle crossTalkFactorMie = rtiAmbassador.getAttributeHandle(
							lidarOutputObjectClassHandle,
							"crossTalkFactorMie");
					
					AttributeHandle virtualCoPolarMie = rtiAmbassador.getAttributeHandle(
							lidarOutputObjectClassHandle,
							"virtualCoPolarMie");

					AttributeHandle virtualCrossPolarMie = rtiAmbassador.getAttributeHandle(
							lidarOutputObjectClassHandle,
							"virtualCrossPolarMie");

					AttributeHandle virtualCoPolarRayleigh = rtiAmbassador.getAttributeHandle(
							lidarOutputObjectClassHandle,
							"virtualCoPolarRayleigh");

					AttributeHandle virtualCrossPolarRayleigh = rtiAmbassador.getAttributeHandle(
							lidarOutputObjectClassHandle,
							"virtualCrossPolarRayleigh");

					AttributeHandle virtualCoPolarTotal = rtiAmbassador.getAttributeHandle(
							lidarOutputObjectClassHandle,
							"virtualCoPolarTotal");

					AttributeHandle virtualCrossPolarTotal = rtiAmbassador.getAttributeHandle(
							lidarOutputObjectClassHandle,
							"virtualCrossPolarTotal");

					AttributeHandle varianceCoPolarMie = rtiAmbassador.getAttributeHandle(
							lidarOutputObjectClassHandle,
							"varianceCoPolarMie");

					AttributeHandle varianceCrossPolarMie = rtiAmbassador.getAttributeHandle(
							lidarOutputObjectClassHandle,
							"varianceCrossPolarMie");

					AttributeHandle varianceCoPolarRayleigh = rtiAmbassador.getAttributeHandle(
							lidarOutputObjectClassHandle,
							"varianceCoPolarRayleigh");

					AttributeHandle varianceCrossPolarRayleigh = rtiAmbassador.getAttributeHandle(
							lidarOutputObjectClassHandle,
							"varianceCrossPolarRayleigh");

					AttributeHandle varianceCoPolarTotal = rtiAmbassador.getAttributeHandle(
							lidarOutputObjectClassHandle,
							"varianceCoPolarTotal");

					AttributeHandle varianceCrossPolarTotal = rtiAmbassador.getAttributeHandle(
							lidarOutputObjectClassHandle,
							"varianceCrossPolarTotal");

					AttributeHandle crossTalkFactorRayleigh = rtiAmbassador.getAttributeHandle(
							lidarOutputObjectClassHandle,
							"crossTalkFactorRayleigh");

					AttributeHandle temperatureProfile = rtiAmbassador.getAttributeHandle(
							lidarOutputObjectClassHandle,
							"temperatureProfile");

					AttributeHandle rayleighExtinctionProfile = rtiAmbassador.getAttributeHandle(
							lidarOutputObjectClassHandle,
							"rayleighExtinctionProfile");
					
					
					updateData.put(backgroundAndDarkgroundSubtracted, new ChannelData());
					updateData.put(noiseVariance, new ChannelData());
					updateData.put(virtualCoPolarMie, new ChannelData());
					updateData.put(virtualCrossPolarMie, new ChannelData());
					updateData.put(virtualCoPolarRayleigh, new ChannelData());
					updateData.put(virtualCrossPolarRayleigh, new ChannelData());
					updateData.put(virtualCoPolarTotal, new ChannelData());
					updateData.put(virtualCrossPolarTotal, new ChannelData());
					updateData.put(varianceCoPolarMie, new ChannelData());
					updateData.put(varianceCrossPolarMie, new ChannelData());
					updateData.put(varianceCoPolarRayleigh, new ChannelData());
					updateData.put(varianceCrossPolarRayleigh, new ChannelData());
					updateData.put(varianceCoPolarTotal, new ChannelData());
					updateData.put(varianceCrossPolarTotal, new ChannelData());
					updateData.put(crossTalkFactorRayleigh, new ChannelData());
					updateData.put(temperatureProfile, new ChannelData());
					updateData.put(rayleighExtinctionProfile, new ChannelData());

					// go through output data and add to update attributes:
					
					AttributeHandleValueMap attributeHandleValueMap = new AttributeHandleValueMapImpl();
					
					for (Map.Entry<String, byte[]> entry : lidarOutputData.entrySet()) {
						
						AttributeHandle currentHandle = null;
						String key = entry.getKey();
						logger.debug("process: " + key);

						if (key.length() == 12) {
							currentHandle = backgroundAndDarkgroundSubtracted;
						} else if (key.contains("_noise_")) {
							currentHandle = noiseVariance;
						} else if (key.contains("_mie_interchannel.dat")) {
							currentHandle = crossTalkFactorMie;
							attributeHandleValueMap.put( currentHandle, entry.getValue() );
							continue;
						} else if (key.contains("_para_mie_")) {
							currentHandle = virtualCoPolarMie;
						} else if (key.contains("_perp_mie__")) {
							currentHandle = virtualCrossPolarMie;
						} else if (key.contains("_para_ray_")) {
							currentHandle = virtualCoPolarRayleigh;
						} else if (key.contains("_perp_Ray_")) {
							currentHandle = virtualCrossPolarRayleigh;
						} else if (key.contains("_tot_para_")) {
							currentHandle =  virtualCoPolarTotal;
						} else if (key.contains("_tot_perp_")) {
							currentHandle = virtualCrossPolarTotal;
						} else if (key.contains("_para_mie_error_")) {
							currentHandle = varianceCoPolarMie;
						} else if (key.contains("_perp_mie_error_")) {
							currentHandle = varianceCrossPolarMie;
						} else if (key.contains("_para_ray_error_")) {
							currentHandle = varianceCoPolarRayleigh;
						} else if (key.contains("_perp_ray_error_")) {
							currentHandle = varianceCrossPolarRayleigh;
						} else if (key.contains("_tot_para_error_")) {
							currentHandle = varianceCoPolarTotal;
						} else if (key.contains("_tot_perp_error_")) {
							currentHandle = varianceCrossPolarTotal;
						} else if (key.contains("_Ray_X_talk")) {
							currentHandle = crossTalkFactorRayleigh;
						} else if (key.contains("_Temperature_")) {
							currentHandle = temperatureProfile;
						} else if (key.contains("_Ray_ext_")) {
							currentHandle = rayleighExtinctionProfile;
						} else {
							logger.error("No attribute defined for file: " + key);
							continue;
						}
						
						
						ChannelData channelData = updateData.get( currentHandle );
						int channelNr = Integer.valueOf( key.substring( key.length() - 6, key.length() -4 ) ).intValue();
						int wavelenght = Integer.valueOf( key.substring( 1, 5 ) ).intValue();
						logger.debug(String.format( "ChannelNr: %d, Wavelength: %d", channelNr, wavelenght ));
						channelData.addChannelData( channelNr, entry.getValue() );
						channelData.setWavelength( wavelenght );
						channelData.addChannelData(channelNr, entry.getValue() );
					} // for lidarOutputData.entrySet()
					
					
					
					for( Map.Entry<AttributeHandle, ChannelData> updateEntry : updateData.entrySet() ) {
						ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
						ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
						objectOutputStream.writeObject( updateEntry.getValue() );
						attributeHandleValueMap.put( updateEntry.getKey(), byteArrayOutputStream.toByteArray() );
					}
					
					logger.info("Lidar Federate updates attribute values on LidarOutput object class instance "
							+ lidarOutputInstanceHandle);

					rtiAmbassador.updateAttributeValues(lidarOutputInstanceHandle, attributeHandleValueMap, new byte[0]);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		};
		t.start();
	}

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) {
		
	}

}
