/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.examples.earthCare.wrapper;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class MasterConfig {

	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	static Logger logger = Logger.getLogger(MasterConfig.class);

	private String sceneFile = "./output/scene_creator/scene.out";

	private String orbitInFile = "./input/orbit.inp";

	private String surfaceModelInfoFile = "./data/RPV_parameters.txt";

	private String lidFilterIn = "./input/lid_filter/lid_filter.inp";

	private String lidFilterOut = "./output/lid_filter/lid_filter.out";

	private String lidarIn = "./input/lidar/lidar.inp";

	private String lidarOut = "./output/lidar/lidar.out";

	private String radarFilterIn = "./input/rad_filter/rad_filter.inp";

	private String radarFilterOut = "./output/rad_filter/rad_filter.out";

	private String radarIn = "./input/radar/radar.inp";

	private String radarOut = "./output/radar/radar.out";

	private String lidarRet1InFile = "./input/lidar_ret1/lidar_ret1.inp";

	private String lidarRet1OutFile = "./output/lidar_ret1/lidar_ret1.out";

	public void save(File file) throws IOException {
		file.createNewFile();
		PrintWriter printWriter = new PrintWriter(file, "UTF-8");
		printWriter.println("#");
		printWriter.println("#============================");
		printWriter.println("# Size dist scaling factor");
		printWriter.println("# 1.0 ==> N is in 1/cm^3");
		printWriter.println("#============================");
		printWriter.println("#");
		printWriter.println("1.0");
		printWriter.println("#");
		printWriter.println("#=============================");
		printWriter.println("# Override the Surface type");
		printWriter.println("# and sub-type ");
		printWriter.println("# in the UFF file ?");
		printWriter.println("# -1,-1 ==> use the surface ");
		printWriter.println("# info in rthe scene file ");
		printWriter.println("# For list of Valid surface ");
		printWriter.println("# types see the");
		printWriter.println("# scene_creator input file");
		printWriter.println("#=============================");
		printWriter.println("#");
		printWriter.println("-1,-1");
		printWriter.println("#");
		printWriter.println("#===================================");
		printWriter.println("# Input directory to be substituted");
		printWriter.println("# for `$inpath' in inputfiles. ");
		printWriter.println("# Enter `null' if not used");
		printWriter.println("#===================================");
		printWriter.println("#");
		printWriter.println("null");
		printWriter.println("# ");
		printWriter.println("#====================================");
		printWriter.println("# Output directory to be substituted");
		printWriter.println("# for `$outpath' in outputfiles. ");
		printWriter.println("# Enter `null' if not used");
		printWriter.println("#===================================");
		printWriter.println("#");
		printWriter.println("null");
		printWriter.println("#");
		printWriter.println("#=============================");
		printWriter.println("# UFF FILE DEFINING THE SCENE");
		printWriter.println("#=============================");
		printWriter.println("#");
		// Scene file
		printWriter.println(sceneFile);
		printWriter.println("#");
		printWriter.println("#========================================");
		printWriter.println("# Orbit file defining altitude and where ");
		printWriter.println("# we will fly over the scene");
		printWriter.println("#========================================");
		printWriter.println("#");
		// Orbit In File
		printWriter.println(orbitInFile);
		printWriter.println("#");
		printWriter.println("#====================================");
		printWriter.println("# File containing Surface model info");
		printWriter.println("#====================================");
		printWriter.println("#");
		// Surface model file
		printWriter.println(this.surfaceModelInfoFile);
		printWriter.println("#");
		printWriter.println("#=============");
		printWriter.println("# LIDAR FILES");
		printWriter.println("#=============");
		printWriter.println("#");
		printWriter.println("# lid_filter input");
		// lid filter input
		printWriter.println(lidFilterIn);
		printWriter.println("#");
		printWriter.println("# lid_filter output");
		// lid filter output
		printWriter.println(lidFilterOut);
		printWriter.println("#");
		printWriter.println("# lidar instrument module input");
		// lidar input
		printWriter.println(lidarIn);
		printWriter.println("#");
		printWriter.println("# lidar instrument module output");
		// lidar out
		printWriter.println(lidarOut);
		printWriter.println("#");
		printWriter.println("#=============");
		printWriter.println("# RADAR FILES");
		printWriter.println("#=============");
		printWriter.println("#");
		printWriter.println("# rad_filter input");
		// radar input
		printWriter.println(radarFilterIn);
		printWriter.println("#");
		printWriter.println("# rad_filter output");
		// radar output
		printWriter.println(radarFilterOut);
		printWriter.println("#");
		printWriter.println("# radar instrument module input");

		// Radar instrument input
		printWriter.println(radarIn);
		printWriter.println("#./input/radar/radar_hr.inp");
		printWriter.println("#");
		printWriter.println("# radar instrument module output");
		printWriter.println(radarOut);
		printWriter.println("#./output/radar/radar_hr.out");
		printWriter.println("#");
		printWriter.println("#=============");
		printWriter.println("# SW MC FILES");
		printWriter.println("#=============");
		printWriter.println("#");
		printWriter.println("# MC_SW input file");
		printWriter.println("./input/sw_mc/sw_mc.inp");
		printWriter.println("# MC_SW output file");
		printWriter.println("./output/sw_mc/sw_mc.out");
		printWriter.println("#");
		printWriter.println("#=============");
		printWriter.println("# LW MC FILES");
		printWriter.println("#=============");
		printWriter.println("#");
		printWriter.println("# MC_LW input file");
		printWriter.println("./input/lw_mc/lw_mc.inp");
		printWriter.println("# MC_LW output file");
		printWriter.println("./output/lw_mc/lw_mc.out");
		printWriter.println("#");
		printWriter.println("#==========================");
		printWriter.println("# Lidar single instrument");
		printWriter.println("# retrievals");
		printWriter.println("#==========================");
		printWriter.println("#");
		// lidar retrieval in
		printWriter.println(lidarRet1InFile);
		printWriter.println("#");
		// lidar retrieval out
		printWriter.println(lidarRet1OutFile);
		printWriter.println("#");
		printWriter.println("#============================");
		printWriter.println("# lw lidar radar msi ret");
		printWriter.println("#============================");
		printWriter.println("#");
		printWriter.println("./input/lw_msi_lidar_radar/lw_msi_lidar_radar.inp");
		printWriter.println("#");
		printWriter.println("./output/lw_msi_lidar_radar/lw_msi_lidar_radar.out");
		printWriter.println("#");
		printWriter.println("#==============");
		printWriter.println("# MSI only ret");
		printWriter.println("#===============");
		printWriter.println("#");
		printWriter.println("./input/msi_ret/msi_ret.inp");
		printWriter.println("#");
		printWriter.println("./output/msi_ret/msi_ret.out");

		logger.debug(String.format("Write master config to: %s", file.getAbsoluteFile()));
		printWriter.close();
	}
	
	
	


	/**
	 * @return Returns the lidarIn.
	 */
	public String getLidarIn() {
		return lidarIn;
	}





	/**
	 * @param lidarIn The lidarIn to set.
	 */
	public void setLidarIn(String lidarIn) {
		this.lidarIn = lidarIn;
	}





	/**
	 * @return Returns the lidarOut.
	 */
	public String getLidarOut() {
		return lidarOut;
	}





	/**
	 * @param lidarOut The lidarOut to set.
	 */
	public void setLidarOut(String lidarOut) {
		this.lidarOut = lidarOut;
	}





	/**
	 * @return Returns the lidarRet1InFile.
	 */
	public String getLidarRet1InFile() {
		return lidarRet1InFile;
	}





	/**
	 * @param lidarRet1InFile The lidarRet1InFile to set.
	 */
	public void setLidarRet1InFile(String lidarRet1InFile) {
		this.lidarRet1InFile = lidarRet1InFile;
	}





	/**
	 * @return Returns the lidarRet1OutFile.
	 */
	public String getLidarRet1OutFile() {
		return lidarRet1OutFile;
	}





	/**
	 * @param lidarRet1OutFile The lidarRet1OutFile to set.
	 */
	public void setLidarRet1OutFile(String lidarRet1OutFile) {
		this.lidarRet1OutFile = lidarRet1OutFile;
	}





	/**
	 * @return Returns the lidFilterIn.
	 */
	public String getLidFilterIn() {
		return lidFilterIn;
	}





	/**
	 * @param lidFilterIn The lidFilterIn to set.
	 */
	public void setLidFilterIn(String lidFilterIn) {
		this.lidFilterIn = lidFilterIn;
	}





	/**
	 * @return Returns the lidFilterOut.
	 */
	public String getLidFilterOut() {
		return lidFilterOut;
	}





	/**
	 * @param lidFilterOut The lidFilterOut to set.
	 */
	public void setLidFilterOut(String lidFilterOut) {
		this.lidFilterOut = lidFilterOut;
	}





	/**
	 * @return Returns the orbitInFile.
	 */
	public String getOrbitInFile() {
		return orbitInFile;
	}





	/**
	 * @param orbitInFile The orbitInFile to set.
	 */
	public void setOrbitInFile(String orbitInFile) {
		this.orbitInFile = orbitInFile;
	}





	/**
	 * @return Returns the radarFilterIn.
	 */
	public String getRadarFilterIn() {
		return radarFilterIn;
	}





	/**
	 * @param radarFilterIn The radarFilterIn to set.
	 */
	public void setRadarFilterIn(String radarFilterIn) {
		this.radarFilterIn = radarFilterIn;
	}





	/**
	 * @return Returns the radarFilterOut.
	 */
	public String getRadarFilterOut() {
		return radarFilterOut;
	}





	/**
	 * @param radarFilterOut The radarFilterOut to set.
	 */
	public void setRadarFilterOut(String radarFilterOut) {
		this.radarFilterOut = radarFilterOut;
	}





	/**
	 * @return Returns the radarIn.
	 */
	public String getRadarIn() {
		return radarIn;
	}





	/**
	 * @param radarIn The radarIn to set.
	 */
	public void setRadarIn(String radarIn) {
		this.radarIn = radarIn;
	}





	/**
	 * @return Returns the radarOut.
	 */
	public String getRadarOut() {
		return radarOut;
	}





	/**
	 * @param radarOut The radarOut to set.
	 */
	public void setRadarOut(String radarOut) {
		this.radarOut = radarOut;
	}





	/**
	 * @return Returns the sceneFile.
	 */
	public String getSceneFile() {
		return sceneFile;
	}





	/**
	 * @param sceneFile The sceneFile to set.
	 */
	public void setSceneFile(String sceneFile) {
		this.sceneFile = sceneFile;
	}





	/**
	 * @return Returns the surfaceModelInfoFile.
	 */
	public String getSurfaceModelInfoFile() {
		return surfaceModelInfoFile;
	}





	/**
	 * @param surfaceModelInfoFile The surfaceModelInfoFile to set.
	 */
	public void setSurfaceModelInfoFile(String surfaceModelInfoFile) {
		this.surfaceModelInfoFile = surfaceModelInfoFile;
	}





	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		Logger.getRootLogger().addAppender(
				new ConsoleAppender(new PatternLayout("%r [%t] %p %l %x - %m%n"), "System.out"));
		MasterConfig masterInputFile = new MasterConfig();
		masterInputFile.save( new File("/tmp/masterTestFile.inp") );
	}

}
