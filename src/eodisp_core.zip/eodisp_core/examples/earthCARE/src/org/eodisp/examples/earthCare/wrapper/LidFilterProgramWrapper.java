/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.examples.earthCare.wrapper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.types.Environment;
import org.apache.tools.ant.types.Commandline.Argument;
import org.eodisp.examples.earthCare.*;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class LidFilterProgramWrapper {

	private static final String SCENE_FILENAME = "scene.dat";

	private static final String FILTERED_SCENE_FILENAME = "filteredScene.dat";

	private static final String MASTER_INPUT_FILENAME = "master.inp";

	private static final String EXECUTABLE = "bin/lid_filter";

	private static final String TMP_DIR_PREFIX = "lid_filter_";

	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	static Logger logger = Logger.getLogger(LidFilterProgramWrapper.class);

	private File sceneFile;

	private File earthCareInstallDir;

	private File workingDir;

	private File filteredSceneFile;

	private File executable;

	public LidFilterProgramWrapper(File sceneFile, String tmpDirName) throws IOException {
		initEarthCareInstallDir();
		initWorkingDir(tmpDirName);
		this.sceneFile = sceneFile;
		createMasterConficFile();
	}

	public LidFilterProgramWrapper(byte[] sceneData, String tmpDirName) throws IOException {
		initEarthCareInstallDir();
		initWorkingDir(tmpDirName);

		sceneFile = new File(workingDir, SCENE_FILENAME);

		// Save the scene in a file
		sceneFile.createNewFile();
		FileOutputStream fileOutputStream = new FileOutputStream(sceneFile);
		fileOutputStream.write(sceneData);
		fileOutputStream.close();
		createMasterConficFile();
	}

	private void createMasterConficFile() throws IOException {
		MasterConfig masterInputFile = new MasterConfig();
		masterInputFile.setSceneFile(sceneFile.getAbsolutePath());
		masterInputFile.setLidFilterOut(filteredSceneFile.getAbsolutePath());
		File file = new File(workingDir, MASTER_INPUT_FILENAME);
		logger.debug("Save master input file " + file);
		masterInputFile.save(file);
	}

	private void initWorkingDir(String tmpDirName) {
		workingDir = new File(new File(System.getProperty("java.io.tmpdir")), TMP_DIR_PREFIX + tmpDirName);
		workingDir.mkdirs();
		filteredSceneFile = new File(workingDir, FILTERED_SCENE_FILENAME);
		logger.debug("LidFilter working dir: " + workingDir.getAbsolutePath());
	}

	private void initEarthCareInstallDir() {
		String home = System.getenv("EARTH_CARE_INSTALL_DIR");
		if (home == null) {
			// TODO better default value
			home = "/home/ibirrer/pnp/earthcare_sim";
		}
		earthCareInstallDir = new File(home);
		executable = new File(earthCareInstallDir, EXECUTABLE);
		logger.debug("EARTH_CARE_INSTALL_DIR: " + earthCareInstallDir.getAbsolutePath());
		logger.debug("EXECUTABLE: " + executable.getAbsolutePath());
	}

	/**
	 * @return The scene file as byte array.
	 * @throws ExitStatusException
	 * @throws IOException
	 */
	public byte[] execute() throws ExitStatusException, IOException {
		// If there's an output available on this we just return this one without computing it again.
		// TODO: this is for demo purposes only because it takes about 30 min. to compute the filtered scene.
		if (!filteredSceneFile.exists()) {
			ProgramExecution lidarExec = new ProgramExecution(true);
			lidarExec.setTaskName(EXECUTABLE);
			lidarExec.setFailonerror(true);
			lidarExec.setExecutable(new File(earthCareInstallDir, EXECUTABLE).getAbsolutePath());
			lidarExec.setDir(earthCareInstallDir);
			Argument arg = lidarExec.createArg();
			arg.setValue(new File(workingDir, MASTER_INPUT_FILENAME).getAbsolutePath());

			// Disable Terminal (vt200) output
//			Environment.Variable envVar = new Environment.Variable();
//			envVar.setKey("NOXTERMFWIN");
//			envVar.setValue("true");
//			lidarExec.addEnv(envVar);
			logger.info("Execute " + EXECUTABLE);
			try {
				lidarExec.execute();
			} catch (BuildException e) {
				throw new ExitStatusException(e);
			}
		} else {
			logger.warn("Omitted computing of filtered scene because temporary output found at: " + filteredSceneFile.getAbsolutePath());
		}
		logger.info("LidFilter has finished computing the filtered scene. Temporary file saved at " + filteredSceneFile.getAbsolutePath());
		return Util.getBytesFromFile(filteredSceneFile);
	}

	public static void main(String[] args) throws IOException, ExitStatusException {
		Logger.getRootLogger().addAppender(
				new ConsoleAppender(new PatternLayout("%5p - %m%n"), "System.out"));
		LidFilterProgramWrapper lidFilterProgramWrapper = new LidFilterProgramWrapper(new File("/tmp/scene"), "test");
		lidFilterProgramWrapper.execute();
	}
}
