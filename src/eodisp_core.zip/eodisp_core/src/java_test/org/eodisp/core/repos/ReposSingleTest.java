/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.repos;

import java.util.UUID;

import org.eclipse.emf.ecore.sdo.EChangeSummary;
import org.eclipse.emf.ecore.sdo.EDataGraph;
import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eodisp.core.gen.repository.impl.RepositoryPackageImpl;

import commonj.sdo.DataObject;

/**
 * @author eglimi
 * @version $Id:$
 */
public class ReposSingleTest extends ReposTest {

	@Override
	protected void setUp() throws Exception {
		// TODO Auto-generated method stub
		super.setUp();

		// init emf
		RepositoryPackageImpl.eINSTANCE.getName();
	}

	@Override
	protected void tearDown() throws Exception {
		// TODO Auto-generated method stub
		super.tearDown();
	}

	/**
	 * Tests the initial settings. For this test to succeed, many conditions
	 * must be met
	 * <ul>
	 * <li>The connections to the repository must be established. This also
	 * implies that a repository was successfully started.</li>
	 * <li>The repository could be initialized.</li>
	 * <li>The data could be transferred using the eodisp_remote package.</li>
	 * <li>The data graph was successfully marshalled and unmarshalled.</li>
	 * </ul>
	 * 
	 * @throws Exception
	 */
	public void testInitial() throws Exception {
		EDataGraph allData = reposModelService.getAllData();
		assertNotNull(allData);
	}

	/**
	 * @throws Exception
	 */
	public void testAddSimManager() throws Exception {
		String smId = UUID.randomUUID().toString();

		EDataGraph allData = reposModelService.getAllData();
		allData.getChangeSummary().beginLogging();

		EDataObject root = (EDataObject) allData.getRootObject().get(RepositoryPackageImpl.DOCUMENT_ROOT__REPOSITORY);

		DataObject simManager = root.createDataObject(RepositoryPackageImpl.REPOSITORY__SIM_MANAGERS);
		simManager.set(RepositoryPackageImpl.SIM_MANAGER__NAME, "Test Simulation Manager");
		simManager.set(RepositoryPackageImpl.SIM_MANAGER__DESCRIPTION, "Test Simulation Manager Description");
		simManager.set(RepositoryPackageImpl.SIM_MANAGER__ID, smId);

		root.getList(RepositoryPackageImpl.REPOSITORY__SIM_MANAGERS).add(simManager);

		// update
		allData.getChangeSummary().endLogging();
		((EChangeSummary) allData.getChangeSummary()).applyAndReverse();
		reposModelService.update(allData);

		// reread the data
		allData = reposModelService.getAllData();
		root = (EDataObject) allData.getRootObject().get(RepositoryPackageImpl.DOCUMENT_ROOT__REPOSITORY);
		EDataObject remoteSimManager = (EDataObject) root.get(String.format("simManager[id=%s]", smId));
		assertNotNull(remoteSimManager);
		assertEquals(smId, remoteSimManager.getString(RepositoryPackageImpl.SIM_MANAGER__ID));

		// remove if ok.
		allData.getChangeSummary().beginLogging();
		remoteSimManager.delete();
		allData.getChangeSummary().endLogging();
		((EChangeSummary) allData.getChangeSummary()).applyAndReverse();
		reposModelService.update(allData);
	}
}
