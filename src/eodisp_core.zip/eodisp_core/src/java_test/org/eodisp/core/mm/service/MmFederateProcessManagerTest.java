package org.eodisp.core.mm.service;

import java.io.File;
import java.net.URI;
import java.util.concurrent.TimeUnit;

import junit.framework.TestCase;

import org.eodisp.core.common.*;

/**
 * 
 * The following federates can be used
 * <ul>
 * <li>Federate1: org.eodisp.core.test.federate1, 0.1.1, one start</li>
 * <li>Federate2: org.eodisp.core.test.federate2, 1.0.0, multiple starts</li>
 * </ul>
 * 
 * @author iwan, eglimi
 * @version $Id:$
 * 
 */
public class MmFederateProcessManagerTest extends TestCase {
	private MmFederateProcessManager processManager;

	@Override
	protected void setUp() throws Exception {
		cleanSetUp();
	}

	public void testReadFederates() throws Exception {
		assertEquals(2, processManager.getEntries().size());
	}

	public void testGetFederate1() throws Exception {
		Federate federate = processManager.getFederate("org.eodisp.core.test.federate1", "0.1.1");
		assertEquals("org.eodisp.core.test.federate1", federate.getFederateId());
		assertEquals("0.1.1", federate.getFederateVersion());
		assertEquals("Federate to test the MmFederateProcessManager", federate.getFederateDescription());
	}

	public void testGetFederate2() throws Exception {
		Federate federate = processManager.getFederate("org.eodisp.core.test.federate2", "1.0.0");
		assertEquals("org.eodisp.core.test.federate2", federate.getFederateId());
		assertEquals("1.0.0", federate.getFederateVersion());
		assertEquals("Federate to test the MmFederateProcessManager", federate.getFederateDescription());
	}

	public void testGetFederate_FederateNotKnownException_Wrong_Id() throws Exception {
		try {
			processManager.getFederate("org.eodisp.core.test.federate10", "0.1.1");
			fail("Trying to get a federate with a wrong version must throw Federate NotKnownException");
		} catch (FederateNotKnownException expected) {
			assertTrue(true);
		}
	}

	public void testGetFederate_FederateNotKnownException_Wrong_Version() throws Exception {
		try {
			processManager.getFederate("org.eodisp.core.test.federate1", "0.1.2");
			fail("Trying to get a federate with a wrong version must throw Federate NotKnownException");
		} catch (FederateNotKnownException expected) {
			assertTrue(true);
		}
	}

	public void testLockFederate1() throws Exception {
		FederateProcessHandle federateProcessHandle = processManager.lockFederate("simManagerId1", "experiment1",
				"org.eodisp.core.test.federate1", "0.1.1");
		assertNotNull(federateProcessHandle);
	}

	public void testLockFederate1_sameSm_sameExperiment() throws Exception {
		cleanSetUp();
		FederateProcessHandle federateProcessHandle1 = processManager.lockFederate("simManagerId1", "experiment1",
				"org.eodisp.core.test.federate1", "0.1.1");
		FederateProcessHandle federateProcessHandle2 = processManager.lockFederate("simManagerId1", "experiment1",
				"org.eodisp.core.test.federate1", "0.1.1");
		assertNotNull(federateProcessHandle1);
		assertNotNull(federateProcessHandle2);
		assertNotSame(federateProcessHandle1, federateProcessHandle2);
	}

	public void testLockFederate1_sameSm_otherExperiment() throws Exception {
		cleanSetUp();
		FederateProcessHandle federateProcessHandle1 = processManager.lockFederate("simManagerId1", "experiment1",
				"org.eodisp.core.test.federate1", "0.1.1");
		FederateProcessHandle federateProcessHandle2 = processManager.lockFederate("simManagerId1", "experiment2",
				"org.eodisp.core.test.federate1", "0.1.1");
		assertNotNull(federateProcessHandle1);
		assertNull(federateProcessHandle2);
	}

	public void testLockFederate1_otherSm_otherExperiment() throws Exception {
		cleanSetUp();
		FederateProcessHandle federateProcessHandle1 = processManager.lockFederate("simManagerId1", "experiment1",
				"org.eodisp.core.test.federate1", "0.1.1");
		FederateProcessHandle federateProcessHandle2 = processManager.lockFederate("simManagerId2", "experiment2",
				"org.eodisp.core.test.federate1", "0.1.1");
		assertNotNull(federateProcessHandle1);
		assertNull(federateProcessHandle2);
	}

	public void testLockFederate_parallel() throws Exception {
		cleanSetUp();
		FederateProcessHandle federateProcessHandle = processManager.lockFederate("simManagerId2", "experiment2",
				"org.eodisp.core.test.federate2", "1.0.0");
		federateProcessHandle = processManager.lockFederate("simManagerId2", "experiment2",
				"org.eodisp.core.test.federate2", "1.0.0");
		assertNotNull(federateProcessHandle);
	}

	public void testStartFederate() throws Exception {
		cleanSetUp();
		FederateProcessHandle federateProcessHandle = processManager.lockFederate("simManagerId1", "experiment1",
				"org.eodisp.core.test.federate1", "0.1.1");
		processManager.startFederate(federateProcessHandle, new URI("http://www.test.ch:6574"), "FedEx1",
				new FileInitData[] { new FileInitData(new byte[] { 'a', 'b', 'c', 'd' }, "initFileName") });
		TimeUnit.SECONDS.sleep(3);
		processManager.stopFederate(federateProcessHandle);
		TimeUnit.SECONDS.sleep(3);
	}

	public void testStartFederate_Twice() throws Exception {
		cleanSetUp();
		FederateProcessHandle federateProcessHandle = processManager.lockFederate("simManagerId1", "experiment",
				"org.eodisp.core.test.federate1", "0.1.1");
		processManager.startFederate(federateProcessHandle, new URI("http://www.test.ch:6574"), "FedEx1",
				new FileInitData[] { new FileInitData(new byte[] { 'a', 'b', 'c', 'd' }, "initFileName") });
		try {
			processManager.startFederate(federateProcessHandle, new URI("http://www.test.ch:6574"), "FedEx1",
					new FileInitData[] { new FileInitData(new byte[] { 'a', 'b', 'c', 'd' }, "initFileName") });
		} catch (FederateStartException ex) {
			assertTrue(true);
		}
		TimeUnit.SECONDS.sleep(2);
		processManager.stopFederate(federateProcessHandle);
		TimeUnit.SECONDS.sleep(3);
	}

	private void cleanSetUp() {
		processManager = new MmFederateProcessManager();
		processManager.readFederates(new File("dist/test/federates"));
	}

}
