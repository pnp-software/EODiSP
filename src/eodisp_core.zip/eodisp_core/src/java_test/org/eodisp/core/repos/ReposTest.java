package org.eodisp.core.repos;

import java.io.File;
import java.net.URI;
import java.rmi.registry.Registry;
import java.util.EnumSet;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.eodisp.core.common.ReposModelService;
import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.remote.config.RemoteConfiguration.TransportType;
import org.eodisp.remote.launcher.RootAppProcessFactoryRemote;
import org.eodisp.remote.launcher.RootAppProcessRemote;
import org.eodisp.remote.launcher.server.LaunchServerRemote;
import org.eodisp.remote.launcher.server.LaunchServerRemoteImpl;
import org.eodisp.remote.registry.JeriRegistry;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.FileUtil;
import org.eodisp.util.RootApp;
import org.eodisp.util.junit.FixtureTestCase;

public class ReposTest extends FixtureTestCase {

	protected static ReposModelService reposModelService;

	public static final File DEFAULT_WORKING_DIR = new File(
			new File(System.getProperty("user.home"), ".eodisp"),
			"repos-test-client");

	public static RootAppProcessRemote reposProcessRemote;

	@Override
	protected void setUpFixture() throws Exception {
		TransportType transportType = TransportType.JXTA;

		System.setProperty("org.eodisp.working-dir", FileUtil.createTempDir("ReposTmp", "", null).getAbsolutePath());
		System.setProperty("org.eodisp.log-level", "debug");
		System.setProperty("org.eodisp.remote.transport", transportType.toString());

		RootApp reposApp = new RootApp("repos app client", "repos app client for tests", DEFAULT_WORKING_DIR, null);
		reposApp.registerAppModule(new RemoteAppModule(0));

		reposApp.execute(new String[] {});

		// Get launch server
		RemoteAppModule remoteAppModule = (RemoteAppModule) AppRegistry.getRootApp().getAppModule(RemoteAppModule.ID);
		// local
		Registry launchServerRegistry = remoteAppModule.getRegistry(URI
				.create("urn:jxta:uuid-59616261646162614E5047205032503319CD32F4F7524318B4A6A3499741221503"));
		

		LaunchServerRemote launchServerRemote = (LaunchServerRemote) launchServerRegistry
				.lookup(LaunchServerRemoteImpl.REGISTRY_NAME);
		System.out.println(launchServerRemote);
		RootAppProcessFactoryRemote reposProcessFactoryRemote = (RootAppProcessFactoryRemote) launchServerRemote
				.newProcessFactory(ReposProcessFactory.FACTORY_ID);

		reposProcessFactoryRemote.setTransports(EnumSet.of(transportType));

		reposProcessRemote = (RootAppProcessRemote) reposProcessFactoryRemote.newProcess();

		Map<TransportType, JeriRegistry> reposRegistries;
		System.out.println("JUnit: Starting Repository ...");
		if ((reposRegistries = reposProcessRemote.launchBlocking(120, TimeUnit.SECONDS)) == null) {
			fail("Could not start reposModelService Process");
		}

		final JeriRegistry reposJeriRegistry = reposRegistries.get(transportType);
		reposModelService = (ReposModelService) reposJeriRegistry.lookup(ReposModelService.REGISTRY_NAME);
	}

	@Override
	protected void tearDownFixture() throws Exception {
		reposProcessRemote.kill(1000);
	}
}
