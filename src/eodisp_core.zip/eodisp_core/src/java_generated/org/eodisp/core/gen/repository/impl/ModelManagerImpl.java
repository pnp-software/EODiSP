/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.core.gen.repository.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

import org.eodisp.core.gen.repository.AppOwner;
import org.eodisp.core.gen.repository.ModelManager;
import org.eodisp.core.gen.repository.RemoteLocation;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Model Manager</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eodisp.core.gen.repository.impl.ModelManagerImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.impl.ModelManagerImpl#getId <em>Id</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.impl.ModelManagerImpl#getDescription <em>Description</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.impl.ModelManagerImpl#getAppOwner <em>App Owner</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.impl.ModelManagerImpl#getRemoteLocation <em>Remote Location</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ModelManagerImpl extends EDataObjectImpl implements ModelManager {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getId() <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId()
	 * @generated
	 * @ordered
	 */
	protected static final String ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getId() <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId()
	 * @generated
	 * @ordered
	 */
	protected String id = ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getDescription() <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDescription()
	 * @generated
	 * @ordered
	 */
	protected static final String DESCRIPTION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDescription() <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDescription()
	 * @generated
	 * @ordered
	 */
	protected String description = DESCRIPTION_EDEFAULT;

	/**
	 * The cached value of the '{@link #getAppOwner() <em>App Owner</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAppOwner()
	 * @generated
	 * @ordered
	 */
	protected AppOwner appOwner = null;

	/**
	 * The cached value of the '{@link #getRemoteLocation() <em>Remote Location</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRemoteLocation()
	 * @generated
	 * @ordered
	 */
	protected RemoteLocation remoteLocation = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ModelManagerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return RepositoryPackageImpl.Literals.MODEL_MANAGER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RepositoryPackageImpl.MODEL_MANAGER__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getId() {
		return id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setId(String newId) {
		String oldId = id;
		id = newId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RepositoryPackageImpl.MODEL_MANAGER__ID, oldId, id));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDescription(String newDescription) {
		String oldDescription = description;
		description = newDescription;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RepositoryPackageImpl.MODEL_MANAGER__DESCRIPTION, oldDescription, description));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AppOwner getAppOwner() {
		return appOwner;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetAppOwner(AppOwner newAppOwner, NotificationChain msgs) {
		AppOwner oldAppOwner = appOwner;
		appOwner = newAppOwner;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, RepositoryPackageImpl.MODEL_MANAGER__APP_OWNER, oldAppOwner, newAppOwner);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAppOwner(AppOwner newAppOwner) {
		if (newAppOwner != appOwner) {
			NotificationChain msgs = null;
			if (appOwner != null)
				msgs = ((InternalEObject)appOwner).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - RepositoryPackageImpl.MODEL_MANAGER__APP_OWNER, null, msgs);
			if (newAppOwner != null)
				msgs = ((InternalEObject)newAppOwner).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - RepositoryPackageImpl.MODEL_MANAGER__APP_OWNER, null, msgs);
			msgs = basicSetAppOwner(newAppOwner, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RepositoryPackageImpl.MODEL_MANAGER__APP_OWNER, newAppOwner, newAppOwner));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RemoteLocation getRemoteLocation() {
		return remoteLocation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetRemoteLocation(RemoteLocation newRemoteLocation, NotificationChain msgs) {
		RemoteLocation oldRemoteLocation = remoteLocation;
		remoteLocation = newRemoteLocation;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, RepositoryPackageImpl.MODEL_MANAGER__REMOTE_LOCATION, oldRemoteLocation, newRemoteLocation);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRemoteLocation(RemoteLocation newRemoteLocation) {
		if (newRemoteLocation != remoteLocation) {
			NotificationChain msgs = null;
			if (remoteLocation != null)
				msgs = ((InternalEObject)remoteLocation).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - RepositoryPackageImpl.MODEL_MANAGER__REMOTE_LOCATION, null, msgs);
			if (newRemoteLocation != null)
				msgs = ((InternalEObject)newRemoteLocation).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - RepositoryPackageImpl.MODEL_MANAGER__REMOTE_LOCATION, null, msgs);
			msgs = basicSetRemoteLocation(newRemoteLocation, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RepositoryPackageImpl.MODEL_MANAGER__REMOTE_LOCATION, newRemoteLocation, newRemoteLocation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case RepositoryPackageImpl.MODEL_MANAGER__APP_OWNER:
				return basicSetAppOwner(null, msgs);
			case RepositoryPackageImpl.MODEL_MANAGER__REMOTE_LOCATION:
				return basicSetRemoteLocation(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case RepositoryPackageImpl.MODEL_MANAGER__NAME:
				return getName();
			case RepositoryPackageImpl.MODEL_MANAGER__ID:
				return getId();
			case RepositoryPackageImpl.MODEL_MANAGER__DESCRIPTION:
				return getDescription();
			case RepositoryPackageImpl.MODEL_MANAGER__APP_OWNER:
				return getAppOwner();
			case RepositoryPackageImpl.MODEL_MANAGER__REMOTE_LOCATION:
				return getRemoteLocation();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case RepositoryPackageImpl.MODEL_MANAGER__NAME:
				setName((String)newValue);
				return;
			case RepositoryPackageImpl.MODEL_MANAGER__ID:
				setId((String)newValue);
				return;
			case RepositoryPackageImpl.MODEL_MANAGER__DESCRIPTION:
				setDescription((String)newValue);
				return;
			case RepositoryPackageImpl.MODEL_MANAGER__APP_OWNER:
				setAppOwner((AppOwner)newValue);
				return;
			case RepositoryPackageImpl.MODEL_MANAGER__REMOTE_LOCATION:
				setRemoteLocation((RemoteLocation)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case RepositoryPackageImpl.MODEL_MANAGER__NAME:
				setName(NAME_EDEFAULT);
				return;
			case RepositoryPackageImpl.MODEL_MANAGER__ID:
				setId(ID_EDEFAULT);
				return;
			case RepositoryPackageImpl.MODEL_MANAGER__DESCRIPTION:
				setDescription(DESCRIPTION_EDEFAULT);
				return;
			case RepositoryPackageImpl.MODEL_MANAGER__APP_OWNER:
				setAppOwner((AppOwner)null);
				return;
			case RepositoryPackageImpl.MODEL_MANAGER__REMOTE_LOCATION:
				setRemoteLocation((RemoteLocation)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case RepositoryPackageImpl.MODEL_MANAGER__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case RepositoryPackageImpl.MODEL_MANAGER__ID:
				return ID_EDEFAULT == null ? id != null : !ID_EDEFAULT.equals(id);
			case RepositoryPackageImpl.MODEL_MANAGER__DESCRIPTION:
				return DESCRIPTION_EDEFAULT == null ? description != null : !DESCRIPTION_EDEFAULT.equals(description);
			case RepositoryPackageImpl.MODEL_MANAGER__APP_OWNER:
				return appOwner != null;
			case RepositoryPackageImpl.MODEL_MANAGER__REMOTE_LOCATION:
				return remoteLocation != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", id: ");
		result.append(id);
		result.append(", description: ");
		result.append(description);
		result.append(')');
		return result.toString();
	}

} //ModelManagerImpl