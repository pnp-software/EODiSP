/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.core.gen.smproject.impl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EFactory;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.eclipse.emf.ecore.xml.type.XMLTypePackage;

import org.eodisp.core.gen.smproject.DocumentRoot;
import org.eodisp.core.gen.smproject.Experiment;
import org.eodisp.core.gen.smproject.FederateExecution;
import org.eodisp.core.gen.smproject.FederationExecution;
import org.eodisp.core.gen.smproject.InitData;
import org.eodisp.core.gen.smproject.SmProject;
import org.eodisp.core.gen.smproject.SmprojectFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see org.eodisp.core.gen.smproject.SmprojectFactory
 * @model kind="package"
 * @generated
 */
public class SmprojectPackageImpl extends EPackageImpl {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String eNAME = "smproject";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String eNS_URI = "http://www.pnp-software.com/eodisp/smproject";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String eNS_PREFIX = "smproject";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final SmprojectPackageImpl eINSTANCE = org.eodisp.core.gen.smproject.impl.SmprojectPackageImpl.init();

	/**
	 * The meta object id for the '{@link org.eodisp.core.gen.smproject.impl.DocumentRootImpl <em>Document Root</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eodisp.core.gen.smproject.impl.DocumentRootImpl
	 * @see org.eodisp.core.gen.smproject.impl.SmprojectPackageImpl#getDocumentRoot()
	 * @generated
	 */
	public static final int DOCUMENT_ROOT = 0;

	/**
	 * The feature id for the '<em><b>Mixed</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int DOCUMENT_ROOT__MIXED = 0;

	/**
	 * The feature id for the '<em><b>XMLNS Prefix Map</b></em>' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int DOCUMENT_ROOT__XMLNS_PREFIX_MAP = 1;

	/**
	 * The feature id for the '<em><b>XSI Schema Location</b></em>' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int DOCUMENT_ROOT__XSI_SCHEMA_LOCATION = 2;

	/**
	 * The feature id for the '<em><b>Project</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int DOCUMENT_ROOT__PROJECT = 3;

	/**
	 * The feature id for the '<em><b>Local Path</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int DOCUMENT_ROOT__LOCAL_PATH = 4;

	/**
	 * The number of structural features of the '<em>Document Root</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int DOCUMENT_ROOT_FEATURE_COUNT = 5;

	/**
	 * The meta object id for the '{@link org.eodisp.core.gen.smproject.impl.ExperimentImpl <em>Experiment</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eodisp.core.gen.smproject.impl.ExperimentImpl
	 * @see org.eodisp.core.gen.smproject.impl.SmprojectPackageImpl#getExperiment()
	 * @generated
	 */
	public static final int EXPERIMENT = 2;

	/**
	 * The meta object id for the '{@link org.eodisp.core.gen.smproject.impl.FederationExecutionImpl <em>Federation Execution</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eodisp.core.gen.smproject.impl.FederationExecutionImpl
	 * @see org.eodisp.core.gen.smproject.impl.SmprojectPackageImpl#getFederationExecution()
	 * @generated
	 */
	public static final int FEDERATION_EXECUTION = 3;

	/**
	 * The meta object id for the '{@link org.eodisp.core.gen.smproject.impl.InitDataImpl <em>Init Data</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eodisp.core.gen.smproject.impl.InitDataImpl
	 * @see org.eodisp.core.gen.smproject.impl.SmprojectPackageImpl#getInitData()
	 * @generated
	 */
	public static final int INIT_DATA = 5;

	/**
	 * The meta object id for the '{@link org.eodisp.core.gen.smproject.impl.FederateExecutionImpl <em>Federate Execution</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eodisp.core.gen.smproject.impl.FederateExecutionImpl
	 * @see org.eodisp.core.gen.smproject.impl.SmprojectPackageImpl#getFederateExecution()
	 * @generated
	 */
	public static final int FEDERATE_EXECUTION = 4;

	/**
	 * The meta object id for the '{@link org.eodisp.core.gen.smproject.impl.SmProjectImpl <em>Sm Project</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eodisp.core.gen.smproject.impl.SmProjectImpl
	 * @see org.eodisp.core.gen.smproject.impl.SmprojectPackageImpl#getSmProject()
	 * @generated
	 */
	public static final int SM_PROJECT = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int SM_PROJECT__NAME = 0;

	/**
	 * The feature id for the '<em><b>Federate Executions</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int SM_PROJECT__FEDERATE_EXECUTIONS = 1;

	/**
	 * The feature id for the '<em><b>Experiments</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int SM_PROJECT__EXPERIMENTS = 2;

	/**
	 * The feature id for the '<em><b>Init Data</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int SM_PROJECT__INIT_DATA = 3;

	/**
	 * The number of structural features of the '<em>Sm Project</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int SM_PROJECT_FEATURE_COUNT = 4;

	/**
	 * The feature id for the '<em><b>Federation Execution</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int EXPERIMENT__FEDERATION_EXECUTION = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int EXPERIMENT__NAME = 1;

	/**
	 * The number of structural features of the '<em>Experiment</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int EXPERIMENT_FEATURE_COUNT = 2;

	/**
	 * The feature id for the '<em><b>Federate Executions</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int FEDERATION_EXECUTION__FEDERATE_EXECUTIONS = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int FEDERATION_EXECUTION__NAME = 1;

	/**
	 * The number of structural features of the '<em>Federation Execution</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int FEDERATION_EXECUTION_FEATURE_COUNT = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int FEDERATE_EXECUTION__NAME = 0;

	/**
	 * The feature id for the '<em><b>Remote Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int FEDERATE_EXECUTION__REMOTE_ID = 1;

	/**
	 * The feature id for the '<em><b>Init Data</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int FEDERATE_EXECUTION__INIT_DATA = 2;

	/**
	 * The number of structural features of the '<em>Federate Execution</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int FEDERATE_EXECUTION_FEATURE_COUNT = 3;

	/**
	 * The feature id for the '<em><b>Local Path</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int INIT_DATA__LOCAL_PATH = 0;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int INIT_DATA__DESCRIPTION = 1;

	/**
	 * The number of structural features of the '<em>Init Data</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int INIT_DATA_FEATURE_COUNT = 2;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass documentRootEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass experimentEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass federationExecutionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass initDataEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass federateExecutionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass smProjectEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see org.eodisp.core.gen.smproject.impl.SmprojectPackageImpl#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private SmprojectPackageImpl() {
		super(eNS_URI, ((EFactory)SmprojectFactory.INSTANCE));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this
	 * model, and for any others upon which it depends.  Simple
	 * dependencies are satisfied by calling this method on all
	 * dependent packages before doing anything else.  This method drives
	 * initialization for interdependent packages directly, in parallel
	 * with this package, itself.
	 * <p>Of this package and its interdependencies, all packages which
	 * have not yet been registered by their URI values are first created
	 * and registered.  The packages are then initialized in two steps:
	 * meta-model objects for all of the packages are created before any
	 * are initialized, since one package's meta-model objects may refer to
	 * those of another.
	 * <p>Invocation of this method will not affect any packages that have
	 * already been initialized.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static SmprojectPackageImpl init() {
		if (isInited) return (SmprojectPackageImpl)EPackage.Registry.INSTANCE.getEPackage(SmprojectPackageImpl.eNS_URI);

		// Obtain or create and register package
		SmprojectPackageImpl theSmprojectPackageImpl = (SmprojectPackageImpl)(EPackage.Registry.INSTANCE.getEPackage(eNS_URI) instanceof SmprojectPackageImpl ? EPackage.Registry.INSTANCE.getEPackage(eNS_URI) : new SmprojectPackageImpl());

		isInited = true;

		// Initialize simple dependencies
		XMLTypePackage.eINSTANCE.eClass();

		// Create package meta-data objects
		theSmprojectPackageImpl.createPackageContents();

		// Initialize created meta-data
		theSmprojectPackageImpl.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theSmprojectPackageImpl.freeze();

		return theSmprojectPackageImpl;
	}


	/**
	 * Returns the meta object for class '{@link org.eodisp.core.gen.smproject.DocumentRoot <em>Document Root</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Document Root</em>'.
	 * @see org.eodisp.core.gen.smproject.DocumentRoot
	 * @generated
	 */
	public EClass getDocumentRoot() {
		return documentRootEClass;
	}

	/**
	 * Returns the meta object for the attribute list '{@link org.eodisp.core.gen.smproject.DocumentRoot#getMixed <em>Mixed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Mixed</em>'.
	 * @see org.eodisp.core.gen.smproject.DocumentRoot#getMixed()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	public EAttribute getDocumentRoot_Mixed() {
		return (EAttribute)documentRootEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * Returns the meta object for the map '{@link org.eodisp.core.gen.smproject.DocumentRoot#getXMLNSPrefixMap <em>XMLNS Prefix Map</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the map '<em>XMLNS Prefix Map</em>'.
	 * @see org.eodisp.core.gen.smproject.DocumentRoot#getXMLNSPrefixMap()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	public EReference getDocumentRoot_XMLNSPrefixMap() {
		return (EReference)documentRootEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * Returns the meta object for the map '{@link org.eodisp.core.gen.smproject.DocumentRoot#getXSISchemaLocation <em>XSI Schema Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the map '<em>XSI Schema Location</em>'.
	 * @see org.eodisp.core.gen.smproject.DocumentRoot#getXSISchemaLocation()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	public EReference getDocumentRoot_XSISchemaLocation() {
		return (EReference)documentRootEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.core.gen.smproject.DocumentRoot#getProject <em>Project</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Project</em>'.
	 * @see org.eodisp.core.gen.smproject.DocumentRoot#getProject()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	public EReference getDocumentRoot_Project() {
		return (EReference)documentRootEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.smproject.DocumentRoot#getLocalPath <em>Local Path</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Local Path</em>'.
	 * @see org.eodisp.core.gen.smproject.DocumentRoot#getLocalPath()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	public EAttribute getDocumentRoot_LocalPath() {
		return (EAttribute)documentRootEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * Returns the meta object for class '{@link org.eodisp.core.gen.smproject.Experiment <em>Experiment</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Experiment</em>'.
	 * @see org.eodisp.core.gen.smproject.Experiment
	 * @generated
	 */
	public EClass getExperiment() {
		return experimentEClass;
	}

	/**
	 * Returns the meta object for the containment reference list '{@link org.eodisp.core.gen.smproject.Experiment#getFederationExecution <em>Federation Execution</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Federation Execution</em>'.
	 * @see org.eodisp.core.gen.smproject.Experiment#getFederationExecution()
	 * @see #getExperiment()
	 * @generated
	 */
	public EReference getExperiment_FederationExecution() {
		return (EReference)experimentEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.smproject.Experiment#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eodisp.core.gen.smproject.Experiment#getName()
	 * @see #getExperiment()
	 * @generated
	 */
	public EAttribute getExperiment_Name() {
		return (EAttribute)experimentEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * Returns the meta object for class '{@link org.eodisp.core.gen.smproject.FederationExecution <em>Federation Execution</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Federation Execution</em>'.
	 * @see org.eodisp.core.gen.smproject.FederationExecution
	 * @generated
	 */
	public EClass getFederationExecution() {
		return federationExecutionEClass;
	}

	/**
	 * Returns the meta object for the reference list '{@link org.eodisp.core.gen.smproject.FederationExecution#getFederateExecutions <em>Federate Executions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Federate Executions</em>'.
	 * @see org.eodisp.core.gen.smproject.FederationExecution#getFederateExecutions()
	 * @see #getFederationExecution()
	 * @generated
	 */
	public EReference getFederationExecution_FederateExecutions() {
		return (EReference)federationExecutionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.smproject.FederationExecution#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eodisp.core.gen.smproject.FederationExecution#getName()
	 * @see #getFederationExecution()
	 * @generated
	 */
	public EAttribute getFederationExecution_Name() {
		return (EAttribute)federationExecutionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * Returns the meta object for class '{@link org.eodisp.core.gen.smproject.InitData <em>Init Data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Init Data</em>'.
	 * @see org.eodisp.core.gen.smproject.InitData
	 * @generated
	 */
	public EClass getInitData() {
		return initDataEClass;
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.smproject.InitData#getDescription <em>Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description</em>'.
	 * @see org.eodisp.core.gen.smproject.InitData#getDescription()
	 * @see #getInitData()
	 * @generated
	 */
	public EAttribute getInitData_Description() {
		return (EAttribute)initDataEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.smproject.InitData#getLocalPath <em>Local Path</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Local Path</em>'.
	 * @see org.eodisp.core.gen.smproject.InitData#getLocalPath()
	 * @see #getInitData()
	 * @generated
	 */
	public EAttribute getInitData_LocalPath() {
		return (EAttribute)initDataEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * Returns the meta object for class '{@link org.eodisp.core.gen.smproject.FederateExecution <em>Federate Execution</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Federate Execution</em>'.
	 * @see org.eodisp.core.gen.smproject.FederateExecution
	 * @generated
	 */
	public EClass getFederateExecution() {
		return federateExecutionEClass;
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.smproject.FederateExecution#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eodisp.core.gen.smproject.FederateExecution#getName()
	 * @see #getFederateExecution()
	 * @generated
	 */
	public EAttribute getFederateExecution_Name() {
		return (EAttribute)federateExecutionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.smproject.FederateExecution#getRemoteId <em>Remote Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Remote Id</em>'.
	 * @see org.eodisp.core.gen.smproject.FederateExecution#getRemoteId()
	 * @see #getFederateExecution()
	 * @generated
	 */
	public EAttribute getFederateExecution_RemoteId() {
		return (EAttribute)federateExecutionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * Returns the meta object for the reference list '{@link org.eodisp.core.gen.smproject.FederateExecution#getInitData <em>Init Data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Init Data</em>'.
	 * @see org.eodisp.core.gen.smproject.FederateExecution#getInitData()
	 * @see #getFederateExecution()
	 * @generated
	 */
	public EReference getFederateExecution_InitData() {
		return (EReference)federateExecutionEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * Returns the meta object for class '{@link org.eodisp.core.gen.smproject.SmProject <em>Sm Project</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Sm Project</em>'.
	 * @see org.eodisp.core.gen.smproject.SmProject
	 * @generated
	 */
	public EClass getSmProject() {
		return smProjectEClass;
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.smproject.SmProject#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eodisp.core.gen.smproject.SmProject#getName()
	 * @see #getSmProject()
	 * @generated
	 */
	public EAttribute getSmProject_Name() {
		return (EAttribute)smProjectEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * Returns the meta object for the containment reference list '{@link org.eodisp.core.gen.smproject.SmProject#getFederateExecutions <em>Federate Executions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Federate Executions</em>'.
	 * @see org.eodisp.core.gen.smproject.SmProject#getFederateExecutions()
	 * @see #getSmProject()
	 * @generated
	 */
	public EReference getSmProject_FederateExecutions() {
		return (EReference)smProjectEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * Returns the meta object for the containment reference list '{@link org.eodisp.core.gen.smproject.SmProject#getExperiments <em>Experiments</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Experiments</em>'.
	 * @see org.eodisp.core.gen.smproject.SmProject#getExperiments()
	 * @see #getSmProject()
	 * @generated
	 */
	public EReference getSmProject_Experiments() {
		return (EReference)smProjectEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * Returns the meta object for the containment reference list '{@link org.eodisp.core.gen.smproject.SmProject#getInitData <em>Init Data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Init Data</em>'.
	 * @see org.eodisp.core.gen.smproject.SmProject#getInitData()
	 * @see #getSmProject()
	 * @generated
	 */
	public EReference getSmProject_InitData() {
		return (EReference)smProjectEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	public SmprojectFactory getSmprojectFactory() {
		return (SmprojectFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		documentRootEClass = createEClass(DOCUMENT_ROOT);
		createEAttribute(documentRootEClass, DOCUMENT_ROOT__MIXED);
		createEReference(documentRootEClass, DOCUMENT_ROOT__XMLNS_PREFIX_MAP);
		createEReference(documentRootEClass, DOCUMENT_ROOT__XSI_SCHEMA_LOCATION);
		createEReference(documentRootEClass, DOCUMENT_ROOT__PROJECT);
		createEAttribute(documentRootEClass, DOCUMENT_ROOT__LOCAL_PATH);

		smProjectEClass = createEClass(SM_PROJECT);
		createEAttribute(smProjectEClass, SM_PROJECT__NAME);
		createEReference(smProjectEClass, SM_PROJECT__FEDERATE_EXECUTIONS);
		createEReference(smProjectEClass, SM_PROJECT__EXPERIMENTS);
		createEReference(smProjectEClass, SM_PROJECT__INIT_DATA);

		experimentEClass = createEClass(EXPERIMENT);
		createEReference(experimentEClass, EXPERIMENT__FEDERATION_EXECUTION);
		createEAttribute(experimentEClass, EXPERIMENT__NAME);

		federationExecutionEClass = createEClass(FEDERATION_EXECUTION);
		createEReference(federationExecutionEClass, FEDERATION_EXECUTION__FEDERATE_EXECUTIONS);
		createEAttribute(federationExecutionEClass, FEDERATION_EXECUTION__NAME);

		federateExecutionEClass = createEClass(FEDERATE_EXECUTION);
		createEAttribute(federateExecutionEClass, FEDERATE_EXECUTION__NAME);
		createEAttribute(federateExecutionEClass, FEDERATE_EXECUTION__REMOTE_ID);
		createEReference(federateExecutionEClass, FEDERATE_EXECUTION__INIT_DATA);

		initDataEClass = createEClass(INIT_DATA);
		createEAttribute(initDataEClass, INIT_DATA__LOCAL_PATH);
		createEAttribute(initDataEClass, INIT_DATA__DESCRIPTION);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		XMLTypePackage theXMLTypePackage = (XMLTypePackage)EPackage.Registry.INSTANCE.getEPackage(XMLTypePackage.eNS_URI);

		// Add supertypes to classes

		// Initialize classes and features; add operations and parameters
		initEClass(documentRootEClass, DocumentRoot.class, "DocumentRoot", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDocumentRoot_Mixed(), ecorePackage.getEFeatureMapEntry(), "mixed", null, 0, -1, null, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_XMLNSPrefixMap(), ecorePackage.getEStringToStringMapEntry(), null, "xMLNSPrefixMap", null, 0, -1, null, IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_XSISchemaLocation(), ecorePackage.getEStringToStringMapEntry(), null, "xSISchemaLocation", null, 0, -1, null, IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_Project(), this.getSmProject(), null, "project", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
		initEAttribute(getDocumentRoot_LocalPath(), theXMLTypePackage.getAnyURI(), "localPath", null, 0, 1, null, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(smProjectEClass, SmProject.class, "SmProject", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSmProject_Name(), theXMLTypePackage.getString(), "name", null, 1, 1, SmProject.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSmProject_FederateExecutions(), this.getFederateExecution(), null, "federateExecutions", null, 0, -1, SmProject.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSmProject_Experiments(), this.getExperiment(), null, "experiments", null, 0, -1, SmProject.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSmProject_InitData(), this.getInitData(), null, "initData", null, 0, -1, SmProject.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(experimentEClass, Experiment.class, "Experiment", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getExperiment_FederationExecution(), this.getFederationExecution(), null, "federationExecution", null, 0, -1, Experiment.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getExperiment_Name(), theXMLTypePackage.getString(), "name", null, 1, 1, Experiment.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(federationExecutionEClass, FederationExecution.class, "FederationExecution", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getFederationExecution_FederateExecutions(), this.getFederateExecution(), null, "federateExecutions", null, 1, -1, FederationExecution.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFederationExecution_Name(), theXMLTypePackage.getString(), "name", null, 1, 1, FederationExecution.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(federateExecutionEClass, FederateExecution.class, "FederateExecution", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getFederateExecution_Name(), theXMLTypePackage.getString(), "name", null, 1, 1, FederateExecution.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFederateExecution_RemoteId(), theXMLTypePackage.getID(), "remoteId", null, 1, 1, FederateExecution.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFederateExecution_InitData(), this.getInitData(), null, "initData", null, 0, -1, FederateExecution.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(initDataEClass, InitData.class, "InitData", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getInitData_LocalPath(), theXMLTypePackage.getAnyURI(), "localPath", null, 0, 1, InitData.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getInitData_Description(), theXMLTypePackage.getString(), "description", null, 0, 1, InitData.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http:///org/eclipse/emf/ecore/util/ExtendedMetaData
		createExtendedMetaDataAnnotations();
	}

	/**
	 * Initializes the annotations for <b>http:///org/eclipse/emf/ecore/util/ExtendedMetaData</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createExtendedMetaDataAnnotations() {
		String source = "http:///org/eclipse/emf/ecore/util/ExtendedMetaData";		
		addAnnotation
		  (documentRootEClass, 
		   source, 
		   new String[] {
			 "name", "",
			 "kind", "mixed"
		   });		
		addAnnotation
		  (getDocumentRoot_Mixed(), 
		   source, 
		   new String[] {
			 "kind", "elementWildcard",
			 "name", ":mixed"
		   });		
		addAnnotation
		  (getDocumentRoot_XMLNSPrefixMap(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "xmlns:prefix"
		   });		
		addAnnotation
		  (getDocumentRoot_XSISchemaLocation(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "xsi:schemaLocation"
		   });		
		addAnnotation
		  (getDocumentRoot_Project(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "project",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getDocumentRoot_LocalPath(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "localPath",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (smProjectEClass, 
		   source, 
		   new String[] {
			 "name", "SmProject",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getSmProject_Name(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "name"
		   });		
		addAnnotation
		  (getSmProject_FederateExecutions(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "federateExecutions",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getSmProject_Experiments(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "experiments",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getSmProject_InitData(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "initData",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (experimentEClass, 
		   source, 
		   new String[] {
			 "name", "Experiment",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getExperiment_FederationExecution(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "federationExecution",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getExperiment_Name(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "name"
		   });		
		addAnnotation
		  (federationExecutionEClass, 
		   source, 
		   new String[] {
			 "name", "FederationExecution",
			 "kind", "empty"
		   });		
		addAnnotation
		  (getFederationExecution_FederateExecutions(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "federateExecutions"
		   });		
		addAnnotation
		  (getFederationExecution_Name(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "name"
		   });		
		addAnnotation
		  (federateExecutionEClass, 
		   source, 
		   new String[] {
			 "name", "FederateExecution",
			 "kind", "empty"
		   });		
		addAnnotation
		  (getFederateExecution_Name(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "name"
		   });		
		addAnnotation
		  (getFederateExecution_RemoteId(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "remoteId"
		   });		
		addAnnotation
		  (getFederateExecution_InitData(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "initData"
		   });		
		addAnnotation
		  (initDataEClass, 
		   source, 
		   new String[] {
			 "name", "InitData",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getInitData_LocalPath(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "localPath"
		   });		
		addAnnotation
		  (getInitData_Description(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "description",
			 "namespace", "##targetNamespace"
		   });
	}

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public interface Literals {
		/**
		 * The meta object literal for the '{@link org.eodisp.core.gen.smproject.impl.DocumentRootImpl <em>Document Root</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.core.gen.smproject.impl.DocumentRootImpl
		 * @see org.eodisp.core.gen.smproject.impl.SmprojectPackageImpl#getDocumentRoot()
		 * @generated
		 */
		public static final EClass DOCUMENT_ROOT = eINSTANCE.getDocumentRoot();

		/**
		 * The meta object literal for the '<em><b>Mixed</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute DOCUMENT_ROOT__MIXED = eINSTANCE.getDocumentRoot_Mixed();

		/**
		 * The meta object literal for the '<em><b>XMLNS Prefix Map</b></em>' map feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EReference DOCUMENT_ROOT__XMLNS_PREFIX_MAP = eINSTANCE.getDocumentRoot_XMLNSPrefixMap();

		/**
		 * The meta object literal for the '<em><b>XSI Schema Location</b></em>' map feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EReference DOCUMENT_ROOT__XSI_SCHEMA_LOCATION = eINSTANCE.getDocumentRoot_XSISchemaLocation();

		/**
		 * The meta object literal for the '<em><b>Project</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EReference DOCUMENT_ROOT__PROJECT = eINSTANCE.getDocumentRoot_Project();

		/**
		 * The meta object literal for the '<em><b>Local Path</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute DOCUMENT_ROOT__LOCAL_PATH = eINSTANCE.getDocumentRoot_LocalPath();

		/**
		 * The meta object literal for the '{@link org.eodisp.core.gen.smproject.impl.ExperimentImpl <em>Experiment</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.core.gen.smproject.impl.ExperimentImpl
		 * @see org.eodisp.core.gen.smproject.impl.SmprojectPackageImpl#getExperiment()
		 * @generated
		 */
		public static final EClass EXPERIMENT = eINSTANCE.getExperiment();

		/**
		 * The meta object literal for the '<em><b>Federation Execution</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EReference EXPERIMENT__FEDERATION_EXECUTION = eINSTANCE.getExperiment_FederationExecution();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute EXPERIMENT__NAME = eINSTANCE.getExperiment_Name();

		/**
		 * The meta object literal for the '{@link org.eodisp.core.gen.smproject.impl.FederationExecutionImpl <em>Federation Execution</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.core.gen.smproject.impl.FederationExecutionImpl
		 * @see org.eodisp.core.gen.smproject.impl.SmprojectPackageImpl#getFederationExecution()
		 * @generated
		 */
		public static final EClass FEDERATION_EXECUTION = eINSTANCE.getFederationExecution();

		/**
		 * The meta object literal for the '<em><b>Federate Executions</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EReference FEDERATION_EXECUTION__FEDERATE_EXECUTIONS = eINSTANCE.getFederationExecution_FederateExecutions();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute FEDERATION_EXECUTION__NAME = eINSTANCE.getFederationExecution_Name();

		/**
		 * The meta object literal for the '{@link org.eodisp.core.gen.smproject.impl.InitDataImpl <em>Init Data</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.core.gen.smproject.impl.InitDataImpl
		 * @see org.eodisp.core.gen.smproject.impl.SmprojectPackageImpl#getInitData()
		 * @generated
		 */
		public static final EClass INIT_DATA = eINSTANCE.getInitData();

		/**
		 * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute INIT_DATA__DESCRIPTION = eINSTANCE.getInitData_Description();

		/**
		 * The meta object literal for the '<em><b>Local Path</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute INIT_DATA__LOCAL_PATH = eINSTANCE.getInitData_LocalPath();

		/**
		 * The meta object literal for the '{@link org.eodisp.core.gen.smproject.impl.FederateExecutionImpl <em>Federate Execution</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.core.gen.smproject.impl.FederateExecutionImpl
		 * @see org.eodisp.core.gen.smproject.impl.SmprojectPackageImpl#getFederateExecution()
		 * @generated
		 */
		public static final EClass FEDERATE_EXECUTION = eINSTANCE.getFederateExecution();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute FEDERATE_EXECUTION__NAME = eINSTANCE.getFederateExecution_Name();

		/**
		 * The meta object literal for the '<em><b>Remote Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute FEDERATE_EXECUTION__REMOTE_ID = eINSTANCE.getFederateExecution_RemoteId();

		/**
		 * The meta object literal for the '<em><b>Init Data</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EReference FEDERATE_EXECUTION__INIT_DATA = eINSTANCE.getFederateExecution_InitData();

		/**
		 * The meta object literal for the '{@link org.eodisp.core.gen.smproject.impl.SmProjectImpl <em>Sm Project</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.core.gen.smproject.impl.SmProjectImpl
		 * @see org.eodisp.core.gen.smproject.impl.SmprojectPackageImpl#getSmProject()
		 * @generated
		 */
		public static final EClass SM_PROJECT = eINSTANCE.getSmProject();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute SM_PROJECT__NAME = eINSTANCE.getSmProject_Name();

		/**
		 * The meta object literal for the '<em><b>Federate Executions</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EReference SM_PROJECT__FEDERATE_EXECUTIONS = eINSTANCE.getSmProject_FederateExecutions();

		/**
		 * The meta object literal for the '<em><b>Experiments</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EReference SM_PROJECT__EXPERIMENTS = eINSTANCE.getSmProject_Experiments();

		/**
		 * The meta object literal for the '<em><b>Init Data</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EReference SM_PROJECT__INIT_DATA = eINSTANCE.getSmProject_InitData();

	}

} //SmprojectPackageImpl
