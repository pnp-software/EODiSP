/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.core.gen.smproject.impl;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.eodisp.core.gen.smproject.Experiment;
import org.eodisp.core.gen.smproject.FederateExecution;
import org.eodisp.core.gen.smproject.InitData;
import org.eodisp.core.gen.smproject.SmProject;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Sm Project</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eodisp.core.gen.smproject.impl.SmProjectImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.core.gen.smproject.impl.SmProjectImpl#getFederateExecutions <em>Federate Executions</em>}</li>
 *   <li>{@link org.eodisp.core.gen.smproject.impl.SmProjectImpl#getExperiments <em>Experiments</em>}</li>
 *   <li>{@link org.eodisp.core.gen.smproject.impl.SmProjectImpl#getInitData <em>Init Data</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class SmProjectImpl extends EDataObjectImpl implements SmProject {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getFederateExecutions() <em>Federate Executions</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFederateExecutions()
	 * @generated
	 * @ordered
	 */
	protected EList federateExecutions = null;

	/**
	 * The cached value of the '{@link #getExperiments() <em>Experiments</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExperiments()
	 * @generated
	 * @ordered
	 */
	protected EList experiments = null;

	/**
	 * The cached value of the '{@link #getInitData() <em>Init Data</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInitData()
	 * @generated
	 * @ordered
	 */
	protected EList initData = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SmProjectImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return SmprojectPackageImpl.Literals.SM_PROJECT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmprojectPackageImpl.SM_PROJECT__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getFederateExecutions() {
		if (federateExecutions == null) {
			federateExecutions = new EObjectContainmentEList(FederateExecution.class, this, SmprojectPackageImpl.SM_PROJECT__FEDERATE_EXECUTIONS);
		}
		return federateExecutions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getExperiments() {
		if (experiments == null) {
			experiments = new EObjectContainmentEList(Experiment.class, this, SmprojectPackageImpl.SM_PROJECT__EXPERIMENTS);
		}
		return experiments;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getInitData() {
		if (initData == null) {
			initData = new EObjectContainmentEList(InitData.class, this, SmprojectPackageImpl.SM_PROJECT__INIT_DATA);
		}
		return initData;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case SmprojectPackageImpl.SM_PROJECT__FEDERATE_EXECUTIONS:
				return ((InternalEList)getFederateExecutions()).basicRemove(otherEnd, msgs);
			case SmprojectPackageImpl.SM_PROJECT__EXPERIMENTS:
				return ((InternalEList)getExperiments()).basicRemove(otherEnd, msgs);
			case SmprojectPackageImpl.SM_PROJECT__INIT_DATA:
				return ((InternalEList)getInitData()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SmprojectPackageImpl.SM_PROJECT__NAME:
				return getName();
			case SmprojectPackageImpl.SM_PROJECT__FEDERATE_EXECUTIONS:
				return getFederateExecutions();
			case SmprojectPackageImpl.SM_PROJECT__EXPERIMENTS:
				return getExperiments();
			case SmprojectPackageImpl.SM_PROJECT__INIT_DATA:
				return getInitData();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SmprojectPackageImpl.SM_PROJECT__NAME:
				setName((String)newValue);
				return;
			case SmprojectPackageImpl.SM_PROJECT__FEDERATE_EXECUTIONS:
				getFederateExecutions().clear();
				getFederateExecutions().addAll((Collection)newValue);
				return;
			case SmprojectPackageImpl.SM_PROJECT__EXPERIMENTS:
				getExperiments().clear();
				getExperiments().addAll((Collection)newValue);
				return;
			case SmprojectPackageImpl.SM_PROJECT__INIT_DATA:
				getInitData().clear();
				getInitData().addAll((Collection)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case SmprojectPackageImpl.SM_PROJECT__NAME:
				setName(NAME_EDEFAULT);
				return;
			case SmprojectPackageImpl.SM_PROJECT__FEDERATE_EXECUTIONS:
				getFederateExecutions().clear();
				return;
			case SmprojectPackageImpl.SM_PROJECT__EXPERIMENTS:
				getExperiments().clear();
				return;
			case SmprojectPackageImpl.SM_PROJECT__INIT_DATA:
				getInitData().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SmprojectPackageImpl.SM_PROJECT__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case SmprojectPackageImpl.SM_PROJECT__FEDERATE_EXECUTIONS:
				return federateExecutions != null && !federateExecutions.isEmpty();
			case SmprojectPackageImpl.SM_PROJECT__EXPERIMENTS:
				return experiments != null && !experiments.isEmpty();
			case SmprojectPackageImpl.SM_PROJECT__INIT_DATA:
				return initData != null && !initData.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //SmProjectImpl