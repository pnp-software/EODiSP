/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.core.gen.repository.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

import org.eodisp.core.gen.repository.AppOwner;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>App Owner</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eodisp.core.gen.repository.impl.AppOwnerImpl#getFirstname <em>Firstname</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.impl.AppOwnerImpl#getSurname <em>Surname</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.impl.AppOwnerImpl#getMail <em>Mail</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.impl.AppOwnerImpl#getTel <em>Tel</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.impl.AppOwnerImpl#getCountry <em>Country</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.impl.AppOwnerImpl#getCustom1 <em>Custom1</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.impl.AppOwnerImpl#getCustom2 <em>Custom2</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.impl.AppOwnerImpl#getCustom3 <em>Custom3</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class AppOwnerImpl extends EDataObjectImpl implements AppOwner {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * The default value of the '{@link #getFirstname() <em>Firstname</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFirstname()
	 * @generated
	 * @ordered
	 */
	protected static final String FIRSTNAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getFirstname() <em>Firstname</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFirstname()
	 * @generated
	 * @ordered
	 */
	protected String firstname = FIRSTNAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getSurname() <em>Surname</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSurname()
	 * @generated
	 * @ordered
	 */
	protected static final String SURNAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSurname() <em>Surname</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSurname()
	 * @generated
	 * @ordered
	 */
	protected String surname = SURNAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getMail() <em>Mail</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMail()
	 * @generated
	 * @ordered
	 */
	protected static final String MAIL_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getMail() <em>Mail</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMail()
	 * @generated
	 * @ordered
	 */
	protected String mail = MAIL_EDEFAULT;

	/**
	 * The default value of the '{@link #getTel() <em>Tel</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTel()
	 * @generated
	 * @ordered
	 */
	protected static final String TEL_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTel() <em>Tel</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTel()
	 * @generated
	 * @ordered
	 */
	protected String tel = TEL_EDEFAULT;

	/**
	 * The default value of the '{@link #getCountry() <em>Country</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCountry()
	 * @generated
	 * @ordered
	 */
	protected static final String COUNTRY_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCountry() <em>Country</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCountry()
	 * @generated
	 * @ordered
	 */
	protected String country = COUNTRY_EDEFAULT;

	/**
	 * The default value of the '{@link #getCustom1() <em>Custom1</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCustom1()
	 * @generated
	 * @ordered
	 */
	protected static final String CUSTOM1_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCustom1() <em>Custom1</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCustom1()
	 * @generated
	 * @ordered
	 */
	protected String custom1 = CUSTOM1_EDEFAULT;

	/**
	 * The default value of the '{@link #getCustom2() <em>Custom2</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCustom2()
	 * @generated
	 * @ordered
	 */
	protected static final String CUSTOM2_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCustom2() <em>Custom2</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCustom2()
	 * @generated
	 * @ordered
	 */
	protected String custom2 = CUSTOM2_EDEFAULT;

	/**
	 * The default value of the '{@link #getCustom3() <em>Custom3</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCustom3()
	 * @generated
	 * @ordered
	 */
	protected static final String CUSTOM3_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCustom3() <em>Custom3</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCustom3()
	 * @generated
	 * @ordered
	 */
	protected String custom3 = CUSTOM3_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AppOwnerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return RepositoryPackageImpl.Literals.APP_OWNER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getFirstname() {
		return firstname;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFirstname(String newFirstname) {
		String oldFirstname = firstname;
		firstname = newFirstname;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RepositoryPackageImpl.APP_OWNER__FIRSTNAME, oldFirstname, firstname));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSurname() {
		return surname;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSurname(String newSurname) {
		String oldSurname = surname;
		surname = newSurname;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RepositoryPackageImpl.APP_OWNER__SURNAME, oldSurname, surname));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getMail() {
		return mail;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMail(String newMail) {
		String oldMail = mail;
		mail = newMail;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RepositoryPackageImpl.APP_OWNER__MAIL, oldMail, mail));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTel() {
		return tel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTel(String newTel) {
		String oldTel = tel;
		tel = newTel;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RepositoryPackageImpl.APP_OWNER__TEL, oldTel, tel));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCountry(String newCountry) {
		String oldCountry = country;
		country = newCountry;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RepositoryPackageImpl.APP_OWNER__COUNTRY, oldCountry, country));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getCustom1() {
		return custom1;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCustom1(String newCustom1) {
		String oldCustom1 = custom1;
		custom1 = newCustom1;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RepositoryPackageImpl.APP_OWNER__CUSTOM1, oldCustom1, custom1));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getCustom2() {
		return custom2;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCustom2(String newCustom2) {
		String oldCustom2 = custom2;
		custom2 = newCustom2;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RepositoryPackageImpl.APP_OWNER__CUSTOM2, oldCustom2, custom2));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getCustom3() {
		return custom3;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCustom3(String newCustom3) {
		String oldCustom3 = custom3;
		custom3 = newCustom3;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RepositoryPackageImpl.APP_OWNER__CUSTOM3, oldCustom3, custom3));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case RepositoryPackageImpl.APP_OWNER__FIRSTNAME:
				return getFirstname();
			case RepositoryPackageImpl.APP_OWNER__SURNAME:
				return getSurname();
			case RepositoryPackageImpl.APP_OWNER__MAIL:
				return getMail();
			case RepositoryPackageImpl.APP_OWNER__TEL:
				return getTel();
			case RepositoryPackageImpl.APP_OWNER__COUNTRY:
				return getCountry();
			case RepositoryPackageImpl.APP_OWNER__CUSTOM1:
				return getCustom1();
			case RepositoryPackageImpl.APP_OWNER__CUSTOM2:
				return getCustom2();
			case RepositoryPackageImpl.APP_OWNER__CUSTOM3:
				return getCustom3();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case RepositoryPackageImpl.APP_OWNER__FIRSTNAME:
				setFirstname((String)newValue);
				return;
			case RepositoryPackageImpl.APP_OWNER__SURNAME:
				setSurname((String)newValue);
				return;
			case RepositoryPackageImpl.APP_OWNER__MAIL:
				setMail((String)newValue);
				return;
			case RepositoryPackageImpl.APP_OWNER__TEL:
				setTel((String)newValue);
				return;
			case RepositoryPackageImpl.APP_OWNER__COUNTRY:
				setCountry((String)newValue);
				return;
			case RepositoryPackageImpl.APP_OWNER__CUSTOM1:
				setCustom1((String)newValue);
				return;
			case RepositoryPackageImpl.APP_OWNER__CUSTOM2:
				setCustom2((String)newValue);
				return;
			case RepositoryPackageImpl.APP_OWNER__CUSTOM3:
				setCustom3((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case RepositoryPackageImpl.APP_OWNER__FIRSTNAME:
				setFirstname(FIRSTNAME_EDEFAULT);
				return;
			case RepositoryPackageImpl.APP_OWNER__SURNAME:
				setSurname(SURNAME_EDEFAULT);
				return;
			case RepositoryPackageImpl.APP_OWNER__MAIL:
				setMail(MAIL_EDEFAULT);
				return;
			case RepositoryPackageImpl.APP_OWNER__TEL:
				setTel(TEL_EDEFAULT);
				return;
			case RepositoryPackageImpl.APP_OWNER__COUNTRY:
				setCountry(COUNTRY_EDEFAULT);
				return;
			case RepositoryPackageImpl.APP_OWNER__CUSTOM1:
				setCustom1(CUSTOM1_EDEFAULT);
				return;
			case RepositoryPackageImpl.APP_OWNER__CUSTOM2:
				setCustom2(CUSTOM2_EDEFAULT);
				return;
			case RepositoryPackageImpl.APP_OWNER__CUSTOM3:
				setCustom3(CUSTOM3_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case RepositoryPackageImpl.APP_OWNER__FIRSTNAME:
				return FIRSTNAME_EDEFAULT == null ? firstname != null : !FIRSTNAME_EDEFAULT.equals(firstname);
			case RepositoryPackageImpl.APP_OWNER__SURNAME:
				return SURNAME_EDEFAULT == null ? surname != null : !SURNAME_EDEFAULT.equals(surname);
			case RepositoryPackageImpl.APP_OWNER__MAIL:
				return MAIL_EDEFAULT == null ? mail != null : !MAIL_EDEFAULT.equals(mail);
			case RepositoryPackageImpl.APP_OWNER__TEL:
				return TEL_EDEFAULT == null ? tel != null : !TEL_EDEFAULT.equals(tel);
			case RepositoryPackageImpl.APP_OWNER__COUNTRY:
				return COUNTRY_EDEFAULT == null ? country != null : !COUNTRY_EDEFAULT.equals(country);
			case RepositoryPackageImpl.APP_OWNER__CUSTOM1:
				return CUSTOM1_EDEFAULT == null ? custom1 != null : !CUSTOM1_EDEFAULT.equals(custom1);
			case RepositoryPackageImpl.APP_OWNER__CUSTOM2:
				return CUSTOM2_EDEFAULT == null ? custom2 != null : !CUSTOM2_EDEFAULT.equals(custom2);
			case RepositoryPackageImpl.APP_OWNER__CUSTOM3:
				return CUSTOM3_EDEFAULT == null ? custom3 != null : !CUSTOM3_EDEFAULT.equals(custom3);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (firstname: ");
		result.append(firstname);
		result.append(", surname: ");
		result.append(surname);
		result.append(", mail: ");
		result.append(mail);
		result.append(", tel: ");
		result.append(tel);
		result.append(", country: ");
		result.append(country);
		result.append(", custom1: ");
		result.append(custom1);
		result.append(", custom2: ");
		result.append(custom2);
		result.append(", custom3: ");
		result.append(custom3);
		result.append(')');
		return result.toString();
	}

} //AppOwnerImpl