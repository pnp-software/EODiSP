/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.core.gen.repository.impl;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

import org.eodisp.core.gen.repository.Federate;
import org.eodisp.core.gen.repository.ModelManager;
import org.eodisp.core.gen.repository.SOM;
import org.eodisp.core.gen.repository.SimManager;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Federate</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eodisp.core.gen.repository.impl.FederateImpl#getId <em>Id</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.impl.FederateImpl#getBundleName <em>Bundle Name</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.impl.FederateImpl#getBundleSymbolicName <em>Bundle Symbolic Name</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.impl.FederateImpl#getBundleVersion <em>Bundle Version</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.impl.FederateImpl#getBundleDescription <em>Bundle Description</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.impl.FederateImpl#getDescription <em>Description</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.impl.FederateImpl#getOwningMm <em>Owning Mm</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.impl.FederateImpl#getTrustedSimManagers <em>Trusted Sim Managers</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.impl.FederateImpl#getSom <em>Som</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class FederateImpl extends EDataObjectImpl implements Federate {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * The default value of the '{@link #getId() <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId()
	 * @generated
	 * @ordered
	 */
	protected static final String ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getId() <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId()
	 * @generated
	 * @ordered
	 */
	protected String id = ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getBundleName() <em>Bundle Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBundleName()
	 * @generated
	 * @ordered
	 */
	protected static final String BUNDLE_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getBundleName() <em>Bundle Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBundleName()
	 * @generated
	 * @ordered
	 */
	protected String bundleName = BUNDLE_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getBundleSymbolicName() <em>Bundle Symbolic Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBundleSymbolicName()
	 * @generated
	 * @ordered
	 */
	protected static final String BUNDLE_SYMBOLIC_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getBundleSymbolicName() <em>Bundle Symbolic Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBundleSymbolicName()
	 * @generated
	 * @ordered
	 */
	protected String bundleSymbolicName = BUNDLE_SYMBOLIC_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getBundleVersion() <em>Bundle Version</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBundleVersion()
	 * @generated
	 * @ordered
	 */
	protected static final String BUNDLE_VERSION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getBundleVersion() <em>Bundle Version</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBundleVersion()
	 * @generated
	 * @ordered
	 */
	protected String bundleVersion = BUNDLE_VERSION_EDEFAULT;

	/**
	 * The default value of the '{@link #getBundleDescription() <em>Bundle Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBundleDescription()
	 * @generated
	 * @ordered
	 */
	protected static final String BUNDLE_DESCRIPTION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getBundleDescription() <em>Bundle Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBundleDescription()
	 * @generated
	 * @ordered
	 */
	protected String bundleDescription = BUNDLE_DESCRIPTION_EDEFAULT;

	/**
	 * The default value of the '{@link #getDescription() <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDescription()
	 * @generated
	 * @ordered
	 */
	protected static final String DESCRIPTION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDescription() <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDescription()
	 * @generated
	 * @ordered
	 */
	protected String description = DESCRIPTION_EDEFAULT;

	/**
	 * The cached value of the '{@link #getOwningMm() <em>Owning Mm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOwningMm()
	 * @generated
	 * @ordered
	 */
	protected ModelManager owningMm = null;

	/**
	 * The cached value of the '{@link #getTrustedSimManagers() <em>Trusted Sim Managers</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrustedSimManagers()
	 * @generated
	 * @ordered
	 */
	protected EList trustedSimManagers = null;

	/**
	 * The cached value of the '{@link #getSom() <em>Som</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSom()
	 * @generated
	 * @ordered
	 */
	protected SOM som = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FederateImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return RepositoryPackageImpl.Literals.FEDERATE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getId() {
		return id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setId(String newId) {
		String oldId = id;
		id = newId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RepositoryPackageImpl.FEDERATE__ID, oldId, id));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getBundleName() {
		return bundleName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBundleName(String newBundleName) {
		String oldBundleName = bundleName;
		bundleName = newBundleName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RepositoryPackageImpl.FEDERATE__BUNDLE_NAME, oldBundleName, bundleName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getBundleSymbolicName() {
		return bundleSymbolicName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBundleSymbolicName(String newBundleSymbolicName) {
		String oldBundleSymbolicName = bundleSymbolicName;
		bundleSymbolicName = newBundleSymbolicName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RepositoryPackageImpl.FEDERATE__BUNDLE_SYMBOLIC_NAME, oldBundleSymbolicName, bundleSymbolicName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getBundleVersion() {
		return bundleVersion;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBundleVersion(String newBundleVersion) {
		String oldBundleVersion = bundleVersion;
		bundleVersion = newBundleVersion;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RepositoryPackageImpl.FEDERATE__BUNDLE_VERSION, oldBundleVersion, bundleVersion));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getBundleDescription() {
		return bundleDescription;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBundleDescription(String newBundleDescription) {
		String oldBundleDescription = bundleDescription;
		bundleDescription = newBundleDescription;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RepositoryPackageImpl.FEDERATE__BUNDLE_DESCRIPTION, oldBundleDescription, bundleDescription));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDescription(String newDescription) {
		String oldDescription = description;
		description = newDescription;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RepositoryPackageImpl.FEDERATE__DESCRIPTION, oldDescription, description));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ModelManager getOwningMm() {
		if (owningMm != null && ((EObject)owningMm).eIsProxy()) {
			InternalEObject oldOwningMm = (InternalEObject)owningMm;
			owningMm = (ModelManager)eResolveProxy(oldOwningMm);
			if (owningMm != oldOwningMm) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, RepositoryPackageImpl.FEDERATE__OWNING_MM, oldOwningMm, owningMm));
			}
		}
		return owningMm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ModelManager basicGetOwningMm() {
		return owningMm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOwningMm(ModelManager newOwningMm) {
		ModelManager oldOwningMm = owningMm;
		owningMm = newOwningMm;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RepositoryPackageImpl.FEDERATE__OWNING_MM, oldOwningMm, owningMm));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getTrustedSimManagers() {
		if (trustedSimManagers == null) {
			trustedSimManagers = new EObjectResolvingEList(SimManager.class, this, RepositoryPackageImpl.FEDERATE__TRUSTED_SIM_MANAGERS);
		}
		return trustedSimManagers;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SOM getSom() {
		if (som != null && ((EObject)som).eIsProxy()) {
			InternalEObject oldSom = (InternalEObject)som;
			som = (SOM)eResolveProxy(oldSom);
			if (som != oldSom) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, RepositoryPackageImpl.FEDERATE__SOM, oldSom, som));
			}
		}
		return som;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SOM basicGetSom() {
		return som;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetSom(SOM newSom, NotificationChain msgs) {
		SOM oldSom = som;
		som = newSom;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, RepositoryPackageImpl.FEDERATE__SOM, oldSom, newSom);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSom(SOM newSom) {
		if (newSom != som) {
			NotificationChain msgs = null;
			if (som != null)
				msgs = ((InternalEObject)som).eInverseRemove(this, RepositoryPackageImpl.SOM__FEDERATES, SOM.class, msgs);
			if (newSom != null)
				msgs = ((InternalEObject)newSom).eInverseAdd(this, RepositoryPackageImpl.SOM__FEDERATES, SOM.class, msgs);
			msgs = basicSetSom(newSom, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RepositoryPackageImpl.FEDERATE__SOM, newSom, newSom));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case RepositoryPackageImpl.FEDERATE__SOM:
				if (som != null)
					msgs = ((InternalEObject)som).eInverseRemove(this, RepositoryPackageImpl.SOM__FEDERATES, SOM.class, msgs);
				return basicSetSom((SOM)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case RepositoryPackageImpl.FEDERATE__SOM:
				return basicSetSom(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case RepositoryPackageImpl.FEDERATE__ID:
				return getId();
			case RepositoryPackageImpl.FEDERATE__BUNDLE_NAME:
				return getBundleName();
			case RepositoryPackageImpl.FEDERATE__BUNDLE_SYMBOLIC_NAME:
				return getBundleSymbolicName();
			case RepositoryPackageImpl.FEDERATE__BUNDLE_VERSION:
				return getBundleVersion();
			case RepositoryPackageImpl.FEDERATE__BUNDLE_DESCRIPTION:
				return getBundleDescription();
			case RepositoryPackageImpl.FEDERATE__DESCRIPTION:
				return getDescription();
			case RepositoryPackageImpl.FEDERATE__OWNING_MM:
				if (resolve) return getOwningMm();
				return basicGetOwningMm();
			case RepositoryPackageImpl.FEDERATE__TRUSTED_SIM_MANAGERS:
				return getTrustedSimManagers();
			case RepositoryPackageImpl.FEDERATE__SOM:
				if (resolve) return getSom();
				return basicGetSom();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case RepositoryPackageImpl.FEDERATE__ID:
				setId((String)newValue);
				return;
			case RepositoryPackageImpl.FEDERATE__BUNDLE_NAME:
				setBundleName((String)newValue);
				return;
			case RepositoryPackageImpl.FEDERATE__BUNDLE_SYMBOLIC_NAME:
				setBundleSymbolicName((String)newValue);
				return;
			case RepositoryPackageImpl.FEDERATE__BUNDLE_VERSION:
				setBundleVersion((String)newValue);
				return;
			case RepositoryPackageImpl.FEDERATE__BUNDLE_DESCRIPTION:
				setBundleDescription((String)newValue);
				return;
			case RepositoryPackageImpl.FEDERATE__DESCRIPTION:
				setDescription((String)newValue);
				return;
			case RepositoryPackageImpl.FEDERATE__OWNING_MM:
				setOwningMm((ModelManager)newValue);
				return;
			case RepositoryPackageImpl.FEDERATE__TRUSTED_SIM_MANAGERS:
				getTrustedSimManagers().clear();
				getTrustedSimManagers().addAll((Collection)newValue);
				return;
			case RepositoryPackageImpl.FEDERATE__SOM:
				setSom((SOM)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case RepositoryPackageImpl.FEDERATE__ID:
				setId(ID_EDEFAULT);
				return;
			case RepositoryPackageImpl.FEDERATE__BUNDLE_NAME:
				setBundleName(BUNDLE_NAME_EDEFAULT);
				return;
			case RepositoryPackageImpl.FEDERATE__BUNDLE_SYMBOLIC_NAME:
				setBundleSymbolicName(BUNDLE_SYMBOLIC_NAME_EDEFAULT);
				return;
			case RepositoryPackageImpl.FEDERATE__BUNDLE_VERSION:
				setBundleVersion(BUNDLE_VERSION_EDEFAULT);
				return;
			case RepositoryPackageImpl.FEDERATE__BUNDLE_DESCRIPTION:
				setBundleDescription(BUNDLE_DESCRIPTION_EDEFAULT);
				return;
			case RepositoryPackageImpl.FEDERATE__DESCRIPTION:
				setDescription(DESCRIPTION_EDEFAULT);
				return;
			case RepositoryPackageImpl.FEDERATE__OWNING_MM:
				setOwningMm((ModelManager)null);
				return;
			case RepositoryPackageImpl.FEDERATE__TRUSTED_SIM_MANAGERS:
				getTrustedSimManagers().clear();
				return;
			case RepositoryPackageImpl.FEDERATE__SOM:
				setSom((SOM)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case RepositoryPackageImpl.FEDERATE__ID:
				return ID_EDEFAULT == null ? id != null : !ID_EDEFAULT.equals(id);
			case RepositoryPackageImpl.FEDERATE__BUNDLE_NAME:
				return BUNDLE_NAME_EDEFAULT == null ? bundleName != null : !BUNDLE_NAME_EDEFAULT.equals(bundleName);
			case RepositoryPackageImpl.FEDERATE__BUNDLE_SYMBOLIC_NAME:
				return BUNDLE_SYMBOLIC_NAME_EDEFAULT == null ? bundleSymbolicName != null : !BUNDLE_SYMBOLIC_NAME_EDEFAULT.equals(bundleSymbolicName);
			case RepositoryPackageImpl.FEDERATE__BUNDLE_VERSION:
				return BUNDLE_VERSION_EDEFAULT == null ? bundleVersion != null : !BUNDLE_VERSION_EDEFAULT.equals(bundleVersion);
			case RepositoryPackageImpl.FEDERATE__BUNDLE_DESCRIPTION:
				return BUNDLE_DESCRIPTION_EDEFAULT == null ? bundleDescription != null : !BUNDLE_DESCRIPTION_EDEFAULT.equals(bundleDescription);
			case RepositoryPackageImpl.FEDERATE__DESCRIPTION:
				return DESCRIPTION_EDEFAULT == null ? description != null : !DESCRIPTION_EDEFAULT.equals(description);
			case RepositoryPackageImpl.FEDERATE__OWNING_MM:
				return owningMm != null;
			case RepositoryPackageImpl.FEDERATE__TRUSTED_SIM_MANAGERS:
				return trustedSimManagers != null && !trustedSimManagers.isEmpty();
			case RepositoryPackageImpl.FEDERATE__SOM:
				return som != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (id: ");
		result.append(id);
		result.append(", BundleName: ");
		result.append(bundleName);
		result.append(", BundleSymbolicName: ");
		result.append(bundleSymbolicName);
		result.append(", BundleVersion: ");
		result.append(bundleVersion);
		result.append(", BundleDescription: ");
		result.append(bundleDescription);
		result.append(", description: ");
		result.append(description);
		result.append(')');
		return result.toString();
	}

} //FederateImpl