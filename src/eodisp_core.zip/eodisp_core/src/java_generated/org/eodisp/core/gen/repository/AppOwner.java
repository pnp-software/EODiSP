/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.core.gen.repository;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>App Owner</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.core.gen.repository.AppOwner#getFirstname <em>Firstname</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.AppOwner#getSurname <em>Surname</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.AppOwner#getMail <em>Mail</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.AppOwner#getTel <em>Tel</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.AppOwner#getCountry <em>Country</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.AppOwner#getCustom1 <em>Custom1</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.AppOwner#getCustom2 <em>Custom2</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.AppOwner#getCustom3 <em>Custom3</em>}</li>
 * </ul>
 * </p>
 *
 * @model extendedMetaData="name='AppOwner' kind='empty'"
 * @generated
 */
public interface AppOwner {
	/**
	 * Returns the value of the '<em><b>Firstname</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Firstname</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Firstname</em>' attribute.
	 * @see #setFirstname(String)
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='attribute' name='firstname'"
	 * @generated
	 */
	String getFirstname();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.repository.AppOwner#getFirstname <em>Firstname</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Firstname</em>' attribute.
	 * @see #getFirstname()
	 * @generated
	 */
	void setFirstname(String value);

	/**
	 * Returns the value of the '<em><b>Surname</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Surname</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Surname</em>' attribute.
	 * @see #setSurname(String)
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 *        extendedMetaData="kind='attribute' name='surname'"
	 * @generated
	 */
	String getSurname();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.repository.AppOwner#getSurname <em>Surname</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Surname</em>' attribute.
	 * @see #getSurname()
	 * @generated
	 */
	void setSurname(String value);

	/**
	 * Returns the value of the '<em><b>Mail</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Mail</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mail</em>' attribute.
	 * @see #setMail(String)
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
	 *        extendedMetaData="kind='attribute' name='mail'"
	 * @generated
	 */
	String getMail();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.repository.AppOwner#getMail <em>Mail</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Mail</em>' attribute.
	 * @see #getMail()
	 * @generated
	 */
	void setMail(String value);

	/**
	 * Returns the value of the '<em><b>Tel</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Tel</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Tel</em>' attribute.
	 * @see #setTel(String)
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
	 *        extendedMetaData="kind='attribute' name='tel'"
	 * @generated
	 */
	String getTel();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.repository.AppOwner#getTel <em>Tel</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Tel</em>' attribute.
	 * @see #getTel()
	 * @generated
	 */
	void setTel(String value);

	/**
	 * Returns the value of the '<em><b>Country</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Country</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Country</em>' attribute.
	 * @see #setCountry(String)
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
	 *        extendedMetaData="kind='attribute' name='country'"
	 * @generated
	 */
	String getCountry();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.repository.AppOwner#getCountry <em>Country</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Country</em>' attribute.
	 * @see #getCountry()
	 * @generated
	 */
	void setCountry(String value);

	/**
	 * Returns the value of the '<em><b>Custom1</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Custom1</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Custom1</em>' attribute.
	 * @see #setCustom1(String)
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
	 *        extendedMetaData="kind='attribute' name='custom1'"
	 * @generated
	 */
	String getCustom1();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.repository.AppOwner#getCustom1 <em>Custom1</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Custom1</em>' attribute.
	 * @see #getCustom1()
	 * @generated
	 */
	void setCustom1(String value);

	/**
	 * Returns the value of the '<em><b>Custom2</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Custom2</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Custom2</em>' attribute.
	 * @see #setCustom2(String)
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
	 *        extendedMetaData="kind='attribute' name='custom2'"
	 * @generated
	 */
	String getCustom2();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.repository.AppOwner#getCustom2 <em>Custom2</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Custom2</em>' attribute.
	 * @see #getCustom2()
	 * @generated
	 */
	void setCustom2(String value);

	/**
	 * Returns the value of the '<em><b>Custom3</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Custom3</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Custom3</em>' attribute.
	 * @see #setCustom3(String)
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
	 *        extendedMetaData="kind='attribute' name='custom3'"
	 * @generated
	 */
	String getCustom3();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.repository.AppOwner#getCustom3 <em>Custom3</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Custom3</em>' attribute.
	 * @see #getCustom3()
	 * @generated
	 */
	void setCustom3(String value);

} // AppOwner