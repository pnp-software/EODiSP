/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.core.gen.repository;

import java.util.List;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Federate</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.core.gen.repository.Federate#getId <em>Id</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.Federate#getBundleName <em>Bundle Name</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.Federate#getBundleSymbolicName <em>Bundle Symbolic Name</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.Federate#getBundleVersion <em>Bundle Version</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.Federate#getBundleDescription <em>Bundle Description</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.Federate#getDescription <em>Description</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.Federate#getOwningMm <em>Owning Mm</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.Federate#getTrustedSimManagers <em>Trusted Sim Managers</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.Federate#getSom <em>Som</em>}</li>
 * </ul>
 * </p>
 *
 * @model extendedMetaData="name='Federate' kind='elementOnly'"
 * @generated
 */
public interface Federate {
	/**
	 * Returns the value of the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id</em>' attribute.
	 * @see #setId(String)
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='attribute' name='id'"
	 * @generated
	 */
	String getId();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.repository.Federate#getId <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id</em>' attribute.
	 * @see #getId()
	 * @generated
	 */
	void setId(String value);

	/**
	 * Returns the value of the '<em><b>Bundle Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Bundle Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Bundle Name</em>' attribute.
	 * @see #setBundleName(String)
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='attribute' name='BundleName'"
	 * @generated
	 */
	String getBundleName();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.repository.Federate#getBundleName <em>Bundle Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Bundle Name</em>' attribute.
	 * @see #getBundleName()
	 * @generated
	 */
	void setBundleName(String value);

	/**
	 * Returns the value of the '<em><b>Bundle Symbolic Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Bundle Symbolic Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Bundle Symbolic Name</em>' attribute.
	 * @see #setBundleSymbolicName(String)
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 *        extendedMetaData="kind='attribute' name='BundleSymbolicName'"
	 * @generated
	 */
	String getBundleSymbolicName();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.repository.Federate#getBundleSymbolicName <em>Bundle Symbolic Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Bundle Symbolic Name</em>' attribute.
	 * @see #getBundleSymbolicName()
	 * @generated
	 */
	void setBundleSymbolicName(String value);

	/**
	 * Returns the value of the '<em><b>Bundle Version</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Bundle Version</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Bundle Version</em>' attribute.
	 * @see #setBundleVersion(String)
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 *        extendedMetaData="kind='attribute' name='BundleVersion'"
	 * @generated
	 */
	String getBundleVersion();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.repository.Federate#getBundleVersion <em>Bundle Version</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Bundle Version</em>' attribute.
	 * @see #getBundleVersion()
	 * @generated
	 */
	void setBundleVersion(String value);

	/**
	 * Returns the value of the '<em><b>Bundle Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Bundle Description</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Bundle Description</em>' attribute.
	 * @see #setBundleDescription(String)
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 *        extendedMetaData="kind='attribute' name='BundleDescription'"
	 * @generated
	 */
	String getBundleDescription();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.repository.Federate#getBundleDescription <em>Bundle Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Bundle Description</em>' attribute.
	 * @see #getBundleDescription()
	 * @generated
	 */
	void setBundleDescription(String value);

	/**
	 * Returns the value of the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Description</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Description</em>' attribute.
	 * @see #setDescription(String)
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='element' name='description' namespace='##targetNamespace'"
	 * @generated
	 */
	String getDescription();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.repository.Federate#getDescription <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Description</em>' attribute.
	 * @see #getDescription()
	 * @generated
	 */
	void setDescription(String value);

	/**
	 * Returns the value of the '<em><b>Owning Mm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Owning Mm</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Owning Mm</em>' reference.
	 * @see #setOwningMm(ModelManager)
	 * @model extendedMetaData="kind='attribute' name='owningMm'"
	 * @generated
	 */
	ModelManager getOwningMm();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.repository.Federate#getOwningMm <em>Owning Mm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Owning Mm</em>' reference.
	 * @see #getOwningMm()
	 * @generated
	 */
	void setOwningMm(ModelManager value);

	/**
	 * Returns the value of the '<em><b>Trusted Sim Managers</b></em>' reference list.
	 * The list contents are of type {@link org.eodisp.core.gen.repository.SimManager}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Trusted Sim Managers</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trusted Sim Managers</em>' reference list.
	 * @model type="org.eodisp.core.gen.repository.SimManager"
	 *        extendedMetaData="kind='attribute' name='trustedSimManagers'"
	 * @generated
	 */
	List getTrustedSimManagers();

	/**
	 * Returns the value of the '<em><b>Som</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link org.eodisp.core.gen.repository.SOM#getFederates <em>Federates</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Som</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Som</em>' reference.
	 * @see #setSom(SOM)
	 * @see org.eodisp.core.gen.repository.SOM#getFederates
	 * @model opposite="federates" required="true"
	 *        extendedMetaData="kind='attribute' name='som'"
	 * @generated
	 */
	SOM getSom();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.repository.Federate#getSom <em>Som</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Som</em>' reference.
	 * @see #getSom()
	 * @generated
	 */
	void setSom(SOM value);

} // Federate