/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.core.gen.smproject.util;

import java.util.Map;

import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.xmi.util.XMLProcessor;

import org.eodisp.core.gen.smproject.impl.SmprojectPackageImpl;

/**
 * This class contains helper methods to serialize and deserialize XML documents
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class SmprojectXMLProcessor extends XMLProcessor {
	/**
	 * Public constructor to instantiate the helper.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SmprojectXMLProcessor() {
		super((EPackage.Registry.INSTANCE));
		SmprojectPackageImpl.eINSTANCE.eClass();
	}
	
	/**
	 * Register for "*" and "xml" file extensions the SmprojectResourceFactoryImpl factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Map getRegistrations() {
		if (registrations == null) {
			super.getRegistrations();
			registrations.put(XML_EXTENSION, new SmprojectResourceFactoryImpl());
			registrations.put(STAR_EXTENSION, new SmprojectResourceFactoryImpl());
		}
		return registrations;
	}

} //SmprojectXMLProcessor
