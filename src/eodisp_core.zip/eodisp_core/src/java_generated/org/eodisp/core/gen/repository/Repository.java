/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.core.gen.repository;

import java.util.List;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Repository</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.core.gen.repository.Repository#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.Repository#getDescription <em>Description</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.Repository#getModelManagers <em>Model Managers</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.Repository#getSimManagers <em>Sim Managers</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.Repository#getCategories <em>Categories</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.Repository#getSoms <em>Soms</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.Repository#getFederates <em>Federates</em>}</li>
 * </ul>
 * </p>
 *
 * @model extendedMetaData="name='Repository' kind='elementOnly'"
 * @generated
 */
public interface Repository {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='attribute' name='name'"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.repository.Repository#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Description</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Description</em>' attribute.
	 * @see #setDescription(String)
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
	 *        extendedMetaData="kind='element' name='description' namespace='##targetNamespace'"
	 * @generated
	 */
	String getDescription();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.repository.Repository#getDescription <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Description</em>' attribute.
	 * @see #getDescription()
	 * @generated
	 */
	void setDescription(String value);

	/**
	 * Returns the value of the '<em><b>Model Managers</b></em>' containment reference list.
	 * The list contents are of type {@link org.eodisp.core.gen.repository.ModelManager}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Model Managers</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Model Managers</em>' containment reference list.
	 * @model type="org.eodisp.core.gen.repository.ModelManager" containment="true"
	 *        extendedMetaData="kind='element' name='modelManagers' namespace='##targetNamespace'"
	 * @generated
	 */
	List getModelManagers();

	/**
	 * Returns the value of the '<em><b>Sim Managers</b></em>' containment reference list.
	 * The list contents are of type {@link org.eodisp.core.gen.repository.SimManager}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sim Managers</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sim Managers</em>' containment reference list.
	 * @model type="org.eodisp.core.gen.repository.SimManager" containment="true"
	 *        extendedMetaData="kind='element' name='simManagers' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSimManagers();

	/**
	 * Returns the value of the '<em><b>Categories</b></em>' containment reference list.
	 * The list contents are of type {@link org.eodisp.core.gen.repository.Category}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Categories</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Categories</em>' containment reference list.
	 * @model type="org.eodisp.core.gen.repository.Category" containment="true"
	 *        extendedMetaData="kind='element' name='categories' namespace='##targetNamespace'"
	 * @generated
	 */
	List getCategories();

	/**
	 * Returns the value of the '<em><b>Soms</b></em>' containment reference list.
	 * The list contents are of type {@link org.eodisp.core.gen.repository.SOM}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Soms</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Soms</em>' containment reference list.
	 * @model type="org.eodisp.core.gen.repository.SOM" containment="true"
	 *        extendedMetaData="kind='element' name='soms' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSoms();

	/**
	 * Returns the value of the '<em><b>Federates</b></em>' containment reference list.
	 * The list contents are of type {@link org.eodisp.core.gen.repository.Federate}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Federates</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Federates</em>' containment reference list.
	 * @model type="org.eodisp.core.gen.repository.Federate" containment="true"
	 *        annotation="ExtendedMetaData kind='element' name='federates' namespace='##targetNamespace'"
	 * @generated
	 */
	List getFederates();

} // Repository