/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.core.gen.smproject;

import java.util.List;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Experiment</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.core.gen.smproject.Experiment#getFederationExecution <em>Federation Execution</em>}</li>
 *   <li>{@link org.eodisp.core.gen.smproject.Experiment#getName <em>Name</em>}</li>
 * </ul>
 * </p>
 *
 * @model extendedMetaData="name='Experiment' kind='elementOnly'"
 * @generated
 */
public interface Experiment {
	/**
	 * Returns the value of the '<em><b>Federation Execution</b></em>' containment reference list.
	 * The list contents are of type {@link org.eodisp.core.gen.smproject.FederationExecution}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Federation Execution</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Federation Execution</em>' containment reference list.
	 * @model type="org.eodisp.core.gen.smproject.FederationExecution" containment="true"
	 *        extendedMetaData="kind='element' name='federationExecution' namespace='##targetNamespace'"
	 * @generated
	 */
	List getFederationExecution();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='attribute' name='name'"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.smproject.Experiment#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

} // Experiment