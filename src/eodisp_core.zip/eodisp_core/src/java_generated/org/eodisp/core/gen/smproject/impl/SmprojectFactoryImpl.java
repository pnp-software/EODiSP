/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.core.gen.smproject.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import org.eodisp.core.gen.smproject.*;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class SmprojectFactoryImpl extends EFactoryImpl implements SmprojectFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final SmprojectFactoryImpl eINSTANCE = init();

	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static SmprojectFactoryImpl init() {
		try {
			SmprojectFactoryImpl theSmprojectFactory = (SmprojectFactoryImpl)EPackage.Registry.INSTANCE.getEFactory("http://www.pnp-software.com/eodisp/smproject"); 
			if (theSmprojectFactory != null) {
				return theSmprojectFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new SmprojectFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SmprojectFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case SmprojectPackageImpl.DOCUMENT_ROOT: return (EObject)createDocumentRoot();
			case SmprojectPackageImpl.SM_PROJECT: return (EObject)createSmProject();
			case SmprojectPackageImpl.EXPERIMENT: return (EObject)createExperiment();
			case SmprojectPackageImpl.FEDERATION_EXECUTION: return (EObject)createFederationExecution();
			case SmprojectPackageImpl.FEDERATE_EXECUTION: return (EObject)createFederateExecution();
			case SmprojectPackageImpl.INIT_DATA: return (EObject)createInitData();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DocumentRoot createDocumentRoot() {
		DocumentRootImpl documentRoot = new DocumentRootImpl();
		return documentRoot;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Experiment createExperiment() {
		ExperimentImpl experiment = new ExperimentImpl();
		return experiment;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FederationExecution createFederationExecution() {
		FederationExecutionImpl federationExecution = new FederationExecutionImpl();
		return federationExecution;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InitData createInitData() {
		InitDataImpl initData = new InitDataImpl();
		return initData;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FederateExecution createFederateExecution() {
		FederateExecutionImpl federateExecution = new FederateExecutionImpl();
		return federateExecution;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SmProject createSmProject() {
		SmProjectImpl smProject = new SmProjectImpl();
		return smProject;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SmprojectPackageImpl getSmprojectPackageImpl() {
		return (SmprojectPackageImpl)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	public static SmprojectPackageImpl getPackage() {
		return SmprojectPackageImpl.eINSTANCE;
	}

} //SmprojectFactoryImpl
