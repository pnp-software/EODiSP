/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.core.gen.repository.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import org.eodisp.core.gen.repository.*;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class RepositoryFactoryImpl extends EFactoryImpl implements RepositoryFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final RepositoryFactoryImpl eINSTANCE = init();

	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static RepositoryFactoryImpl init() {
		try {
			RepositoryFactoryImpl theRepositoryFactory = (RepositoryFactoryImpl)EPackage.Registry.INSTANCE.getEFactory("http://www.pnp-software.com/eodisp/repository"); 
			if (theRepositoryFactory != null) {
				return theRepositoryFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new RepositoryFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RepositoryFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case RepositoryPackageImpl.DOCUMENT_ROOT: return (EObject)createDocumentRoot();
			case RepositoryPackageImpl.REPOSITORY: return (EObject)createRepository();
			case RepositoryPackageImpl.MODEL_MANAGER: return (EObject)createModelManager();
			case RepositoryPackageImpl.SIM_MANAGER: return (EObject)createSimManager();
			case RepositoryPackageImpl.CATEGORY: return (EObject)createCategory();
			case RepositoryPackageImpl.SOM: return (EObject)createSOM();
			case RepositoryPackageImpl.FEDERATE: return (EObject)createFederate();
			case RepositoryPackageImpl.APP_OWNER: return (EObject)createAppOwner();
			case RepositoryPackageImpl.REMOTE_LOCATION: return (EObject)createRemoteLocation();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DocumentRoot createDocumentRoot() {
		DocumentRootImpl documentRoot = new DocumentRootImpl();
		return documentRoot;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Repository createRepository() {
		RepositoryImpl repository = new RepositoryImpl();
		return repository;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ModelManager createModelManager() {
		ModelManagerImpl modelManager = new ModelManagerImpl();
		return modelManager;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SimManager createSimManager() {
		SimManagerImpl simManager = new SimManagerImpl();
		return simManager;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Category createCategory() {
		CategoryImpl category = new CategoryImpl();
		return category;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SOM createSOM() {
		SOMImpl som = new SOMImpl();
		return som;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Federate createFederate() {
		FederateImpl federate = new FederateImpl();
		return federate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AppOwner createAppOwner() {
		AppOwnerImpl appOwner = new AppOwnerImpl();
		return appOwner;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RemoteLocation createRemoteLocation() {
		RemoteLocationImpl remoteLocation = new RemoteLocationImpl();
		return remoteLocation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RepositoryPackageImpl getRepositoryPackageImpl() {
		return (RepositoryPackageImpl)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	public static RepositoryPackageImpl getPackage() {
		return RepositoryPackageImpl.eINSTANCE;
	}

} //RepositoryFactoryImpl
