/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.core.gen.repository;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sim Manager</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.core.gen.repository.SimManager#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.SimManager#getId <em>Id</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.SimManager#getDescription <em>Description</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.SimManager#getAppOwner <em>App Owner</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.SimManager#getRemoteLocation <em>Remote Location</em>}</li>
 * </ul>
 * </p>
 *
 * @model extendedMetaData="name='SimManager' kind='elementOnly'"
 * @generated
 */
public interface SimManager {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='attribute' name='name'"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.repository.SimManager#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id</em>' attribute.
	 * @see #setId(String)
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
	 *        extendedMetaData="kind='attribute' name='id'"
	 * @generated
	 */
	String getId();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.repository.SimManager#getId <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id</em>' attribute.
	 * @see #getId()
	 * @generated
	 */
	void setId(String value);

	/**
	 * Returns the value of the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Description</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Description</em>' attribute.
	 * @see #setDescription(String)
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='element' name='description' namespace='##targetNamespace'"
	 * @generated
	 */
	String getDescription();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.repository.SimManager#getDescription <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Description</em>' attribute.
	 * @see #getDescription()
	 * @generated
	 */
	void setDescription(String value);

	/**
	 * Returns the value of the '<em><b>App Owner</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>App Owner</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>App Owner</em>' containment reference.
	 * @see #setAppOwner(AppOwner)
	 * @model containment="true" required="true"
	 *        extendedMetaData="kind='element' name='appOwner' namespace='##targetNamespace'"
	 * @generated
	 */
	AppOwner getAppOwner();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.repository.SimManager#getAppOwner <em>App Owner</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>App Owner</em>' containment reference.
	 * @see #getAppOwner()
	 * @generated
	 */
	void setAppOwner(AppOwner value);

	/**
	 * Returns the value of the '<em><b>Remote Location</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Remote Location</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Remote Location</em>' containment reference.
	 * @see #setRemoteLocation(RemoteLocation)
	 * @model containment="true" required="true"
	 *        extendedMetaData="kind='element' name='remoteLocation' namespace='##targetNamespace'"
	 * @generated
	 */
	RemoteLocation getRemoteLocation();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.repository.SimManager#getRemoteLocation <em>Remote Location</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Remote Location</em>' containment reference.
	 * @see #getRemoteLocation()
	 * @generated
	 */
	void setRemoteLocation(RemoteLocation value);

} // SimManager