/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.core.gen.repository.impl;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.eodisp.core.gen.repository.Category;
import org.eodisp.core.gen.repository.Federate;
import org.eodisp.core.gen.repository.ModelManager;
import org.eodisp.core.gen.repository.Repository;
import org.eodisp.core.gen.repository.SOM;
import org.eodisp.core.gen.repository.SimManager;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Repository</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eodisp.core.gen.repository.impl.RepositoryImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.impl.RepositoryImpl#getDescription <em>Description</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.impl.RepositoryImpl#getModelManagers <em>Model Managers</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.impl.RepositoryImpl#getSimManagers <em>Sim Managers</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.impl.RepositoryImpl#getCategories <em>Categories</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.impl.RepositoryImpl#getSoms <em>Soms</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.impl.RepositoryImpl#getFederates <em>Federates</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class RepositoryImpl extends EDataObjectImpl implements Repository {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getDescription() <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDescription()
	 * @generated
	 * @ordered
	 */
	protected static final String DESCRIPTION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDescription() <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDescription()
	 * @generated
	 * @ordered
	 */
	protected String description = DESCRIPTION_EDEFAULT;

	/**
	 * The cached value of the '{@link #getModelManagers() <em>Model Managers</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getModelManagers()
	 * @generated
	 * @ordered
	 */
	protected EList modelManagers = null;

	/**
	 * The cached value of the '{@link #getSimManagers() <em>Sim Managers</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSimManagers()
	 * @generated
	 * @ordered
	 */
	protected EList simManagers = null;

	/**
	 * The cached value of the '{@link #getCategories() <em>Categories</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCategories()
	 * @generated
	 * @ordered
	 */
	protected EList categories = null;

	/**
	 * The cached value of the '{@link #getSoms() <em>Soms</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSoms()
	 * @generated
	 * @ordered
	 */
	protected EList soms = null;

	/**
	 * The cached value of the '{@link #getFederates() <em>Federates</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFederates()
	 * @generated
	 * @ordered
	 */
	protected EList federates = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RepositoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return RepositoryPackageImpl.Literals.REPOSITORY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RepositoryPackageImpl.REPOSITORY__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDescription(String newDescription) {
		String oldDescription = description;
		description = newDescription;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RepositoryPackageImpl.REPOSITORY__DESCRIPTION, oldDescription, description));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getModelManagers() {
		if (modelManagers == null) {
			modelManagers = new EObjectContainmentEList(ModelManager.class, this, RepositoryPackageImpl.REPOSITORY__MODEL_MANAGERS);
		}
		return modelManagers;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getSimManagers() {
		if (simManagers == null) {
			simManagers = new EObjectContainmentEList(SimManager.class, this, RepositoryPackageImpl.REPOSITORY__SIM_MANAGERS);
		}
		return simManagers;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getCategories() {
		if (categories == null) {
			categories = new EObjectContainmentEList(Category.class, this, RepositoryPackageImpl.REPOSITORY__CATEGORIES);
		}
		return categories;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getSoms() {
		if (soms == null) {
			soms = new EObjectContainmentEList(SOM.class, this, RepositoryPackageImpl.REPOSITORY__SOMS);
		}
		return soms;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getFederates() {
		if (federates == null) {
			federates = new EObjectContainmentEList(Federate.class, this, RepositoryPackageImpl.REPOSITORY__FEDERATES);
		}
		return federates;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case RepositoryPackageImpl.REPOSITORY__MODEL_MANAGERS:
				return ((InternalEList)getModelManagers()).basicRemove(otherEnd, msgs);
			case RepositoryPackageImpl.REPOSITORY__SIM_MANAGERS:
				return ((InternalEList)getSimManagers()).basicRemove(otherEnd, msgs);
			case RepositoryPackageImpl.REPOSITORY__CATEGORIES:
				return ((InternalEList)getCategories()).basicRemove(otherEnd, msgs);
			case RepositoryPackageImpl.REPOSITORY__SOMS:
				return ((InternalEList)getSoms()).basicRemove(otherEnd, msgs);
			case RepositoryPackageImpl.REPOSITORY__FEDERATES:
				return ((InternalEList)getFederates()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case RepositoryPackageImpl.REPOSITORY__NAME:
				return getName();
			case RepositoryPackageImpl.REPOSITORY__DESCRIPTION:
				return getDescription();
			case RepositoryPackageImpl.REPOSITORY__MODEL_MANAGERS:
				return getModelManagers();
			case RepositoryPackageImpl.REPOSITORY__SIM_MANAGERS:
				return getSimManagers();
			case RepositoryPackageImpl.REPOSITORY__CATEGORIES:
				return getCategories();
			case RepositoryPackageImpl.REPOSITORY__SOMS:
				return getSoms();
			case RepositoryPackageImpl.REPOSITORY__FEDERATES:
				return getFederates();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case RepositoryPackageImpl.REPOSITORY__NAME:
				setName((String)newValue);
				return;
			case RepositoryPackageImpl.REPOSITORY__DESCRIPTION:
				setDescription((String)newValue);
				return;
			case RepositoryPackageImpl.REPOSITORY__MODEL_MANAGERS:
				getModelManagers().clear();
				getModelManagers().addAll((Collection)newValue);
				return;
			case RepositoryPackageImpl.REPOSITORY__SIM_MANAGERS:
				getSimManagers().clear();
				getSimManagers().addAll((Collection)newValue);
				return;
			case RepositoryPackageImpl.REPOSITORY__CATEGORIES:
				getCategories().clear();
				getCategories().addAll((Collection)newValue);
				return;
			case RepositoryPackageImpl.REPOSITORY__SOMS:
				getSoms().clear();
				getSoms().addAll((Collection)newValue);
				return;
			case RepositoryPackageImpl.REPOSITORY__FEDERATES:
				getFederates().clear();
				getFederates().addAll((Collection)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case RepositoryPackageImpl.REPOSITORY__NAME:
				setName(NAME_EDEFAULT);
				return;
			case RepositoryPackageImpl.REPOSITORY__DESCRIPTION:
				setDescription(DESCRIPTION_EDEFAULT);
				return;
			case RepositoryPackageImpl.REPOSITORY__MODEL_MANAGERS:
				getModelManagers().clear();
				return;
			case RepositoryPackageImpl.REPOSITORY__SIM_MANAGERS:
				getSimManagers().clear();
				return;
			case RepositoryPackageImpl.REPOSITORY__CATEGORIES:
				getCategories().clear();
				return;
			case RepositoryPackageImpl.REPOSITORY__SOMS:
				getSoms().clear();
				return;
			case RepositoryPackageImpl.REPOSITORY__FEDERATES:
				getFederates().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case RepositoryPackageImpl.REPOSITORY__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case RepositoryPackageImpl.REPOSITORY__DESCRIPTION:
				return DESCRIPTION_EDEFAULT == null ? description != null : !DESCRIPTION_EDEFAULT.equals(description);
			case RepositoryPackageImpl.REPOSITORY__MODEL_MANAGERS:
				return modelManagers != null && !modelManagers.isEmpty();
			case RepositoryPackageImpl.REPOSITORY__SIM_MANAGERS:
				return simManagers != null && !simManagers.isEmpty();
			case RepositoryPackageImpl.REPOSITORY__CATEGORIES:
				return categories != null && !categories.isEmpty();
			case RepositoryPackageImpl.REPOSITORY__SOMS:
				return soms != null && !soms.isEmpty();
			case RepositoryPackageImpl.REPOSITORY__FEDERATES:
				return federates != null && !federates.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", description: ");
		result.append(description);
		result.append(')');
		return result.toString();
	}

} //RepositoryImpl