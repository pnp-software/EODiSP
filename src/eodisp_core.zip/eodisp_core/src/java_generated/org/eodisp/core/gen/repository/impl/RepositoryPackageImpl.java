/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.core.gen.repository.impl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EFactory;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.eclipse.emf.ecore.xml.type.XMLTypePackage;

import org.eodisp.core.gen.repository.AppOwner;
import org.eodisp.core.gen.repository.Category;
import org.eodisp.core.gen.repository.DocumentRoot;
import org.eodisp.core.gen.repository.Federate;
import org.eodisp.core.gen.repository.ModelManager;
import org.eodisp.core.gen.repository.RemoteLocation;
import org.eodisp.core.gen.repository.Repository;
import org.eodisp.core.gen.repository.RepositoryFactory;
import org.eodisp.core.gen.repository.SimManager;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see org.eodisp.core.gen.repository.RepositoryFactory
 * @model kind="package"
 * @generated
 */
public class RepositoryPackageImpl extends EPackageImpl {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String eNAME = "repository";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String eNS_URI = "http://www.pnp-software.com/eodisp/repository";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String eNS_PREFIX = "repository";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final RepositoryPackageImpl eINSTANCE = org.eodisp.core.gen.repository.impl.RepositoryPackageImpl.init();

	/**
	 * The meta object id for the '{@link org.eodisp.core.gen.repository.impl.DocumentRootImpl <em>Document Root</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eodisp.core.gen.repository.impl.DocumentRootImpl
	 * @see org.eodisp.core.gen.repository.impl.RepositoryPackageImpl#getDocumentRoot()
	 * @generated
	 */
	public static final int DOCUMENT_ROOT = 0;

	/**
	 * The feature id for the '<em><b>Mixed</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int DOCUMENT_ROOT__MIXED = 0;

	/**
	 * The feature id for the '<em><b>XMLNS Prefix Map</b></em>' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int DOCUMENT_ROOT__XMLNS_PREFIX_MAP = 1;

	/**
	 * The feature id for the '<em><b>XSI Schema Location</b></em>' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int DOCUMENT_ROOT__XSI_SCHEMA_LOCATION = 2;

	/**
	 * The feature id for the '<em><b>Repository</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int DOCUMENT_ROOT__REPOSITORY = 3;

	/**
	 * The feature id for the '<em><b>Local Path</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int DOCUMENT_ROOT__LOCAL_PATH = 4;

	/**
	 * The number of structural features of the '<em>Document Root</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int DOCUMENT_ROOT_FEATURE_COUNT = 5;

	/**
	 * The meta object id for the '{@link org.eodisp.core.gen.repository.impl.RepositoryImpl <em>Repository</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eodisp.core.gen.repository.impl.RepositoryImpl
	 * @see org.eodisp.core.gen.repository.impl.RepositoryPackageImpl#getRepository()
	 * @generated
	 */
	public static final int REPOSITORY = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int REPOSITORY__NAME = 0;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int REPOSITORY__DESCRIPTION = 1;

	/**
	 * The feature id for the '<em><b>Model Managers</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int REPOSITORY__MODEL_MANAGERS = 2;

	/**
	 * The feature id for the '<em><b>Sim Managers</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int REPOSITORY__SIM_MANAGERS = 3;

	/**
	 * The feature id for the '<em><b>Categories</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int REPOSITORY__CATEGORIES = 4;

	/**
	 * The feature id for the '<em><b>Soms</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int REPOSITORY__SOMS = 5;

	/**
	 * The feature id for the '<em><b>Federates</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int REPOSITORY__FEDERATES = 6;

	/**
	 * The number of structural features of the '<em>Repository</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int REPOSITORY_FEATURE_COUNT = 7;

	/**
	 * The meta object id for the '{@link org.eodisp.core.gen.repository.impl.ModelManagerImpl <em>Model Manager</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eodisp.core.gen.repository.impl.ModelManagerImpl
	 * @see org.eodisp.core.gen.repository.impl.RepositoryPackageImpl#getModelManager()
	 * @generated
	 */
	public static final int MODEL_MANAGER = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int MODEL_MANAGER__NAME = 0;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int MODEL_MANAGER__ID = 1;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int MODEL_MANAGER__DESCRIPTION = 2;

	/**
	 * The feature id for the '<em><b>App Owner</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int MODEL_MANAGER__APP_OWNER = 3;

	/**
	 * The feature id for the '<em><b>Remote Location</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int MODEL_MANAGER__REMOTE_LOCATION = 4;

	/**
	 * The number of structural features of the '<em>Model Manager</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int MODEL_MANAGER_FEATURE_COUNT = 5;

	/**
	 * The meta object id for the '{@link org.eodisp.core.gen.repository.impl.SimManagerImpl <em>Sim Manager</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eodisp.core.gen.repository.impl.SimManagerImpl
	 * @see org.eodisp.core.gen.repository.impl.RepositoryPackageImpl#getSimManager()
	 * @generated
	 */
	public static final int SIM_MANAGER = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int SIM_MANAGER__NAME = 0;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int SIM_MANAGER__ID = 1;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int SIM_MANAGER__DESCRIPTION = 2;

	/**
	 * The feature id for the '<em><b>App Owner</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int SIM_MANAGER__APP_OWNER = 3;

	/**
	 * The feature id for the '<em><b>Remote Location</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int SIM_MANAGER__REMOTE_LOCATION = 4;

	/**
	 * The number of structural features of the '<em>Sim Manager</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int SIM_MANAGER_FEATURE_COUNT = 5;

	/**
	 * The meta object id for the '{@link org.eodisp.core.gen.repository.impl.CategoryImpl <em>Category</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eodisp.core.gen.repository.impl.CategoryImpl
	 * @see org.eodisp.core.gen.repository.impl.RepositoryPackageImpl#getCategory()
	 * @generated
	 */
	public static final int CATEGORY = 4;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int CATEGORY__ID = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int CATEGORY__NAME = 1;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int CATEGORY__DESCRIPTION = 2;

	/**
	 * The feature id for the '<em><b>Closed</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int CATEGORY__CLOSED = 3;

	/**
	 * The feature id for the '<em><b>Soms</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int CATEGORY__SOMS = 4;

	/**
	 * The number of structural features of the '<em>Category</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int CATEGORY_FEATURE_COUNT = 5;

	/**
	 * The meta object id for the '{@link org.eodisp.core.gen.repository.impl.SOMImpl <em>SOM</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eodisp.core.gen.repository.impl.SOMImpl
	 * @see org.eodisp.core.gen.repository.impl.RepositoryPackageImpl#getSOM()
	 * @generated
	 */
	public static final int SOM = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int SOM__NAME = 0;

	/**
	 * The feature id for the '<em><b>Version</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int SOM__VERSION = 1;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int SOM__DESCRIPTION = 2;

	/**
	 * The feature id for the '<em><b>Categories</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int SOM__CATEGORIES = 3;

	/**
	 * The feature id for the '<em><b>Federates</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int SOM__FEDERATES = 4;

	/**
	 * The feature id for the '<em><b>Local Path</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int SOM__LOCAL_PATH = 5;

	/**
	 * The feature id for the '<em><b>File Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int SOM__FILE_NAME = 6;

	/**
	 * The number of structural features of the '<em>SOM</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int SOM_FEATURE_COUNT = 7;

	/**
	 * The meta object id for the '{@link org.eodisp.core.gen.repository.impl.FederateImpl <em>Federate</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eodisp.core.gen.repository.impl.FederateImpl
	 * @see org.eodisp.core.gen.repository.impl.RepositoryPackageImpl#getFederate()
	 * @generated
	 */
	public static final int FEDERATE = 6;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int FEDERATE__ID = 0;

	/**
	 * The feature id for the '<em><b>Bundle Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int FEDERATE__BUNDLE_NAME = 1;

	/**
	 * The feature id for the '<em><b>Bundle Symbolic Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int FEDERATE__BUNDLE_SYMBOLIC_NAME = 2;

	/**
	 * The feature id for the '<em><b>Bundle Version</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int FEDERATE__BUNDLE_VERSION = 3;

	/**
	 * The feature id for the '<em><b>Bundle Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int FEDERATE__BUNDLE_DESCRIPTION = 4;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int FEDERATE__DESCRIPTION = 5;

	/**
	 * The feature id for the '<em><b>Owning Mm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int FEDERATE__OWNING_MM = 6;

	/**
	 * The feature id for the '<em><b>Trusted Sim Managers</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int FEDERATE__TRUSTED_SIM_MANAGERS = 7;

	/**
	 * The feature id for the '<em><b>Som</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int FEDERATE__SOM = 8;

	/**
	 * The number of structural features of the '<em>Federate</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int FEDERATE_FEATURE_COUNT = 9;

	/**
	 * The meta object id for the '{@link org.eodisp.core.gen.repository.impl.AppOwnerImpl <em>App Owner</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eodisp.core.gen.repository.impl.AppOwnerImpl
	 * @see org.eodisp.core.gen.repository.impl.RepositoryPackageImpl#getAppOwner()
	 * @generated
	 */
	public static final int APP_OWNER = 7;

	/**
	 * The feature id for the '<em><b>Firstname</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int APP_OWNER__FIRSTNAME = 0;

	/**
	 * The feature id for the '<em><b>Surname</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int APP_OWNER__SURNAME = 1;

	/**
	 * The feature id for the '<em><b>Mail</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int APP_OWNER__MAIL = 2;

	/**
	 * The feature id for the '<em><b>Tel</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int APP_OWNER__TEL = 3;

	/**
	 * The feature id for the '<em><b>Country</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int APP_OWNER__COUNTRY = 4;

	/**
	 * The feature id for the '<em><b>Custom1</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int APP_OWNER__CUSTOM1 = 5;

	/**
	 * The feature id for the '<em><b>Custom2</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int APP_OWNER__CUSTOM2 = 6;

	/**
	 * The feature id for the '<em><b>Custom3</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int APP_OWNER__CUSTOM3 = 7;

	/**
	 * The number of structural features of the '<em>App Owner</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int APP_OWNER_FEATURE_COUNT = 8;

	/**
	 * The meta object id for the '{@link org.eodisp.core.gen.repository.impl.RemoteLocationImpl <em>Remote Location</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eodisp.core.gen.repository.impl.RemoteLocationImpl
	 * @see org.eodisp.core.gen.repository.impl.RepositoryPackageImpl#getRemoteLocation()
	 * @generated
	 */
	public static final int REMOTE_LOCATION = 8;

	/**
	 * The feature id for the '<em><b>Uri</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int REMOTE_LOCATION__URI = 0;

	/**
	 * The number of structural features of the '<em>Remote Location</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int REMOTE_LOCATION_FEATURE_COUNT = 1;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass documentRootEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass repositoryEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass modelManagerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass simManagerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass categoryEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass somEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass federateEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass appOwnerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass remoteLocationEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see org.eodisp.core.gen.repository.impl.RepositoryPackageImpl#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private RepositoryPackageImpl() {
		super(eNS_URI, ((EFactory)RepositoryFactory.INSTANCE));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this
	 * model, and for any others upon which it depends.  Simple
	 * dependencies are satisfied by calling this method on all
	 * dependent packages before doing anything else.  This method drives
	 * initialization for interdependent packages directly, in parallel
	 * with this package, itself.
	 * <p>Of this package and its interdependencies, all packages which
	 * have not yet been registered by their URI values are first created
	 * and registered.  The packages are then initialized in two steps:
	 * meta-model objects for all of the packages are created before any
	 * are initialized, since one package's meta-model objects may refer to
	 * those of another.
	 * <p>Invocation of this method will not affect any packages that have
	 * already been initialized.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static RepositoryPackageImpl init() {
		if (isInited) return (RepositoryPackageImpl)EPackage.Registry.INSTANCE.getEPackage(RepositoryPackageImpl.eNS_URI);

		// Obtain or create and register package
		RepositoryPackageImpl theRepositoryPackageImpl = (RepositoryPackageImpl)(EPackage.Registry.INSTANCE.getEPackage(eNS_URI) instanceof RepositoryPackageImpl ? EPackage.Registry.INSTANCE.getEPackage(eNS_URI) : new RepositoryPackageImpl());

		isInited = true;

		// Initialize simple dependencies
		XMLTypePackage.eINSTANCE.eClass();

		// Create package meta-data objects
		theRepositoryPackageImpl.createPackageContents();

		// Initialize created meta-data
		theRepositoryPackageImpl.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theRepositoryPackageImpl.freeze();

		return theRepositoryPackageImpl;
	}


	/**
	 * Returns the meta object for class '{@link org.eodisp.core.gen.repository.DocumentRoot <em>Document Root</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Document Root</em>'.
	 * @see org.eodisp.core.gen.repository.DocumentRoot
	 * @generated
	 */
	public EClass getDocumentRoot() {
		return documentRootEClass;
	}

	/**
	 * Returns the meta object for the attribute list '{@link org.eodisp.core.gen.repository.DocumentRoot#getMixed <em>Mixed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Mixed</em>'.
	 * @see org.eodisp.core.gen.repository.DocumentRoot#getMixed()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	public EAttribute getDocumentRoot_Mixed() {
		return (EAttribute)documentRootEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * Returns the meta object for the map '{@link org.eodisp.core.gen.repository.DocumentRoot#getXMLNSPrefixMap <em>XMLNS Prefix Map</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the map '<em>XMLNS Prefix Map</em>'.
	 * @see org.eodisp.core.gen.repository.DocumentRoot#getXMLNSPrefixMap()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	public EReference getDocumentRoot_XMLNSPrefixMap() {
		return (EReference)documentRootEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * Returns the meta object for the map '{@link org.eodisp.core.gen.repository.DocumentRoot#getXSISchemaLocation <em>XSI Schema Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the map '<em>XSI Schema Location</em>'.
	 * @see org.eodisp.core.gen.repository.DocumentRoot#getXSISchemaLocation()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	public EReference getDocumentRoot_XSISchemaLocation() {
		return (EReference)documentRootEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.core.gen.repository.DocumentRoot#getRepository <em>Repository</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Repository</em>'.
	 * @see org.eodisp.core.gen.repository.DocumentRoot#getRepository()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	public EReference getDocumentRoot_Repository() {
		return (EReference)documentRootEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.DocumentRoot#getLocalPath <em>Local Path</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Local Path</em>'.
	 * @see org.eodisp.core.gen.repository.DocumentRoot#getLocalPath()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	public EAttribute getDocumentRoot_LocalPath() {
		return (EAttribute)documentRootEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * Returns the meta object for class '{@link org.eodisp.core.gen.repository.Repository <em>Repository</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Repository</em>'.
	 * @see org.eodisp.core.gen.repository.Repository
	 * @generated
	 */
	public EClass getRepository() {
		return repositoryEClass;
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.Repository#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eodisp.core.gen.repository.Repository#getName()
	 * @see #getRepository()
	 * @generated
	 */
	public EAttribute getRepository_Name() {
		return (EAttribute)repositoryEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.Repository#getDescription <em>Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description</em>'.
	 * @see org.eodisp.core.gen.repository.Repository#getDescription()
	 * @see #getRepository()
	 * @generated
	 */
	public EAttribute getRepository_Description() {
		return (EAttribute)repositoryEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * Returns the meta object for the containment reference list '{@link org.eodisp.core.gen.repository.Repository#getModelManagers <em>Model Managers</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Model Managers</em>'.
	 * @see org.eodisp.core.gen.repository.Repository#getModelManagers()
	 * @see #getRepository()
	 * @generated
	 */
	public EReference getRepository_ModelManagers() {
		return (EReference)repositoryEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * Returns the meta object for the containment reference list '{@link org.eodisp.core.gen.repository.Repository#getSimManagers <em>Sim Managers</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Sim Managers</em>'.
	 * @see org.eodisp.core.gen.repository.Repository#getSimManagers()
	 * @see #getRepository()
	 * @generated
	 */
	public EReference getRepository_SimManagers() {
		return (EReference)repositoryEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * Returns the meta object for the containment reference list '{@link org.eodisp.core.gen.repository.Repository#getCategories <em>Categories</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Categories</em>'.
	 * @see org.eodisp.core.gen.repository.Repository#getCategories()
	 * @see #getRepository()
	 * @generated
	 */
	public EReference getRepository_Categories() {
		return (EReference)repositoryEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * Returns the meta object for the containment reference list '{@link org.eodisp.core.gen.repository.Repository#getSoms <em>Soms</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Soms</em>'.
	 * @see org.eodisp.core.gen.repository.Repository#getSoms()
	 * @see #getRepository()
	 * @generated
	 */
	public EReference getRepository_Soms() {
		return (EReference)repositoryEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * Returns the meta object for the containment reference list '{@link org.eodisp.core.gen.repository.Repository#getFederates <em>Federates</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Federates</em>'.
	 * @see org.eodisp.core.gen.repository.Repository#getFederates()
	 * @see #getRepository()
	 * @generated
	 */
	public EReference getRepository_Federates() {
		return (EReference)repositoryEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * Returns the meta object for class '{@link org.eodisp.core.gen.repository.ModelManager <em>Model Manager</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Model Manager</em>'.
	 * @see org.eodisp.core.gen.repository.ModelManager
	 * @generated
	 */
	public EClass getModelManager() {
		return modelManagerEClass;
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.ModelManager#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eodisp.core.gen.repository.ModelManager#getName()
	 * @see #getModelManager()
	 * @generated
	 */
	public EAttribute getModelManager_Name() {
		return (EAttribute)modelManagerEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.ModelManager#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see org.eodisp.core.gen.repository.ModelManager#getId()
	 * @see #getModelManager()
	 * @generated
	 */
	public EAttribute getModelManager_Id() {
		return (EAttribute)modelManagerEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.ModelManager#getDescription <em>Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description</em>'.
	 * @see org.eodisp.core.gen.repository.ModelManager#getDescription()
	 * @see #getModelManager()
	 * @generated
	 */
	public EAttribute getModelManager_Description() {
		return (EAttribute)modelManagerEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.core.gen.repository.ModelManager#getAppOwner <em>App Owner</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>App Owner</em>'.
	 * @see org.eodisp.core.gen.repository.ModelManager#getAppOwner()
	 * @see #getModelManager()
	 * @generated
	 */
	public EReference getModelManager_AppOwner() {
		return (EReference)modelManagerEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.core.gen.repository.ModelManager#getRemoteLocation <em>Remote Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Remote Location</em>'.
	 * @see org.eodisp.core.gen.repository.ModelManager#getRemoteLocation()
	 * @see #getModelManager()
	 * @generated
	 */
	public EReference getModelManager_RemoteLocation() {
		return (EReference)modelManagerEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * Returns the meta object for class '{@link org.eodisp.core.gen.repository.SimManager <em>Sim Manager</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Sim Manager</em>'.
	 * @see org.eodisp.core.gen.repository.SimManager
	 * @generated
	 */
	public EClass getSimManager() {
		return simManagerEClass;
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.SimManager#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eodisp.core.gen.repository.SimManager#getName()
	 * @see #getSimManager()
	 * @generated
	 */
	public EAttribute getSimManager_Name() {
		return (EAttribute)simManagerEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.SimManager#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see org.eodisp.core.gen.repository.SimManager#getId()
	 * @see #getSimManager()
	 * @generated
	 */
	public EAttribute getSimManager_Id() {
		return (EAttribute)simManagerEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.SimManager#getDescription <em>Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description</em>'.
	 * @see org.eodisp.core.gen.repository.SimManager#getDescription()
	 * @see #getSimManager()
	 * @generated
	 */
	public EAttribute getSimManager_Description() {
		return (EAttribute)simManagerEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.core.gen.repository.SimManager#getAppOwner <em>App Owner</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>App Owner</em>'.
	 * @see org.eodisp.core.gen.repository.SimManager#getAppOwner()
	 * @see #getSimManager()
	 * @generated
	 */
	public EReference getSimManager_AppOwner() {
		return (EReference)simManagerEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * Returns the meta object for the containment reference '{@link org.eodisp.core.gen.repository.SimManager#getRemoteLocation <em>Remote Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Remote Location</em>'.
	 * @see org.eodisp.core.gen.repository.SimManager#getRemoteLocation()
	 * @see #getSimManager()
	 * @generated
	 */
	public EReference getSimManager_RemoteLocation() {
		return (EReference)simManagerEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * Returns the meta object for class '{@link org.eodisp.core.gen.repository.Category <em>Category</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Category</em>'.
	 * @see org.eodisp.core.gen.repository.Category
	 * @generated
	 */
	public EClass getCategory() {
		return categoryEClass;
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.Category#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see org.eodisp.core.gen.repository.Category#getId()
	 * @see #getCategory()
	 * @generated
	 */
	public EAttribute getCategory_Id() {
		return (EAttribute)categoryEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.Category#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eodisp.core.gen.repository.Category#getName()
	 * @see #getCategory()
	 * @generated
	 */
	public EAttribute getCategory_Name() {
		return (EAttribute)categoryEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.Category#getDescription <em>Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description</em>'.
	 * @see org.eodisp.core.gen.repository.Category#getDescription()
	 * @see #getCategory()
	 * @generated
	 */
	public EAttribute getCategory_Description() {
		return (EAttribute)categoryEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.Category#getClosed <em>Closed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Closed</em>'.
	 * @see org.eodisp.core.gen.repository.Category#getClosed()
	 * @see #getCategory()
	 * @generated
	 */
	public EAttribute getCategory_Closed() {
		return (EAttribute)categoryEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * Returns the meta object for the reference list '{@link org.eodisp.core.gen.repository.Category#getSoms <em>Soms</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Soms</em>'.
	 * @see org.eodisp.core.gen.repository.Category#getSoms()
	 * @see #getCategory()
	 * @generated
	 */
	public EReference getCategory_Soms() {
		return (EReference)categoryEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * Returns the meta object for class '{@link org.eodisp.core.gen.repository.SOM <em>SOM</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>SOM</em>'.
	 * @see org.eodisp.core.gen.repository.SOM
	 * @generated
	 */
	public EClass getSOM() {
		return somEClass;
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.SOM#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eodisp.core.gen.repository.SOM#getName()
	 * @see #getSOM()
	 * @generated
	 */
	public EAttribute getSOM_Name() {
		return (EAttribute)somEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.SOM#getVersion <em>Version</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Version</em>'.
	 * @see org.eodisp.core.gen.repository.SOM#getVersion()
	 * @see #getSOM()
	 * @generated
	 */
	public EAttribute getSOM_Version() {
		return (EAttribute)somEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.SOM#getDescription <em>Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description</em>'.
	 * @see org.eodisp.core.gen.repository.SOM#getDescription()
	 * @see #getSOM()
	 * @generated
	 */
	public EAttribute getSOM_Description() {
		return (EAttribute)somEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * Returns the meta object for the reference list '{@link org.eodisp.core.gen.repository.SOM#getCategories <em>Categories</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Categories</em>'.
	 * @see org.eodisp.core.gen.repository.SOM#getCategories()
	 * @see #getSOM()
	 * @generated
	 */
	public EReference getSOM_Categories() {
		return (EReference)somEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * Returns the meta object for the reference list '{@link org.eodisp.core.gen.repository.SOM#getFederates <em>Federates</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Federates</em>'.
	 * @see org.eodisp.core.gen.repository.SOM#getFederates()
	 * @see #getSOM()
	 * @generated
	 */
	public EReference getSOM_Federates() {
		return (EReference)somEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.SOM#getLocalPath <em>Local Path</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Local Path</em>'.
	 * @see org.eodisp.core.gen.repository.SOM#getLocalPath()
	 * @see #getSOM()
	 * @generated
	 */
	public EAttribute getSOM_LocalPath() {
		return (EAttribute)somEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.SOM#getFileName <em>File Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>File Name</em>'.
	 * @see org.eodisp.core.gen.repository.SOM#getFileName()
	 * @see #getSOM()
	 * @generated
	 */
	public EAttribute getSOM_FileName() {
		return (EAttribute)somEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * Returns the meta object for class '{@link org.eodisp.core.gen.repository.Federate <em>Federate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Federate</em>'.
	 * @see org.eodisp.core.gen.repository.Federate
	 * @generated
	 */
	public EClass getFederate() {
		return federateEClass;
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.Federate#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see org.eodisp.core.gen.repository.Federate#getId()
	 * @see #getFederate()
	 * @generated
	 */
	public EAttribute getFederate_Id() {
		return (EAttribute)federateEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.Federate#getBundleName <em>Bundle Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Bundle Name</em>'.
	 * @see org.eodisp.core.gen.repository.Federate#getBundleName()
	 * @see #getFederate()
	 * @generated
	 */
	public EAttribute getFederate_BundleName() {
		return (EAttribute)federateEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.Federate#getBundleSymbolicName <em>Bundle Symbolic Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Bundle Symbolic Name</em>'.
	 * @see org.eodisp.core.gen.repository.Federate#getBundleSymbolicName()
	 * @see #getFederate()
	 * @generated
	 */
	public EAttribute getFederate_BundleSymbolicName() {
		return (EAttribute)federateEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.Federate#getBundleVersion <em>Bundle Version</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Bundle Version</em>'.
	 * @see org.eodisp.core.gen.repository.Federate#getBundleVersion()
	 * @see #getFederate()
	 * @generated
	 */
	public EAttribute getFederate_BundleVersion() {
		return (EAttribute)federateEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.Federate#getBundleDescription <em>Bundle Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Bundle Description</em>'.
	 * @see org.eodisp.core.gen.repository.Federate#getBundleDescription()
	 * @see #getFederate()
	 * @generated
	 */
	public EAttribute getFederate_BundleDescription() {
		return (EAttribute)federateEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.Federate#getDescription <em>Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description</em>'.
	 * @see org.eodisp.core.gen.repository.Federate#getDescription()
	 * @see #getFederate()
	 * @generated
	 */
	public EAttribute getFederate_Description() {
		return (EAttribute)federateEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * Returns the meta object for the reference '{@link org.eodisp.core.gen.repository.Federate#getOwningMm <em>Owning Mm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Owning Mm</em>'.
	 * @see org.eodisp.core.gen.repository.Federate#getOwningMm()
	 * @see #getFederate()
	 * @generated
	 */
	public EReference getFederate_OwningMm() {
		return (EReference)federateEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * Returns the meta object for the reference list '{@link org.eodisp.core.gen.repository.Federate#getTrustedSimManagers <em>Trusted Sim Managers</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Trusted Sim Managers</em>'.
	 * @see org.eodisp.core.gen.repository.Federate#getTrustedSimManagers()
	 * @see #getFederate()
	 * @generated
	 */
	public EReference getFederate_TrustedSimManagers() {
		return (EReference)federateEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * Returns the meta object for the reference '{@link org.eodisp.core.gen.repository.Federate#getSom <em>Som</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Som</em>'.
	 * @see org.eodisp.core.gen.repository.Federate#getSom()
	 * @see #getFederate()
	 * @generated
	 */
	public EReference getFederate_Som() {
		return (EReference)federateEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * Returns the meta object for class '{@link org.eodisp.core.gen.repository.AppOwner <em>App Owner</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>App Owner</em>'.
	 * @see org.eodisp.core.gen.repository.AppOwner
	 * @generated
	 */
	public EClass getAppOwner() {
		return appOwnerEClass;
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.AppOwner#getFirstname <em>Firstname</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Firstname</em>'.
	 * @see org.eodisp.core.gen.repository.AppOwner#getFirstname()
	 * @see #getAppOwner()
	 * @generated
	 */
	public EAttribute getAppOwner_Firstname() {
		return (EAttribute)appOwnerEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.AppOwner#getSurname <em>Surname</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Surname</em>'.
	 * @see org.eodisp.core.gen.repository.AppOwner#getSurname()
	 * @see #getAppOwner()
	 * @generated
	 */
	public EAttribute getAppOwner_Surname() {
		return (EAttribute)appOwnerEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.AppOwner#getMail <em>Mail</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Mail</em>'.
	 * @see org.eodisp.core.gen.repository.AppOwner#getMail()
	 * @see #getAppOwner()
	 * @generated
	 */
	public EAttribute getAppOwner_Mail() {
		return (EAttribute)appOwnerEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.AppOwner#getTel <em>Tel</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Tel</em>'.
	 * @see org.eodisp.core.gen.repository.AppOwner#getTel()
	 * @see #getAppOwner()
	 * @generated
	 */
	public EAttribute getAppOwner_Tel() {
		return (EAttribute)appOwnerEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.AppOwner#getCountry <em>Country</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Country</em>'.
	 * @see org.eodisp.core.gen.repository.AppOwner#getCountry()
	 * @see #getAppOwner()
	 * @generated
	 */
	public EAttribute getAppOwner_Country() {
		return (EAttribute)appOwnerEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.AppOwner#getCustom1 <em>Custom1</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Custom1</em>'.
	 * @see org.eodisp.core.gen.repository.AppOwner#getCustom1()
	 * @see #getAppOwner()
	 * @generated
	 */
	public EAttribute getAppOwner_Custom1() {
		return (EAttribute)appOwnerEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.AppOwner#getCustom2 <em>Custom2</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Custom2</em>'.
	 * @see org.eodisp.core.gen.repository.AppOwner#getCustom2()
	 * @see #getAppOwner()
	 * @generated
	 */
	public EAttribute getAppOwner_Custom2() {
		return (EAttribute)appOwnerEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.AppOwner#getCustom3 <em>Custom3</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Custom3</em>'.
	 * @see org.eodisp.core.gen.repository.AppOwner#getCustom3()
	 * @see #getAppOwner()
	 * @generated
	 */
	public EAttribute getAppOwner_Custom3() {
		return (EAttribute)appOwnerEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * Returns the meta object for class '{@link org.eodisp.core.gen.repository.RemoteLocation <em>Remote Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Remote Location</em>'.
	 * @see org.eodisp.core.gen.repository.RemoteLocation
	 * @generated
	 */
	public EClass getRemoteLocation() {
		return remoteLocationEClass;
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eodisp.core.gen.repository.RemoteLocation#getUri <em>Uri</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Uri</em>'.
	 * @see org.eodisp.core.gen.repository.RemoteLocation#getUri()
	 * @see #getRemoteLocation()
	 * @generated
	 */
	public EAttribute getRemoteLocation_Uri() {
		return (EAttribute)remoteLocationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	public RepositoryFactory getRepositoryFactory() {
		return (RepositoryFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		documentRootEClass = createEClass(DOCUMENT_ROOT);
		createEAttribute(documentRootEClass, DOCUMENT_ROOT__MIXED);
		createEReference(documentRootEClass, DOCUMENT_ROOT__XMLNS_PREFIX_MAP);
		createEReference(documentRootEClass, DOCUMENT_ROOT__XSI_SCHEMA_LOCATION);
		createEReference(documentRootEClass, DOCUMENT_ROOT__REPOSITORY);
		createEAttribute(documentRootEClass, DOCUMENT_ROOT__LOCAL_PATH);

		repositoryEClass = createEClass(REPOSITORY);
		createEAttribute(repositoryEClass, REPOSITORY__NAME);
		createEAttribute(repositoryEClass, REPOSITORY__DESCRIPTION);
		createEReference(repositoryEClass, REPOSITORY__MODEL_MANAGERS);
		createEReference(repositoryEClass, REPOSITORY__SIM_MANAGERS);
		createEReference(repositoryEClass, REPOSITORY__CATEGORIES);
		createEReference(repositoryEClass, REPOSITORY__SOMS);
		createEReference(repositoryEClass, REPOSITORY__FEDERATES);

		modelManagerEClass = createEClass(MODEL_MANAGER);
		createEAttribute(modelManagerEClass, MODEL_MANAGER__NAME);
		createEAttribute(modelManagerEClass, MODEL_MANAGER__ID);
		createEAttribute(modelManagerEClass, MODEL_MANAGER__DESCRIPTION);
		createEReference(modelManagerEClass, MODEL_MANAGER__APP_OWNER);
		createEReference(modelManagerEClass, MODEL_MANAGER__REMOTE_LOCATION);

		simManagerEClass = createEClass(SIM_MANAGER);
		createEAttribute(simManagerEClass, SIM_MANAGER__NAME);
		createEAttribute(simManagerEClass, SIM_MANAGER__ID);
		createEAttribute(simManagerEClass, SIM_MANAGER__DESCRIPTION);
		createEReference(simManagerEClass, SIM_MANAGER__APP_OWNER);
		createEReference(simManagerEClass, SIM_MANAGER__REMOTE_LOCATION);

		categoryEClass = createEClass(CATEGORY);
		createEAttribute(categoryEClass, CATEGORY__ID);
		createEAttribute(categoryEClass, CATEGORY__NAME);
		createEAttribute(categoryEClass, CATEGORY__DESCRIPTION);
		createEAttribute(categoryEClass, CATEGORY__CLOSED);
		createEReference(categoryEClass, CATEGORY__SOMS);

		somEClass = createEClass(SOM);
		createEAttribute(somEClass, SOM__NAME);
		createEAttribute(somEClass, SOM__VERSION);
		createEAttribute(somEClass, SOM__DESCRIPTION);
		createEReference(somEClass, SOM__CATEGORIES);
		createEReference(somEClass, SOM__FEDERATES);
		createEAttribute(somEClass, SOM__LOCAL_PATH);
		createEAttribute(somEClass, SOM__FILE_NAME);

		federateEClass = createEClass(FEDERATE);
		createEAttribute(federateEClass, FEDERATE__ID);
		createEAttribute(federateEClass, FEDERATE__BUNDLE_NAME);
		createEAttribute(federateEClass, FEDERATE__BUNDLE_SYMBOLIC_NAME);
		createEAttribute(federateEClass, FEDERATE__BUNDLE_VERSION);
		createEAttribute(federateEClass, FEDERATE__BUNDLE_DESCRIPTION);
		createEAttribute(federateEClass, FEDERATE__DESCRIPTION);
		createEReference(federateEClass, FEDERATE__OWNING_MM);
		createEReference(federateEClass, FEDERATE__TRUSTED_SIM_MANAGERS);
		createEReference(federateEClass, FEDERATE__SOM);

		appOwnerEClass = createEClass(APP_OWNER);
		createEAttribute(appOwnerEClass, APP_OWNER__FIRSTNAME);
		createEAttribute(appOwnerEClass, APP_OWNER__SURNAME);
		createEAttribute(appOwnerEClass, APP_OWNER__MAIL);
		createEAttribute(appOwnerEClass, APP_OWNER__TEL);
		createEAttribute(appOwnerEClass, APP_OWNER__COUNTRY);
		createEAttribute(appOwnerEClass, APP_OWNER__CUSTOM1);
		createEAttribute(appOwnerEClass, APP_OWNER__CUSTOM2);
		createEAttribute(appOwnerEClass, APP_OWNER__CUSTOM3);

		remoteLocationEClass = createEClass(REMOTE_LOCATION);
		createEAttribute(remoteLocationEClass, REMOTE_LOCATION__URI);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		XMLTypePackage theXMLTypePackage = (XMLTypePackage)EPackage.Registry.INSTANCE.getEPackage(XMLTypePackage.eNS_URI);

		// Add supertypes to classes

		// Initialize classes and features; add operations and parameters
		initEClass(documentRootEClass, DocumentRoot.class, "DocumentRoot", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDocumentRoot_Mixed(), ecorePackage.getEFeatureMapEntry(), "mixed", null, 0, -1, null, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_XMLNSPrefixMap(), ecorePackage.getEStringToStringMapEntry(), null, "xMLNSPrefixMap", null, 0, -1, null, IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_XSISchemaLocation(), ecorePackage.getEStringToStringMapEntry(), null, "xSISchemaLocation", null, 0, -1, null, IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_Repository(), this.getRepository(), null, "repository", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
		initEAttribute(getDocumentRoot_LocalPath(), theXMLTypePackage.getAnyURI(), "localPath", null, 0, 1, null, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(repositoryEClass, Repository.class, "Repository", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getRepository_Name(), theXMLTypePackage.getString(), "name", null, 1, 1, Repository.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRepository_Description(), theXMLTypePackage.getString(), "description", null, 0, 1, Repository.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRepository_ModelManagers(), this.getModelManager(), null, "modelManagers", null, 0, -1, Repository.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRepository_SimManagers(), this.getSimManager(), null, "simManagers", null, 0, -1, Repository.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRepository_Categories(), this.getCategory(), null, "categories", null, 0, -1, Repository.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRepository_Soms(), this.getSOM(), null, "soms", null, 0, -1, Repository.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRepository_Federates(), this.getFederate(), null, "federates", null, 0, -1, Repository.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(modelManagerEClass, ModelManager.class, "ModelManager", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getModelManager_Name(), theXMLTypePackage.getString(), "name", null, 1, 1, ModelManager.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getModelManager_Id(), theXMLTypePackage.getString(), "id", null, 1, 1, ModelManager.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getModelManager_Description(), theXMLTypePackage.getString(), "description", null, 1, 1, ModelManager.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getModelManager_AppOwner(), this.getAppOwner(), null, "appOwner", null, 1, 1, ModelManager.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getModelManager_RemoteLocation(), this.getRemoteLocation(), null, "remoteLocation", null, 1, 1, ModelManager.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(simManagerEClass, SimManager.class, "SimManager", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSimManager_Name(), theXMLTypePackage.getString(), "name", null, 1, 1, SimManager.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSimManager_Id(), theXMLTypePackage.getString(), "id", null, 0, 1, SimManager.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSimManager_Description(), theXMLTypePackage.getString(), "description", null, 1, 1, SimManager.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSimManager_AppOwner(), this.getAppOwner(), null, "appOwner", null, 1, 1, SimManager.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSimManager_RemoteLocation(), this.getRemoteLocation(), null, "remoteLocation", null, 1, 1, SimManager.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(categoryEClass, Category.class, "Category", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCategory_Id(), theXMLTypePackage.getString(), "id", null, 1, 1, Category.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCategory_Name(), theXMLTypePackage.getString(), "name", null, 1, 1, Category.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCategory_Description(), theXMLTypePackage.getString(), "description", null, 1, 1, Category.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCategory_Closed(), theXMLTypePackage.getBooleanObject(), "closed", "false", 0, 1, Category.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCategory_Soms(), this.getSOM(), this.getSOM_Categories(), "soms", null, 0, -1, Category.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(somEClass, org.eodisp.core.gen.repository.SOM.class, "SOM", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSOM_Name(), theXMLTypePackage.getString(), "name", "", 1, 1, org.eodisp.core.gen.repository.SOM.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSOM_Version(), theXMLTypePackage.getString(), "version", null, 0, 1, org.eodisp.core.gen.repository.SOM.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSOM_Description(), theXMLTypePackage.getString(), "description", null, 1, 1, org.eodisp.core.gen.repository.SOM.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSOM_Categories(), this.getCategory(), this.getCategory_Soms(), "categories", null, 0, -1, org.eodisp.core.gen.repository.SOM.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSOM_Federates(), this.getFederate(), this.getFederate_Som(), "federates", "", 0, -1, org.eodisp.core.gen.repository.SOM.class, IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSOM_LocalPath(), theXMLTypePackage.getAnyURI(), "localPath", null, 0, 1, org.eodisp.core.gen.repository.SOM.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSOM_FileName(), theXMLTypePackage.getString(), "fileName", null, 0, 1, org.eodisp.core.gen.repository.SOM.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(federateEClass, Federate.class, "Federate", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getFederate_Id(), theXMLTypePackage.getString(), "id", null, 1, 1, Federate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFederate_BundleName(), theXMLTypePackage.getString(), "BundleName", null, 1, 1, Federate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFederate_BundleSymbolicName(), theXMLTypePackage.getString(), "BundleSymbolicName", null, 0, 1, Federate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFederate_BundleVersion(), theXMLTypePackage.getString(), "BundleVersion", null, 0, 1, Federate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFederate_BundleDescription(), theXMLTypePackage.getString(), "BundleDescription", null, 0, 1, Federate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFederate_Description(), theXMLTypePackage.getString(), "description", null, 1, 1, Federate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFederate_OwningMm(), this.getModelManager(), null, "owningMm", null, 0, 1, Federate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFederate_TrustedSimManagers(), this.getSimManager(), null, "trustedSimManagers", null, 0, -1, Federate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFederate_Som(), this.getSOM(), this.getSOM_Federates(), "som", null, 1, 1, Federate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(appOwnerEClass, AppOwner.class, "AppOwner", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAppOwner_Firstname(), theXMLTypePackage.getString(), "firstname", null, 1, 1, AppOwner.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAppOwner_Surname(), theXMLTypePackage.getString(), "surname", null, 0, 1, AppOwner.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAppOwner_Mail(), theXMLTypePackage.getString(), "mail", null, 0, 1, AppOwner.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAppOwner_Tel(), theXMLTypePackage.getString(), "tel", null, 0, 1, AppOwner.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAppOwner_Country(), theXMLTypePackage.getString(), "country", null, 0, 1, AppOwner.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAppOwner_Custom1(), theXMLTypePackage.getString(), "custom1", null, 0, 1, AppOwner.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAppOwner_Custom2(), theXMLTypePackage.getString(), "custom2", null, 0, 1, AppOwner.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAppOwner_Custom3(), theXMLTypePackage.getString(), "custom3", null, 0, 1, AppOwner.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(remoteLocationEClass, RemoteLocation.class, "RemoteLocation", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getRemoteLocation_Uri(), theXMLTypePackage.getAnyURI(), "uri", null, 1, 1, RemoteLocation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http:///org/eclipse/emf/ecore/util/ExtendedMetaData
		createExtendedMetaDataAnnotations();
		// ExtendedMetaData
		createExtendedMetaData_1Annotations();
	}

	/**
	 * Initializes the annotations for <b>http:///org/eclipse/emf/ecore/util/ExtendedMetaData</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createExtendedMetaDataAnnotations() {
		String source = "http:///org/eclipse/emf/ecore/util/ExtendedMetaData";		
		addAnnotation
		  (documentRootEClass, 
		   source, 
		   new String[] {
			 "name", "",
			 "kind", "mixed"
		   });		
		addAnnotation
		  (getDocumentRoot_Mixed(), 
		   source, 
		   new String[] {
			 "kind", "elementWildcard",
			 "name", ":mixed"
		   });		
		addAnnotation
		  (getDocumentRoot_XMLNSPrefixMap(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "xmlns:prefix"
		   });		
		addAnnotation
		  (getDocumentRoot_XSISchemaLocation(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "xsi:schemaLocation"
		   });		
		addAnnotation
		  (getDocumentRoot_Repository(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "repository",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getDocumentRoot_LocalPath(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "localPath"
		   });		
		addAnnotation
		  (repositoryEClass, 
		   source, 
		   new String[] {
			 "name", "Repository",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getRepository_Name(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "name"
		   });		
		addAnnotation
		  (getRepository_Description(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "description",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getRepository_ModelManagers(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "modelManagers",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getRepository_SimManagers(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "simManagers",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getRepository_Categories(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "categories",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getRepository_Soms(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "soms",
			 "namespace", "##targetNamespace"
		   });			
		addAnnotation
		  (modelManagerEClass, 
		   source, 
		   new String[] {
			 "name", "ModelManager",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getModelManager_Name(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "name"
		   });		
		addAnnotation
		  (getModelManager_Id(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "id"
		   });		
		addAnnotation
		  (getModelManager_Description(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "description",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getModelManager_AppOwner(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "appOwner",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getModelManager_RemoteLocation(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "remoteLocation",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (simManagerEClass, 
		   source, 
		   new String[] {
			 "name", "SimManager",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getSimManager_Name(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "name"
		   });		
		addAnnotation
		  (getSimManager_Id(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "id"
		   });		
		addAnnotation
		  (getSimManager_Description(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "description",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getSimManager_AppOwner(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "appOwner",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getSimManager_RemoteLocation(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "remoteLocation",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (categoryEClass, 
		   source, 
		   new String[] {
			 "name", "Category",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getCategory_Id(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "id"
		   });		
		addAnnotation
		  (getCategory_Name(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "name"
		   });		
		addAnnotation
		  (getCategory_Description(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "description",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getCategory_Closed(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "closed"
		   });		
		addAnnotation
		  (getCategory_Soms(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "soms"
		   });		
		addAnnotation
		  (somEClass, 
		   source, 
		   new String[] {
			 "name", "SOM",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getSOM_Name(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "name"
		   });		
		addAnnotation
		  (getSOM_Version(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "version"
		   });		
		addAnnotation
		  (getSOM_Description(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "description",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getSOM_Categories(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "categories"
		   });		
		addAnnotation
		  (getSOM_Federates(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "federates"
		   });		
		addAnnotation
		  (getSOM_LocalPath(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "localPath"
		   });		
		addAnnotation
		  (getSOM_FileName(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "fileName"
		   });		
		addAnnotation
		  (federateEClass, 
		   source, 
		   new String[] {
			 "name", "Federate",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getFederate_Id(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "id"
		   });		
		addAnnotation
		  (getFederate_BundleName(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "BundleName"
		   });		
		addAnnotation
		  (getFederate_BundleSymbolicName(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "BundleSymbolicName"
		   });		
		addAnnotation
		  (getFederate_BundleVersion(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "BundleVersion"
		   });		
		addAnnotation
		  (getFederate_BundleDescription(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "BundleDescription"
		   });		
		addAnnotation
		  (getFederate_Description(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "description",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getFederate_OwningMm(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "owningMm"
		   });		
		addAnnotation
		  (getFederate_TrustedSimManagers(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "trustedSimManagers"
		   });		
		addAnnotation
		  (getFederate_Som(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "som"
		   });		
		addAnnotation
		  (appOwnerEClass, 
		   source, 
		   new String[] {
			 "name", "AppOwner",
			 "kind", "empty"
		   });		
		addAnnotation
		  (getAppOwner_Firstname(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "firstname"
		   });		
		addAnnotation
		  (getAppOwner_Surname(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "surname"
		   });		
		addAnnotation
		  (getAppOwner_Mail(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "mail"
		   });		
		addAnnotation
		  (getAppOwner_Tel(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "tel"
		   });		
		addAnnotation
		  (getAppOwner_Country(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "country"
		   });		
		addAnnotation
		  (getAppOwner_Custom1(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "custom1"
		   });		
		addAnnotation
		  (getAppOwner_Custom2(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "custom2"
		   });		
		addAnnotation
		  (getAppOwner_Custom3(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "custom3"
		   });		
		addAnnotation
		  (remoteLocationEClass, 
		   source, 
		   new String[] {
			 "name", "RemoteLocation",
			 "kind", "empty"
		   });		
		addAnnotation
		  (getRemoteLocation_Uri(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "uri"
		   });
	}

	/**
	 * Initializes the annotations for <b>ExtendedMetaData</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createExtendedMetaData_1Annotations() {
		String source = "ExtendedMetaData";															
		addAnnotation
		  (getRepository_Federates(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "federates",
			 "namespace", "##targetNamespace"
		   });																																															
	}

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public interface Literals {
		/**
		 * The meta object literal for the '{@link org.eodisp.core.gen.repository.impl.DocumentRootImpl <em>Document Root</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.core.gen.repository.impl.DocumentRootImpl
		 * @see org.eodisp.core.gen.repository.impl.RepositoryPackageImpl#getDocumentRoot()
		 * @generated
		 */
		public static final EClass DOCUMENT_ROOT = eINSTANCE.getDocumentRoot();

		/**
		 * The meta object literal for the '<em><b>Mixed</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute DOCUMENT_ROOT__MIXED = eINSTANCE.getDocumentRoot_Mixed();

		/**
		 * The meta object literal for the '<em><b>XMLNS Prefix Map</b></em>' map feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EReference DOCUMENT_ROOT__XMLNS_PREFIX_MAP = eINSTANCE.getDocumentRoot_XMLNSPrefixMap();

		/**
		 * The meta object literal for the '<em><b>XSI Schema Location</b></em>' map feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EReference DOCUMENT_ROOT__XSI_SCHEMA_LOCATION = eINSTANCE.getDocumentRoot_XSISchemaLocation();

		/**
		 * The meta object literal for the '<em><b>Repository</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EReference DOCUMENT_ROOT__REPOSITORY = eINSTANCE.getDocumentRoot_Repository();

		/**
		 * The meta object literal for the '<em><b>Local Path</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute DOCUMENT_ROOT__LOCAL_PATH = eINSTANCE.getDocumentRoot_LocalPath();

		/**
		 * The meta object literal for the '{@link org.eodisp.core.gen.repository.impl.RepositoryImpl <em>Repository</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.core.gen.repository.impl.RepositoryImpl
		 * @see org.eodisp.core.gen.repository.impl.RepositoryPackageImpl#getRepository()
		 * @generated
		 */
		public static final EClass REPOSITORY = eINSTANCE.getRepository();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute REPOSITORY__NAME = eINSTANCE.getRepository_Name();

		/**
		 * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute REPOSITORY__DESCRIPTION = eINSTANCE.getRepository_Description();

		/**
		 * The meta object literal for the '<em><b>Model Managers</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EReference REPOSITORY__MODEL_MANAGERS = eINSTANCE.getRepository_ModelManagers();

		/**
		 * The meta object literal for the '<em><b>Sim Managers</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EReference REPOSITORY__SIM_MANAGERS = eINSTANCE.getRepository_SimManagers();

		/**
		 * The meta object literal for the '<em><b>Categories</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EReference REPOSITORY__CATEGORIES = eINSTANCE.getRepository_Categories();

		/**
		 * The meta object literal for the '<em><b>Soms</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EReference REPOSITORY__SOMS = eINSTANCE.getRepository_Soms();

		/**
		 * The meta object literal for the '<em><b>Federates</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EReference REPOSITORY__FEDERATES = eINSTANCE.getRepository_Federates();

		/**
		 * The meta object literal for the '{@link org.eodisp.core.gen.repository.impl.ModelManagerImpl <em>Model Manager</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.core.gen.repository.impl.ModelManagerImpl
		 * @see org.eodisp.core.gen.repository.impl.RepositoryPackageImpl#getModelManager()
		 * @generated
		 */
		public static final EClass MODEL_MANAGER = eINSTANCE.getModelManager();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute MODEL_MANAGER__NAME = eINSTANCE.getModelManager_Name();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute MODEL_MANAGER__ID = eINSTANCE.getModelManager_Id();

		/**
		 * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute MODEL_MANAGER__DESCRIPTION = eINSTANCE.getModelManager_Description();

		/**
		 * The meta object literal for the '<em><b>App Owner</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EReference MODEL_MANAGER__APP_OWNER = eINSTANCE.getModelManager_AppOwner();

		/**
		 * The meta object literal for the '<em><b>Remote Location</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EReference MODEL_MANAGER__REMOTE_LOCATION = eINSTANCE.getModelManager_RemoteLocation();

		/**
		 * The meta object literal for the '{@link org.eodisp.core.gen.repository.impl.SimManagerImpl <em>Sim Manager</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.core.gen.repository.impl.SimManagerImpl
		 * @see org.eodisp.core.gen.repository.impl.RepositoryPackageImpl#getSimManager()
		 * @generated
		 */
		public static final EClass SIM_MANAGER = eINSTANCE.getSimManager();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute SIM_MANAGER__NAME = eINSTANCE.getSimManager_Name();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute SIM_MANAGER__ID = eINSTANCE.getSimManager_Id();

		/**
		 * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute SIM_MANAGER__DESCRIPTION = eINSTANCE.getSimManager_Description();

		/**
		 * The meta object literal for the '<em><b>App Owner</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EReference SIM_MANAGER__APP_OWNER = eINSTANCE.getSimManager_AppOwner();

		/**
		 * The meta object literal for the '<em><b>Remote Location</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EReference SIM_MANAGER__REMOTE_LOCATION = eINSTANCE.getSimManager_RemoteLocation();

		/**
		 * The meta object literal for the '{@link org.eodisp.core.gen.repository.impl.CategoryImpl <em>Category</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.core.gen.repository.impl.CategoryImpl
		 * @see org.eodisp.core.gen.repository.impl.RepositoryPackageImpl#getCategory()
		 * @generated
		 */
		public static final EClass CATEGORY = eINSTANCE.getCategory();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute CATEGORY__ID = eINSTANCE.getCategory_Id();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute CATEGORY__NAME = eINSTANCE.getCategory_Name();

		/**
		 * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute CATEGORY__DESCRIPTION = eINSTANCE.getCategory_Description();

		/**
		 * The meta object literal for the '<em><b>Closed</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute CATEGORY__CLOSED = eINSTANCE.getCategory_Closed();

		/**
		 * The meta object literal for the '<em><b>Soms</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EReference CATEGORY__SOMS = eINSTANCE.getCategory_Soms();

		/**
		 * The meta object literal for the '{@link org.eodisp.core.gen.repository.impl.SOMImpl <em>SOM</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.core.gen.repository.impl.SOMImpl
		 * @see org.eodisp.core.gen.repository.impl.RepositoryPackageImpl#getSOM()
		 * @generated
		 */
		public static final EClass SOM = eINSTANCE.getSOM();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute SOM__NAME = eINSTANCE.getSOM_Name();

		/**
		 * The meta object literal for the '<em><b>Version</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute SOM__VERSION = eINSTANCE.getSOM_Version();

		/**
		 * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute SOM__DESCRIPTION = eINSTANCE.getSOM_Description();

		/**
		 * The meta object literal for the '<em><b>Categories</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EReference SOM__CATEGORIES = eINSTANCE.getSOM_Categories();

		/**
		 * The meta object literal for the '<em><b>Federates</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EReference SOM__FEDERATES = eINSTANCE.getSOM_Federates();

		/**
		 * The meta object literal for the '<em><b>Local Path</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute SOM__LOCAL_PATH = eINSTANCE.getSOM_LocalPath();

		/**
		 * The meta object literal for the '<em><b>File Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute SOM__FILE_NAME = eINSTANCE.getSOM_FileName();

		/**
		 * The meta object literal for the '{@link org.eodisp.core.gen.repository.impl.FederateImpl <em>Federate</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.core.gen.repository.impl.FederateImpl
		 * @see org.eodisp.core.gen.repository.impl.RepositoryPackageImpl#getFederate()
		 * @generated
		 */
		public static final EClass FEDERATE = eINSTANCE.getFederate();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute FEDERATE__ID = eINSTANCE.getFederate_Id();

		/**
		 * The meta object literal for the '<em><b>Bundle Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute FEDERATE__BUNDLE_NAME = eINSTANCE.getFederate_BundleName();

		/**
		 * The meta object literal for the '<em><b>Bundle Symbolic Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute FEDERATE__BUNDLE_SYMBOLIC_NAME = eINSTANCE.getFederate_BundleSymbolicName();

		/**
		 * The meta object literal for the '<em><b>Bundle Version</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute FEDERATE__BUNDLE_VERSION = eINSTANCE.getFederate_BundleVersion();

		/**
		 * The meta object literal for the '<em><b>Bundle Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute FEDERATE__BUNDLE_DESCRIPTION = eINSTANCE.getFederate_BundleDescription();

		/**
		 * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute FEDERATE__DESCRIPTION = eINSTANCE.getFederate_Description();

		/**
		 * The meta object literal for the '<em><b>Owning Mm</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EReference FEDERATE__OWNING_MM = eINSTANCE.getFederate_OwningMm();

		/**
		 * The meta object literal for the '<em><b>Trusted Sim Managers</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EReference FEDERATE__TRUSTED_SIM_MANAGERS = eINSTANCE.getFederate_TrustedSimManagers();

		/**
		 * The meta object literal for the '<em><b>Som</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EReference FEDERATE__SOM = eINSTANCE.getFederate_Som();

		/**
		 * The meta object literal for the '{@link org.eodisp.core.gen.repository.impl.AppOwnerImpl <em>App Owner</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.core.gen.repository.impl.AppOwnerImpl
		 * @see org.eodisp.core.gen.repository.impl.RepositoryPackageImpl#getAppOwner()
		 * @generated
		 */
		public static final EClass APP_OWNER = eINSTANCE.getAppOwner();

		/**
		 * The meta object literal for the '<em><b>Firstname</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute APP_OWNER__FIRSTNAME = eINSTANCE.getAppOwner_Firstname();

		/**
		 * The meta object literal for the '<em><b>Surname</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute APP_OWNER__SURNAME = eINSTANCE.getAppOwner_Surname();

		/**
		 * The meta object literal for the '<em><b>Mail</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute APP_OWNER__MAIL = eINSTANCE.getAppOwner_Mail();

		/**
		 * The meta object literal for the '<em><b>Tel</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute APP_OWNER__TEL = eINSTANCE.getAppOwner_Tel();

		/**
		 * The meta object literal for the '<em><b>Country</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute APP_OWNER__COUNTRY = eINSTANCE.getAppOwner_Country();

		/**
		 * The meta object literal for the '<em><b>Custom1</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute APP_OWNER__CUSTOM1 = eINSTANCE.getAppOwner_Custom1();

		/**
		 * The meta object literal for the '<em><b>Custom2</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute APP_OWNER__CUSTOM2 = eINSTANCE.getAppOwner_Custom2();

		/**
		 * The meta object literal for the '<em><b>Custom3</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute APP_OWNER__CUSTOM3 = eINSTANCE.getAppOwner_Custom3();

		/**
		 * The meta object literal for the '{@link org.eodisp.core.gen.repository.impl.RemoteLocationImpl <em>Remote Location</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eodisp.core.gen.repository.impl.RemoteLocationImpl
		 * @see org.eodisp.core.gen.repository.impl.RepositoryPackageImpl#getRemoteLocation()
		 * @generated
		 */
		public static final EClass REMOTE_LOCATION = eINSTANCE.getRemoteLocation();

		/**
		 * The meta object literal for the '<em><b>Uri</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute REMOTE_LOCATION__URI = eINSTANCE.getRemoteLocation_Uri();

	}

} //RepositoryPackageImpl
