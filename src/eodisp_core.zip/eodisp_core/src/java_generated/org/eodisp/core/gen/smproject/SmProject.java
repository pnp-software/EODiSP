/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.core.gen.smproject;

import java.util.List;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sm Project</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.core.gen.smproject.SmProject#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.core.gen.smproject.SmProject#getFederateExecutions <em>Federate Executions</em>}</li>
 *   <li>{@link org.eodisp.core.gen.smproject.SmProject#getExperiments <em>Experiments</em>}</li>
 *   <li>{@link org.eodisp.core.gen.smproject.SmProject#getInitData <em>Init Data</em>}</li>
 * </ul>
 * </p>
 *
 * @model extendedMetaData="name='SmProject' kind='elementOnly'"
 * @generated
 */
public interface SmProject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='attribute' name='name'"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.smproject.SmProject#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Federate Executions</b></em>' containment reference list.
	 * The list contents are of type {@link org.eodisp.core.gen.smproject.FederateExecution}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Federate Executions</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Federate Executions</em>' containment reference list.
	 * @model type="org.eodisp.core.gen.smproject.FederateExecution" containment="true"
	 *        extendedMetaData="kind='element' name='federateExecutions' namespace='##targetNamespace'"
	 * @generated
	 */
	List getFederateExecutions();

	/**
	 * Returns the value of the '<em><b>Experiments</b></em>' containment reference list.
	 * The list contents are of type {@link org.eodisp.core.gen.smproject.Experiment}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Experiments</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Experiments</em>' containment reference list.
	 * @model type="org.eodisp.core.gen.smproject.Experiment" containment="true"
	 *        extendedMetaData="kind='element' name='experiments' namespace='##targetNamespace'"
	 * @generated
	 */
	List getExperiments();

	/**
	 * Returns the value of the '<em><b>Init Data</b></em>' containment reference list.
	 * The list contents are of type {@link org.eodisp.core.gen.smproject.InitData}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Init Data</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Init Data</em>' containment reference list.
	 * @model type="org.eodisp.core.gen.smproject.InitData" containment="true"
	 *        extendedMetaData="kind='element' name='initData' namespace='##targetNamespace'"
	 * @generated
	 */
	List getInitData();

} // SmProject