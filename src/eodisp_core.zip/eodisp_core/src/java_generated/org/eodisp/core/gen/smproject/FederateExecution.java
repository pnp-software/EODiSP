/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.core.gen.smproject;

import java.util.List;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Federate Execution</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.core.gen.smproject.FederateExecution#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.core.gen.smproject.FederateExecution#getRemoteId <em>Remote Id</em>}</li>
 *   <li>{@link org.eodisp.core.gen.smproject.FederateExecution#getInitData <em>Init Data</em>}</li>
 * </ul>
 * </p>
 *
 * @model extendedMetaData="name='FederateExecution' kind='empty'"
 * @generated
 */
public interface FederateExecution {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='attribute' name='name'"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.smproject.FederateExecution#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Remote Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Remote Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Remote Id</em>' attribute.
	 * @see #setRemoteId(String)
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.ID" required="true"
	 *        extendedMetaData="kind='attribute' name='remoteId'"
	 * @generated
	 */
	String getRemoteId();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.smproject.FederateExecution#getRemoteId <em>Remote Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Remote Id</em>' attribute.
	 * @see #getRemoteId()
	 * @generated
	 */
	void setRemoteId(String value);

	/**
	 * Returns the value of the '<em><b>Init Data</b></em>' reference list.
	 * The list contents are of type {@link org.eodisp.core.gen.smproject.InitData}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Init Data</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Init Data</em>' reference list.
	 * @model type="org.eodisp.core.gen.smproject.InitData"
	 *        extendedMetaData="kind='attribute' name='initData'"
	 * @generated
	 */
	List getInitData();

} // FederateExecution