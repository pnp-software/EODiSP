/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eodisp.core.gen.repository;

import java.util.List;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SOM</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eodisp.core.gen.repository.SOM#getName <em>Name</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.SOM#getVersion <em>Version</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.SOM#getDescription <em>Description</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.SOM#getCategories <em>Categories</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.SOM#getFederates <em>Federates</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.SOM#getLocalPath <em>Local Path</em>}</li>
 *   <li>{@link org.eodisp.core.gen.repository.SOM#getFileName <em>File Name</em>}</li>
 * </ul>
 * </p>
 *
 * @model extendedMetaData="name='SOM' kind='elementOnly'"
 * @generated
 */
public interface SOM {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * The default value is <code>""</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @model default="" unique="false" dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='attribute' name='name'"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.repository.SOM#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Version</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Version</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Version</em>' attribute.
	 * @see #setVersion(String)
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 *        extendedMetaData="kind='attribute' name='version'"
	 * @generated
	 */
	String getVersion();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.repository.SOM#getVersion <em>Version</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Version</em>' attribute.
	 * @see #getVersion()
	 * @generated
	 */
	void setVersion(String value);

	/**
	 * Returns the value of the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Description</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Description</em>' attribute.
	 * @see #setDescription(String)
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='element' name='description' namespace='##targetNamespace'"
	 * @generated
	 */
	String getDescription();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.repository.SOM#getDescription <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Description</em>' attribute.
	 * @see #getDescription()
	 * @generated
	 */
	void setDescription(String value);

	/**
	 * Returns the value of the '<em><b>Categories</b></em>' reference list.
	 * The list contents are of type {@link org.eodisp.core.gen.repository.Category}.
	 * It is bidirectional and its opposite is '{@link org.eodisp.core.gen.repository.Category#getSoms <em>Soms</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Categories</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Categories</em>' reference list.
	 * @see org.eodisp.core.gen.repository.Category#getSoms
	 * @model type="org.eodisp.core.gen.repository.Category" opposite="soms"
	 *        extendedMetaData="kind='attribute' name='categories'"
	 * @generated
	 */
	List getCategories();

	/**
	 * Returns the value of the '<em><b>Federates</b></em>' reference list.
	 * The list contents are of type {@link org.eodisp.core.gen.repository.Federate}.
	 * It is bidirectional and its opposite is '{@link org.eodisp.core.gen.repository.Federate#getSom <em>Som</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Federates</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Federates</em>' reference list.
	 * @see org.eodisp.core.gen.repository.Federate#getSom
	 * @model type="org.eodisp.core.gen.repository.Federate" opposite="som" transient="true"
	 *        extendedMetaData="kind='attribute' name='federates'"
	 * @generated
	 */
	List getFederates();

	/**
	 * Returns the value of the '<em><b>Local Path</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Local Path</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Local Path</em>' attribute.
	 * @see #setLocalPath(String)
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.AnyURI"
	 *        extendedMetaData="kind='attribute' name='localPath'"
	 * @generated
	 */
	String getLocalPath();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.repository.SOM#getLocalPath <em>Local Path</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Local Path</em>' attribute.
	 * @see #getLocalPath()
	 * @generated
	 */
	void setLocalPath(String value);

	/**
	 * Returns the value of the '<em><b>File Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>File Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>File Name</em>' attribute.
	 * @see #setFileName(String)
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
	 *        extendedMetaData="kind='attribute' name='fileName'"
	 * @generated
	 */
	String getFileName();

	/**
	 * Sets the value of the '{@link org.eodisp.core.gen.repository.SOM#getFileName <em>File Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>File Name</em>' attribute.
	 * @see #getFileName()
	 * @generated
	 */
	void setFileName(String value);

} // SOM