/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.mm.application;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.rmi.registry.Registry;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.eodisp.core.common.ModelManagerRemote;
import org.eodisp.core.common.ReposModelService;
import org.eodisp.core.common.ReposServiceProxy;
import org.eodisp.core.gen.repository.impl.RepositoryPackageImpl;
import org.eodisp.core.mm.config.MmConfiguration;
import org.eodisp.core.mm.service.MmCoreServiceProxy;
import org.eodisp.core.mm.service.MmFederateProcessManager;
import org.eodisp.core.mm.service.ModelManagerRemoteImpl;
import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.util.AppModule;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.RootApp;

/**
 * Application module to startup the model manager core.
 * 
 * @author ibirrer
 * @version $Id:$
 */
public class MmAppModuleCore implements AppModule {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(MmAppModuleCore.class);

	/**
	 * The Id of this Application Module.
	 */
	public static final String ID = MmAppModuleCore.class.getName();

	private final MmCoreServiceProxy mmCoreServiceProxy = new MmCoreServiceProxy();

	private ReposServiceProxy reposServiceProxy = null;

	/**
	 * The name of the configuration file for the model manager application
	 * proper.
	 */
	private static final String CONFIG_FILE_MAIN = "mm_core.conf";

	private ReposModelService reposService;

	private final MmFederateProcessManager federateProcessManager = new MmFederateProcessManager();

	/**
	 * {@inheritDoc}
	 */
	public String getId() {
		return ID;
	}

	/**
	 * {@inheritDoc}
	 */
	public void registerConfiguration(RootApp rootApp) throws Exception {
		File configFileMain = new File(rootApp.getConfigurationDir(), CONFIG_FILE_MAIN);
		MmConfiguration modelManagerConfiguration = new MmConfiguration(configFileMain);

		// register configurations
		rootApp.registerConfiguration(modelManagerConfiguration);
	}

	/**
	 * {@inheritDoc}
	 */
	public void preStartup(RootApp rootApp) throws Exception {
		// init emf for the repository service
		RepositoryPackageImpl.eINSTANCE.getName();

		ensureAppId();

		File federatesDir = ((MmConfiguration) AppRegistry.getRootApp().getConfiguration(MmConfiguration.ID))
				.getFederateDir();
		federateProcessManager.readFederates(federatesDir);
	}

	/**
	 * {@inheritDoc}
	 */
	public void startup(RootApp rootApp) throws Exception {
		if (getMmConfiguration().isRemoteTestSupport()) {
			logger.warn("Remote administration enabled for model manager. "
					+ "Make sure you only turn this on for debug and testing purposes.");
			Registry registry = getRemoteAppModule().getRegistry();
		}

		if (!getMmConfiguration().isCheckPermissions()) {
			logger.warn("Permission check is disabled. This allows all simulation managers"
					+ "to use your models without restriction.");
		}
		ModelManagerRemote modelManagerRemote = new ModelManagerRemoteImpl();
		getRemoteAppModule().exportAndRegister(modelManagerRemote, ModelManagerRemote.REGISTRY_NAME);
	}

	/**
	 * {@inheritDoc}
	 */
	public void shutdown(RootApp rootApp) throws Exception {
		federateProcessManager.cancelAll();
	}

	/**
	 * {@inheritDoc}
	 */
	public void postShutdown(RootApp rootApp) throws Exception {
		// TODO Auto-generated method stub

	}

	/**
	 * Returns a reference to the repository service or null, if it is not
	 * connected. It is your job to connect to the repository.
	 * 
	 * @return A reference to the repository service or null.
	 */
	public ReposModelService getReposService() {
		return reposService;
	}

	/**
	 * Returns the process manager for the model manager.
	 * 
	 * @return The process manager for the model manager.
	 */
	public MmFederateProcessManager getFederateProcessManager() {
		return federateProcessManager;
	}

	/**
	 * Sets the reference to the repository service. It can then be retrieved
	 * from here by the whole application.
	 * 
	 * @param service
	 *            The reference to the repository service.
	 */
	public void setReposService(ReposModelService service) {
		reposService = service;
	}

	/**
	 * Returns the configuration for the model manager. This is just a
	 * convenient method.
	 * 
	 * @return The configuration for the model manager.
	 */
	private MmConfiguration getMmConfiguration() {
		return (MmConfiguration) AppRegistry.getRootApp().getConfiguration(MmConfiguration.ID);
	}

	/**
	 * Returns the remote application module for the model manager. This is just
	 * a convenient method.
	 * 
	 * @return The remote application module for the model manager.
	 */
	private RemoteAppModule getRemoteAppModule() {
		return (RemoteAppModule) AppRegistry.getRootApp().getAppModule(RemoteAppModule.ID);
	}

	public ReposServiceProxy getReposServiceProxy() {
		if (reposServiceProxy == null) {
			if (getMmCoreServiceProxy().isReposConnected()) {
				ReposModelService service = ((MmAppModuleCore) AppRegistry.getRootApp()
						.getAppModule(MmAppModuleCore.ID)).getReposService();
				if (service != null) {
					reposServiceProxy = new ReposServiceProxy(service);
				}
			}
		}

		return reposServiceProxy;
	}

	public MmCoreServiceProxy getMmCoreServiceProxy() {
		return mmCoreServiceProxy;
	}

	/**
	 * This ensures that this application has a valid application id.
	 */
	private void ensureAppId() {
		
		// check id
		String appId = getMmConfiguration().getEntry(MmConfiguration.APP_ID).getValue();
		if (appId == null || appId.equals("")) {
			appId = UUID.randomUUID().toString();
			getMmConfiguration().getEntry(MmConfiguration.APP_ID).setValue(appId);
		}
		
		// check name
		String appName = getMmConfiguration().getEntry(MmConfiguration.APP_NAME).getValue();
		if (appName == null || appName.equals("")) {
			InetAddress addr;
			try {
				addr = InetAddress.getLocalHost();
				appName = addr.getHostName();
			} catch (UnknownHostException e) {
				appName = "Model Manager";
			}

			getMmConfiguration().getEntry(MmConfiguration.APP_NAME).setValue(appName);
		}

		try {
			getMmConfiguration().save();
		} catch (IOException e) {
			logger.error("Could not write the configuration file. "
					+ "This is serious, because the application won't have a unique Id. "
					+ "Such an Id is needed to communicate with the repository.");
		}
	}
}
