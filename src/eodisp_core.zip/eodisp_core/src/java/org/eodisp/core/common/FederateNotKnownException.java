/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.common;

/**
 * Thrown to indicate that a federate specified by a federateId (UUID) is not
 * known.
 * 
 * @author ibirrer
 * @version $Id:$
 */
public class FederateNotKnownException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * {@inheritDoc}
	 */
	public FederateNotKnownException() {
		super();
	}

	/**
	 * {@inheritDoc}
	 */
	public FederateNotKnownException(String message) {
		super(message);
	}

	/**
	 * {@inheritDoc}
	 */
	public FederateNotKnownException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * {@inheritDoc}
	 */
	public FederateNotKnownException(Throwable cause) {
		super(cause);
	}

}
