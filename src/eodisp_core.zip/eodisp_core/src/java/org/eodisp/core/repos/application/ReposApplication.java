/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.repos.application;

import java.io.File;

import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.remote.launcher.server.application.RootAppStartedCallbackAppModule;
import org.eodisp.util.RootApp;

/**
 * @author eglimi
 * @version $Id:$
 * 
 */
public class ReposApplication extends RootApp {

	

	/**
	 * The name of the application. This is shown on the command line.
	 */
	private static final String APP_NAME = "Model Repository";
	
	private static final String APP_DESCRIPTION = "EODiSP Model Repository";

	/**
	 * The complete path of the default working directory of the model
	 * repository application, this is:
	 * <code>{user.home}/.eodisp/model_repository</code>
	 */
	public static final File DEFAULT_WORKING_DIR = new File(
			new File(System.getProperty("user.home"), ".eodisp"),
			"model_repository");

	/**
	 * The main class of the model repository application.
	 */
	private static final Class REPOS_MAIN_CLASS = ReposMain.class;

	private static final int DEFAULT_TCP_PORT = 14242;

	/**
	 * Default constructor. Calls the super constructor with the name and
	 * working directory of the current application.
	 * 
	 */
	public ReposApplication() {
		super(APP_NAME, APP_DESCRIPTION, DEFAULT_WORKING_DIR, REPOS_MAIN_CLASS);
				
		RemoteAppModule remoteAppModule = new RemoteAppModule(DEFAULT_TCP_PORT);
		registerAppModule(remoteAppModule);

		// Create the modules and register them in the root application.
		ReposAppModule reposModule = new ReposAppModule();
		registerAppModule(reposModule);
		
		registerAppModule(new RootAppStartedCallbackAppModule());
	}
}
