/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.sm.service;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.util.*;

import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eodisp.core.common.*;
import org.eodisp.core.gen.repository.impl.RepositoryPackageImpl;
import org.eodisp.core.gen.smproject.impl.SmprojectPackageImpl;
import org.eodisp.core.sm.application.SmAppModuleCore;
import org.eodisp.core.sm.helper.SmEmfHelper;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.FileUtil;

import commonj.sdo.DataObject;

/**
 * @author eglimi
 * @version $Id:$
 */
final class AcquiredExperiment {

	private final EDataObject experiment;

	private final String experimentName;

	private final List<FederationExecution> federationExecutions = new ArrayList<FederationExecution>();

	AcquiredExperiment(EDataObject experiment) throws ExperimentAcquireException {
		// this.experiment = (ExperimentImpl) EcoreUtil.copy(experiment);
		this.experiment = experiment;

		experimentName = this.experiment.getString(SmprojectPackageImpl.EXPERIMENT__NAME);

		List<EDataObject> fexs = SmEmfHelper.findAllFederationExecutionsForExperiment(this.experiment);
		for (EDataObject fex : fexs) {
			String name = fex.getString(SmprojectPackageImpl.FEDERATION_EXECUTION__NAME);
			federationExecutions.add(new FederationExecution(name, fex));
		}
	}

	boolean compareExperiment(EDataObject other) {
		return EcoreUtil.equals(experiment, other);
	}

	List<FederationExecution> getFederations() {
		return Collections.unmodifiableList(federationExecutions);
	}

	List<Federate> getAllFederates() {
		List<Federate> tmpList = new ArrayList<Federate>();

		for (FederationExecution federationExecution : federationExecutions) {
			tmpList.addAll(federationExecution.getFederates());
		}

		return Collections.unmodifiableList(tmpList);
	}

	/**
	 * @return Returns the experimentName.
	 */
	String getExperimentName() {
		return experimentName;
	}

	@Override
	public String toString() {
		return experimentName;
	}

	class FederationExecution {
		private final List<Federate> federates = new ArrayList<Federate>();

		private final String name;

		private final String uniqueName;

		private URI fomUri;

		private final EDataObject federationExecution;

		@SuppressWarnings("unchecked")
		public FederationExecution(String name, EDataObject federationExecution) throws ExperimentAcquireException {
			this.name = name;
			this.uniqueName = name + "_" + UUID.randomUUID();
			this.federationExecution = federationExecution;

			ReposServiceProxy service = ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(SmAppModuleCore.ID))
					.getReposServiceProxy();
			if (service != null) {

				List<DataObject> sdoFederates = SmEmfHelper.findAllFederatesForFederationExecution(federationExecution);

				for (DataObject federate : sdoFederates) {
					String federateName = federate.getString(SmprojectPackageImpl.FEDERATE_EXECUTION__NAME);
					String federateId = federate.getString(SmprojectPackageImpl.FEDERATE_EXECUTION__REMOTE_ID);

					DataObject reposFed = SmEmfHelper.findReposFederate(service.getRootObject(), federate);

					if (reposFed == null) {
						final String message = String
								.format(
										"The federate with name: %s\n and id: %s\n could not be found in the repository. It might have been deleted or changed.",
										federateName, federateId);
						throw new ExperimentAcquireException(message);
					}

					String bundleId = reposFed.getString(RepositoryPackageImpl.FEDERATE__BUNDLE_SYMBOLIC_NAME);
					String bundleVersion = reposFed.getString(RepositoryPackageImpl.FEDERATE__BUNDLE_VERSION);

					// get model manager for federate
					DataObject sdoModelManager = reposFed.getDataObject(RepositoryPackageImpl.FEDERATE__OWNING_MM);

					// get som for federate
					DataObject sdoSom = reposFed.getDataObject(RepositoryPackageImpl.FEDERATE__SOM);

					if (sdoModelManager == null) {
						final String message = String.format(
								"The model manager for the federate \n %s \ncould not be found in the repository.",
								SmEmfHelper.getName(federate));
						throw new ExperimentAcquireException(message);
					}

					if (sdoSom == null) {
						final String message = String
								.format(
										"The simulation object mode (SOM) for the federate \n %s \ncould not be found in the repository.",
										SmEmfHelper.getName(federate));
						throw new ExperimentAcquireException(message);
					}

					String somId = sdoSom.getString(RepositoryPackageImpl.SOM__NAME);
					String somVersion = sdoSom.getString(RepositoryPackageImpl.SOM__VERSION);

					// remote location
					DataObject rl = sdoModelManager.getDataObject(RepositoryPackageImpl.MODEL_MANAGER__REMOTE_LOCATION);
					String remoteLocation = rl.getString(RepositoryPackageImpl.REMOTE_LOCATION__URI);

					// get the file
					SomFile somFile;
					try {
						somFile = service.getSom(somId, somVersion);
					} catch (Exception e) {
						final String message = String.format("The SOM file could not be retrieved for federate \n %s",
								SmEmfHelper.getName(federate));
						throw new ExperimentAcquireException(message, e);
					}

					// get the initdata
					List<DataObject> initDatas = federate.getList(SmprojectPackageImpl.FEDERATE_EXECUTION__INIT_DATA);
					FileInitData[] fileInitData = new FileInitData[initDatas.size()];
					for (int i = 0; i < initDatas.size(); i++) {
						String localPath = initDatas.get(i).getString(SmprojectPackageImpl.INIT_DATA__LOCAL_PATH);

						File initFile = new File(localPath);

						byte[] initDataBytes;
						try {
							initDataBytes = FileUtil.loadFileToByteArray(initFile);
						} catch (IOException e) {
							String message = "Could not load init data from file:\n" + initFile.getPath();
							throw new ExperimentAcquireException(message, e);
						}

						fileInitData[i] = new FileInitData(initDataBytes, initFile.getName());
					}

					// create new federate with all information
					federates.add(new Federate(bundleId, bundleVersion, remoteLocation, somId, somVersion, somFile,
							fileInitData));
				}
			}
		}

		/**
		 * @return Returns the federates.
		 */
		List<Federate> getFederates() {
			return Collections.unmodifiableList(federates);
		}

		/**
		 * @return Returns the name.
		 */
		String getName() {
			return name;
		}

		String getUniqueName() {
			return uniqueName;
		}

		/**
		 * @return Returns the fomUri.
		 */
		URI getFomUri() {
			return fomUri;
		}

		/**
		 * @param fomUri
		 *            The fomUri to set.
		 */
		void setFomUri(URI fomUri) {
			this.fomUri = fomUri;
		}

		/**
		 * @return Returns the federationExecution.
		 */
		EDataObject getFederationExecution() {
			return (EDataObject) EcoreUtil.copy(federationExecution);
		}
	}

	static class Federate {
		private final String bundleId;

		private final String bundleVersion;

		private final String remoteLocation;

		private final String somId;

		private final String somVersion;

		private final SomFile somFile;

		private FederateProcessHandle handle;

		private final FileInitData[] initData;

		private ModelManagerRemote remoteService = null;

		/**
		 * @return Returns the remoteService.
		 */
		ModelManagerRemote getRemoteService() {
			return remoteService;
		}

		/**
		 * @param remoteService
		 *            The remoteService to set.
		 */
		void setRemoteService(ModelManagerRemote remoteService) {
			this.remoteService = remoteService;
		}

		/**
		 * @param bundleId
		 * @param bundleVersion
		 * @param remoteId
		 * @param somId
		 * @param somVersion
		 */
		Federate(String bundleId, String bundleVersion, String remoteLocation, String somId, String somVersion,
				SomFile somFile, FileInitData[] initData) {
			this.bundleId = bundleId;
			this.bundleVersion = bundleVersion;
			this.remoteLocation = remoteLocation;
			this.somId = somId;
			this.somVersion = somVersion;
			this.somFile = somFile;
			this.initData = initData;
		}

		/**
		 * @return Returns the federateId.
		 */
		String getBundleId() {
			return bundleId;
		}

		/**
		 * @return Returns the federateVersion.
		 */
		String getBundleVersion() {
			return bundleVersion;
		}

		/**
		 * @return Returns the remoteId.
		 */
		String getRemoteLocation() {
			return remoteLocation;
		}

		/**
		 * @return Returns the somId.
		 */
		String getSomId() {
			return somId;
		}

		/**
		 * @return Returns the somVersion.
		 */
		String getSomVersion() {
			return somVersion;
		}

		synchronized FederateProcessHandle getHandle() {
			return handle;
		}

		synchronized void setHandle(FederateProcessHandle handle) {
			this.handle = handle;
		}

		/**
		 * @return Returns the somFile.
		 */
		byte[] getSomData() {
			int length = somFile.getFileData().length;
			byte[] copy = new byte[length];
			System.arraycopy(somFile.getFileData(), 0, copy, 0, length);

			return copy;
		}

		/**
		 * @return Returns the somFile.
		 */
		FileInitData[] getInitData() {
			int length = initData.length;
			FileInitData[] copy = new FileInitData[length];
			System.arraycopy(initData, 0, copy, 0, length);

			return copy;
		}
	}

}
