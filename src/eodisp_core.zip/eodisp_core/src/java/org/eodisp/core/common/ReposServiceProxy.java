/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.common;

import java.io.*;
import java.rmi.RemoteException;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.sdo.EChangeSummary;
import org.eclipse.emf.ecore.sdo.EDataGraph;
import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eclipse.emf.ecore.sdo.util.SDOUtil;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eodisp.core.gen.repository.impl.RepositoryPackageImpl;
import org.eodisp.core.gen.smproject.impl.SmprojectPackageImpl;

import commonj.sdo.DataGraph;

/**
 * @author eglimi
 * @version $Id:$
 */
public class ReposServiceProxy {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(ReposServiceProxy.class);

	/**
	 * Contains the options for loading and saving the data graph.
	 */
	private final HashMap options = new HashMap();

	private final ReposModelService reposService;

	private EDataGraph reposDg = null;

	private boolean isScheduledForReload = false;

	public ReposServiceProxy(ReposModelService reposService) {
		this.reposService = reposService;

		// Set a few options for the XML resources
		options.put(XMLResource.OPTION_ENCODING, "UTF-8");
		options.put(XMLResource.OPTION_USE_DEPRECATED_METHODS, Boolean.TRUE);
	}

	public EDataObject getRootObject() throws IllegalStateException {
		if (reposDg != null && !isScheduledForReload) {
			return findRepository(reposDg);
		}

		final String message = "The root object of the repository has been requested, but it cannot be served because it is either null or is scheduled for reload.\n You must load the data manually";
		throw new IllegalStateException(message);
	}

	private EDataObject findRepository(DataGraph reposDg) {
		return (EDataObject) reposDg.getRootObject().getDataObject(RepositoryPackageImpl.DOCUMENT_ROOT__REPOSITORY);
	}

	public void load() throws IOException {

		EDataGraph tmpDg = reposService.getAllData();

		reposDg = copyDg(tmpDg);

		// start logging.
		if (!((EChangeSummary) reposDg.getChangeSummary()).isLogging()) {
			((EChangeSummary) reposDg.getChangeSummary()).beginLogging();
		}

		setScheduledForReload(false);
	}

	/**
	 * Saves the changes made to the data graph. This method does two things
	 * <ol>
	 * <li>Makes a copy of the original data graph and sends this copy to the
	 * real service that will handle the save to the persistent storage</li>
	 * <li>If the save was successful, it applies the changes on the original
	 * (local) data graph as well.</li>
	 * <ol>
	 * The advantage of this procedure is its simplicity, because no reload of
	 * the data is necessary. This is useful especially for the trees that
	 * display this data in order to not reload the whole tree. It should work
	 * most of the time since it is not expected that multiple applications
	 * share the same project data. Therefore, the data in the local data graph
	 * should be the same as the data in the remote data graph.
	 * <p>
	 * Reloading the data from the persistent storage must therefore be handled
	 * separately.
	 */
	public void save() throws IOException {
		if (isDirty()) {
			EDataGraph copyDg = createChangeDg(reposDg);

			reposService.update(copyDg);

			// if ok, apply the changes here as well.
			if (reposDg.getChangeSummary().isLogging()) {
				reposDg.getChangeSummary().endLogging();
			}

			if (isDirty()) {
				((EChangeSummary) reposDg.getChangeSummary()).applyAndReverse();
				((EChangeSummary) reposDg.getChangeSummary()).apply();
			}

			reposDg.getChangeSummary().beginLogging();
		}
	}

	/**
	 * Checks if there are some changes to be saved.
	 * 
	 * @return True, if there are changes, otherwise false.
	 */
	public boolean isDirty() {
		if (reposDg != null) {
			return reposDg.getChangeSummary().getChangedDataObjects().size() > 0 ? true : false;
		}

		return false;
	}

	/**
	 * Creates a copy of the given data graph and prepares the changes summary
	 * to be transferred in order to apply the changes to the persistent store.
	 * 
	 * @param dg
	 *            The data graph to be copied.
	 * @return The copy of the data graph or null, if it cannot be copied.
	 * @throws IOException
	 */
	private EDataGraph createChangeDg(EDataGraph origDg) throws IOException {
		EDataGraph copyDg = copyDg(origDg);

		// stop logging
		if (copyDg.getChangeSummary().isLogging()) {
			((EChangeSummary) copyDg.getChangeSummary()).endLogging();
		}

		// reverse the changes to get the forward change (needed by the server)
		boolean hasChanges = ((EChangeSummary) copyDg.getChangeSummary()).getChangedDataObjects().size() > 0 ? true
				: false;
		if (hasChanges) {
			((EChangeSummary) copyDg.getChangeSummary()).applyAndReverse();
		}

		return copyDg;
	}

	/**
	 * Creates an copy of the given data graph.
	 * 
	 * @param origDg
	 *            The data graph to be copied.
	 * @return The copy of the data graph or null if it cannot be copied.
	 */
	private EDataGraph copyDg(EDataGraph origDg) throws IOException {
		ByteArrayOutputStream buf = new ByteArrayOutputStream();

		ResourceSet resourceSet = SDOUtil.createResourceSet();
		resourceSet.getPackageRegistry().put(SmprojectPackageImpl.eNS_URI, SmprojectPackageImpl.eINSTANCE);
		Resource resource = resourceSet.createResource(URI.createURI("repos.datagraph"));

		origDg.getDataGraphResource().save(buf, options);
		resource.load(new ByteArrayInputStream(buf.toByteArray()), options);

		return (EDataGraph) resource.getContents().get(0);
	}

	// below are the methods we just delegate

	public String addSom(String somName, String somVersion, String somDescription, File somFile)
			throws RemoteException, IllegalArgumentException, IOException {

		if (somName.equals("") || somVersion.equals("") || somDescription.equals("") || somFile == null) {
			throw new IllegalArgumentException(
					"not all parameters has been specified.\nPlease ensure that no parameter is empty or null.\nThe following parameters have been given:\nsomName: "
							+ somName
							+ "\nsomVersion: "
							+ somVersion
							+ "\nsomDescription: "
							+ somDescription
							+ "\nsomFile: " + somFile);
		}

		final long length = somFile.length();
		if (length > Integer.MAX_VALUE) {
			throw new IllegalArgumentException("The SOM file you want to store is too large. The maximum size is "
					+ Integer.MAX_VALUE + " bytes, but your file is " + somFile.length());
		}

		byte[] buf = new byte[(int) length];
		FileInputStream in = new FileInputStream(somFile);
		in.read(buf);
		in.close();

		SomFile sf = new SomFile(somName, somVersion, somFile.getName(), buf);
		return reposService.addSom(sf);
	}

	public SomFile getSom(String somName, String somVersion) throws RemoteException, SomNotKnownException, IOException {
		return reposService.getSom(somName, somVersion);
	}

	public void deleteSom(String somName, String somVersion) throws RemoteException, SomNotKnownException {
		reposService.deleteSom(somName, somVersion);
	}

	/**
	 * @return Returns the isScheduledForReload.
	 */
	public boolean isScheduledForReload() {
		return isScheduledForReload;
	}

	/**
	 * @param isScheduledForReload
	 *            The isScheduledForReload to set.
	 */
	public void setScheduledForReload(boolean isScheduledForReload) {
		this.isScheduledForReload = isScheduledForReload;
	}
}
