/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005,2006  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.sm.control;

import static java.util.concurrent.TimeUnit.SECONDS;
import static org.eodisp.wrapper.hla.FederationState.ERROR;
import static org.eodisp.wrapper.hla.FederationState.PAUSING;
import static org.eodisp.wrapper.hla.FederationState.RESUMING;
import static org.eodisp.wrapper.hla.FederationState.STEPPING;
import hla.rti1516.*;
import hla.rti1516.jlc.NullFederateAmbassador;
import hla.rti1516.jlc.RtiFactory;
import hla.rti1516.jlc.RtiFactoryFactory;

import java.net.URL;
import java.rmi.RemoteException;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import net.jcip.annotations.GuardedBy;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eodisp.core.sm.control.proxies.ControlFederate;
import org.eodisp.core.sm.control.proxies.ControlFederateInteractionListener;
import org.eodisp.wrapper.hla.FederationState;
import org.eodisp.wrapper.hla.FederationSynchronizationException;
import org.eodisp.wrapper.hla.SynchronizationPointRegistrationException;
import static org.eodisp.wrapper.hla.FederationState.*;

/**
 * @author ibirrer
 */
public class ControlFederateRemoteImpl extends NullFederateAmbassador implements ControlFederateRemote,
		ControlFederateInteractionListener, FederateAmbassador {
	private static final String EODISP_PAUSE = "EODISP_PAUSE";

	private static final String EODISP_RESUME = "EODISP_RESUME";

	private static final String EODISP_STEP = "EODISP_STEP";

	private static final String EODISP_INIT = "EODISP_INIT";

	private static final String EODISP_START = "EODISP_START";

	private static final String EODISP_STOP = "EODISP_STOP";

	private static final byte[] NULL_BYTE = new byte[0];

	private static final int SYNC_POINT_REG_TIMEOUT = 30;

	private final String stateLock = "controlStateLock";

	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	private final static Logger logger = Logger.getLogger(ControlFederateRemoteImpl.class);

	@GuardedBy(stateLock)
	private volatile FederationState state;

	private final CountDownLatch federateRegisterLatch;

	@GuardedBy("this")
	private RTIambassador rtiAmbassador;

	private final CopyOnWriteArrayList<FederateHandle> registeredFederateHandles = new CopyOnWriteArrayList<FederateHandle>();

	private final CopyOnWriteArrayList<ControlFederateListenerRemote> listeners = new CopyOnWriteArrayList<ControlFederateListenerRemote>();

	private final URL fdd;

	private final String federationExecutionName;

	@GuardedBy("this")
	private ControlFederate controlFederate;

	private FederateHandleSet synchronizationSet;

	private final String rtiFactoryClass;

	public void addFederationStateListener(ControlFederateListenerRemote federationStateListener)
			throws RemoteException {
		listeners.add(federationStateListener);
	}

	public FederationState getState() throws RemoteException {
		synchronized (stateLock) {
			return state;
		}
	}

	/**
	 * @param federationExecutionName
	 * @param fdd
	 *            The URL of the
	 * @param participatingEodispFederates
	 * @param rtiFactoryClass
	 *            The fully qualified name of the {@link RtiFactory}
	 *            implementation class. Can be <code>null</code> to use the
	 *            standard factory class of the first RTI in the classpath.
	 */
	public ControlFederateRemoteImpl(String federationExecutionName, URL fdd, int participatingEodispFederates,
			String rtiFactoryClass) {
		federateRegisterLatch = new CountDownLatch(participatingEodispFederates);
		state = FederationState.NOT_INITIALIZED;
		this.fdd = fdd;
		this.federationExecutionName = federationExecutionName;
		this.rtiFactoryClass = rtiFactoryClass;
	}

	private void setState(FederationState newState) {
		synchronized (stateLock) {
			if (!state.isStateChangeAllowed(newState)) {
				throw new IllegalStateException(String.format("Cannot change to state %s if in state %s", newState,
						state));
			}

			this.state = newState;
			logger.info("Control Federate changed state to: " + state);
			final FederationState finalState = newState;
			// Thread t = new Thread() {
			// @Override
			// public void run() {
			for (ControlFederateListenerRemote listener : listeners) {
				try {
					listener.stateChanged(finalState);
				} catch (RemoteException e) {
					logger.error("Remote exception during callback to ControlFederateListenerRemote", e);
				}
			}
			// }
			// };
			// t.start();
		}
	}

	private void changeToErrorState(final Throwable e) {
		synchronized (stateLock) {
			this.state = ERROR;
			Thread t = new Thread() {
				@Override
				public void run() {
					for (ControlFederateListenerRemote listener : listeners) {
						try {
							listener.error(e);
						} catch (RemoteException e) {
							logger.error("Remote exception during callback to ControlFederateListenerRemote", e);
						}
					}
				}
			};
			t.start();
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @throws
	 */
	public synchronized void init(long timeout, TimeUnit unit) throws InterruptedException, FederationException {
		setState(INITIALIZING);
		try {
			if (rtiFactoryClass == null) {
				rtiAmbassador = RtiFactoryFactory.getRtiFactory().getRtiAmbassador();
			} else {
				rtiAmbassador = RtiFactoryFactory.getRtiFactory(rtiFactoryClass).getRtiAmbassador();
			}

			rtiAmbassador.enableCallbacks();
			rtiAmbassador.createFederationExecution(federationExecutionName, fdd);
			logger.log(Level.INFO, String.format("Created Federation Execution %s", federationExecutionName));

			controlFederate = new ControlFederate(rtiAmbassador);

			controlFederate.addInteractionListener(this);
			controlFederate.getFederateAmbassadorDelegator().registerDelegate(this);

			controlFederate.joinFederationExecution("EodispControlFederate", federationExecutionName, null);
			logger.log(Level.INFO, String.format("Joined Federation Execution %s", federationExecutionName));

			controlFederate.defaultPublishSubscribe();
			logger.log(Level.INFO, "Finished ObjectClass/InterationClass Publications and Subscription");

			controlFederate.registerSynchronizationPoint(EODISP_INIT, NULL_BYTE, 10, SECONDS);
			logger.log(Level.INFO, "Registered synchronization point EODISP_INIT");

			logger.info("Wait for federates to register with control federate");
			if (!federateRegisterLatch.await(timeout, unit)) {
				throw new FederationException(String.format(
						"Not all federates registered with the control federate (%d missing)", new Long(
								federateRegisterLatch.getCount())));
			}

			logger.info("Federates have registered with the control federate");
		} catch (RTIexception e) {
			throw new FederationException(e);
		} catch (SynchronizationPointRegistrationException e) {
			throw new FederationException(e);
		}
		setState(INITIALIZED);
	}

	/**
	 * It may take up to 30 seconds for this method to return.
	 * 
	 * {@inheritDoc}
	 */
	public void pause() {
		try {
			controlFederate.registerSynchronizationPoint(EODISP_PAUSE, NULL_BYTE, SYNC_POINT_REG_TIMEOUT,
					TimeUnit.SECONDS);
		} catch (RTIexception e) {
			changeToErrorState(e);
		} catch (InterruptedException e) {
			changeToErrorState(e);
			Thread.currentThread().interrupt();
		} catch (SynchronizationPointRegistrationException e) {
			changeToErrorState(e);
		}
	}

	/**
	 * It may take up to 30 seconds for this method to return.
	 * 
	 * {@inheritDoc}
	 */
	public void step() {
		try {
			controlFederate.registerSynchronizationPoint(EODISP_STEP, NULL_BYTE, SYNC_POINT_REG_TIMEOUT,
					TimeUnit.SECONDS);
		} catch (RTIexception e) {
			changeToErrorState(e);

		} catch (InterruptedException e) {
			changeToErrorState(e);
			Thread.currentThread().interrupt();

		} catch (SynchronizationPointRegistrationException e) {
			changeToErrorState(e);
		}
	}

	/**
	 * It may take up to 30 seconds for this method to return.
	 * 
	 * {@inheritDoc}
	 */
	public void resume() {
		try {
			controlFederate.registerSynchronizationPoint(EODISP_RESUME, NULL_BYTE, SYNC_POINT_REG_TIMEOUT,
					TimeUnit.SECONDS);
		} catch (RTIexception e) {
			changeToErrorState(e);
		} catch (InterruptedException e) {
			changeToErrorState(e);
			Thread.currentThread().interrupt();
		} catch (SynchronizationPointRegistrationException e) {
			changeToErrorState(e);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public synchronized void start(long timeout, TimeUnit unit) throws InterruptedException, FederationException,
			RemoteException {
		try {
			setState(STARTING);

			try {
				controlFederate.registerSynchronizationPoint(EODISP_START, NULL_BYTE, getSynchronizationSet(), 10,
						SECONDS);
				controlFederate.achieveSyncPointAndAwaitFederationSynchronization(EODISP_START, timeout, SECONDS);
			} catch (Exception e) {
				throw new FederationException(e);
			}
			setState(STARTED);
			stop(timeout, unit);
			setState(STOPPED);
		} finally {
			Thread t = new Thread() {
				@Override
				public void run() {
					try {
						/*
						 * Make sure that the stop call returns to the (remote)
						 * caller before the application is shutdown.
						 */
						SECONDS.sleep(5);
						// AppRegistry.getRootApp().shutdown();
					} catch (Exception e) {
						e.printStackTrace();
						System.exit(1);
					} finally {
						System.exit(0);
					}
				}
			};
			t.start();
		}
	}

	/**
	 * @return
	 * @throws FederateNotExecutionMember
	 */
	@SuppressWarnings("unchecked")
	private synchronized FederateHandleSet getSynchronizationSet() throws FederateNotExecutionMember {
		if (synchronizationSet != null) {
			return synchronizationSet;
		}
		synchronizationSet = rtiAmbassador.getFederateHandleSetFactory().create();
		synchronizationSet.add(controlFederate.getFederatHandle());
		for (FederateHandle federateHandle : registeredFederateHandles) {
			synchronizationSet.add(federateHandle);
		}
		return synchronizationSet;
	}

	private synchronized void stop(long timeout, TimeUnit unit) throws InterruptedException, FederationException {
		try {
			controlFederate.registerSynchronizationPoint(EODISP_STOP, NULL_BYTE, getSynchronizationSet(), 120, SECONDS);
			controlFederate.achieveSyncPointAndAwaitFederationSynchronization(EODISP_STOP, timeout, unit);
			rtiAmbassador.resignFederationExecution(ResignAction.UNCONDITIONALLY_DIVEST_ATTRIBUTES);
			while (true) {
				try {
					rtiAmbassador.destroyFederationExecution(federationExecutionName);
					logger.debug(String.format("Destroyed federation execution %s", federationExecutionName));
					break;
				} catch (FederatesCurrentlyJoined e) {
					logger.info("Could not destroy federation execution. Wait 2 seconds and try again");
					SECONDS.sleep(2);
					// ignore and try again
				}
			}
		} catch (RTIexception e) {
			throw new FederationException(e);
		} catch (SynchronizationPointRegistrationException e) {
			throw new FederationException(e);
		} catch (FederationSynchronizationException e) {
			throw new FederationException(e);
		}
	}

	@Override
	public void federationSynchronized(String synchronizationPointLabel) {
		logger.info("Federation synchronized at: " + synchronizationPointLabel);
		try {
			if (synchronizationPointLabel.equals(EODISP_PAUSE)) {
				setState(PAUSED);
			} else if (synchronizationPointLabel.equals(EODISP_STEP)) {
				setState(PAUSED);
			} else if (synchronizationPointLabel.equals(EODISP_RESUME)) {
				setState(STARTED);
			}
		} catch (IllegalStateException e) {
			logger
					.fatal("Federation Synchronized at %s but the control federate is in state %s which is not compatible with the control federate's state machine");
			changeToErrorState(e);
		}
	}

	@Override
	public void announceSynchronizationPoint(String label, byte[] userSuppliedTag) throws FederateInternalError {
		if (label.equals(EODISP_INIT) || label.equals(EODISP_START) || label.equals(EODISP_STOP)) {
			return;
		}
		synchronized (stateLock) {
			try {
				controlFederate.getRtiAmbassador().synchronizationPointAchieved(label);
			} catch (RTIexception e) {
				setState(ERROR);
				logger.error("Error in EodispFederate while achieving sync point", e);
				return;
			}
			if (label.equals(EODISP_PAUSE)) {
				setState(PAUSING);
			} else if (label.equals(EODISP_RESUME)) {
				setState(RESUMING);
			} else if (label.equals(EODISP_STEP)) {
				setState(STEPPING);
			}
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void receiveRegisterFederate(byte[] federateHandleParam, byte[] userSuppliedTag, OrderType sentOrdering,
			TransportationType theTransport) throws InteractionClassNotRecognized, InteractionParameterNotRecognized,
			InteractionClassNotSubscribed, FederateInternalError {

		if (federateRegisterLatch.getCount() == 0) {
			final String errorMsg = String.format("Too many EODiSP federates registered with the control federate");
			logger.error(errorMsg);
			changeToErrorState(new Exception(errorMsg));
		}

		try {
			FederateHandle federateHandle = rtiAmbassador.getFederateHandleFactory().decode(federateHandleParam, 0);
			registeredFederateHandles.add(federateHandle);
			federateRegisterLatch.countDown();
			logger.log(Level.DEBUG, String.format(
					"Federate handle %s has been registered with the EODiSP Control Federate", federateHandle));
		} catch (RTIexception e) {
			Exception exception = new Exception("EODiSP federate registration error", e);
			logger.error(exception.getMessage(), e);
			changeToErrorState(e);
		}
	}
}
