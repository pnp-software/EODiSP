/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005,2006  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.sm.control;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.concurrent.TimeUnit;

import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.wrapper.hla.FederationState;

/**
 * Interface to control and receive the status of an EODiSP federation
 * execution. See the following state diagram for valid state changes:
 * 
 * <pre> 
 *                                                                        
 *                                                                        .---------------------------------------------------------------.
 *                                                                        |                                                               |
 *                                                                        |      .-------------------------------------------.            |
 *                                                                        |      |                       STEPPING            |            |
 *                                                                        |      |                        ^    |             |            |
 *                                                                        |      |                 step() |    |             |            |
 *                    init()                             start()          |      V    pause()             |    v  resume()   |            |
 *    NOT_INITIALIZED ---»  INITIALIZING ----» INITIALIZED ---» STARTING -|-» STARTED ---»  PAUSING  --»  PAUSED -------» RESUMING        |
 *                                                                        |                                                               |
 *                                                                        '---------------------------------------------------------------'
 *                                                                                                       |    
 *                                                                                                       |
 *                                                                                                       v      
 *                                                                                                    STOPPED       
 *                                                                           
 *                                                                            (From anywhere at anytime) ---> ERROR ---.
 *                                                                                                              A      |
 *                                                                                                              |______|
 *                                                                                        
 * </pre>
 * 
 * @author ibirrer
 */
public interface ControlFederateRemote extends Remote {
	String REGISTRY_NAME = "org.eodisp.core.sm.control.ControlFederateRemote";

	/**
	 * Causes a transition from the state
	 * {@linkplain FederationState#NOT_INITIALIZED} to
	 * {@linkplain FederationState#INITIALIZED}, while during the state
	 * transition it the state is set to
	 * {@linkplain FederationState#INITIALIZING}.
	 * 
	 * Postconditions:
	 * <ul>
	 * <li>{@linkplain #getState()} returns
	 * {@linkplain FederationState#INITIALIZED}</li>
	 * <li>The control federate has joined to the CRC</li>
	 * <li>The federation execution has been created on the CRC</li>
	 * <li>The synchronization point EODISP_INIT has been announced to the
	 * federation</li>
	 * <li>All federates have registered with the control federate using the
	 * interaction 'RegisterFederate(...)'</li>
	 * </ul>
	 * 
	 * @param timeout
	 *            the maximum time to wait. If this timeout expires before all
	 *            postconditions met, a {@link FederationException} is thrown.
	 * @param unit
	 *            the time unit of the <tt>timeout</tt> argument.
	 * 
	 * @throws InterruptedException
	 *             if the current thread is interrupted while waiting.
	 * @throws FederationException
	 *             If, for any reason, the
	 *             {@linkplain  FederationState#INITIALIZED} state could not be
	 *             reached. This includes the case of timeout expiration. Use
	 *             {@link FederationException#getCause()} to get the actual
	 *             cause of the exception. Implementation classes should
	 *             document all exception that can cause this exception to allow
	 *             a client to react differently to each cause.
	 * 
	 * @throws RemoteException
	 *             if a communication error occurs
	 * 
	 */
	void init(long timeout, TimeUnit unit) throws InterruptedException, FederationException, RemoteException;

	/**
	 * Causes a transition from the state
	 * {@linkplain FederationState#INITIALIZED} to
	 * {@linkplain FederationState#STARTED}, while during the state transition
	 * it the state is set to {@linkplain FederationState#STARTING}.
	 * Postconditions:
	 * <ul>
	 * <li>{@linkplain #getState()} returns
	 * {@linkplain FederationState#STARTED}</li>
	 * <li>The synchronization point <code>EODISP_START</code> has been
	 * announced and the federation synchronized at this point.</li>
	 * <li>The synchronization point <code>EODISP_STOP</code> has been
	 * announced and the federation synchronized at this point.</li>
	 * <li>All participating federates have resigned from the federation
	 * execution and the federation has been destroyed</li>
	 * </ul>
	 * <p>
	 * The control federate shuts down itself after waiting for 2 seconds after
	 * the start call has returned.
	 * 
	 * @param timeout
	 *            the maximum time to wait. If this timeout expires before all
	 *            postconditions met, a {@link FederationException} is thrown.
	 * @param unit
	 *            the time unit of the <tt>timeout</tt> argument.
	 * 
	 * @throws InterruptedException
	 *             if the current thread is interrupted while waiting.
	 * @throws FederationException
	 *             If, for any reason, the {@linkplain  FederationState#STARTED}
	 *             state could not be reached. This includes the case of timeout
	 *             expiration. Use {@link FederationException#getCause()} to get
	 *             the actual cause of the exception. Implementation classes
	 *             should document all exception that can cause this exception
	 *             to allow a client to react differently to each cause.
	 * 
	 * @throws RemoteException
	 *             if a communication error occurs
	 */
	void start(long timeout, TimeUnit unit) throws InterruptedException, FederationException, RemoteException;

	/**
	 * Causes a transition from the state {@linkplain FederationState#STARTED}
	 * to {@linkplain FederationState#PAUSED}, while during the state
	 * transition it the state is set to {@linkplain FederationState#PAUSING}.
	 * Postconditions:
	 * <ul>
	 * <li>{@linkplain #getState()} returns {@linkplain FederationState#PAUSED}</li>
	 * <li>The synchronization point EODISP_PAUSE has been announced and the
	 * federation has synchronized at this point</li>
	 * </ul>
	 * 
	 * @throws FederationException
	 *             If, for any reason, the {@linkplain  FederationState#PAUSED}
	 *             state could not be reached. This includes the case of timeout
	 *             expiration. Use {@link FederationException#getCause()} to get
	 *             the actual cause of the exception. Implementation classes
	 *             should document all exception that can cause this exception
	 *             to allow a client to react differently to each cause.
	 * 
	 * @throws RemoteException
	 *             if a communication error occurs
	 */
	void pause() throws RemoteException;

	/**
	 * Causes a transition from the state {@linkplain FederationState#PAUSED} to
	 * {@linkplain FederationState#PAUSED}, while during the state transition
	 * it the state is set to {@linkplain FederationState#STEPPING}.
	 * Postconditions:
	 * <ul>
	 * <li>{@linkplain #getState()} returns {@linkplain FederationState#PAUSED}</li>
	 * <li>The synchronization point EODISP_STEP has been announced and the
	 * federation has synchronized at this point</li>
	 * </ul>
	 * 
	 * @throws FederationException
	 *             If, for any reason, the {@linkplain  FederationState#PAUSED}
	 *             state could not be reached. This includes the case of timeout
	 *             expiration. Use {@link FederationException#getCause()} to get
	 *             the actual cause of the exception. Implementation classes
	 *             should document all exception that can cause this exception
	 *             to allow a client to react differently to each cause.
	 * 
	 * @throws RemoteException
	 *             if a communication error occurs
	 */
	void step() throws RemoteException;

	/**
	 * Causes a transition from the state {@linkplain FederationState#PAUSED} to
	 * {@linkplain FederationState#STARTED}, while during the state transition
	 * it the state is set to {@linkplain FederationState#RESUMING}.
	 * Postconditions:
	 * <ul>
	 * <li>{@linkplain #getState()} returns
	 * {@linkplain FederationState#STARTED}</li>
	 * <li>The synchronization point EODISP_RESUME has been announced and the
	 * federation has synchronized at this point</li>
	 * </ul>
	 * 
	 * @throws FederationException
	 *             If, for any reason, the {@linkplain  FederationState#STARTED}
	 *             state could not be reached. This includes the case of timeout
	 *             expiration. Use {@link FederationException#getCause()} to get
	 *             the actual cause of the exception. Implementation classes
	 *             should document all exception that can cause this exception
	 *             to allow a client to react differently to each cause.
	 * 
	 * @throws RemoteException
	 *             if a communication error occurs
	 */
	void resume() throws RemoteException;

	/**
	 * Registers a listener with the control federate. The listener receives all
	 * state changes and any exceptions that are thrown while the control
	 * federate is processing callbacks from the RTI.
	 * 
	 * @param federationStateListener
	 *            the listener. Must to be exported by
	 *            {@link RemoteAppModule#export(Remote)}.
	 * @throws RemoteException
	 *             if a communication error occurs
	 */
	void addFederationStateListener(ControlFederateListenerRemote federationStateListener) throws RemoteException;

	/**
	 * Returns the state of the EODiSP federation
	 * 
	 * @return the state of the EODiSP federation
	 * @throws RemoteException
	 *             if a communication error occurs
	 */
	FederationState getState() throws RemoteException;
}
