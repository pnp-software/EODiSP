/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.common;

import java.io.IOException;

import org.eclipse.emf.ecore.sdo.EDataGraph;

/**
 * The service that can be used to query the project model of the simulation
 * manager application. This interface is only accessible from a local node. It
 * is never exported to be remotely available. Hence, the name is a bit
 * misleading. However, this class could be well used as a remote interface for
 * querying the model of the simulation manager.
 * 
 * @author eglimi
 * @version $Id:$
 * 
 */
public interface SmModelService {

	/**
	 * Returns all data currently stored in the project file.
	 * 
	 * @return A data graph representing all data currently in the model.
	 * @throws IOException
	 */
	public EDataGraph getAllData() throws IOException;

	/**
	 * Updates the simulation manager project file according to the changes
	 * included in the data graph.
	 * 
	 * @param dg
	 *            The data graph that includes the changes that are to be made
	 *            to the simulation manager project file.
	 * @throws IOException
	 */
	public void update(EDataGraph dg) throws IOException;

}