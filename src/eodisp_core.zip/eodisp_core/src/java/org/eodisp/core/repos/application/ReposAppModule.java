/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.repos.application;

import java.io.File;

import org.eodisp.core.common.ReposModelService;
import org.eodisp.core.repos.config.ReposConfiguration;
import org.eodisp.core.repos.service.ReposModelReader;
import org.eodisp.core.repos.service.ReposModelServiceImpl;
import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.util.AppModule;
import org.eodisp.util.RootApp;

/**
 * @author eglimi
 * @version $Id:$
 */
public class ReposAppModule implements AppModule {

	public static final String ID = "org.eodisp.core.repos";

	private static final String CONFIG_FILE_NAME = "repos.conf";

	private final ReposModelServiceImpl reposServiceImpl = new ReposModelServiceImpl();

	private final ReposModelReader modelReader = new ReposModelReader();

	private RemoteAppModule remoteAppModule;

	/**
	 * {@inheritDoc}
	 */
	public String getId() {
		return ID;
	}

	/**
	 * {@inheritDoc}
	 */
	public void registerConfiguration(RootApp rootApp) throws Exception {
		File configFile = new File(rootApp.getConfigurationDir(), CONFIG_FILE_NAME);
		ReposConfiguration reposConfig = new ReposConfiguration(configFile);

		// register configurations
		rootApp.registerConfiguration(reposConfig);
	}

	/**
	 * {@inheritDoc}
	 */
	public void startup(RootApp rootApp) throws Exception {
		remoteAppModule = (RemoteAppModule) rootApp.getAppModule(RemoteAppModule.ID);
		remoteAppModule.exportAndRegister(reposServiceImpl, ReposModelService.REGISTRY_NAME);
		
		modelReader.load();
	}

	/**
	 * {@inheritDoc}
	 */
	public void preStartup(RootApp rootApp) throws Exception {
		// nothing to do
	}

	/**
	 * {@inheritDoc}
	 */
	public void shutdown(RootApp rootApp) throws Exception {
		remoteAppModule.getRegistry().unbind(ReposModelService.REGISTRY_NAME);
	}

	/**
	 * {@inheritDoc}
	 */
	public void postShutdown(RootApp rootApp) throws Exception {
		// nothing to do
	}

	/**
	 * @return Returns the modelReader.
	 */
	public ReposModelReader getModelReader() {
		return modelReader;
	}

}
