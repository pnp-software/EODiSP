/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.repos.service;

import java.io.File;
import java.util.List;

import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.sdo.EDataGraph;
import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eclipse.emf.ecore.sdo.SDOFactory;
import org.eclipse.emf.ecore.sdo.util.SDOUtil;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eodisp.core.common.SomNotKnownException;
import org.eodisp.core.gen.repository.DocumentRoot;
import org.eodisp.core.gen.repository.impl.RepositoryPackageImpl;
import org.eodisp.core.gen.smproject.SmProject;

import commonj.sdo.DataObject;

/**
 * @author eglimi
 * @version $Id:$
 */
public class ReposUtil {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(ReposUtil.class);

	@SuppressWarnings("unchecked")
	static EDataGraph loadAllData(EDataGraph origGraph, String query) {

		// The DataGraph that will be returned.
		EDataGraph dg = null;

		// get the root object
		EDataObject origRoot = (EDataObject) origGraph.getERootObject();

		// Try to find an Object according to the query.
		EObject result = (EObject) origRoot.get(query);

		// If it could find an object with the query, create a new DataGraph
		// that will hold the resulting object.
		if (result != null) {
			dg = createInitiDg();

			DataObject root = dg.getRootObject();

			// add the result
			root.set(query, EcoreUtil.copy(result));
		}

		return dg;
	}

	/**
	 * Creates an initial data graph which can be used as an empty skeleton.
	 * This can be filled with data according to the query.
	 * <p>
	 * This skeleton includes a {@link DocumentRoot}, and a {@link SmProject}
	 * object. The name of the project is set to the name set in the origRoot
	 * object.
	 * 
	 * @param projectName
	 *            The original root object of the data graph that includes all
	 *            data from the repository. This will be used to query the
	 *            project name and possibly other values that need to be copied
	 *            every time a new data graph has to be created.
	 * @return The newly created data graph.
	 */
	@SuppressWarnings("unchecked")
	static EDataGraph createInitiDg() {
		ResourceSet rs = SDOUtil.createResourceSet();
		rs.getPackageRegistry().put(RepositoryPackageImpl.eNS_URI, RepositoryPackageImpl.eINSTANCE);
		rs.createResource(org.eclipse.emf.common.util.URI.createURI("repos.datagraph"));

		// create the data graph
		EDataGraph dg = SDOFactory.eINSTANCE.createEDataGraph();

		// set objects (SmProject)
		dg.createRootObject(RepositoryPackageImpl.eNS_URI, "DocumentRoot");

		dg.setResourceSet(rs);

		return dg;
	}

	static File getPhysicalSomFile(EDataGraph dataGraph, String somName, String somVersion) throws SomNotKnownException {
		// get the root object
		EDataObject docRoot = (EDataObject) dataGraph.getERootObject();
		EDataObject repository = (EDataObject) docRoot.getDataObject(RepositoryPackageImpl.DOCUMENT_ROOT__REPOSITORY);
		List<EDataObject> soms = repository.getList(RepositoryPackageImpl.REPOSITORY__SOMS);

		for (EDataObject som : soms) {
			if (somName.equals(som.getString(RepositoryPackageImpl.SOM__NAME))
					&& somVersion.equals(som.getString(RepositoryPackageImpl.SOM__VERSION))) {

				File somFile = new File(som.getString(RepositoryPackageImpl.SOM__LOCAL_PATH));
				logger.debug("SOM file has been found on the repository. The file is " + somFile.getPath());

				return somFile;
			}
		}

		final String message = "The SOM with name " + somName + " and version " + somVersion
				+ " could not be found on the repository";
		logger.error(message);
		throw new SomNotKnownException(message);
	}

}
