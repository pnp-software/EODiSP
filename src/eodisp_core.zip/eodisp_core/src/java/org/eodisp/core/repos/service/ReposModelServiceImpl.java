/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.repos.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.sdo.EDataGraph;
import org.eodisp.core.common.ReposModelService;
import org.eodisp.core.common.SomFile;
import org.eodisp.core.common.SomNotKnownException;
import org.eodisp.core.repos.application.ReposAppModule;
import org.eodisp.core.repos.config.ReposConfiguration;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.FileUtil;

/**
 * This implementation will be exported by the eodisp_remote package and
 * therefore accessible through the network. Since the remote mechanism takes
 * care of the objects, it is not implemented as singleton.
 * 
 * @author eglimi
 * @version $Id:$
 */
public class ReposModelServiceImpl implements ReposModelService {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(ReposModelServiceImpl.class);

	/**
	 * Constructor.
	 */
	public ReposModelServiceImpl() {
	}

	public EDataGraph getAllData() throws IOException {

		logger.debug("Request for all data received.");

		ReposModelReader modelReader = ((ReposAppModule) AppRegistry.getRootApp().getAppModule(ReposAppModule.ID))
				.getModelReader();
		EDataGraph origGraph = modelReader.getDataGraph();

		EDataGraph dataGraph = ReposUtil.loadAllData(origGraph, "repository");

		return dataGraph;
	}

	/**
	 * {@inheritDoc}
	 */
	public void update(EDataGraph dataGraph) throws IOException {

		logger.debug("Request to update received.");

		ReposModelReader modelReader = ((ReposAppModule) AppRegistry.getRootApp().getAppModule(ReposAppModule.ID))
				.getModelReader();
		modelReader.updateDataGraph(dataGraph);
	}

	/**
	 * {@inheritDoc}
	 */
	public String addSom(SomFile somFile) throws IOException, IllegalStateException {
		File somsDir = ((ReposConfiguration) AppRegistry.getRootApp().getConfiguration(ReposConfiguration.ID))
				.getSomsDir();
		if (!somsDir.exists()) {
			if (!somsDir.mkdir()) {
				final String message = "The directory " + somsDir.getPath() + " could not be created.";
				logger.error(message);
				throw new IOException(message);
			}
			logger.debug("Created directory " + somsDir.getPath());
		}

		File som = new File(somsDir, somFile.getUniqueFileName());
		FileOutputStream out = new FileOutputStream(som);
		try {
			out.write(somFile.getFileData());
			logger.debug("SOM file " + somFile.getUniqueFileName() + " has been written to " + som.getPath());

			return som.getPath();
		} catch (IOException e) {
			logger.error("Could not write som file data to disk", e);
			throw e;
		} finally {
			out.close();
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public SomFile getSom(String somName, String somVersion) throws SomNotKnownException, IOException {
		ReposModelReader modelReader = ((ReposAppModule) AppRegistry.getRootApp().getAppModule(ReposAppModule.ID))
				.getModelReader();

		File physicalSomFile = ReposUtil.getPhysicalSomFile(modelReader.getDataGraph(), somName, somVersion);

		if (!physicalSomFile.exists()) {
			final String message = "The file " + physicalSomFile.getPath() + " does not exist on the repository.";
			logger.error(message);
			throw new SomNotKnownException(message);
		}

		byte[] somBytes = FileUtil.loadFileToByteArray(physicalSomFile);

		// create the SomFile
		return new SomFile(somName, somVersion, physicalSomFile.getName(), somBytes);
	}

	/**
	 * {@inheritDoc}
	 */
	public void deleteSom(String somName, String somVersion) throws SomNotKnownException {
		ReposModelReader modelReader = ((ReposAppModule) AppRegistry.getRootApp().getAppModule(ReposAppModule.ID))
				.getModelReader();

		File physicalSomFile = ReposUtil.getPhysicalSomFile(modelReader.getDataGraph(), somName, somVersion);

		if (!physicalSomFile.exists()) {
			final String message = "The file " + physicalSomFile.getPath() + " does not exist on the repository.";
			logger.error(message);
			throw new SomNotKnownException(message);
		}

		physicalSomFile.delete();
	}
}
