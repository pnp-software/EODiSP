package org.eodisp.core.repos.service;

import java.io.*;
import java.net.URISyntaxException;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.sdo.EDataGraph;
import org.eclipse.emf.ecore.sdo.util.SDOUtil;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eodisp.core.common.EmfUtil;
import org.eodisp.core.gen.repository.impl.RepositoryPackageImpl;
import org.eodisp.core.repos.config.ReposConfiguration;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.FileUtil;

public final class ReposModelReader {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(ReposModelReader.class);

	private final HashMap options = new HashMap();

	private final Resource resource;

	private final ResourceSet resourceSet;

	private EDataGraph dataGraph;

	private File modelFile;

	public ReposModelReader() {
		// Set a few options for the XML resources
		options.put(XMLResource.OPTION_ENCODING, "UTF-8");
		options.put(XMLResource.OPTION_USE_DEPRECATED_METHODS, Boolean.TRUE);

		resourceSet = SDOUtil.createResourceSet();
		resourceSet.getPackageRegistry().put(RepositoryPackageImpl.eNS_URI, RepositoryPackageImpl.eINSTANCE);

		resource = resourceSet.createResource(URI.createURI("repos.datagraph"));
	}

	public synchronized EDataGraph getDataGraph() {
		if (dataGraph != null) {
			return dataGraph;
		}

		final String message = "The datagraph has not been loaded. Load it first, before trying to get the data graph";
		throw new IllegalStateException(message);
	}

	public void updateDataGraph(EDataGraph changedDg) throws IOException {
		EmfUtil.updateDataGraph(getDataGraph(), changedDg, modelFile, options);
	}

	public synchronized void load() throws IOException, URISyntaxException {
		if (resource.isLoaded()) {
			return;
		}

		modelFile = getModelFile();

		logger.debug(String.format("loading the datagraph from file %s", modelFile.getPath()));

		FileInputStream is = new FileInputStream(modelFile);

		try {
			resource.load(is, options);
		} catch (IOException ex) {
			// log the error and throw it further to inform clients
			logger.error("The data could not be loaded into the resource", ex);
			throw ex;
		} finally {
			is.close();
		}

		dataGraph = (EDataGraph) resource.getContents().get(0);
	}

	private File getModelFile() throws URISyntaxException, IOException {
		File modelReposFile = ((ReposConfiguration) AppRegistry.getRootApp().getConfiguration(ReposConfiguration.ID))
				.getReposModelFile();

		ensureModelFile(modelReposFile);

		return modelReposFile;
	}

	/**
	 * Ensures that the model file exists. If it does not exist, a new one will
	 * be created using the template file (RepositoryTemplate.xml) from the
	 * {@link org.eodisp.core.repos.resources} package.
	 * 
	 * @param file
	 *            The file where the model is expected.
	 * @throws URISyntaxException
	 * @throws IOException
	 */
	private void ensureModelFile(File file) throws IOException {
		// If the file exists, we do not change anything.
		if (file.exists()) {
			return;
		}

		// otherwise, we create a template file
		InputStream tplStream = getClass().getClassLoader().getResourceAsStream(
				"org/eodisp/core/resources/Repository.tpl");

		try {
			FileUtil.copy(tplStream, file);
		} catch (IOException e) {
			logger.error(String.format("The new file: %1$s could not created.", file), e);
			throw e;
		}

	}
}
