/**
 * 
 */
package org.eodisp.core.sm.control.application;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.eodisp.util.configuration.CommandlineMapper;
import org.eodisp.util.configuration.ConfigurationException;
import org.eodisp.util.configuration.ConfigurationImpl;
import org.eodisp.util.configuration.ManualCommandlineMapper;
import org.eodisp.util.configuration.ManualCommandlineMapper.CommandlineOption;

/**
 * @author ibirrer
 * 
 */
public class ControlFederateConfiguration extends ConfigurationImpl {
	private static final String EODISP_FEDERATES = "eodisp-federates";

	/**
	 * The Id of this configuration.This id can be used to retrieve the
	 * configuration entries.
	 */
	public static final String ID = ControlFederateConfiguration.class
			.getName();

	/**
	 * The name of the configuration. This will be shown on the command line.
	 */
	public static final String NAME = "Scene Creator Federate Configuration";

	/**
	 * Describes the configuration. This will be shown on the command line.
	 */
	public static final String DESCRIPTION = "Configuration of the EODiSP Control Federate.";

	private static final String FEDERATION_EXECUTION = "federation-execution";

	private static final String FDD = "fdd";

	/**
	 * A command line mapper that adds short flags for the fdd and
	 * federation-execution command line flags.
	 */
	public static final CommandlineMapper COMMAND_LINE_MAPPER;

	static {
		Map<String, CommandlineOption> commandlineMapping = new HashMap<String, CommandlineOption>();
		commandlineMapping.put(FDD, new CommandlineOption('f', null, null));
		commandlineMapping.put(FEDERATION_EXECUTION, new CommandlineOption('e',
				null, null));
		commandlineMapping.put(EODISP_FEDERATES, new CommandlineOption('n', null, null, true));

		COMMAND_LINE_MAPPER = new ManualCommandlineMapper(commandlineMapping,
				true);
	}

	/**
	 * {@inheritDoc}
	 */
	public ControlFederateConfiguration(File file) {
		super(ID, NAME, DESCRIPTION, file);
		createEntry(FEDERATION_EXECUTION, "DefaultFederationExecution",
				"The federation execution that this federate shall join");

		createFileEntry(
				FDD,
				new File("default.fdd"),
				"The FOM document data file that describes the federation execution to be controlled by this control federate.");
		
		createIntEntry(EODISP_FEDERATES, 0, "The number of federate that will join this federation execution and take part in the EODiSP life-cycle.");
	}

	public static void main(String[] args) {
		System.out.println(new ControlFederateConfiguration(null).getCode());
	}

	public String getFederationExecution() {
		 return getEntry(FEDERATION_EXECUTION).getValue(); 
	}

	public void setFederationExecution(String federationExecution) {
		 getEntry(FEDERATION_EXECUTION).setValue(federationExecution);
	}
	
	public URL getFddUrl() throws ConfigurationException {
		try {
			return new URL(getEntry(FDD).getValue());
		} catch (MalformedURLException e) {
			throw new ConfigurationException(e);
		}
	}
	
	public int getEodispFederates() {
		 return getEntry(EODISP_FEDERATES).getInt(); 
	}

	public void setEodispFederates(int eodispFederates) {
		 getEntry(EODISP_FEDERATES).setInt(eodispFederates); 
	}
}
