/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.common;

import java.io.Serializable;

/**
 * An immutable handle that identifies a running federate on the model manager.
 * It is returned when starting a federate on the model manager through the
 * method
 * {@link org.eodisp.core.common.ModelManagerRemote#startFederate(java.util.UUID, String, java.util.Map)}
 * 
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class FederateProcessHandle implements Serializable {

	/**
	 * the id of the process
	 */
	private final int id;

	/**
	 * Creates a new FederateProcessHandle with the given id.
	 */
	public FederateProcessHandle(int id) {
		this.id = id;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final FederateProcessHandle other = (FederateProcessHandle) obj;
		if (id != other.id)
			return false;
		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode() {
		return id;
	}

	@Override
	public String toString() {
		return id + "";
	}
}
