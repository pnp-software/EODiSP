package org.eodisp.core.sm.control.application;

import java.io.File;

import org.apache.log4j.Logger;
import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.remote.launcher.server.application.RootAppStartedCallbackAppModule;
import org.eodisp.util.RootApp;

/**
 * The EODiSP control federate that used by the simulation manager to control a
 * federation execution.
 * 
 * @author ibirrer
 */
public class ControlFederateMain {

	// prevent subclassing and instantiation
	private ControlFederateMain() {
	}

	public static final String APP_NAME = "EODiSP Control Federate";

	public static final String APP_DESCRIPTION = "The federate that control the execution of an EODiSP simulation";

	public static final File DEFAULT_WORKING_DIR = new File(new File(System.getProperty("user.home"), ".eodisp_earthcare"),
			"eodisp_control_federate");

	public static final Class MAIN_CLASS = ControlFederateMain.class;

	final static Logger logger = Logger.getLogger(ControlFederateMain.class.getName());

	/**
	 * Creates the {@link RootApp} instance and starts the federate.
	 * 
	 * @param args
	 *            command line arguments
	 */
	public static void main(String[] args) {
		try {
			RootApp federateApplication = new RootApp(APP_NAME, APP_DESCRIPTION, DEFAULT_WORKING_DIR, MAIN_CLASS);
			federateApplication.registerAppModule(new RemoteAppModule(0));
			federateApplication.registerAppModule(new ControlFederateAppModule());
			federateApplication.registerAppModule(new RootAppStartedCallbackAppModule());
			federateApplication.execute(args);
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}
}
