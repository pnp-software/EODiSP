/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.sm.service;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.sdo.EDataGraph;
import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eclipse.emf.ecore.sdo.SDOFactory;
import org.eclipse.emf.ecore.sdo.util.SDOUtil;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.util.EcoreUtil.Copier;
import org.eodisp.core.gen.smproject.DocumentRoot;
import org.eodisp.core.gen.smproject.SmProject;
import org.eodisp.core.gen.smproject.impl.SmprojectPackageImpl;

import commonj.sdo.DataObject;

/**
 * @author eglimi
 * @version $Id:$
 * 
 */
public class SmProjectUtil {

	/**
	 * This loads all Data currently in the resource. It does it by querying the
	 * original data graph and copying the resulting object to a new DataGraph.
	 * 
	 * @param origGraph
	 *            The DataGraph originally created by loading the resource.
	 * @param query
	 *            The query used on the origGraph in order to receive the
	 *            desired object(s).
	 * @return The newly created datagraph that only holds the requested
	 *         objects.
	 */
	public static EDataGraph loadAllData(EDataGraph origGraph, String query) {
		// The DataGraph that will be returned.
		EDataGraph dataGraph = null;

		// get the root object
		EDataObject origRoot = (EDataObject) origGraph.getERootObject();

		// Try to find an Object according to the query.
		EObject result = (EObject) origRoot.get(query);

		// If it could find an object with the query, create a new DataGraph
		// that will hold the
		// resulting object.
		if (result != null) {
			// create a new data graph
			dataGraph = createInitiDg();
			
			// get the root object of the new data graph
			DataObject root = dataGraph.getRootObject();
			
			// add the result from the query to the root object 
			root.set(query, EcoreUtil.copy(result));
		}

		return dataGraph;
	}

	/**
	 * Creates an initial data graph which can be used as an empty skeleton.
	 * This can be filled with data according to the query.
	 * <p>
	 * This skeleton includes a {@link DocumentRoot}, and a {@link SmProject}
	 * object. The name of the project is set to the name set in the origRoot
	 * object.
	 * 
	 * @param projectName
	 *            The original root object of the data graph that includes all
	 *            data from the repository. This will be used to query the
	 *            project name and possibly other values that need to be copied
	 *            every time a new data graph has to be created.
	 * @return The newly created data graph.
	 */
	@SuppressWarnings("unchecked")
	public static EDataGraph createInitiDg() {

		ResourceSet rs = SDOUtil.createResourceSet();
		rs.getPackageRegistry().put(SmprojectPackageImpl.eNS_URI, SmprojectPackageImpl.eINSTANCE);
		rs.createResource(URI.createURI("sm.datagraph"));

		// create the data graph
		EDataGraph dg = SDOFactory.eINSTANCE.createEDataGraph();

		// set objects (SmProject)
		dg.createRootObject(SmprojectPackageImpl.eNS_URI, "DocumentRoot");

		dg.setResourceSet(rs);

		return dg;
	}

	/**
	 * Creates a shallow copy of an {@link EObject}. It uses the copy method
	 * from the (see {@link Copier#copy(EObject)}}), but does not copy
	 * containment features (references). This is used to copy the attributes
	 * from objects to create a new datagraph.
	 * 
	 * @param obj
	 *            The object that will be copied.
	 * @return A shallow copy of the given object.
	 */
	@SuppressWarnings({ "unused", "serial" })
	private static EObject copyAttributes(EObject obj) {
		Copier copier = new Copier() {
			@Override
			protected void copyContainment(EReference eReference, EObject eObject, EObject copyEObject) {
			}
		};
		EObject result = copier.copy(obj);
		copier.copyReferences();
		return result;
	}
}
