/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.sm.service;

import java.net.URI;
import java.net.URISyntaxException;
import java.rmi.AccessException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.Registry;

import org.apache.log4j.Logger;
import org.eodisp.core.common.ReposModelService;
import org.eodisp.core.common.SmCoreService;
import org.eodisp.core.sm.application.SmAppModuleCore;
import org.eodisp.core.sm.config.SmConfiguration;
import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.configuration.ConfigurationException;

/**
 * @author eglimi
 * @version $Id:$
 * 
 */
public class SmCoreServiceImpl implements SmCoreService {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(SmCoreServiceImpl.class);

	private static SmCoreServiceImpl INSTANCE = new SmCoreServiceImpl();

	/**
	 * Enforce {@link #getInstance()}
	 * 
	 */
	private SmCoreServiceImpl() {
	}

	/**
	 * Return the only instance of this class (singleton).
	 * 
	 * @return The only instance of this class.
	 */
	public static SmCoreServiceImpl getInstance() {
		return INSTANCE;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @throws URISyntaxException
	 * @throws NotBoundException
	 * @throws RemoteException
	 * @throws AccessException
	 * 
	 * @throws ConfigurationException
	 */
	public void connectToRepos() throws URISyntaxException, AccessException, RemoteException, NotBoundException {
		if (!isReposConnected()) {
			URI reposUri;
			Registry registry;
			reposUri = ((SmConfiguration) AppRegistry.getRootApp().getConfiguration(SmConfiguration.ID)).getReposUri();
			RemoteAppModule remoteAppModule = (RemoteAppModule) AppRegistry.getRootApp().getAppModule(
					RemoteAppModule.ID);

			registry = remoteAppModule.getRegistry(reposUri);

			logger.debug(String.format("Created proxy for remote registry: %s", registry));

			// set the service in the app module for further reference
			ReposModelService reposService = (ReposModelService) registry.lookup(ReposModelService.REGISTRY_NAME);
			((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(SmAppModuleCore.ID)).setReposService(reposService);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isReposConnected() {
		return ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(SmAppModuleCore.ID)).getReposService() == null ? false
				: true;
	}

}
