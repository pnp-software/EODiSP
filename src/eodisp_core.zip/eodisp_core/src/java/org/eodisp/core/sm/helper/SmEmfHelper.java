/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.sm.helper;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eodisp.core.common.EmfUtil;
import org.eodisp.core.common.ReposServiceProxy;
import org.eodisp.core.gen.repository.impl.RepositoryPackageImpl;
import org.eodisp.core.gen.smproject.impl.SmprojectPackageImpl;
import org.eodisp.core.sm.config.SmConfiguration;
import org.eodisp.util.configuration.Configuration;

import commonj.sdo.DataGraph;
import commonj.sdo.DataObject;

/**
 * @author eglimi
 * @version $Id:$
 */
public class SmEmfHelper {
	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(SmEmfHelper.class);

	/**
	 * Copies data from the local configuration to the repository data.
	 * 
	 * @param reposSm
	 *            The simulation manager object from the repository.
	 * @param config
	 *            The configuration.
	 * @see Configuration
	 */
	public static void copyApplicationData(DataObject reposSm, Configuration config) {
		// get the data from the application
		String appName = config.getEntry(SmConfiguration.APP_NAME).getValue();
		String appId = config.getEntry(SmConfiguration.APP_ID).getValue();
		String appDescription = config.getEntry(SmConfiguration.APP_DESCRIPTION).getValue();
		String appOwnerFirstname = config.getEntry(SmConfiguration.APP_OWNER_FIRSTNAME).getValue();
		String appOwnerSurname = config.getEntry(SmConfiguration.APP_OWNER_SURNAME).getValue();
		String appOwnerTel = config.getEntry(SmConfiguration.APP_OWNER_TEL).getValue();
		String appOwnerMail = config.getEntry(SmConfiguration.APP_OWNER_MAIL).getValue();
		String custom1 = config.getEntry(SmConfiguration.APP_OWNER_CUSTOM_1).getValue();
		String custom2 = config.getEntry(SmConfiguration.APP_OWNER_CUSTOM_2).getValue();
		String custom3 = config.getEntry(SmConfiguration.APP_OWNER_CUSTOM_3).getValue();

		// copy the data to the destination
		reposSm.setString(RepositoryPackageImpl.SIM_MANAGER__ID, appId);
		reposSm.setString(RepositoryPackageImpl.SIM_MANAGER__NAME, appName);
		reposSm.setString(RepositoryPackageImpl.SIM_MANAGER__DESCRIPTION, appDescription);

		DataObject appOwner = reposSm.getDataObject(RepositoryPackageImpl.SIM_MANAGER__APP_OWNER);
		if (appOwner == null) {
			appOwner = reposSm.createDataObject(RepositoryPackageImpl.SIM_MANAGER__APP_OWNER);
		}
		appOwner.setString(RepositoryPackageImpl.APP_OWNER__FIRSTNAME, appOwnerFirstname);
		appOwner.setString(RepositoryPackageImpl.APP_OWNER__SURNAME, appOwnerSurname);
		appOwner.setString(RepositoryPackageImpl.APP_OWNER__TEL, appOwnerTel);
		appOwner.setString(RepositoryPackageImpl.APP_OWNER__MAIL, appOwnerMail);
		appOwner.setString(RepositoryPackageImpl.APP_OWNER__CUSTOM1, custom1);
		appOwner.setString(RepositoryPackageImpl.APP_OWNER__CUSTOM2, custom2);
		appOwner.setString(RepositoryPackageImpl.APP_OWNER__CUSTOM3, custom3);
	}

	public static DataObject findSmProject(DataGraph dg) {
		if (dg == null) {
			logger.debug("The provided data graph object is null. Terminate search.");
			return null;
		}

		return dg.getRootObject().getDataObject(SmprojectPackageImpl.DOCUMENT_ROOT__PROJECT);
	}

	@SuppressWarnings("unchecked")
	public static List<DataObject> findFederationExecutionsForExperiment(DataObject experiment) {
		if (experiment == null) {
			logger.debug("The provided experiment object is null. Terminate search.");
			return null;
		}

		return experiment.getList(SmprojectPackageImpl.EXPERIMENT__FEDERATION_EXECUTION);
	}

	@SuppressWarnings("unchecked")
	public static DataObject findFederationExecutionForLocalFederat(DataObject experiment, DataObject localFederate) {
		if (experiment == null) {
			logger.debug("The provided experiment object null. Terminate search.");
			return null;
		}

		if (localFederate == null) {
			logger.debug("The provided federate object null. Terminate search.");
			return null;
		}

		// search through the lists...

		// first experiment -> federation executions
		List<DataObject> federationExecutions = experiment
				.getList(SmprojectPackageImpl.EXPERIMENT__FEDERATION_EXECUTION);
		for (DataObject federationExecution : federationExecutions) {

			// then federation executions -> federates
			List<DataObject> federates = federationExecution
					.getList(SmprojectPackageImpl.FEDERATION_EXECUTION__FEDERATE_EXECUTIONS);
			for (DataObject federate : federates) {
				if (federate.equals(localFederate)) {
					return federationExecution;
				}
			}
		}

		return null;
	}

	@SuppressWarnings("unchecked")
	public static DataObject findLocalFederateForInitData(DataObject experiment, DataObject initData) {
		if (experiment == null) {
			logger.debug("The provided experiment object null. Terminate search.");
			return null;
		}

		if (initData == null) {
			logger.debug("The provided init data object null. Terminate search.");
			return null;
		}

		// search through the lists...

		// first experiment -> federation executions
		List<DataObject> federationExecutions = experiment
				.getList(SmprojectPackageImpl.EXPERIMENT__FEDERATION_EXECUTION);
		for (DataObject federationExecution : federationExecutions) {

			// then federation executions -> federates
			List<DataObject> federates = federationExecution
					.getList(SmprojectPackageImpl.FEDERATION_EXECUTION__FEDERATE_EXECUTIONS);
			for (DataObject federate : federates) {

				// then federates -> list of init data
				List<DataObject> initDatums = federate.getList(SmprojectPackageImpl.FEDERATE_EXECUTION__INIT_DATA);
				for (DataObject initDatum : initDatums) {
					if (initDatum.equals(initData)) {
						return federate;
					}
				}
			}
		}

		return null;
	}

	@SuppressWarnings("unchecked")
	public static List<DataObject> findAllExperiments(DataObject localRoot) {
		if (localRoot == null) {
			logger.debug("The provided root object is null. Terminate search.");
			return null;
		}

		return localRoot.getList(SmprojectPackageImpl.SM_PROJECT__EXPERIMENTS);
	}

	@SuppressWarnings("unchecked")
	public static List<DataObject> findAllReposSoms(DataObject reposRoot) {
		if (reposRoot == null) {
			logger.debug("The provided root object is null. Terminate search.");
			return null;
		}

		return reposRoot.getList(RepositoryPackageImpl.REPOSITORY__SOMS);
	}

	@SuppressWarnings("unchecked")
	public static List<EDataObject> findAllFederationExecutionsForExperiment(DataObject experiment) {
		if (experiment == null) {
			logger.debug("The provided experiment object is null. Terminate search.");
			return null;
		}

		return experiment.getList(SmprojectPackageImpl.EXPERIMENT__FEDERATION_EXECUTION);
	}

	@SuppressWarnings("unchecked")
	public static List<DataObject> findAllFederates(DataObject reposRoot) {
		if (reposRoot == null) {
			logger.debug("The provided repository root object is null. Terminate search.");
			return null;
		}

		return reposRoot.getList(RepositoryPackageImpl.REPOSITORY__FEDERATES);
	}

	@SuppressWarnings("unchecked")
	public static List<DataObject> findAllFederatesForFederationExecution(DataObject federationExecution) {
		if (federationExecution == null) {
			logger.debug("The provided federation execution object is null. Terminate search.");
			return null;
		}

		return federationExecution.getList(SmprojectPackageImpl.FEDERATION_EXECUTION__FEDERATE_EXECUTIONS);
	}

	@SuppressWarnings("unchecked")
	public static List<DataObject> findAllInitDataForFederate(DataObject federate) {
		if (federate == null) {
			logger.debug("The provided federate object is null. Terminate search.");
			return null;
		}

		return federate.getList(SmprojectPackageImpl.FEDERATE_EXECUTION__INIT_DATA);
	}

	public static DataObject findSomForReposFederate(DataObject reposFed) {
		if (reposFed == null) {
			logger.debug("The provided federate object null. Terminate search.");
			return null;
		}

		return reposFed.getDataObject(RepositoryPackageImpl.FEDERATE__SOM);
	}

	@SuppressWarnings("unchecked")
	public static List<DataObject> findCategoriesForSom(DataObject som) {
		if (som == null) {
			logger.debug("The provided som object null. Terminate search.");
			return null;
		}

		return som.getList(RepositoryPackageImpl.SOM__CATEGORIES);
	}

	@SuppressWarnings("unchecked")
	public static DataObject findReposFederate(DataObject reposRoot, DataObject localFederate) {
		if (reposRoot == null) {
			logger.debug("The provided root object is null. Terminate search.");
			return null;
		}

		if (localFederate == null) {
			logger.debug("The provided local federate object is null. Terminate search.");
			return null;
		}

		String federateId = localFederate.getString(SmprojectPackageImpl.FEDERATE_EXECUTION__REMOTE_ID);

		List<DataObject> reposFederates = reposRoot.getList(RepositoryPackageImpl.REPOSITORY__FEDERATES);
		for (DataObject reposFederate : reposFederates) {
			if (reposFederate.getString(RepositoryPackageImpl.FEDERATE__ID).equals(federateId)) {
				return reposFederate;
			}
		}

		return null;
	}

	public static String getModelManagerNameForFederate(EDataObject reposRoot, EDataObject localFederate) {
		DataObject reposFederate = findReposFederate(reposRoot, localFederate);
		if (reposFederate != null) {
			DataObject modelManager = reposFederate.getDataObject(RepositoryPackageImpl.FEDERATE__OWNING_MM);
			if (modelManager != null) { // should never be null!
				return modelManager.getString(RepositoryPackageImpl.MODEL_MANAGER__NAME);
			}
		}

		return "";
	}

	public static String getFederateInfo(DataObject reposFederate) {
		StringBuilder sb = new StringBuilder();
		String fedName = "";
		String fedVersion = "";
		String fedId = "";
		String fedInfo = "";
		String mmName = "";
		String mmDescription = "";
		String ownerFirstName = "";
		String ownerSurName = "";
		String ownerMail = "";
		String ownerTel = "";
		String ownerCountry = "";
		String ownerCustom1 = "";
		String ownerCustom2 = "";
		String ownerCustom3 = "";
		String somName = "";
		String somVersion = "";
		String somDescription = "";

		if (reposFederate != null) {
			DataObject modelManager = reposFederate.getDataObject(RepositoryPackageImpl.FEDERATE__OWNING_MM);
			DataObject som = reposFederate.getDataObject(RepositoryPackageImpl.FEDERATE__SOM);
			DataObject federateOwner = modelManager.getDataObject(RepositoryPackageImpl.MODEL_MANAGER__APP_OWNER);

			fedName = reposFederate.getString(RepositoryPackageImpl.FEDERATE__BUNDLE_NAME);
			fedVersion = reposFederate.getString(RepositoryPackageImpl.FEDERATE__BUNDLE_VERSION);
			fedId = reposFederate.getString(RepositoryPackageImpl.FEDERATE__BUNDLE_SYMBOLIC_NAME);
			fedInfo = reposFederate.getString(RepositoryPackageImpl.FEDERATE__DESCRIPTION);

			if (modelManager != null) {
				mmName = modelManager.getString(RepositoryPackageImpl.MODEL_MANAGER__NAME);
				mmDescription = modelManager.getString(RepositoryPackageImpl.MODEL_MANAGER__DESCRIPTION);
			}

			if (som != null) {
				somName = som.getString(RepositoryPackageImpl.SOM__NAME);
				somVersion = som.getString(RepositoryPackageImpl.SOM__VERSION);
				somDescription = som.getString(RepositoryPackageImpl.SOM__DESCRIPTION);
			}

			if (federateOwner != null) {
				ownerFirstName = federateOwner.getString(RepositoryPackageImpl.APP_OWNER__FIRSTNAME);
				ownerSurName = federateOwner.getString(RepositoryPackageImpl.APP_OWNER__SURNAME);
				ownerMail = federateOwner.getString(RepositoryPackageImpl.APP_OWNER__MAIL);
				ownerTel = federateOwner.getString(RepositoryPackageImpl.APP_OWNER__TEL);
				ownerCountry = federateOwner.getString(RepositoryPackageImpl.APP_OWNER__COUNTRY);
				ownerCustom1 = federateOwner.getString(RepositoryPackageImpl.APP_OWNER__CUSTOM1);
				ownerCustom2 = federateOwner.getString(RepositoryPackageImpl.APP_OWNER__CUSTOM2);
				ownerCustom3 = federateOwner.getString(RepositoryPackageImpl.APP_OWNER__CUSTOM3);
			}
		}

		sb.append("<html>");
		sb.append("<head></head>");
		sb.append("<body>");

		sb.append("<div class='section'>");
		sb.append("<h1>Federate Info</h1>");
		sb.append(String.format("<br><strong>Name</strong>: %s", fedName));
		sb.append(String.format("<br><strong>Version</strong>: %s", fedVersion));
		sb.append(String.format("<br><strong>Id:</strong> %s", fedId));
		sb.append(String.format("<br><strong>Additional Information:</strong> %s", fedInfo));
		sb.append("</div>");

		sb.append("<div class='section'>");
		sb.append("<h1>Simulation Object Model (SOM) Info</h1>");
		sb.append(String.format("<br><strong>Name</strong>: %s", somName));
		sb.append(String.format("<br><strong>Version</strong>: %s", somVersion));
		sb.append(String.format("<br><strong>Description</strong>: %s", somDescription));
		sb.append("</div>");

		sb.append("<div class='section'>");
		sb.append("<h1>Model Manager Info</h1>");
		sb.append(String.format("<br><strong>Name</strong>: %s", mmName));
		sb.append(String.format("<br><strong>Description</strong>: %s", mmDescription));
		sb.append("</div>");

		sb.append("<div class='section'>");
		sb.append("<h1>Owner Info</h1>");
		sb.append(String.format("<br><strong>Name</strong>: %s, %s", ownerFirstName, ownerSurName));
		sb.append(String.format("<br><strong>E-Mail</strong>: %s", ownerMail));
		sb.append(String.format("<br><strong>Tel</strong>: %s", ownerTel));
		sb.append(String.format("<br><strong>Country</strong>: %s", ownerCountry));
		sb.append(String.format("<br><strong>Custom Info 1</strong>: %s", ownerCustom1));
		sb.append(String.format("<br><strong>Custom Info 2</strong>: %s", ownerCustom2));
		sb.append(String.format("<br><strong>Custom Info 3</strong>: %s", ownerCustom3));
		sb.append("</div>");

		sb.append("</body></html>");

		return sb.toString();
	}

	public static EDataObject addNewExperiment(DataObject reposRoot, String name) throws IllegalArgumentException {
		if (reposRoot == null) {
			throw new IllegalArgumentException("The provided root object is null. Cannot add a experiment object");
		}

		EDataObject experiment = (EDataObject) reposRoot.createDataObject(SmprojectPackageImpl.SM_PROJECT__EXPERIMENTS);
		if (experiment != null) {
			experiment.setString(SmprojectPackageImpl.EXPERIMENT__NAME, name);
		}

		return experiment;
	}

	public static void addNewFederationExecution(DataObject experiment, String name) throws IllegalArgumentException {
		if (experiment == null) {
			logger.debug("The provided experiment object is null. Terminate search.");
			throw new IllegalArgumentException("The provided experiment object is null. Terminate search.");
		}

		DataObject federationExecution = experiment
				.createDataObject(SmprojectPackageImpl.EXPERIMENT__FEDERATION_EXECUTION);
		if (federationExecution != null) {
			federationExecution.setString(SmprojectPackageImpl.FEDERATION_EXECUTION__NAME, name);
		}
	}

	@SuppressWarnings("unchecked")
	public static void addNewFederateExecution(DataObject federationExecution, DataObject reposFederate)
			throws IllegalArgumentException {
		if (federationExecution == null) {
			throw new IllegalArgumentException("The provided experiment object is null. Cannot add to a null object");
		}

		if (reposFederate == null) {
			throw new IllegalArgumentException(
					"The provided repository federate object is null. Cannot add a null object.");
		}

		String remoteId = reposFederate.getString(RepositoryPackageImpl.FEDERATE__ID);
		String name = reposFederate.getString(RepositoryPackageImpl.FEDERATE__BUNDLE_NAME);

		// get the root (the SmProject)
		DataObject localRoot = federationExecution.getDataGraph().getRootObject().getDataObject(
				SmprojectPackageImpl.DOCUMENT_ROOT__PROJECT);

		// create the local federate
		DataObject federateExecution = localRoot.createDataObject(SmprojectPackageImpl.SM_PROJECT__FEDERATE_EXECUTIONS);
		if (federateExecution != null) {
			// add the federate to the federation execution.
			federateExecution.setString(SmprojectPackageImpl.FEDERATE_EXECUTION__NAME, name);
			federateExecution.setString(SmprojectPackageImpl.FEDERATE_EXECUTION__REMOTE_ID, remoteId);
			List<DataObject> federates = federationExecution
					.getList(SmprojectPackageImpl.FEDERATION_EXECUTION__FEDERATE_EXECUTIONS);
			federates.add(federateExecution);
		}
	}

	@SuppressWarnings("unchecked")
	public static void addNewInitData(DataObject localFederate, File initDataFile, String description)
			throws IllegalArgumentException {
		if (localFederate == null) {
			throw new IllegalArgumentException("The provided local federate object is null. Cannot add a null object");
		}

		if (initDataFile == null) {
			throw new IllegalArgumentException("The provided init data filet is null. Cannot add a null object.");
		}

		// get the root (the SmProject)
		DataObject localRoot = localFederate.getDataGraph().getRootObject().getDataObject(
				SmprojectPackageImpl.DOCUMENT_ROOT__PROJECT);

		// create the init data object
		DataObject initData = localRoot.createDataObject(SmprojectPackageImpl.SM_PROJECT__INIT_DATA);
		if (initData != null) {
			// add the init data to the federate
			initData.setString(SmprojectPackageImpl.INIT_DATA__DESCRIPTION, description);
			initData.setString(SmprojectPackageImpl.INIT_DATA__LOCAL_PATH, initDataFile.getPath());
			localFederate.getList(SmprojectPackageImpl.FEDERATE_EXECUTION__INIT_DATA).add(initData);
		}
	}

	/**
	 * @see #getName(Object, String)
	 */
	public static String getName(Object object) {
		return getName(object, null);
	}

	/**
	 * Returns a string representing the name of the given object. The object
	 * must be of type <code>EDataObject</code>.
	 * 
	 * @param object
	 *            The object whose name should be returned.
	 * @param propertyName
	 *            The name of the property that holds the value representing the
	 *            name of the given object. If this parameter is
	 *            <code>null</code> or the empty string, <code>"name"</code>
	 *            will be assumed as the right name of the property.
	 * @return A string representing the name of this object or the empty
	 *         string, if either the give object is <code>null</code> or the
	 *         property could not be found.
	 */
	@SuppressWarnings("unchecked")
	public static String getName(Object object, String propertyName) {
		if (object == null) {
			final String message = "Cannot get the name of the object, because the provided object is null";
			logger.debug(message);
			return "";
		}

		if (!(object instanceof EDataObject)) {
			final String message = "The provided object is not of type EDataObject";
			logger.warn(message);
			return "";
		}

		EDataObject dataObject = (EDataObject) object;

		String nodeString = "";
		List<Object> props = dataObject.getInstanceProperties();
		for (int i = 0; i < props.size(); i++) {
			if (dataObject.isSet(i)) {
				Object obj = props.get(i);
				if (obj instanceof EAttribute) {
					EAttribute prop = (EAttribute) props.get(i);
					if (prop.getName().equalsIgnoreCase(
							(propertyName == null || propertyName.equals("")) ? "name" : propertyName)) {
						nodeString = dataObject.getString(i);
					}
				}
			}
		}

		// if nothing is found, return the string representation of the object
		// (this indicates an error).
		return (nodeString != null && !nodeString.equals("")) ? nodeString : object.toString();
	}

	public static boolean isExperiment(Object object) {
		if (object != null && object instanceof EDataObject) {
			return ((EDataObject) object).eClass().getClassifierID() == SmprojectPackageImpl.EXPERIMENT;
		}

		return false;
	}

	public static boolean isFederationExecution(Object object) {
		if (object != null && object instanceof EDataObject) {
			return ((EDataObject) object).eClass().getClassifierID() == SmprojectPackageImpl.FEDERATION_EXECUTION;
		}

		return false;
	}

	public static boolean isLocalFederate(Object object) {
		if (object != null && object instanceof EDataObject) {
			return ((EDataObject) object).eClass().getClassifierID() == SmprojectPackageImpl.FEDERATE_EXECUTION;
		}

		return false;
	}

	public static boolean isInitData(Object object) {
		if (object != null && object instanceof EDataObject) {
			return ((EDataObject) object).eClass().getClassifierID() == SmprojectPackageImpl.INIT_DATA;
		}

		return false;
	}

	public static EDataObject findReposSimulationManager(DataObject reposRoot, String smId)
			throws IllegalArgumentException {

		if (reposRoot == null) {
			final String message = "The provided root object must not be null and of type DataObject";
			logger.warn(message);
			throw new IllegalArgumentException(message);
		}

		return (EDataObject) reposRoot.getDataObject(String.format("simManagers[id=%s]", smId));
	}

	public static void removeExperimentChildren(DataObject experiment) {
		List<DataObject> federationsToRemove = new ArrayList<DataObject>(
				findFederationExecutionsForExperiment(experiment));
		for (DataObject federation : federationsToRemove) {

			removeFederationChildren(federation);

			EmfUtil.delete((EObject) federation);
		}
	}

	public static void removeFederationChildren(DataObject federation) {
		List<DataObject> federatesToRemove = new ArrayList<DataObject>(
				findAllFederatesForFederationExecution(federation));
		for (DataObject federate : federatesToRemove) {

			removeFederateChildren(federate);

			EmfUtil.delete((EObject) federate);
		}

	}

	public static void removeFederateChildren(DataObject federate) {
		List<DataObject> initDataToRemove = new ArrayList<DataObject>(findAllInitDataForFederate(federate));
		for (DataObject initData : initDataToRemove) {
			EmfUtil.delete((EObject) initData);
		}
	}
}
