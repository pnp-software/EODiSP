/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.common;

import java.io.IOException;
import java.rmi.Remote;
import java.rmi.RemoteException;

import org.eclipse.emf.ecore.sdo.EDataGraph;

/**
 * This is the service that can be used to access data store in the model
 * repository. This interface is exported by the eodisp_remote package.
 * Therefore, any remote application can use it.
 * 
 * @author eglimi
 * @version $Id:$
 */
public interface ReposModelService extends Remote {

	/**
	 * This name is used for two purposes:
	 * <ul>
	 * <li>The model repository application will export this interface with
	 * this name (through the eodisp_remote package)</li>
	 * <li>All applications can perform a lookup on this name to find the
	 * remote (this) interface (through the eodisp_remote package)</li>
	 * </ul>
	 */
	public static final String REGISTRY_NAME = "reposService";

	/**
	 * Returns all data currently stored in the model repository.
	 * 
	 * @return An EDataGraph containing the data.
	 * @throws RemoteException
	 *             see documentation of {@link RemoteException}
	 * @throws IOException
	 *             Thrown if there is a problem loading the data.
	 */
	public EDataGraph getAllData() throws RemoteException, IOException;

	/**
	 * Updates a data graph in the resource. The resource is the XML file that
	 * holds the repository instance data.
	 * <p>
	 * Updates are performed (saved) immediately, without any chance to undo
	 * changes.
	 * 
	 * @param dataGraph
	 *            The data graph with the changes to be committed.
	 * @throws RemoteException
	 *             see documentation of {@link RemoteException}
	 * @throws IOException
	 *             thrown if there is a problem while saving the data to the
	 *             disk.
	 */
	public void update(EDataGraph dataGraph) throws RemoteException, IOException;

	/**
	 * Adds a physical SOM file to the repository. The SOM file will be locally
	 * stored in a location specified in the configuration.
	 * 
	 * @param somFile
	 *            The object containing the physical file.
	 * @return The path at which the file has been stored.
	 * @throws RemoteException
	 *             see documentation of {@link RemoteException}
	 * @throws IOException
	 *             thrown if the file could not be save in the repository.
	 */
	public String addSom(SomFile somFile) throws RemoteException, IOException;

	/**
	 * Reads a SOM file locally in the repository and returns it. This is a file
	 * that has been stored with {@link #addSom(SomFile)} method.
	 * <p>
	 * The name and version of the SOM will be used to lookup the location of
	 * the file on the file system.
	 * 
	 * @param somName
	 *            The name of the SOM.
	 * @param somVersion
	 *            The version of the SOM.
	 * @return An instance of {@link SomFile}, including the byte array
	 *         representing the data. It always returns a non null object. In
	 *         case of an error, an exception will be thrown, but never will be
	 *         a <code>null</code> object returned.
	 * @throws RemoteException
	 *             see documentation of {@link RemoteException}
	 * @throws SomNotKnownException
	 *             thrown if no SOM file could be found that corresponds to the
	 *             given somName and somVersion.
	 * @throws IOException
	 *             thrown in case of an error when reading the file or if the
	 *             file is too large.
	 */
	public SomFile getSom(String somName, String somVersion) throws RemoteException, SomNotKnownException, IOException;

	/**
	 * Deletes the physical SOM file that is locally stored on in the
	 * repository. The SOM file is identified by the name and version of the
	 * SOM. The repository model will be queried to find the location of the
	 * file.
	 * <p>
	 * An exception will be thrown if the file cannot be deleted, otherwise, the
	 * deletion process has succeeded.
	 * 
	 * @param somName
	 *            The name of SOM.
	 * @param somVersion
	 *            The version of the SOM.
	 * @throws RemoteException
	 *             see documentation of {@link RemoteException}
	 * @throws SomNotKnownException
	 *             thrown if no SOM file could be found that corresponds to the
	 *             given somName and somVersion.
	 */
	public void deleteSom(String somName, String somVersion) throws RemoteException, SomNotKnownException;
}
