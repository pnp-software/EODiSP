/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.sm.application;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.rmi.registry.Registry;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.eodisp.core.common.ReposModelService;
import org.eodisp.core.common.ReposServiceProxy;
import org.eodisp.core.gen.repository.impl.RepositoryPackageImpl;
import org.eodisp.core.mm.config.MmConfiguration;
import org.eodisp.core.sm.config.SmConfiguration;
import org.eodisp.core.sm.service.*;
import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.util.AppModule;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.RootApp;
import org.eodisp.util.configuration.CommandlineMapper;

/**
 * @author eglimi
 * @version $Id:$
 */
public class SmAppModuleCore implements AppModule {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(SmAppModuleCore.class);

	private ReposModelService reposService;

	private final ExperimentTaskManager experimentTaskManager = new ExperimentTaskManager();

	private final SmCoreServiceProxy smCoreServiceProxy = new SmCoreServiceProxy();

	private final SmModelReader modelReader = new SmModelReader();

	private ReposServiceProxy reposServiceProxy = null;

	private final SmModelServiceProxy smModelServiceProxy = new SmModelServiceProxy();

	/**
	 * The Id of this Application Module.
	 */
	public static final String ID = "org.eodisp.core.sm.application.SmAppModuleCore";

	/**
	 * The name of the configuration file for the simulation manager application
	 * proper.
	 */
	private static final String CONFIG_FILE_MAIN = "sm_core.conf";

	/**
	 * {@inheritDoc}
	 */
	public String getId() {
		return ID;
	}

	/**
	 * {@inheritDoc}
	 */
	public void registerConfiguration(RootApp rootApp) throws Exception {
		File configFileMain = new File(rootApp.getConfigurationDir(), CONFIG_FILE_MAIN);
		SmConfiguration smConfigMain = new SmConfiguration(configFileMain);

		// register configurations
		rootApp.registerConfiguration(smConfigMain, CommandlineMapper.BASIC_COMMAND_LINE_MAPPER);
	}

	/**
	 * {@inheritDoc}
	 */
	public void startup(RootApp rootApp) throws Exception {
		if (getSmConfiguration().isRemoteTestSupport()) {
			logger.warn("Remote administration enabled for simulation manager. "
					+ "Make sure you only turn this on for debug and testing purposes.");
			@SuppressWarnings("unused")
			Registry registry = getRemoteAppModule().getRegistry();
		}

		// load the model
		modelReader.load();

		// load the model in the proxy. This could be changed to require the
		// user to press a button.
		smModelServiceProxy.load();
	}

	/**
	 * {@inheritDoc}
	 */
	public void preStartup(RootApp rootApp) throws Exception {
		// init emf for the repository service
		RepositoryPackageImpl.eINSTANCE.getName();

		ensureAppId();
	}

	/**
	 * {@inheritDoc}
	 */
	public void shutdown(RootApp rootApp) throws Exception {
		// TODO Auto-generated method stub

	}

	/**
	 * {@inheritDoc}
	 */
	public void postShutdown(RootApp rootApp) throws Exception {
		// TODO Auto-generated method stub

	}

	/**
	 * Returns a reference to the repository service or null, if it is not
	 * connected. It is your job to connect to the repository.
	 * 
	 * @return A reference to the repository service or null.
	 */
	public ReposModelService getReposService() {
		return reposService;
	}

	/**
	 * Sets the reference to the repository service. It can then be retrieved
	 * from here by the whole application.
	 * 
	 * @param service
	 *            The reference to the repository service.
	 */
	public void setReposService(ReposModelService service) {
		reposService = service;
	}

	/**
	 * Returns the configuration for the simulation manager. This is just a
	 * convenient method.
	 * 
	 * @return The configuration for the simulation manager.
	 */
	private SmConfiguration getSmConfiguration() {
		return (SmConfiguration) AppRegistry.getRootApp().getConfiguration(SmConfiguration.ID);
	}

	/**
	 * Returns the remote application module for the simulation manager. This is
	 * just a convenient method.
	 * 
	 * @return The remote application module for the simulation manager.
	 */
	private RemoteAppModule getRemoteAppModule() {
		return (RemoteAppModule) AppRegistry.getRootApp().getAppModule(RemoteAppModule.ID);
	}

	/**
	 * This ensures that this application has a valid application id.
	 */
	private void ensureAppId() {
		
		// check id
		String appId = getSmConfiguration().getEntry(SmConfiguration.APP_ID).getValue();
		if (appId == null || appId.equals("")) {
			appId = UUID.randomUUID().toString();
			getSmConfiguration().getEntry(MmConfiguration.APP_ID).setValue(appId);

		}

		// check name
		String appName = getSmConfiguration().getEntry(SmConfiguration.APP_NAME).getValue();
		if (appName == null || appName.equals("")) {
			InetAddress addr;
			try {
				addr = InetAddress.getLocalHost();
				// Get hostname
				appName = addr.getHostName();
			} catch (UnknownHostException e) {
				appName = "Simulation Manager";
			}

			getSmConfiguration().getEntry(MmConfiguration.APP_NAME).setValue(appName);
		}

		try {
			getSmConfiguration().save();
		} catch (IOException e) {
			logger.error("Could not write the configuration file. "
					+ "This is serious, because the application won't have a unique Id. "
					+ "Such an Id is needed to communicate with the repository.");
		}
	}

	public ExperimentTaskManager getExperimentTaskManager() {
		return experimentTaskManager;
	}

	public ReposServiceProxy getReposServiceProxy() {
		if (reposServiceProxy == null) {
			if (getSmCoreServiceProxy().isReposConnected()) {
				ReposModelService service = ((SmAppModuleCore) AppRegistry.getRootApp()
						.getAppModule(SmAppModuleCore.ID)).getReposService();
				if (service != null) {
					reposServiceProxy = new ReposServiceProxy(service);
				}
			}
		}

		return reposServiceProxy;
	}

	public SmCoreServiceProxy getSmCoreServiceProxy() {
		return smCoreServiceProxy;
	}

	public SmModelServiceProxy getSmModelServiceProxy() {
		return smModelServiceProxy;
	}

	/**
	 * @return Returns the modelReader.
	 */
	public SmModelReader getModelReader() {
		return modelReader;
	}
}
