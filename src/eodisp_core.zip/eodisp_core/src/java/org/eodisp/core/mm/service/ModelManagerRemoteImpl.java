/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.mm.service;

import java.net.URI;
import java.rmi.RemoteException;

import org.apache.log4j.Logger;
import org.eodisp.core.common.*;
import org.eodisp.core.mm.application.MmAppModuleCore;
import org.eodisp.core.mm.config.MmConfiguration;
import org.eodisp.core.mm.helper.MmEmfHelper;
import org.eodisp.util.AppRegistry;

/**
 * @author ibirrer, eglimi
 * @version $Id:$
 */
public class ModelManagerRemoteImpl implements ModelManagerRemote {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(ModelManagerRemoteImpl.class);

	/**
	 * {@inheritDoc}
	 */
	public FederateProcessHandle lockFederate(String simulationManagerId, String experimentName, String federateId, String federateVersion)
			throws FederateAccessException, FederateNotKnownException {

		// check config
		boolean checkPermissions = ((MmConfiguration) AppRegistry.getRootApp().getConfiguration(MmConfiguration.ID))
				.isCheckPermissions();

		if (checkPermissions) {
			logger.debug(String.format(
					"Check if simulation manager with id %s has permission to use federate with id %s and versions %s",
					simulationManagerId, federateId, federateVersion));
			
			ReposServiceProxy service = ((MmAppModuleCore) AppRegistry.getRootApp().getAppModule(MmAppModuleCore.ID))
					.getReposServiceProxy();

			if (service == null) {
				throw new FederateAccessException(simulationManagerId, federateId, federateVersion);
			}

			if (!MmEmfHelper.hasPermission(service.getRootObject(), federateId, federateVersion, simulationManagerId)) {
				throw new FederateAccessException(simulationManagerId, federateId, federateVersion);
			}
		}

		MmFederateProcessManager processManager = ((MmAppModuleCore) AppRegistry.getRootApp().getAppModule(
				MmAppModuleCore.ID)).getFederateProcessManager();

		return processManager.lockFederate(simulationManagerId, experimentName, federateId, federateVersion);
	}
	
	/**
	 * 
	 * {@inheritDoc}
	 */
	public void updateLock(FederateProcessHandle handle) {
		MmFederateProcessManager processManager = ((MmAppModuleCore) AppRegistry.getRootApp().getAppModule(
				MmAppModuleCore.ID)).getFederateProcessManager();
		processManager.updateLock(handle);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean startFederate(FederateProcessHandle handle, URI crc, String federationExecutionName,
			FileInitData[] fileInitData) throws FederateStartException {

		MmFederateProcessManager processManager = ((MmAppModuleCore) AppRegistry.getRootApp().getAppModule(
				MmAppModuleCore.ID)).getFederateProcessManager();
		return processManager.startFederate(handle, crc, federationExecutionName, fileInitData);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean stopFederate(FederateProcessHandle handle) throws RemoteException {
		MmFederateProcessManager processManager = ((MmAppModuleCore) AppRegistry.getRootApp().getAppModule(
				MmAppModuleCore.ID)).getFederateProcessManager();
		return processManager.stopFederate(handle);
	}

}
