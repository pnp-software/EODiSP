/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.common;

import java.io.*;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.sdo.EChangeSummary;
import org.eclipse.emf.ecore.sdo.EDataGraph;
import org.eclipse.emf.ecore.util.EcoreUtil;

/**
 * @author eglimi
 * @version $Id:$
 */
public final class EmfUtil {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(EmfUtil.class);

	/**
	 * No instance should be create. This is a utility class with static methods
	 * only.
	 */
	private EmfUtil() {
	}

	/**
	 * A delete method that removes an object from its containing resource and
	 * handles cross references if necessary.
	 * <p>
	 * It only handles cross references in one document. Handling of references
	 * within multiple documents in one resource set is not supported.
	 */
	public static void delete(EObject eObject) {
		EObject rootEObject = EcoreUtil.getRootContainer(eObject);

		Collection usages = null;
		if (rootEObject != null) {
			usages = EcoreUtil.UsageCrossReferencer.find(eObject, rootEObject);

			for (Iterator i = usages.iterator(); i.hasNext();) {
				EStructuralFeature.Setting setting = (EStructuralFeature.Setting) i.next();
				if (setting.getEStructuralFeature().isChangeable()) {
					EcoreUtil.remove(setting, eObject);
				}
			}
		}

		EcoreUtil.remove(eObject);
	}

	public static synchronized void updateDataGraph(EDataGraph origDg, EDataGraph changedDg,
			File modelFile, HashMap options) throws IOException {
		ByteArrayOutputStream buf;

		EChangeSummary changeSummary = null;
		EChangeSummary newChangeSummary = null;

		// The change summary that was sent from the client
		changeSummary = (EChangeSummary) changedDg.getChangeSummary();

		// (If still logging, turn if off)
		if (changeSummary.isLogging()) {
			changeSummary.endLogging();
		}

		// reverse the changes (this should be done on the client!)
		// changeSummary.applyAndReverse();

		// copy the changes
		buf = new ByteArrayOutputStream();

		Resource r = changeSummary.eResource();
		Resource rs = ((EChangeSummary) origDg.getChangeSummary()).eResource();
		try {
			r.save(buf, null);
			rs.unload();
			rs.load(new ByteArrayInputStream(buf.toByteArray()), null);
		} catch (IOException ex) {
			logger
					.error("The changes you have sent could not be saved into the root datagraph",
							ex);
			throw ex;
		}

		newChangeSummary = (EChangeSummary) rs.getContents().get(0);

		// set the changes in the original data graph
		origDg.setEChangeSummary(newChangeSummary);

		// re-apply the changes
		newChangeSummary.apply();

		FileOutputStream os = new FileOutputStream(modelFile);
		try {
			// save the changes to the XML resource
			origDg.getDataGraphResource().save(os, options);
		} catch (IOException ex) {
			final String message = "The datagraph could not be save to the file "
					+ modelFile.getPath();
			logger.error(message, ex);
			throw ex;
		} finally {
			os.close();
		}
	}
}
