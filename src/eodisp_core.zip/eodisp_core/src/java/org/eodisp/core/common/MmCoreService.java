/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.common;

import java.net.URISyntaxException;
import java.rmi.AccessException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

/**
 * <p>
 * The local interface for the core services of the model manager application.
 * This interface will primarily be used by the GUI component of this
 * application.
 * </p>
 * <p>
 * This interface is not exported remotely and can therefore only be used by
 * projects that are linked to this component.
 * <p>
 * 
 * @author eglimi
 * @version $Id:$
 * 
 */
public interface MmCoreService {

	/**
	 * Establishes a connection to the model repository application. This
	 * application might be locally or remotely available. To which model
	 * repository this methods tries to connect can be configured in the
	 * configuration files for the model manager application.
	 * 
	 * @throws URISyntaxException
	 *             See {@link URISyntaxException} for more information about
	 *             this exception.
	 * @throws AccessException
	 *             See {@link AccessException} for more information about this
	 *             exception.
	 * @throws RemoteException
	 *             See {@link RemoteException} for more information about this
	 *             exception.
	 * @throws NotBoundException
	 *             See {@link NotBoundException} for more information about this
	 *             exception.
	 */
	void connectToRepos() throws URISyntaxException, AccessException, RemoteException, NotBoundException;

	/**
	 * Tests if a connection to the model repository application is already
	 * established.
	 * 
	 * @return true, if a connection is established, otherwise false.
	 */
	boolean isReposConnected();

}
