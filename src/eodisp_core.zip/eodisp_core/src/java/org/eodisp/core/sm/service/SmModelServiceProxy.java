/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.sm.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.sdo.EChangeSummary;
import org.eclipse.emf.ecore.sdo.EDataGraph;
import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eclipse.emf.ecore.sdo.util.SDOUtil;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eodisp.core.common.SmModelService;
import org.eodisp.core.gen.smproject.impl.SmprojectPackageImpl;
import org.eodisp.core.sm.helper.SmEmfHelper;

/**
 * @author eglimi
 * @version $Id:$
 */
public final class SmModelServiceProxy {
	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(SmModelServiceProxy.class);

	private final HashMap options = new HashMap();

	private final SmModelService smModelService = new SmModelServiceImpl();

	private EDataGraph rootDg = null;

	public SmModelServiceProxy() {
		options.put(XMLResource.OPTION_ENCODING, "UTF-8");
		options.put(XMLResource.OPTION_USE_DEPRECATED_METHODS, Boolean.TRUE);
	}

	public void load() throws IOException {
		EDataGraph tmpDg = smModelService.getAllData();

		rootDg = copyDg(tmpDg);

		// start logging.
		if (!((EChangeSummary) rootDg.getChangeSummary()).isLogging()) {
			((EChangeSummary) rootDg.getChangeSummary()).beginLogging();
		}
	}

	public void save() throws IOException {
		if (isDirty()) {
			EDataGraph copyDg = createChangeDg(rootDg);

			smModelService.update(copyDg);

			// if ok, apply the changes here as well.
			if (rootDg.getChangeSummary().isLogging()) {
				rootDg.getChangeSummary().endLogging();
			}

			if (isDirty()) {
				((EChangeSummary) rootDg.getChangeSummary()).applyAndReverse();
				((EChangeSummary) rootDg.getChangeSummary()).apply();
			}
			
			rootDg.getChangeSummary().beginLogging();
		}
	}

	public EDataObject getRootObject() {
		return (EDataObject) SmEmfHelper.findSmProject(rootDg);
	}

	public boolean isDirty() {
		if (rootDg != null) {
			return rootDg.getChangeSummary().getChangedDataObjects().size() > 0 ? true : false;
		}

		return false;
	}

	/**
	 * Creates a copy of the given data graph and prepares the changes summary
	 * to be transferred in order to apply the changes to the persistent store.
	 * 
	 * @param dg
	 *            The data graph to be copied.
	 * @return The copy of the data graph or null, if it cannot be copied.
	 * @throws IOException
	 */
	private EDataGraph createChangeDg(EDataGraph origDg) throws IOException {
		EDataGraph copyDg = copyDg(origDg);

		// stop logging
		if (copyDg.getChangeSummary().isLogging()) {
			((EChangeSummary) copyDg.getChangeSummary()).endLogging();
		}

		// reverse the changes to get the forward change (needed by the server)
		boolean hasChanges = ((EChangeSummary) copyDg.getChangeSummary()).getChangedDataObjects()
				.size() > 0 ? true : false;
		if (hasChanges) {
			((EChangeSummary) copyDg.getChangeSummary()).applyAndReverse();
		}

		return copyDg;
	}

	/**
	 * Creates an copy of the given data graph.
	 * 
	 * @param origDg
	 *            The data graph to be copied.
	 * @return The copy of the data graph or null if it cannot be copied.
	 */
	@SuppressWarnings("unchecked")
	private EDataGraph copyDg(EDataGraph origDg) throws IOException {
		ByteArrayOutputStream buf = new ByteArrayOutputStream();
		
		ResourceSet resourceSet = SDOUtil.createResourceSet();
		resourceSet.getPackageRegistry().put(SmprojectPackageImpl.eNS_URI,
				SmprojectPackageImpl.eINSTANCE);
		Resource resource = resourceSet.createResource(URI.createURI("sm.datagraph"));

		origDg.getDataGraphResource().save(buf, options);
		resource.load(new ByteArrayInputStream(buf.toByteArray()), options);

		return (EDataGraph) resource.getContents().get(0);
	}
}
