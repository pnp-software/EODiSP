/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.sm.service;

import java.io.*;
import java.net.URI;
import java.rmi.RemoteException;
import java.rmi.registry.Registry;
import java.util.*;
import java.util.concurrent.*;

import org.apache.log4j.Logger;
import org.apache.tools.ant.types.CommandlineJava;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eodisp.core.common.FederateProcessHandle;
import org.eodisp.core.common.ModelManagerRemote;
import org.eodisp.core.sm.config.SmConfiguration;
import org.eodisp.core.sm.control.ControlFederateListenerRemote;
import org.eodisp.core.sm.control.ControlFederateRemote;
import org.eodisp.core.sm.control.application.ControlFederateMain;
import org.eodisp.core.sm.service.AcquiredExperiment.Federate;
import org.eodisp.core.sm.service.AcquiredExperiment.FederationExecution;
import org.eodisp.core.sm.service.ExperimentTaskState.ControlFederateState;
import org.eodisp.core.sm.service.ExperimentTaskState.TaskState;
import org.eodisp.hla.crc.omt.DocumentRoot;
import org.eodisp.hla.crc.omt.util.OmtResourceFactoryImpl;
import org.eodisp.hla.crc.omt.util.SomMerger;
import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.remote.config.RemoteConfiguration.TransportType;
import org.eodisp.remote.launcher.RootAppProcess;
import org.eodisp.remote.launcher.RootAppProcessImpl;
import org.eodisp.remote.registry.JeriRegistry;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.FileUtil;
import org.eodisp.util.launcher.ProcessListener;
import org.eodisp.wrapper.hla.FederationState;

/**
 * This is a single task that is able to execute an experiment. Such a task will
 * be created and managed by a {@link ExperimentTaskManager}. It has a
 * reference to a single {@link AcquiredExperiment}, from which it will take
 * information about the experiment.
 * 
 * <p>
 * In general, an experiment consists of the following parts:
 * 
 * <pre>
 * Experiment 
 *     |
 *     | (one or more)
 *     -- Federation Execution
 *                |
 *                | (one or more)
 *                -- Federates 
 *                       |
 *                       | ( one ore more)
 *                       -- init data 
 * </pre>
 * 
 * The exact information of how a specific experiment looks like is stored in
 * the model of the simulation manager application. This information will be
 * queried to construct an appropriate <code>AcquiredExperiment</code> object.
 * An object is created in order to have a 'snapshot' of the experiment at the
 * moment it is acquired. This enables the user to work on the experiment even
 * if the experiment is running. However, parameters of a running cannot be
 * changed.
 * 
 * <p>
 * An experiment task can execute the following upon an experiment (this is what
 * an EODiSP experiment supports)
 * <ul>
 * <li><i>acquire: </i>This will prepare an experiment in order to be ready to
 * get executed. This method contacts all model manager application involved to
 * lock the federate(s) that will be used in the experiment. Additionally, it
 * creates a <code>SOM</code> file for every federation execution. This file
 * is stored on the file system and will be used later to start the control
 * federate.</li>
 * <li><i>start: </i>This actually starts the experiment. It starts one
 * federation execution at the time, one after the other. Starting a federation
 * execution means to first start the control federate for this federation and
 * then to contact each model manager involved in order to start the federates
 * included in the federation execution. After starting all of these components,
 * the federation will run by itself, without any further interactions.</li>
 * <li><i>pause: </i>This will issue the EODISP_PAUSE synchronization point.</li>
 * <li><i>step: </i>This will issue the EODISP_STEP synchronization point.</li>
 * <li><i>resume: </i>This will issue the EODISP_RESUME synchronization point.</li>
 * <li><i>cancel: </i>This cancels the experiment. This can be used at any time
 * and will cleanup all resources. If the experiment is already running, it will
 * stop it.</li>
 * </ul>
 * 
 * <strong>Threads</strong><br>
 * A separate thread is created for the following tasks performed by this class.
 * <ul>
 * <li>acquiring the experiment</li>
 * <li>starting/running the experiment</li>
 * <li>starting/running the control federate</li>
 * </ul>
 * 
 * <strong>States</strong><br>
 * Because there are several parties involved in running an experiment, several
 * states are used to control (or monitor) the runtime behaviour of the
 * experiment. All these states are reported in a separated object of type
 * {@link ExperimentTaskState}. One such state object will be created for each
 * experiment. The following states will be recorded in this state object
 * <ul>
 * <li>The state of the experiment itself (see {@link TaskState}), </li>
 * <li>the state of the control federate (see {@link ControlFederateState}),
 * and</li>
 * <li>the state of the federation execution ({@link FederationState})</li>
 * </ul>
 * 
 * <p>
 * In respect of the possible functionality of a experiment task, the following
 * should illustrate the dependencies (or preconditions) between the states and
 * the functionality possible in the states.
 * 
 * <pre>
 * Legend: TS=Task State, CS=Control Federate State, FS=Federation State
 * 
 * acquire: 
 *     TS: STOPPED
 *     CS: STOPPED
 *     FS: NOT_INITIALIZED
 *     
 * start: 
 *     TS: PREPARED
 *     CS: STOPPED
 *     FS: NOT_INITIALIZED
 *     
 * pause: 
 *     TS: STARTED
 *     CS: STARTED
 *     FS: STARTED (this will be enforced by the control federate)
 *     
 * step: 
 *     TS: STARTED
 *     CS: STARTED
 *     FS: PAUSED (this will be enforced by the control federate)
 *     
 * resume: 
 *     TS: STARTED
 *     CS: STARTED
 *     FS: PAUSED (this will be enforced by the control federate)
 *     
 * cancel: 
 *     TS: any but not STOPPED
 *     CS: any
 *     FS: any
 * </pre>
 * 
 * <strong>Visibility</strong><br>
 * Methods declared in this class have all a package private visibility. Public
 * methods are declare in the <code>ExperimentTaskManager</code> class.
 * 
 * @see ControlFederateRemote
 * @see ExperimentTaskManager
 * @see ExperimentTaskState
 * @see AcquiredExperiment
 * 
 * @author eglimi
 * @version $Id:$
 */
final class ExperimentTask {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(ExperimentTask.class);

	private final ExecutorService experimentExecutor = Executors.newSingleThreadExecutor();

	private final ExecutorService cancelExecutor = Executors.newSingleThreadExecutor();

	private final ScheduledExecutorService updateLocksTask = Executors.newSingleThreadScheduledExecutor();

	private final AcquiredExperiment experiment;

	private final CopyOnWriteArrayList<ExperimentTaskListener> listeners = new CopyOnWriteArrayList<ExperimentTaskListener>();

	private final CopyOnWriteArrayList<RootAppProcess> controlFederateProcesses = new CopyOnWriteArrayList<RootAppProcess>();

	private final URI crcUri;

	private ControlFederateRemote controlFederateRemote;

	private final ExperimentTaskState state = new ExperimentTaskState();

	private final String applicationId;

	ExperimentTask(AcquiredExperiment experiment) {
		this.experiment = experiment;

		crcUri = ((SmConfiguration) AppRegistry.getRootApp().getConfiguration(SmConfiguration.ID)).getCrcUri();
		applicationId = ((SmConfiguration) AppRegistry.getRootApp().getConfiguration(SmConfiguration.ID)).getEntry(
				SmConfiguration.APP_ID).getValue();
	}

	void acquire() {
		state.setTaskState(TaskState.PREPARING);
		fireExperimentChanged();

		final FutureTask<Void> acquireTask = new FutureTask<Void>(new AcquireRunnable()) {
			@Override
			protected void done() {
				try {
					get();

					state.setTaskState(TaskState.PREPARED);
					fireExperimentChanged();
				} catch (Exception e) {
					state.setTaskState(TaskState.END_ERROR);
					addException(e);
				}
			}
		};

		experimentExecutor.submit(acquireTask);

		updateLocksTask.scheduleWithFixedDelay(new Runnable() {

			public void run() {
				try {
					updateLocks();
				} catch (ExperimentTaskException e) {
					state.addError(e);
					fireExperimentChanged();
				} catch (Throwable e) {
					state.addError(e);
					fireExperimentChanged();
				}
			}

		}, ModelManagerRemote.LOCK_TIMEOUT / 10, ModelManagerRemote.LOCK_TIMEOUT / 2, TimeUnit.SECONDS);
	}

	private boolean updateLocks() throws ExperimentTaskException {
		if (state.getTaskState() == TaskState.END) {
			return false;
		}
		for (Federate federate : experiment.getAllFederates()) {
			ModelManagerRemote mmRemoteservice = federate.getRemoteService();
			if (mmRemoteservice != null) {
				try {
					mmRemoteservice.updateLock(federate.getHandle());

					final String message = String.format(
							"Updated the lock for federate for federate with id %s and version %s", federate
									.getBundleId(), federate.getBundleVersion());
					logger.info(message);

				} catch (RemoteException e) {
					final String message = String.format(
							"Could not update lock for federate with id %s and version %s", federate.getBundleId(),
							federate.getBundleVersion());
					throw new ExperimentTaskException(message, e);
				}
			}
		}
		return true;
	}

	void start() {
		state.setTaskState(TaskState.STARTED);
		fireExperimentChanged();

		final FutureTask<Void> experimentTask = new FutureTask<Void>(new Callable<Void>() {
			public Void call() throws Exception {
				for (FederationExecution federationExecution : experiment.getFederations()) {

					while (state.getControlFederateState() != ControlFederateState.STOPPED) {
						logger.debug("Control federate still running. Waiting for 5 seconds to try to start again.");
						TimeUnit.SECONDS.sleep(5);
					}

					logger.debug("StartNextFederationExecution: " + federationExecution.getName());
					if (!startNextFederationExecution(federationExecution)) {
						return null;
					}
				}
				return null;
			}

		}) {
			@Override
			protected void done() {
				try {
					get();

					state.setTaskState(TaskState.END);
					fireExperimentChanged();
				} catch (Exception e) {
					state.setTaskState(TaskState.END_ERROR);
					addException(e);
				}
			}
		};

		experimentExecutor.submit(experimentTask);
	}

	private void addException(Throwable ex) {
		if (ex != null) {
			state.addError(ex);
			fireExperimentChanged();
		}
	}

	void pause() {
		logger.debug("Change to Pause state");
		try {
			controlFederateRemote.pause();
		} catch (RemoteException e) {
			state.addError(e);
			fireExperimentChanged();
		}
	}

	void step() {
		logger.debug("Change to Pause step");
		try {
			controlFederateRemote.step();
		} catch (RemoteException e) {
			state.addError(e);
			fireExperimentChanged();
		}
	}

	void resume() {
		logger.debug("Change to Pause resume");
		try {
			controlFederateRemote.resume();
		} catch (RemoteException e) {
			state.addError(e);
			fireExperimentChanged();
		}
	}

	void cancel() {

		FutureTask<Void> cancelTask = new FutureTask<Void>(new Runnable() {

			public void run() {
				cancelAll();
			}

		}, null) {
			@Override
			protected void done() {
				state.setTaskState(TaskState.END);
				fireExperimentChanged();
			}
		};

		cancelExecutor.submit(cancelTask);
	}

	/**
	 * Resets the experiment if it is not in {@link TaskState#END} state. It
	 * does the same as {@link #cancel()}.
	 * 
	 */
	void reset() {
		if (state.getTaskState() != TaskState.END) {
			cancelAll();
		}
	}

	private void cancelAll() {
		state.setTaskState(TaskState.CANCELLING);
		fireExperimentChanged();

		// stop updating federates
		updateLocksTask.shutdown();

		// stop control federate -> this should be done before stopping
		// federate, stopping federates can take long (beause of remote
		// exceptions)
		for (RootAppProcess controlFederateProcess : controlFederateProcesses) {
			controlFederateProcess.kill(1);
		}

		// stop federates
		for (Federate federate : experiment.getAllFederates()) {
			FederateProcessHandle handle = federate.getHandle();
			if (handle != null) {
				try {
					federate.getRemoteService().stopFederate(handle);
				} catch (RemoteException e) {
					final String message = "Federate " + federate + " could not be stopped";
					logger.error(message, e);
					addException(e);
				}
			}
		}
		
		experimentExecutor.shutdownNow();
	}

	void addExperimentTaskListener(ExperimentTaskListener listener) {
		listeners.add(listener);
	}

	void removeExperimentTaskListener(ExperimentTaskListener listener) {
		listeners.remove(listener);
	}

	private void fireExperimentChanged() {
		for (ExperimentTaskListener listener : listeners) {
			listener.experimentChanged();
		}
	}

	ExperimentTaskState getTaskState() {
		return state;
	}

	boolean isTaskForExperiment(EDataObject exp) {
		return this.experiment.compareExperiment(exp);
	}

	private class AcquireRunnable<T> implements Callable {

		public Object call() throws Exception {
			for (FederationExecution federation : experiment.getFederations()) {

				SomMerger merger = new SomMerger();

				for (Federate federate : federation.getFederates()) {
					// lock each federate
					try {
						Registry registry;

						URI modelManagerUri = new URI(federate.getRemoteLocation());

						RemoteAppModule remoteAppModule = (RemoteAppModule) AppRegistry.getRootApp().getAppModule(
								RemoteAppModule.ID);

						registry = remoteAppModule.getRegistry(modelManagerUri);

						ModelManagerRemote modelManagerService = (ModelManagerRemote) registry
								.lookup(ModelManagerRemote.REGISTRY_NAME);

						FederateProcessHandle federateHandle = modelManagerService.lockFederate(applicationId,
								experiment.getExperimentName(), federate.getBundleId(), federate.getBundleVersion());

						if (federateHandle == null) {
							final String message = String.format(
									"Federate with id %s and version %s is already locked.", federate.getBundleId(),
									federate.getBundleVersion());
							throw new ExperimentAcquireException(message);
						}

						federate.setRemoteService(modelManagerService);
						federate.setHandle(federateHandle);

					} catch (Exception ex) {
						throw new ExperimentAcquireException(ex.getMessage(), ex);
					}

					// get the som and create the document
					try {
						ByteArrayOutputStream buf = new ByteArrayOutputStream();

						OmtResourceFactoryImpl resourceFactoryImpl = new OmtResourceFactoryImpl();
						Resource omtResource = resourceFactoryImpl.createResource(org.eclipse.emf.common.util.URI
								.createURI("federate.som"));
						omtResource.load(new ByteArrayInputStream(federate.getSomData()), Collections.EMPTY_MAP);

						DocumentRoot loadedRoot = (DocumentRoot) omtResource.getContents().get(0);

						// merge it
						merger.merge(loadedRoot);

					} catch (Exception e) {
						final String message = "Could not load the SOM file for federate " + federate.getBundleId();
						throw new ExperimentAcquireException(message, e);
					}

				}

				// save the fom file for the federation execution
				DocumentRoot docRoot = merger.getFom();
				if (docRoot != null) {
					try {

						File fomFile = new File(FileUtil.createTempDir("FederateObjectModel", null, null), federation
								.getUniqueName()
								+ ".fdd");

						// save the fom and store the location in the federate
						OmtResourceFactoryImpl resourceFactoryImpl = new OmtResourceFactoryImpl();
						Resource omtResource = resourceFactoryImpl.createResource(org.eclipse.emf.common.util.URI
								.createURI("federationExecution.fdd"));
						omtResource.getContents().add(docRoot);
						Resource resource = docRoot.getObjectModel().eResource();

						federation.setFomUri(fomFile.toURI());

						if (resource == null) {
							final String message = "Could not add the DocumentRoot from the merged FOM file to a resource";
							throw new ExperimentAcquireException(message);
						}

						docRoot.eResource().save(new FileOutputStream(fomFile), Collections.EMPTY_MAP);

					} catch (Exception e) {
						final String message = "Could not save the FOM file for federation " + federation.getName();
						throw new ExperimentAcquireException(message, e);
					}
				}
			}
			return null;
		}
	}

	private boolean startNextFederationExecution(FederationExecution federationExecution)
			throws ExperimentStartException {
		state.setCurrentFederationExecution(federationExecution.getFederationExecution());
		if (federationExecution.getFederates().isEmpty()) {
			logger.warn("No federates defined for federation execution: " + federationExecution.getName());
			return true;
		}
		// try to lock and start every federate, one after another
		for (Federate federate : federationExecution.getFederates()) {
			try {
				logger.info("Start Federate " + federate.getBundleId() + "_" + federate.getBundleVersion());
				boolean started = federate.getRemoteService().startFederate(federate.getHandle(), crcUri,
						federationExecution.getUniqueName(), federate.getInitData());
				logger.debug("After Start Federate " + federate.getBundleId() + "_" + federate.getBundleVersion());

				while (!started) {
					String message = String.format(
							"Cannot start federate with id %s and version %s. Wait for 5 seconds to try again.",
							federate.getBundleId(), federate.getBundleVersion());
					logger.debug(message);
					TimeUnit.SECONDS.sleep(5);
					started = federate.getRemoteService().startFederate(federate.getHandle(), crcUri,
							federationExecution.getUniqueName(), federate.getInitData());
				}

			} catch (Exception ex) {
				final String message = "The federate " + federate.getBundleId() + " could not be started";
				logger.error(message, ex);
				throw new ExperimentStartException(message, ex);
			}
		}

		return startControlFederate(federationExecution.getUniqueName(), federationExecution.getFederates().size(),
				federationExecution.getFomUri());
	}

	/**
	 * @param federationExecutionName
	 * @param nrOfFederates
	 * @param fomUri
	 * @return <code>false</code> if the control federate has been cancelled
	 * @throws ExperimentStartException
	 */
	private boolean startControlFederate(String federationExecutionName, int nrOfFederates, URI fomUri)
			throws ExperimentStartException {
		// start control federates
		Map<TransportType, JeriRegistry> registries;
		final RootAppProcess controlFederate;

		final File workingDir;
		try {
			workingDir = FileUtil.createTempDir("controlFed", null, null);
		} catch (IOException ex) {
			final String message = "Could not create a directory to store the settings for the control federate";
			throw new ExperimentStartException(message, ex);
		}

		final RemoteAppModule remoteAppModule = (RemoteAppModule) AppRegistry.getRootApp().getAppModule(
				RemoteAppModule.ID);

		CommandlineJava cli = new CommandlineJava();
		cli.createArgument().setValue("--eodisp-federates");
		cli.createArgument().setValue(String.valueOf(nrOfFederates));
		cli.createArgument().setValue("--fdd");
		cli.createArgument().setValue(fomUri.toString());
		cli.createArgument().setValue("--federation-execution");
		cli.createArgument().setValue(federationExecutionName);

		Map<String, String> properties = new HashMap<String, String>();
		properties.put("org.eodisp.hla.lrc.crc-uri", crcUri.toString());

		logger.debug("Starting the control federate with the following parameters: " + cli.getJavaCommand().toString());

		controlFederate = new RootAppProcessImpl(ControlFederateMain.class.getName(), workingDir, EnumSet
				.of(remoteAppModule.getFavoriteTransport()), 0, null, cli.getJavaCommand().toString(), properties);

		controlFederateProcesses.addIfAbsent(controlFederate);

		controlFederate.addListener(new ProcessListener() {

			public void processTerminated(int exitCode) {
				controlFederateProcesses.remove(controlFederate);
				state.setControlFederateState(ControlFederateState.STOPPED);
				fireExperimentChanged();
			}

			public void processStarted() {
				state.setControlFederateState(ControlFederateState.STARTING);
				fireExperimentChanged();
			}

		});

		try {
			registries = controlFederate.launchBlocking(180, TimeUnit.SECONDS);
		} catch (Exception e) {
			final String message = "Could not start the control federate for federation execution"
					+ federationExecutionName;
			throw new ExperimentStartException(message);
		}

		try {

			controlFederateRemote = (ControlFederateRemote) registries.get(remoteAppModule.getFavoriteTransport())
					.lookup(ControlFederateRemote.REGISTRY_NAME);

			ControlFederateListenerRemote controlFederateListenerRemote = new ControlFederateListenerRemote() {
				public void stateChanged(FederationState newState) throws RemoteException {
					logger.debug("GUI should change to " + newState);
					state.setFederationState(newState);
					fireExperimentChanged();
				}

				public void error(Throwable e) {
					final String message = String.format("An error occurred in the experiment "
							+ experiment.getExperimentName());
					logger.error(message, e);
					addException(e);
				}
			};

			ControlFederateListenerRemote controlFederateListenerRemoteProxy = (ControlFederateListenerRemote) remoteAppModule
					.export(controlFederateListenerRemote);

			controlFederateRemote.addFederationStateListener(controlFederateListenerRemoteProxy);

		} catch (Exception e) {
			final String message = "Could not get the remote interface for the control federate";
			throw new ExperimentStartException(message, e);
		}

		try {
			// it is started now...
			state.setControlFederateState(ControlFederateState.STARTED);
			fireExperimentChanged();

			controlFederateRemote.init(Long.MAX_VALUE, TimeUnit.SECONDS);
			controlFederateRemote.start(Long.MAX_VALUE, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			logger.debug("Ignore", e);
			state.setFederationState(FederationState.STOPPED);
			fireExperimentChanged();
			/*
			 * TODO: Ignore this exception. It happens if we kill the control
			 * federate process. The correct solution might be to make the
			 * service.start(...) method non-blocking.
			 */
			return false;
		} catch (RemoteException e) {
			logger.debug("Ignore", e);
			state.setFederationState(FederationState.STOPPED);
			fireExperimentChanged();
			/*
			 * TODO: Ignore this exception. It happens if we kill the control
			 * federate process. The correct solution might be to make the
			 * service.start(...) method non-blocking.
			 */
			return false;
		} catch (Exception e) {
			logger.error("", e);
			throw new ExperimentStartException(e);
		}

		return true;
	}
}
