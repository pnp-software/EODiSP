/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.repos.application;

import org.apache.log4j.Logger;

/**
 * The main entry point for the model repository application.
 * 
 * @author eglimi
 * @version $Id:$
 * 
 */
public class ReposMain {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(ReposMain.class);

	/**
	 * The main class for the model repository application. This class can be
	 * executed in order to start the application.
	 * 
	 * @param args
	 *            Arguments for the application.
	 */
	public static void main(String[] args) {
		new ReposApplication().execute(args);
	}
}
