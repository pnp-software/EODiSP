/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.mm.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URI;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.TimeUnit;
import java.util.jar.Attributes;
import java.util.jar.Manifest;
import java.util.jar.Attributes.Name;

import net.jcip.annotations.GuardedBy;
import net.jcip.annotations.ThreadSafe;

import org.apache.log4j.Logger;
import org.apache.tools.ant.types.CommandlineJava;
import org.apache.tools.ant.types.Environment;
import org.apache.tools.ant.types.Path;
import org.apache.tools.ant.types.CommandlineJava.SysProperties;
import org.eodisp.core.common.FederateStartException;
import org.eodisp.core.common.FileInitData;
import org.eodisp.core.mm.config.MmConfiguration;
import org.eodisp.remote.config.RemoteConfiguration;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.FileUtil;
import org.eodisp.util.configuration.Configuration.Entry;
import org.eodisp.util.launcher.Process;
import org.eodisp.util.launcher.ProcessImpl;
import org.eodisp.util.launcher.ProcessListener;

/**
 * Starts the federate bundle.
 * 
 * @author ibirrer, eglimi
 * @version $Id:$
 */
@ThreadSafe
class FederateProcess {
	private static final Logger logger = Logger.getLogger(FederateProcess.class);

	private final Federate federate;

	@GuardedBy("this")
	private Process process;

	private volatile boolean isRunning;

	private final CopyOnWriteArrayList<FederateProcessListener> listeners = new CopyOnWriteArrayList<FederateProcessListener>();

	FederateProcess(final Federate federate) {
		this.federate = federate;
	}

	public void addFederateProcessListener(FederateProcessListener listener) {
		listeners.add(listener);
	}

	public void removeFederateProcessListener(FederateProcessListener listener) {
		listeners.remove(listener);
	}

	public synchronized boolean stop(long timeout, TimeUnit unit) {
		if (process != null) {
			logger.debug(String.format("Kill process: %s ", process));
			return process.kill(unit.toMillis(timeout));
		}
		logger.debug(String.format("Federate process %s has never been started or already been stopped", process));
		return true;
	}

	public synchronized void start(URI crc, String federationExecutionName, FileInitData[] fileInitData)
			throws FederateStartException {
		if (fileInitData == null) {
			fileInitData = new FileInitData[0];
		}
		logger.debug(String.format("Start federate bundle: %s", federate));
		Manifest manifest = federate.getManifest();
		Attributes mainAttributes = manifest.getMainAttributes();

		Path classpath = new Path(null, "");

		if (federate.getBundlePath().isDirectory()) {
			String bundleClasspath = mainAttributes.getValue("Bundle-Classpath");
			if (bundleClasspath != null) {
				String[] elements = bundleClasspath.split(",");
				for (String element : elements) {
					if (!element.trim().equals("")) {
						String absolutePath = new File(federate.getBundlePath(), element).getAbsolutePath();
						logger.debug(String.format("Add to classpath: %s", absolutePath));
						classpath.add(new Path(null, absolutePath));
					}
				}
			} else {
				logger.debug(String.format("No Bundle-Classpath defined for federate %s", federate));
			}
		} else {
			classpath.add(new Path(null, federate.getBundlePath().getAbsolutePath()));
		}

		/*
		 * Add all directories and jar file in data/lib to the classpath
		 */
		if (AppRegistry.getRootApp() != null) {
			// tests may not define a root app
			File libDir = new File(AppRegistry.getRootApp().getDataDir(), "lib");
			if (libDir.exists()) {
				File[] libs = libDir.listFiles();
				for (File libFile : libs) {
					if (libFile.isDirectory() || libFile.getName().endsWith(".jar")) {
						logger.debug(String.format("Add to classpath: %s", libFile.getAbsolutePath()));
						classpath.add(new Path(null, libFile.getAbsolutePath()));
					} else {
						logger.warn(String.format("%s not added to classpath", libFile.getAbsolutePath()));
					}
				}
			}
		}

		String mainClass = mainAttributes.getValue(Name.MAIN_CLASS);
		if (mainClass == null) {
			final String error = String.format("Main-Class not specified in manifest of bundle %s", federate
					.getBundlePath());
			MmFederateProcessManager.logger.error(error);
			throw new FederateStartException(error);
		}

		CommandlineJava cli = new CommandlineJava();
		cli.createClasspath(null);
		/*
		 * TODO: adding the classpath of the model manager itself is only done
		 * fore testing purposes. Remove for production!
		 */
		cli.getClasspath().add(Path.systemClasspath);
		cli.getClasspath().add(classpath);
		cli.setClassname(mainClass);

		// Setting Java System Properties
		SysProperties sysProperties = new SysProperties();

		// Set CRC URI. EODiSP RTI specific
		Environment.Variable crcUriVar = new Environment.Variable();
		crcUriVar.setKey("org.eodisp.hla.lrc.crc-uri");
		crcUriVar.setValue(crc.toString());
		sysProperties.addVariable(crcUriVar);
		logger.debug(String.format("Set System property %s to %s", crcUriVar.getKey(), crcUriVar.getValue()));

		// Set Federation Execution.
		Environment.Variable fedexUriVar = new Environment.Variable();
		fedexUriVar.setKey("org.eodisp.federation-execution-name");
		fedexUriVar.setValue(federationExecutionName);
		sysProperties.addVariable(fedexUriVar);
		logger.debug(String.format("Set System property %s to %s", fedexUriVar.getKey(), fedexUriVar.getValue()));

		if (AppRegistry.getRootApp() != null) {
			// Set java.libary.path to the bundle path
			Environment.Variable libraryPath = new Environment.Variable();
			libraryPath.setKey("java.library.path");
			String bundlePath = federate.getBundlePath().getAbsolutePath();
			String nativeLibPath = new File(AppRegistry.getRootApp().getDataDir(), "native_lib").getAbsolutePath();
			libraryPath.setValue(bundlePath + File.separator + nativeLibPath);
			sysProperties.addVariable(libraryPath);
			logger.debug(String.format("Set System property %s to %s", libraryPath.getKey(), libraryPath.getValue()));

			// Set debug level Execution.
			MmConfiguration mmConfiguration = (MmConfiguration) AppRegistry.getRootApp().getConfiguration(
					MmConfiguration.ID);
			Entry entry = mmConfiguration.getEntry(MmConfiguration.EODISP_LRC_LOG_LEVEL);
			Environment.Variable debugLevelVar = new Environment.Variable();
			debugLevelVar.setKey("org.eodisp.log-level");
			debugLevelVar.setValue(entry.getValue());
			sysProperties.addVariable(debugLevelVar);
			logger.debug(String
					.format("Set System property %s to %s", debugLevelVar.getKey(), debugLevelVar.getValue()));

			Entry customFileEntry = mmConfiguration.getEntry(MmConfiguration.EODISP_LRC_LOG4J_CUSTOM_FILE);
			final String customFile = customFileEntry.getValue();
			if (!customFile.equals("")) {
				Environment.Variable customFileVar = new Environment.Variable();
				customFileVar.setKey("org.eodisp.config-file");
				customFileVar.setValue(customFileEntry.getFile().getAbsolutePath());
				sysProperties.addVariable(customFileVar);
				logger.debug(String.format("Set System property %s to %s", customFileVar.getKey(), customFileVar
						.getValue()));

				Environment.Variable useCustomVar = new Environment.Variable();
				useCustomVar.setKey("org.eodisp.use-custom-file");
				useCustomVar.setValue("true");
				sysProperties.addVariable(useCustomVar);
				logger.debug(String.format("Set System property %s to %s", useCustomVar.getKey(), useCustomVar
						.getValue()));
			}

			// Set transport (JXTA or TCP)
			Environment.Variable transportVar = new Environment.Variable();
			transportVar.setKey("org.eodisp.remote.transport");
			RemoteConfiguration remoteConfig = (RemoteConfiguration) AppRegistry.getRootApp().getConfiguration(
					RemoteConfiguration.ID);
			transportVar.setValue(remoteConfig.getEntry(RemoteConfiguration.TRANSPORT).getValue());
			sysProperties.addVariable(transportVar);
			logger.debug(String.format("Set System property %s to %s", transportVar.getKey(), transportVar.getValue()));
		}

		// Set bundle location
		Environment.Variable bundleLocation = new Environment.Variable();
		bundleLocation.setKey("org.eodisp.bundle-path");
		bundleLocation.setValue(federate.getBundlePath().getAbsolutePath());
		sysProperties.addVariable(bundleLocation);
		logger.debug(String.format("Set System property %s to %s", bundleLocation.getKey(), bundleLocation.getValue()));

		StringBuilder initDataBuiler = new StringBuilder();

		boolean isFirst = true;
		for (FileInitData data : fileInitData) {
			File file;
			try {
				file = File.createTempFile("initData_", data.getFilename());
				FileOutputStream out = new FileOutputStream(file);
				out.write(data.getFileData());
				out.close();
			} catch (IOException e) {
				logger.error("Could not write init data to disk", e);
				throw new FederateStartException("Could not write init data on model manager", e);
			}
			if (isFirst) {
				isFirst = false;
			} else {
				initDataBuiler.append(",");
			}
			initDataBuiler.append(file.getAbsolutePath());
		}

		// cli.createArgument().setValue("--log-level");
		// cli.createArgument().setValue("debug");
		cli.createArgument().setValue("--federation-execution");
		cli.createArgument().setValue(federationExecutionName);
		if (fileInitData.length != 0) {
			cli.createArgument().setValue("--init-data");
			cli.createArgument().setValue(initDataBuiler.toString());
			// Set init data location
			Environment.Variable initDataVar = new Environment.Variable();
			initDataVar.setKey("org.eodisp.init-data");
			initDataVar.setValue(federate.getBundlePath().getAbsolutePath());
			sysProperties.addVariable(initDataVar);
			logger.debug(String.format("Set System property %s to %s", initDataVar.getKey(), initDataVar.getValue()));
		}

		// Set lrc working directory
		File workingDirRoot;

		if (AppRegistry.getRootApp() != null) {
			workingDirRoot = new File(AppRegistry.getRootApp().getDataDir(), ".lrcWorkingDirs");
			workingDirRoot.mkdirs();
		} else {
			// this case is only needed for tests where no RootApp is present.
			try {
				workingDirRoot = FileUtil.createTempDir("lrcWorkingDir", null, null);
			} catch (IOException e) {
				final String errorMsg = String.format(
						"Could not start federate %s, because its working directory could not be created", federate
								.getFederateId());
				logger.error(errorMsg, e);
				throw new FederateStartException(errorMsg, e);
			}
		}
		String federateIdString = federate.getFederateId() + "_" + federate.getFederateVersion();
		File workingDir = new File(workingDirRoot, federateIdString);
		/*
		 * ibirrer: Using the same LRC working directory for two subsequent
		 * federate runs results in problems with JXTA. It seems that the CRC
		 * keeps JXTA socket connections from the previously running federates.
		 * If then this socket is used, but the federate has restarted in the
		 * meantime a RMI call may take forever and never return. At the end
		 * this is a JXTA problem and should be solved there.
		 */
		// if (federate.getMaxParallelStarts() > 1) {
		try {
			workingDir = FileUtil.createTempDir(federateIdString + "_", "", workingDirRoot);
		} catch (IOException e) {
			final String errorMsg = String.format(
					"Could not start federate %s, because its working directory could not be created", federate
							.getFederateId());
			logger.error(errorMsg, e);
			throw new FederateStartException(errorMsg, e);
		}
		// }
		workingDir.mkdirs();

		if (!workingDir.exists()) {
			throw new FederateStartException(String.format(
					"Could not start federate '%s', because its working directory '%s' could not be created", federate
							.getFederateId(), workingDir.getAbsolutePath()));
		}

		Environment.Variable workingDirVar = new Environment.Variable();
		workingDirVar.setKey("org.eodisp.lrc.working-dir");
		workingDirVar.setValue(workingDir.getAbsolutePath());
		sysProperties.addVariable(workingDirVar);
		logger.debug(String.format("Set System property %s to %s", workingDirVar.getKey(), workingDirVar.getValue()));

		cli.addSysproperties(sysProperties);

		process = new ProcessImpl(cli, workingDir.getAbsoluteFile());

		File logDir = FileUtil.getTempDir();
		if (AppRegistry.getRootApp() != null) {
			logDir = new File(AppRegistry.getRootApp().getWorkingDir(), "log");
			logDir.mkdir();
		}

		try {
			// process.launch(new FileOutputStream(new File(logDir,
			// federate.getIdAndVersion()
			// + String.format("%1$tF-%1$tH-%1$tM-%1$tS-%1$tL",
			// Calendar.getInstance()))));
			process.launch();

			process.addListener(new ProcessListener() {
				public void processTerminated(int exitCode) {
					isRunning = false;
					fireFederateProcessStopped();
				}

				public void processStarted() {
					isRunning = true;
					fireFederateProcessStarted();
				}
			});

		} catch (IOException e) {
			MmFederateProcessManager.logger.error("Could not start federate main class", e);
			throw new FederateStartException(e);
		}

	}

	private void fireFederateProcessStopped() {
		for (FederateProcessListener listener : listeners) {
			listener.processStopped();
		}

	}

	private void fireFederateProcessStarted() {
		for (FederateProcessListener listener : listeners) {
			listener.processStarted();
		}
	}

	public synchronized boolean isProcessCreated() {
		return process != null;
	}

	public boolean isRunning() {
		return isRunning;
	}

	/**
	 * @return Returns the federate.
	 */
	public Federate getFederate() {
		return federate;
	}

	@Override
	public String toString() {
		if (process != null) {
			return process.toString();
		}
		return "Unstarted Federate Process";
	}
}
