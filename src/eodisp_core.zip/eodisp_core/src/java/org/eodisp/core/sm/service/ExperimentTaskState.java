/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.sm.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eodisp.wrapper.hla.FederationState;

public final class ExperimentTaskState {
	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	private final static Logger logger = Logger.getLogger(ExperimentTaskState.class);

	public enum ControlFederateState {
		STOPPED, STARTING, STARTED
	}

	public enum TaskState {
		NOT_INITIALIZED, PREPARING, PREPARED, STARTED, CANCELLING, END, END_ERROR
	}

	private ControlFederateState controlFederateState;

	private TaskState taskState;

	private FederationState federationState;

	private CopyOnWriteArrayList<Throwable> errors = new CopyOnWriteArrayList<Throwable>();

	private EDataObject currentFederationExecution;

	public ExperimentTaskState() {
		this.controlFederateState = ControlFederateState.STOPPED;
		this.taskState = TaskState.NOT_INITIALIZED;
		this.federationState = FederationState.NOT_INITIALIZED;
	}

	/**
	 * @return Returns the controlFederateState.
	 */
	public synchronized ControlFederateState getControlFederateState() {
		return controlFederateState;
	}

	/**
	 * @param controlFederateState
	 *            The controlFederateState to set.
	 */
	public synchronized void setControlFederateState(ControlFederateState newState) {
		boolean illegalStateTransition = false;
		
		switch (newState) {
		case STARTING:
			if(controlFederateState != ControlFederateState.STOPPED) {
				illegalStateTransition = true;
			}
			break;
		case STARTED :
			if(controlFederateState != ControlFederateState.STARTING) {
				illegalStateTransition = true;
			}
		case STOPPED:
			// case STOPPED is always possible
		}
		
		if (illegalStateTransition) {
			throw new IllegalStateException(String.format("Cannot change the control federate state to %s if in state %s", newState, controlFederateState));
		}
		
		logger.debug(String.format("Changing control federate state from %s to %s", controlFederateState, newState));
		controlFederateState = newState;
	}

	/**
	 * @return Returns the federationState.
	 */
	public synchronized FederationState getFederationState() {
		return federationState;
	}

	/**
	 * @param federationState
	 *            The federationState to set.
	 */
	public synchronized void setFederationState(FederationState federationState) {
		this.federationState = federationState;
	}

	/**
	 * @return Returns the taskState.
	 */
	public synchronized TaskState getTaskState() {
		return taskState;
	}

	/**
	 * @param taskState
	 *            The taskState to set.
	 */
	public synchronized void setTaskState(TaskState newState) {
		boolean illegalStateTransition = false;
		switch(newState) {
			case PREPARING:
				if(taskState != TaskState.NOT_INITIALIZED) {
					illegalStateTransition = true;
				}
				break;
			case PREPARED:
				if(taskState != TaskState.PREPARING) {
					illegalStateTransition = true;
				}
				break;
			case STARTED:
				if(taskState != TaskState.PREPARED) {
					illegalStateTransition = true;
				}
				break;
			case END:
				if(!(taskState != TaskState.CANCELLING || taskState != TaskState.STARTED)) {
					illegalStateTransition = true;
				}
				break;
			case CANCELLING:
				// CANCELLING is always possible
			case END_ERROR:
				// END_ERROR is always possible
		}
		
		if (illegalStateTransition) {
			throw new IllegalStateException(String.format("Cannot change the task state to %s if in state %s", newState, taskState));
		}
		
		logger.debug(String.format("Changing task state from %s to %s", taskState, newState));
		this.taskState = newState;
	}

	/**
	 * @return Returns the hasError.
	 */
	public boolean hasError() {
		return errors.size() > 0;
	}

	public void addError(Throwable error) {
		logger.debug("Add error to ExperimentTaskState", error);
		errors.add(error);
	}

	public List<Throwable> getErrors() {
		return new ArrayList<Throwable>(errors);
	}

	/**
	 * @return Returns the currentFederationExecution.
	 */
	public synchronized EDataObject getCurrentFederationExecution() {
		return currentFederationExecution;
	}

	/**
	 * @param currentFederationExecution
	 *            The currentFederationExecution to set.
	 */
	public synchronized void setCurrentFederationExecution(EDataObject currentFederationExecution) {
		this.currentFederationExecution = currentFederationExecution;
	}
}