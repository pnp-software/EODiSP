/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.sm.service;

import java.util.concurrent.CopyOnWriteArrayList;

import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eodisp.core.sm.helper.SmEmfHelper;
import org.eodisp.core.sm.service.ExperimentTaskState.TaskState;

/**
 * @author eglimi
 * @version $Id:$
 */
public final class ExperimentTaskManager {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(ExperimentTaskManager.class);

	private final CopyOnWriteArrayList<ExperimentTask> experimentTasks = new CopyOnWriteArrayList<ExperimentTask>();

	private final CopyOnWriteArrayList<ExperimentListener> listeners = new CopyOnWriteArrayList<ExperimentListener>();

	private final TaskListener taskListener = new TaskListener();

	/**
	 * Default constructor.
	 */
	public ExperimentTaskManager() {
	}

	public boolean isExperimentAcquired(EDataObject experiment) {
		ExperimentTask task = findExperimentTask(experiment);

		if (task != null) {
			return true;
		}

		return false;
	}

	public void acquireExperiment(EDataObject experiment) throws ExperimentAcquireException {
		if (isExperimentAcquired(experiment)) {
			throw new ExperimentAcquireException("The object " + SmEmfHelper.getName(experiment)
					+ " has already been acquired.");
		}

		AcquiredExperiment acquiredExperiment = new AcquiredExperiment(experiment);

		ExperimentTask experimentTask = new ExperimentTask(acquiredExperiment);

		experimentTask.addExperimentTaskListener(taskListener);

		experimentTasks.add(experimentTask);

		experimentTask.acquire();
	}

	public void startExperiment(final EDataObject experiment) throws ExperimentStartException {
		ExperimentTask task = findExperimentTask(experiment);

		if (task == null) {
			final String message = "No task corresponding to the given experiment could be found in the list of prepared experiments.\nPlease prepare it first.";
			throw new ExperimentStartException(message);
		}

		if (task.getTaskState().getTaskState() == TaskState.STARTED) {
			final String message = "This experiment has already been started. Ignoring request to start.";
			throw new ExperimentStartException(message);
		}

		task.start();
	}

	public void pauseExperiment(EDataObject experiment) throws ExperimentTaskException {
		ExperimentTask task = findExperimentTask(experiment);

		if (task == null) {
			final String message = "No task corresponding to the given experiment could be found in the list of prepared experiments.\nPlease prepare it first.";
			throw new ExperimentTaskException(message);
		}

		task.pause();
	}

	public void stepExperiment(EDataObject experiment) throws ExperimentTaskException {
		ExperimentTask task = findExperimentTask(experiment);

		if (task == null) {
			final String message = "No task corresponding to the given experiment could be found in the list of prepared experiments.\nPlease prepare it first.";
			throw new ExperimentTaskException(message);
		}

		task.step();
	}

	public void resumeExperiment(EDataObject experiment) throws ExperimentTaskException {
		ExperimentTask task = findExperimentTask(experiment);

		if (task == null) {
			final String message = "No task corresponding to the given experiment could be found in the list of prepared experiments.\nPlease prepare it first.";
			throw new ExperimentTaskException(message);
		}

		task.resume();
	}

	public void cancelExperiment(EDataObject experiment) throws ExperimentTaskException {
		ExperimentTask task = findExperimentTask(experiment);

		if (task == null) {
			final String message = "No task corresponding to the given experiment could be found in the list of prepared experiments.\nPlease prepare it first.";
			throw new ExperimentTaskException(message);
		}

		task.cancel();
	}

	/**
	 * This will cancel <strong>and</strong> clear the experiment. Clearing the
	 * experiment means to remove it from the list of acquired experiment.
	 * <p>
	 * Doing a cancel before the reset must be done to try to cancel/stop all
	 * resources (such as the update task) before removing the experiment all
	 * together.
	 * 
	 * @param experiment
	 *            the experiment which should be cleared.
	 * @throws ExperimentTaskException
	 *             thrown if there is no task that corresponds to the given
	 *             experiment.
	 */
	public void clearExperiment(EDataObject experiment) throws ExperimentTaskException {
		ExperimentTask task = findExperimentTask(experiment);

		if (task == null) {
			final String message = "No task corresponding to the given experiment could be found in the list of prepared experiments.\nPlease prepare it first.";
			throw new ExperimentTaskException(message);
		}

		task.reset();

		experimentTasks.remove(task);
		fireExperimentChanged();
	}

	public ExperimentTaskState getState(EDataObject experiment) {
		ExperimentTask task = findExperimentTask(experiment);
		if (task != null) {
			return task.getTaskState();
		}

		return null;
	}

	/**
	 * 
	 * @return True, if there is one or more experiments running (including
	 *         acquired experiments). False otherwise.
	 */
	public boolean hasRunningExperiments() {
		return !experimentTasks.isEmpty();
	}
	
	/**
	 * Kills all currently running experiments.
	 *
	 */
	public void cancelAll() {
		for(ExperimentTask task : experimentTasks) {
			task.reset();
		}
		
		experimentTasks.clear();
	}

	public void addExperimentListener(ExperimentListener listener) {
		listeners.add(listener);
	}

	public void removeExperimentListener(ExperimentListener listener) {
		listeners.remove(listener);
	}

	private void fireExperimentChanged() {
		for (ExperimentListener listener : listeners) {
			listener.experimentChanged();
		}
	}

	private ExperimentTask findExperimentTask(EDataObject experiment) {
		for (ExperimentTask task : experimentTasks) {
			if (task.isTaskForExperiment(experiment)) {
				return task;
			}
		}

		return null;
	}

	private class TaskListener implements ExperimentTaskListener {

		public void experimentChanged() {
			fireExperimentChanged();

		}
	}
}
