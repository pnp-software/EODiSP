/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.mm.service;

import java.io.File;
import java.util.jar.Manifest;

import net.jcip.annotations.GuardedBy;

public class Federate {

	private final String federateName;

	private final String federateId;

	private final String federateDescription;

	private final String federateVersion;

	private final File bundlePath;

	private final Manifest manifest;

	private final String somId;

	private final String somVersion;

	private final int maxParallelStarts;

	public Federate(final String federateName, final String federateId, final String federateDescription,
			final String federateVersion, final File bundlePath, final Manifest manifest, final String somId,
			final String somVersion, int maxParallelStarts) {

		this.federateName = federateName;
		this.federateId = federateId;
		this.federateDescription = federateDescription;
		this.federateVersion = federateVersion;
		this.bundlePath = bundlePath;
		this.manifest = manifest;
		this.somId = somId;
		this.somVersion = somVersion;
		this.maxParallelStarts = maxParallelStarts;
	}

	public File getBundlePath() {
		return bundlePath;
	}

	public Manifest getManifest() {
		return manifest;
	}

	public String getFederateName() {
		return federateName;
	}

	public String getFederateId() {
		return federateId;
	}

	public String getFederateDescription() {
		return federateDescription;
	}

	public String getFederateVersion() {
		return federateVersion;
	}

	public int getMaxParallelStarts() {
		return maxParallelStarts;
	}

	/**
	 * @return Returns the somId.
	 */
	public String getSomId() {
		return somId;
	}

	/**
	 * @return Returns the somVersion.
	 */
	public String getSomVersion() {
		return somVersion;
	}

	@Override
	public String toString() {
		return getIdAndVersion();
	}

	/**
	 * Returns the federate id and the federate version concatenated with an
	 * underline ('_').
	 * 
	 * @return returns {@link #getFederateId()} + '_' +
	 *         {@link #getFederateVersion()}.
	 */
	public String getIdAndVersion() {
		return federateId + "_" + federateVersion;
	}

	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((federateId == null) ? 0 : federateId.hashCode());
		result = PRIME * result + ((federateVersion == null) ? 0 : federateVersion.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final Federate other = (Federate) obj;
		if (federateId == null) {
			if (other.federateId != null)
				return false;
		} else if (!federateId.equals(other.federateId))
			return false;
		if (federateVersion == null) {
			if (other.federateVersion != null)
				return false;
		} else if (!federateVersion.equals(other.federateVersion))
			return false;
		return true;
	}

}