/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.mm.service;

import java.util.concurrent.atomic.AtomicInteger;

import org.eodisp.core.common.FederateProcessHandle;
import org.eodisp.core.common.ModelManagerRemote;

/**
 * @author eglimi
 * @version $Id:$
 * 
 */
public class FederateLock {

	private final String simulationManagerId;

	private final String experimentName;

	private final FederateProcessHandle handle;

	private final Federate federate;

	private AtomicInteger time = new AtomicInteger(ModelManagerRemote.LOCK_TIMEOUT);

	/**
	 * @param simulationManagerId
	 * @param experimentName
	 * @param handle
	 */
	public FederateLock(String simulationManagerId, String experimentName, FederateProcessHandle handle,
			Federate federate) {
		this.simulationManagerId = simulationManagerId;
		this.experimentName = experimentName;
		this.handle = handle;
		this.federate = federate;
	}

	int decreaseTime() {
		return time.decrementAndGet();
	}

	void resetTime() {
		time.set(ModelManagerRemote.LOCK_TIMEOUT);
	}

	/**
	 * @return Returns the experimentName.
	 */
	String getExperimentName() {
		return experimentName;
	}

	/**
	 * @return Returns the federate.
	 */
	Federate getFederate() {
		return federate;
	}

	/**
	 * @return Returns the handle.
	 */
	FederateProcessHandle getHandle() {
		return handle;
	}

	/**
	 * @return Returns the simulationManagerId.
	 */
	String getSimulationManagerId() {
		return simulationManagerId;
	}

}
