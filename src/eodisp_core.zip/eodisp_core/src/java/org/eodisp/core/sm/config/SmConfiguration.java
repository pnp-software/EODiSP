/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.sm.config;

import java.io.File;
import java.io.IOException;
import java.net.URI;

import org.apache.log4j.Logger;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.FileUtil;
import org.eodisp.util.configuration.ConfigurationImpl;

/**
 * @author eglimi
 * @version $Id:$
 */
public class SmConfiguration extends ConfigurationImpl {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(SmConfiguration.class);

	/**
	 * The Id of this configuration.This id can be used to retrieve the
	 * configuration entries.
	 */
	public static final String ID = "org.eodisp.core.sm.config.SmConfiguration";

	/**
	 * The name of the configuration. This will be shown on the command line.
	 */
	public static final String NAME = "Simulation Manager Configuration";

	/**
	 * Describes the configuration. This will be shown on the command line.
	 */
	public static final String DESCRIPTION = "Configuration for simulation manager application.";

	// Static definitions of keys for this configuration
	public static final String APP_NAME = "app_name";

	private static final String APP_NAME_DESC = "This is the name of the application. This application will be registered in the repository with this name";

	public static final String APP_DESCRIPTION = "app_description";

	private static final String APP_DESCRIPTION_DESC = "A short description of this application. Others can read this description from the repository when searching simulation manager applications.";

	public static final String APP_ID = "app_Id";

	private static final String APP_ID_DESC = "The unique Id of this application. This Id will be used to register and identify the simulation manager application in the repository. Do not change this value manually. It will be handled by the application.";

	public static final String APP_OWNER_FIRSTNAME = "app_owner_firstname";

	private static final String APP_OWNER_FIRSTNAME_DESC = "The surname of the person who is the owner of this application (the simulation manager application owner) .";

	public static final String APP_OWNER_SURNAME = "app_owner_surname";

	private static final String APP_OWNER_SURNAME_DESC = "The surname of the person who is the owner of this application (the simulation manager application owner) .";

	public static final String APP_OWNER_TEL = "app_owner_tel";

	private static final String APP_OWNER_TEL_DESC = "The telephone number of the application owner";

	public static final String APP_OWNER_MAIL = "app_owner_mail";

	private static final String APP_OWNER_MAIL_DESC = "The email address of the application owner";

	public static final String APP_OWNER_COUNTRY = "country";

	private static final String APP_OWNER_COUNTRY_DESC = "The country of the application owner";

	public static final String APP_OWNER_CUSTOM_1 = "custom1";

	private static final String APP_OWNER_CUSTOM_1_DESC = "Custom field for the application owner";

	public static final String APP_OWNER_CUSTOM_2 = "custom1";

	private static final String APP_OWNER_CUSTOM_2_DESC = "Custom field for the application owner";

	public static final String APP_OWNER_CUSTOM_3 = "custom1";

	private static final String APP_OWNER_CUSTOM_3_DESC = "Custom field for the application owner";

	public static final String SM_PROJECT_FILE = "sm_project_file";

	private static final String SM_PROJECT_FILE_DESC = "The location of the model for the simulation manager application given as a relative path to the current location.";

	public static final String REPOS_URI = "repos-uri";

	private static final String REPOS_URI_DESC = "An URI pointing to the repository.";

	public static final String CRC_URI = "crc-uri";

	private static final String CRC_URI_DESC = "An URI pointing to the crc which should be used by this simulation manager application.";

	public static final String REMOTE_TEST_SUPPORT = "Xremote-test-support";

	private static final String REMOTE_TEST_SUPPORT_DESCR = "If this flag is set, the simulation manager provides an additional interface "
			+ "(SmTestSupportRemote) that allows clients to call certain services on the simulation manager from remote (e.g. starting a new CRC) "
			+ "This should only be enabled for testing and debugging purposes. This is a non-standard option";

	/**
	 * Constructor. Calls the super constructor with the parameters defined
	 * above.
	 * 
	 * @param file
	 *            The configuration file which will be used to store the
	 *            configuration entries.
	 */
	public SmConfiguration(File file) {
		super(ID, NAME, DESCRIPTION, file);

		File smProjectFile = new File(AppRegistry.getRootApp().getDataDir(), "smProject.datagraph");
		String smProjectFileRelative;
		try {
			smProjectFileRelative = FileUtil.getRelativePath(file.getParentFile(), smProjectFile);
		} catch (IOException e) {
			// Happens on windows if data directory and configuration directory
			// are not on the same device (e.g. C: and D:).
			smProjectFileRelative = smProjectFile.getAbsolutePath();
		}

		logger.debug(String.format("Setting default location of smProject.model file to %s",
				smProjectFileRelative));

		// create entry for sm project file
		createFileEntry(SM_PROJECT_FILE, new File(smProjectFileRelative), SM_PROJECT_FILE_DESC);

		createEntry(REPOS_URI, "", REPOS_URI_DESC);
		createEntry(CRC_URI, "", CRC_URI_DESC);
		createBooleanEntry(REMOTE_TEST_SUPPORT, false, REMOTE_TEST_SUPPORT_DESCR);

		// Create entries for application settings
		createEntry(APP_NAME, "", APP_NAME_DESC);
		createEntry(APP_DESCRIPTION, "", APP_DESCRIPTION_DESC);
		createEntry(APP_ID, "", APP_ID_DESC);
		createEntry(APP_OWNER_FIRSTNAME, "", APP_OWNER_FIRSTNAME_DESC);
		createEntry(APP_OWNER_SURNAME, "", APP_OWNER_SURNAME_DESC);
		createEntry(APP_OWNER_TEL, "", APP_OWNER_TEL_DESC);
		createEntry(APP_OWNER_MAIL, "", APP_OWNER_MAIL_DESC);
		createEntry(APP_OWNER_COUNTRY, "", APP_OWNER_COUNTRY_DESC);
		createEntry(APP_OWNER_CUSTOM_1, "", APP_OWNER_CUSTOM_1_DESC);
		createEntry(APP_OWNER_CUSTOM_2, "", APP_OWNER_CUSTOM_2_DESC);
		createEntry(APP_OWNER_CUSTOM_3, "", APP_OWNER_CUSTOM_3_DESC);
	}

	public File getSmModelFile() {
		return ((EntryImpl) getEntry(SM_PROJECT_FILE)).getFileResolved();
	}

	public void setSmModelFile(File smModelFile) {
		getEntry(SM_PROJECT_FILE).setFile(smModelFile);
	}

	public URI getReposUri() {
		return URI.create(getEntry(REPOS_URI).getValue().trim());
	}

	public URI getCrcUri() {
		return URI.create(getEntry(CRC_URI).getValue());
	}

	public void setCrcUri(URI crcUri) {
		getEntry(CRC_URI).setValue(crcUri.toString());
	}

	public boolean isRemoteTestSupport() {
		return getEntry(REMOTE_TEST_SUPPORT).getBoolean();
	}

	public void setRemoteTestSupport(boolean remoteAdmin) {
		getEntry(REMOTE_TEST_SUPPORT).setBoolean(remoteAdmin);
	}

	public static void main(String[] args) {
		System.out.println(new SmConfiguration(new File("dummy")).getCode());
	}

}
