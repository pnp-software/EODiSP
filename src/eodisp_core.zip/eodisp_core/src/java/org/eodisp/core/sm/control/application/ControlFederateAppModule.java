/**
 * 
 */
package org.eodisp.core.sm.control.application;

import java.io.File;

import org.eodisp.core.sm.control.ControlFederateRemote;
import org.eodisp.core.sm.control.ControlFederateRemoteImpl;
import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.util.AbstractAppModule;
import org.eodisp.util.RootApp;

public class ControlFederateAppModule extends AbstractAppModule {
	public static final String ID = ControlFederateAppModule.class.getName();

	private ControlFederateRemote controlFederateRemote;

	@Override
	public String getId() {
		return ID;
	}

	@Override
	public void registerConfiguration(RootApp rootApp) {
		final File configFile = new File(rootApp.getConfigurationDir(), "control-federate.conf");
		rootApp.registerConfiguration(new ControlFederateConfiguration(configFile),
				ControlFederateConfiguration.COMMAND_LINE_MAPPER);
	}

	@Override
	public void startup(RootApp rootApp) throws Exception {
		ControlFederateConfiguration config = (ControlFederateConfiguration) rootApp
				.getConfiguration(ControlFederateConfiguration.ID);
		controlFederateRemote = new ControlFederateRemoteImpl(config.getFederationExecution(), config.getFddUrl(),
				config.getEodispFederates(), null);
		RemoteAppModule remoteAppModule = (RemoteAppModule) rootApp.getAppModule(RemoteAppModule.ID);
		remoteAppModule.exportAndRegister(controlFederateRemote, ControlFederateRemote.REGISTRY_NAME);
	}

	public ControlFederateRemote getControlFederateRemote() {
		return controlFederateRemote;
	}
}
