/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.repos.config;

import java.io.File;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.FileUtil;
import org.eodisp.util.configuration.ConfigurationImpl;

/**
 * @author eglimi
 * @version $Id:$
 *
 */
public class ReposConfiguration extends ConfigurationImpl {
	
	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(ReposConfiguration.class);
	
	public static final String ID = "org.eodisp.core.repos.config.ReposConfiguration";
	
	public static final String NAME = "Repository Configuration";
	
	public static final String DESCRIPTION = "Configuration for the model repository application.";
	
	public static final String SOMS_DIR = "federate_dir";

	private static final String SOMS_DIR_DESC = "This is the directory where the model repository application stores the SOM files that are sent from clients.";
	
	// Static definitions of keys for this configuration
	public static final String REPOS_MODEL_FILE = "emf_model_file";
	public static final String REPOS_MODEL_FILE_DESC = "The location of the model for the repository given as a relative path to the current location.";
	
	public ReposConfiguration(File file) {
		super(ID, NAME, DESCRIPTION, file);
		
		File reposFile = new File(AppRegistry.getRootApp().getDataDir(), "repos.datagraph");
		String reposRelativePath;
		try {
			reposRelativePath = FileUtil.getRelativePath(file.getParentFile(), reposFile);
		} catch (IOException e) {
			// Happens on windows if data directory and configuration directory
			// are not on the same device (e.g. C: and D:).
			reposRelativePath = reposFile.getAbsolutePath();
		}
		
		File somsDir = new File(AppRegistry.getRootApp().getDataDir(), "soms");
		String somsDirRelative;
		try {
			somsDirRelative = FileUtil.getRelativePath(file.getParentFile(), somsDir);
		} catch (IOException e) {
			// Happens on windows if data directory and configuration directory
			// are not on the same device (e.g. C: and D:).
			somsDirRelative = somsDir.getAbsolutePath();
		}
		
		logger.debug(String.format("Setting default location of repository.model file to %s", reposRelativePath));
		
		createFileEntry(REPOS_MODEL_FILE, new File(reposRelativePath), REPOS_MODEL_FILE_DESC);
		
		createFileEntry(SOMS_DIR, new File(somsDirRelative), SOMS_DIR_DESC);
	}
	
	public File getReposModelFile() {
		 return ((EntryImpl)getEntry(REPOS_MODEL_FILE)).getFile();
	}

	public void setReposModelFile(File emfModelFile) {
		 getEntry(REPOS_MODEL_FILE).setFile(emfModelFile); 
	}
	
	public File getSomsDir() {
		return ((EntryImpl) getEntry(SOMS_DIR)).getFile();
	}

	public void setSomsDir(File somsDir) {
		getEntry(SOMS_DIR).setFile(somsDir);
	}
}
