/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.mm.config;

import java.io.File;
import java.io.IOException;
import java.net.URI;

import org.apache.log4j.Logger;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.FileUtil;
import org.eodisp.util.configuration.ConfigurationImpl;

/**
 * Configuration of the model manager.
 * 
 * @author eglimi
 * @version $Id:$
 * @see org.eodisp.util.configuration.Configuration
 */
public class MmConfiguration extends ConfigurationImpl {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(MmConfiguration.class);

	/**
	 * The Id of this configuration.This id can be used to retrieve the
	 * configuration entries.
	 */
	public static final String ID = MmConfiguration.class.getName();

	/**
	 * The name of the configuration. This will be shown on the command line.
	 */
	public static final String NAME = "Model Manager Configuration";

	/**
	 * Describes the configuration. This will be shown on the command line.
	 */
	public static final String DESCRIPTION = "Configuration for model manager application.";

	public static final String MM_PROJECT_FILE = "mm_project_file";

	private static final String MM_PROJECT_FILE_DESC = "The location of the model for the model manager application given as a relative path to the current location.";

	public static final String REPOS_URI = "repos-uri";

	private static final String REPOS_URI_DESC = "An URI pointing to the repository.";

	private static final String REMOTE_TEST_SUPPORT = "Xremote-test-support";

	public static final String MM_FEDERATE_DIR = "federate_dir";

	private static final String MM_FEDERATE_DIR_DESC = "This is the directory where the model manager is searching for federates."
			+ "Currently, only one directory is supported.";

	public static String CHECK_PERMISSIONS = "check-permissions";

	private static final String CHECK_PERMISSIONS_DESC = "This flag indicates whether the model manager should check for permissions. "
			+ "If it is set to 'true', the model manager will, if connected, check in the repository if the a calling simulation manager has permission to use a certain federate. "
			+ "This implies that the model manager is connected to the repository. Otherwise, an exception will be thrown. "
			+ "If it is set to 'false', the model manager will omit this check, allowing every simulation manager to use all its federates.";

	private static final String REMOTE_TEST_SUPPORT_DESCR = "If this flag is set, the model manager provides an additional interface "
			+ "(MmTestSupportRemote) that allows clients to call certain services on the model manager from remote (e.g. starting a new CRC) "
			+ "This should only be enabled for testing and debugging purposes. This is a non-standard option";

	// Static definitions of keys for this configuration
	public static final String APP_NAME = "app_name";

	private static final String APP_NAME_DESC = "This is the name of the application. This application will be registered in the repository with this name";

	public static final String APP_DESCRIPTION = "app_description";

	private static final String APP_DESCRIPTION_DESC = "A short description of this application. Others can read this description from the repository when searching simulation manager applications.";

	public static final String APP_ID = "app_Id";

	private static final String APP_ID_DESC = "The unique Id of this application. This Id will be used to register and identify the model manager application in the repository. Do not change this value manually. It will be handled by the application.";

	public static final String APP_OWNER_FIRSTNAME = "app_owner_firstname";

	private static final String APP_OWNER_FIRSTNAME_DESC = "The surname of the person who is the owner of this application (the model manager application owner) .";

	public static final String APP_OWNER_SURNAME = "app_owner_surname";

	private static final String APP_OWNER_SURNAME_DESC = "The surname of the person who is the owner of this application (the model manager application owner) .";

	public static final String APP_OWNER_TEL = "app_owner_tel";

	private static final String APP_OWNER_TEL_DESC = "The telephone number of the application owner";

	public static final String APP_OWNER_MAIL = "app_owner_mail";

	private static final String APP_OWNER_MAIL_DESC = "The email address of the application owner";

	public static final String APP_OWNER_COUNTRY = "country";

	private static final String APP_OWNER_COUNTRY_DESC = "The country of the application owner";

	public static final String APP_OWNER_CUSTOM_1 = "custom1";

	private static final String APP_OWNER_CUSTOM_1_DESC = "Custom field for the application owner";

	public static final String APP_OWNER_CUSTOM_2 = "custom1";

	private static final String APP_OWNER_CUSTOM_2_DESC = "Custom field for the application owner";

	public static final String APP_OWNER_CUSTOM_3 = "custom1";

	private static final String APP_OWNER_CUSTOM_3_DESC = "Custom field for the application owner";

	public static final String EODISP_LRC_LOG_LEVEL = "eodisp_lrc_log_level";

	private static final String EODISP_LRC_LOG_LEVEL_DESC = "The log level of the EODiSP LRC. Possible values are: OFF, FATAL, ERROR, WARN, INFO, DEBUG.";

	public static final String EODISP_LRC_LOG4J_CUSTOM_FILE = "eodisp_lrc_log4j_custom_file";

	private static final String EODISP_LRC_LOG4J_CUSTOM_FILE_DESC = "The log4j custom file to be used for the EODiSP LRC";

	/**
	 * Constructor. Calls the super constructor with the parameters defined
	 * above.
	 * 
	 * @param file
	 *            The configuration file which will be used to store the
	 *            configuration entries.
	 */
	public MmConfiguration(File file) {
		super(ID, NAME, DESCRIPTION, file);

		File mmProjectFile = new File(AppRegistry.getRootApp().getDataDir(), "mmProject.datagraph");
		String mmProjectFileRelative;
		try {
			mmProjectFileRelative = FileUtil.getRelativePath(file.getParentFile(), mmProjectFile);
		} catch (IOException e) {
			// Happens on windows if data directory and configuration directory
			// are not on the same device (e.g. C: and D:).
			mmProjectFileRelative = mmProjectFile.getAbsolutePath();
		}

		File mmFederateDir = new File(AppRegistry.getRootApp().getDataDir(), "federates");
		String mmFederateDirRelative;
		try {
			mmFederateDirRelative = FileUtil.getRelativePath(file.getParentFile(), mmFederateDir);
		} catch (IOException e) {
			// Happens on windows if data directory and configuration directory
			// are not on the same device (e.g. C: and D:).
			mmFederateDirRelative = mmFederateDir.getAbsolutePath();

		}

		logger.debug(String.format("Setting default location of mmProject.model file to %s", mmProjectFileRelative));

		// create entry for mm project file
		createFileEntry(MM_PROJECT_FILE, new File(mmProjectFileRelative), MM_PROJECT_FILE_DESC);

		// dir for the federates
		createFileEntry(MM_FEDERATE_DIR, new File(mmFederateDirRelative), MM_FEDERATE_DIR_DESC);

		// create entry for the repository URI
		createEntry(REPOS_URI, "", "The URI of the repository component");

		// create entry for repository URI
		createEntry(REPOS_URI, "", REPOS_URI_DESC);

		createBooleanEntry(REMOTE_TEST_SUPPORT, false, REMOTE_TEST_SUPPORT_DESCR);

		createBooleanEntry(CHECK_PERMISSIONS, true, CHECK_PERMISSIONS_DESC);

		// Create entries for application settings
		createEntry(APP_NAME, "", APP_NAME_DESC);
		createEntry(APP_DESCRIPTION, "", APP_DESCRIPTION_DESC);
		createEntry(APP_ID, "", APP_ID_DESC);
		createEntry(APP_OWNER_FIRSTNAME, "", APP_OWNER_FIRSTNAME_DESC);
		createEntry(APP_OWNER_SURNAME, "", APP_OWNER_SURNAME_DESC);
		createEntry(APP_OWNER_TEL, "", APP_OWNER_TEL_DESC);
		createEntry(APP_OWNER_MAIL, "", APP_OWNER_MAIL_DESC);
		createEntry(APP_OWNER_COUNTRY, "", APP_OWNER_COUNTRY_DESC);
		createEntry(APP_OWNER_CUSTOM_1, "", APP_OWNER_CUSTOM_1_DESC);
		createEntry(APP_OWNER_CUSTOM_2, "", APP_OWNER_CUSTOM_2_DESC);
		createEntry(APP_OWNER_CUSTOM_3, "", APP_OWNER_CUSTOM_3_DESC);
		createEntry(EODISP_LRC_LOG_LEVEL, "ERROR", EODISP_LRC_LOG_LEVEL_DESC);
		createFileEntry(EODISP_LRC_LOG4J_CUSTOM_FILE, new File(""), EODISP_LRC_LOG4J_CUSTOM_FILE_DESC);
	}

	public URI getReposUri() {
		return URI.create(getEntry(REPOS_URI).getValue().trim());
	}

	public File getMmModelFile() {
		return ((EntryImpl) getEntry(MM_PROJECT_FILE)).getFile();
	}

	public void setMmModelFile(File mmModelFile) {
		getEntry(MM_PROJECT_FILE).setFile(mmModelFile);
	}

	public boolean isRemoteTestSupport() {
		return getEntry(REMOTE_TEST_SUPPORT).getBoolean();
	}

	public void setRemoteTestSupport(boolean remoteAdmin) {
		getEntry(REMOTE_TEST_SUPPORT).setBoolean(remoteAdmin);
	}

	public File getFederateDir() {
		return ((EntryImpl) getEntry(MM_FEDERATE_DIR)).getFile();
	}

	public void setFederateDir(File federateDir) {
		getEntry(MM_FEDERATE_DIR).setFile(federateDir);
	}

	public boolean isCheckPermissions() {
		return getEntry(CHECK_PERMISSIONS).getBoolean();
	}

	public void setCheckPermissions(boolean checkPermissions) {
		getEntry(CHECK_PERMISSIONS).setBoolean(checkPermissions);
	}
}
