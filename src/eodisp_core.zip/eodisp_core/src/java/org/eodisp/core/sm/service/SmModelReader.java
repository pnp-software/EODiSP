/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.sm.service;

import java.io.*;
import java.net.URISyntaxException;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.sdo.EDataGraph;
import org.eclipse.emf.ecore.sdo.util.SDOUtil;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eodisp.core.common.EmfUtil;
import org.eodisp.core.gen.smproject.impl.SmprojectPackageImpl;
import org.eodisp.core.sm.config.SmConfiguration;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.FileUtil;

/**
 * @author eglimi
 * @version $Id:$
 */
public final class SmModelReader {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(SmModelReader.class);

	private final HashMap options = new HashMap();

	private final Resource resource;

	private final ResourceSet resourceSet;

	private EDataGraph dataGraph;

	private File modelFile;

	public SmModelReader() {
		options.put(XMLResource.OPTION_ENCODING, "UTF-8");
		options.put(XMLResource.OPTION_USE_DEPRECATED_METHODS, Boolean.TRUE);

		resourceSet = SDOUtil.createResourceSet();
		resourceSet.getPackageRegistry().put(SmprojectPackageImpl.eNS_URI, SmprojectPackageImpl.eINSTANCE);

		resource = resourceSet.createResource(URI.createURI("sm.datagraph"));
	}

	public synchronized EDataGraph getDataGraph() {
		if (dataGraph != null) {
			return dataGraph;
		}

		final String message = "The datagraph has not been loaded. Load it first, before trying to get the data graph";
		throw new IllegalStateException(message);
	}

	public void updateDataGraph(EDataGraph changedDg) throws IOException {
		EmfUtil.updateDataGraph(getDataGraph(), changedDg, modelFile, options);
	}

	public synchronized void load() throws IOException, URISyntaxException {
		if (resource.isLoaded()) {
			return;
		}

		modelFile = getModelFile();

		FileInputStream is = new FileInputStream(modelFile);

		try {
			resource.load(is, options);
		} catch (IOException ex) {
			// log the error and throw it further to inform clients
			logger.error("The data could not be loaded into the resource", ex);
			throw ex;
		} finally {
			is.close();
		}

		dataGraph = (EDataGraph) resource.getContents().get(0);
	}

	private File getModelFile() throws URISyntaxException, IOException {
		File smProjectFile = ((SmConfiguration) AppRegistry.getRootApp().getConfiguration(SmConfiguration.ID))
				.getSmModelFile();

		ensureModelFile(smProjectFile);

		return smProjectFile;
	}

	private void ensureModelFile(File file) throws IOException {
		// If the file exists, we do not change anything.
		if (file.exists()) {
			return;
		}

		// otherwise, we create a template file
		InputStream tplStream = getClass().getClassLoader().getResourceAsStream(
				"org/eodisp/core/resources/SmProject.tpl");

		try {
			FileUtil.copy(tplStream, file);
		} catch (IOException e) {
			logger.error(String.format("The new file: %1$s could not created.", file), e);
			throw e;
		}
	}
}
