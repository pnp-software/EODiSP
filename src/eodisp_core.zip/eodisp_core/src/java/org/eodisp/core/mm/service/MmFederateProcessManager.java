/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.mm.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.jar.JarFile;
import java.util.jar.Manifest;

import org.apache.log4j.Logger;
import org.eodisp.core.common.*;

/**
 * @author eglimi
 * @version $Id:$
 */
public final class MmFederateProcessManager {

	/**
	 * Log4J logger for this class
	 */
	final static Logger logger = Logger.getLogger(ModelManagerRemoteImpl.class);

	private volatile boolean initialized = false;

	private final CopyOnWriteArrayList<Federate> federates = new CopyOnWriteArrayList<Federate>();

	private final CopyOnWriteArrayList<FederateListener> listeners = new CopyOnWriteArrayList<FederateListener>();

	private final ScheduledExecutorService processCleanupTasks = Executors.newScheduledThreadPool(1);

	private final ConcurrentHashMap<FederateLock, FederateProcess> federateProcesses = new ConcurrentHashMap<FederateLock, FederateProcess>();

	private final AtomicInteger nextFederateProcessHandle = new AtomicInteger(0);

	/**
	 * Default constructor.
	 */
	public MmFederateProcessManager() {
		processCleanupTasks.scheduleAtFixedRate(new Runnable() {
			public void run() {
				checkAllLocks();
			}

		}, 1, 1, TimeUnit.SECONDS);
	}

	private void checkAllLocks() {
		for (FederateLock lock : federateProcesses.keySet()) {
			if (lock.decreaseTime() == 0) {
				String message = String.format("Remove lock for for the federate with id: %s and version: %s."
						+ "It has been locked by the simulation manager with id: %s for experiment: %s", lock
						.getFederate().getFederateId(), lock.getFederate().getFederateVersion(), lock
						.getSimulationManagerId(), lock.getExperimentName());
				logger.info(message);

				// stop the federate. This will remove the lock as well.
				stopFederate(lock.getHandle());
			}
		}
	}

	public List<Federate> getEntries() {
		return new ArrayList<Federate>(federates);
	}

	public synchronized void readFederates(File federatesDir) {
		if (initialized) {
			return;
		}

		logger.debug(String.format("Reading federates from directory %s", federatesDir));

		if (!federatesDir.exists() || !federatesDir.isDirectory()) {
			logger.error("Cannot read federates because the directory " + federatesDir.getAbsolutePath()
					+ " either does not exist or it is not a directory. Please create it.");
			return;
		}

		for (File bundle : federatesDir.listFiles()) {
			Manifest manifest = null;

			if (bundle.isFile() && bundle.getName().endsWith(".jar")) {
				try {
					JarFile jarFile = new JarFile(bundle);
					manifest = jarFile.getManifest();
				} catch (IOException e) {
					final String message = "The manifest file for bundle '" + bundle
							+ "' could not be read. Ignoring this federate.";
					logger.warn(message);
					return;
				}

			} else { // directory
				try {
					final File manifestFile = new File(bundle, JarFile.MANIFEST_NAME);
					manifest = new Manifest(new FileInputStream(manifestFile));
				} catch (IOException e) {
					final String message = "The manifest file for bundle '" + bundle
							+ "' could not be read. Ignoring this federate.";
					logger.warn(message, e);
					continue;
				}
			}

			String bundleName = manifest.getMainAttributes().getValue("Bundle-Name");
			String bundleId = manifest.getMainAttributes().getValue("Bundle-SymbolicName");
			String bundleDescription = manifest.getMainAttributes().getValue("Bundle-Description");
			String bundleVersion = manifest.getMainAttributes().getValue("Bundle-Version");
			String maxParallelStartsProperty = manifest.getMainAttributes().getValue("Max-Parallel");
			int maxParallelStarts = maxParallelStartsProperty == null ? 1 : Integer.valueOf(maxParallelStartsProperty)
					.intValue();
			String somId = manifest.getMainAttributes().getValue("Som-Id");
			String somVersion = manifest.getMainAttributes().getValue("Som-Version");

			logger.debug(String.format(
					"Adding federate with name '%s' and version '%s' to the list of handled federates.", bundleName,
					bundleVersion));

			createFederate(bundleName, bundleId, bundleDescription, bundleVersion, bundle, manifest, somId, somVersion,
					maxParallelStarts);
		}

		initialized = true;
	}

	/**
	 * @param federateId
	 *            the federate id
	 * @param federateVersion
	 *            the federate version
	 * @return the federate with the given id and version
	 * @throws FederateNotKnownException
	 *             if the federate is not available through this manager
	 */
	Federate getFederate(String federateId, String federateVersion) throws FederateNotKnownException {
		for (Federate federate : federates) {
			if (federate.getFederateId().equals(federateId) && federate.getFederateVersion().equals(federateVersion)) {
				return federate;
			}
		}

		final String message = String.format(
				"This model manager does not know anything about a federate with the id %s and the version %s",
				federateId, federateVersion);
		throw new FederateNotKnownException(message);
	}

	private void createFederate(String federateName, String federateId, String federateDescription,
			String federateVersion, File bundlePath, Manifest manifest, String somId, String somVersion,
			int maxParallelStarts) {
		Federate federate = new Federate(federateName, federateId, federateDescription, federateVersion, bundlePath,
				manifest, somId, somVersion, maxParallelStarts);
		logger.debug(String
				.format("Install federate: %s_%s from location: %s", federateId, federateVersion, bundlePath));
		federates.add(federate);
	}

	public synchronized FederateProcessHandle lockFederate(String simulationManagerId, String experimentName,
			String federateId, String federateVersion) throws FederateNotKnownException {

		Federate federate = getFederate(federateId, federateVersion);
		final FederateProcessHandle handle;

		if (allowsNewLock(simulationManagerId, experimentName, federate)) {
			handle = nextFederateProcessHandle();
			federateProcesses.put(new FederateLock(simulationManagerId, experimentName, handle, federate),
					new FederateProcess(federate));
		} else {
			handle = null;
		}
		return handle;
	}

	public synchronized void updateLock(FederateProcessHandle handle) {
		for (FederateLock federateLock : federateProcesses.keySet()) {
			if (federateLock.getHandle().equals(handle)) {
				federateLock.resetTime();
			}
		}
	}

	private synchronized boolean allowsNewLock(String simulationManagerId, String experimentName, Federate federate) {
		// TODO possible to check for number of locks

		if (federate.getMaxParallelStarts() == 0) {
			return true;
		}

		for (FederateLock federateLock : federateProcesses.keySet()) {
			if (federateLock.getFederate().equals(federate)) {
				if (federateLock.getSimulationManagerId().equals(simulationManagerId)
						&& federateLock.getExperimentName().equals(experimentName)) {
					return true;
				}

				// a lock for this federate exists, but not for the same SM
				// and/or experiment
				return false;
			}
		}

		// no lock so far
		return true;
	}

	private FederateProcessHandle nextFederateProcessHandle() {
		return new FederateProcessHandle(nextFederateProcessHandle.incrementAndGet());
	}

	public boolean startFederate(final FederateProcessHandle handle, URI crc, String federationExecutionName,
			FileInitData[] fileInitData) throws FederateStartException {

		if (handle == null) {
			throw new IllegalArgumentException("FederateProcessHandle must not be null");
		}

		FederateLock federateLock = findFederateLock(handle);
		if (federateLock != null && federateProcesses.get(federateLock).isProcessCreated()) {
			throw new FederateStartException(
					"The process for this handle has already been started. You are not allowed request a start for the same handle more than once.");
		}
		
		logger.debug("Before isAllowedToRun()");
		final boolean allowedToRun = isAllowedToRun(handle);
		logger.debug("After isAllowedToRun()");
		if (!allowedToRun) {	
			return false;
		}

		final FederateProcess federateProcess = federateProcesses.get(findFederateLock(handle));

		if (federateProcess == null) {
			throw new FederateStartException(String.format("Federate with handle %s has not been locked", handle));
		}

		federateProcess.addFederateProcessListener(new FederateProcessListener() {

			public void processStarted() {
				logger.debug(String.format("Process started for federate: %s", federateProcess.getFederate().getIdAndVersion()));
				fireFederateChanged();
			}

			public void processStopped() {
				FederateLock lock = findFederateLock(handle);
				if (lock != null) {
					FederateProcess fProcess = federateProcesses.remove(lock);
					lock = null;
					logger.debug(String.format("Removed federate process %s with handle %s because process has exit",
							fProcess, handle));
				}
				fireFederateChanged();
			}

		});

		try {
			federateProcess.start(crc, federationExecutionName, fileInitData);
		} catch (FederateStartException e) {
			FederateLock lock = findFederateLock(handle);
			if (lock != null) {
				logger
						.debug(String.format("Remove federate process with handle %s due FederateStartException",
								handle));
				federateProcesses.remove(lock);
				lock = null;
			}
			throw e;
		}

		return true;
	}

	public synchronized boolean stopFederate(FederateProcessHandle handle) {
		if (handle == null) {
			throw new IllegalArgumentException("FederateProcessHandle must not be null");
		}

		FederateProcess federateProcess = null;

		FederateLock lock = findFederateLock(handle);
		if (lock != null) {
			federateProcess = federateProcesses.get(lock);
		}

		if (federateProcess == null) {
			logger.debug(String.format("Federate process with handle %s has already been stopped", handle));
			return true;
		}
		federateProcesses.remove(lock);
		return federateProcess.stop(1, TimeUnit.MILLISECONDS);
	}

	/**
	 * This methods stops (i.e. kills) all federate process that have been
	 * started from this model manager. It also stops other tasks that are used
	 * by the application. In short, this methods does everything it can to stop
	 * all processes created by this application.
	 * <p>
	 * The method synchronous (blocking).
	 * 
	 */
	public synchronized void cancelAll() {
		// cancel the cleanup task
		processCleanupTasks.shutdownNow();

		// cancel all federat processes
		for (FederateLock federateLock : federateProcesses.keySet()) {
			stopFederate(federateLock.getHandle());
		}
	}

	/**
	 * Checks whether the federate with the given id and version is currently
	 * running. This method is not synchronized. Thus, the result might not be
	 * accurate in every case, but should be enough to display the status, for
	 * example.
	 * 
	 * @param federateId
	 *            the id of the federate.
	 * @param federateVersion
	 *            the version of the federate.
	 * @return True, if the federate is running, false otherwise.
	 */
	public boolean isFederateRunning(String federateId, String federateVersion) {
		Federate federate;

		try {
			federate = getFederate(federateId, federateVersion);
		} catch (FederateNotKnownException e) {
			return false;
		}

		boolean running = false;

		if (federate != null) {
			for (FederateProcess federateProcess : federateProcesses.values()) {
				if (federateProcess.getFederate().equals(federate)) {
					if (federateProcess.isRunning()) {
						running = true;
					}
				}
			}
		}

		return running;
	}

	public void addFederateListener(FederateListener listener) {
		listeners.add(listener);
	}

	public void removeFederateListener(FederateListener listener) {
		listeners.remove(listener);
	}

	private void fireFederateChanged() {
		for (FederateListener listener : listeners) {
			listener.federateChanged();
		}
	}

	private synchronized FederateLock findFederateLock(FederateProcessHandle handle) {
		for (FederateLock federateLock : federateProcesses.keySet()) {
			if (federateLock.getHandle().equals(handle)) {
				return federateLock;
			}
		}
		return null;
	}

	private synchronized boolean isAllowedToRun(FederateProcessHandle handle) throws FederateStartException {
		
		FederateLock lock = findFederateLock(handle);
		if (lock == null) {
			final String errorMsg = "Expected to find lock with handle " + handle;
			logger.error(errorMsg);
			throw new FederateStartException(errorMsg);
		}
		Federate federate = lock.getFederate();

		if (federate.getMaxParallelStarts() == 0) {
			return true;
		}

		boolean foundRunning = false;
		for (FederateLock federateLock : federateProcesses.keySet()) {
			if (federateLock.getFederate().equals(federate)) {
				if (federateProcesses.get(federateLock).isProcessCreated()) {
					foundRunning = true;
				}
			}
		}

		return !foundRunning;
	}
}
