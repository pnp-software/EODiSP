/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.common;

import java.net.URI;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Map;

/**
 * The remote interface of the model manager. This remote interface is used by
 * the simulation manager to control federates on the model manager that shall
 * participate in a federation execution.
 * 
 * @author ibirrer
 * @version $Id:$
 */
public interface ModelManagerRemote extends Remote {
	public static final String REGISTRY_NAME = "org.eodisp.core.common.ModelManagerRemote";

	/**
	 * This is the time specifying how long a lock for a federate is valid.
	 * Whether the lock for a federate persists also after this time has elapsed
	 * is implementation specific. You should therefore update the lock before
	 * this timeout elapses.
	 * 
	 * @see #updateLock(FederateProcessHandle)
	 * 
	 */
	public static final int LOCK_TIMEOUT = 600;

	/**
	 * Locks the federate with the given Id and version so that it is ready to
	 * be started by the calling simulation manager. If the simulation manager
	 * does not start the federate within 5 minutes it unlocks the federate. If
	 * a simulation manager tries to start a federate with the returned process
	 * handle after the timeout has been reached, the
	 * {@link #startFederate(FederateProcessHandle, URI, String, Map)} throws a
	 * {@link FederateStartException}.
	 * 
	 * @param simulationManagerId
	 *            the ID of the simulation manager that wants to lock a
	 *            federate.
	 * @param experimentName
	 *            the name of the experiment
	 * @param federateId
	 *            The ID of the federate that shall be started. This ID should
	 *            be based on the reverse domain name convention (example:
	 *            <code>org.eodisp.example.rocket</code>)
	 * @param federateVersion
	 *            The version must have the following form:
	 * 
	 * <pre>
	 *      version ::=
	 *     	 major( '.' minor ( '.' micro ( '.' qualifier )? )? )?
	 *     	 major ::= number
	 *     	 minor ::= number
	 *     	 micro ::= number
	 *     	 qualifier ::= ( alphanum | '_' | '-' )+
	 * </pre>
	 * 
	 * (copied from the OSGI standard)
	 * @return The handle which can be used to start the federate.
	 *         <code>null</code> if the federate is already locked. Always
	 *         returns a new handle if a federate can be started multiple times.
	 * @throws FederateNotKnownException
	 *             thrown if the federate with the given <code>federateId</code>
	 *             and <code>version</code> is not known on the model manager.
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method.
	 */
	FederateProcessHandle lockFederate(String simulationManagerId, String experimentName, String federateId,
			String federateVersion) throws FederateNotKnownException, FederateAccessException, RemoteException;

	/**
	 * Starts the federate that was previously locked using
	 * {@link #lockFederate(String, String)}}. This method also allows to send
	 * initialization data to the federate.
	 * 
	 * @param handle
	 *            A handle identifying a previously locked federate process.
	 * @param crc
	 *            URI of the CRC that the newly started federate shall connect
	 *            to
	 * @param federationExecutionName
	 *            the name of the federation execution that the federate shall
	 *            join.
	 * @param fileInitData
	 *            <p>
	 *            Initialization data as files for the federate to start. The
	 *            elements of the array will be passed to the federate as
	 *            command line argument in the same order as in the array.
	 *            </p>
	 * 
	 * <pre>
	 *            	java Federate --init-data fileInitData[0],fileInitData[1],fileInitData[2]
	 *            </pre>
	 * 
	 * @throws FederateStartException
	 *             thrown if the federate could not be started on the model
	 *             manager.
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method.
	 * @return True, if the federate has been successfully started. False, if
	 *         the federate cannot be started yet. This indicates that the
	 *         request in principle is valid, but the federate is not yet ready
	 *         to be started. You could then try to call this method until true
	 *         (or an error) is returned.
	 */
	boolean startFederate(FederateProcessHandle handle, URI crc, String federationExecutionName,
			FileInitData[] fileInitData) throws FederateStartException, RemoteException;

	/**
	 * Updates a lock of a previously fetched handle. Updating a lock will
	 * ensure that a lock persists.
	 * <p>
	 * No error is thrown if the handle does not identify a valid federate. The
	 * request will be silently ignored.
	 * 
	 * @param handle
	 *            The previously fetched handle.
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method.
	 * 
	 * @see #LOCK_TIMEOUT
	 */
	public void updateLock(FederateProcessHandle handle) throws RemoteException;

	/**
	 * Stops the federate (process) with the given federate process handle. It
	 * is guaranteed that the process with the given federate process ID is
	 * stopped if this method returns true.
	 * 
	 * @param federateProcessHandle
	 *            the handle of the federate process which shall be stopped.
	 *            This handle must have been received by the
	 *            {@link #lockFederate(String, String) method.
	 * @return return <code>true</code> if the federate process is stopped,
	 *         false otherwise. It the federate was not running or if the
	 *         federate handle is unknown by the model manager this method
	 *         returns <code>true</code>. A <code>false</code> return value
	 *         does does not indicate if the process is running or not.
	 * @throws RemoteException
	 *             RMI remote exception happened while calling this method.
	 */
	boolean stopFederate(FederateProcessHandle federateProcessHandle) throws RemoteException;
}
