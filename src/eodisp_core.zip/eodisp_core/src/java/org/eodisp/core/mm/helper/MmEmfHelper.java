/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.mm.helper;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eodisp.core.gen.repository.impl.RepositoryPackageImpl;
import org.eodisp.core.mm.config.MmConfiguration;
import org.eodisp.core.mm.service.Federate;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.configuration.Configuration;

import commonj.sdo.DataObject;

/**
 * @author eglimi
 * @version $Id:$
 */
public class MmEmfHelper {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(MmEmfHelper.class);

	@SuppressWarnings("unchecked")
	public static EDataObject findReposFederate(DataObject reposRoot, String federateId, String federateVersion) {
		if (reposRoot == null) {
			logger.warn("The repository root object is null. Terminating search.");
			return null;
		}

		String appId = ((MmConfiguration) AppRegistry.getRootApp().getConfiguration(MmConfiguration.ID)).getEntry(
				MmConfiguration.APP_ID).getValue();

		List<EDataObject> federates = reposRoot.getList(RepositoryPackageImpl.REPOSITORY__FEDERATES);
		if (federates.size() > 0) {
			for (EDataObject federate : federates) {
				if (federate.getString(RepositoryPackageImpl.FEDERATE__BUNDLE_SYMBOLIC_NAME).equals(federateId)
						&& federate.getString(RepositoryPackageImpl.FEDERATE__BUNDLE_VERSION).equals(federateVersion)) {

					DataObject modelManager = federate.getDataObject(RepositoryPackageImpl.FEDERATE__OWNING_MM);
					if (modelManager != null
							&& modelManager.getString(RepositoryPackageImpl.MODEL_MANAGER__ID).equals(appId)) {
						return federate;
					}
				}
			}
		}

		return null;
	}

	@SuppressWarnings("unchecked")
	public static boolean hasPermission(DataObject reposRoot, String federateId, String federateVersion,
			String simulationManagerId) {
		EDataObject reposFederate = findReposFederate(reposRoot, federateId, federateVersion);

		if (reposFederate == null) {
			return false;
		}

		List<DataObject> trustedSms = reposFederate.getList(RepositoryPackageImpl.FEDERATE__TRUSTED_SIM_MANAGERS);
		for (DataObject trustedSm : trustedSms) {
			if (trustedSm.getString(RepositoryPackageImpl.SIM_MANAGER__ID).equals(simulationManagerId)) {
				return true;
			}
		}

		return false;
	}

	public static EDataObject findReposModelManager(DataObject reposRoot, String mmId) throws IllegalArgumentException {

		if (reposRoot == null) {
			final String message = "The provided root object must not be null and of type DataObject";
			logger.warn(message);
			throw new IllegalArgumentException(message);
		}

		return (EDataObject) reposRoot.getDataObject(String.format("modelManagers[id=%s]", mmId));
	}

	public static DataObject findReposSomForLocalFederate(DataObject reposRoot, Federate localFederate) {

		String somId = localFederate.getSomId();
		String somVersion = localFederate.getSomVersion();
		if (somId == null || somVersion == null) {
			return null;
		}

		List<DataObject> soms = findAllSoms(reposRoot);
		if (soms != null) {
			for (DataObject som : soms) {
				if (som.getString(RepositoryPackageImpl.SOM__NAME).equals(somId)
						&& som.getString(RepositoryPackageImpl.SOM__VERSION).equals(somVersion)) {
					return som;
				}
			}
		}

		return null;
	}

	@SuppressWarnings("unchecked")
	public static void copyFederateData(DataObject reposRoot, Federate localFederate, String additionalFederateInfo,
			String appId) throws IllegalArgumentException, IllegalStateException {

		if (localFederate.getFederateId().equals("") && localFederate.getFederateVersion().equals("")) {
			final String message = "This federate does not specify a SOM to which it conforms.\nBoth, the federate id and the federate version are not specified.\nYou have to update your federate before you can proceed.";
			logger.error(message);
			throw new IllegalStateException(message);
		}

		DataObject reposFederate = findReposFederate(reposRoot, localFederate.getFederateId(), localFederate
				.getFederateVersion());
		if (reposFederate != null) {
			logger.error("Federate is already registered. No need to register it.");
			throw new IllegalStateException("Federate is already registered. No need to register it.");
		}

		DataObject reposModelManager = findReposModelManager(reposRoot, appId);
		if (reposModelManager == null) {
			final String message = "The model manager application could not be found in the repository. Register the application first";
			logger.error(message);
			throw new IllegalStateException(message);
		}

		DataObject reposSom = findReposSomForLocalFederate(reposRoot, localFederate);
		if (reposSom == null) {
			final String message = "The SOM that this federate complies to is not yet registered in the repository. It must be registered first.\nPlease use the repository manager application to accomplish this.\nThe SOM in question has the id "
					+ localFederate.getSomId() + " and version " + localFederate.getSomVersion();
			logger.error(message);
			throw new IllegalStateException(message);
		}

		// create and set repository federate
		reposFederate = reposRoot.createDataObject(RepositoryPackageImpl.REPOSITORY__FEDERATES);

		copyFederateDataPlain(localFederate, additionalFederateInfo, reposFederate);

		reposFederate.setDataObject(RepositoryPackageImpl.FEDERATE__OWNING_MM, reposModelManager);

		reposFederate.setDataObject(RepositoryPackageImpl.FEDERATE__SOM, reposSom);
	}

	public static void copyApplicationData(DataObject reposMm, Configuration config, URI localUri) {
		// get the data from the application
		String appName = config.getEntry(MmConfiguration.APP_NAME).getValue();
		String appId = config.getEntry(MmConfiguration.APP_ID).getValue();
		String appDescription = config.getEntry(MmConfiguration.APP_DESCRIPTION).getValue();
		String appOwnerFirstname = config.getEntry(MmConfiguration.APP_OWNER_FIRSTNAME).getValue();
		String appOwnerSurname = config.getEntry(MmConfiguration.APP_OWNER_SURNAME).getValue();
		String appOwnerTel = config.getEntry(MmConfiguration.APP_OWNER_TEL).getValue();
		String appOwnerMail = config.getEntry(MmConfiguration.APP_OWNER_MAIL).getValue();
		String custom1 = config.getEntry(MmConfiguration.APP_OWNER_CUSTOM_1).getValue();
		String custom2 = config.getEntry(MmConfiguration.APP_OWNER_CUSTOM_2).getValue();
		String custom3 = config.getEntry(MmConfiguration.APP_OWNER_CUSTOM_3).getValue();

		// copy the data to the destination
		reposMm.setString(RepositoryPackageImpl.MODEL_MANAGER__ID, appId);
		reposMm.setString(RepositoryPackageImpl.MODEL_MANAGER__NAME, appName);
		reposMm.setString(RepositoryPackageImpl.MODEL_MANAGER__DESCRIPTION, appDescription);

		DataObject appOwner = reposMm.getDataObject(RepositoryPackageImpl.MODEL_MANAGER__APP_OWNER);
		if (appOwner == null) {
			appOwner = reposMm.createDataObject(RepositoryPackageImpl.MODEL_MANAGER__APP_OWNER);
		}
		appOwner.setString(RepositoryPackageImpl.APP_OWNER__FIRSTNAME, appOwnerFirstname);
		appOwner.setString(RepositoryPackageImpl.APP_OWNER__SURNAME, appOwnerSurname);
		appOwner.setString(RepositoryPackageImpl.APP_OWNER__TEL, appOwnerTel);
		appOwner.setString(RepositoryPackageImpl.APP_OWNER__MAIL, appOwnerMail);
		appOwner.setString(RepositoryPackageImpl.APP_OWNER__CUSTOM1, custom1);
		appOwner.setString(RepositoryPackageImpl.APP_OWNER__CUSTOM2, custom2);
		appOwner.setString(RepositoryPackageImpl.APP_OWNER__CUSTOM3, custom3);

		DataObject remoteLocation = reposMm.getDataObject(RepositoryPackageImpl.MODEL_MANAGER__REMOTE_LOCATION);
		if (remoteLocation == null) {
			remoteLocation = reposMm.createDataObject(RepositoryPackageImpl.MODEL_MANAGER__REMOTE_LOCATION);
		}
		remoteLocation.setString(RepositoryPackageImpl.REMOTE_LOCATION__URI, localUri.toString());
	}

	@SuppressWarnings("unchecked")
	public static List<DataObject> findTrustedSmsForLocalFederate(DataObject reposRoot, Federate localFederate) {
		DataObject reposFederate = findReposFederate(reposRoot, localFederate.getFederateId(), localFederate
				.getFederateVersion());
		if (reposFederate != null) {
			return reposFederate.getList(RepositoryPackageImpl.FEDERATE__TRUSTED_SIM_MANAGERS);
		}

		return new ArrayList(0);
	}

	@SuppressWarnings("unchecked")
	public static List<DataObject> findAllReposSimulationManagers(DataObject reposRoot) {
		if (reposRoot != null) {
			return reposRoot.getList(RepositoryPackageImpl.REPOSITORY__SIM_MANAGERS);
		}

		return new ArrayList(0);
	}

	@SuppressWarnings("unchecked")
	public static List<DataObject> findAllSoms(DataObject reposRoot) {
		if (reposRoot != null) {
			return reposRoot.getList(RepositoryPackageImpl.REPOSITORY__SOMS);
		}

		return new ArrayList(0);
	}

	public static String getFederateInfoText(DataObject reposRoot, String federateId, String federateVersion) {
		EDataObject federate = findReposFederate(reposRoot, federateId, federateVersion);
		if (federate != null) {
			return federate.getString(RepositoryPackageImpl.FEDERATE__DESCRIPTION);
		}

		return "";
	}

	public static void setFederateInfoText(DataObject reposRoot, String federateId, String federateVersion,
			String federateInfo) {
		EDataObject federate = findReposFederate(reposRoot, federateId, federateVersion);
		if (federate != null) {
			federate.setString(RepositoryPackageImpl.FEDERATE__DESCRIPTION, federateInfo);
		}
	}

	public static String getFederatInfo(Federate localFederate, DataObject reposFederate) {

		StringBuilder sb = new StringBuilder();
		String fedName = "no information";
		String fedVersion = "no information";
		String fedId = "no information";
		String fedDescription = "no information";
		String fedInfo = "no information";
		String somName = "no information";
		String somVersion = "no information";
		String somDescription = "no information";

		if (localFederate != null) {
			fedName = localFederate.getFederateName();
			fedVersion = localFederate.getFederateVersion();
			fedId = localFederate.getFederateId();
			fedDescription = localFederate.getFederateDescription();
		}

		if (reposFederate != null) {
			fedInfo = reposFederate.getString(RepositoryPackageImpl.FEDERATE__DESCRIPTION);

			DataObject som = reposFederate.getDataObject(RepositoryPackageImpl.FEDERATE__SOM);
			if (som != null) {
				somName = som.getString(RepositoryPackageImpl.SOM__NAME);
				somVersion = som.getString(RepositoryPackageImpl.SOM__VERSION);
				somDescription = som.getString(RepositoryPackageImpl.SOM__DESCRIPTION);
			}
		}

		sb.append("<html>");
		sb.append("<head></head>");
		sb.append("<body>");

		// sb.append("<div class='section'>");
		sb.append("<h1>Federate Info</h1>");
		sb.append("<table>");
		addRow(sb, "Name:", fedName);
		addRow(sb, "Version:", fedVersion);
		addRow(sb, "Id:", fedId);
		addRow(sb, "Description:", fedDescription);
		addRow(sb, "More Information:", fedInfo);

		addRow(sb, "SOM Name:", somName);
		addRow(sb, "SOM Version:", somVersion);
		addRow(sb, "SOM Description:", somDescription);
		sb.append("</table>");
		// sb.append("</div>");

		sb.append("</body></html>");

		return sb.toString();
	}

	public static void addRow(StringBuilder sb, String title, String value) {
		sb.append("<tr>");
		sb.append("<td style='width: 120px'><strong>" + title + "</strong></td>");
		sb.append("<td style='padding-left: 10px'>" + value + "</td>");
		sb.append("</tr>");
	}

	private static void copyFederateDataPlain(Federate localFederate, String additionalFederateInfo,
			DataObject reposFederate) {
		
		String federateId = UUID.randomUUID().toString();
		String fedDescription = additionalFederateInfo;
		String bundleName = localFederate.getFederateName();
		String bundleId = localFederate.getFederateId();
		String bundleDescription = localFederate.getFederateDescription();
		String bundleVersion = localFederate.getFederateVersion();

		// copy to repository
		reposFederate.setString(RepositoryPackageImpl.FEDERATE__ID, federateId);
		reposFederate.setString(RepositoryPackageImpl.FEDERATE__BUNDLE_NAME, bundleName);
		reposFederate.setString(RepositoryPackageImpl.FEDERATE__BUNDLE_SYMBOLIC_NAME, bundleId);
		reposFederate.setString(RepositoryPackageImpl.FEDERATE__BUNDLE_DESCRIPTION, bundleDescription);
		reposFederate.setString(RepositoryPackageImpl.FEDERATE__BUNDLE_VERSION, bundleVersion);
		reposFederate.setString(RepositoryPackageImpl.FEDERATE__DESCRIPTION, fedDescription);
	}
}
