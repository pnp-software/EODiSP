package org.eodisp.util;

import java.io.File;
import java.util.*;

import junit.framework.TestCase;

import org.apache.log4j.BasicConfigurator;

public class ZipUtilTest extends TestCase {
	public void testZip() throws Exception {
		BasicConfigurator.configure();
		System.out.println(FileUtil.getRelativePath(new File("/tmp"), new File("/tmp/hello")));

		// create some test files

		File root = FileUtil.createTempDir("ZipUtilTest", "", null);
		File file1 = new File(root, "file1");
		File file2 = new File(root, "file2");
		File file3 = new File(root, "file3");
		File file4 = new File(root, "file4");
		FileUtil.createFile(file1, 1024 * 137);
		FileUtil.createFile(file2, 35);
		FileUtil.createFile(file3, 35);
		FileUtil.createFile(file4, 35);

		File zipFile = File.createTempFile("zipTest", "");

		ZipUtil.zip(zipFile, root.getParentFile(), root);
		System.out.println(zipFile.getAbsolutePath());
		System.out.println(zipFile.length());

		final File dest = FileUtil.createTempDir("ZipUtilTestDest", "", null);
		ZipUtil.unzip(zipFile, dest);
		final File file = dest.listFiles()[0];
		assertTrue(file.getName().startsWith("ZipUtilTest"));

		Set<String> actual = new HashSet<String>(Arrays.asList(file.list()));
		Set<String> expected = new HashSet<String>(Arrays.asList(new String[] { "file1", "file2", "file3", "file4" }));

		assertEquals(expected, actual);
	}
}
