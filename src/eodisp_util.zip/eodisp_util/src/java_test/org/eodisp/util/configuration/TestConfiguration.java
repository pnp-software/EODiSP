/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.util.configuration;

import java.io.File;
import java.io.IOException;

/**
 * @author ibirrer
 * @version $Id:$
 *
 */
public class TestConfiguration extends ConfigurationImpl {
	
	
	public static final String INTEGER2_HELP = "integer2 config option";
	public static final String INTEGER1_HELP = "integer1 config option";
	public static final String BOOL2_HELP = "bool2 config option";
	public static final String BOOL1_HELP = "bool1 config option";
	public static final String INT1 = "int1";
	public static final String INT2 = "int2";
	public static final String BOOL1 = "bool1";
	public static final String BOOL2 = "bool2";

	public TestConfiguration(String id, File file) {
		super( id, id, "test config", file );
		
		createBooleanEntry(BOOL1, true, BOOL1_HELP);
		createBooleanEntry(BOOL2, true, BOOL2_HELP);
		
		createIntEntry(INT1, 120, INTEGER1_HELP);
		createIntEntry(INT2, 200, INTEGER2_HELP);
	}
	
	public TestConfiguration() throws IOException {
		this( "testConfig", File.createTempFile("test", ".conf") );
	}
	
	public boolean isBool1() {
		 return getEntry(BOOL1).getBoolean(); 
	}

	public void setBool1(boolean bool1) {
		 getEntry(BOOL1).setBoolean(bool1); 
	}

	public int getInt2() {
		 return getEntry(INT2).getInt(); 
	}

	public void setInt2(int int2) {
		 getEntry(INT2).setInt(int2); 
	}

	public int getInt1() {
		 return getEntry(INT1).getInt(); 
	}

	public void setInt1(int int1) {
		 getEntry(INT1).setInt(int1); 
	}

	public boolean isBool2() {
		 return getEntry(BOOL2).getBoolean(); 
	}

	public void setBool2(boolean bool2) {
		 getEntry(BOOL2).setBoolean(bool2); 
	}
	
	public static void main(String[] args) {
		TestConfiguration testConfiguration = new TestConfiguration("test", null);
		System.out.println(testConfiguration.getCode());
	}
}
