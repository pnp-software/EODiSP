package org.eodisp.util.configuration;

import java.io.File;
import java.io.IOException;
import java.util.EnumSet;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.SimpleLayout;
import org.eodisp.util.configuration.Configuration.Entry;

import junit.framework.TestCase;

public class ConfigurationTest extends TestCase {

	@Override
	protected void setUp() throws Exception {
		Logger.getRootLogger().addAppender(new ConsoleAppender(new SimpleLayout()));
	}

	/*
	 * Test method for 'org.eodisp.util.configuration.ConfigurationImpl.load()'
	 */
	public void testLoad() throws IOException {
		File tmpFile = File.createTempFile("test", ".conf");
		TestConfiguration testConfiguration1 = new TestConfiguration("Test Configuration 1", tmpFile);
		testConfiguration1.getEntry(TestConfiguration.BOOL1).setBoolean(true);
		testConfiguration1.getEntry(TestConfiguration.BOOL2).setBoolean(false);
		testConfiguration1.save();

		TestConfiguration testConfiguration2 = new TestConfiguration("Test Configuration 2", tmpFile);
		testConfiguration2.load();

		assertEquals(testConfiguration1, testConfiguration2);
		tmpFile.delete();
	}

	private enum TestEnum {
		ONE, TWO, THREE
	}

	public void testGetFile() throws Exception {
		ConfigurationImpl configurationImpl = new ConfigurationImpl("id", "name", "descr", null);
		Entry entry = configurationImpl.createFileEntry("file", new File("dir/subdir"), "descr");
		assertEquals(entry.getFile(), new File("dir/subdir"));
	}

	public void testGetEnum() throws Exception {
		ConfigurationImpl configurationImpl = new ConfigurationImpl("id", "name", "descr", null);
		Entry entry = configurationImpl.createEnumEntry("number", TestEnum.ONE, "descr");
		assertEquals("ONE", entry.getValue());
		assertEquals(TestEnum.ONE, entry.getEnum());
		assertSame(TestEnum.ONE, entry.getEnum());

		entry.setValue("three");
		assertEquals("three", entry.getValue());
		assertEquals(TestEnum.THREE, entry.getEnum());
		assertSame(TestEnum.THREE, entry.getEnum());

		entry.setValue("FOUR");
		assertEquals("FOUR", entry.getValue());
		assertEquals(
				"Setting a value that does not correspond to an enum constant must return default value",
				TestEnum.ONE,
				entry.getEnum());
	}

	public void testSetEnum() throws Exception {
		ConfigurationImpl configurationImpl = new ConfigurationImpl("id", "name", "descr", null);
		Entry entry = configurationImpl.createEnumEntry("number", TestEnum.ONE, "descr");
		entry.setEnum(TestEnum.TWO);
		assertEquals(TestEnum.TWO, entry.getEnum());
		assertSame(TestEnum.TWO, entry.getEnum());
		assertEquals("TWO", entry.getValue());
	}

	public void testGetEnumSet() throws Exception {
		ConfigurationImpl configurationImpl = new ConfigurationImpl("id", "name", "descr", null);
		Entry entry = configurationImpl.createEnumSetEntry("number", EnumSet.of(TestEnum.ONE), TestEnum.class, "descr");
		assertEquals("ONE", entry.getValue());
		assertEquals(EnumSet.of(TestEnum.ONE), entry.getEnumSet());
		
		entry.setValue("ONE,TWO");
		assertEquals("ONE,TWO", entry.getValue());
		assertEquals(EnumSet.of(TestEnum.ONE, TestEnum.TWO), entry.getEnumSet());

		entry.setValue(" ONE, TwO ");
		assertEquals(EnumSet.of(TestEnum.ONE, TestEnum.TWO), entry.getEnumSet());

		entry.setValue("");
		assertEquals("", entry.getValue());
		EnumSet<TestEnum> enumSet = EnumSet.noneOf(TestEnum.class);
		assertEquals(enumSet, entry.getEnumSet());

		entry.setValue("FOUR");
		assertEquals("FOUR", entry.getValue());
		assertEquals("Setting a value that does not correspond to an enum constant must return default value", EnumSet
				.of(TestEnum.ONE), entry.getEnumSet());

	}
	
	public void testSetEnumSet() throws Exception {
		ConfigurationImpl configurationImpl = new ConfigurationImpl("id", "name", "descr", null);
		Entry entry = configurationImpl.createEnumSetEntry("number", EnumSet.of(TestEnum.ONE), TestEnum.class, "descr");
		entry.setEnumSet(EnumSet.of(TestEnum.ONE, TestEnum.TWO));
		assertEquals(EnumSet.of(TestEnum.ONE, TestEnum.TWO), entry.getEnumSet());
		assertEquals("ONE,TWO", entry.getValue());
		
		entry.setEnumSet(EnumSet.noneOf(TestEnum.class));
		assertEquals(EnumSet.noneOf(TestEnum.class), entry.getEnumSet());
		assertEquals("", entry.getValue());
	}

	public void testNeedsSave() throws Exception {
		File tmpFile = File.createTempFile("test", ".conf");
		TestConfiguration testConfiguration1 = new TestConfiguration("Test Configuration 1", tmpFile);
		assertTrue(testConfiguration1.needsSave());

		testConfiguration1.setBool1(true);
		assertTrue(testConfiguration1.needsSave());

		testConfiguration1.save();
		assertFalse(testConfiguration1.needsSave());

		testConfiguration1.setBool1(true);
		assertFalse(testConfiguration1.needsSave());

		testConfiguration1.setBool1(false);
		assertTrue(testConfiguration1.needsSave());

		testConfiguration1.load();
		assertFalse(testConfiguration1.needsSave());

		testConfiguration1.setBool2(true);
		assertTrue(
				"Even though the default value is set to true, setting the actual value to true must still change the configuration",
				testConfiguration1.needsSave());

		tmpFile.delete();
	}

	public void testEqual() {
		TestConfiguration testConfiguration1 = new TestConfiguration("Test Configuration 1", null);
		testConfiguration1.getEntry(TestConfiguration.BOOL1).setBoolean(true);
		testConfiguration1.getEntry(TestConfiguration.BOOL2).setBoolean(false);
		testConfiguration1.getEntry(TestConfiguration.INT1).setInt(80);
		testConfiguration1.getEntry(TestConfiguration.INT2).setInt(1099);

		TestConfiguration testConfiguration2 = new TestConfiguration("Test Configuration 1", null);
		testConfiguration2.getEntry(TestConfiguration.BOOL1).setBoolean(true);
		testConfiguration2.getEntry(TestConfiguration.BOOL2).setBoolean(false);
		testConfiguration2.getEntry(TestConfiguration.INT1).setInt(80);
		testConfiguration2.getEntry(TestConfiguration.INT2).setInt(1099);

		assertEquals(testConfiguration1, testConfiguration2);

		testConfiguration2.getEntry(TestConfiguration.BOOL2).setBoolean(true);
		assertFalse(testConfiguration1.equals(testConfiguration2));
	}
}
