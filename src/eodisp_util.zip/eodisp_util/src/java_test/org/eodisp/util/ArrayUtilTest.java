package org.eodisp.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import junit.framework.TestCase;

public class ArrayUtilTest extends TestCase {

	public void testListToString_0() {
		List<String> testList = new ArrayList<String>();
		assertEquals("", ArrayUtil.listToString(testList));
	}

	public void testListToString_1() {
		List<String> testList = new ArrayList<String>();
		testList.add("a");
		assertEquals("a", ArrayUtil.listToString(testList));
	}

	public void testListToString_2() {
		List<String> testList = new ArrayList<String>();
		testList.add("a");
		testList.add("b");
		assertEquals("a,b", ArrayUtil.listToString(testList));
	}

	public void testListToString_3() {
		List<String> testList = new ArrayList<String>();
		testList.add("a");
		testList.add("b");
		testList.add("c");
		assertEquals("a,b,c", ArrayUtil.listToString(testList));
	}

	public void testStringToList_0() throws Exception {
		String string = "";
		String[] array = new String[0];
		assertTrue(Arrays.deepEquals(array, ArrayUtil.stringToArray(string)));
	}

	public void testStringToList_1() throws Exception {
		String string = "a";
		String[] array = new String[] { "a" };
		assertTrue(Arrays.deepEquals(array, ArrayUtil.stringToArray(string)));
	}

	public void testStringToList_2() throws Exception {
		String string = "a,b";
		String[] array = new String[] { "a", "b" };
		assertTrue(Arrays.deepEquals(array, ArrayUtil.stringToArray(string)));
	}

	public void testStringToList_3() throws Exception {
		String string = "a,b,c";
		String[] array = new String[] { "a", "b", "c" };
		assertTrue(Arrays.deepEquals(array, ArrayUtil.stringToArray(string)));
	}
	
	public void testStringToList_4() throws Exception {
		String string = ",a,b,,c, ";
		String[] array = new String[] { "a", "b", "c" };
		assertTrue(Arrays.deepEquals(array, ArrayUtil.stringToArray(string)));
	}

	public void testStringToList_5() throws Exception {
		String string = "a,b,c,";
		String[] array = new String[] { "a", "b", "c" };
		assertTrue(Arrays.deepEquals(array, ArrayUtil.stringToArray(string)));
	}

}
