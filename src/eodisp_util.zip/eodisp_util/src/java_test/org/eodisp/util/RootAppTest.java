package org.eodisp.util;

import java.io.File;

import org.eodisp.util.configuration.Configuration;
import org.eodisp.util.configuration.TestConfiguration;

import junit.framework.TestCase;

public class RootAppTest extends TestCase {

	public static class TestAppModule implements AppModule {
		static final String TEST_APP_ID_1 = "1";

		static final String TEST_APP_ID_2 = "2";

		boolean ranStartup = false;

		boolean ranPostStartup = false;

		boolean ranShutdown = false;

		boolean ranPostShutdown = false;

		TestConfiguration testConfiguration1 = null;

		TestConfiguration testConfiguration2 = null;

		public String getId() {
			return TEST_APP_ID_1;
		}

		public void registerConfiguration(RootApp rootApp) throws Exception {
			testConfiguration1 = new TestConfiguration(TEST_APP_ID_1, File.createTempFile("test1", ".conf"));
			testConfiguration2 = new TestConfiguration(TEST_APP_ID_2, File.createTempFile("test2", ".conf"));
			rootApp.registerConfiguration(testConfiguration1);
			rootApp.registerConfiguration(testConfiguration2);
		}

		public void startup(RootApp rootApp) throws Exception {
			ranStartup = true;
		}

		public void preStartup(RootApp rootApp) throws Exception {
			ranPostStartup = true;

		}

		public void shutdown(RootApp rootApp) throws Exception {
			ranShutdown = true;

		}

		public void postShutdown(RootApp rootApp) throws Exception {
			ranPostShutdown = true;
		}

	}

	public static class IncrementalAppModuleDuringRegistering extends AbstractAppModule {
		static final String TEST_APP_ID_3 = "3";

		@Override
		public String getId() {
			return TEST_APP_ID_3;
		}

		@Override
		public void registerConfiguration(RootApp rootApp) {
			rootApp.registerAppModule(new TestAppModule());
		}

	}
	
	public static class IncrementalAppModuleDuringPreStartup extends AbstractAppModule {
		static final String ID = "4";

		@Override
		public String getId() {
			return ID;
		}
		
		@Override
		public void preStartup(RootApp rootApp) {
			rootApp.registerAppModule(new TestAppModule());
		}

	}
	
	public static class IncrementalAppModuleDuringStartup extends AbstractAppModule {
		static final String ID = "5";

		@Override
		public String getId() {
			return ID;
		}
		
		@Override
		public void startup(RootApp rootApp) {
			rootApp.registerAppModule(new TestAppModule());
		}

	}

	public void testRegistry() throws Exception {
		RootApp rootApp = new RootApp(
				"Test App",
				"Test Application",
				new File(System.getProperty("java.io.tmpdir")),
				RootApp.class);
		assertEquals(rootApp, AppRegistry.getRootApp());
	}

	/*
	 * Test method for
	 * 'org.eodisp.util.Application.registerConfiguration(Configuration)'
	 */
	public void testRegisterConfiguration() {
		Configuration config1 = new TestConfiguration("config1", null);
		Configuration config2 = new TestConfiguration("config1", null);

		RootApp rootApp = new RootApp(
				"Test App",
				"Test Application",
				new File(System.getProperty("java.io.tmpdir")),
				RootApp.class);
		rootApp.registerConfiguration(config1);
		try {
			rootApp.registerConfiguration(config2);
			fail("Registering two configurations with the same name must throw an IllegalArgumentException");
		} catch (IllegalArgumentException exp) {
			assertTrue(true);
		}
	}

	public void testExecute() throws Exception {
		RootApp rootApp = new RootApp(
				"Test App",
				"Test Application",
				new File(System.getProperty("java.io.tmpdir")),
				RootApp.class);
		TestAppModule testAppModule = new TestAppModule();
		rootApp.registerAppModule(testAppModule);
		rootApp.execute(new String[0]);

		Configuration configuration1 = rootApp.getConfiguration(TestAppModule.TEST_APP_ID_1);
		Configuration configuration2 = rootApp.getConfiguration(TestAppModule.TEST_APP_ID_2);
		assertSame(configuration1, testAppModule.testConfiguration1);
		assertSame(configuration2, testAppModule.testConfiguration2);

		assertTrue(testAppModule.ranStartup);
		assertTrue(testAppModule.ranPostStartup);

		rootApp.shutdown();
		assertTrue(testAppModule.ranShutdown);
		assertTrue(testAppModule.ranPostShutdown);
	}

	public void testExecuteIncrementalModuleAdditionsDuringConfigurationRegistration() throws Exception {
		RootApp rootApp = new RootApp(
				"Test App",
				"Test Application",
				new File(System.getProperty("java.io.tmpdir")),
				RootApp.class);
		IncrementalAppModuleDuringRegistering incAppModule = new IncrementalAppModuleDuringRegistering();

		rootApp.registerAppModule(incAppModule);
		rootApp.execute(new String[0]);

		TestAppModule testAppModule = (TestAppModule) rootApp.getAppModule(TestAppModule.TEST_APP_ID_1);
		assertNotNull("Incrementally added application module must be registered with root application", testAppModule);

		Configuration configuration1 = rootApp.getConfiguration(TestAppModule.TEST_APP_ID_1);
		Configuration configuration2 = rootApp.getConfiguration(TestAppModule.TEST_APP_ID_2);
		assertNotNull(configuration1);
		assertNotNull(configuration2);

		assertTrue("Test Module not started", testAppModule.ranStartup);
		assertTrue("Test Module not post-started", testAppModule.ranPostStartup);

		rootApp.shutdown();
		assertTrue(testAppModule.ranShutdown);
		assertTrue(testAppModule.ranPostShutdown);
	}
	
	public void testExecuteIncrementalModuleAdditionsAtPreStartup() throws Exception {
		RootApp rootApp = new RootApp(
				"Test App",
				"Test Application",
				new File(System.getProperty("java.io.tmpdir")),
				RootApp.class);
		IncrementalAppModuleDuringPreStartup incAppModule = new IncrementalAppModuleDuringPreStartup();

		rootApp.registerAppModule(incAppModule);
		rootApp.execute(new String[0]);

		TestAppModule testAppModule = (TestAppModule) rootApp.getAppModule(TestAppModule.TEST_APP_ID_1);
		assertNotNull("Incrementally added application module must be registered with root application", testAppModule);

		Configuration configuration1 = rootApp.getConfiguration(TestAppModule.TEST_APP_ID_1);
		Configuration configuration2 = rootApp.getConfiguration(TestAppModule.TEST_APP_ID_2);
		assertNotNull(configuration1);
		assertNotNull(configuration2);

		assertTrue("Test Module not started", testAppModule.ranStartup);
		assertTrue("Test Module not post-started", testAppModule.ranPostStartup);

		rootApp.shutdown();
		assertTrue(testAppModule.ranShutdown);
		assertTrue(testAppModule.ranPostShutdown);
	}
	
	public void testExecuteIncrementalModuleAdditionsAtStartup() throws Exception {
		RootApp rootApp = new RootApp(
				"Test App",
				"Test Application",
				new File(System.getProperty("java.io.tmpdir")),
				RootApp.class);
		IncrementalAppModuleDuringStartup incAppModule = new IncrementalAppModuleDuringStartup();

		rootApp.registerAppModule(incAppModule);
		rootApp.execute(new String[0]);

		TestAppModule testAppModule = (TestAppModule) rootApp.getAppModule(TestAppModule.TEST_APP_ID_1);
		assertNotNull("Incrementally added application module must be registered with root application", testAppModule);

		Configuration configuration1 = rootApp.getConfiguration(TestAppModule.TEST_APP_ID_1);
		Configuration configuration2 = rootApp.getConfiguration(TestAppModule.TEST_APP_ID_2);
		assertNotNull(configuration1);
		assertNotNull(configuration2);
		

		assertTrue("Test Module not started", testAppModule.ranStartup);
		assertTrue("Test Module not post-started", testAppModule.ranPostStartup);

		rootApp.shutdown();
		assertTrue(testAppModule.ranShutdown);
		assertTrue(testAppModule.ranPostShutdown);
	}

	public void testCommandLine() throws Exception {
		RootApp rootApp = new RootApp(
				"Test App",
				"Test Application",
				new File(System.getProperty("java.io.tmpdir")),
				RootApp.class);
		TestAppModule testAppModule = new TestAppModule();
		rootApp.registerAppModule(testAppModule);
		String[] args = {};
		rootApp.execute(args);

		Configuration configuration1 = rootApp.getConfiguration(TestAppModule.TEST_APP_ID_1);
		Configuration configuration2 = rootApp.getConfiguration(TestAppModule.TEST_APP_ID_2);
		assertSame(configuration1, testAppModule.testConfiguration1);
		assertSame(configuration2, testAppModule.testConfiguration2);
	}

	public static void main(String[] args) {
		RootApp rootApp = new RootApp(
				"Test App",
				"Test Application",
				new File(System.getProperty("java.io.tmpdir")),
				RootAppTest.class);
		TestAppModule testAppModule = new TestAppModule();
		rootApp.registerAppModule(testAppModule);
		String[] args1 = { "--help" };
		rootApp.execute(args1);
	}

	public void testWorkingDir() throws Exception {
		File defaultWorkingDir = new File(System.getProperty("java.io.tmpdir"));
		File workingDir = new File(System.getProperty("java.io.tmpdir"), "eodisp-test-wd");
		RootApp rootApp = new RootApp("Test App", "Test Application", defaultWorkingDir, RootAppTest.class);
		assertEquals(defaultWorkingDir, rootApp.getDefaultWorkingDir());
		assertNull(rootApp.getWorkingDir());

		String[] args = { "--working-dir", workingDir.getAbsolutePath() };
		rootApp.execute(args);

		assertEquals(rootApp.getWorkingDir(), workingDir);
		testConfDir(rootApp.getWorkingDir(), rootApp.getConfigurationDir());
		testDataDir(rootApp.getWorkingDir(), rootApp.getDataDir());

		rootApp.shutdown();
		assertNull(rootApp.getWorkingDir());
	}

	public void testWorkingDirDefault() throws Exception {
		File defaultWorkingDir = new File(System.getProperty("java.io.tmpdir"));
		RootApp rootApp = new RootApp("Test App", "Test Application", defaultWorkingDir, RootAppTest.class);

		rootApp.execute(new String[0]);
		assertEquals(defaultWorkingDir, rootApp.getWorkingDir());
		testConfDir(rootApp.getWorkingDir(), rootApp.getConfigurationDir());
		testDataDir(rootApp.getWorkingDir(), rootApp.getDataDir());
	}

	public void testWorkingDirSystemProperty() throws Exception {
		File defaultWorkingDir = new File(System.getProperty("java.io.tmpdir"));
		File workingDir = new File(System.getProperty("java.io.tmpdir"), "eodisp-test-wd");
		RootApp rootApp = new RootApp("Test App", "Test Application", defaultWorkingDir, RootApp.class);
		System.setProperty(RootApp.WORKING_DIR_SYSTEM_PROPERTY, workingDir.getAbsolutePath());
		rootApp.execute(new String[0]);
		assertEquals(workingDir, rootApp.getWorkingDir());
		testConfDir(rootApp.getWorkingDir(), rootApp.getConfigurationDir());
		testDataDir(rootApp.getWorkingDir(), rootApp.getDataDir());
	}

	private static void testConfDir(File workingDirectory, File configDir) {
		assertEquals(new File(workingDirectory, "conf"), configDir);
	}

	private static void testDataDir(File workingDirectory, File dataDir) {
		assertEquals(new File(workingDirectory, "data"), dataDir);
	}

}
