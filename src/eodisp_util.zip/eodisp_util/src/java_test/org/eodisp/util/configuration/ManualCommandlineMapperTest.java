package org.eodisp.util.configuration;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import org.eodisp.util.configuration.Configuration.Entry;
import org.eodisp.util.configuration.ManualCommandlineMapper.CommandlineOption;

import com.martiansoftware.jsap.Flagged;
import com.martiansoftware.jsap.Parameter;

public class ManualCommandlineMapperTest extends TestCase {

	/*
	 * Test method for
	 * 'org.eodisp.util.configuration.CommandlineFrontEnd.getParameters(Configuration)'
	 */
	public void testGetParametersConfiguration() throws IOException {
		TestConfiguration testConfiguration = new TestConfiguration();
		Map<String, CommandlineOption> commandlineMapping = new HashMap<String, CommandlineOption>();
		commandlineMapping.put(TestConfiguration.BOOL1,  new CommandlineOption(new Character('b'), null, null));
		commandlineMapping.put(TestConfiguration.BOOL2, new CommandlineOption(null, "bool2-long", null));
		commandlineMapping.put(TestConfiguration.INT1, new CommandlineOption(null, null, "another help for int1"));
		commandlineMapping.put(TestConfiguration.INT2, new CommandlineOption(new Character('i'), "int2-long", "another help for int2"));
		
		ManualCommandlineMapper manualCommandlineMapper = new ManualCommandlineMapper( commandlineMapping );
		for( Entry entry : testConfiguration.entries() ) {
			
			Parameter parameter = manualCommandlineMapper.mapEntry( entry );
			
			if (parameter.getID().equals("testConfig.bool1")) {
				assertEquals(((Flagged) parameter).getShortFlag(), 'b');
			}

			if (parameter.getID().equals("testConfig.bool2")) {
				assertEquals(((Flagged) parameter).getLongFlag(), "bool2-long");
			}

			if (parameter.getID().equals("testConfig.int1")) {
				assertEquals(parameter.getHelp(), "another help for int1");
			}

			if (parameter.getID().equals("testConfig.int2")) {
				assertEquals(((Flagged) parameter).getShortFlag(), 'i');
				assertEquals(((Flagged) parameter).getLongFlag(), "int2-long");
				assertEquals(parameter.getHelp(), "another help for int2");
			}
			
		}
	}
	
	/*
	 * Test method for
	 * 'org.eodisp.util.configuration.CommandlineFrontEnd.getParameters(Configuration)'
	 */
	public void testManualMappings() throws IOException {
		TestConfiguration testConfiguration = new TestConfiguration();
		Map<String, CommandlineOption> commandlineMapping = new HashMap<String, CommandlineOption>();
		commandlineMapping.put(TestConfiguration.BOOL1,  new CommandlineOption(new Character('b'), null, null));
		commandlineMapping.put(TestConfiguration.INT1, new CommandlineOption(null, null, "another help for int1"));
		commandlineMapping.put(TestConfiguration.INT2, new CommandlineOption(new Character('i'), "int2-long", "another help for int2"));
		
		ManualCommandlineMapper manualCommandlineMapper = new ManualCommandlineMapper( commandlineMapping );
		for( Entry entry : testConfiguration.entries() ) {
			
			Parameter parameter = manualCommandlineMapper.mapEntry( entry );
			if( entry.getKey().equals(TestConfiguration.BOOL2) ) {
				assertNull(parameter);
				continue;
			}
			if (parameter.getID().equals("testConfig.bool1")) {
				assertEquals(((Flagged) parameter).getShortFlag(), 'b');
			}

			if (parameter.getID().equals("testConfig.bool2")) {
				assertEquals(((Flagged) parameter).getLongFlag(), "bool2-long");
			}

			if (parameter.getID().equals("testConfig.int1")) {
				assertEquals(parameter.getHelp(), "another help for int1");
			}

			if (parameter.getID().equals("testConfig.int2")) {
				assertEquals(((Flagged) parameter).getShortFlag(), 'i');
				assertEquals(((Flagged) parameter).getLongFlag(), "int2-long");
				assertEquals(parameter.getHelp(), "another help for int2");
			}
			
		}
	}
	
	public void testManualMappingsBasicMapping() throws IOException {
		TestConfiguration testConfiguration = new TestConfiguration();
		Map<String, CommandlineOption> commandlineMapping = new HashMap<String, CommandlineOption>();
		commandlineMapping.put(TestConfiguration.BOOL1,  new CommandlineOption(new Character('b'), null, null));
		commandlineMapping.put(TestConfiguration.INT1, new CommandlineOption(null, null, "another help for int1"));
		commandlineMapping.put(TestConfiguration.INT2, new CommandlineOption(new Character('i'), "int2-long", "another help for int2"));
		
		ManualCommandlineMapper manualCommandlineMapper = new ManualCommandlineMapper( commandlineMapping, true );
		for( Entry entry : testConfiguration.entries() ) {
			
			Parameter parameter = manualCommandlineMapper.mapEntry( entry );
			if( entry.getKey().equals(TestConfiguration.BOOL2) ) {
				assertEquals(((Flagged) parameter).getLongFlag(), TestConfiguration.BOOL2);
				continue;
			}
			if (parameter.getID().equals("testConfig.bool1")) {
				assertEquals(((Flagged) parameter).getShortFlag(), 'b');
			}

			if (parameter.getID().equals("testConfig.bool2")) {
				assertEquals(((Flagged) parameter).getLongFlag(), "bool2-long");
			}

			if (parameter.getID().equals("testConfig.int1")) {
				assertEquals(parameter.getHelp(), "another help for int1");
			}

			if (parameter.getID().equals("testConfig.int2")) {
				assertEquals(((Flagged) parameter).getShortFlag(), 'i');
				assertEquals(((Flagged) parameter).getLongFlag(), "int2-long");
				assertEquals(parameter.getHelp(), "another help for int2");
			}
			
		}
	}
	
	

	/*
	 * Test method for
	 * 'org.eodisp.util.configuration.CommandlineFrontEnd.getParameters(Configuration,
	 * Map<String, ParamMapping>)'
	 */
	public void testGetParametersConfigurationMapOfStringParamMapping() throws IOException {
		TestConfiguration testConfiguration = new TestConfiguration();
		for( Entry entry : testConfiguration.entries() ) {
			Parameter parameter = BasicCommandlineMapper.INSTANCE.mapEntry( entry );
			if (parameter.getID().equals("testConfig.bool1")) {
				assertNull(((Flagged) parameter).getShortFlagCharacter());
				assertEquals(TestConfiguration.BOOL1, ((Flagged) parameter).getLongFlag());
				assertEquals(TestConfiguration.BOOL1_HELP, parameter.getHelp());
			}

			if (parameter.getID().equals("testConfig.bool2")) {
				assertNull(((Flagged) parameter).getShortFlagCharacter());
				assertEquals(TestConfiguration.BOOL2, ((Flagged) parameter).getLongFlag());
				assertEquals(TestConfiguration.BOOL2_HELP, parameter.getHelp());
			}

			if (parameter.getID().equals("testConfig.int1")) {
				assertNull(((Flagged) parameter).getShortFlagCharacter());
				assertEquals(TestConfiguration.INT1, ((Flagged) parameter).getLongFlag());
				assertEquals(TestConfiguration.INTEGER1_HELP, parameter.getHelp());
			}

			if (parameter.getID().equals("testConfig.int2")) {
				assertNull(((Flagged) parameter).getShortFlagCharacter());
				assertEquals(TestConfiguration.INT2, ((Flagged) parameter).getLongFlag());
				assertEquals(TestConfiguration.INTEGER2_HELP, parameter.getHelp());
			}
		}
	}

}
