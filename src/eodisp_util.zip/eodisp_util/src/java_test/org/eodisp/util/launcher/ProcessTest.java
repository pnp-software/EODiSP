package org.eodisp.util.launcher;

import static java.util.concurrent.TimeUnit.*;

import java.util.concurrent.CountDownLatch;

import junit.framework.TestCase;

import org.apache.log4j.*;
import org.apache.tools.ant.types.CommandlineJava;
import org.apache.tools.ant.types.Path;

public class ProcessTest extends TestCase {
	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	static Logger logger = Logger.getLogger(ProcessTest.class);

	static {
		Logger.getRootLogger().addAppender(new ConsoleAppender(new SimpleLayout()));
		Logger.getRootLogger().setLevel(Level.DEBUG);
	}

	public static Process newTestMainProcess(int secondsToRun) {
		CommandlineJava cli = new CommandlineJava();
		cli.createClasspath(null);
		cli.getClasspath().add(Path.systemClasspath);
		cli.setClassname(TestMain.class.getName());
		cli.createArgument().setLine(String.valueOf(secondsToRun));
		return new ProcessImpl(cli);
	}

	public void testLaunch() throws Exception {
		final CountDownLatch countDownLatch = new CountDownLatch(2);

		Process process = newTestMainProcess(0);
		process.addListener(new ProcessListener() {
			public void processStarted() {
				countDownLatch.countDown();
			}

			public void processTerminated(int exitCode) {
				countDownLatch.countDown();
			}
		});
		process.launch();
		assertTrue(countDownLatch.await(3, SECONDS));
	}

	public void testLaunch1() throws Exception {
		final CountDownLatch countDownLatch = new CountDownLatch(2);

		Process process = newTestMainProcess(2);
		process.addListener(new ProcessListener() {
			public void processStarted() {
				countDownLatch.countDown();
			}

			public void processTerminated(int exitCode) {
				countDownLatch.countDown();
			}
		});
		process.launch();
		assertFalse(countDownLatch.await(1, SECONDS));
		assertTrue(countDownLatch.await(10, SECONDS));
	}

	public void testLaunch_IllegalStateException() throws Exception {
		Process process = newTestMainProcess(10);
		process.launch();
		try {
			process.launch();
			fail("Expected IllegalStateException when launching a process a second time");
		} catch (IllegalStateException expected) {
			assertTrue(true);
		}
	}

	public void testKill() throws Exception {
		Process process = newTestMainProcess(10);
		assertFalse("kill must always return false if process has not yet been started", process.kill(0));
		process.launch();
		assertTrue(process.kill(5000));
		assertTrue(process.kill(10000));
		assertTrue(process.kill(1));
	}
}
