/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com
 *  mail: info@pnp-software.com
 */
package org.eodisp.util;

import java.io.*;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.channels.OverlappingFileLockException;
import java.util.*;

import org.apache.log4j.*;
import org.eodisp.util.configuration.*;
import org.eodisp.util.configuration.Configuration.Entry;

import com.martiansoftware.jsap.*;

/**
 * The root application is holds registered application modules and
 * configurations.
 * <p>
 * As of now there can only be one RootApp instance in one JVM. This instance is
 * registered with the {@link org.eodisp.util.AppRegistry} at the time an
 * instance of this class is created. An assertion exception will be thrown if
 * you try to create two instances of this class.
 * <p>
 * This class is not thread safe. It is assumed that the
 * <code>registerXXX</code> methods are not called concurrently from different
 * Threads.
 * <p>
 * Most of the functionality of a Java application should be implemented in
 * separate application modules. Only very few core functionality is directly
 * implemented in this class:
 * <ul>
 * <li>Setting up the working directory. See {@link #initWorkingDirs(String[])}</li>
 * <li>Setting up the logging framework (log4j). See
 * {@link #initLogger(String[])}</li>
 * </ul>
 * 
 * @author ibirrer
 * @version $Id: RootApp.java 4154 2006-10-26 13:33:47Z ibirrer $
 * @see org.eodisp.util.AppModule
 * @see org.eodisp.util.configuration.Configuration
 */
public class RootApp {

	private static final String DATA_REL_PATH = "data";

	private static final String CONFIGURATION_REL_PATH = "conf";

	private static final String WORKING_DIR_OPTION = "working-dir";

	public static final String WORKING_DIR_SYSTEM_PROPERTY = "org.eodisp.working-dir";

	private static final char WORKING_DIR_SHORT_OPTION = 'w';

	private static final String HELP_OPTION = "help";

	private static final char HELP_SHORT_OPTION = 'h';

	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	private final static Logger logger = Logger.getLogger(RootApp.class);

	/**
	 * The arguments given in the {@link #execute(String[])} method.
	 */
	private String[] args;

	/**
	 * Holds the configuration instances of this application
	 */
	private Map<String, Configuration> configurations = new HashMap<String, Configuration>();

	/**
	 * Keeps track of the configuration that have not yet been initialized (from
	 * any source: command line, file, system properties).
	 */
	private List<Configuration> notInitializedConfigurations = new ArrayList<Configuration>();

	private Map<String, CommandlineMapper> cliMappers = new HashMap<String, CommandlineMapper>();

	private Map<String, SystemPropertyMapper> sysPropMappers = new HashMap<String, SystemPropertyMapper>();

	/**
	 * Holds the application modules this root application is made up of.
	 */
	private Map<String, AppModule> appModules = new HashMap<String, AppModule>();

	private List<AppModule> stoppedAppModules = new ArrayList<AppModule>();

	private List<AppModule> configRegisteredAppModules = new ArrayList<AppModule>();

	private List<AppModule> preStartedAppModules = new ArrayList<AppModule>();

	private List<AppModule> startedAppModules = new ArrayList<AppModule>();

	private List<AppModule> initiallyRegisteredAppModules;

	/**
	 * The default working directory of the root application. Must be absolute.
	 */
	private final File defaultWorkingDir;

	private File workingDir;

	private File confDir;

	private File dataDir;

	/**
	 * The name of the application. Used for customizing some of the help texts.
	 * Can be accessed by the application modules and may be shown to the user.
	 */
	private final String name;

	public enum RunState {
		STOPPED, INIT_CONFIGURATION, STARTUP, PRE_STARTUP, SHUTDOWN, POST_SHUTDOWN, EXECUTING
	}

	private RunState runState = RunState.STOPPED;

	private JSAP jsap;

	/**
	 * The class that contains the main method to start this class.
	 */
	private Class mainClass = null;

	private final Appender defaultLog4JAppender;

	private final String description;

	/**
	 * Creates a new root application and registers it with the
	 * {@link AppManager}.
	 * 
	 * @param defaultWorkingDir
	 *            The default working directory of the root application. The
	 *            given file path must be absolute.
	 * @param name
	 *            The name of the application. Used for customizing some of the
	 *            help texts. Can be accessed by the application modules and may
	 *            be shown to the user.
	 * @param mainClass
	 *            The class that contains the main method from which the JVM was
	 *            originally started from. Used for command line usage help
	 *            output.
	 */
	public RootApp(String name, String description, File defaultWorkingDir, Class mainClass) {

		assert (defaultWorkingDir.isAbsolute());
		defaultLog4JAppender = new ConsoleAppender(new PatternLayout("%-5p [%d{yyyy-MM-dd HH:mm:ss}] [" + name
				+ ":%t]: %m%n"));
		LogManager.resetConfiguration();
		Logger.getRootLogger().addAppender(defaultLog4JAppender);
		Logger.getRootLogger().setLevel(Level.INFO);

		this.name = name;
		this.description = description;
		this.defaultWorkingDir = defaultWorkingDir;
		this.mainClass = mainClass;
		AppRegistry.registerRootApp(this);
	}

	/**
	 * Executes the root application.
	 * 
	 * @param commandLineArgs
	 *            The arguments given on the command line. Normally this should
	 *            be the <code>args</code> variable from
	 *            <code>main( String[] args )</code>.
	 */
	public void execute(String[] commandLineArgs) {
		if (initiallyRegisteredAppModules == null) {
			initiallyRegisteredAppModules = new ArrayList<AppModule>(stoppedAppModules);
		}
		this.args = commandLineArgs;

		if (runState != RunState.STOPPED) {
			throw new IllegalStateException("Can only execute root application if in STOPPED state");
		}

		initJsap();
		try {
			initWorkingDirs(args);
		} catch (IOException e1) {
			System.err.println("Could not create application directories: " + e1.getMessage());
			System.exit(1);
		}

		final File lockFile = new File(workingDir, ".lock");
		try {
			// Get a file channel for the file
			FileChannel channel = new RandomAccessFile(lockFile, "rw").getChannel();

			// Try acquiring the lock without blocking. This method returns
			// null or throws an exception if the file is already locked.
			try {
				FileLock lock = channel.tryLock();
				if (lock == null) {
					System.err
							.printf(
									"An instance of '%s' is already running. If that instance quit abnormally, delete the lock file at '%s' be able to start another instance.%n",
									name, lockFile);
					System.exit(1);
				}
			} catch (OverlappingFileLockException e) {
				System.err
						.printf(
								"An instance of '%s' is already running. If that instance quit abnormally, delete the lock file at '%s' be able to start another instance.%n",
								name, lockFile);
				System.exit(1);
			}
		} catch (Throwable e) {
			System.err.printf("Could not create and lock file: %s", lockFile);
			e.printStackTrace();
			System.exit(1);
		}

		initLogger(args);
		runState = RunState.INIT_CONFIGURATION;
		registerConfigurations(stoppedAppModules);

		runState = RunState.PRE_STARTUP;
		preStartup(configRegisteredAppModules);

		runState = RunState.STARTUP;
		startup(preStartedAppModules);
		runState = RunState.EXECUTING;
	}

	public void executeAdditionalAppModules() {
		List<AppModule> modulesToExecut = new ArrayList<AppModule>(stoppedAppModules);
		registerConfigurations(modulesToExecut);
		preStartup(modulesToExecut);
		startup(modulesToExecut);
	}

	/**
	 * Shuts down the root the root application.
	 */
	public void shutdown() {
		runState = RunState.SHUTDOWN;
		shutdownAppModules();

		runState = RunState.POST_SHUTDOWN;
		postShutdown();
		configurations.clear();
		workingDir = null;
		this.confDir = null;
		this.dataDir = null;
		this.jsap = null;
		runState = RunState.STOPPED;
	}

	/**
	 * The working directory. It is initially not set (returns <code>null</code>)
	 * and only when invoking {@link #execute(String[])} it is set. It is unset
	 * (null) after shutting down the root application.
	 * 
	 * @return the working directory
	 */
	public File getWorkingDir() {
		return workingDir;
	}

	/**
	 * Returns the standard configuration path for this root application
	 * 
	 * @return the standard configuration path for this root application
	 */
	public File getConfigurationDir() {
		return confDir;
	}

	/**
	 * Returns the standard data path for this root application
	 * 
	 * @return the standard data path for this root application
	 */
	public File getDataDir() {
		return dataDir;
	}

	/**
	 * The default working directory of this root application. This is not
	 * necessarily the same as the working directory. The working directory can
	 * be set on the command line or through the Java system properties.
	 * 
	 * @return the default working directory (always absolute)
	 */
	protected File getDefaultWorkingDir() {
		return defaultWorkingDir;
	}

	/**
	 * Registers and application module with the root application. The startup
	 * sequence of the application modules is specified by the sequence of calls
	 * to this method. The application module that is registered first is also
	 * the first that is being started. This method must only be called before
	 * the {@link #execute()} method is invoked.
	 * {@link AppModule#initConfiguration()}
	 */
	public void registerAppModule(AppModule appModule) {
		appModules.put(appModule.getId(), appModule);
		stoppedAppModules.add(appModule);
	}

	public AppModule getAppModule(String appModuleId) {
		return appModules.get(appModuleId);
	}

	/**
	 * Registers a Configuration. No mapping of configuration entries to command
	 * line parameters is done.
	 * <p>
	 * This method must only be called during the configuration initialization
	 * phase, i.e. in implementation of the method
	 * {@link AppModule#initConfiguration()}
	 * 
	 * @param configuration
	 *            The configuration to be registered. Each configuration
	 *            registered must have a distinct id
	 * @return the newly registered configuration
	 * @throws IllegalArgumentException
	 *             if a configuration with the same name is already registered.
	 * @throws NullPointerException
	 *             if given configuration is <code>null</code>
	 */
	public Configuration registerConfiguration(Configuration configuration) {
		return registerConfiguration(configuration, CommandlineMapper.NULL_COMMAND_LINE_MAPPER);
	}

	/**
	 * Registers a Configuration with a associated command line mapper. The
	 * command line mapper is used to generate a command line parser that parses
	 * command line options given by a user. This method must only be called
	 * during the configuration initialization phase, i.e. in implementation of
	 * the method {@link AppModule#registerConfiguration(RootApp)}
	 * 
	 * @param configuration
	 *            The configuration to be registered. Each configuration
	 *            registered must have a distinct id
	 * @param commandlineMapper
	 * @return the newly registered configuration
	 * @throws IllegalArgumentException
	 *             if a configuration with the same name is already registered.
	 * @throws NullPointerException
	 *             if any of the arguments is <code>null</code>. Use
	 *             {@link CommandlineMapper#NULL_COMMAND_LINE_MAPPER} instead of
	 *             <code>null</code>.
	 */
	public Configuration registerConfiguration(Configuration configuration, CommandlineMapper commandlineMapper) {
		return registerConfiguration(configuration, commandlineMapper, SystemPropertyMapper.NULL_SYSTEM_PROPERTY_MAPPER);
	}

	/**
	 * Registers a Configuration with a associated command line mapper and
	 * system property mapper. The command line mapper is used to generate a
	 * command line parser that parses command line options given by a user. If
	 * a mapping to a system property exists, the configuration is updated at
	 * startup by reading the system property.
	 * <p>
	 * The order in which configuration are read is as follows
	 * <ol>
	 * <li>Configuration File</li>
	 * <li>System Property</li>
	 * <li>Command line arguments</li>
	 * </ol>
	 * This method must only be called during the configuration initialization
	 * phase, i.e. in implementation of the method
	 * {@link AppModule#initConfiguration()}
	 * 
	 * @param configuration
	 *            The configuration to be registered. Each configuration
	 *            registered must have a distinct id
	 * @param commandlineMapper
	 * @param systemPropertyMapper
	 * @return the newly registered configuration
	 * @throws IllegalArgumentException
	 *             if a configuration with the same name is already registered.
	 * @throws NullPointerException
	 *             if any of the arguments is <code>null</code>. Use
	 *             {@link CommandlineMapper#NULL_COMMAND_LINE_MAPPER} and
	 *             {@link SystemPropertyMapper#NULL_SYSTEM_PROPERTY_MAPPER}
	 *             instead of <code>null</code>.
	 */
	public Configuration registerConfiguration(Configuration configuration, CommandlineMapper commandlineMapper,
			SystemPropertyMapper systemPropertyMapper) {
		if (configurations.containsKey(configuration.getId())) {
			throw new IllegalArgumentException(String.format("A configuration with the id [%s] is already registered",
					configuration.getId()));
		}

		if (configuration == null || commandlineMapper == null || systemPropertyMapper == null) {
			throw new NullPointerException("Null arguments not allowed for RootApp#registerConfiguration(...)");
		}

		cliMappers.put(configuration.getId(), commandlineMapper);
		sysPropMappers.put(configuration.getId(), systemPropertyMapper);
		notInitializedConfigurations.add(configuration);
		return configurations.put(configuration.getId(), configuration);
	}

	/**
	 * Returns the configuration identified by the configuration id parameter.
	 * 
	 * @param configurationId
	 *            The id of the configuration to be retrieved.
	 * @return the configuration identified by the given configuration id
	 *         parameter or <code>null</code> if no configuration with the
	 *         given name exists.
	 */
	public Configuration getConfiguration(String configurationId) {
		return configurations.get(configurationId);
	}

	/**
	 * Returns the state of this application.
	 * 
	 * @return the state of this application.
	 */
	public RunState getRunState() {
		return runState;
	}

	/**
	 * Creates the JSAP instance and adds the following options:
	 * <ul>
	 * <li><code>--help</code></li>
	 * <li><code>--working-dir</code></li>
	 * <li><code>--delete-lock</code></li>
	 * </ul>
	 */
	protected void initJsap() {
		jsap = new JSAP();

		// Create global parameters command line parameters
		Switch help = new Switch(HELP_OPTION).setShortFlag(HELP_SHORT_OPTION).setLongFlag(HELP_OPTION);
		help.setHelp("Display this help text and exit.");

		FlaggedOption workingDirOption = new FlaggedOption(WORKING_DIR_OPTION).setShortFlag(WORKING_DIR_SHORT_OPTION)
				.setLongFlag(WORKING_DIR_OPTION).setStringParser(JSAP.STRING_PARSER);
		workingDirOption
				.setHelp(String
						.format(
								"The working directory of the %1$s. This is the directory where the %1$s will save its configuration and data. Default is '%2$s', or the value of the '%3$s' Java system property.",
								this.name, this.defaultWorkingDir.getAbsolutePath(), WORKING_DIR_SYSTEM_PROPERTY));

		try {
			// Register global parameters
			jsap.registerParameter(help);
			jsap.registerParameter(workingDirOption);
		} catch (JSAPException e1) {
			// Should never happen...
			System.err.println("Fatal Error while adding command line parameters: " + e1.getMessage());
			e1.printStackTrace();
			System.exit(1);
		}
	}

	/**
	 * Determines the working directory of this root application. Precedence is
	 * as follows:
	 * <ol>
	 * <li>The path that was given to the command line option
	 * <code>--working-dir</code></li>
	 * <li>The value that is set for the <code>org.eodisp.working-dir</code>
	 * system property</li>
	 * <li>Default value given to the constructor of the root application</li>
	 * </ol>
	 * 
	 * @param args
	 * @throws IOException
	 */
	protected void initWorkingDirs(String[] args) throws IOException {
		JSAPResult cliOptions = jsap.parse(args);
		workingDir = defaultWorkingDir;

		// Setting working-dir from Java System Properties
		if (System.getProperty(WORKING_DIR_SYSTEM_PROPERTY) != null) {
			workingDir = new File(System.getProperty(WORKING_DIR_SYSTEM_PROPERTY)).getAbsoluteFile();
		}

		// Parse command line
		if (cliOptions.contains(WORKING_DIR_OPTION)) {
			// resolves the given path to the directory the program was
			// started in.
			String wdOption = cliOptions.getString(WORKING_DIR_OPTION).trim();
			workingDir = new File(wdOption).getAbsoluteFile();
		}

		dataDir = new File(workingDir, DATA_REL_PATH);
		if (dataDir.mkdirs()) {
			logger.debug("Created data directory at " + dataDir.getAbsolutePath());
		}

		confDir = new File(workingDir, CONFIGURATION_REL_PATH);
		if (confDir.mkdirs()) {
			logger.debug("Created config directory at " + confDir.getAbsolutePath());
		}

		if (!dataDir.exists()) {
			throw new IOException(String.format("Could not create data directory for %s at %s", dataDir
					.getAbsolutePath()));
		}

		if (!confDir.exists()) {
			throw new IOException(String.format("Could not create configuration directory for %s at %s", confDir
					.getAbsolutePath()));
		}
	}

	protected void loadConfigurationsFromFile() {
		for (Configuration config : notInitializedConfigurations) {
			try {
				config.load();
			} catch (IOException e) {
				logger.error(String.format("Could not load %s.", config.getName()), e);
			}
		}
	}

	private void loadConfigurationsFromSystemSettings() {
		for (Configuration configuration : notInitializedConfigurations) {
			SystemPropertyMapper systemPropertyMapper = sysPropMappers.get(configuration.getId());
			for (Entry configEntry : configuration.entries()) {
				String propertyKey = systemPropertyMapper.mapEntry(configEntry);
				if (propertyKey == null) {
					logger.debug(String.format("No mapping to command line option for config entry: %s", configEntry
							.getKey()));
					continue;
				}

				String value;
				if ((value = System.getProperty(propertyKey)) != null) {
					configEntry.setValue(value);
					System.out.println(String.format(
							"Update configuration entry '%s' from system property %s to value: %s", configEntry
									.getKey(), propertyKey, configEntry.getValue()));
				}
			}
		}
	}

	/**
	 * Initializes the log4j framework
	 * 
	 * @param args
	 *            Command line parameters from <code>main</code> method.
	 */
	protected void initLogger(String[] args) {
		Log4JConfiguration log4JConfiguration = new Log4JConfiguration(new File(getConfigurationDir(), "log4j.conf"));
		try {
			log4JConfiguration.load();
		} catch (IOException e) {
			System.err.printf("Could not load log4j configuration");
			e.printStackTrace();
		}

		if (!log4JConfiguration.getConfigFile().exists()) {
			InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream(
					"org/eodisp/util/resources/custom-log4j.conf");
			try {
				FileUtil.copy(in, log4JConfiguration.getConfigFile());
			} catch (IOException e) {
				System.err.println("Could not create custom-log4j.conf: " + e.getMessage());
			}
		}

		Entry configEntry = log4JConfiguration.getEntry(Log4JConfiguration.LOG_LEVEL);

		// Override by System Property
		String key = BasicSystemPropertyMapper.INSTANCE.mapEntry(configEntry);
		if (System.getProperty(key) != null) {
			configEntry.setValue(System.getProperty(key));
		}

		// Override configuration with command line arguments
		Parameter param = CommandlineMapper.BASIC_COMMAND_LINE_MAPPER.mapEntry(configEntry);
		try {
			jsap.registerParameter(param);
		} catch (JSAPException e) {
			System.err.printf("Could not register JSAP Parameter %s", param);
		}

		JSAPResult result = jsap.parse(args);

		if (result.contains(param.getID())) {
			configEntry.setValue(result.getString(param.getID()));
		}

		if (!log4JConfiguration.isUseCustomFile()) {
			Level level = null;
			switch (log4JConfiguration.getLogLevel()) {
			case ALL:
				level = Level.ALL;
				break;
			case DEBUG:
				level = Level.DEBUG;
				break;
			case ERROR:
				level = Level.ERROR;
				break;
			case FATAL:
				level = Level.FATAL;
				break;
			case INFO:
				level = Level.INFO;
				break;
			case TRACE:
				level = Level.TRACE;
				break;
			case OFF:
				level = Level.OFF;
				break;
			case WARN:
				level = Level.WARN;
				break;
			default:
				assert (false);
			}
			Logger.getRootLogger().setLevel(level);
			logger.debug("Set log level to: " + level);
		} else {
			Logger.getRootLogger().removeAppender(defaultLog4JAppender);
			File file = log4JConfiguration.getConfigFile();
			PropertyConfigurator.configure(file.getAbsolutePath());
		}
	}

	/**
	 * Processes the command line arguments. Exits and prints error message if
	 * wrong parameters were given.
	 * 
	 * @param args
	 *            Command line parameters from <code>main</code> method.
	 */
	protected void loadConfigurationsFromCommandLine() {
		Map<Parameter, Entry> flaggedParams = new HashMap<Parameter, Entry>();
		Map<Parameter, Entry> booleanParams = new HashMap<Parameter, Entry>();

		// Register configuration parameters from configurations
		for (Configuration configuration : notInitializedConfigurations) {
			CommandlineMapper commandlineMapper = cliMappers.get(configuration.getId());
			for (Entry entry : configuration.entries()) {
				Parameter param = commandlineMapper.mapEntry(entry);
				if (param == null) {
					logger.debug(String
							.format("No mapping to command line option for config entry: %s", entry.getKey()));
					continue;
				}
				try {
					jsap.registerParameter(param);
					if (param instanceof Switch) {
						booleanParams.put(param, entry);
					} else {
						flaggedParams.put(param, entry);
					}
				} catch (JSAPException e) {
					logger.error("Could not register configuration entry as a command line parameter.", e);
				}

			}
		}

		// Parse command line
		JSAPResult cliOptions = jsap.parse(args);

		// Check command line arguments. Aborts execution on error
		if (!cliOptions.success()) {
			System.out.println();

			for (Iterator it = cliOptions.getBadParameterIDIterator(); it.hasNext();) {
				final String id = (String) it.next();
				for (Iterator it2 = cliOptions.getExceptionIterator(id); it2.hasNext();) {
					final Exception exception = (Exception) it2.next();
					if (exception instanceof RequiredParameterMissingException) {
						Parameter param = jsap.getByID(id);
						System.out.printf("Missing Parameter '%s'%n", param.getSyntax());
					} else if (exception instanceof IllegalMultipleDeclarationException) {
						Parameter param = jsap.getByID(id);
						System.out.printf("Parameter '%s' cannot be declared more than once.", param.getSyntax());
					} else {
						System.out.println(exception.getMessage());
					}
				}
			}
			// abnormal termination
			printUsageHelp(jsap, mainClass);
			System.exit(-1);
		}

		// Help command line option
		if (cliOptions.getBoolean(HELP_OPTION)) {
			printUsageHelp(jsap, mainClass);
			// normal termination
			System.exit(0);
		}

		// Update configurations from command line
		for (Map.Entry<Parameter, Entry> mapEntry : flaggedParams.entrySet()) {
			FlaggedOption parameter = (FlaggedOption) mapEntry.getKey();
			String paramID = parameter.getID();
			Entry configEntry = mapEntry.getValue();
			if (cliOptions.contains(paramID)) {
				if (parameter.isList()) {
					configEntry.setValue(cliOptions.getStringArray(paramID));
				} else {
					configEntry.setValue(cliOptions.getString(paramID));
				}

				System.out.println(String.format("Update configuration entry '%s' from command line to value: %s",
						configEntry.getKey(), configEntry.getValue()));
			}
		}

		for (Map.Entry<Parameter, Entry> mapEntry : booleanParams.entrySet()) {
			String paramID = mapEntry.getKey().getID();
			Entry configEntry = mapEntry.getValue();
			if (cliOptions.contains(paramID)) {
				configEntry.setBoolean(cliOptions.getBoolean(paramID));
				System.out.println(String.format("Update configuration entry '%s' from command line to value: %s",
						configEntry.getKey(), configEntry.getValue()));
			}
		}
	}

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	/**
	 * Prints usage help
	 */
	private static void printUsageHelp(JSAP jsap, Class mainClass) {
		System.out.println();
		System.out.println("Usage: java " + mainClass.getName());
		System.out.println("                " + jsap.getUsage());
		System.out.println();
		System.out.println(jsap.getHelp());
	}

	private void registerConfigurations(List<AppModule> addAppModules) {
		if (addAppModules == null || addAppModules.isEmpty()) {
			return;
		}

		final ArrayList<AppModule> copy = new ArrayList<AppModule>(addAppModules);
		for (AppModule appModule : copy) {
			try {
				logger.debug("Init configuration of application module: " + appModule.getId());
				int nrOfStoppedAppModules = stoppedAppModules.size();

				appModule.registerConfiguration(this);

				List<AppModule> newlyAddedAppModule = new ArrayList<AppModule>(stoppedAppModules.subList(
						nrOfStoppedAppModules, stoppedAppModules.size()));
				stoppedAppModules.remove(appModule);
				configRegisteredAppModules.add(appModule);

				/*
				 * if this application module added additional application
				 * modules register them immediately.
				 */
				registerConfigurations(newlyAddedAppModule);

			} catch (Exception e) {
				logger.fatal("Error while init configuration of application module: " + appModule.getId(), e);
				System.exit(-1);
			}
		}
		loadConfiguration();
	}

	/**
	 * 
	 */
	private void loadConfiguration() {
		loadConfigurationsFromFile();
		loadConfigurationsFromSystemSettings();
		loadConfigurationsFromCommandLine();
		notInitializedConfigurations.clear();
	}

	/**
	 * 
	 */
	private void preStartup(List<AppModule> addAppModules) {
		final ArrayList<AppModule> copy = new ArrayList<AppModule>(addAppModules);
		for (AppModule appModule : copy) {
			try {
				logger.debug("Pre-Startup of application module: " + appModule.getId());
				int nrOfStoppedAppModules = stoppedAppModules.size();

				appModule.preStartup(this);

				List<AppModule> newlyAddedAppModule = new ArrayList<AppModule>(stoppedAppModules.subList(
						nrOfStoppedAppModules, stoppedAppModules.size()));
				configRegisteredAppModules.remove(appModule);
				preStartedAppModules.add(appModule);

				/*
				 * if this application module added additional application
				 * modules register them immediately.
				 */
				registerConfigurations(newlyAddedAppModule);
				preStartup(newlyAddedAppModule);

			} catch (Exception e) {
				logger.fatal("Error during pre startup of application module: " + appModule.getId(), e);
				System.exit(-1);
			}
		}
	}

	private void startup(List<AppModule> addAppModules) {
		final ArrayList<AppModule> copy = new ArrayList<AppModule>(addAppModules);
		for (AppModule appModule : copy) {
			try {
				logger.debug("Startup of application module: " + appModule.getId());
				int nrOfStoppedAppModules = stoppedAppModules.size();

				appModule.startup(this);

				List<AppModule> newlyAddedAppModule = new ArrayList<AppModule>(stoppedAppModules.subList(
						nrOfStoppedAppModules, stoppedAppModules.size()));
				preStartedAppModules.remove(appModule);
				startedAppModules.add(appModule);

				/*
				 * if this application module added additional application
				 * modules register them immediately and run them through their
				 * whole startup process
				 */
				registerConfigurations(newlyAddedAppModule);
				preStartup(newlyAddedAppModule);
				startup(newlyAddedAppModule);

			} catch (Exception e) {
				logger.fatal("Error while starting up application module: " + appModule.getId(), e);
				System.exit(-1);
			}
		}
	}

	/**
	 * 
	 */
	private void shutdownAppModules() {
		for (int i = startedAppModules.size() - 1; i >= 0; i--) {
			AppModule appModule = startedAppModules.get(i);
			try {
				logger.debug("Shutdown application module: " + appModule.getId());
				appModule.shutdown(this);
			} catch (Exception e) {
				logger.error("Error while shutting down application module: " + appModule.getId(), e);
			}
		}
	}

	/**
	 * 
	 */
	private void postShutdown() {
		for (int i = startedAppModules.size() - 1; i >= 0; i--) {
			AppModule appModule = startedAppModules.get(i);
			try {
				logger.debug("Post shutdown of application module: " + appModule.getId());
				appModule.postShutdown(this);
			} catch (Exception e) {
				logger.error("Error during post shutdown of application module: " + appModule.getId(), e);
			}
		}
		startedAppModules.clear();
		stoppedAppModules.addAll(initiallyRegisteredAppModules);
		notInitializedConfigurations.clear();
		configurations.clear();
	}

}
