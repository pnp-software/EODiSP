/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.util.launcher;

import java.io.*;
import java.util.*;
import java.util.concurrent.CountDownLatch;

import org.apache.log4j.Logger;
import org.apache.tools.ant.taskdefs.ExecuteStreamHandler;
import org.apache.tools.ant.taskdefs.PumpStreamHandler;
import org.apache.tools.ant.types.Commandline;
import org.apache.tools.ant.types.CommandlineJava;
import org.apache.tools.ant.types.Environment;
import org.apache.tools.ant.types.Environment.Variable;
import org.eodisp.util.FileUtil;
import org.eodisp.util.ProgramExecution;

/**
 * @author ibirrer
 * @version $Id:$
 */
public class ProcessImpl implements Process {
	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	static Logger logger = Logger.getLogger(ProcessImpl.class);

	private final CommandlineJava commandlineJava;

	private final Commandline commandline;

	private java.lang.Process process;

	private final Map<String, String> environment = new HashMap<String, String>();

	private Thread processThread;

	private final File workingDir;

	private final Set<ProcessListener> processListeners = Collections.synchronizedSet(new HashSet<ProcessListener>());

	private volatile boolean terminated = false;

	public ProcessImpl(CommandlineJava commandlineJava) {
		this(commandlineJava, null);
	}

	public ProcessImpl(CommandlineJava commandlineJava, File workingdir) {
		this.commandlineJava = commandlineJava;
		this.commandline = null;
		this.workingDir = workingdir;
	}

	public ProcessImpl(Commandline commandline) {
		this(commandline, null);
	}

	public ProcessImpl(Commandline commandline, File workingDir) {
		this.commandlineJava = null;
		this.commandline = commandline;
		if (workingDir != null) {
			this.workingDir = workingDir;
		} else {
			this.workingDir = FileUtil.getTempDir();
		}
	}

	public void addEnvVar(String key, String value) {
		environment.put(key, value);
	}

	/**
	 * {@inheritDoc}
	 */
	public synchronized boolean kill(long timeoutInMillis) {
		if (process == null) {
			return isTerminated();
		}
		process.destroy();
		try {
			processThread.join(timeoutInMillis);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return isTerminated();
	}

	/**
	 * Launches the process and returns immediately. {@inheritDoc}
	 */
	public synchronized void launch() throws IOException {
		createProcess();

		processThread = new Thread() {
			/**
			 * {@inheritDoc}
			 */
			@Override
			public void run() {
				fireProcessStarted();
				int exitCode = -1;
				while (!isTerminated()) {
					try {
						exitCode = process.waitFor();
						setTerminated(true);
					} catch (InterruptedException e) {
						// Kill the process
						process.destroy();
						logger.warn("Interrupted while waiting for process to be terminated.");
						Thread.currentThread().interrupt();
						continue;
					}
				}
				fireProcessTerminated(exitCode);
				logger.info("Process terminated: " + process);
			}
		};
		processThread.start();
	}

	/**
	 * Launches the process and block until the process terminates or the thread
	 * is being interrupted.
	 */
	public synchronized int launchBlocking() throws IOException {
		createProcess();
		fireProcessStarted();
		int exitCode = 0;
		try {
			exitCode = process.waitFor();
		} catch (InterruptedException e) {
			kill(1);
		} finally {
			setTerminated(true);
			fireProcessTerminated(exitCode);
			logger.info("Process terminated: " + process);
		}
		return exitCode;
	}

	/**
	 * @throws IllegalStateException
	 * @throws IOException
	 */
	private void createProcess() throws IllegalStateException, IOException {
		if (process != null) {
			throw new IllegalStateException("Process already launched");
		}
		logger.info("Start new process: " + commandlineJava);

		Environment env = new Environment();
		for (Map.Entry<String, String> entry : environment.entrySet()) {
			Variable var = new Variable();
			var.setKey(entry.getKey());
			var.setValue(entry.getValue());
			env.addVariable(var);
		}

		if (commandlineJava != null) {
			process = ProgramExecution.executeJava(commandlineJava, env, workingDir);
		} else {
			process = ProgramExecution.execute(commandline, env, workingDir);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public synchronized void addListener(ProcessListener processListener) {
		processListeners.add(processListener);
	}

	/**
	 * @return the class that is started by this process
	 */
	public synchronized String getClassname() {
		return commandlineJava.getClassname();
	}

	private void fireProcessTerminated(int exitCode) {
		synchronized (processListeners) {
			for (ProcessListener processListener : processListeners) {
				processListener.processTerminated(exitCode);
			}
		}
	}

	private void fireProcessStarted() {
		synchronized (processListeners) {
			for (ProcessListener processListener : processListeners) {
				processListener.processStarted();
			}
		}
	}

	private boolean isTerminated() {
		return terminated;
	}

	private void setTerminated(boolean terminated) {
		this.terminated = terminated;
	}

	@Override
	public String toString() {
		if (commandlineJava != null) {
			return commandlineJava.getClassname();
		}
		return commandline.getExecutable();
	}

	public void addOutputStream(OutputStream stream) throws IOException {
		ExecuteStreamHandler streamHandler = new PumpStreamHandler(stream);
		streamHandler.setProcessErrorStream(process.getErrorStream());
		streamHandler.setProcessOutputStream(process.getInputStream());
		streamHandler.start();
	}
}
