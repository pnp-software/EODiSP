package org.eodisp.util.configuration;

/**
 * Thrown to indicate that the operation called is not applicable for the
 * instance it was called upon. Thrown if
 * {@link org.eodisp.util.configuration.Configuration.Entry#getInt()} is called
 * but the type of the entry is not {@link java.lang.Integer#TYPE} and alike for
 * other configuration entry types.
 * 
 * @author ibirrer
 * @version $Id: OperationNotApplicableException.java 2094 2006-05-15 13:28:33Z ibirrer $
 * 
 */
public class OperationNotApplicableException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	/**
	 * @param message error message
	 */
	public OperationNotApplicableException(String message) {
		super(message);
	}
}