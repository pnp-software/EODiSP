/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.util;

import java.io.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import org.apache.log4j.Logger;

public class ZipUtil {
	/**
	 * Log4J logger for this class
	 * 
	 * @hidden
	 */
	private final static Logger logger = Logger.getLogger(ZipUtil.class);

	public static void zip(File zipfile, File root, File... files) throws IOException {
		byte[] buffer = new byte[4096]; // Create a buffer for copying
		ZipOutputStream zipOutputStream = new ZipOutputStream(new FileOutputStream(zipfile));

		for (File file : files) {
			zip(file, root, zipOutputStream, buffer);
		}

		zipOutputStream.close();
	}

	private static void zip(File file, File root, ZipOutputStream zipOutputStream, byte[] buffer) throws IOException {
		String path = slashify(FileUtil.getRelativePath(root, file), file.isDirectory());

		if (file.isDirectory()) {
			logger.debug("Add directory: " + path);
			zipOutputStream.putNextEntry(new ZipEntry(path));
			for (File subdirFile : file.listFiles()) {
				zip(subdirFile, root, zipOutputStream, buffer);
			}
		} else {
			logger.debug("Add file: " + path);
			zipOutputStream.putNextEntry(new ZipEntry(path));
			FileInputStream in = new FileInputStream(file);
			int bytesRead;
			while ((bytesRead = in.read(buffer)) != -1)
				zipOutputStream.write(buffer, 0, bytesRead);
			in.close();
		}
	}

	public static void unzip(File zipFile, File dest) throws IOException {
		ZipInputStream in = new ZipInputStream(new FileInputStream(zipFile));
		ZipEntry entry;
		while ((entry = in.getNextEntry()) != null) {
			final File outfile = new File(dest, entry.getName());
			if (entry.isDirectory()) {
				outfile.mkdir();
				continue;
			}

			logger.debug("extract: " + outfile);
			OutputStream out = new BufferedOutputStream(new FileOutputStream(outfile));
			byte[] buf = new byte[4096];
			int len;
			while ((len = in.read(buf)) > 0) {
				out.write(buf, 0, len);
			}
			out.close();
		}

		in.close();
	}

	private static String slashify(String path, boolean isDirectory) {
		String p = path;
		if (File.separatorChar != '/')
			p = p.replace(File.separatorChar, '/');
		if (!p.endsWith("/") && isDirectory)
			p = p + "/";
		return p;
	}

}