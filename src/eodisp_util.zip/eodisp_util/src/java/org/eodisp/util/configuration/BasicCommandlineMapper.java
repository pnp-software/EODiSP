package org.eodisp.util.configuration;

import java.lang.reflect.Field;

import org.eodisp.util.configuration.Configuration.Entry;

import com.martiansoftware.jsap.FlaggedOption;
import com.martiansoftware.jsap.Parameter;
import com.martiansoftware.jsap.Switch;
import com.martiansoftware.jsap.stringparsers.EnumeratedStringParser;

/**
 * A basic implementation of the mapper interface. Maps configuration entries of
 * type <code>boolean</code> to {@link com.martiansoftware.jsap.Switch},
 * others to {@link FlaggedOption} instances. The id of the JSAP parameter is
 * set to the following string:
 * <code>ConfigurationId.ConfigurationEntryId</code>. The long flag is the
 * key of the configuration entry ({@link org.eodisp.util.configuration.Configuration.Entry#getKey()})
 * and the help is set from the configuration's description ({@link org.eodisp.util.configuration.Configuration.Entry#getDescription()}).
 * 
 * @author ibirrer
 * @version $Id: BasicCommandlineMapper.java 3017 2006-08-11 22:23:22Z ibirrer $
 * 
 */
class BasicCommandlineMapper implements CommandlineMapper {
	static CommandlineMapper INSTANCE = new BasicCommandlineMapper();

	public Parameter mapEntry(Entry entry) {
		String paramId = entry.getConfiguration().getId() + "." + entry.getKey();
		if (entry.getType() == Boolean.TYPE) {
			Switch option = new Switch(paramId);
			String nullString = null;
			option.setDefault(nullString);
			option.setLongFlag(entry.getKey());
			option.setHelp(entry.getDescription());
			return option;
		}

		FlaggedOption option = new FlaggedOption(paramId);
		option.setLongFlag(entry.getKey());
		option.setHelp(entry.getDescription());
		option.setUsageName(entry.getKey());

		if (Enum.class.isAssignableFrom(entry.getType())) {
			Field[] enumConstants = entry.getType().getFields();
			StringBuilder stringBuilder = new StringBuilder();

			for (int i = 0; i < enumConstants.length; i++) {
				String enumConstant = enumConstants[i].getName();
				stringBuilder.append(enumConstant);
				if (i != enumConstants.length - 1) {
					stringBuilder.append(";");
				}
			}

			option.setStringParser(EnumeratedStringParser.getParser(stringBuilder.toString(), false, false));

			if (entry.isList()) {
				option.setList(true);
				option.setListSeparator(',');
				option
						.setHelp(String
								.format(
										"%s (Valid values are any of the following or any combination of them separated by a comma: %s)",
										option.getHelp(),
										stringBuilder.toString().replaceAll(";", ", ")));

			} else {
				option.setHelp(String.format("%s (Valid values are: %s)", option.getHelp(), stringBuilder
						.toString()
						.replaceAll(";", ", ")));
			}

		}

		return option;
	}
}