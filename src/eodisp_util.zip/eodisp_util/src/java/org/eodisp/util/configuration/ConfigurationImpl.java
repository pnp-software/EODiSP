package org.eodisp.util.configuration;

import java.io.*;
import java.lang.reflect.Field;
import java.util.*;

import org.apache.log4j.Logger;
import org.eodisp.util.ArrayUtil;

import com.martiansoftware.jsap.JSAPResult;

/**
 * A basic implementation of the Configuration interface using a file as its
 * backend.
 * 
 * @author ibirrer
 * @version $Id: ConfigurationImpl.java 3753 2006-09-26 16:11:53Z ibirrer $
 */
public class ConfigurationImpl implements Configuration {

	/**
	 * A configuration entry that saves a configuration value as a string.
	 */
	public class EntryImpl implements Configuration.Entry {

		/**
		 * The key of this configuration entry.
		 */
		private String key = null;

		/**
		 * the value (null means unset and use default)
		 */
		private String value = null;

		/**
		 * the default value (cannot be null)
		 */
		private String defaultValue = null;

		/**
		 * The type of the entry (used to check for applicability of getXXX()
		 * methods. )
		 */
		private Class type = Object.class;

		/**
		 * Determines if this entry can contain a list of values (separated by
		 * commas)
		 */
		private boolean isList = false;

		/**
		 * Description of the entry
		 */
		private String entryDescription = null;

		/**
		 * Creates a configuration entry with the value initialized to
		 * <code>null</code> (not set). isList is set to <code>false</code>.
		 * 
		 * @param defaultValue
		 *            the default value of the configuration
		 * @param entryDescription
		 *            a text describing the configuration
		 */
		public EntryImpl(String key, String defaultValue, Class type, String entryDescription) {
			this(key, defaultValue, type, entryDescription, false);
		}

		/**
		 * Creates a configuration entry with the value initialized with
		 * <code>null</code>
		 * 
		 * @param defaultValue
		 *            the default value of the configuration
		 * @param entryDescription
		 *            a text describing the configuration
		 * @param isList
		 *            determines if this entry can contain a list of values from
		 *            the given type
		 */
		public EntryImpl(String key, String defaultValue, Class type, String entryDescription,
				boolean isList) {
			this.key = key;
			setDefaultValue(defaultValue);
			this.type = type;
			setDescription(entryDescription);
			this.isList = isList;
		}

		/**
		 * Returns the key of this configuration entry
		 * 
		 * @return the key of this configuration entry
		 */
		public String getKey() {
			return key;
		}

		/**
		 * Returns the value if it is set (non null) or the default value
		 * otherwise.
		 * 
		 * @return the value of this configuration option
		 */
		public synchronized String getValue() {
			if (!isSet()) {
				return defaultValue;
			}
			return value;
		}

		/**
		 * Sets the value for this configuration entry.
		 * 
		 * @param value
		 *            <code>null</code> means to use the default value.
		 */
		public synchronized void setValue(String value) {
			if (value != null && this.value != null && this.value.equals(value)) {
				return;
			}
			this.value = value;
			needsSave = true;
		}

		public void setValue(String[] value) {
			String stringValue = ArrayUtil.stringArrayToString(value, ",");

			if (stringValue != null && this.value != null && this.value.equals(stringValue)) {
				return;
			}
			this.value = stringValue;
			needsSave = true;
		}

		/**
		 * Returns the default value of this configuration entry. Use
		 * {@link #getValue()} to get either the value or default value
		 * depending if the value has been set.
		 * 
		 * @see #getValue()
		 * @return the default value
		 */
		public synchronized Object getDefaultValue() {
			return defaultValue;
		}

		/**
		 * Sets the default value.
		 * 
		 * @param defaultValue
		 *            the default value. <code>null</code> is not allowed.
		 * @throws NullPointerException
		 *             if trying to set the default value to <code>null</code>.
		 */
		private void setDefaultValue(String defaultValue) {
			if (defaultValue == null) {
				throw new NullPointerException(
						"Default value for a configuration entry cannot be null");
			}
			this.defaultValue = defaultValue;
		}

		/**
		 * {@inheritDoc}
		 */
		public synchronized Class getType() {
			return type;
		}

		public boolean isList() {
			return isList;
		}

		/**
		 * Returns the help text of this configuration entry
		 * 
		 * @return the help text
		 */
		public synchronized String getDescription() {
			return entryDescription;
		}

		/**
		 * Sets the description of this configuration entry
		 * 
		 * @param description
		 *            the description, <code>null</code> values are converted
		 *            to an empty string.
		 */
		public synchronized void setDescription(String description) {
			if (description == null) {
				description = "";
			}
			this.entryDescription = description;
		}

		/**
		 * Returns <code>true</code> if a value other than the default value
		 * is set for this configuration entry.
		 * 
		 * @return <code>false</code> of no value is set for this
		 *         configuration entry
		 */
		public synchronized boolean isSet() {
			return this.value == null ? false : true;
		}

		/**
		 * Returns the integer value of this configuration entry.
		 * 
		 * @return The integer value of this configuration entry. If the value
		 *         cannot be parsed as an integer the default value is parsed
		 *         and returned.
		 */
		public int getInt() {
			if (type != Integer.TYPE) {
				throw new OperationNotApplicableException(
						"Configuration entry is not of type 'int' and can therefore not be retrieved using 'getInt()'");
			}

			try {
				return Integer.parseInt(getValue());
			} catch (IllegalArgumentException e) {
				// assume the default value can be parsed
				logger.warn("Could not parse integer value in configuration entry: " + key
						+ ". Return default value.");
				return Integer.parseInt(defaultValue);
			}
		}

		/**
		 * {@inheritDoc}
		 */
		public void setInt(int port) {
			if (type != Integer.TYPE) {
				throw new OperationNotApplicableException(
						"Configuration entry is not of type 'int' and can therefore not be set using 'setInt(...)'");
			}
			this.value = String.valueOf(port);
		}

		/**
		 * {@inheritDoc}
		 */
		public long getLong() {
			if (type != Long.TYPE) {
				throw new OperationNotApplicableException(
						"Configuration entry is not of type 'long' and can therefore not be retrieved using 'getLong()'");
			}
			try {
				return Long.parseLong(getValue());
			} catch (IllegalArgumentException e) {
				// assume the default value can be parsed
				logger.warn("Could not parse long value in configuration entry: " + key
						+ ". Return default value.");
				return Long.parseLong(defaultValue);
			}
		}

		/**
		 * {@inheritDoc}
		 */
		public void setLong(long value) {
			if (type != Long.TYPE) {
				throw new OperationNotApplicableException(
						"Configuration entry is not of type 'long' and can therefore not be set using 'setLong(...)'");
			}
			setValue(String.valueOf(value));
		}

		/**
		 * {@inheritDoc}
		 */
		public boolean getBoolean() {
			if (type != Boolean.TYPE) {
				throw new OperationNotApplicableException(
						"Configuration entry is not of type 'boolean' and can therefore not be retrieved using 'getBoolean()'");
			}
			return Boolean.parseBoolean(getValue());
		}

		/**
		 * {@inheritDoc}
		 */
		public void setBoolean(boolean enabled) {
			if (type != Boolean.TYPE) {
				throw new OperationNotApplicableException(
						"Configuration entry is not of type 'boolean' and can therefore not be set using 'setBoolean(...)'");
			}
			setValue(Boolean.toString(enabled));
		}

		/**
		 * Returns the entry value as a file that is resolved to the location
		 * {@link ConfigurationImpl#getFile()} of the configuration instance it
		 * belongs to. If the current value denotes an absolute file it is just
		 * returned. If the location of the configuration file is not set the
		 * relative path is returned, though there's no guarantee that this
		 * method returns an absolute path.
		 * 
		 * @return this entry's value resolved to an absolute path using the
		 *         configuration's location.
		 */
		public File getFile() {
			if (type != File.class) {
				throw new OperationNotApplicableException(
						String
								.format(
										"Configuration entry is not of type %s and can therefore not be retrieved using 'getFile()'",
										File.class.getName()));
			}
			return getFile(getValue());
		}

		private File getFile(String fileValue) {
			File f = new File(fileValue);
			if (f.isAbsolute()) {
				return f;
			}

			if (file != null) {
				return new File(file.getParentFile(), getValue());
			}
			return f;
		}

		/**
		 * Returns the entry value as a file that is resolved to the location
		 * {@link ConfigurationImpl#getFile()} of the configuration instance it
		 * belongs to. If the current value denotes an absolute file it is just
		 * returned. If the location of the configuration file is not set the
		 * relative path is returned, though there's no guarantee that this
		 * method returns an absolute path.
		 * 
		 * @return this entry's value resolved to an absolute path using the
		 *         configuration's location.
		 * @deprecated use {@link Entry#getFile()}
		 */
		public File getFileResolved() {
			return getFile();
		}

		public List<File> getFilelist() {
			if (type != File.class && !isList()) {
				throw new OperationNotApplicableException(
						"Configuration entry is not of type List<File> and can therefore not be set using 'getFilelist(...)'");
			}
			List<File> result = new ArrayList<File>();
			String[] splitted = ArrayUtil.stringToArray(getValue());
			for (String string : splitted) {
				File theFile = getFile(string);
				result.add(theFile);
			}
			return result;
		}

		/**
		 * {@inheritDoc}
		 */
		public void setFile(File file) {
			if (type != File.class) {
				throw new OperationNotApplicableException(
						String
								.format(
										"Configuration entry is not of type %s and can therefore not be set using 'setFile(...)'",
										File.class.getName()));
			}
			setValue(file.getPath());
		}

		/**
		 * {@inheritDoc}
		 */
		@SuppressWarnings("unchecked")
		public Enum getEnum() {
			if (type.isAssignableFrom(Enum.class)) {
				throw new OperationNotApplicableException(
						String
								.format(
										"Configuration entry is not of type %s and can therefore not be retrieved using 'getEnum()'",
										Enum.class.getName()));
			}

			try {
				return Enum.valueOf(type, getValue().toUpperCase());
			} catch (IllegalArgumentException e) {
				logger.error("Could not parse enum value in configuration entry: " + key
						+ ". Return default value.");
				return Enum.valueOf(type, defaultValue.toUpperCase());
			}
		}

		@SuppressWarnings("unchecked")
		public void setEnum(Enum theEnum) {
			if (type.isAssignableFrom(Enum.class)) {
				throw new OperationNotApplicableException(
						String
								.format(
										"Configuration entry is not of type %s and can therefore not be set using 'setEnum(...)'",
										Enum.class.getName()));
			}
			setValue(theEnum.toString());
		}

		public EnumSet getEnumSet() {
			if (type.isAssignableFrom(Enum.class) && isList()) {
				throw new OperationNotApplicableException(
						String
								.format(
										"Configuration entry is not of type %s and can therefore not be set using 'setEnum(...)'",
										Enum.class.getName()));
			}

			try {
				return ArrayUtil.enumSetFromString(getValue(), type);
			} catch (IllegalArgumentException e) {
				EnumSet enumSetFromString = ArrayUtil.enumSetFromString(defaultValue, type);
				logger
						.error(String
								.format(
										"Could not parse enumSet value in configuration entry '%s' Return default value '%s'",
										key, enumSetFromString));
				return enumSetFromString;
			}
		}

		public void setEnumSet(EnumSet enumSet) {
			if (type.isAssignableFrom(EnumSet.class) && isList()) {
				throw new OperationNotApplicableException(
						String
								.format(
										"Configuration entry is not of type %s and can therefore not be set using 'setEnumSet(...)'",
										EnumSet.class.getName()));
			}
			setValue(ArrayUtil.enumSetToString(enumSet));
		}

		public Configuration getConfiguration() {
			return ConfigurationImpl.this;
		}

		/**
		 * Entries are equal if they are both set or both not set and if their
		 * string values are equal.
		 */
		@Override
		public boolean equals(Object obj) {
			if (obj == null || !(obj instanceof EntryImpl)) {
				return false;
			}

			EntryImpl otherEntry = (EntryImpl) obj;

			if (isSet() != otherEntry.isSet()) {
				return false;
			}

			return getValue().equals(otherEntry.getValue());
		}

		@Override
		public int hashCode() {
			if (isSet()) {
				return this.value.hashCode();
			}

			return this.defaultValue.hashCode() + 1;
		}

		@Override
		public String toString() {
			return key + "=" + getValue() + (isSet() ? " (default)" : "");
		}

		/**
		 * {@inheritDoc}
		 */
		public String getDoc() {
			String newline = System.getProperty("line.separator") + " *      ";
			StringBuffer buf = new StringBuffer();
			char[] helpCharArray = entryDescription.toCharArray();
			boolean breakNeeded = false;
			for (int i = 0; i < helpCharArray.length; i++) {
				char c = helpCharArray[i];
				buf.append(c);

				if (i != 0 && i % 70 == 0) {
					breakNeeded = true;
				}
				if (breakNeeded && c == ' ') {
					buf.append(newline);
					breakNeeded = false;
				}
			}
			return (String.format(" *  %s:" + newline + "default: '%s'" + newline + "%s", key,
					getDefaultValue(), buf.toString()));
		}

		public String getPropertyFileComment() {
			String newline = System.getProperty("line.separator") + "# ";
			StringBuffer buf = new StringBuffer();
			String descr = entryDescription;

			if (Enum.class.isAssignableFrom(type)) {
				StringBuilder builder = new StringBuilder();
				Field[] fields = type.getFields();

				for (int i = 0; i < fields.length; i++) {
					Field field = fields[i];
					if (i != 0) {
						builder.append(", ");
					}
					builder.append(field.getName());
				}
				descr = descr + String.format(" (%s)", builder.toString());
			}

			char[] helpCharArray = descr.toCharArray();
			boolean breakNeeded = false;
			for (int i = 0; i < helpCharArray.length; i++) {
				char c = helpCharArray[i];
				buf.append(c);

				if (i != 0 && i % 70 == 0) {
					breakNeeded = true;
				}
				if (breakNeeded && c == ' ') {
					buf.append(newline);
					breakNeeded = false;
				}
			}
			return (String.format("# %s %n# %s=%s%n", buf.toString(), key, getDefaultValue()));
		}
	}

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(ConfigurationImpl.class);

	/**
	 * Holds configuration entries
	 */
	Map<String, Entry> entries = Collections.synchronizedMap(new HashMap<String, Entry>());

	/**
	 * The file this configuration is persisted in.
	 */
	private File file = null;

	/**
	 * The name of the configuration. The name can be used in a GUI but needn't
	 * to be unique in a JVM.
	 */
	private String name;

	/**
	 * The id is used as the registration key if the configuration is registered
	 * with and application. Must be unique.
	 */
	private String id;

	/**
	 * A description of the configuration.
	 */
	private String description;

	boolean needsSave = true;

	/**
	 * Creates a new configuration with no entries.
	 * 
	 * @param name
	 *            the name of the new configuration. Must be unique among other
	 *            configurations. Make sure the name is human-readable as it is
	 *            possible that the name is displayed in a GUI.
	 * @param description
	 *            A description of this configuration. Can be used to generate
	 *            documentation or to proved online help in a GUI.
	 * @param file
	 *            The file this configuration is persisted or loaded from using
	 *            the {@link #load()} and {@link #save()} methods.
	 */
	public ConfigurationImpl(String id, String name, String description, File file) {
		this.id = id;
		this.name = name;
		this.file = file;
		this.description = description;
	}

	/**
	 * Subclasses must override this method to populate the configuration
	 * entries using the {@link #putEntry(String, ConfigurationEntry)} method.
	 */
	// protected abstract void populateEntries();
	/**
	 * Add a configuration entry. The key of the entry itself is going to
	 * replaces by the one given here.
	 * 
	 * @param key
	 *            the key for the new entry.
	 * @param entry
	 *            the configuration entry.
	 */
	public void putEntry(Entry entry) {
		entries.put(entry.getKey(), entry);
		needsSave = true;
	}

	/**
	 * Returns the entry with the given key.
	 * 
	 * @param key
	 *            the key of the entry
	 * @return the configuration entry
	 */
	public Entry getEntry(String key) {
		return entries.get(key);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean containsEntry(String key) {
		return entries.containsKey(key);
	}

	/**
	 * {@inheritDoc}
	 */
	public synchronized void load() throws IOException {
		Properties properties = new Properties();
		try {
			properties.load(new FileInputStream(file));

			for (Map.Entry<Object, Object> propertyEntry : properties.entrySet()) {
				Entry configEntry = getEntry((String) propertyEntry.getKey());

				if (configEntry == null) {
					// ignore unknown entries and log a warning message
					logger.warn(String.format("Unknown configuration entry '%s' in '%s' for '%s'",
							propertyEntry.getKey(), file.getAbsolutePath(), getName()));
				} else {
					configEntry.setValue((String) propertyEntry.getValue());
				}
			}
		} catch (FileNotFoundException e) {
			logger
					.warn(String
							.format(
									"Configuration file '%s' for '%s' does not exist. A new configuration file will be created.",
									file.getAbsolutePath(), getName()));
			save();
		} catch (IOException e) {
			throw e;
		}
		needsSave = false;
		logger.debug(String.format("Successfully loaded '%s' from '%s'", getName(), file
				.getAbsolutePath()));
	}

	public synchronized void save() throws IOException {
		Properties properties = new Properties();

		// populate properties
		synchronized (entries) {
			for (Entry configEntry : entries.values()) {
				// Do not save default values
				if (configEntry.isSet()) {
					properties.put(configEntry.getKey(), configEntry.getValue());
				}
			}
		}

		try {
			properties.store(new FileOutputStream(file), getPropertyFileComment());
		} catch (IOException e) {
			throw e;
		}
		needsSave = false;
		logger.debug(String.format("Saved '%s' to '%s'", getName(), file.getAbsolutePath()));
	}

	/**
	 * {@inheritDoc}
	 */
	public Entry[] entries() {
		synchronized (entries) {
			return entries.values().toArray(new Entry[0]);
		}
	}

	/**
	 * Loads the configuration from the configuration file ({@link #getFile()})
	 * If the file cannot be loaded, a new file with default values is created
	 * using the {@link #save()} method.
	 * 
	 * @see #save(File)
	 * @throws IOException
	 */

	/**
	 * Saves the configuration entries to the configuration file ({@link #getFile()})
	 * using the
	 * {@link Properties#store(java.io.OutputStream, java.lang.String)}
	 * mechanism.
	 * <p>
	 * Help text are not saved.
	 * 
	 * @throws IOException
	 */

	/**
	 * Returns the location this configuration was last saved to or loaded from.
	 * 
	 * @return the location of the configuration. Returns <code>null</code> if
	 *         this configuration was never saved or loaded.
	 */
	public synchronized File getFile() {
		return file;
	}

	/**
	 * Overrides configuration entries using the values given on the command
	 * line.
	 * 
	 * @param cliOptions
	 *            the command line options
	 */
	public void overrideFromCommandLineParameters(JSAPResult cliOptions) {
		synchronized (entries) {
			for (Entry entry : entries.values()) {
				if (cliOptions.contains(entry.getKey())) {
					entry.setValue(cliOptions.getString(entry.getKey()));
					logger.debug("Set Option " + entry.getKey() + " to " + entry.getValue());
				}
			}
		}
	}

	public String getPropertyFileComment() {
		StringBuffer buf = new StringBuffer();
		buf.append(String.format("%n"));
		synchronized (entries) {
			for (Entry entry : entries.values()) {
				if (!entry.isSet()) {
					buf.append(String.format("%s%n", entry.getPropertyFileComment()));
				}
			}
		}
		return buf.toString();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString() {
		String newline = System.getProperty("line.separator");
		StringBuffer buf = new StringBuffer();
		synchronized (entries) {
			for (Entry entry : entries.values()) {
				buf.append(entry.toString() + newline);
			}
		}
		return buf.toString();
	}

	public String getDoc() {
		String newline = System.getProperty("line.separator");
		StringBuffer buf = new StringBuffer();
		synchronized (entries) {
			for (Entry entry : entries.values()) {
				buf.append(entry.getDoc() + newline);
			}
		}
		return buf.toString();
	}

	/**
	 * Helper method to generates the setter and getter methods of any
	 * configuration class.
	 * 
	 * @return Setter and getter methods (Java code) that can be used as type
	 *         safe methods in subclasses.
	 */
	public String getCode() {
		StringBuffer buf = new StringBuffer();
		synchronized (entries) {
			for (Entry entry : entries.values()) {
				// getter
				String key = entry.getKey();
				Class type = entry.getType();
				String keyConstant = "";
				String[] kelElemnts = key.split("[-_.]");

				String keyAsMethodName = "";
				for (int i = 0; i < kelElemnts.length; i++) {
					keyAsMethodName += Character.toUpperCase(kelElemnts[i].charAt(0))
							+ kelElemnts[i].substring(1);
				}

				String getXXX = "get" + keyAsMethodName;
				if (type == Boolean.TYPE) {
					// if( key.startsWith("use") ) {
					// getXXX = "uses" + keyAsMethodName.substring(3);
					// } else {
					getXXX = "is" + keyAsMethodName;
					// }
				}

				String typeName = Enum.class.isAssignableFrom(type) ? "Enum" : type.getSimpleName();

				for (int i = 0; i < kelElemnts.length; i++) {
					if (i != 0) {
						keyConstant += "_";
					}
					keyConstant += kelElemnts[i].toUpperCase();
				}

				String keyAsArgumentName = "";
				for (int i = 0; i < kelElemnts.length; i++) {
					char el = Character.toUpperCase(kelElemnts[i].charAt(0));
					if (i == 0) {
						el = kelElemnts[i].charAt(0);
					}
					keyAsArgumentName += el + kelElemnts[i].substring(1);
				}

				String castString = Enum.class.isAssignableFrom(type) ? "(" + type.getSimpleName()
						+ ")" : "";

				String getType = "get" + Character.toUpperCase(typeName.charAt(0))
						+ typeName.substring(1);
				if (type == String.class) {
					getType = "getValue";
				}

				String declaration = String.format("public %s %s() {\n\t %%s \n}", type
						.getSimpleName(), getXXX);
				String body = String.format("return %sgetEntry(%s).%s();", castString, keyConstant,
						getType);
				buf.append(String.format(declaration, body) + "\n\n");

				// setter

				String setXXX = "set" + keyAsMethodName;
				String setType = "set" + Character.toUpperCase(typeName.charAt(0))
						+ typeName.substring(1);
				if (type == String.class) {
					setType = "setValue";
				}

				declaration = String.format("public void %s(%s %s) {\n\t %%s \n}", setXXX, type
						.getSimpleName(), keyAsArgumentName);
				body = String.format("getEntry(%s).%s(%s);", keyConstant, setType,
						keyAsArgumentName);
				buf.append(String.format(declaration, body) + "\n\n");
			}
		}
		return buf.toString();
	}

	public String getId() {
		return id;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getName() {
		return name;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getDescription() {
		return description;
	}

	public Entry createEntry(String key, String defaultValue, String entryDescription) {
		Entry entry = new EntryImpl(key, defaultValue, String.class, entryDescription);
		putEntry(entry);
		return entry;
	}

	public Entry createIntEntry(String key, int defaultValue, String entryDescription) {
		Entry entry = new EntryImpl(key, String.valueOf(defaultValue), Integer.TYPE,
				entryDescription);
		putEntry(entry);
		return entry;
	}

	public Entry createBooleanEntry(String key, boolean defaultValue, String entryDescription) {
		Entry entry = new EntryImpl(key, String.valueOf(defaultValue), Boolean.TYPE,
				entryDescription);
		putEntry(entry);
		return entry;
	}

	public Entry createLongEntry(String key, long defaultValue, String entryDescription) {
		Entry entry = new EntryImpl(key, String.valueOf(defaultValue), Long.TYPE, entryDescription);
		putEntry(entry);
		return entry;
	}

	public Entry createFileEntry(String key, File defaultValue, String entryDescription) {
		Entry entry = new EntryImpl(key, defaultValue.getPath(), File.class, entryDescription);
		putEntry(entry);
		return entry;
	}

	public Entry createEnumEntry(String key, Enum defaultValue, String entryDescription) {
		Entry entry = new EntryImpl(key, String.valueOf(defaultValue), defaultValue.getClass(),
				entryDescription);
		putEntry(entry);
		return entry;
	}

	public <E extends Enum<E>> Entry createEnumSetEntry(String key, EnumSet<E> defaultEnumSet,
			Class elementType, String entryDescription) {
		Entry entry = new EntryImpl(key, ArrayUtil.enumSetToString(defaultEnumSet), elementType,
				entryDescription, true);
		putEntry(entry);
		return entry;
	}

	public Entry createFilelistEntry(String key, List<File> defaultFileList, String entryDescription) {
		Entry entry = new EntryImpl(key, ArrayUtil.listToString(defaultFileList), File.class,
				entryDescription, true);
		putEntry(entry);
		return entry;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj == null || !(obj instanceof ConfigurationImpl)) {
			return false;
		}

		ConfigurationImpl otherConfigurationImpl = (ConfigurationImpl) obj;
		if (otherConfigurationImpl.entries.size() != entries.size()) {
			return false;
		}
		synchronized (entries) {
			for (Entry entry : entries.values()) {
				Entry otherEntry = otherConfigurationImpl.getEntry(entry.getKey());
				if (otherEntry == null) {
					return false;
				}

				if (!entry.equals(otherEntry)) {
					return false;
				}
			}
		}
		return true;
	}

	@Override
	public int hashCode() {
		return name.hashCode();
	}

	public boolean needsSave() {
		return needsSave;
	}
}
