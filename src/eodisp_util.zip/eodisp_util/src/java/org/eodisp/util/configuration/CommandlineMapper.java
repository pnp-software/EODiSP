/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.util.configuration;

import org.eodisp.util.configuration.Configuration.Entry;

import com.martiansoftware.jsap.FlaggedOption;
import com.martiansoftware.jsap.Parameter;

/**
 * Interface of the command line wrapper. Maps configuration entries ({@link org.eodisp.util.configuration.Configuration.Entry})
 * to command line parameters.
 * 
 * @author ibirrer
 * @version $Id: CommandlineMapper.java 3018 2006-08-11 22:23:35Z ibirrer $
 * 
 */
public interface CommandlineMapper {

	public static CommandlineMapper NULL_COMMAND_LINE_MAPPER = new CommandlineMapper() {
		public Parameter mapEntry(Entry entry) {
			return null;
		}
	};

	/**
	 * Returns a basic command line mapper that maps configuration entries of
	 * type <code>boolean</code> to {@link com.martiansoftware.jsap.Switch}
	 * and others to {@link FlaggedOption} instances. The id of the JSAP
	 * parameter is set to the following string:
	 * <code>ConfigurationId.ConfigurationEntryId</code>. The long flag is
	 * the key of the configuration entry ({@link org.eodisp.util.configuration.Configuration.Entry#getKey()})
	 * and the help is set from the configuration's description ({@link org.eodisp.util.configuration.Configuration.Entry#getDescription()}).
	 * 
	 * @author ibirrer
	 * @version $Id: BasicCommandlineMapper.java 2094 2006-05-15 13:28:33Z
	 *          ibirrer $
	 */
	public static final CommandlineMapper BASIC_COMMAND_LINE_MAPPER = new BasicCommandlineMapper();

	/**
	 * Returns the JSAP parameter (command line option) that is mapped to the
	 * given entry. A return value of <code>null</code> means that no command
	 * line option shall be created for the given entry.
	 * 
	 * @param entry
	 *            the entry that shall be mapped to a parameter
	 * @return the parameter mapped to the given configuration entry or null if
	 *         the given configuration entry shall not be mapped to a command
	 *         line option.
	 */
	public Parameter mapEntry(Entry entry);
}