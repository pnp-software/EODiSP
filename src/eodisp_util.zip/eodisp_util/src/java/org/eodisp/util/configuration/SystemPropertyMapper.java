/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.util.configuration;

import org.eodisp.util.configuration.Configuration.Entry;

/**
 * Interface of the system property wrapper. Maps configuration entries ({@link org.eodisp.util.configuration.Configuration.Entry})
 * to system properties.
 * 
 * @author ibirrer
 * @version $Id: CommandlineMapper.java 2094 2006-05-15 13:28:33Z ibirrer $
 * 
 */
public interface SystemPropertyMapper {
	public static SystemPropertyMapper NULL_SYSTEM_PROPERTY_MAPPER = new SystemPropertyMapper() {
		public String mapEntry(Entry entry) {
			return null;
		}
	};
	
	/**
	 * Returns the key in the system property ({@link System#getProperty(String)})
	 * that is mapped to the given entry. A return value of <code>null</code>
	 * means that no system property is mapped to the given entry.
	 * 
	 * @param entry
	 *            the entry that shall be mapped to a system property
	 * @return the key of the system property mapped to the given configuration
	 *         entry or null if the given configuration entry shall not be
	 *         mapped to a system property.
	 */
	String mapEntry(Entry entry);
}