package org.eodisp.util.configuration;

import org.eodisp.util.configuration.Configuration.Entry;

/**
 * A basic implementation of the system property mapper interface. Returns the
 * key of the configuration entry prefixed with the given prefix in the
 * constructor as the new key for the system property. The default prefix
 * <code>org.eodisp.</code> is used if <code>null</code> is given in the
 * constructor.
 * 
 * @author ibirrer
 * @version $Id: BasicCommandlineMapper.java 2094 2006-05-15 13:28:33Z ibirrer $
 */
public class BasicSystemPropertyMapper implements SystemPropertyMapper {
	private static final String PREFIX = "org.eodisp.";

	private String prefix = PREFIX;

	public static SystemPropertyMapper INSTANCE = new BasicSystemPropertyMapper(null);

	public BasicSystemPropertyMapper(String prefix) {
		if (prefix != null) {
			this.prefix = prefix;
		}
	}

	public String mapEntry(Entry entry) {
		return prefix + entry.getKey();
	}
}