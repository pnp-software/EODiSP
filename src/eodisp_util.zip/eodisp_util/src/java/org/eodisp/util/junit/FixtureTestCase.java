/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.util.junit;

import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;
import junit.framework.TestResult;

public class FixtureTestCase extends TestCase {
	
	static class FixtureException extends Exception {
		public FixtureException(String message, Throwable cause) {
			super(message, cause);
		}
	}
	
	private static Map<Class, Integer> totalNumberOfRunsPerClass = new HashMap<Class, Integer>();
	private static Map<Class, Integer> actualNumberOfRunsPerClass = new HashMap<Class, Integer>();

	public FixtureTestCase() {
		Integer currentTotalNumber = totalNumberOfRunsPerClass.get(getClass());
		if( currentTotalNumber == null ) {
			currentTotalNumber = Integer.valueOf(0);
		}
		
		Integer newValue = Integer.valueOf(currentTotalNumber.intValue() + 1);
		
		totalNumberOfRunsPerClass.put(getClass(), newValue);
	}

	@Override
	public void run(TestResult result) {
		if (getNrOfActualTestRuns() == 0) {
			try {
				setUpFixture();
			} catch (Throwable e) {
				result.addError(this, new FixtureException("Error during setUpFixture()", e));
				result.stop();
				try {
					tearDownFixture();
				} catch (Exception e1) {
					// ignore
				} 
				return;
			}
		}
		super.run(result);
		increaseActualNrOfTestRuns();
		if (getNrOfActualTestRuns() == getTotalTestRuns()) {
			try {
				tearDownFixture();
			} catch (Throwable e) {
				result.addError(this, new FixtureException("Error during tearDownFixture()", e));
			}
		}
	}

	protected void setUpFixture() throws Exception {
	}

	protected void tearDownFixture() throws Exception {
	}
	
	private int getNrOfActualTestRuns() {
		Integer currentTotalNumber = actualNumberOfRunsPerClass.get(getClass());
		if( currentTotalNumber == null ) {
			return 0;
		}
		return currentTotalNumber.intValue();
	}
	
	private void increaseActualNrOfTestRuns() {
		Integer currentTotalNumber = actualNumberOfRunsPerClass.get(getClass());
		if( currentTotalNumber == null ) {
			currentTotalNumber = Integer.valueOf(0);
		}
		
		Integer newValue = Integer.valueOf(currentTotalNumber.intValue() + 1);
		
		actualNumberOfRunsPerClass.put(getClass(), newValue);
	}
	
	private int getTotalTestRuns() {
		return totalNumberOfRunsPerClass.get(getClass()).intValue();
	}
}
