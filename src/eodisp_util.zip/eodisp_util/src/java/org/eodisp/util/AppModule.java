/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.util;

/**
 * The interface of the an application module. Several application modules build
 * an application where each application module is responsible for a distinct
 * functionality of the application.
 * <p>
 * 
 * This interface defines the methods which are called during the
 * initialization, startup and shutdown of an application.
 * 
 * <p>
 * 
 * Each application module implementation that shall be part of an application
 * must be registered with the {@link org.eodisp.util.RootApp} by calling the
 * {@link org.eodisp.util.RootApp#registerAppModule(AppModule)} method on it.
 * 
 * <p>
 * 
 * The methods are called in the following order:
 * <ol>
 * <li>{@link #registerConfiguration(RootApp)}</li>
 * <li>{@link #preStartup(RootApp)}</li>
 * <li>{@link #startup(RootApp)}</li>
 * <li>{@link #shutdown(RootApp)}</li>
 * <li>{@link #postShutdown(RootApp)}</li>
 * </ol>
 * 
 * Note that when <code>preStartup(...)</code> is called, the
 * <code>registerConfiguration(...)</code> has been called on all registered
 * application modules. This is true for all methods, that is, the first method
 * is called on all the registered application modules, then the second method
 * is called on all registered application modules, and so on.
 * 
 * <p>
 * The order of registered application modules is defined by the order of which
 * the <code>registerAppModules(...)</code> is called on the
 * <code>RootApp</code> is called. The shutdown methods are called in reverse
 * order though.
 * 
 * @author ibirrer
 * @version $Id: AppModule.java 2107 2006-05-15 14:50:12Z ibirrer $
 * 
 * @see org.eodisp.util.RootApp
 */
public interface AppModule {
	
	/**
	 * Returns the unique id of this application module.
	 * 
	 * @return the unique id of this application module.
	 */
	public String getId();

	/**
	 * Gives the application module a change to register its configuration with
	 * the root application.
	 * 
	 * <p>
	 * The method {@link RootApp#registerConfiguration(Configuration)} must be
	 * called on the {@link RootApp} class to do this. If the AppModule wants to
	 * contribute any command line options, it can use the
	 * {@link RootApp#registerConfiguration(Configuration, CommandlineMapper)}
	 * instead.
	 * 
	 * <p>
	 * The configuration that is being registered through the methods mentioned
	 * above, is automatically loaded by the root application, so do not call
	 * {@link org.eodisp.util.configuration.Configuration#load()} here.
	 * 
	 * 
	 * @throws Exception
	 *             An application module can throw an exception if anything goes
	 *             wrong during the configuration initialization.
	 * 
	 * @param rootApp
	 *            The root application. This is the instance where the
	 *            <code>register</code> methods can be invoked.
	 * 
	 * @see RootApp
	 * @see org.eodisp.util.configuration.Configuration
	 */
	public void registerConfiguration(RootApp rootApp) throws Exception;

	/**
	 * This callback is invoked before the real startup.
	 * 
	 * @param rootApp
	 *            A reference to the root application
	 * @throws Exception
	 *             Indicates that something went wrong during the application
	 *             module pre-startup.
	 */
	public void preStartup(RootApp rootApp) throws Exception;

	/**
	 * This callback indicates that this application module can now start.
	 * 
	 * <p>
	 * In practice this means that after this method returns, the application
	 * module should be up and running. In the case of a GUI application module
	 * this probably means that the GUI is being displayed on the screen and is
	 * ready for user inputs.
	 * 
	 * @param rootApp
	 *            A reference to the root application
	 * @throws Exception
	 *             Indicates that something went wrong during the application
	 *             module startup.
	 * 
	 * 
	 */
	public void startup(RootApp rootApp) throws Exception;

	/**
	 * This callback indicates that this application module shall shutdown.
	 * 
	 * @param rootApp
	 *            A reference to the root application
	 * @throws Exception
	 *             Indicates that something went wrong during the application
	 *             shutdown.
	 */
	public void shutdown(RootApp rootApp) throws Exception;

	/**
	 * Called after all application modules were shutdown.
	 * 
	 * @param rootApp
	 *            A reference to the root application
	 * @throws Exception
	 *             Indicates that something went wrong during the application
	 *             shutdown.
	 */
	public void postShutdown(RootApp rootApp) throws Exception;
}