/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.util.configuration;

import org.eodisp.util.configuration.Configuration.Entry;
import org.eodisp.util.configuration.ConfigurationImpl.EntryImpl;

/**
 * Thrown to indicate a configuration exception.
 * 
 * @author ibirrer
 * @version $Id: ConfigurationException.java 2845 2006-07-24 13:56:58Z ibirrer $
 * 
 */
public class ConfigurationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	public ConfigurationException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ConfigurationException(String reason, Entry configEntry) {
		super(String.format("Could not read configuration entry %s. Reason: %s", configEntry, reason));
	}

	public ConfigurationException(String reason, Entry configEntry, Throwable cause) {
		super(String.format("Could not read configuration entry %s. Reason: %s", configEntry, reason), cause);
	}

	/**
	 * @param message
	 */
	public ConfigurationException(String message) {
		super(message);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public ConfigurationException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param cause
	 */
	public ConfigurationException(Throwable cause) {
		super(cause);
	}

}
