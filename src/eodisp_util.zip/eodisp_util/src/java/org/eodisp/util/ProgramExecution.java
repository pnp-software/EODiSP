package org.eodisp.util;

import java.io.File;
import java.io.IOException;
import java.util.Vector;

import org.apache.log4j.Logger;
import org.apache.tools.ant.taskdefs.Execute;
import org.apache.tools.ant.taskdefs.ExecuteStreamHandler;
import org.apache.tools.ant.taskdefs.PumpStreamHandler;
import org.apache.tools.ant.taskdefs.condition.Os;
import org.apache.tools.ant.types.Commandline;
import org.apache.tools.ant.types.CommandlineJava;
import org.apache.tools.ant.types.Environment;

/**
 * Provides static methods to create new processes on any operating system,
 * including a special method to start a new Java Virtual Machine (JVM).
 * <p>
 * The implementation uses ant classes.
 * 
 * @author ibirrer
 * @version $Id: ProgramExecution.java 4377 2006-11-01 22:27:09Z ibirrer $
 */
public class ProgramExecution {
	/**
	 * Log4J logger for this class
	 * @hidden
	 */
	private final static Logger logger = Logger.getLogger(ProgramExecution.class);
	
	
	/**
	 * Creates a new process with the given command line. Output is sent to
	 * <code>System.out</code>. Usage Example:
	 * 
	 * <pre>
	 * Commandline commandline = new Commandline();
	 * commandline.setExecutable(&quot;ls&quot;);
	 * Process p = ProgramExecution.execute(commandline, new Environment(), new File(&quot;/tmp&quot;));
	 * p.waitFor();
	 * </pre>
	 * 
	 * @param commandline
	 *            the command line. Needs to have an executable defined with
	 *            {@link Commandline#setExecutable(java.lang.String)}.
	 * @param environment
	 *            The environment of the newly created process
	 * @param workingDir
	 *            The working directory of the newly created process
	 * @return the newly created process. Call
	 *         {@link java.lang.Process#waitFor()} to wait for termination of
	 *         the process.
	 * @throws IOException
	 *             If an IOException occurs during process creation
	 */
	public static Process execute(Commandline commandline, Environment environment, File workingDir) throws IOException {
		Execute.getProcEnvironment();

		Process process = Execute.launch(null, commandline.getCommandline(), patchEnvironment(environment), workingDir,
				true);
		 ExecuteStreamHandler streamHandler = new
		 PumpStreamHandler(System.out);
		 streamHandler.setProcessErrorStream(process.getErrorStream());
		 streamHandler.setProcessOutputStream(process.getInputStream());
		 streamHandler.start();
		return process;
	}

	/**
	 * Patch the current environment with the new values from the user.
	 * 
	 * @return the patched environment
	 */
	private static String[] patchEnvironment(Environment environment) {
		// On OpenVMS Runtime#exec() doesn't support the environment array,
		// so we only return the new values which then will be set in
		// the generated DCL script, inheriting the parent process environment
		if (Os.isFamily("openvms")) {
			return environment.getVariables();
		}

		Vector osEnv = (Vector) Execute.getProcEnvironment().clone();
		String[] env = environment.getVariables();
		for (int i = 0; i < env.length; i++) {
			int pos = env[i].indexOf('=');
			// Get key including "="
			String key = env[i].substring(0, pos + 1);
			int size = osEnv.size();
			for (int j = 0; j < size; j++) {
				if (((String) osEnv.elementAt(j)).startsWith(key)) {
					osEnv.removeElementAt(j);
					break;
				}
			}
			osEnv.addElement(env[i]);
		}
		String[] result = new String[osEnv.size()];
		osEnv.copyInto(result);
		return result;
	}

	/**
	 * Creates a new Java Virtual Machine with the given command line options.
	 * Output is sent to <code>System.out</code>.
	 * 
	 * @param commandline
	 *            the command line options.
	 * @param environment
	 *            The environment of the newly created JVM.
	 * @param workingDir
	 *            The working directory of the newly created JVM.
	 * @return the process of the newly created JVM. Call
	 *         {@link java.lang.Process#waitFor()} to wait for termination of
	 *         the process.
	 * @throws IOException
	 *             If an IOException occurs during process creation
	 */
	public static Process executeJava(CommandlineJava commandlineJava, Environment environment, File workingDir)
			throws IOException {
		logger.info("ExecuteJava: " + commandlineJava.getClassname());
		Process process = Execute.launch(null, commandlineJava.getCommandline(), environment.getVariables(),
				workingDir, true);
		ExecuteStreamHandler streamHandler = new PumpStreamHandler(System.out);
		streamHandler.setProcessErrorStream(process.getErrorStream());
		streamHandler.setProcessOutputStream(process.getInputStream());
		streamHandler.start();
		return process;
	}
}
