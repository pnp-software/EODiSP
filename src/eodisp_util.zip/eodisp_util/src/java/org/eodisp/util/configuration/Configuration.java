/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.util.configuration;

import java.io.File;
import java.io.IOException;
import java.util.EnumSet;
import java.util.List;

/**
 * Defines the basic interface for all configuration used in the EODiSP. It is
 * defined independent of any backend (persistence) or front-end (e.g: GUI,
 * command-line) mechanism. Even though it is possible to specify the type of a
 * configuration entry, no validation of values is done. This is left to the
 * user of this class.
 * 
 * @author ibirrer
 * @version $Id: Configuration.java 3753 2006-09-26 16:11:53Z ibirrer $
 */
public interface Configuration {

	/**
	 * This interface represents one entry (option) of a configuration.
	 */
	public static interface Entry {
		/**
		 * Returns the key of this configuration entry
		 * 
		 * @return the key of this configuration entry
		 */
		public String getKey();

		/**
		 * Returns the value if it is set (non null) or the default value
		 * otherwise. Never returns null.
		 * 
		 * @return the value of this configuration option
		 */
		public String getValue();

		/**
		 * Sets the value for this configuration entry. It shall not set the
		 * value if the given value equals to the current value.
		 * 
		 * @param value
		 *            <code>null</code> means to use the default value.
		 */
		public void setValue(String string);

		/**
		 * Sets the value if this configuration entry allows a list of entries ({@link #isList()}
		 * returns <code>true</code>) for this configuration entry. It shall
		 * not set the value if the given value equals to the current value.
		 * 
		 * @param stringArray
		 *            <code>null</code> means to use the default value.
		 */
		public void setValue(String[] stringArray);

		/**
		 * Returns the type of this configuration entry. The following types are
		 * supported:
		 * <ul>
		 * <li>{@link File}</li>
		 * <li>Any class that is the class of an enumeration (defined using
		 * <code>public enum</code>)</li>
		 * <li>{@link Boolean#TYPE}</li>
		 * <li>{@link Integer#TYPE}</li>
		 * <li>{@link Long#TYPE}</li>
		 * </ul>
		 * 
		 * Note that all configuration entries are stored as strings. The type
		 * returned by this method only indicates to what class this string can
		 * be transformed to.
		 * 
		 * @return the type of this configuration entry
		 */
		public Class getType();

		/**
		 * Returns the description of this configuration entry
		 * 
		 * @return the description of this configuration entry
		 */
		public String getDescription();

		/**
		 * Sets the description of this configuration entry.
		 * 
		 * @param description
		 *            the description of this configuration entry.
		 */
		public void setDescription(String description);

		/**
		 * Returns true if this configuration has a value other than the default
		 * value.
		 * 
		 * @return true if this configuration has a value other than the default
		 *         value.
		 */
		public boolean isSet();

		/**
		 * Returns the integer value of this configuration entry.
		 * 
		 * @return The integer value of this configuration entry. If the value
		 *         cannot be parsed as an integer value, the default value is
		 *         parsed and returned. If the default value cannot be parsed as
		 *         an integer value, <code>0</code> is returned.
		 */
		public int getInt();

		/**
		 * Sets the value to the given integer value.
		 * 
		 * @param value
		 *            The value to be set.
		 */
		public void setInt(int port);

		/**
		 * Returns the long value of this configuration entry.
		 * 
		 * @return The long value of this configuration entry. If the value
		 *         cannot be parsed as a long value, the default value is parsed
		 *         and returned. If the default value cannot be parsed as an
		 *         long value, <code>0</code> is returned.
		 */
		public long getLong();

		/**
		 * Sets the value to the given long value.
		 * 
		 * @param value
		 *            The value to be set.
		 */
		public void setLong(long value);

		/**
		 * Returns the boolean value of this configuration entry.
		 * 
		 * @return The boolean value of this configuration entry. If the value
		 *         cannot be parsed as a boolean value, the default value is
		 *         parsed and returned. If the default value cannot be parsed as
		 *         a boolean value, <code>false</code> is returned.
		 * 
		 * @see Boolean#parseBoolean(java.lang.String)
		 */
		public boolean getBoolean();

		/**
		 * Sets the string value of this entry to the given boolean value.
		 * 
		 * @param enabled
		 *            the boolean value to be set.
		 * @see Boolean#toString(boolean)
		 */
		public void setBoolean(boolean enabled);

		/**
		 * Always returns file instance describing an absolute path.
		 * 
		 * @return the entry resolved to an absolute path.
		 */
		public File getFile();

		/**
		 * Sets the current string value to the given file.
		 * 
		 * @param file
		 *            the file the value should be set to.
		 */
		public void setFile(File file);

		/**
		 * Returns the current string value of this configuration entry as an
		 * enumeration constant.
		 * 
		 * @return
		 */
		public Enum getEnum();

		/**
		 * Sets the current string value to the given enumeration constant.
		 * 
		 * @param theEnum
		 *            the enumeration constant the value should be set to.
		 */
		public void setEnum(Enum theEnum);

		public EnumSet getEnumSet();

		public boolean isList();

		public void setEnumSet(EnumSet enumSet);

		/**
		 * Returns the configuration that this entry belongs to.
		 */
		public Configuration getConfiguration();

		/**
		 * Returns a string representing this configuration entry.
		 * 
		 * @return a string representing this configuration entry.
		 */
		public String getDoc();

		public String getPropertyFileComment();

		public List<File> getFilelist();
	}

	/**
	 * Load the configuration from its stored location. Specific implementations
	 * of the Configuration class define how (e.g: database, file etc.) and from
	 * where (e.g: db table, file location etc..) the configuration is loaded.
	 * See the implementations of this interface for details.
	 * 
	 * @throws IOException
	 *             Indicates an error while loading.
	 */
	public void load() throws IOException;

	/**
	 * Returns the entry with the given key.
	 * 
	 * @param key
	 *            the key of the entry that shall be returned.
	 * @return the entry with the given key. Returns null if no entry with the
	 *         given key exists.
	 */
	public Entry getEntry(String key);

	/**
	 * Returns whether this configuration contains an entry with the given key.
	 * This test can be performed to distinguish between a <code>null</code>
	 * and a non-existing entry.
	 * 
	 * @param key
	 *            the key of the entry that shall be returned.
	 * @return True, if the entry exists, otherwise false.
	 */
	public boolean containsEntry(String key);

	/**
	 * Saves the configuration to a persistent storage. Only entries are saved
	 * that for which {@link Entry#isSet()} returns true.
	 * 
	 * @throws IOException
	 *             Indicates an error while saving.
	 */
	public void save() throws IOException;

	/**
	 * Returns a safe array of all configuration entries of this configuration..
	 * 
	 * @return an array containing all entries of this configuration.
	 */
	public Entry[] entries();

	/**
	 * Returns the name of the configuration. The name can be used in a GUI but
	 * needn't to be unique in a JVM.
	 * 
	 * @return the name of this configuration
	 */
	public String getName();

	/**
	 * The id is used as the registration key if the configuration is registered
	 * with and application. Must be unique.
	 * 
	 * @return the unique id of this configuration
	 */
	public String getId();

	/**
	 * The description of this configuration. Suitable to be shown to a human.
	 * 
	 * @return the description of this configuration
	 */
	public String getDescription();

	/**
	 * Indicates if this configuration needs to be saved. This is true if the
	 * configuration in memory is different to the persisted configuration.
	 * 
	 * @return true if this configuration is different from its persisted form.
	 */
	public boolean needsSave();

}
