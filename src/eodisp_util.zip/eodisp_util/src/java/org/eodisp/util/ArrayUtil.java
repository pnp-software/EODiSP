/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.util;

import java.util.*;

/**
 * @author ibirrer
 * @version $Id:$
 */
public final class ArrayUtil {
	private ArrayUtil() {
	}

	public static String listToString(List list) {
		StringBuilder builder = new StringBuilder();
		boolean isFirst = true;
		for (Object object : list) {
			if (isFirst) {
				isFirst = false;
			} else {
				builder.append(",");
			}
			builder.append(object);
		}
		return builder.toString();
	}

	public static String[] stringToArray(String commaString) {
		List<String> result = new ArrayList<String>();
		String[] elements = commaString.split(",");

		for (String element : elements) {
			if (!element.trim().equals("")) {
				result.add(element);
			}
		}
		return result.toArray(new String[0]);
	}

	public static <E extends Enum<E>> String enumSetToString(EnumSet<E> enumSet) {
		StringBuffer buf = new StringBuffer();
		Iterator<E> i = enumSet.iterator();
		boolean hasNext = i.hasNext();
		while (hasNext) {
			Enum e = i.next();
			buf.append(e.toString().toUpperCase());
			hasNext = i.hasNext();
			if (hasNext)
				buf.append(",");
		}
		return buf.toString();
	}

	public static String stringArrayToString(String[] stringArray, String separator) {
		if (stringArray == null)
			return null;
		if (stringArray.length == 0)
			return "";

		StringBuilder buf = new StringBuilder();

		for (int i = 0; i < stringArray.length; i++) {
			if (i != 0)
				buf.append(separator);
			buf.append(String.valueOf(stringArray[i]));
		}
		return buf.toString();
	}

	public static <E extends Enum<E>> EnumSet<E> enumSetFromString(String s, Class<E> elementType) {
		EnumSet<E> enumSet = EnumSet.noneOf(elementType);
		String[] enums = s.split(",");

		for (String enumInst : enums) {
			if (!enumInst.equals("")) {
				enumSet.add(Enum.valueOf(elementType, enumInst.trim().toUpperCase()));
			}
		}
		return enumSet;
	}

}
