/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.util;

/**
 * This class gives access to the root application ({@link org.eodisp.util.RootApp})
 * as a singleton. The root application registers itself at creation time.
 * Trying to register a second time results in a <code>AssertionException</code>.
 * Use the {@link #getRootApp()} to get a reference of the root application at
 * any time.
 * 
 * @author ibirrer
 * @version $Id: AppRegistry.java 2094 2006-05-15 13:28:33Z ibirrer $
 * 
 * @see org.eodisp.util.RootApp
 * 
 */
public class AppRegistry {
	/**
	 * Reference to the root application
	 */
	private static RootApp rootApplication = null;

	/**
	 * This method is called by the root application's constructor.
	 * 
	 * @param rootApp
	 *            The root application to be registered
	 */
	static void registerRootApp(RootApp rootApp) {
		assert (rootApplication == null && rootApp != null);
		rootApplication = rootApp;

	}

	/**
	 * Returns the only instance of the root application.
	 * 
	 * @return The root application
	 */
	public static RootApp getRootApp() {
		assert (rootApplication != null);
		return rootApplication;
	}
}
