/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com
 *  mail: info@pnp-software.com
 */
package org.eodisp.util;

/*
 * Copyright (c) 2003, Dániel Dékány All rights reserved. Redistribution and use
 * in source and binary forms, with or without modification, are permitted
 * provided that the following conditions are met: - Redistributions of source
 * code must retain the above copyright notice, this list of conditions and the
 * following disclaimer. - Redistributions in binary form must reproduce the
 * above copyright notice, this list of conditions and the following disclaimer
 * in the documentation and/or other materials provided with the distribution. -
 * Neither the name "FMPP" nor the names of the project contributors may be used
 * to endorse or promote products derived from this software without specific
 * prior written permission. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS
 * AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING,
 * BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.ReadableByteChannel;

/**
 * Collection of file and path related functions.
 * 
 * @author Dániel Dékány
 * @version $Id: FileUtil.java 4156 2006-10-26 13:45:43Z ibirrer $
 */
public class FileUtil {

	/**
	 * Lock used for {@link #createTempDir(String, String, File)}
	 */
	private static Object fileLock = new Object();

	/**
	 * Returns the operation system specific temp directory as a File. The
	 * returned temp directory is defined by the <code>"java.io.tmpdir"</code>
	 * Java system property.
	 * 
	 * @return the operation system specific temp directory
	 * @see System#getProperty(java.lang.String)
	 */
	public static File getTempDir() {
		return new File(System.getProperty("java.io.tmpdir"));
	}

	/**
	 * Returns the path of a file or directory relative to a directory, in
	 * native format.
	 * 
	 * @return The relative path. It never starts with separator char (/ on
	 *         UN*X).
	 * @throws IOException
	 *             if the two paths has no common parent directory (such as
	 *             <code>C:\foo.txt</code> and <code>D:\foo.txt</code>), or
	 *             the the paths are malformed.
	 */
	public static String getRelativePath(File fromDir, File toFileOrDir) throws IOException {
		char sep = File.separatorChar;
		String ofrom = fromDir.getCanonicalPath();
		String oto = toFileOrDir.getCanonicalPath();
		boolean needSepEndForDirs;
		if (!ofrom.endsWith(File.separator)) {
			ofrom += sep;
			needSepEndForDirs = false;
		} else {
			needSepEndForDirs = true;
		}
		boolean otoEndsWithSep;
		if (!oto.endsWith(File.separator)) {
			oto += sep;
			otoEndsWithSep = false;
		} else {
			otoEndsWithSep = true;
		}
		String from = ofrom.toLowerCase();
		String to = oto.toLowerCase();

		StringBuffer path = new StringBuffer(oto.length());

		int fromln = from.length();
		goback: while (true) {
			if (to.regionMatches(0, from, 0, fromln)) {
				File fromf = new File(ofrom.substring(0, needSepEndForDirs ? fromln : fromln - 1));
				File tof = new File(oto.substring(0, needSepEndForDirs ? fromln : fromln - 1));
				if (fromf.equals(tof)) {
					break goback;
				}
			}
			path.append(".." + sep);
			fromln--;
			while (fromln > 0 && from.charAt(fromln - 1) != sep) {
				fromln--;
			}
			if (fromln == 0) {
				throw new IOException("Could not find common parent directory in these " + "paths: " + ofrom + " and "
						+ oto);
			}
		}
		path.append(oto.substring(fromln));
		if (!otoEndsWithSep && path.length() != 0) {
			path.setLength(path.length() - 1);
		}

		return path.toString();
	}

	/**
	 * Specifies the type of copy command. This is only used internally. The
	 * interface for all of this commands should be available as separate public
	 * methods.
	 */
	private static enum CopyType {
		/**
		 * Copies the content from one file to another. It writes the content
		 * from the source file to the beginning of the destination file. It
		 * overwrites the data in the destination file, but leaves additional
		 * data in the destination file intact.
		 */
		COPY,
		/**
		 * Appends the content of the source file to the destination file.
		 */
		APPEND,
		/**
		 * Merge the contents of the source and the destination file together
		 * into a third file. Whatever content is in the third file remains
		 * there.
		 */
		APPEND_TO_NEW,
		/**
		 * Overwrites the destination file with the content of the source file.
		 * All data will be deleted in the destination file before the copy
		 * command is executed.
		 */
		OVERWRITE
	}

	/**
	 * A convenient method to copy the content of a file to another file. The
	 * destination file will be created if it does not exists.
	 * <p>
	 * <em>The destination file will be overridden if it already exists.</em>
	 * 
	 * @param src
	 *            The source file with the content to be copied.
	 * @param dest
	 *            The destination file to which the content of the source file
	 *            should be copied. Will be created if it does not exist.
	 * @throws IOException
	 *             If the operation fails for any reason, this exception will be
	 *             thrown to indicate the error. See the documentation of the
	 *             exception for more information about possible errors.
	 */
	public static void copyFile(File src, File dst) throws IOException {
		transferContent(src, dst, null, CopyType.OVERWRITE);
	}

	/**
	 * Convenient method to merge the content of two files together. Both files
	 * must exist. A new file with the merged content will be created and
	 * returned.
	 * 
	 * @param src1
	 *            The first file. Its content will be transferred to the result
	 *            file.
	 * @param src2
	 *            The second file. Its content will be transferred to the result
	 *            file.
	 * @param result
	 *            The file to which the merged content should be written.
	 * @return The file with the merged content.
	 * @throws IOException
	 *             If the operation fails for any reason, this exception will be
	 *             thrown to indicate the error. See the documentation of the
	 *             exception for more information about possible errors.
	 */
	public static File mergeFileToNew(File src1, File src2, File result) throws IOException {
		return transferContent(src1, src2, result, CopyType.APPEND_TO_NEW);
	}

	/**
	 * Convenient method to merge the content of two files together. Both files
	 * must exist.
	 * 
	 * @param src
	 *            The first file. Its content will be transferred to the dest
	 *            file.
	 * @param dest
	 *            The second file. This will be the file with the merged
	 *            content.
	 * @throws IOException
	 *             If the operation fails for any reason, this exception will be
	 *             thrown to indicate the error. See the documentation of the
	 *             exception for more information about possible errors.
	 */
	public static void mergeFilesToDest(File src, File dest) throws IOException {
		transferContent(src, dest, null, CopyType.APPEND);
	}

	/**
	 * This class does the job of actually copying data between files, depending
	 * on the type of copy.
	 * <p>
	 * If a result file is specified, both the source and the destination files
	 * will be treated as input stream and the result file will be the output
	 * stream. If no result file is specified (i.e. <code>null</code>), only
	 * the source file will be an input stream and the destination file will be
	 * the output stream.
	 * 
	 * @param src1
	 *            The source file. This file is always left untouched. Only data
	 *            is read from the file. This file must exist.
	 * @param src2
	 *            The destination file. The merged or copied content will go in
	 *            this file. If a result file is specified, it will also treated
	 *            as a source file.
	 * @param result
	 *            The file in which the content of the command should be
	 *            written. <code>null</code>, if no new file shall be
	 *            created.
	 * @param type
	 *            The type of the copy command that is requested.
	 * @return The result file after the command has been executed. If the
	 *         result file is <code>null</code>, the destination file will be
	 *         returned.
	 * @throws IOException
	 *             If the operation fails for any reason, this exception will be
	 *             thrown to indicate the error. See the documentation of the
	 *             exception for more information about possible errors.
	 */
	private static File transferContent(File src1, File src2, File result, CopyType type) throws IOException {
		FileChannel src1Channel = null;
		FileChannel src2Channel = null;
		FileChannel resultChannel = null;

		try {
			// Do whatever is requested
			switch (type) {
			case COPY:
				// Copy file contents from source to destination from the
				// beginning.
				// Create channel on the source
				if (src1 != null && src2 != null) {
					src1Channel = new FileInputStream(src1).getChannel();
					src2Channel = new FileOutputStream(src2).getChannel();
					src2Channel.transferFrom(src1Channel, 0, src1Channel.size());
				}
				break;
			case APPEND:
				// Copy file contents from source to destination
				if (src1 != null && src2 != null) {
					src1Channel = new FileInputStream(src1).getChannel();
					src2Channel = new FileOutputStream(src2).getChannel();
					src2Channel.transferFrom(src1Channel, src2Channel.size(), src1Channel.size());
				}
				break;
			case APPEND_TO_NEW:
				if (src1 != null && src2 != null && result != null) {
					src1Channel = new FileInputStream(src1).getChannel();
					src2Channel = new FileInputStream(src2).getChannel();
					resultChannel = new FileOutputStream(result).getChannel();
					resultChannel.transferFrom(src1Channel, resultChannel.size(), src1Channel.size());
					resultChannel.transferFrom(src2Channel, resultChannel.size(), src2Channel.size());
				}
				break;
			case OVERWRITE:
				// delete the destination channel first
				if (src1 != null && src2 != null) {
					src1Channel = new FileInputStream(src1).getChannel();
					src2Channel = new FileOutputStream(src2).getChannel();
					src2Channel.truncate(0);
					src2Channel.transferFrom(src1Channel, 0, src1Channel.size());
				}
				break;
			}
		} finally {
			src1Channel.close();
			src2Channel.close();
			if (resultChannel != null) {
				resultChannel.close();
			}
		}

		// Return the destination file.
		return result != null ? result : src2;
	}

	/**
	 * Copies the given input stream to a file.
	 * 
	 * @param in
	 *            the input stream to copy from
	 * @param outFile
	 *            the file to write the stream to
	 * @throws IOException
	 *             if an IO Error occurs
	 */
	public static void copy(InputStream in, File outFile) throws IOException {
		FileOutputStream out = new FileOutputStream(outFile);
		try {
			byte[] buf = new byte[1024];
			int len;
			while ((len = in.read(buf)) > 0) {
				out.write(buf, 0, len);
			}
		} finally {
			in.close();
			out.close();
		}
	}

	/**
	 * Returns true if <code>file</code> is inside <code>ascendant</code> or
	 * <code>file</code> is the same as the <code>ascendant</code>,
	 * otherwise returns false.
	 */
	public static boolean isInsideOrEquals(File file, File ascendant) {
		while (!file.equals(ascendant)) {
			file = file.getParentFile();
			if (file == null) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Returns true if <code>file</code> is inside <code>ascendant</code>,
	 * otherwise returns false.
	 */
	public static boolean isInside(File file, File ascendant) {
		if (!file.equals(ascendant)) {
			return false;
		}
		do {
			file = file.getParentFile();
			if (file == null) {
				return false;
			}
		} while (!file.equals(ascendant));
		return true;
	}

	/**
	 * Resolves relative UN*X path based on given root and working directory.
	 * 
	 * @param root
	 *            root directory
	 * @param wd
	 *            working directory (current directory)
	 * @param path
	 *            path in UN*X format
	 */
	public static File resolveRelativeUnixPath(File root, File wd, String path) throws IOException {
		File c;
		int i;
		if (path.startsWith("/")) {
			i = 1;
			c = root.getAbsoluteFile();
		} else {
			i = 0;
			c = wd.getAbsoluteFile();
		}
		int ln = path.length();
		while (i < ln) {
			String step;
			int si = path.indexOf(i, '/');
			if (si == -1) {
				si = ln;
			}
			step = path.substring(i, si);
			i = si + 1;
			if (step == ".") {
				continue;
			} else if (step == "..") {
				c = c.getParentFile();
				if (c == null) {
					throw new IOException("Parent directory not found.");
				}
			} else {
				c = new File(c, step);
			}
		}
		c = c.getCanonicalFile();

		if (!isInsideOrEquals(c, root)) {
			throw new IOException("Attempt to leave the root directory.");
		}

		return c;
	}

	/**
	 * Returns a compressed version of the path. For example,
	 * <code>/foo/ba.../baaz.txt</code> instead of
	 * <code>/foo/bar/blah/blah/blah/baaz.txt</code>.
	 * 
	 * @param path
	 *            the path to compress. Either native or UNIX format.
	 * @param maxPathLength
	 *            the maximum length of the result. Must be at least 4.
	 */
	public static String compressPath(String path, int maxPathLength) {
		if (path.length() > maxPathLength) {
			int r = path.length() - maxPathLength + 3;
			int i = path.lastIndexOf(File.separatorChar);
			if (i == -1) {
				i = path.lastIndexOf('/');
			}
			if (i <= r) {
				return "..." + path.substring(r);
			}
			return path.substring(0, i - r) + "..." + path.substring(i);
		}
		return path;
	}

	/**
	 * Brings the path to UNI*X style format, so that it can be handled with
	 * path pattern handling functions.
	 */
	public static String pathToUnixStyle(String path) {
		path = path.replace(File.separatorChar, '/');
		if (File.separatorChar != '\\') {
			path = path.replace('\\', '/'); // Protection from Win users... :)
		}
		return path;
	}

	public static String removeSlashPrefix(String path) {
		if (path.startsWith("/") && !path.startsWith("//")) {
			return path.substring(1);
		}
		return path;
	}

	/**
	 * Converts UN*X style path to Perl 5 regular expression. In additional to
	 * standard UN*X path meta characters (<code>*</code>, <code>?</code>)
	 * it understands <code>**</code>, that is the same as in Jakarta Ant. It
	 * assumes that the paths what you will later match with the pattern are
	 * always starting with slash (they are absolute paths to an imaginary
	 * base).
	 */
	public static String pathPatternToPerl5Regex(String text) {
		StringBuffer sb = new StringBuffer();

		if (!text.startsWith("/")) {
			text = "/" + text;
		}
		if (text.endsWith("/")) {
			text += "**";
		}

		char[] chars = text.toCharArray();
		int ln = chars.length;
		for (int i = 0; i < ln; i++) {
			char c = chars[i];
			if (c == '\\' || c == '^' || c == '.' || c == '$' || c == '|' || c == '(' || c == ')' || c == '['
					|| c == ']' || c == '+' || c == '{' || c == '}' || c == '@') {
				sb.append('\\');
				sb.append(c);
			} else if (i == 0 && ln > 2 && chars[0] == '*' && chars[1] == '*' && chars[2] == '/') {
				sb.append(".*/");
				i += 2;
			} else if (c == '/' && i + 2 < ln && chars[i + 1] == '*' && chars[i + 2] == '*') {
				if (i + 3 == ln) {
					sb.append("/.*");
				} else {
					sb.append("(/.*)?");
				}
				i += 2;
			} else if (c == '*') {
				sb.append("[^/]*");
			} else if (c == '?') {
				sb.append("[^/]");
			} else {
				sb.append(c);
			}
		}

		return sb.toString();
	}

	public static String loadString(InputStream in, String charset) throws IOException {
		Reader r = new InputStreamReader(in, charset);
		StringBuffer sb = new StringBuffer(1024);
		try {
			char[] buf = new char[4096];
			int ln;
			while ((ln = r.read(buf)) != -1) {
				sb.append(buf, 0, ln);
			}
		} finally {
			r.close();
		}
		return sb.toString();
	}

	public static byte[] loadByteArray(InputStream in) throws IOException {
		int size = 0;
		int bcap = 1024;
		byte[] b = new byte[bcap];
		try {
			int rdn;
			while ((rdn = in.read(b, size, bcap - size)) != -1) {
				size += rdn;
				if (bcap == size) {
					bcap *= 2;
					byte[] newB = new byte[bcap];
					System.arraycopy(b, 0, newB, 0, size);
					b = newB;
				}
			}
		} finally {
			in.close();
		}
		if (b.length != size) {
			byte[] newB = new byte[size];
			System.arraycopy(b, 0, newB, 0, size);
			return newB;
		}
		return b;
	}

	public static byte[] loadFileToByteArray(File file) throws IOException {
		long length = file.length();
		if (length > Integer.MAX_VALUE) {
			final String message = "The length of the file exceeds the maximum size allowed (i.e. file is too large)";
			throw new IOException(message);
		}

		ByteBuffer buf = ByteBuffer.allocateDirect((int) length);
		FileInputStream in = null;
		try {
			in = new FileInputStream(file);
			ReadableByteChannel channel = in.getChannel();

			int numRead = 0;
			while (numRead >= 0) {
				buf.rewind();
				numRead = channel.read(buf);
				buf.rewind();
			}
		} finally {
			if (in != null) {
				in.close();
			}
		}

		// create the byte array
		byte[] fileByteArray = new byte[buf.capacity()];
		buf.get(fileByteArray);

		return fileByteArray;
	}

	/**
	 * Deletes all files and subdirectories under <code>dir</code>. Returns
	 * true if all deletions were successful. If a deletion fails, the method
	 * stops attempting to delete and returns false.
	 * 
	 * @param dir
	 * @return
	 */
	public static boolean deleteDir(File dir) {
		if (dir.isDirectory()) {
			String[] children = dir.list();
			for (int i = 0; i < children.length; i++) {
				boolean success = deleteDir(new File(dir, children[i]));
				if (!success) {
					return false;
				}
			}
		}

		// The directory is now empty so delete it
		return dir.delete();
	}

	/**
	 * Creates an empty temporary directory.
	 * 
	 * @param prefix
	 *            The prefix string to be used in generating the directory's
	 *            name; must be at least three characters long
	 * @param postfix
	 *            The suffix string to be used in generating the directory's
	 *            name; may be <code>null</code>, in which case the suffix
	 *            <code>".tmp"</code> will be used
	 * @param dir
	 *            The directory in which the temp directory is to be created, or
	 *            <code>null</code> if the default temporary-file directory is
	 *            to be used as the parent directory.
	 * @return An abstract pathname denoting a newly-created empty directory
	 * @throws IOException
	 *             If a directory could not be created
	 * @throws SecurityException
	 *             If a security manager exists and its <code>{@link
	 *          java.lang.SecurityManager#checkWrite(java.lang.String)}</code>
	 *             method does not allow a file to be created
	 */
	public static File createTempDir(String prefix, String postfix, File dir) throws IOException {
		synchronized (fileLock) {
			File f = File.createTempFile(prefix, postfix, dir);
			f.delete();
			File tmpDir = f.getAbsoluteFile();
			if (!tmpDir.mkdir()) {
				throw new IOException("Could not create temp directory: " + tmpDir.getAbsolutePath());
			}
			return tmpDir;
		}
	}

	/**
	 * Creates a file on the local file system with the given file size. The
	 * file is filled 0. Overwrites an already existing file.
	 * 
	 * @param file
	 *            the file to be created
	 * @param size
	 *            the size of the file in bytes
	 * @throws IOException
	 *             if the file could not be created
	 */
	public static void createFile(File file, long size) throws IOException {
		file.createNewFile();
		FileOutputStream fileOutputStream = new FileOutputStream(file);
		byte[] chunk = new byte[1024 * 1024 * 10];
		long bytesLeft = size;
		while (true) {
			if (bytesLeft == 0) {
				break;
			} else if (bytesLeft < chunk.length) {
				fileOutputStream.write(chunk, 0, Math.abs((int) bytesLeft));
				break;
			} else {
				fileOutputStream.write(chunk);
			}
			bytesLeft = bytesLeft - chunk.length;
		}

		fileOutputStream.close();
	}

}
