/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.util.configuration;

import java.io.File;

/**
 * Configuration parameters for the log4j Framework. Internally used by
 * {@link org.eodisp.util.RootApp}.
 * 
 * @author ibirrer
 * @version $Id: Log4JConfiguration.java 4157 2006-10-26 13:46:37Z ibirrer $
 */
public class Log4JConfiguration extends ConfigurationImpl {
	public static final String CONFIG_FILE = "config-file";

	public static final String USE_CUSTOM_FILE = "use-custom-file";

	public static final String LOG_LEVEL = "log-level";

	private static final String ID = "org.eodisp.util.log4j.Log4JConfiguration";

	/**
	 * Enumeration of the log levels provided by log4j.
	 * 
	 * @see org.apache.log4j.Level
	 */
	public enum LogLevel {
		ALL, TRACE, DEBUG, INFO, WARN, ERROR, FATAL, OFF
	}

	/**
	 * Creates a new log4j configuration.
	 * 
	 * @param file
	 *            The file this configuration shall be saved to.
	 */
	public Log4JConfiguration(File file) {
		super(ID, "Log4J Configuration", "Specifies the logging of log4j", file);
		createEnumEntry(LOG_LEVEL, LogLevel.INFO, "the EODiSP log level");
		createBooleanEntry(USE_CUSTOM_FILE, false, "If true, uses the file given in the 'config-file' option as the log4j configuration file. This allows for much more sophisticated logging configurations. See the log4j documentation and the custom-log4j.conf default file for more information.");
		createFileEntry(CONFIG_FILE, new File("custom-log4j.conf"), "location of the log4j configuration file");
	}

	public static void main(String[] args) {
		System.out.println(new Log4JConfiguration(null).getCode());
	}

	public boolean isUseCustomFile() {
		return getEntry(USE_CUSTOM_FILE).getBoolean();
	}

	public void setUseCustomFile(boolean useCustomFile) {
		getEntry(USE_CUSTOM_FILE).setBoolean(useCustomFile);
	}

	public LogLevel getLogLevel() {
		return (LogLevel) getEntry(LOG_LEVEL).getEnum();
	}

	public void setLogLevel(LogLevel logLevel) {
		getEntry(LOG_LEVEL).setEnum(logLevel);
	}

	public File getConfigFile() {
		return getEntry(CONFIG_FILE).getFile();
	}

	public void setConfigFile(File configFile) {
		getEntry(CONFIG_FILE).setFile(configFile);
	}

}
