package org.eodisp.util;

import java.io.File;

import org.apache.log4j.Logger;

/**
 * Shutdown hook that deletes the .lock file in the working directory on JVM
 * shutdown.
 * 
 * @author ibirrer
 * @version $Id:$
 */
public class DeleteLockFileShutdownHook extends Thread {
	File workingDir = null;

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(DeleteLockFileShutdownHook.class);

	/**
	 * @param workingDir
	 *            the working directory the lock file is present in.
	 */
	public DeleteLockFileShutdownHook(File workingDir) {
		this.workingDir = workingDir;
	}

	@Override
	public void run() {
		if (this.workingDir != null) {
			File lockFile = new File(workingDir, ".lock");
			if (lockFile.delete()) {
				logger.debug("'.lock' file deleted: " + lockFile);
			} else {
				logger.warn("Could not delete lock file: " + lockFile);
			}
		}
	}
	
//	public static void main(String[] args) {
//		logger.debug("Set working directory to: " + workingDirectory);
//
//		File lockFile = new File(workingDirectory, LOCK_FILENAME);
//
//		if (!lockFile.createNewFile()) {
//			throw new WorkingDirectoryLockedException(workingDirectory);
//		}
//		logger.debug("'.lock' file created: " + lockFile);
//
//		Runtime.getRuntime().addShutdownHook(deleteLockFileShutdownHook);
//		logger.debug("Working directory locked: " + lockFile);
//	}
}