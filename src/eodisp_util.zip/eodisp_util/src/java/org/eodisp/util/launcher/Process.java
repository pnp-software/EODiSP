/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.util.launcher;

import java.io.IOException;

/**
 * @author ibirrer
 * @version $Id:$
 */
public interface Process {
	/**
	 * Launches this process. A process cannot be launched twice. A second call
	 * to this method will always throw a {@linkplain IllegalStateException}.
	 * 
	 * @throws IOException
	 *             thrown if this process could not be launched.
	 * @throws IllegalStateException
	 *             if this process has already been launched
	 */
	void launch() throws IOException;

	/**
	 * Adds the environment variable with the given key and value
	 * 
	 * @param key
	 *            the key of the environment variable
	 * @param value
	 *            the value of the environment variable
	 */
	void addEnvVar(String key, String value);

	/**
	 * Launches this process and blocks until the process has terminated.
	 * 
	 * @throws IOException
	 */
	int launchBlocking() throws IOException;

	/**
	 * Forcibly kills this process. This method returns <code>true</code> if
	 * this process has been started and is not running anymore (for whatever
	 * reason). Returns <code>false</code> if {@link #launch()} has not been
	 * invoked. If this method returns <code>true</code>, it must return
	 * <code>true</code> for all subsequent calls to this method. If this
	 * method returns <code>false</code> it means that the process is probably
	 * still running.
	 * 
	 * @param timeoutInMillis
	 *            wait at most <code>timeoutInMillis</code> to try to kill the
	 *            process. A value of <code>0</code> means to wait forever.
	 * @return <code>true</code> if the process has been stopped,
	 *         <code>false</code> if the process is still running or has never
	 *         been started.
	 */
	boolean kill(long timeoutInMillis);

	/**
	 * Add a listener to this process to get notified of state changes.
	 * 
	 * @param processListener
	 */
	void addListener(ProcessListener processListener);
}
