package org.eodisp.util.configuration;

import java.util.HashMap;
import java.util.Map;

import org.eodisp.util.configuration.Configuration.Entry;

import com.martiansoftware.jsap.FlaggedOption;
import com.martiansoftware.jsap.Parameter;
import com.martiansoftware.jsap.Switch;

/**
 * This class allows a manual mapping mapping of the shortFlag, longFlag and
 * help of a parameter.
 * 
 * <p>
 * Usage:
 * 
 * <pre>
 * Map&lt;String, CommandlineOption&gt; commandlineMapping = new HashMap&lt;String, CommandlineOption&gt;();
 * commandlineMapping.put(&quot;s&quot;, new CommandlineOption('s', &quot;long-flag&quot;, &quot;help message&quot;));
 * ManualCommandlineMapper manualCommandlineMapper = new ManualCommandlineMapper(commandlineMapping, true);
 * </pre>
 * 
 * @author ibirrer
 * @version $Id: ManualCommandlineMapper.java 3151 2006-08-23 13:16:01Z ibirrer $
 * 
 */
public class ManualCommandlineMapper implements CommandlineMapper {
	private Map<String, CommandlineOption> mappings = new HashMap<String, CommandlineOption>();

	private boolean useBasicMapperAsDefault = false;

	/**
	 * Helper class to define a command line option's:
	 * <ul>
	 * <li>short flag</li>
	 * <li>long flag</li>
	 * <li>help text</li>
	 * </ul>
	 * 
	 */
	public static class CommandlineOption {
		/**
		 * The short flag. If <code>null</code>> the standard mapping is
		 * applied. See {@link BasicCommandlineMapper}.
		 */
		Character shortFlag = null;

		/**
		 * The long flag. If <code>null</code>> the standard mapping is
		 * applied. See {@link BasicCommandlineMapper}.
		 */
		String longFlag = null;

		/**
		 * The help text. If <code>null</code>> the standard mapping is
		 * applied. See {@link BasicCommandlineMapper}.
		 */
		String help = null;

		/**
		 * If the command line is required. If <code>null</code>> the
		 * standard mapping is applied, which is <code>false</code>). See
		 * {@link BasicCommandlineMapper}.
		 */
		boolean required = false;

		/**
		 * 
		 * 
		 * @param shortFlag
		 *            The short flag. If <code>null</code>> the standard
		 *            mapping is applied. See {@link BasicCommandlineMapper}.
		 * @param longFlag
		 *            The long flag. If <code>null</code>> the standard
		 *            mapping is applied. See {@link BasicCommandlineMapper}.
		 * @param help
		 *            The help text. If <code>null</code>> the standard
		 *            mapping is applied. See {@link BasicCommandlineMapper}.
		 */

		public CommandlineOption(Character shortFlag, String longFlag, String help) {
			this.shortFlag = shortFlag;
			this.longFlag = longFlag;
			this.help = help;
		}

		/**
		 * 
		 * 
		 * @param shortFlag
		 *            The short flag. If <code>null</code>> the standard
		 *            mapping is applied. See {@link BasicCommandlineMapper}.
		 * @param longFlag
		 *            The long flag. If <code>null</code>> the standard
		 *            mapping is applied. See {@link BasicCommandlineMapper}.
		 * @param help
		 *            The help text. If <code>null</code>> the standard
		 *            mapping is applied. See {@link BasicCommandlineMapper}.
		 * @param required
		 *            If the command line is required. If <code>null</code>>
		 *            the standard mapping is applied, which is
		 *            <code>false</code>). Has no effect on configuration
		 *            entries of type boolean. See
		 *            {@link BasicCommandlineMapper}.
		 */

		public CommandlineOption(Character shortFlag, String longFlag, String help, boolean required) {
			this.shortFlag = shortFlag;
			this.longFlag = longFlag;
			this.help = help;
			this.required = required;
		}
	}

	/**
	 * Creates a new manual command line mapper. The mapping is defined by the
	 * <code>mappings</code> parameter. Parameters with no manual mapping are
	 * not mapped.
	 * 
	 * 
	 * @param mappings
	 *            A map with its keys set to the id of a configuration entry and
	 *            the value set to the mapped {@link CommandlineOption}.
	 * 
	 * @see #ManualCommandlineMapper(Map, boolean)
	 */
	public ManualCommandlineMapper(Map<String, CommandlineOption> mappings) {
		this(mappings, false);
	}

	/**
	 * Creates a new manual command line mapper. The mapping is defined by the
	 * <code>mappings</code> parameter.
	 * 
	 * @param mappings
	 *            A map with its keys set to the id of a configuration entry and
	 *            the value set to the mapped {@link CommandlineOption}.
	 * @param useBasicMapperAsDefault
	 *            if set to <code>true</code>, each configuration entry with
	 *            no manual mapping is mapped with the
	 *            {@link BasicCommandlineMapper}. If set to <code>false</code>,
	 *            no mapping for the configuration entry is done, that is, the
	 *            {@link #mapEntry(Entry)} returns null for configuration
	 *            entries not defined in the <code>mappings</code> parameter.
	 */
	public ManualCommandlineMapper(Map<String, CommandlineOption> mappings, boolean useBasicMapperAsDefault) {
		this.mappings = mappings;
		this.useBasicMapperAsDefault = useBasicMapperAsDefault;
	}

	/**
	 * {@inheritDoc}
	 */
	public Parameter mapEntry(Entry entry) {
		CommandlineOption commandlineOption = mappings.get(entry.getKey());

		if (commandlineOption == null && !useBasicMapperAsDefault) {
			return null;
		}

		Parameter option = BasicCommandlineMapper.INSTANCE.mapEntry(entry);
		if (commandlineOption == null) {
			return option;
		}

		String newLongFlag = entry.getKey();
		Character newShortFlag = null;
		String newHelp = entry.getDescription();

		if (commandlineOption.shortFlag != null) {
			newShortFlag = commandlineOption.shortFlag;
		}

		if (commandlineOption.longFlag != null) {
			newLongFlag = commandlineOption.longFlag;
		}

		if (commandlineOption.help != null) {
			newHelp = commandlineOption.help;
		}

		if (option instanceof FlaggedOption) {
			final FlaggedOption flaggedOption = (FlaggedOption) option;
			flaggedOption.setLongFlag(newLongFlag);
			flaggedOption.setHelp(newHelp);
			flaggedOption.setRequired(commandlineOption.required);
			if (newShortFlag != null) {
				flaggedOption.setShortFlag(newShortFlag.charValue());
			}
		} else if (option instanceof Switch) {
			final Switch switchOption = (Switch) option;
			switchOption.setLongFlag(newLongFlag);
			switchOption.setHelp(newHelp);
			if (newShortFlag != null) {
				switchOption.setShortFlag(newShortFlag.charValue());
			}
		} else {
			assert (false);
		}
		return option;
	}

}