/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.sm.views;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eodisp.ui.common.base.UIUtil;
import org.eodisp.ui.common.components.EodispListCellRenderer;
import org.eodisp.ui.sm.models.ExperimentChooserModel;
import org.eodisp.ui.sm.resources.SmResources;

import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.factories.ButtonBarFactory;
import com.jgoodies.forms.factories.FormFactory;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

/**
 * @author eglimi
 * @version $Id:$
 */
public final class ExperimentChooser {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(ExperimentChooser.class);

	/**
	 * This is the main panel that will hold all other components. It will be
	 * embedded in a scroll pane.
	 */
	private JPanel mainPanel;

	private final ExperimentChooserModel model = new ExperimentChooserModel();

	private final JDialog dialog;

	private final JList experimentsList = new JList();

	private final JScrollPane experimentsListSp = new JScrollPane();

	private final JButton[] dialogButtons = new JButton[2];

	private EDataObject selected = null;

	private final JFrame owner;

	private ExperimentChooser(JFrame owner) {
		this.owner = owner;

		dialog = new JDialog(owner, true);

		initializeComponents();
		buildPanels();
		dialog.setContentPane(mainPanel);
	}

	private void initializeComponents() {
		// The list categories
		experimentsList.setModel(getModel().getExpListModel());
		experimentsList.setCellRenderer(new EodispListCellRenderer());

		experimentsListSp.setViewportView(experimentsList);

		dialogButtons[0] = new JButton(SmResources.getMessage("ExperimentChooser.Button0.Text"));
		dialogButtons[0].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (experimentsList.getSelectedValue() != null) {
					selected = (EDataObject) experimentsList.getSelectedValue();
				}
				exitDialog();
			}
		});

		dialogButtons[1] = new JButton(SmResources.getMessage("ExperimentChooser.Button1.Text"));
		dialogButtons[1].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exitDialog();
			}
		});
	}

	@SuppressWarnings("boxing")
	private void buildPanels() {
		// create the layout
		CellConstraints cc = new CellConstraints();
		FormLayout layout = new FormLayout("75dlu:grow, 4dlu, 50dlu", "p, 3dlu, p:grow, 3dlu, p");
		PanelBuilder builder = new PanelBuilder(layout);
		builder.setDefaultDialogBorder();
		buildListPanel(builder, cc, layout);

		logger.debug(String.format("added %d rows to the form.", builder.getRowCount()));

		// get and set the panel
		mainPanel = builder.getPanel();
	}

	private void buildListPanel(PanelBuilder builder, CellConstraints cc, FormLayout layout) {
		int list1Col = 1;
		builder.setRow(1);

		// Categories
		builder.addSeparator(SmResources.getMessage("ExperimentChooser.Prop.Header"), cc.xyw(list1Col,
				builder.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.add(experimentsListSp, cc.xyw(list1Col, builder.getRow(), 3, "fill, fill"));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		JPanel btnPanel = ButtonBarFactory.buildRightAlignedBar(dialogButtons);
		builder.add(btnPanel, cc.xyw(builder.getColumn(), builder.getRow(), 3));
	}

	/**
	 * Displays the dialog. It automatically selects the experiment if only one
	 * is available.
	 * 
	 * @param owner
	 *            the frame from which the dialog is displayed.
	 */
	public static EDataObject showExperimentDialog(JFrame owner) {
		return showExperimentDialog(owner, true);
	}

	/**
	 * Displays the dialog.
	 * 
	 * @param owner
	 *            the frame from which the dialog is displayed.
	 * @param autoSelect
	 *            automatically returns the experiment if only one experiment
	 *            exists.
	 */
	public static EDataObject showExperimentDialog(JFrame owner, boolean autoSelect) {
		ExperimentChooser chooser = new ExperimentChooser(owner);
		return chooser.showInternalExperimentDialog(autoSelect);
	}

	private EDataObject showInternalExperimentDialog(boolean autoSelect) {

		if (autoSelect && getModel().getExpListModel().getSize() == 1) {
			return (EDataObject) getModel().getExpListModel().getElementAt(0);
		}

		dialog.pack();
		// place it a bit better if no frame has been specified.
		if (owner == null) {
			UIUtil.locateOnScreen(dialog);
		} else {
			dialog.setLocationRelativeTo(owner);
		}
		dialog.setVisible(true);
		dialog.dispose();
		return selected;
	}

	private ExperimentChooserModel getModel() {
		return model;
	}

	/**
	 * Closes the dialog.
	 */
	private void exitDialog() {
		dialog.dispose();
	}

}
