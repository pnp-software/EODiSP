/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.shared.views;

import java.text.NumberFormat;

import javax.swing.*;

import org.apache.log4j.Logger;
import org.eodisp.ui.common.base.EodispModel;
import org.eodisp.ui.common.components.AbstractConfigPanel;
import org.eodisp.ui.common.resources.CommonMessages;
import org.eodisp.ui.shared.models.JxtaConfigModel;

import com.jgoodies.binding.PresentationModel;
import com.jgoodies.binding.adapter.BasicComponentFactory;
import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.factories.FormFactory;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

/**
 * This is a panel to configure the settings for JXTA.
 * 
 * @author eglimi
 * @version $Id:$
 */
public class JxtaConfig extends AbstractConfigPanel {

	/**
	 * Default serial version id
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(JxtaConfig.class);

	public static final int ID = 20;

	private NumberFormat portFormat;

	private NumberFormat mcastSizeFormat;

	private NumberFormat maxClientsFormat;

	private JTextField name;

	private JTextArea description;

	private JCheckBox tcpEnabled;

	private JCheckBox tcpIncoming;

	private JCheckBox tcpOutgoing;

	private JFormattedTextField tcpPort;

	private JFormattedTextField tcpStartPort;

	private JFormattedTextField tcpEndPort;

	private JTextField tcpInterfaceAddress;

	private JTextField tcpPublicAddress;

	private JCheckBox tcpPublicAddressExclusive;

	private JCheckBox useMulticast;

	private JTextField multicastAddress;

	private JFormattedTextField multicastPort;

	private JFormattedTextField multicastSize;

	private JCheckBox httpEnabled;

	private JCheckBox httpIncoming;

	private JCheckBox httpOutgoing;

	private JFormattedTextField httpPort;

	private JTextField httpPublicAddress;

	private JCheckBox httpPublicAddressExclusive;

	private JTextField httpInterfaceAddress;

	private JCheckBox relayEnabled;

	private JCheckBox relayServer;

	private JCheckBox relayClient;

	private JFormattedTextField relayMaxClients;

	private JCheckBox useOnlyRelaySeeds;

	private JCheckBox rendezvousEnabled;

	private JFormattedTextField rendezvousMaxClients;

	private JCheckBox useOnlyRendezvousSeeds;

	private JTextField principal;

	private JPasswordField password;

	private JCheckBox proxyEnabled;

	private JPanel configPanel;

	// private final JScrollPane scrollPane = new JScrollPane();

	PresentationModel presentationModel;

	public JxtaConfig(EodispModel model) {
		super(model);

		initializeComponents();

		CellConstraints cc = new CellConstraints();
		FormLayout layout = new FormLayout(
				"right:pref, 4dlu, 75dlu:grow, 10dlu, right:pref, 4dlu, 75dlu:grow",
				"p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p");

		layout.setColumnGroups(new int[][] { { 1, 5 }, { 3, 7 } });
		PanelBuilder builder = new PanelBuilder(layout);
		builder.setDefaultDialogBorder();

		buildLeftPanel(cc, layout, builder);
		buildRightPanel(cc, layout, builder);

		configPanel = builder.getPanel();
	}

	public JPanel getPanel() {
		return configPanel;
	}

	private void initializeComponents() {
		presentationModel = new PresentationModel(((JxtaConfigModel) getModel()).getNetworkConfigurator());

		// define some formats for text fields
		portFormat = NumberFormat.getIntegerInstance();
		portFormat.setGroupingUsed(false);
		mcastSizeFormat = NumberFormat.getIntegerInstance();
		maxClientsFormat = NumberFormat.getIntegerInstance();

		// create components
		name = BasicComponentFactory.createTextField(presentationModel.getModel(JxtaConfigModel.PROPERTY_NAME), true);
		description = BasicComponentFactory.createTextArea(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_DESCRIPTION), true);
		tcpEnabled = BasicComponentFactory.createCheckBox(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_TCP_ENABLED), "");
		tcpIncoming = BasicComponentFactory.createCheckBox(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_TCP_INCOMING), "");
		tcpOutgoing = BasicComponentFactory.createCheckBox(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_TCP_OUTGOING), "");
		tcpPort = BasicComponentFactory.createIntegerField(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_TCP_PORT), portFormat);
		tcpStartPort = BasicComponentFactory.createIntegerField(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_TCP_START_PORT), portFormat);
		tcpEndPort = BasicComponentFactory.createIntegerField(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_TCP_END_PORT), portFormat);
		tcpInterfaceAddress = BasicComponentFactory.createTextField(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_TCP_INTERFACE_ADDRESS), true);
		tcpPublicAddress = BasicComponentFactory.createTextField(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_TCP_PUBLIC_ADDRESS), true);
		tcpPublicAddressExclusive = BasicComponentFactory.createCheckBox(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_TCP_PUBLIC_ADDRESS_EXCLUSIVE), "");
		useMulticast = BasicComponentFactory.createCheckBox(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_USE_MULTICAST), "");
		multicastAddress = BasicComponentFactory.createTextField(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_MULTICAST_ADDRESS), true);
		multicastPort = BasicComponentFactory.createIntegerField(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_MULTICAST_PORT), portFormat);
		multicastSize = BasicComponentFactory.createIntegerField(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_MULTICAST_SIZE), mcastSizeFormat);
		httpEnabled = BasicComponentFactory.createCheckBox(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_HTTP_ENABLED), "");
		httpIncoming = BasicComponentFactory.createCheckBox(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_HTTP_INCOMING), "");
		httpOutgoing = BasicComponentFactory.createCheckBox(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_HTTP_OUTGOING), "");
		httpPort = BasicComponentFactory.createIntegerField(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_HTTP_PORT), portFormat);
		httpPublicAddress = BasicComponentFactory.createTextField(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_HTTP_PUBLIC_ADDRESS), true);
		httpPublicAddressExclusive = BasicComponentFactory.createCheckBox(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_HTTP_PUBLIC_ADDRESS_EXCLUSIVE), "");
		httpInterfaceAddress = BasicComponentFactory.createTextField(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_HTTP_INTERFACE_ADDRESS), true);
		relayEnabled = BasicComponentFactory.createCheckBox(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_RELAY_ENABLED), "");
		relayServer = BasicComponentFactory.createCheckBox(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_RELAY_SERVER), "");
		relayClient = BasicComponentFactory.createCheckBox(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_RELAY_CLIENT), "");
		relayMaxClients = BasicComponentFactory.createIntegerField(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_RELAY_MAX_CLIENTS), maxClientsFormat);
		useOnlyRelaySeeds = BasicComponentFactory.createCheckBox(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_USE_ONLY_RELAY_SEEDS), "");
		rendezvousEnabled = BasicComponentFactory.createCheckBox(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_RENDEZVOUS_ENABLED), "");
		rendezvousMaxClients = BasicComponentFactory.createIntegerField(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_RENDEZVOUS_MAX_CLIENTS), maxClientsFormat);
		useOnlyRendezvousSeeds = BasicComponentFactory.createCheckBox(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_USE_ONLY_RENDEZVOUS_SEEDS), "");
		principal = BasicComponentFactory.createTextField(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_PRINCIPAL), true);
		password = BasicComponentFactory.createPasswordField(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_PASSWORD), true);
		proxyEnabled = BasicComponentFactory.createCheckBox(presentationModel
				.getModel(JxtaConfigModel.PROPERTY_PROXY_ENABLED), "");

		// add special behavior
		description.setLineWrap(true);
		description.setWrapStyleWord(true);
	}

	private void buildLeftPanel(CellConstraints cc, FormLayout layout, PanelBuilder builder) {
		int labelCol = 1;
		int compCol = 3;

		// Default Settings
		builder.addSeparator(CommonMessages.getMessage("JxtaConfig.Prop.Header.General"), cc.xyw(labelCol, builder
				.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.name"), cc.xy(labelCol, builder.getRow()));
		builder.add(name, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.description"), cc.xywh(labelCol, builder.getRow(),
				1, 1));
		builder.add(new JScrollPane(description), cc.xywh(compCol, builder.getRow(), 1, 5, "fill, fill"));
		builder.nextRow(5);

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.principal"), cc.xy(labelCol, builder.getRow()));
		builder.add(principal, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.password"), cc.xy(labelCol, builder.getRow()));
		builder.add(password, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.proxyEnabled"), cc.xy(labelCol, builder.getRow()));
		builder.add(proxyEnabled, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		// Relay and Rendezvous Settings
		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addSeparator(CommonMessages.getMessage("JxtaConfig.Prop.Header.Relay"), cc.xyw(labelCol, builder
				.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.relayEnabled"), cc.xy(labelCol, builder.getRow()));
		builder.add(relayEnabled, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.relayServer"), cc.xy(labelCol, builder.getRow()));
		builder.add(relayServer, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.relayClient"), cc.xy(labelCol, builder.getRow()));
		builder.add(relayClient, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.useOnlyRelaySeeds"), cc.xy(labelCol, builder
				.getRow()));
		builder.add(useOnlyRelaySeeds, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.relayMaxClients"), cc
				.xy(labelCol, builder.getRow()));
		builder.add(relayMaxClients, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.rendezvousEnabled"), cc.xy(labelCol, builder
				.getRow()));
		builder.add(rendezvousEnabled, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.useOnlyRendezvousSeeds"), cc.xy(labelCol, builder
				.getRow()));
		builder.add(useOnlyRendezvousSeeds, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.rendezvousMaxClients"), cc.xy(labelCol, builder
				.getRow()));
		builder.add(rendezvousMaxClients, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		// Multicast Settings
		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addSeparator(CommonMessages.getMessage("JxtaConfig.Prop.Header.Multicast"), cc.xyw(labelCol, builder
				.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.useMulticast"), cc.xy(labelCol, builder.getRow()));
		builder.add(useMulticast, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.multicastAddress"), cc.xy(labelCol, builder
				.getRow()));
		builder.add(multicastAddress, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.multicastPort"), cc.xy(labelCol, builder.getRow()));
		builder.add(multicastPort, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.multicastSize"), cc.xy(labelCol, builder.getRow()));
		builder.add(multicastSize, cc.xy(compCol, builder.getRow()));
	}

	private void buildRightPanel(CellConstraints cc, FormLayout layout, PanelBuilder builder) {
		int labelCol = 5;
		int compCol = 7;

		// TCP Settings
		builder.setRow(1);

		builder.addSeparator(CommonMessages.getMessage("JxtaConfig.Prop.Header.Tcp"), cc.xyw(labelCol,
				builder.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.tcpEnabled"), cc.xy(labelCol, builder.getRow()));
		builder.add(tcpEnabled, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.tcpIncoming"), cc.xy(labelCol, builder.getRow()));
		builder.add(tcpIncoming, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.tcpOutgoing"), cc.xy(labelCol, builder.getRow()));
		builder.add(tcpOutgoing, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.tcpPort"), cc.xy(labelCol, builder.getRow()));
		builder.add(tcpPort, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.tcpStartPort"), cc.xy(labelCol, builder.getRow()));
		builder.add(tcpStartPort, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.tcpEndPort"), cc.xy(labelCol, builder.getRow()));
		builder.add(tcpEndPort, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.tcpInterfaceAddress"), cc.xy(labelCol, builder
				.getRow()));
		builder.add(tcpInterfaceAddress, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.tcpPublicAddress"), cc.xy(labelCol, builder
				.getRow()));
		builder.add(tcpPublicAddress, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.tcpPublicAddressExclusive"), cc.xy(labelCol,
				builder.getRow()));
		builder.add(tcpPublicAddressExclusive, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		// HTTP Settings
		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addSeparator(CommonMessages.getMessage("JxtaConfig.Prop.Header.Http"), cc.xyw(labelCol, builder
				.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.httpEnabled"), cc.xy(labelCol, builder.getRow()));
		builder.add(httpEnabled, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.httpIncoming"), cc.xy(labelCol, builder.getRow()));
		builder.add(httpIncoming, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.httpOutgoing"), cc.xy(labelCol, builder.getRow()));
		builder.add(httpOutgoing, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.httpPort"), cc.xy(labelCol, builder.getRow()));
		builder.add(httpPort, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.httpInterfaceAddress"), cc.xy(labelCol, builder
				.getRow()));
		builder.add(httpInterfaceAddress, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.httpPublicAddress"), cc.xy(labelCol, builder
				.getRow()));
		builder.add(httpPublicAddress, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("JxtaConfig.Prop.httpPublicAddressExclusive"), cc.xy(labelCol,
				builder.getRow()));
		builder.add(httpPublicAddressExclusive, cc.xy(compCol, builder.getRow()));
	}
}
