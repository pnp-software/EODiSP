/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com
 *  mail: info@pnp-software.com
 */
package org.eodisp.ui.common.actions;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;

/**
 * An EodispAction extends the {@link javax.swing.AbstractAction} to be used by
 * the EODiSP framework. It adds some functionality needed by the framework.
 * More specifically, it specifies if an EodispAction should be used in the menu
 * bar, in the tool bar, or in the context menu (or any combination of those).
 * <p>
 * It also has the functionality to add a target handler to the action. The
 * target handler is responsible to handle the
 * {@link #actionPerformed(ActionEvent)} event. Usually, this will be a
 * controller which takes the responsibility to react to an action.
 * <p>
 * Registering a controller as a target handler can be done through the use of
 * the delegation mechanism provided by the
 * {@link org.eodisp.ui.common.base.EodispDelegate} class.
 * 
 * @author eglimi
 * @version $Id:EodispAction.java 2134 2006-05-16 08:43:27Z eglimi $
 */
public class EodispAction extends AbstractAction {

	/**
	 * Default Serial Version ID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 * An additional user object.
	 */
	public static final String USER_OBJECT = "userObject";

	/**
	 * This is the name of a dedicated sub-menu for a list of menu item.
	 */
	public static final String CTX_GROUP_SUBMENU = "ctxGroupSubmenu";

	/**
	 * This is the name of a context group. A context group is a section within
	 * a <code>JMenu</code> that is separated by a <code>JSeparator</code>.
	 * The menu item will <strong>not</strong> be placed in a dedicated
	 * sub-menu when using this value.
	 */
	public static final String CTX_GROUP = "ctxGroup";

	/**
	 * Holds the target handler which is responsible for handling the events
	 * (i.e. if an action is performed). See
	 * {@link #actionPerformed(ActionEvent)}. Such a target handler should be
	 * an instance of the class {@link org.eodisp.ui.common.base.EodispDelegate}.
	 */
	protected ActionListener targetHandler = null;

	/**
	 * This enables or disables the action to show in a MenuBar. As a result, a
	 * {@link javax.swing.JMenuItem} will be created to represent this action.
	 * This can also be changed at runtime, to enable/disable certain features
	 * 'on-the-fly'.
	 */
	private boolean showInMenuBar = true;

	/**
	 * This enables or disables the action to show in the ToolBar. As a result,
	 * an appropriate Component in the {@link javax.swing.JToolBar} will be
	 * created to represent this action. This can also be changed at runtime, to
	 * enable/disable certain features 'on-the-fly'.
	 */
	private boolean showInToolBar = false;

	/**
	 * This enables or disables the action to show in a context menu. As a
	 * result, a context menu will be created to represent this action. This can
	 * also be changed at runtime, to enable/disable certain features
	 * 'on-the-fly'.
	 */
	private boolean showInContextMenu = false;

	/**
	 * This holds the name of the parent menu. In order to allow sub-menus, this
	 * string can be constructed with a "/" between the names of the menus. For
	 * example, if you want to construct a menu called "File" with a sub-menu
	 * called "Open", you can specify it with the following string:
	 * <p>
	 * <code>
	 * setTopMenuItemName("File/Open");
	 * </code> There is no restriction
	 * in how deep the hierarchy can grow. Bear in mind that a lot of sub-menus
	 * makes a menu confusing.
	 * <p>
	 * The default Menu if no String is given is "File". Do not rely on this
	 * default, since it makes the structure confusing as well;
	 */
	private String topMenuItemName = "File";

	/**
	 * The index of the action when used in the menu bar. This can be used to
	 * sort the entries within a menu bar. A smaller index will be placed on top
	 * of the greater number in within a container (i.e. a menu or a sub-menu
	 * respectively).
	 * <p>
	 * The default value uses the default sorting method of the
	 * {@link javax.swing.JMenuBar} class.
	 */
	private int menuIndex = -1;

	/**
	 * The index of the action when used in the tool bar. This can be used to
	 * sort the entries. A smaller index will be placed left of the greater
	 * number within a container.
	 * <p>
	 * The default value uses the default sorting method of the
	 * {@link javax.swing.JToolBar} class.
	 */
	private int toolBarIndex = -1;

	/**
	 * Tells the menu whether it should be created with a checkbox. This can be
	 * useful to represent boolean (enable/disable) features. Default is not to
	 * use a checkbox.
	 */
	private boolean isCheckBox = false;

	/**
	 * Tells the action whether the checkbox should be enabled or disabled by
	 * default. The default is to enable a checkbox at startup.
	 */
	private boolean checkBoxEnabled = true;

	/**
	 * Holds an optional field for an action source handler. This can be a view
	 * or a frame that is responsible for registering this action.
	 * <p>
	 * This information can be use to clear all actions defined for such a
	 * component. This can happen if the component is disposed or if the if it
	 * uses dynamic action entries.
	 */
	private Class<? extends ActionSourceProvider> actionSource = null;

	/**
	 * Holds a value indication whether the action has already been process.
	 */
	private boolean isProcessed = false;

	/**
	 * Indicates that an action is always selected and can never be disabled.
	 * This should be set for common menu entries such as exit, etc.
	 */
	private boolean isAlwaysSelected = false;

	/**
	 * This is the icon that will be used in the tool bar. Default is to not use
	 * an icon.
	 */
	private ImageIcon toolBarIcon = null;

	/**
	 * This distributes the event. There is either a targetHandler attached to
	 * this action, or the event will be distributed to all listeners by the
	 * {@link EodispActionRegistry}. The first is the preferred way, the second
	 * the more natural way for dynamic actions. Also, the second approach
	 * (distributing the event), is only available for dynamic actions.
	 * <p>
	 * {@inheritDoc}
	 */
	public void actionPerformed(ActionEvent e) {
		if (targetHandler != null) {
			targetHandler.actionPerformed(e);
		}
	}

	/**
	 * Registers a target handler. This should be an instance of
	 * {@link org.eodisp.ui.common.base.EodispDelegate}. The target class in
	 * this defined in this instance will be responsible to execute appropriate
	 * code when an action is performed.
	 * 
	 * @param l
	 *            The target handler which is responsible to handle the event.
	 */
	public void registerTargetHandler(ActionListener l) {
		if (l != null) {
			targetHandler = l;
		}
	}

	/**
	 * Returns whether or not this action should be showed as an entry in the
	 * context menu. The default is 'false'.
	 * 
	 * @return True, if the action is shown in the context menu or false, if it
	 *         should be omitted.
	 */
	public boolean isShowInContextMenu() {
		return showInContextMenu;
	}

	/**
	 * Specifies whether this action should be showed as an entry in the menu
	 * bar.
	 * 
	 * @param showInContextMenu
	 *            Used to set the visibility in the context menu.
	 */
	public void setShowInContextMenu(boolean showInContextMenu) {
		this.showInContextMenu = showInContextMenu;
	}

	/**
	 * Returns whether or not this action should be showed as an entry in the
	 * menu bar. The default is 'true'.
	 * 
	 * @return True, if the action is shown in the menu bar or false, if it
	 *         should be omitted.
	 */
	public boolean isShowInMenuBar() {
		return showInMenuBar;
	}

	/**
	 * Specifies whether this action should be showed as an entry in the menu
	 * bar.
	 * <p>
	 * The default value is true.
	 * 
	 * @param showInMenuBar
	 *            Used to set the visibility in the menu bar.
	 */
	public void setShowInMenuBar(boolean showInMenuBar) {
		this.showInMenuBar = showInMenuBar;
	}

	/**
	 * Returns whether or not this action should be showed as an entry in the
	 * tool bar. The default is 'false'.
	 * <p>
	 * The default value is false.
	 * 
	 * @return True, if the action is shown in the tool bar or false, if it
	 *         should be omitted.
	 */
	public boolean isShowInToolBar() {
		return showInToolBar;
	}

	/**
	 * Specifies whether this action should be showed as an entry in the tool
	 * bar.
	 * <p>
	 * Remember to specify an icon for the action if you set this to true.
	 * <p>
	 * The default value is false.
	 * 
	 * @param showInToolBar
	 *            Used to set the visibility in the tool bar.
	 */
	public void setShowInToolBar(boolean showInToolBar) {
		this.showInToolBar = showInToolBar;
	}

	/**
	 * Return the value of the index of this action. This is only useful for
	 * displaying the action as an item in the menu bar. You should not be using
	 * this method, since the ordering of the menu items in the menu bar is done
	 * automatically.
	 * 
	 * @return The value of the index.
	 */
	public int getMenuIndex() {
		return menuIndex;
	}

	/**
	 * Changes the value of the index in the menu bar for this action. This
	 * possibly resorts the items in the menu bar.
	 * 
	 * @param menuIndex
	 */
	public void setMenuIndex(int menuIndex) {
		this.menuIndex = menuIndex;
	}

	/**
	 * Returns the name of the parent menu as a string.
	 * 
	 * @return The name of the parent menu as String.
	 */
	public String getTopMenuItemName() {
		return topMenuItemName;
	}

	/**
	 * Sets the name of the parent menu. See {@link #topMenuItemName} for
	 * further explanation how the name can be constructed (especially for
	 * sub-menus).
	 * <p>
	 * This is only useful if this action should be displayed in the menu bar.
	 * 
	 * @param topMenuItemName
	 *            The name of the parent menu. If this action should be shown in
	 *            the menu bar, it will be a child item of the top menu bar.
	 */
	public void setTopMenuItemName(String topMenuItemName) {
		this.topMenuItemName = topMenuItemName;
	}

	/**
	 * @return Returns the enableCheckBox.
	 */
	public boolean isCheckBox() {
		return isCheckBox;
	}

	/**
	 * Sets the isCheckBox flag. If this flag is set, the item will be shown as
	 * check box.
	 * 
	 * @param isCheckBox
	 *            The enableCheckBox to set.
	 */
	public void setCheckBox(boolean isCheckBox) {
		this.isCheckBox = isCheckBox;
	}

	/**
	 * @return Returns the checkBoxEnabled.
	 */
	public boolean isCheckBoxEnabled() {
		return checkBoxEnabled;
	}

	/**
	 * Toggles the initial state of a checkbox enabled action.
	 * 
	 * @param checkBoxEnabled
	 *            The checkBoxEnabled to set. If true, the initial state of the
	 *            checkbox will be enabled, if false, the initial state of will
	 *            be disabled.
	 */
	public void setCheckBoxEnabled(boolean checkBoxEnabled) {
		this.checkBoxEnabled = checkBoxEnabled;
	}

	/**
	 * Returns the action source for this action.
	 * <p>
	 * This information can be use to clear all actions defined for such a
	 * component. This can happen if the component is disposed or if the if it
	 * uses dynamic action entries.
	 * 
	 * @param actionSource
	 *            The action source for this action.
	 */
	public Class<? extends ActionSourceProvider> getActionSource() {
		return actionSource;
	}

	/**
	 * Sets the action source for this action. This should be either a
	 * <code>EodispView</code> or a <code>EodispFrame</code>. It is the
	 * component which is responsible for registering this action.
	 * 
	 * @return the action source for this action or null, if no action source
	 *         has been attached to this action.
	 */
	public <T extends ActionSourceProvider> void setActionSource(Class<T> actionSource) {
		this.actionSource = actionSource;
	}

	/**
	 * Return whether the action has already been processed. This can be used to
	 * dynamically update actions in the menu bar, tool bar and context menu. If
	 * an action is dynamically added, we just process it if it was not
	 * processed before.
	 * 
	 * @return Returns the isProcessed.
	 */
	public boolean isProcessed() {
		return isProcessed;
	}

	/**
	 * Sets whether the action has been processed by the action manager. If set
	 * to true, future requests to process it will be ignored.
	 * 
	 * @param isProcessed
	 *            True, if the action has been processed.
	 */
	public void setProcessed(boolean isProcessed) {
		this.isProcessed = isProcessed;
	}

	/**
	 * @return Returns the isAlwaysSelected.
	 */
	public boolean isAlwaysSelected() {
		return isAlwaysSelected;
	}

	/**
	 * This can be set to indicate that an action cannot be disabled.
	 * 
	 * @param isAlwaysSelected
	 *            The isAlwaysSelected to set.
	 */
	public void setAlwaysSelected(boolean isAlwaysSelected) {
		this.isAlwaysSelected = isAlwaysSelected;
	}

	/**
	 * @return Returns the toolBarIcon.
	 */
	public ImageIcon getToolBarIcon() {
		return toolBarIcon;
	}

	/**
	 * @param toolBarIcon
	 *            The toolBarIcon to set.
	 */
	public void setToolBarIcon(ImageIcon toolBarIcon) {
		this.toolBarIcon = toolBarIcon;
	}

	/**
	 * @return Returns the toolBarIndex.
	 */
	public int getToolBarIndex() {
		return toolBarIndex;
	}

	/**
	 * @param toolBarIndex
	 *            The toolBarIndex to set.
	 */
	public void setToolBarIndex(int toolBarIndex) {
		this.toolBarIndex = toolBarIndex;
	}
}
