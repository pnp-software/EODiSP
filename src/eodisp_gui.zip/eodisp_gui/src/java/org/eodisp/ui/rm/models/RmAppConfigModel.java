/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.rm.models;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.eodisp.ui.common.components.AbstractEodispModel;
import org.eodisp.ui.rm.config.RmGuiConfiguration;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.configuration.Configuration;

/**
 * This is the model for the application settings panel for the model manager
 * application.
 * 
 * @author eglimi
 * @version $Id:$
 * 
 */
public class RmAppConfigModel extends AbstractEodispModel {
	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(RmAppConfigModel.class);

	/**
	 * The configuration that is represented by this model.
	 */
	private final Configuration configuration = AppRegistry.getRootApp().getConfiguration(RmGuiConfiguration.ID);

	/**
	 * Default constructor.
	 * 
	 */
	public RmAppConfigModel() {
	}

	/**
	 * 
	 * {@inheritDoc}
	 */
	public void doSave() throws IOException {
		configuration.save();
	}

	/**
	 * 
	 * {@inheritDoc}
	 */
	@Override
	public void undo() {
		try {
			configuration.load();
		} catch (IOException e) {
			logger.error("Could not reset the configuration by reloading it.", e);
		}
	}

	/**
	 * 
	 * {@inheritDoc}
	 */
	public boolean hasChanges() {
		return configuration.needsSave();
	}

	/**
	 * Returns the configuration object.
	 * 
	 * @return The configuration object.
	 */
	public Configuration getConfigurator() {
		return configuration;
	}
}
