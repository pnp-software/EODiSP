/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.common.base;

import org.eodisp.util.configuration.Configuration;

/**
 * This interface specifies a set of methods that each configuration for a UI
 * application in the EODiSP framework should implement.
 * 
 * @author eglimi
 * @version $Id:$
 * 
 */
public interface UiConfiguration extends Configuration {

	/**
	 * <p>
	 * Returns the path to the file as string that will hold the state of the
	 * root window. This file can be used to store and restore the layout of the
	 * views.
	 * </p>
	 * <p>
	 * Note that the path is not resolved whatsoever. You need to ensure that
	 * the path is correct. Most probably by creating a file like:
	 * </p>
	 * 
	 * <pre>
	 * File file = new File(RootApp.getConfigurationDir(), UiConfiguration.getViewStateEntry());
	 * </pre>
	 * 
	 * @return The file used to store the layout of the root window.
	 */
	String getViewStateEntry();

	/**
	 * Sets the file that will store the state of the root window.
	 * 
	 * @param file
	 *            The path to the file as String that will store the state of
	 *            the root window.
	 */
	void setViewStateEntry(String file);
}
