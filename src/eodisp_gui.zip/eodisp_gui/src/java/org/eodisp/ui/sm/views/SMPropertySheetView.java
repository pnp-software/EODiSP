/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.sm.views;

import java.awt.Component;

import javax.swing.JScrollPane;
import javax.swing.JTable;

import org.eodisp.ui.common.actions.ActionSourceProvider;
import org.eodisp.ui.common.base.EodispView;
import org.eodisp.ui.sm.models.SMPropertySheetModel;
import org.eodisp.ui.sm.resources.SmResources;

/**
 * This is the view for the simulation manager application that will display the
 * properties of an simulation manager project item. The properties will be
 * displayed in a table with one row for each property.
 * 
 * @author eglimi
 * @version $Id:SMPropertySheetView.java 1941 2006-04-21 11:30:46Z eglimi $
 */
public class SMPropertySheetView extends EodispView implements ActionSourceProvider {

	private static final String TITLE = SmResources.getMessage("SmPropertySheet.View.Title");

	public static final int ID = 20;

	private final JTable table = new JTable();

	private final JScrollPane scrollPane = new JScrollPane();

	/**
	 * Default constructor.
	 */
	public SMPropertySheetView() {
		super();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void initializeComponents() {
		table.setModel(getPropertySheetModel());

		scrollPane.setViewportView(table);

		setComponent(getInternalComponent());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eodisp.ui.common.base.EodispView#getTitle()
	 */
	@Override
	public String getTitle() {
		return TITLE;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getId() {
		return ID;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Component getInternalComponent() {
		return scrollPane;
	}

	/**
	 * {@inheritDoc}
	 */
	public void registerActions() {
	}

	/**
	 * Returns the model of this view.
	 * 
	 * @return The currently set model of this view.
	 */
	private SMPropertySheetModel getPropertySheetModel() {
		return (SMPropertySheetModel) super.getModel();
	}

	public void updateRegistrations() {
		// TODO Auto-generated method stub
	}
}
