/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.mm.views;

import javax.swing.*;

import org.apache.log4j.Logger;
import org.eodisp.core.mm.config.MmConfiguration;
import org.eodisp.ui.common.base.EodispModel;
import org.eodisp.ui.common.binding.ConfigAdapter;
import org.eodisp.ui.common.components.AbstractConfigPanel;
import org.eodisp.ui.mm.models.MmAppConfigModel;
import org.eodisp.ui.mm.resources.MmResources;
import org.eodisp.util.configuration.Configuration;

import com.jgoodies.binding.adapter.BasicComponentFactory;
import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.factories.FormFactory;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

/**
 * This is a panel to configure the general settings for the application.
 * 
 * @author eglimi
 * @version $Id:$
 * 
 */
public class MmAppConfig extends AbstractConfigPanel {

	/**
	 * Default serial version id
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(MmAppConfig.class);

	private JPanel configPanel;

	private JTextField appName;

	private JTextArea appDescription;

	private JTextField appId; // read-only

	private JTextField appOwnerFirstname;

	private JTextField appOwnerSurname;

	private JTextField appOwnerTel;

	private JTextField appOwnerCountry;

	private JTextField appOwnerMail;

	private JTextField customField1;

	private JTextField customField2;

	private JTextField customField3;

	private JTextField reposUri;
	
	private JTextField lrcLogLevel;

	/**
	 * Default constructor.
	 * 
	 * @param model
	 *            The model to be used for this panel.
	 */
	public MmAppConfig(EodispModel model) {
		super(model);

		CellConstraints cc = new CellConstraints();
		FormLayout layout = new FormLayout(
				"right:pref, 4dlu, 75dlu:grow",
				"p, 3dlu, p, 3dlu, 50dlu, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p");
		PanelBuilder builder = new PanelBuilder(layout);
		builder.setDefaultDialogBorder();

		initializeComponents();

		buildPanel(cc, layout, builder);
		configPanel = builder.getPanel();
	}

	/**
	 * {@inheritDoc}
	 */
	public JPanel getPanel() {
		return configPanel;
	}

	/**
	 * Does all the initialization of the components.
	 * 
	 */
	private void initializeComponents() {
		Configuration config = ((MmAppConfigModel) getModel()).getConfigurator();

		// create components
		appName = BasicComponentFactory.createTextField(new ConfigAdapter(config, MmConfiguration.APP_NAME), true);
		appDescription = BasicComponentFactory.createTextArea(
				new ConfigAdapter(config, MmConfiguration.APP_DESCRIPTION), true);
		appId = BasicComponentFactory.createTextField(new ConfigAdapter(config, MmConfiguration.APP_ID), true);
		appId.setEditable(false);
		appOwnerFirstname = BasicComponentFactory.createTextField(new ConfigAdapter(config,
				MmConfiguration.APP_OWNER_FIRSTNAME), true);
		appOwnerSurname = BasicComponentFactory.createTextField(new ConfigAdapter(config,
				MmConfiguration.APP_OWNER_SURNAME), true);
		appOwnerMail = BasicComponentFactory.createTextField(new ConfigAdapter(config, MmConfiguration.APP_OWNER_MAIL),
				true);
		appOwnerTel = BasicComponentFactory.createTextField(new ConfigAdapter(config, MmConfiguration.APP_OWNER_TEL),
				true);
		appOwnerCountry = BasicComponentFactory.createTextField(new ConfigAdapter(config,
				MmConfiguration.APP_OWNER_COUNTRY), true);
		customField1 = BasicComponentFactory.createTextField(new ConfigAdapter(config,
				MmConfiguration.APP_OWNER_CUSTOM_1), true);
		customField2 = BasicComponentFactory.createTextField(new ConfigAdapter(config,
				MmConfiguration.APP_OWNER_CUSTOM_2), true);
		customField3 = BasicComponentFactory.createTextField(new ConfigAdapter(config,
				MmConfiguration.APP_OWNER_CUSTOM_3), true);
		reposUri = BasicComponentFactory.createTextField(new ConfigAdapter(config, MmConfiguration.REPOS_URI), true);
		lrcLogLevel = BasicComponentFactory.createTextField(new ConfigAdapter(config, MmConfiguration.EODISP_LRC_LOG_LEVEL), true);

		// specific behaviour
		appDescription.setLineWrap(true);
		appDescription.setWrapStyleWord(true);
	}

	/**
	 * Builds the complete panel.
	 * 
	 * @param cc
	 *            The cell constraints.
	 * @param layout
	 *            The layout.
	 * @param builder
	 *            The builder that is used to build the panel.
	 */
	private void buildPanel(CellConstraints cc, FormLayout layout, PanelBuilder builder) {
		int labelCol = 1;
		int compCol = 3;

		builder.setRow(1);

		// Application Settings
		builder.addSeparator(MmResources.getMessage("MmAppConfig.Prop.Header.App"), cc.xyw(labelCol, builder.getRow(),
				3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(MmResources.getMessage("MmAppConfig.Prop.AppName"), cc.xy(labelCol, builder.getRow()));
		builder.add(appName, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(MmResources.getMessage("MmAppConfig.Prop.AppDescription"), cc.xy(labelCol, builder.getRow()));
		builder.add(new JScrollPane(appDescription), cc.xy(compCol, builder.getRow(), "fill, fill"));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(MmResources.getMessage("MmAppConfig.Prop.AppId"), cc.xy(labelCol, builder.getRow()));
		builder.add(appId, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		// Application Owner Settings
		builder.addSeparator(MmResources.getMessage("MmAppConfig.Prop.Header.AppOwner"), cc.xyw(labelCol, builder
				.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(MmResources.getMessage("MmAppConfig.Prop.AppOwnerFirstname"), cc
				.xy(labelCol, builder.getRow()));
		builder.add(appOwnerFirstname, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(MmResources.getMessage("MmAppConfig.Prop.AppOwnerSurname"), cc.xy(labelCol, builder.getRow()));
		builder.add(appOwnerSurname, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(MmResources.getMessage("MmAppConfig.Prop.AppOwnerMail"), cc.xy(labelCol, builder.getRow()));
		builder.add(appOwnerMail, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(MmResources.getMessage("MmAppConfig.Prop.AppOwnerTel"), cc.xy(labelCol, builder.getRow()));
		builder.add(appOwnerTel, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(MmResources.getMessage("MmAppConfig.Prop.AppOwnerCountry"), cc.xy(labelCol, builder.getRow()));
		builder.add(appOwnerCountry, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(MmResources.getMessage("MmAppConfig.Prop.CustomField1"), cc.xy(labelCol, builder.getRow()));
		builder.add(customField1, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(MmResources.getMessage("MmAppConfig.Prop.CustomField2"), cc.xy(labelCol, builder.getRow()));
		builder.add(customField2, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(MmResources.getMessage("MmAppConfig.Prop.CustomField3"), cc.xy(labelCol, builder.getRow()));
		builder.add(customField3, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();
		
		// LRC Log Settings
		builder.addSeparator(MmResources.getMessage("MmAppConfig.Prop.Header.LogSettings"), cc.xyw(labelCol, builder
				.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(MmResources.getMessage("MmAppConfig.Prop.LrcLogLevel"), cc.xy(labelCol, builder.getRow()));
		builder.add(lrcLogLevel, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		// Repository Settings
		builder.addSeparator(MmResources.getMessage("MmAppConfig.Prop.Header.ReposSettings"), cc.xyw(labelCol, builder
				.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(MmResources.getMessage("MmAppConfig.Prop.ReposUri"), cc.xy(labelCol, builder.getRow()));
		builder.add(reposUri, cc.xy(compCol, builder.getRow()));
	}
}
