/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com
 *  mail: info@pnp-software.com
 */
package org.eodisp.ui.common.base;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JToolBar;

import net.infonode.docking.RootWindow;

import org.eodisp.ui.common.actions.ActionSourceProvider;
import org.eodisp.ui.common.actions.EodispMenuManager;

/**
 * The main frame of an application is the container for all other frames. It
 * holds the main menu bar and the tool bar and embeds all other frames.
 * <p>
 * The connection between the EodispMainFrame and Swing is, that the
 * EodispMainFrame actually extends the Swing top container
 * {@link javax.swing.JFrame}. This might be a bit confusing, since the EODiSP
 * also uses {@link org.eodisp.ui.common.base.EodispFrame}s. This frames,
 * however, are not connected with any Swing top container component. See the
 * documentation for further information. Therefore, it must be clearly
 * distinguished between the main frame and an ordinary frame, because the
 * former is a Swing top level container, whereas the latter is a construct used
 * only in the EODiSP framework.
 * <p>
 * The main frame is responsible for the layout of all embedded frames, views,
 * and other components. This must be implemented in the specific main frame for
 * an application. It also provides some functions to show the application and
 * place it on the screen as appropriate. Generally speaking, the main frame is
 * the frame around the whole application and is responsible for handling the
 * obvious tasks such as showing the application, handling menu and tool bar.
 * <p>
 * Since a main frame has always some menu bar items (such as Exit, etc.), it
 * also implements the <code>ActionSourceProvider</code>. However, the actual
 * implementation is left to the application specific main frame.
 * <p>
 * This class should be sub-classed by a specific main frame implementation to
 * provide the implementation of the abstract methods. Every application should
 * have exactly one main frame.
 * 
 * @author eglimi
 * @version $Id:EodispMainFrame.java 2047 2006-05-09 12:20:54Z eglimi $
 */
public abstract class EodispMainFrame extends JFrame implements ActionSourceProvider {

	/**
	 * Holds the main panel on which all components of the application are
	 * placed.
	 */
	private final JPanel mainPanel = new JPanel(new BorderLayout(), true);

	/**
	 * Default constructor. Should only be instantiated from sub-classes.
	 */
	protected EodispMainFrame() {
		setContentPane(mainPanel);

		setBehaviour();

		registerActions();
	}

	/**
	 * @see org.eodisp.ui.common.actions.ActionSourceProvider#registerActions()
	 */
	public abstract void registerActions();

	/**
	 * Updates the title of the main frame. The default string is defined by the
	 * main frame itself. In addition, a list of strings can be given. These
	 * strings will be appended to the title.
	 * <p>
	 * For example, given a list of the following strings as parameter
	 * <ul>
	 * <li>Locale: en</li>
	 * <li>User: Ursula</li>
	 * </ul>
	 * <p>
	 * The title would look like
	 * 
	 * <pre>
	 *    Main Title - Locale: en - User: Ursula
	 * </pre>
	 * 
	 * @param strings
	 *            A list of strings to be appended to the title of the main
	 *            frame, or no parameter, if the default title should be
	 *            displayed.
	 */
	public abstract void updateTitle(String... strings);

	/**
	 * Shows the main frame on the screen.All components should be built and
	 * included in the main frame before showing it. The application controller
	 * is responsible to delegate all initialization to other controller before
	 * it asks the main frame to show itself on the screen.
	 */
	public void showMainFrame() {
		setContentPane(mainPanel);
		pack();
		setSize(new Dimension(1000, 700));
		UIUtil.locateOnScreen(this);
		setVisible(true);
	}

	/**
	 * Sets the menu bar for this application. The menu bar is referenced
	 * directly by the main frame of the application.
	 * <p>
	 * Creation of the menu bar is done by the {@link EodispMenuManager} class.
	 * It will return the complete menu bar, ready to be included in the main
	 * frame.
	 * <p>
	 * Prior to calling this method, all frames and views that contribute to the
	 * menu or tool bar, should have registered their actions in the
	 * <code>EodispActionRegistry</code>.
	 * <p>
	 * This method should only be called before showing the main frame on the
	 * screen. Tool bar items that are added dynamically at runtime are directly
	 * handled by the <code>EodispMenuManager</code>.
	 */
	public void addMenuBar() {
		setJMenuBar(EodispMenuManager.getInstance().getMenuBar());
	}

	/**
	 * Sets the tool bar for this application. The tool bar resides on the main
	 * panel and its default location is not (top, just under the menu bar). An
	 * empty tool bar will be displayed if no items are present. This is because
	 * items can be added to the tool bar during runtime. However, the tool bar
	 * will be invisible if no items are present. Creation of the tool bar is
	 * done by the {@link EodispMenuManager} class. It will return the complete
	 * tool bar, ready to be included in the main frame.
	 * <p>
	 * Prior to calling this method, all frames and views that contribute to the
	 * menu or tool bar, should have registered their actions in the
	 * <code>EodispActionRegistry</code>.
	 * <p>
	 * This method should only be called before showing the main frame on the
	 * screen. Tool bar items that are added dynamically at runtime are directly
	 * handled by the <code>EodispMenuManager</code>.
	 */
	public void addToolBar() {
		JToolBar tmpToolBar = EodispMenuManager.getInstance().getToolBar();

		mainPanel.add(tmpToolBar, BorderLayout.PAGE_START);

		tmpToolBar.setVisible(isToolBarVisible(tmpToolBar));
		tmpToolBar.repaint();
	}

	/**
	 * Adds the root window to the main frame. The root window will contain all
	 * views of the application and is therefore, the content panel for all
	 * components, except for the tool bar.
	 * <p>
	 * The root window is placed in the center of the main panel.
	 * 
	 * @param rootWindow
	 */
	public void addRootWindow(RootWindow rootWindow) {

		if (rootWindow != null) {
			mainPanel.add(rootWindow, BorderLayout.CENTER);
		}
	}

	/**
	 * Sets specific behaviour such as layout or size for this frame. This is
	 * the standard behaviour of an EODiSP application, but it can be overridden
	 * by sub-classes.
	 * <p>
	 * Not that the default close operation is to do nothing. This means that
	 * concrete applications must take care of shutting down an application
	 * properly. This means, releasing <it>all</it> resources and exit the
	 * application.
	 */
	protected void setBehaviour() {
		setLayout(new BorderLayout());

		// we don't want to exit here, since it should be handled by the
		// application itself.
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
	}

	/**
	 * This adds a dynamic view to the main frame. It should be placed in a
	 * appropriate place.
	 * 
	 * @param dynView
	 *            The view to be added.
	 */
	public abstract void addDynamicView(EodispView dynView);
	
	private boolean isToolBarVisible(JToolBar toolBar) {
		// check if visible
		if (toolBar.getComponentCount() <= 0 && toolBar.isVisible() == true) {
			return false;
		} else if (toolBar.getComponentCount() > 0 && toolBar.isVisible() == false) {
			return true;
		}
		
		return toolBar.isVisible();
	}
}
