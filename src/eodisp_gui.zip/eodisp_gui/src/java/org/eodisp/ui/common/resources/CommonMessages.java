/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.common.resources;

import java.util.Locale;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;
import org.eodisp.ui.common.base.UIApp;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.configuration.Configuration.Entry;

/**
 * This class is for the localization of user interface and exception texts used
 * in the EODiSP framework. The class automatically returns the string best
 * suited for the current configured language. A fallback strategy is used in
 * the case that no String can be found for the current language. The default
 * language is English (ISO Code 'en'). The resource files handled by this class
 * supports the following types of strings.
 * <ul>
 * <li>MessageBoxString: Strings used in message boxes in an EODiSP
 * application. </li>
 * </ul>
 * 
 * @author eglimi
 */
public class CommonMessages {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(CommonMessages.class);

	/**
	 * Holds the value for the resource bundle that includes messages for the
	 * user interface.j
	 */
	private static ResourceBundle commonMsgBundle = null;

	/**
	 * The static method would not be necessary if the bundle was initialized in
	 * the method. Since we use always the same bundle (=same language), it is
	 * initialized here.
	 */
	static {
		String locale = "en";

		Entry userLocaleEntry = ((UIApp) AppRegistry.getRootApp()).getUiConfiguration().getEntry("locale");
		if (userLocaleEntry == null) {
			logger.warn("No entry for the locale of the application has been set."
					+ "Please specify one. For now, a default locale of 'en' will be used");
		} else {
			if (!userLocaleEntry.isSet()) {
				logger.debug("The GUI configuration of this application does not define an entry for the locale."
						+ "The default locale as specified by the application will be used."
						+ "Please add an entry in the configuration if you want to change this");
			}

			locale = userLocaleEntry.getValue();
		}

		Locale userLocale = new Locale(locale);
		commonMsgBundle = ResourceBundle.getBundle("org.eodisp.ui.common.resources.CommonMessages", userLocale);
	}

	/**
	 * Returns the text found by the given key in the resource. Only Strings
	 * which are used in a EODiSP user interface are returned here.
	 * 
	 * @param key
	 *            The resource file is searched for this key.
	 * @return The text for the current language. null is returned if no String
	 *         can be found.
	 */
	public static String getMessage(String key) {
		return commonMsgBundle != null ? commonMsgBundle.getString(key) : null;
	}
}
