/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com
 *  mail: info@pnp-software.com
 */
package org.eodisp.ui.sm.controllers;

import java.awt.event.ActionEvent;

import javax.swing.*;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;

import org.apache.log4j.Logger;
import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.Notifier;
import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eodisp.core.common.EmfUtil;
import org.eodisp.core.common.ReposServiceProxy;
import org.eodisp.core.sm.application.SmAppModuleCore;
import org.eodisp.core.sm.helper.SmEmfHelper;
import org.eodisp.core.sm.service.*;
import org.eodisp.core.sm.service.ExperimentTaskState.ControlFederateState;
import org.eodisp.core.sm.service.ExperimentTaskState.TaskState;
import org.eodisp.ui.common.actions.EodispAction;
import org.eodisp.ui.common.base.*;
import org.eodisp.ui.common.components.SdoTreeNode;
import org.eodisp.ui.common.resources.CommonMessageBoxes;
import org.eodisp.ui.common.resources.MessageBoxHelper;
import org.eodisp.ui.shared.views.SimpleDialog;
import org.eodisp.ui.sm.application.SmAppUtils;
import org.eodisp.ui.sm.models.*;
import org.eodisp.ui.sm.resources.SmResources;
import org.eodisp.ui.sm.views.*;
import org.eodisp.ui.sm.views.SmInitiDataDialog.SmInitData;
import org.eodisp.util.AppRegistry;
import org.eodisp.wrapper.hla.FederationState;

import commonj.sdo.DataObject;

/**
 * @author eglimi
 */
public class SMTreeController extends EodispController {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(SMTreeController.class);

	private final PropertyAdapter propertyAdapter = new PropertyAdapter();

	private final SmExpTreeModel expTreeModel = new SmExpTreeModel();

	private final SmExpTreeView expTreeView = new SmExpTreeView();

	private final SMPropertySheetView propertyView = new SMPropertySheetView();

	private final SMPropertySheetModel propertyModel = new SMPropertySheetModel();

	private final SmErrorView errorView = new SmErrorView();

	private final SmErrorModel errorModel = new SmErrorModel();

	private final SmExperimentInfoView experimentInfo = new SmExperimentInfoView();

	private final SmExperimentInfoModel experimentInfoModel = new SmExperimentInfoModel();

	private final ExperimentObserver experimentObserver = new ExperimentObserver();

	/**
	 * Default constructor.
	 */
	public SMTreeController() {
		super();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void initialize() {
		super.initialize();

		createStaticViews();

		ExperimentTaskManager taskMgr = ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(SmAppModuleCore.ID))
				.getExperimentTaskManager();
		taskMgr.addExperimentListener(experimentObserver);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void registerActionHandler() {
		SmExpTreeView.onAddFederateExecution.registerTargetHandler(new EodispDelegate(this, "onAddFederateExecution"));
		SmExpTreeView.onAddFederationExecution.registerTargetHandler(new EodispDelegate(this,
				"onAddFederationExecution"));
		SmExpTreeView.onAddInitData.registerTargetHandler(new EodispDelegate(this, "onAddInitData"));
		SmExpTreeView.onDeleteSelection.registerTargetHandler(new EodispDelegate(this, "onDeleteSelection"));
		SmExpTreeView.onShowInfo.registerTargetHandler(new EodispDelegate(this, "onShowInfo"));
		SmExpTreeView.onExperimentPrepare.registerTargetHandler(new EodispDelegate(this, "onExperimentPrepare"));
		SmExpTreeView.onExperimentStart.registerTargetHandler(new EodispDelegate(this, "onExperimentStart"));
		SmExpTreeView.onExperimentKill.registerTargetHandler(new EodispDelegate(this, "onExperimentKill"));
		SmExpTreeView.onExperimentReset.registerTargetHandler(new EodispDelegate(this, "onExperimentReset"));
		SmExpTreeView.onExperimentPause.registerTargetHandler(new EodispDelegate(this, "onExperimentPause"));
		SmExpTreeView.onExperimentResume.registerTargetHandler(new EodispDelegate(this, "onExperimentResume"));
		SmExpTreeView.onNextStep.registerTargetHandler(new EodispDelegate(this, "onNextStep"));
	}

	public void onAddFederationExecution(ActionEvent e) {
		logger.debug("performing action: onAddFederationExecution");

		try {
			EodispAction a = (EodispAction) ((JMenuItem) e.getSource()).getAction();
			EDataObject userObj = (EDataObject) a.getValue(EodispAction.USER_OBJECT);
			if (SmEmfHelper.isExperiment(userObj)) {
				SmEmfHelper.addNewFederationExecution(userObj, SmResources
						.getMessage("FederationExecution.New.TemplateName"));

				updateOwnedModels();
			}
		} catch (IllegalArgumentException ex) {
			logger.error("Could not add a new federation execution", ex);
			MessageBoxHelper.ErrorBoxL(null, "CreateError.Msg", "CreateError.Cap", ex.getMessage());
		}

		logger.debug("onAddFederationExecution completed");
	}

	public void onAddFederateExecution(ActionEvent e) {
		logger.debug("performing action: onAddFederateExecution");

		try {
			EodispAction a = (EodispAction) ((JMenuItem) e.getSource()).getAction();
			EDataObject userObj = (EDataObject) a.getValue(EodispAction.USER_OBJECT);

			JFrame owner = ((UIApp) AppRegistry.getRootApp()).getMainFrame();
			DataObject[] selectedFederates = SmReposFederates.showSelectionDialog(owner);

			if (selectedFederates == null) {
				// nothing selected
				return;
			}

			for (DataObject selectedFederate : selectedFederates) {
				if (SmEmfHelper.isFederationExecution(userObj)) {
					SmEmfHelper.addNewFederateExecution(userObj, selectedFederate);
				}
			}

			updateOwnedModels();

		} catch (IllegalArgumentException ex) {
			logger.error("Could not add a new federate", ex);
			MessageBoxHelper.ErrorBoxL(null, "CreateError.Msg", "CreateError.Cap", ex.getMessage());
		}

		logger.debug("onAddFederateExecution completed");
	}

	public void onAddInitData(ActionEvent e) {
		logger.debug("performing action: onAddInitData");

		try {
			EodispAction a = (EodispAction) ((JMenuItem) e.getSource()).getAction();
			EDataObject userObj = (EDataObject) a.getValue(EodispAction.USER_OBJECT);

			JFrame owner = ((UIApp) AppRegistry.getRootApp()).getMainFrame();
			SmInitData initData = SmInitiDataDialog.showInitDataDialog(owner);

			if (initData.getSelectedFile() == null) {
				// nothing selected
				return;
			}

			if (SmEmfHelper.isLocalFederate(userObj)) {
				SmEmfHelper.addNewInitData(userObj, initData.getSelectedFile(), initData.getDescription());

				updateOwnedModels();
			}
		} catch (IllegalArgumentException ex) {
			logger.error("Could not add a new federate", ex);
			MessageBoxHelper.ErrorBoxL(null, "CreateError.Msg", "CreateError.Cap", ex.getMessage());
		}

		logger.debug("onAddInitData completed");
	}

	public void onDeleteSelection(ActionEvent e) {
		logger.debug("performing action: onDeleteSelection");

		if (CommonMessageBoxes.askForDelete(null) == JOptionPane.NO_OPTION) {
			return;
		}

		EodispAction a = (EodispAction) ((JMenuItem) e.getSource()).getAction();
		EDataObject oldValue = (EDataObject) a.getValue(EodispAction.USER_OBJECT);

		if (oldValue != null) {
			// remove listener if neccessary
			if (oldValue.eAdapters().contains(propertyAdapter)) {
				logger.debug("Remove Property Adapter for" + SmEmfHelper.getName(oldValue));
				oldValue.eAdapters().remove(propertyAdapter);
			}

			// delete containments as appropriate (experiments are handled
			// separately in the app controller).
			if (SmEmfHelper.isFederationExecution(oldValue)) {
				SmEmfHelper.removeFederationChildren(oldValue);
			} else if (SmEmfHelper.isLocalFederate(oldValue)) {
				SmEmfHelper.removeFederateChildren(oldValue);
			}

			// delete it
			EmfUtil.delete(oldValue);

			// update everything to show new state
			updateOwnedModels();
		}

		logger.debug("onDeleteSelection completed");
	}

	public void onShowInfo(ActionEvent e) {
		logger.debug("performing action: onShowInfo");

		DataObject reposFederate = null;

		EodispAction a = (EodispAction) ((JMenuItem) e.getSource()).getAction();
		EDataObject value = (EDataObject) a.getValue(EodispAction.USER_OBJECT);

		ReposServiceProxy service = ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(SmAppModuleCore.ID))
				.getReposServiceProxy();
		if (service != null) {
			reposFederate = SmEmfHelper.findReposFederate(service.getRootObject(), value);
		}

		JFrame owner = ((UIApp) AppRegistry.getRootApp()).getMainFrame();

		SimpleDialog.showHtml(owner, SmEmfHelper.getFederateInfo(reposFederate));

		logger.debug("onShowInfo completed");
	}

	public void onExperimentPrepare(ActionEvent e) {
		logger.debug("performing action: onExperimentPrepare");

		if (!SmAppUtils.isConnected()) {
			logger
					.debug("The application is not connected to a repository. The experiment can therefore not be started.");
			CommonMessageBoxes.showReposNotConnectedError(null);
			return;
		}

		SdoTreeNode node = expTreeView.getSelectedNode();

		if (node != null) {

			final EDataObject experiment = (EDataObject) node.getUserObject();

			final ExperimentTaskManager taskMgr = ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(
					SmAppModuleCore.ID)).getExperimentTaskManager();

			if (taskMgr.isExperimentAcquired(experiment)) {
				final String message = "The experiment has already been prepared.";
				logger.debug(message);
				CommonMessageBoxes.showGeneralMessage(null, message);
				return;
			}

			try {
				taskMgr.acquireExperiment(experiment);
			} catch (ExperimentAcquireException ex) {
				final String message = "The experiment could not be prepared.";
				logger.error(message, ex);
				CommonMessageBoxes.showGeneralMessage(null, message + "\n" + ex.getMessage());
				return;
			}
		}

		logger.debug("onExperimentPrepare completed");
	}

	public void onExperimentStart(ActionEvent e) {
		logger.debug("performing action: onExperimentStart");

		SdoTreeNode node = expTreeView.getSelectedNode();
		if (node != null) {
			final EDataObject experiment = (EDataObject) node.getUserObject();

			final ExperimentTaskManager taskMgr = ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(
					SmAppModuleCore.ID)).getExperimentTaskManager();
			try {
				taskMgr.startExperiment(experiment);
			} catch (ExperimentStartException ex) {
				CommonMessageBoxes.showGeneralMessage(null, ex.getMessage());
			}
		}
		
		logger.debug("onExperimentStart completed");
	}

	public void onExperimentKill(ActionEvent e) {
		logger.debug("performing action: onExperimentKill");

		SdoTreeNode node = expTreeView.getSelectedNode();
		if (node != null) {
			EDataObject experiment = (EDataObject) node.getUserObject();

			try {
				cancelExperiment(experiment);
			} catch (Exception ex) {
				CommonMessageBoxes.showGeneralMessage(null, ex.getMessage());
				return;

			}
		}

		logger.debug("onExperimentKill completed");
	}

	public void onExperimentReset(ActionEvent e) {
		logger.debug("performing action: onResetExperiment");

		SdoTreeNode node = expTreeView.getSelectedNode();
		if (node != null) {
			EDataObject experiment = (EDataObject) node.getUserObject();

			try {
				clearExperiment(experiment);
			} catch (Exception ex) {
				CommonMessageBoxes.showGeneralMessage(null, ex.getMessage());
				return;
			}
		}

		logger.debug("onResetExperiment completed");
	}

	private void cancelExperiment(EDataObject experiment) throws ExperimentTaskException {
		ExperimentTaskManager taskMgr = ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(SmAppModuleCore.ID))
				.getExperimentTaskManager();

		taskMgr.cancelExperiment(experiment);
	}

	private void clearExperiment(EDataObject experiment) throws ExperimentTaskException {
		ExperimentTaskManager taskMgr = ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(SmAppModuleCore.ID))
				.getExperimentTaskManager();

		taskMgr.clearExperiment(experiment);

	}

	public void onExperimentPause(ActionEvent e) {
		logger.debug("performing action: onExperimentPause");
		
		SdoTreeNode node = expTreeView.getSelectedNode();
		if (node != null) {
			final EDataObject experiment = (EDataObject) node.getUserObject();

			final ExperimentTaskManager taskMgr = ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(
					SmAppModuleCore.ID)).getExperimentTaskManager();
			try {
				taskMgr.pauseExperiment(experiment);
			} catch (ExperimentTaskException ex) {
				CommonMessageBoxes.showGeneralMessage(null, ex.getMessage());
			}
		}

		logger.debug("onExperimentPause completed");
	}

	public void onExperimentResume(ActionEvent e) {
		logger.debug("performing action: onExperimentResume");

		SdoTreeNode node = expTreeView.getSelectedNode();
		if (node != null) {
			final EDataObject experiment = (EDataObject) node.getUserObject();

			final ExperimentTaskManager taskMgr = ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(
					SmAppModuleCore.ID)).getExperimentTaskManager();
			try {
				taskMgr.resumeExperiment(experiment);
			} catch (ExperimentTaskException ex) {
				CommonMessageBoxes.showGeneralMessage(null, ex.getMessage());
			}
		}

		logger.debug("onExperimentResume completed");
	}

	public void onNextStep(ActionEvent e) {
		logger.debug("performing action: onNextStep");
		
		SdoTreeNode node = expTreeView.getSelectedNode();
		if (node != null) {
			final EDataObject experiment = (EDataObject) node.getUserObject();

			final ExperimentTaskManager taskMgr = ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(
					SmAppModuleCore.ID)).getExperimentTaskManager();
			try {
				taskMgr.stepExperiment(experiment);
			} catch (ExperimentTaskException ex) {
				CommonMessageBoxes.showGeneralMessage(null, ex.getMessage());
			}
		}
		
		logger.debug("onNextStep completed");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void createStaticViews() {

		// set experiments tree view
		expTreeView.setModel(expTreeModel);
		expTreeView.initializeComponents();
		attachView(expTreeView);

		propertyView.setModel(propertyModel);
		propertyView.initializeComponents();
		attachView(propertyView);

		errorView.setModel(errorModel);
		errorView.initializeComponents();
		attachView(errorView);

		experimentInfo.setModel(experimentInfoModel);
		experimentInfo.initializeComponents();
		attachView(experimentInfo);

		expTreeView.addTreeSelectionListener(new TreeSelectionListener() {
			public void valueChanged(TreeSelectionEvent e) {
				Object node = e.getPath().getLastPathComponent();
				if (node != null) {
					EDataObject selectedNode = (EDataObject) ((SdoTreeNode) node).getUserObject();
					if (!selectedNode.eAdapters().contains(propertyAdapter)) {
						logger.debug("Add Property Adapter for" + SmEmfHelper.getName(selectedNode));
						selectedNode.eAdapters().add(propertyAdapter);
					}
					propertyModel.updateSource(selectedNode);
				}
			}
		});
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public EodispView createDynamicView(int id) {
		switch (id) {
		default:
			return null;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isControllerForView(int id) {
		switch (id) {
		case SmExpTreeView.ID:
		case SMPropertySheetView.ID:
		case SmErrorView.ID:
		case SmExperimentInfoView.ID:
			return true;
		default:
			return false;
		}
	}

	private class PropertyAdapter implements Adapter {

		public Notifier getTarget() {
			return null;
		}

		public boolean isAdapterForType(Object type) {
			return false;
		}

		public void notifyChanged(Notification notification) {
			if (notification.getEventType() == Notification.SET) {
				updateOwnedModels();
			}
		}

		public void setTarget(Notifier newTarget) {
		}
	}

	private class ExperimentObserver implements ExperimentListener {

		public void experimentChanged() {
			SwingUtilities.invokeLater(new Runnable() {

				public void run() {
					reflectExperimentState();
				}

			});
		}
	}

	private void reflectExperimentState() {

		final ExperimentTaskManager taskMgr = ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(
				SmAppModuleCore.ID)).getExperimentTaskManager();
		EDataObject experiment = ((SMAppController) ((UIApp) AppRegistry.getRootApp()).getApplicationController())
				.getCurrentExperiment();

		ExperimentTaskState state = taskMgr.getState(experiment);

		updateOwnedViewStates();

		// test for shutdown experiment
		if (state != null
				&& (state.getFederationState() == FederationState.STOPPED || state.getFederationState() == FederationState.NOT_INITIALIZED)
				&& state.getControlFederateState() == ControlFederateState.STOPPED
				&& (state.getTaskState() == TaskState.END)) {
			try {
				clearExperiment(experiment);
			} catch (ExperimentTaskException e) {
				CommonMessageBoxes.showGeneralMessage(null, e.getMessage());
			}
		}
	}

}
