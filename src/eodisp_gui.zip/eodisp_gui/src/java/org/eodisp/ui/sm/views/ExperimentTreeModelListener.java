package org.eodisp.ui.sm.views;

import java.util.EventListener;

import org.eodisp.ui.sm.models.SmExpTreeModel;

/**
 * A component implementing this interface will receive events from the
 * {@link SmExpTreeModel} to notify about reloading of the tree.
 * 
 * @author eglimi
 * @version $Id:$
 */
public interface ExperimentTreeModelListener extends EventListener {

	/**
	 * The tree is about to reload. After this, a
	 * <code>nodeStructureChanged</code> event will be fired.
	 */
	void treeWillReload();

	/**
	 * The tree has been reloaded with a <code>nodeStructureChanged</code>
	 * event.
	 */
	void treeReloaded();

}
