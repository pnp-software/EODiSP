/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com
 *  mail: info@pnp-software.com
 */
package org.eodisp.ui.common.base;

import java.io.IOException;

/**
 * All models in a EODiSP application implement this interface. It indicates
 * that the class serves as a model for a visual component (such as a tree,
 * list, table, etc.)
 * <p>
 * A model is a basic component of the model view controller (MVC) architecture.
 * It serves as a kind of data pool from which views will take their data to
 * display them to the user. A model gets its command from a controller. It will
 * act upon such a command as appropriate and inform the view about updates
 * (such as adding or removing values).
 * <p>
 * The implementation of a model is greatly dependant on the visual component.
 * Hence, only a few methods are generic for each model.
 * 
 * @author eglimi
 * @version $Id:EodispModel.java 2047 2006-05-09 12:20:54Z eglimi $
 */
public interface EodispModel {

	/**
	 * Returns a value stating whether the model has some changes since the last
	 * change.
	 * 
	 * @return True if the model has changes since the last change or false, if
	 *         there are no changes.
	 */
	boolean hasChanges();

	/**
	 * Executes the save command in the model. This saves the changes since the
	 * last save persistently.
	 * 
	 * @throws IOException
	 *             thrown when the data could not be saved persistently. This
	 *             should lead to a visual indication to the user.
	 */
	void doSave() throws IOException;

	/**
	 * <p>
	 * Instructs the model to do an update of its data. Many
	 * <code>EodispModel</code>s are just intermediated models for view
	 * components and do not hold the actual data. The actual data is usually
	 * retrieved and maintained by a persistency framework. Thus, if the real
	 * data has been changed, a model can be informed of this updated and it can
	 * be instructed to reload the data.
	 * </p>
	 * <p>
	 * This should in most cases lead to an update of the visual component
	 * representing the data as well.
	 * </p>
	 */
	void doUpdate();

	/**
	 * This makes and undo of the last command executed by the model. How an
	 * undo is implemented depends on the model. This operation might not be
	 * available on all models. Models not supporting undo should ignore such a
	 * request.
	 */
	void undo();

	/**
	 * This re-performs the last command executed by the model. How a redo is
	 * implemented depends on the model. This operation might not be available
	 * on all models. Models not supporting redo should ignore such a request.
	 */
	void redo();
}
