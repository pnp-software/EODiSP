/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.mm.views;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.*;

import org.apache.log4j.Logger;
import org.eodisp.ui.common.resources.CommonMessageBoxes;
import org.eodisp.ui.common.resources.CommonMessages;
import org.eodisp.ui.common.resources.MessageBoxHelper;
import org.eodisp.ui.mm.resources.MmResources;

import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.factories.ButtonBarFactory;
import com.jgoodies.forms.factories.FormFactory;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

/**
 * <strong>Important</strong><br>
 * This file is not yet complete and thus not in use. See comments below.
 * 
 * TODO This file is not complete and was an idea to support imports of files
 * and directories in the model manager. The files could be imported from either
 * the local hard-drive (file protocol) or from the web (http protocol). It is
 * suspended due to lack of time at the moment.
 * <p>
 * There would be some non-trivial considerations when implementing this feature
 * <ul>
 * <li>What if the file or directory with the same name as an existing one is
 * given for import?</li>
 * <li>How does the reload mechanism work (automatic, restart app, etc.)?
 * <li>Is it possible to import federates while another (any) federate is
 * running? This would be quite complicated since presumably all federates need
 * to be re-read</li>
 * </ul>
 * 
 * 
 * 
 * 
 * 
 * This is a dialog to import existing federates into the model manager
 * application.
 * <p>
 * A predefined federate must be either in the form of a self-contained jar file
 * or in the form of a zip file that may contain directories or other jar files.
 * <p>
 * TODO: document what is possible -> URL? local file?, etc.
 * 
 * @author eglimi
 * @version $Id:$
 */
public class MmImportDialog {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(MmImportDialog.class);

	private final JDialog dialog;

	private JPanel mainPanel;

	private final JScrollPane scrollPane = new JScrollPane();

	private final JTextField urlField = new JTextField();

	private final JButton fileBtn = new JButton("...");

	private final JButton[] dialogButtons = new JButton[2];

	private final JFrame owner;

	private URL federateURL;

	private MmImportDialog(JFrame owner) {
		this.owner = owner;

		dialog = new JDialog(owner, true);

		initializeComponents();
		buildPanels();
		dialog.setContentPane(scrollPane);
	}

	/**
	 * Displays this dialog.
	 */
	public static void showInitDataDialog(JFrame owner) {
		MmImportDialog initiDataDialog = new MmImportDialog(owner);
		initiDataDialog.showInernalInitDataDialog();
	}

	private void showInernalInitDataDialog() {
		dialog.pack();
		dialog.setLocationRelativeTo(owner);
		dialog.setVisible(true);
		dialog.dispose();
	}

	private void initializeComponents() {

		dialogButtons[0] = new JButton(MmResources.getMessage("MmImportDialog.Button0.Text"));
		dialogButtons[0].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				importFederate();
				exitDialog();
			}
		});
		dialogButtons[1] = new JButton(CommonMessages.getMessage("Button.Cancel"));
		dialogButtons[1].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exitDialog();
			}
		});
	}

	private void buildPanels() {
		// create the layout
		CellConstraints cc = new CellConstraints();
		FormLayout layout = new FormLayout("right:50dlu, 4dlu, 75dlu:grow", "p, 1dlu, 100dlu, 3dlu, p");
		PanelBuilder builder = new PanelBuilder(layout);
		builder.setDefaultDialogBorder();
		buildPanel(builder, cc, layout);

		// get and set the panel
		mainPanel = builder.getPanel();
		scrollPane.setViewportView(mainPanel);
	}

	private void buildPanel(PanelBuilder builder, CellConstraints cc, FormLayout layout) {
		int labelCol = 1;

		// federate description
		builder.addLabel(MmResources.getMessage("MmFederateInfoDialog.Label0.Text"), cc.xyw(labelCol, builder.getRow(),
				3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.add(new JScrollPane(urlField), cc.xyw(labelCol, builder.getRow(), 3));
		builder.nextRow();

		// buttons
		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		JPanel btnPanel = ButtonBarFactory.buildRightAlignedBar(dialogButtons);
		builder.add(btnPanel, cc.xyw(builder.getColumn(), builder.getRow(), 3));
	}

	/**
	 * Closes the dialog.
	 */
	private void exitDialog() {
		dialog.dispose();
	}

	private void importFederate() {

		if (federateURL == null) {
			CommonMessageBoxes.showGeneralMessage(dialog, "MmImportDialog.Warning.NotSelected");
			return;
		}

		try {
			if (federateURL.getProtocol() == "http") {
				InputStream fis = federateURL.openStream();
				// TODO load file from URL
			} else if (federateURL.getProtocol() == "file") {
				// TODO handling of files
			} else {
				CommonMessageBoxes.showGeneralMessage(dialog, String.format("protocol %s not valid.", federateURL
						.getProtocol()));
				return;
			}
		} catch (Exception ex) {
			// TODO
		}

		int choice = MessageBoxHelper.YesNoQuestionBoxL(dialog, "Warning.File.Exists.Msg", "Warning.File.Exists.Cap");

	}

	private void showOpenFileDialog() {

		// TODO filter for appropriate files

		JFileChooser chooser = new JFileChooser();
		int returnVal = chooser.showOpenDialog(dialog);
		if (returnVal == JFileChooser.APPROVE_OPTION) {
			try {
				federateURL = chooser.getSelectedFile().toURL();
			} catch (MalformedURLException e) {
				CommonMessageBoxes.showException(dialog, "This URL is not valid", e);
			}
		} else {
			// no file has been chosen.
			return;
		}
	}
}
