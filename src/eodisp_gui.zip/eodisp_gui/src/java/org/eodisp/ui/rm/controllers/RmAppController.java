/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com
 *  mail: info@pnp-software.com
 */
package org.eodisp.ui.rm.controllers;

import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;

import javax.swing.JOptionPane;

import org.apache.log4j.Logger;
import org.eodisp.ui.common.base.EodispApplicationController;
import org.eodisp.ui.common.base.EodispDelegate;
import org.eodisp.ui.common.base.EodispMainFrame;
import org.eodisp.ui.common.resources.CommonMessageBoxes;
import org.eodisp.ui.common.resources.MessageBoxHelper;
import org.eodisp.ui.rm.application.RmAppModuleGui;
import org.eodisp.ui.rm.application.RmAppUtils;
import org.eodisp.ui.rm.views.RmMainFrame;
import org.eodisp.ui.rm.views.RmPrefs;
import org.eodisp.util.AppRegistry;

/**
 * This is the application controller for the EODiSP repos manager application.
 * It is the main controller, which has control over the creation of other
 * controllers. It is therfore the controller of the application which must
 * exist in order to run the application.
 * <p>
 * Specific tasks which this controller is responsible for are:
 * <ul>
 * <li>Creation of other controllers used throughout this application.</li>
 * <li>Creation of the main frame used in this application. </li>
 * </ul>
 * <p>
 * The <code>MmAppController</code> extends the more generic
 * <code>EodispApplicationController</code> and is only useful to handle the
 * specific part for the repos manager application. All generic tasks are
 * handled and documented in the <code>EodispApplicationController</code>
 * class.
 * 
 * @author eglimi
 */
public class RmAppController extends EodispApplicationController {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(RmAppController.class);

	/**
	 * Default constructor.
	 */
	public RmAppController() {
		registerActionHandler();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void initialize() {
		super.initialize();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eodisp.ui.common.base.EodispApplicationController#registerActionHandler()
	 */
	@Override
	public void registerActionHandler() {
		RmMainFrame.onSaveAll.registerTargetHandler(new EodispDelegate(this, "onSaveAll"));
		RmMainFrame.onExitApp.registerTargetHandler(new EodispDelegate(this, "onExitApp"));

		RmMainFrame.onAbout.registerTargetHandler(new EodispDelegate(this, "onAbout"));
		RmMainFrame.onHelp.registerTargetHandler(new EodispDelegate(this, "onHelp"));

		RmMainFrame.onConnectRepos.registerTargetHandler(new EodispDelegate(this, "onConnectRepos"));
		RmMainFrame.onReloadRepos.registerTargetHandler(new EodispDelegate(this, "onReloadRepos"));

		RmMainFrame.onPrefs.registerTargetHandler(new EodispDelegate(this, "onPrefs"));
	}

	public void onSaveAll(ActionEvent e) {
		logger.debug("performing action: onSaveAll");

		try {
			super.saveAllChanges();
		} catch (IOException ex) {
			logger.error("Could not save all data", ex);
			CommonMessageBoxes.showSaveError(null, ex.getMessage());
		}
		logger.debug("saveAll completed");
	}

	public void onExitApp(ActionEvent e) {
		logger.debug("performing action: onExitApp");
		super.handleExit();
		logger.debug("onExitApp completed");
	}

	public void onAbout(ActionEvent e) {
		logger.debug("performing action: onAbout");
		logger.debug("onAbout completed");
		// TODO
	}

	public void onHelp(ActionEvent e) {
		logger.debug("performing action: onExportProjectPart");
		logger.debug("onExportProjectPart completed");
		// TODO
	}

	public void onConnectRepos(ActionEvent e) {
		logger.debug("performing action: onConnectRepos");

		RmAppModuleGui appModul = ((RmAppModuleGui) AppRegistry.getRootApp().getAppModule(RmAppModuleGui.ID));

		if (!RmAppUtils.isConnected()) {
			try {
				appModul.connectToRepos();
			} catch (Exception ex) {
				logger.debug("Could not connect to repository..", ex);
				MessageBoxHelper.ErrorBoxL(null, "ReposConnectError.Msg", "ReposConnectError.Cap", ex.getMessage());
				return;
			}
		}

		try {
			appModul.getReposServiceProxy().load();
		} catch (Exception ex) {
			logger.debug("Could not load data from repository", ex);
			CommonMessageBoxes.showLoadError(getMainFrame(), ex.getMessage());
			return;
		}

		checkState();
		super.updateAllModels();

		logger.debug("onConnectRepos completed");
	}

	public void onReloadRepos(ActionEvent e) {
		logger.debug("performing action: onReloadRepos");

		boolean connected = ((RmAppModuleGui) AppRegistry.getRootApp().getAppModule(RmAppModuleGui.ID))
				.isReposConnected();
		if (!connected) {
			logger
					.info("The data from the repository could not be reloaded. The repository is not connected. Please connect first.");
			CommonMessageBoxes.showReposNotConnectedError(null);
			return;
		}

		if (super.hasAppChanges()) {
			int choice = MessageBoxHelper.YesNoCancelQuestionBoxL(getMainFrame(), "AskForSaveViews.Msg",
					"AskForSaveViews.Cap");
			if (choice == JOptionPane.YES_OPTION) {
				try {
					saveAllChanges();
				} catch (IOException ex) {
					CommonMessageBoxes.showSaveError(null, ex.getMessage());
					return;
				}
			}
		}

		RmAppModuleGui appModul = ((RmAppModuleGui) AppRegistry.getRootApp().getAppModule(RmAppModuleGui.ID));

		appModul.getReposServiceProxy().setScheduledForReload(true);

		try {
			appModul.getReposServiceProxy().load();
		} catch (IOException ex) {
			CommonMessageBoxes.showLoadError(getMainFrame(), ex.getMessage());
		}

		checkState();
		super.updateAllModels();

		logger.debug("onReloadRepos completed");
	}

	public void onPrefs(ActionEvent e) {
		logger.debug("performing action: onPrefs");
		final RmPrefs prefs = new RmPrefs();
		prefs.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				if (prefs.canExit()) {
					prefs.dispose();
				}
			}
		});
		prefs.pack();
		prefs.setVisible(true);
		logger.debug("onPrefs completed");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void createControllers() {

		ReposController reposController = new ReposController();
		reposController.initialize();

		attachController(reposController);

	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected EodispMainFrame createMainFrame() {
		return new RmMainFrame();
	}

	/**
	 * <p>
	 * Sets the main title of the main frame according to the current state.
	 * There are the following states
	 * </p>
	 * 
	 * <pre>
	 * connected | registered | text on main frame
	 * -----------------------------------------------------
	 *     no    |     no     | not connected/not registered
	 *     yes   |     no     | connected/not registered
	 *     yes   |     yes    | connected/registered
	 * </pre>
	 * 
	 * <p>
	 * In addition, it updates the state of the actions.
	 */
	private void checkState() {
		if (RmAppUtils.isConnected()) {
			getMainFrame().updateTitle("connected");
		} else {
			getMainFrame().updateTitle("not connected");
		}

		super.updateAllActions();
	}
}
