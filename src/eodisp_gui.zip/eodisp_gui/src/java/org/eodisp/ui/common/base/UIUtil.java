package org.eodisp.ui.common.base;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import javax.swing.*;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

import net.infonode.gui.icon.IconUtil;

/**
 * The UIUtil class provides generic functions which can be used by every
 * application in the EODiSP framework. Since it is a utility class, it is
 * stateless and all methods should remain static.
 * 
 * @author eglimi
 * @version $Id:UIUtil.java 2048 2006-05-09 12:22:12Z eglimi $
 * 
 */
public abstract class UIUtil {

	/**
	 * Places a component on the screen. This should be a bit better in most
	 * cases than the default placement.
	 * 
	 * @param component
	 *            The component to place on the screen.
	 */
	public static void locateOnScreen(Component component) {
		Dimension paneSize = component.getSize();
		Dimension screenSize = component.getToolkit().getScreenSize();
		component.setLocation((screenSize.width - paneSize.width) - 200, (screenSize.height - paneSize.height) / 2);
	}

	/**
	 * Set some user interface relevant options like font, icon size, etc. Also
	 * a platform specific Look and Feel will be used for the application.
	 * 
	 */
	public static void configureUI() {
		// Set title color
		UIManager.put("TitledBorder.titleColor", Color.BLUE);
	}

	public static List<String> getCssRules() {
		List<String> rules = new ArrayList<String>();
		rules.add("body {background-color: transparent; font-family: 'Bitstream Vera Sans', Verdana, Helvetica}");
		rules.add("div.section {border-width: 2px; border-style: solid; margin-bottom: 10px; padding-left: 5px;}");
		rules.add("h1 {font-size: 18pt; margin: 0;}");

		return rules;
	}

	/**
	 * Aligns a menu. This can be used for menus with icons in order to get an
	 * aligned menu, where all menu items are aligned, whether with or without
	 * icon.
	 * <p>
	 * It supports the icon and disabled icon, but not the selected disabled
	 * icon.
	 * 
	 * @param menu
	 *            the menu to align.
	 */
	public static void align(MenuElement menu) {
		MenuElement[] children = menu.getSubElements();
		final int maxWidth = IconUtil.getMaxIconWidth(children);

		for (int i = 0; i < children.length; i++) {
			if (children[i] instanceof AbstractButton) {
				AbstractButton b = (AbstractButton) children[i];
				final Icon icon = b.getIcon();
				final Icon disabledIcon = b.getDisabledIcon();
				b.setIcon(new Icon() {
					public int getIconHeight() {
						return icon == null ? 1 : icon.getIconHeight();
					}

					public int getIconWidth() {
						return maxWidth;
					}

					public void paintIcon(Component c, Graphics g, int x, int y) {
						if (icon != null)
							icon.paintIcon(c, g, x, y);
					}
				});

				b.setDisabledIcon(new Icon() {

					public void paintIcon(Component c, Graphics g, int x, int y) {
						if (disabledIcon != null) {
							disabledIcon.paintIcon(c, g, x, y);
						}
					}

					public int getIconWidth() {
						return maxWidth;
					}

					public int getIconHeight() {
						return disabledIcon == null ? 1 : disabledIcon.getIconHeight();
					}

				});
			}

			align(children[i]);
		}
	}

	public static void adjustColumnSize(JTable table) {
		TableColumnModel columnModel = table.getColumnModel();

		for (int col = 0; col < table.getColumnCount(); col++) {
			int maxWidth = 0;
			for (int row = 0; row < table.getRowCount(); row++) {
				TableCellRenderer rend = table.getCellRenderer(row, col);
				Object value = table.getValueAt(row, col);
				Component comp = rend.getTableCellRendererComponent(table, value, false, false, row, col);
				maxWidth = Math.max(comp.getPreferredSize().width, maxWidth);
			}

			TableColumn column = columnModel.getColumn(col);
			TableCellRenderer headerRenderer = column.getHeaderRenderer();
			if (headerRenderer == null) {
				headerRenderer = table.getTableHeader().getDefaultRenderer();
			}
			Object headerValue = column.getHeaderValue();
			Component headerComp = headerRenderer.getTableCellRendererComponent(table, headerValue, false, false, 0,
					col);
			maxWidth = Math.max(headerComp.getPreferredSize().width, maxWidth);

			column.setPreferredWidth(maxWidth + 1);
		}
	}
}
