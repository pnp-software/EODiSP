/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.shared.views;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.*;

import org.apache.log4j.Logger;
import org.eodisp.remote.config.RemoteConfiguration;
import org.eodisp.ui.common.base.EodispModel;
import org.eodisp.ui.common.binding.ConfigAdapter;
import org.eodisp.ui.common.components.AbstractConfigPanel;
import org.eodisp.ui.common.resources.CommonMessages;
import org.eodisp.ui.shared.models.RemoteConfModel;
import org.eodisp.util.configuration.Configuration;

import com.jgoodies.binding.adapter.BasicComponentFactory;
import com.jgoodies.binding.list.SelectionInList;
import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.factories.FormFactory;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

/**
 * This is a panel to configure the general settings for network (i.e. the
 * eodisp_remote configuration).
 * 
 * @author eglimi
 * @version $Id:$
 * 
 */
public class RemoteConf extends AbstractConfigPanel {

	/**
	 * Default serial version id
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(JxtaConfig.class);

	private JPanel configPanel;

	private JComboBox transport;

	private JTextField tcpPort;

	private JTextField jxtaPlatformConfig;

	private JCheckBox jxtaResetConfig;

	private JTextField jxtaNpgUri;

	private JCheckBox jxtaLogAll;

	private JTextField jeriTimeout;

	private final JButton jxtaFcBtn = new JButton("...");

	private final JFileChooser jxtaFc = new JFileChooser();

	public RemoteConf(EodispModel model) {
		super(model);

		CellConstraints cc = new CellConstraints();
		FormLayout layout = new FormLayout("right:pref, 4dlu, 75dlu:grow, 4dlu, right:20dlu",
				"p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p");
		PanelBuilder builder = new PanelBuilder(layout);
		builder.setDefaultDialogBorder();

		initializeComponents();

		buildPanel(cc, layout, builder);
		configPanel = builder.getPanel();
	}

	public JPanel getPanel() {
		return configPanel;
	}

	private void initializeComponents() {
		Configuration config = ((RemoteConfModel) getModel()).getRemoteConfigurator();

		jxtaFcBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				handleJxtaFilePath();
			}
		});

		jxtaFc.setFileHidingEnabled(false);

		// create components
		transport = BasicComponentFactory.createComboBox(new SelectionInList(new Object[] { "JXTA", "TCP" },
				new ConfigAdapter(config, RemoteConfiguration.TRANSPORT)));
		tcpPort = BasicComponentFactory.createIntegerField(new ConfigAdapter(config, RemoteConfiguration.TCP_PORT));
		jxtaPlatformConfig = BasicComponentFactory.createTextField(new ConfigAdapter(config,
				RemoteConfiguration.JXTA_PLATFORM_CONFIG), true);
		jxtaResetConfig = BasicComponentFactory.createCheckBox(new ConfigAdapter(config,
				RemoteConfiguration.JXTA_RESET_CONFIG), "");
		jxtaNpgUri = BasicComponentFactory.createTextField(new ConfigAdapter(config, RemoteConfiguration.JXTA_NPG_URI),
				true);
		jxtaLogAll = BasicComponentFactory.createCheckBox(new ConfigAdapter(config,
				RemoteConfiguration.JXTA_LOG_EVERYTHING), "");
		jeriTimeout = BasicComponentFactory.createIntegerField(new ConfigAdapter(config,
				RemoteConfiguration.JERI_CONNECTION_TIMEOUT));
	}

	private void buildPanel(CellConstraints cc, FormLayout layout, PanelBuilder builder) {
		int labelCol = 1;
		int compCol = 3;

		builder.setRow(1);

		// Default Settings
		builder.addSeparator(CommonMessages.getMessage("RemoteConfig.Prop.Header.General"), cc.xyw(labelCol, builder
				.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("RemoteConfig.Prop.transport"), cc.xy(labelCol, builder.getRow()));
		builder.add(transport, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("RemoteConfig.Prop.tcpPort"), cc.xy(labelCol, builder.getRow()));
		builder.add(tcpPort, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("RemoteConfig.Prop.jxtaPlatformConfig"), cc.xy(labelCol, builder
				.getRow()));
		builder.add(jxtaPlatformConfig, cc.xy(compCol, builder.getRow()));
		builder.add(jxtaFcBtn, cc.xy(compCol + 2, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("RemoteConfig.Prop.jxtaResetConfig"), cc.xy(labelCol, builder
				.getRow()));
		builder.add(jxtaResetConfig, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("RemoteConfig.Prop.jxtaNpgUri"), cc.xy(labelCol, builder.getRow()));
		builder.add(jxtaNpgUri, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("RemoteConfig.Prop.jxtaLogAll"), cc.xy(labelCol, builder.getRow()));
		builder.add(jxtaLogAll, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(CommonMessages.getMessage("RemoteConfig.Prop.jeriTimeout"), cc.xy(labelCol, builder.getRow()));
		builder.add(jeriTimeout, cc.xy(compCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();
	}

	private void handleJxtaFilePath() {
		int returnVal = jxtaFc.showOpenDialog(configPanel);
		if (returnVal == JFileChooser.APPROVE_OPTION) {
			File file = jxtaFc.getSelectedFile();
			if (file.isFile()) {

				// set path
				jxtaPlatformConfig.setText(file.getAbsolutePath());
				logger.debug(String.format("File %s is set as the new PlatformConfig file", file.getAbsolutePath()));
			}
		}
	}
}
