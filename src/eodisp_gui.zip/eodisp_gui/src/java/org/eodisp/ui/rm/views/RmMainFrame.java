/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com
 *  mail: info@pnp-software.com
 */
package org.eodisp.ui.rm.views;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.Action;
import javax.swing.KeyStroke;

import org.eodisp.ui.common.actions.EodispAction;
import org.eodisp.ui.common.actions.EodispActionRegistry;
import org.eodisp.ui.common.base.EodispMainFrame;
import org.eodisp.ui.common.base.EodispView;
import org.eodisp.ui.rm.application.RmAppUtils;
import org.eodisp.ui.rm.resources.RmResources;
import org.eodisp.ui.sm.resources.SmResources;

/**
 * This main frame is the parent frame for all other frames used in the repos
 * manager application. It extends the more generic EodispMainFrame which will
 * handle most of the functions of a main frame. See
 * {@link org.eodisp.ui.common.base.EodispMainFrame} for more information.
 * <p>
 * This class handles only tasks specific to the repos manager application.
 * These are:
 * <ul>
 * <li>Specifying all actions that are provided by the main frame. These
 * actions can be accesses as soon as the application has been started. These
 * actions are usually handled by the application controller itself.</li>
 * <li>Setting frame specific options, such as title, size, etc.</li>
 * </ul>
 * 
 * @author eglimi
 */
public class RmMainFrame extends EodispMainFrame {

	/**
	 * default serial version id.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * The view id of the preference view. This view will be used to show (at
	 * least initially) configuration views.
	 */
	private static final int PREFS_VIEW_ID = 0;

	public static final String TITLE = RmResources.getMessage("RmMainFrame.MainTitle");

	/**
	 * This action is used to close the whole application. Before closing the
	 * application, it should check for changes and ask the user to save them if
	 * necessary.
	 */
	public static EodispAction onExitApp = new EodispAction() {
		{
			setTopMenuItemName(RmResources.getMessage("RmMainFrame.Menu.File.Name"));
			putValue(Action.NAME, RmResources.getMessage("RmMainFrame.onExitApp.Name"));
			putValue(Action.SMALL_ICON, SmResources.getIcon("16x16/actions/exit.png"));
			setAlwaysSelected(true);
		}
	};

	/**
	 * This opens the preferences for the jxta settings.
	 */
	public static EodispAction onPrefs = new EodispAction() {
		{
			setTopMenuItemName(RmResources.getMessage("RmMainFrame.Menu.Settings.Name"));
			putValue(Action.NAME, RmResources.getMessage("RmMainFrame.onPrefs.Name"));
			putValue(Action.SHORT_DESCRIPTION, RmResources.getMessage("RmMainFrame.onPrefs.ShortDesc"));
			putValue(Action.SMALL_ICON, SmResources.getIcon("16x16/categories/preferences-system.png"));
			setAlwaysSelected(true);
		}
	};

	/**
	 * This action shows a pop-up window with general information about the
	 * application.
	 */
	public static EodispAction onAbout = new EodispAction() {
		{
			setTopMenuItemName(RmResources.getMessage("RmMainFrame.Menu.Help.Name")); //$NON-NLS-1$
			putValue(Action.NAME, RmResources.getMessage("RmMainFrame.onAbout.Name")); //$NON-NLS-1$
			setAlwaysSelected(true);
		}
	};

	/**
	 * The HelpAction shows a pop-up windows containing a the help text for this
	 * application.
	 */
	public static EodispAction onHelp = new EodispAction() {
		{
			setTopMenuItemName(RmResources.getMessage("RmMainFrame.Menu.Help.Name"));
			putValue(Action.NAME, RmResources.getMessage("RmMainFrame.onHelp.Name"));
			setAlwaysSelected(true);
		}
	};

	public static EodispAction onConnectRepos = new EodispAction() {
		{
			setTopMenuItemName(RmResources.getMessage("RmMainFrame.Menu.Repository.Name"));
			putValue(Action.NAME, RmResources.getMessage("RmMainFrame.onConnectRepos.Name"));
			putValue(Action.SHORT_DESCRIPTION, RmResources.getMessage("RmMainFrame.onConnectRepos.ShortDesc"));
			setShowInToolBar(true);
			setToolBarIcon(RmResources.getIcon("32x32/actions/connect-creating.png"));
			putValue(Action.SMALL_ICON, SmResources.getIcon("16x16/actions/connect-creating.png"));
			setToolBarIndex(10);
			setEnabled(true);
		}
	};

	/**
	 * The SaveAllAction saves all data in the application that have changes.
	 * Hence, every model in the application must be asked for changes and to
	 * save these changes as appropriate.
	 */
	public static EodispAction onSaveAll = new EodispAction() {
		{
			setTopMenuItemName(RmResources.getMessage("RmMainFrame.Menu.Repository.Name"));
			putValue(Action.NAME, RmResources.getMessage("RmMainFrame.onSaveAll.Name"));
			putValue(Action.SHORT_DESCRIPTION, RmResources.getMessage("RmMainFrame.onConnectRepos.ShortDesc"));
			putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_S, ActionEvent.CTRL_MASK));
			setShowInToolBar(true);
			setToolBarIcon(RmResources.getIcon("32x32/actions/up.png"));
			putValue(Action.SMALL_ICON, SmResources.getIcon("16x16/actions/up.png"));
			setToolBarIndex(11);
			setAlwaysSelected(true);
		}
	};

	/**
	 * This action is used to reload data from the repository.
	 */
	public static EodispAction onReloadRepos = new EodispAction() {
		{
			setTopMenuItemName(RmResources.getMessage("RmMainFrame.Menu.Repository.Name"));
			putValue(Action.NAME, RmResources.getMessage("RmMainFrame.onReloadRepos.Name"));
			putValue(Action.SHORT_DESCRIPTION, RmResources.getMessage("RmMainFrame.onReloadRepos.ShortDesc"));
			setShowInToolBar(true);
			setToolBarIcon(RmResources.getIcon("32x32/actions/down.png"));
			putValue(Action.SMALL_ICON, SmResources.getIcon("16x16/actions/down.png"));
			setToolBarIndex(12);
			setEnabled(false);
		}
	};

	/**
	 * The action saves the current project tree to the XML file.
	 */
	// public static EodispAction onSaveProject = new SaveProjectAction();
	/**
	 * Default constructor.
	 */
	public RmMainFrame() {
		super();
		updateTitle();

		setIconImage(SmResources.getAppImage());
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void registerActions() {
		EodispActionRegistry.getInstance().registerAction(onExitApp);
		EodispActionRegistry.getInstance().registerAction(onPrefs);
		// EodispActionRegistry.getInstance().registerAction(onAbout);
		// EodispActionRegistry.getInstance().registerAction(onHelp);
		EodispActionRegistry.getInstance().registerAction(onConnectRepos);
		EodispActionRegistry.getInstance().registerAction(onSaveAll);
		EodispActionRegistry.getInstance().registerAction(onReloadRepos);
	}

	public void updateRegistrations() {
		if (RmAppUtils.isConnected()) {
			onConnectRepos.setEnabled(false);
			onReloadRepos.setEnabled(true);
		} else {
			onConnectRepos.setEnabled(true);
			onReloadRepos.setEnabled(false);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void addDynamicView(EodispView dynView) {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void updateTitle(String... strings) {
		StringBuffer buf = new StringBuffer();
		buf.append(TITLE);

		for (String s : strings) {
			buf.append(" - ");
			buf.append(s);
		}

		setTitle(buf.toString());
	}
}
