/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.rm.views;

import java.awt.Component;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.*;

import org.apache.log4j.Logger;
import org.eodisp.ui.common.actions.*;
import org.eodisp.ui.common.base.EodispView;
import org.eodisp.ui.common.binding.SdoListModel;
import org.eodisp.ui.common.components.EodispListCellRenderer;
import org.eodisp.ui.rm.models.ReposModel;
import org.eodisp.ui.rm.resources.RmResources;

import com.jgoodies.binding.adapter.BasicComponentFactory;
import com.jgoodies.binding.list.SelectionInList;
import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.factories.FormFactory;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

/**
 * This is the configuration view for the SOM's currently available in the
 * repository.
 * 
 * @author eglimi
 * @version $Id:$
 */
public class RmSomsView extends EodispView implements ActionSourceProvider {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(RmSomsView.class);

	/**
	 * default serial version id.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * The static id used to identify this view.
	 */
	public static final int ID = 13;

	private static final String TITLE = RmResources.getMessage("RmSomsView.View.Title");

	private SelectionInList selectionInList = null;

	public static final EodispAction onAddSom = new EodispAction() {
		{
			setShowInContextMenu(true);
			setShowInMenuBar(false);
			putValue(Action.NAME, RmResources.getMessage("RmSomsView.onAddSom.Name"));
			putValue(Action.SHORT_DESCRIPTION, RmResources.getMessage("RmSomsView.onAddSom.ShortDesc"));
			setEnabled(true);
		}
	};

	public static final EodispAction onHandleCategoriesSom = new EodispAction() {
		{
			setShowInContextMenu(true);
			setShowInMenuBar(false);
			putValue(Action.NAME, RmResources.getMessage("RmSomsView.onHandleCategories.Name"));
			putValue(Action.SHORT_DESCRIPTION, RmResources.getMessage("RmSomsView.onHandleCategories.ShortDesc"));
			setEnabled(true);
		}
	};

	public static final EodispAction onDeleteSom = new EodispAction() {
		{
			setShowInContextMenu(true);
			setShowInMenuBar(false);
			putValue(Action.NAME, RmResources.getMessage("RmSomsView.onDeleteSom.Name"));
			putValue(Action.SHORT_DESCRIPTION, RmResources.getMessage("RmSomsView.onDeleteSom.ShortDesc"));
			putValue(Action.SMALL_ICON, RmResources.getIcon("16x16/actions/delete.png"));
			setEnabled(true);
		}
	};

	public static final EodispAction onDownloadSom = new EodispAction() {
		{
			setShowInContextMenu(true);
			setShowInMenuBar(false);
			putValue(Action.NAME, RmResources.getMessage("RmSomsView.onDownloadSom.Name"));
			putValue(Action.SHORT_DESCRIPTION, RmResources.getMessage("RmSomsView.onDownloadSom.ShortDesc"));
			setEnabled(true);
		}
	};

	/**
	 * This is the main panel that will hold all other components. It will be
	 * embedded in a scroll pane.
	 */
	private JPanel mainPanel;

	/**
	 * This is the main scroll pane that will be shown as the view's component.
	 */
	private final JScrollPane scrollPane = new JScrollPane();

	// Below are the elements used in this view
	/**
	 * Shows a list of SOMs
	 */
	private JList somsList;

	/**
	 * The scroll pane for list of SOMs
	 */
	private final JScrollPane somsListSp = new JScrollPane();

	private JTextField somPath;

	private JTextField somName;

	private JTextField somVersion;

	private JTextArea somDescription;

	/**
	 * Default constructor.
	 */
	public RmSomsView() {
		super();

		registerActions();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getId() {
		return ID;
	}

	@Override
	public String getTitle() {
		return TITLE;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Component getInternalComponent() {
		return scrollPane;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void initializeComponents() {
		// the list with the soms
		selectionInList = new SelectionInList(getSomsModel().getSomsListModel());
		SdoListModel presentationModel = new SdoListModel(selectionInList.getSelectionHolder());

		presentationModel.addPropertyChangeListener(new ListDetailPropertyChangeHandler());

		somsList = BasicComponentFactory.createList(selectionInList, new EodispListCellRenderer());
		somsList.setModel(selectionInList);

		somsList.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				if (e.isPopupTrigger()) {
					handlePopup(e);
				}
			}

			@Override
			public void mousePressed(MouseEvent e) {
				if (e.isPopupTrigger()) {
					handlePopup(e);
				}
			}
		});

		// create components
		somPath = BasicComponentFactory.createTextField(presentationModel.getModel(ReposModel.SOM_FILE_NAME), true);
		somPath.setEditable(false);
		somName = BasicComponentFactory.createTextField(presentationModel.getModel(ReposModel.SOM_NAME), true);
		somVersion = BasicComponentFactory.createTextField(presentationModel.getModel(ReposModel.SOM_VERSION), true);
		somDescription = BasicComponentFactory.createTextArea(presentationModel.getModel(ReposModel.SOM_DESCRIPTION),
				true);

		somsListSp.setViewportView(somsList);

		// set specific behavior
		somDescription.setLineWrap(true);
		somDescription.setWrapStyleWord(true);

		// create the layout
		CellConstraints cc = new CellConstraints();
		FormLayout layout = new FormLayout(
				"right:50dlu, 4dlu, 75dlu:grow, 10dlu, right:50dlu, 4dlu, 75dlu:grow, 4dlu, right:20dlu",
				"p, 3dlu, p, 1dlu, p, 3dlu, p, 1dlu, p, 3dlu, p, 1dlu, p, 3dlu, p, 1dlu, 100dlu, p:grow");
		PanelBuilder builder = new PanelBuilder(layout);
		builder.setDefaultDialogBorder();
		buildListPanel(builder, cc, layout);
		buildDetailsPanel(builder, cc, layout);

		logger.debug(String.format("added %d rows to the form.", new Integer(builder.getRowCount())));

		// get and set the panel
		mainPanel = builder.getPanel();
		scrollPane.setViewportView(mainPanel);
		setComponent(getInternalComponent());
	}

	private void handlePopup(MouseEvent e) {
		Object selectedObject = null;
		int selectionIndex = somsList.locationToIndex(e.getPoint());
		Rectangle rect = somsList.getCellBounds(selectionIndex, selectionIndex);
		if (rect != null && rect.contains(e.getPoint())) {
			selectedObject = getSomsModel().getSomsListModel().getElementAt(selectionIndex);
		}

		if (selectedObject != null) {
			somsList.setSelectedValue(selectedObject, false);
		}

		handleActionRegistrations(selectedObject == null ? null : new Object[] { selectedObject });

		JPopupMenu ctxMenu = EodispMenuManager.getInstance().getCtxMenu(this.getClass());
		// show it if something has been added
		if (ctxMenu.getComponents().length > 0) {
			ctxMenu.show(somsList, e.getX(), e.getY());
		}
	}

	private void buildListPanel(PanelBuilder builder, CellConstraints cc, FormLayout layout) {
		// SOMs
		builder.addSeparator(RmResources.getMessage("RmSomsView.Prop.Header.Som"), cc.xyw(builder.getColumn(), builder
				.getRow(), 3));
		builder.nextLine();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextLine();

		builder.add(somsListSp, cc.xywh(builder.getColumn(), builder.getRow(), 3, 17, "fill, fill"));
		builder.nextLine(17);
	}

	private void buildDetailsPanel(PanelBuilder builder, CellConstraints cc, FormLayout layout) {
		int labelCol = 5;
		int compCol = 7;
		builder.setRow(1);

		builder.addSeparator(RmResources.getMessage("RmSomsView.Prop.Header.SomDetail"), cc.xyw(labelCol, builder
				.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		// som path
		builder.addLabel(RmResources.getMessage("RmSomsView.Label1.Text"), cc.xyw(labelCol, builder.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.add(somPath, cc.xyw(labelCol, builder.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		// som name
		builder.addLabel(RmResources.getMessage("RmSomsView.Label2.Text"), cc.xyw(labelCol, builder.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.add(somName, cc.xyw(labelCol, builder.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		// som version
		builder.addLabel(RmResources.getMessage("RmSomsView.Label3.Text"), cc.xyw(labelCol, builder.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.add(somVersion, cc.xyw(labelCol, builder.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		// som description
		builder.addLabel(RmResources.getMessage("RmSomsView.Label4.Text"), cc.xyw(labelCol, builder.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.add(somDescription, cc.xyw(labelCol, builder.getRow(), 3, "fill, fill"));
	}

	/**
	 * Returns the Model for this view.
	 * 
	 * @return The model for this view.
	 */
	private ReposModel getSomsModel() {
		return (ReposModel) super.getModel();
	}

	/**
	 * {@inheritDoc}
	 */
	public void registerActions() {
		EodispActionRegistry.getInstance().registerAction(onAddSom, this.getClass());
		EodispActionRegistry.getInstance().registerAction(onHandleCategoriesSom, this.getClass());
		EodispActionRegistry.getInstance().registerAction(onDeleteSom, this.getClass());
		EodispActionRegistry.getInstance().registerAction(onDownloadSom, this.getClass());
	}

	/**
	 * {@inheritDoc}
	 */
	public void updateRegistrations() {
		handleActionRegistrations(somsList.getSelectedValues());
	}

	private void handleActionRegistrations(Object[] selections) {
		if (selections != null && selections.length == 1) {
			onDeleteSom.setEnabled(true);
			onDownloadSom.setEnabled(true);
			onDeleteSom.putValue(EodispAction.USER_OBJECT, selections[0]);
			onDownloadSom.putValue(EodispAction.USER_OBJECT, selections[0]);
			onHandleCategoriesSom.setEnabled(true);
			onHandleCategoriesSom.putValue(EodispAction.USER_OBJECT, selections[0]);
		} else {
			onDeleteSom.setEnabled(false);
			onDownloadSom.setEnabled(false);
			onHandleCategoriesSom.setEnabled(false);
		}
	}

	private class ListDetailPropertyChangeHandler implements PropertyChangeListener {

		public ListDetailPropertyChangeHandler() {
		}

		public void propertyChange(PropertyChangeEvent evt) {

			if (evt.getPropertyName().equalsIgnoreCase(SdoListModel.PROPERTYNAME_CHANGED)) {
				// update the list when the property in question changes
				somsList.updateUI();
			}

			// ignore otherwise
		}
	}
}
