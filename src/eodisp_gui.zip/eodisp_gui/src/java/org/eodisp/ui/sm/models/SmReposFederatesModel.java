/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.sm.models;

import java.util.ArrayList;
import java.util.List;

import javax.swing.table.AbstractTableModel;

import org.apache.log4j.Logger;
import org.eodisp.core.common.ReposServiceProxy;
import org.eodisp.core.gen.repository.impl.RepositoryPackageImpl;
import org.eodisp.core.sm.application.SmAppModuleCore;
import org.eodisp.core.sm.helper.SmEmfHelper;
import org.eodisp.ui.common.components.AbstractEodispModel;
import org.eodisp.util.AppRegistry;

import commonj.sdo.DataObject;

/**
 * @author eglimi
 * @version $Id:$
 */
public class SmReposFederatesModel extends AbstractEodispModel {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(SmReposFederatesModel.class);

	// strings used for the binding
	public static final String FED_NAME = "name";

	public static final String FED_DESCRIPTION = "description";

	public static final String FED_EXEC_NAME = "name";

	public static final String FED_EXEC_PATH = "localPath";

	private final FederatesTableModel tableModel = new FederatesTableModel();

	/**
	 * Default constructor.
	 */
	public SmReposFederatesModel() {
	}

	/**
	 * {@inheritDoc}
	 */
	public void doSave() {
		// nothing to save here. It is only to choose.
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean hasChanges() {
		return false;
	}

	public FederatesTableModel getFederatesTableModel() {
		return tableModel;
	}

	private ReposServiceProxy getReposService() {
		return ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(SmAppModuleCore.ID)).getReposServiceProxy();
	}

	public class FederatesTableModel extends AbstractTableModel {
		private List<DataObject> delegate = new ArrayList<DataObject>();

		public int getColumnCount() {
			return 3;
		}

		public int getRowCount() {
			if (delegate.size() <= 0) {
				final ReposServiceProxy service = getReposService();
				if (service != null) {
					List<DataObject> federates = SmEmfHelper.findAllFederates(service.getRootObject());

					for (DataObject federate : federates) {
						delegate.add(federate);
					}
				}
			}
			return delegate.size();
		}

		public Object getValueAt(int rowIndex, int columnIndex) {
			if (delegate.size() - 1 >= rowIndex) {
				switch (columnIndex) {
				case 0:
					// federate name
					String name = delegate.get(rowIndex).getString(RepositoryPackageImpl.FEDERATE__BUNDLE_NAME);
					String version = delegate.get(rowIndex).getString(RepositoryPackageImpl.FEDERATE__BUNDLE_VERSION);
					return name + " (" + version + ")";
				case 1:
					// model manager name
					return SmEmfHelper.getName(delegate.get(rowIndex).getDataObject(
							RepositoryPackageImpl.FEDERATE__OWNING_MM));
				case 2:
					// SOM name
					DataObject som = delegate.get(rowIndex).getDataObject(RepositoryPackageImpl.FEDERATE__SOM);
					String somName = som.getString(RepositoryPackageImpl.SOM__NAME);
					String somVersion = som.getString(RepositoryPackageImpl.SOM__VERSION);
					return somName + " (" + somVersion + ")";
				default:
					return null;
				}
			}

			return null;
		}

		@Override
		public String getColumnName(int column) {
			switch (column) {
			case 0:
				return "Federate";
			case 1:
				return "Model Manager";
			case 2:
				return "SOM";
			}

			return "";
		}
		
		public DataObject getRowObject(int rowIndex) {
			if (delegate.size() - 1 >= rowIndex) {
				return delegate.get(rowIndex);
			}

			return null;
		}
	}
}
