/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com
 *  mail: info@pnp-software.com
 */
package org.eodisp.ui.common.components;

import javax.swing.JSplitPane;

/**
 * This class is just a wrapper for a <code>JSplitPane</code> to use in an
 * EODiSP application. It defines some default behaviour for use in the EODiSP
 * framework.
 * <p>
 * Remember that the sequence of adding components to a panel is important in
 * Swing, because they are automatically places. Therefore, a split pane must be
 * added to the panel <i>after</i> the first component and <i>before</i> the
 * second component. This class is just a wrapper for a <code>JSplitPane</code>
 * to use in an EODiSP application.
 * <p>
 * See {@link javax.swing.JSplitPane} for more informations.
 * 
 * @author eglimi
 * @version $Id:EodispSplitPane.java 2134 2006-05-16 08:43:27Z eglimi $
 * 
 */
public class EodispSplitPane extends JSplitPane {

	/**
	 * default serial version id.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Defines how a split pane should be placed. This is either horizontally or
	 * vertically, depending on the actual need.
	 * 
	 * @author eglimi
	 * @version $Id:EodispSplitPane.java 2134 2006-05-16 08:43:27Z eglimi $
	 * 
	 */
	public enum SplitLocation {
		HORIZONTAL, VERTICAL
	}

	/**
	 * Default constructor.
	 * 
	 * @param location
	 *            Specifies how the split pane should be placed.
	 * 
	 * 
	 */
	public EodispSplitPane(SplitLocation location) {
		super();
		setSplitLocation(location);
		setBehavior();
	}

	/**
	 * Defines the location of the split pane. This can be either horizontally
	 * or vertically.
	 * 
	 * @param location
	 *            The location defining how the split pane should be placed.
	 */
	private void setSplitLocation(SplitLocation location) {
		switch (location) {
		case HORIZONTAL:
			setOrientation(JSplitPane.HORIZONTAL_SPLIT);
			break;
		case VERTICAL:
			setOrientation(JSplitPane.VERTICAL_SPLIT);
			break;
		}
	}

	/**
	 * Sets the basic behavior of a split pane used in the EODiSP user
	 * interface.
	 * 
	 */
	private void setBehavior() {
		// Do not add this triangles in the middle of the split pane to
		// collapse/expand the panel.
		setOneTouchExpandable(false);
		setFocusable(false);
		setVisible(true);
	}
}
