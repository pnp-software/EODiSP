package org.eodisp.ui.mm.models;

import java.io.IOException;

import org.eclipse.emf.ecore.sdo.EChangeSummary;
import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eodisp.core.common.ReposServiceProxy;
import org.eodisp.core.mm.application.MmAppModuleCore;
import org.eodisp.core.mm.helper.MmEmfHelper;
import org.eodisp.core.mm.service.Federate;
import org.eodisp.ui.common.components.AbstractEodispModel;
import org.eodisp.ui.mm.application.MmAppUtils;
import org.eodisp.ui.mm.views.MmFederateInfoDialog;
import org.eodisp.util.AppRegistry;

/**
 * This is the model for the {@link MmFederateInfoDialog} dialog.
 * 
 * @author eglimi
 * @version $Id:$
 * 
 */
public class MmFederateInfoModel extends AbstractEodispModel {

	private final Federate federate;

	/**
	 * Constructor.
	 * 
	 * @param federate
	 *            The federate for which information should be received or
	 *            stored.
	 */
	public MmFederateInfoModel(Federate federate) {
		this.federate = federate;
	}

	/**
	 * 
	 * {@inheritDoc}
	 */
	public void doSave() throws IOException {
		if (getReposService() != null) {
			getReposService().save();
		}
	}

	/**
	 * 
	 * {@inheritDoc}
	 */
	public boolean hasChanges() {
		if (getReposService() != null) {
			return getReposService().isDirty();
		}

		return false;
	}

	/**
	 * 
	 * {@inheritDoc}
	 */
	@Override
	public void undo() {
		ReposServiceProxy service = getReposService();
		if (service != null) {
			EDataObject reposRoot = service.getRootObject();
			EChangeSummary cs = (EChangeSummary) reposRoot.getDataGraph().getChangeSummary();
			if (cs != null && cs.isLogging()) {
				cs.summarize();
			}
			cs.apply();
		}
	}

	/**
	 * Returns the information text stored in the repository together with the
	 * federate.
	 * <p>
	 * In order to get this text, the application must be connected to the
	 * repository and the federate must be registered.
	 * 
	 * @return the additional information associated with the federate.
	 */
	public String getInfoText() {
		ReposServiceProxy service = getReposService();
		if (service != null) {
			return MmEmfHelper.getFederateInfoText(service.getRootObject(), federate.getFederateId(), federate
					.getFederateVersion());
		}

		return "";
	}

	/**
	 * Sets the information text stored in the repository together with the
	 * federate.
	 * <p>
	 * In order to set this text, the application must be connected to the
	 * repository and the federate must be registered.
	 * 
	 * @param infoText
	 *            the additional information to be associated with the federate.
	 */
	public void setInfoText(String infoText) {
		ReposServiceProxy service = getReposService();
		if (service != null) {
			MmEmfHelper.setFederateInfoText(service.getRootObject(), federate.getFederateId(), federate
					.getFederateVersion(), infoText);
		}

	}

	/**
	 * Returns the repository service. This is only a convenience method.
	 * 
	 * @return The repository service or null, if there is no connection.
	 */
	private ReposServiceProxy getReposService() {
		if (MmAppUtils.isConnected()) {
			return ((MmAppModuleCore) AppRegistry.getRootApp().getAppModule(MmAppModuleCore.ID)).getReposServiceProxy();
		}

		return null;
	}

}
