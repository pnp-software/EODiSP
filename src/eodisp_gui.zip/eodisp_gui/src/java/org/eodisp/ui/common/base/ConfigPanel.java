/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.common.base;

import javax.swing.JPanel;

/**
 * This interface should be implemented by all panels that are used to configura
 * an application. These panels will be shown in an settings dialog.
 * 
 * @author eglimi
 * @version $Id:$
 * 
 */
public interface ConfigPanel {

	/**
	 * 
	 * Returns the complete panel. Note that the panel should not be added to a
	 * <code>JScrollPane</code>, since this will be done in the showing
	 * component (i.e. the settings dialog).
	 */
	JPanel getPanel();

	/**
	 * Sets the model for the config panel. The model is a ordinary
	 * <code>EodispModel</code>
	 * 
	 * @param model
	 *            The model for the config panel
	 */
	void setModel(EodispModel model);

	/**
	 * Returns the model for the config panel.
	 * 
	 * @return The model for the config panel.
	 */
	EodispModel getModel();
}
