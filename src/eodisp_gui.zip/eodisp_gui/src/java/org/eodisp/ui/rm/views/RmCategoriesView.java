/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.rm.views;

import java.awt.Component;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.*;

import org.apache.log4j.Logger;
import org.eodisp.ui.common.actions.*;
import org.eodisp.ui.common.base.EodispView;
import org.eodisp.ui.common.binding.SdoListModel;
import org.eodisp.ui.common.components.EodispListCellRenderer;
import org.eodisp.ui.rm.models.ReposModel;
import org.eodisp.ui.rm.resources.RmResources;

import com.jgoodies.binding.adapter.BasicComponentFactory;
import com.jgoodies.binding.list.SelectionInList;
import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.factories.FormFactory;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

/**
 * This is the configuration view for the categories currently available in the
 * repository.
 * 
 * @author eglimi
 * @version $Id:$
 */
public class RmCategoriesView extends EodispView implements ActionSourceProvider {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(RmCategoriesView.class);

	/**
	 * default serial version id.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * The static id used to identify this view.
	 */
	public static final int ID = 10;

	private static final String TITLE = RmResources.getMessage("RmCategoriesView.View.Title");

	private SelectionInList selectionInList = null;

	public static final EodispAction onAddCategory = new EodispAction() {
		{
			setShowInContextMenu(true);
			setShowInMenuBar(false);
			putValue(Action.NAME, RmResources.getMessage("RmCategoriesView.onAddCategory.Name"));
			putValue(Action.SHORT_DESCRIPTION, RmResources.getMessage("RmCategoriesView.onAddCategory.ShortDesc"));
			setEnabled(true);
		}
	};

	public static final EodispAction onDeleteCategory = new EodispAction() {
		{
			setShowInContextMenu(true);
			setShowInMenuBar(false);
			putValue(Action.NAME, RmResources.getMessage("RmCategoriesView.onDeleteCategory.Name"));
			putValue(Action.SHORT_DESCRIPTION, RmResources.getMessage("RmCategoriesView.onDeleteCategory.ShortDesc"));
			putValue(Action.SMALL_ICON, RmResources.getIcon("16x16/actions/delete.png"));
			setEnabled(true);
		}
	};

	private final JScrollPane scrollPane = new JScrollPane();

	private final JScrollPane catListSP = new JScrollPane();

	private JPanel mainPanel;

	private JList catList;

	private JTextField catName;

	private JTextArea catDescription;

	private JCheckBox catClosed;

	/**
	 * Default constructor.
	 */
	public RmCategoriesView() {
		super();

		registerActions();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getId() {
		return ID;
	}

	@Override
	public String getTitle() {
		return TITLE;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Component getInternalComponent() {
		return scrollPane;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void initializeComponents() {

		// the list with the categories
		selectionInList = new SelectionInList(getCatModel().getCatListModel());
		SdoListModel presentationModel = new SdoListModel(selectionInList.getSelectionHolder());

		presentationModel.addPropertyChangeListener(new ListDetailPropertyChangeHandler());

		catList = BasicComponentFactory.createList(selectionInList, new EodispListCellRenderer());
		catList.setModel(selectionInList);

		catList.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				if (e.isPopupTrigger()) {
					handlePopup(e);
				}
			}

			@Override
			public void mousePressed(MouseEvent e) {
				if (e.isPopupTrigger()) {
					handlePopup(e);
				}
			}
		});

		// create components
		catName = BasicComponentFactory.createTextField(presentationModel.getModel(ReposModel.CAT_NAME), true);
		catDescription = BasicComponentFactory.createTextArea(presentationModel.getModel(ReposModel.CAT_DESCRIPTION),
				true);
		catClosed = BasicComponentFactory.createCheckBox(presentationModel.getModel(ReposModel.CAT_CLOSED), "");

		catListSP.setViewportView(catList);

		// set special behavior
		catDescription.setLineWrap(true);
		catDescription.setWrapStyleWord(true);

		// create the layout
		CellConstraints cc = new CellConstraints();
		FormLayout layout = new FormLayout(
				"right:50dlu, 4dlu, 75dlu:grow, 4dlu, right:50dlu, 4dlu, 75dlu:grow, 4dlu, right:20dlu",
				"p, 3dlu, p, 1dlu, p, 3dlu, p, 1dlu, 100dlu, 3dlu, p, 1dlu, p, p:grow");
		PanelBuilder builder = new PanelBuilder(layout);
		builder.setDefaultDialogBorder();
		buildListPanel(builder, cc, layout);
		buildDetailsPanel(builder, cc, layout);

		logger.debug(String.format("added %d rows to the form.", new Integer(builder.getRowCount())));

		// get and set the panel
		mainPanel = builder.getPanel();
		scrollPane.setViewportView(mainPanel);
		setComponent(getInternalComponent());
	}

	private void handlePopup(MouseEvent e) {
		Object selectedObject = null;
		int selectionIndex = catList.locationToIndex(e.getPoint());
		Rectangle rect = catList.getCellBounds(selectionIndex, selectionIndex);
		if (rect != null && rect.contains(e.getPoint())) {
			selectedObject = getCatModel().getCatListModel().getElementAt(selectionIndex);
		}

		if (selectedObject != null) {
			catList.setSelectedValue(selectedObject, false);
		}

		handleActionRegistrations(selectedObject == null ? null : new Object[] { selectedObject });

		JPopupMenu ctxMenu = EodispMenuManager.getInstance().getCtxMenu(this.getClass());
		// show it if something has been added
		if (ctxMenu.getComponents().length > 0) {
			ctxMenu.show(catList, e.getX(), e.getY());
		}
	}

	private void buildListPanel(PanelBuilder builder, CellConstraints cc, FormLayout layout) {
		// SOMs
		builder.addSeparator(RmResources.getMessage("RmCategoriesView.Prop.Header.Cat"), cc.xyw(builder.getColumn(),
				builder.getRow(), 3));
		builder.nextLine();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextLine();

		builder.add(catListSP, cc.xywh(builder.getColumn(), builder.getRow(), 3, 12, "fill, fill"));
		builder.nextLine(12);
	}

	private void buildDetailsPanel(PanelBuilder builder, CellConstraints cc, FormLayout layout) {
		int labelCol = 5;
		builder.setRow(1);

		// SOM Infos
		builder.addSeparator(RmResources.getMessage("RmCategoriesView.Prop.Header.CatDetail"), cc.xyw(labelCol, builder
				.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		// cat name
		builder.addLabel(RmResources.getMessage("RmCategoriesView.Label1.Text"), cc.xyw(labelCol, builder.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.add(catName, cc.xyw(labelCol, builder.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		// cat description
		builder.addLabel(RmResources.getMessage("RmCategoriesView.Label2.Text"), cc.xyw(labelCol, builder.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.add(catDescription, cc.xyw(labelCol, builder.getRow(), 3, "fill, fill"));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		// cat closed
		builder.addLabel(RmResources.getMessage("RmCategoriesView.Label3.Text"), cc.xyw(labelCol, builder.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.add(catClosed, cc.xyw(labelCol, builder.getRow(), 3));
	}

	/**
	 * Returns the Model for this view.
	 * 
	 * @return The model for this view.
	 */
	private ReposModel getCatModel() {
		return (ReposModel) super.getModel();
	}

	/**
	 * {@inheritDoc}
	 */
	public void registerActions() {
		EodispActionRegistry.getInstance().registerAction(onAddCategory, this.getClass());
		EodispActionRegistry.getInstance().registerAction(onDeleteCategory, this.getClass());
	}

	/**
	 * {@inheritDoc}
	 */
	public void updateRegistrations() {
		handleActionRegistrations(catList.getSelectedValues());
	}

	private void handleActionRegistrations(Object[] selections) {
		if (selections != null && selections.length == 1) {
			onDeleteCategory.setEnabled(true);
			onDeleteCategory.putValue(EodispAction.USER_OBJECT, selections[0]);
		} else {
			onDeleteCategory.setEnabled(false);
		}
	}

	private class ListDetailPropertyChangeHandler implements PropertyChangeListener {

		public ListDetailPropertyChangeHandler() {
		}

		public void propertyChange(PropertyChangeEvent evt) {

			if (evt.getPropertyName().equalsIgnoreCase(SdoListModel.PROPERTYNAME_CHANGED)) {
				// update the list when the property in question changes
				catList.updateUI();
			}

			// ignore otherwise
		}
	}
}
