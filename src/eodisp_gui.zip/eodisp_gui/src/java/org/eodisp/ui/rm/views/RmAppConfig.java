/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.rm.views;

import javax.swing.JPanel;
import javax.swing.JTextField;

import org.apache.log4j.Logger;
import org.eodisp.ui.common.base.EodispModel;
import org.eodisp.ui.common.binding.ConfigAdapter;
import org.eodisp.ui.common.components.AbstractConfigPanel;
import org.eodisp.ui.mm.resources.MmResources;
import org.eodisp.ui.rm.config.RmGuiConfiguration;
import org.eodisp.ui.rm.models.RmAppConfigModel;
import org.eodisp.ui.rm.resources.RmResources;
import org.eodisp.util.configuration.Configuration;

import com.jgoodies.binding.adapter.BasicComponentFactory;
import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.factories.FormFactory;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

/**
 * This is a panel to configure the general settings for the application.
 * 
 * @author eglimi
 * @version $Id:$
 */
public class RmAppConfig extends AbstractConfigPanel {

	/**
	 * Default serial version id
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(RmAppConfig.class);

	private JPanel configPanel;

	private JTextField reposUri;

	/**
	 * Default constructor.
	 * 
	 * @param model
	 *            The model to be used for this panel.
	 */
	public RmAppConfig(EodispModel model) {
		super(model);

		CellConstraints cc = new CellConstraints();
		FormLayout layout = new FormLayout("left:pref, 4dlu, 75dlu:grow", "p, 3dlu, p");
		PanelBuilder builder = new PanelBuilder(layout);
		builder.setDefaultDialogBorder();

		initializeComponents();

		buildPanel(cc, layout, builder);
		configPanel = builder.getPanel();
	}

	/**
	 * {@inheritDoc}
	 */
	public JPanel getPanel() {
		return configPanel;
	}

	/**
	 * Does all the initialization of the components.
	 */
	private void initializeComponents() {
		Configuration config = ((RmAppConfigModel) getModel()).getConfigurator();

		// create components
		reposUri = BasicComponentFactory.createTextField(new ConfigAdapter(config, RmGuiConfiguration.REPOS_URI), true);
	}

	/**
	 * Builds the complete panel.
	 * 
	 * @param cc
	 *            The cell constraints.
	 * @param layout
	 *            The layout.
	 * @param builder
	 *            The builder that is used to build the panel.
	 */
	private void buildPanel(CellConstraints cc, FormLayout layout, PanelBuilder builder) {
		int leftCol = 1;
		int compCol = 3;

		builder.setRow(1);

		// Repository Settings
		builder.addSeparator(RmResources.getMessage("RmAppConfig.Prop.Header.ReposSettings"), cc.xyw(leftCol, builder
				.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addLabel(RmResources.getMessage("RmAppConfig.Prop.ReposUri"), cc.xy(leftCol, builder.getRow()));
		builder.add(reposUri, cc.xy(compCol, builder.getRow()));
	}
}
