/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.sm.views;

import java.awt.Component;

import javax.swing.*;

import org.apache.log4j.Logger;
import org.eodisp.ui.common.base.EodispView;
import org.eodisp.ui.common.base.UIUtil;

import com.jgoodies.forms.builder.ButtonStackBuilder;

/**
 * This is a sample panel to be used to control an experiment (start, stop,
 * etc.). This panel is not yet included in simulation manager.
 * <p>
 * To include the panel, the mechanism to update the registration would be
 * changed. At the moment, actions are enabled/disabled when selecting a menu or
 * pop-up. When this panel would be used, updating these actions would have to
 * work without selecting anything.
 * <p>
 * This panel now uses stacked buttons. The buttons need to be aligned (because
 * some have icons). See {@link UIUtil#align(MenuElement)} for another example
 * on how to align something.
 * 
 * @author eglimi
 * @version $Id:$
 * 
 */
public class ExperimentControlView extends EodispView {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(ExperimentControlView.class);

	private final String TITLE = "todo";

	private JPanel mainPanel;

	private final JScrollPane scrollPane = new JScrollPane();

	public static final int ID = 12;

	private final JButton[] buttons = new JButton[7];

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getId() {
		return ID;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Component getInternalComponent() {
		return scrollPane;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void initializeComponents() {
		buttons[0] = new JButton(SmExpTreeView.onExperimentPrepare);
		buttons[1] = new JButton(SmExpTreeView.onExperimentStart);
		buttons[2] = new JButton(SmExpTreeView.onExperimentPause);
		buttons[3] = new JButton(SmExpTreeView.onNextStep);
		buttons[4] = new JButton(SmExpTreeView.onExperimentResume);
		buttons[5] = new JButton(SmExpTreeView.onExperimentKill);
		buttons[6] = new JButton(SmExpTreeView.onExperimentReset);

		for (JButton button : buttons) {
			button.setHorizontalAlignment(SwingConstants.LEFT);
		}

		setComponent(getInternalComponent());

		ButtonStackBuilder stackBuilder = new ButtonStackBuilder();
		stackBuilder.addButtons(buttons);

		mainPanel = stackBuilder.getPanel();
		scrollPane.setViewportView(mainPanel);
	}

}
