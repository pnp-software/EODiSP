/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.shared.models;

import java.io.File;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.eodisp.remote.config.RemoteConfiguration;
import org.eodisp.remote.util.NetworkConfigurator;
import org.eodisp.ui.common.components.AbstractEodispModel;
import org.eodisp.ui.common.resources.CommonMessageBoxes;
import org.eodisp.util.AppRegistry;

/**
 * @author eglimi
 * @version $Id:$
 * 
 */
public class JxtaConfigModel extends AbstractEodispModel {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(JxtaConfigModel.class);

	public static final String PROPERTY_NAME = "name";

	public static final String PROPERTY_DESCRIPTION = "description";

	public static final String PROPERTY_TCP_ENABLED = "tcpEnabled";

	public static final String PROPERTY_TCP_INCOMING = "tcpIncoming";

	public static final String PROPERTY_TCP_OUTGOING = "tcpOutgoing";

	public static final String PROPERTY_TCP_PORT = "tcpPort";

	public static final String PROPERTY_TCP_START_PORT = "tcpStartPort";

	public static final String PROPERTY_TCP_END_PORT = "tcpEndPort";

	public static final String PROPERTY_TCP_INTERFACE_ADDRESS = "tcpInterfaceAddress";

	public static final String PROPERTY_TCP_PUBLIC_ADDRESS = "tcpPublicAddress";

	public static final String PROPERTY_TCP_PUBLIC_ADDRESS_EXCLUSIVE = "tcpPublicAddressExclusive";

	public static final String PROPERTY_USE_MULTICAST = "useMulticast";

	public static final String PROPERTY_MULTICAST_ADDRESS = "multicastAddress";

	public static final String PROPERTY_MULTICAST_PORT = "multicastPort";

	public static final String PROPERTY_MULTICAST_SIZE = "multicastSize";

	public static final String PROPERTY_HTTP_ENABLED = "httpEnabled";

	public static final String PROPERTY_HTTP_INCOMING = "httpIncoming";

	public static final String PROPERTY_HTTP_OUTGOING = "httpOutgoing";

	public static final String PROPERTY_HTTP_PORT = "httpPort";

	public static final String PROPERTY_HTTP_PUBLIC_ADDRESS = "httpPublicAddress";

	public static final String PROPERTY_HTTP_PUBLIC_ADDRESS_EXCLUSIVE = "httpPublicAddressExclusive";

	public static final String PROPERTY_HTTP_INTERFACE_ADDRESS = "httpInterfaceAddress";

	public static final String PROPERTY_RELAY_ENABLED = "relayEnabled";

	public static final String PROPERTY_RELAY_SERVER = "relayServer";

	public static final String PROPERTY_RELAY_CLIENT = "relayClient";

	public static final String PROPERTY_RELAY_MAX_CLIENTS = "relayMaxClients";

	public static final String PROPERTY_USE_ONLY_RELAY_SEEDS = "useOnlyRelaySeeds";

	public static final String PROPERTY_RENDEZVOUS_ENABLED = "rendezvousEnabled";

	public static final String PROPERTY_RENDEZVOUS_MAX_CLIENTS = "rendezvousMaxClients";

	public static final String PROPERTY_USE_ONLY_RENDEZVOUS_SEEDS = "useOnlyRendezvousSeeds";

	// public static final String PROPERTY_RDV_SEEDING_URI = "rdvSeedingURI";

	public static final String PROPERTY_PRINCIPAL = "principal";

	public static final String PROPERTY_PASSWORD = "password";

	public static final String PROPERTY_PROXY_ENABLED = "proxyEnabled";

	// public static final String PROPERTY_HOME = "home";

	private NetworkConfigurator networkConfigurator;

	public JxtaConfigModel() {
		createNetworkConfigurator();
	}

	public void doSave() throws IOException {
		networkConfigurator.save(getRemoteConfigFile());
	}

	/**
	 * 
	 * {@inheritDoc}
	 */
	public void doUpdate() {
		// TODO Auto-generated method stub
	}

	public boolean hasChanges() {
		return networkConfigurator.hasChanges();
	}

	public void redo() {
		// redo not supported. Ignore
	}

	public void undo() {
		networkConfigurator = null;
	}

	public NetworkConfigurator getNetworkConfigurator() {
		return networkConfigurator;
	}

	private void createNetworkConfigurator() {
		try {
			networkConfigurator = NetworkConfigurator.loadPlatformConfig(getRemoteConfigFile().toURI());
		} catch (IOException ex) {
			CommonMessageBoxes.showLoadError(null, ex.getMessage());
		}
	}

	private File getRemoteConfigFile() {
		return ((RemoteConfiguration) AppRegistry.getRootApp().getConfiguration(RemoteConfiguration.ID))
				.getJxtaPlatformConfig();
	}
}
