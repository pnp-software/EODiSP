/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.common.binding;

import java.lang.reflect.Constructor;
import java.util.List;

import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.sdo.EDataObject;

import com.jgoodies.binding.adapter.Bindings;
import com.jgoodies.binding.value.AbstractValueModel;
import commonj.sdo.DataObject;

/**
 * This is an adapter for {@link DataObject}'s. It can be used to bind the
 * properties of such an object to a component.
 * 
 * @see Bindings
 * 
 * @author eglimi
 * @version $Id:$
 * 
 */
public class DataObjectAdapter extends AbstractValueModel {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(DataObjectAdapter.class);

	/**
	 * default serial version id.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * The data object itself. It holds the value of the property.
	 */
	private EDataObject dataObject;

	/**
	 * The index of the property. Defaults to -1, which means that the requested
	 * property was not found.
	 */
	private int propertyIndex = -1;

	private EClassifier type;

	/**
	 * Default constructor.
	 * 
	 * @param dataSource
	 *            The data object that holds the properties.
	 * @param propertyName
	 *            The name of the property that will be used for the binding.
	 *            The data object must hold a property with this name.
	 * @exception IllegalArgumentException
	 *                Thrown if either the data object is null or if it does not
	 *                hold a property with the given name.
	 */
	@SuppressWarnings("unchecked")
	public DataObjectAdapter(Object dataSource, String propertyName) throws IllegalArgumentException {
		if (dataSource == null) {
			throw new IllegalArgumentException(
					"The configuration object you have provided is null. This is not valid since we must be able to get and set configuration values on this object");
		}

		if (!(dataSource instanceof EDataObject)) {
			throw new IllegalArgumentException("The data object you have provided must be of type EDataObject");
		}

		this.dataObject = (EDataObject) dataSource;

		List<Object> props = dataObject.getInstanceProperties();
		for (int i = 0; i < props.size(); i++) {
			if (propertyIndex == -1) {
				Object obj = props.get(i);
				if (obj instanceof EAttribute) {
					EAttribute prop = (EAttribute) props.get(i);
					// ignore many properties
					if (!prop.isMany() && prop.getName().equalsIgnoreCase(propertyName)) {
						propertyIndex = i;
						type = prop.getEType();
					}
				}
			}
		}

		if (propertyIndex == -1) {
			throw new IllegalArgumentException(
					String
							.format(
									"The data object (type '%s') that you have provided does not have an attribute with the name '%s' associated",
									dataObject.getClass().getName(),
									propertyName));
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public Object getValue() {
		return dataObject.get(propertyIndex);
	}

	/**
	 * {@inheritDoc}
	 */
	public void setValue(Object stringValue) {
		// if (((String) stringValue).equalsIgnoreCase("")) {
		// return;
		// }
		Object newValue = null;

		Class ic = type.getInstanceClass();
		if (ic == null) {
			return;
		}

		if (ic != null) {
			Constructor cons;

			try {
				cons = ic.getConstructor(new Class[] { String.class });

			} catch (NoSuchMethodException nsme) {
				cons = null;
			}

			if (cons != null) {
				try {
					newValue = cons.newInstance(new Object[] { stringValue.toString() });
				} catch (Throwable ex) {
					logger.warn(String.format("Could not set the property because there was an error "
							+ "when creating a new instance of type %s with the string value %s", type
							.getInstanceClassName(), stringValue), ex);
					return;
				}
			}
		}

		Object oldValue = getValue();
		dataObject.set(propertyIndex, newValue);
		fireValueChange(oldValue, newValue.toString());
	}

	/**
	 * Returns the data object itself.
	 * 
	 * @return The data object.
	 */
	public DataObject getDataObject() {
		return dataObject;
	}
}
