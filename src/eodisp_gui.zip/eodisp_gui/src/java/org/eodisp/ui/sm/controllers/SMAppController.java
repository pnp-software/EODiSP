/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com
 *  mail: info@pnp-software.com
 */
package org.eodisp.ui.sm.controllers;

import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;

import javax.swing.JDialog;
import javax.swing.JOptionPane;

import net.infonode.docking.DockingWindow;
import net.infonode.docking.SplitWindow;
import net.infonode.docking.TabWindow;

import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eodisp.core.common.EmfUtil;
import org.eodisp.core.common.ReposServiceProxy;
import org.eodisp.core.sm.application.SmAppModuleCore;
import org.eodisp.core.sm.config.SmConfiguration;
import org.eodisp.core.sm.helper.SmEmfHelper;
import org.eodisp.core.sm.service.ExperimentTaskManager;
import org.eodisp.core.sm.service.SmModelServiceProxy;
import org.eodisp.ui.common.base.EodispApplicationController;
import org.eodisp.ui.common.base.EodispDelegate;
import org.eodisp.ui.common.base.EodispMainFrame;
import org.eodisp.ui.common.resources.CommonMessageBoxes;
import org.eodisp.ui.common.resources.MessageBoxHelper;
import org.eodisp.ui.shared.views.AboutDialog;
import org.eodisp.ui.shared.views.HelpDialog;
import org.eodisp.ui.sm.application.SmAppUtils;
import org.eodisp.ui.sm.resources.SmResources;
import org.eodisp.ui.sm.views.*;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.configuration.Configuration;

/**
 * This is the application controller for the EODiSP simulation manager
 * application. It is the main controller, which has control over the creation
 * of other controllers. It is therfore the controller of the application which
 * must exist in order to run the application.
 * <p>
 * Specific tasks which this controller is responsible for are:
 * <ul>
 * <li>Creation of other controllers used throughout this application.</li>
 * <li>Creation of the main frame used in this application. </li>
 * </ul>
 * <p>
 * The <code>SimulationManagerAppController</code> extends the more generic
 * <code>EodispApplicationController</code> and is only useful to handle the
 * specific part for the simulation manager application. All generic tasks are
 * handled and documented in the <code>EodispApplicationController</code>
 * class.
 * 
 * @author eglimi
 * @version $Id: SimulationManagerAppController.java 1436 2006-01-04 08:16:08Z
 *          eglimi $
 */
public class SMAppController extends EodispApplicationController {

	private EDataObject currentExperiment;

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(SMAppController.class);

	/**
	 * Default constructor.
	 */
	public SMAppController() {
		registerActionHandler();

		EDataObject experiment = ExperimentChooser.showExperimentDialog(null);
		if (experiment != null) {
			this.currentExperiment = experiment;
		} else {
			AppRegistry.getRootApp().shutdown();
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void initialize() {
		super.initialize();

		checkState();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eodisp.ui.common.base.EodispApplicationController#registerActionHandler()
	 */
	@Override
	public void registerActionHandler() {
		SmMainFrame.onSaveAll.registerTargetHandler(new EodispDelegate(this, "onSaveAll"));
		SmMainFrame.onExitApp.registerTargetHandler(new EodispDelegate(this, "onExitApp"));

		SmMainFrame.onAbout.registerTargetHandler(new EodispDelegate(this, "onAbout"));
		SmMainFrame.onHelp.registerTargetHandler(new EodispDelegate(this, "onHelp"));

		SmMainFrame.onConnectRepos.registerTargetHandler(new EodispDelegate(this, "onConnectRepos"));
		SmMainFrame.onReloadRepos.registerTargetHandler(new EodispDelegate(this, "onReloadRepos"));
		SmMainFrame.onRegisterApp.registerTargetHandler(new EodispDelegate(this, "onRegisterApp"));
		SmMainFrame.onUnregisterApp.registerTargetHandler(new EodispDelegate(this, "onUnregisterApp"));
		SmMainFrame.onUpdateRegistration.registerTargetHandler(new EodispDelegate(this, "onUpdateRegistration"));
		SmMainFrame.onPrefs.registerTargetHandler(new EodispDelegate(this, "onPrefs"));
		SmMainFrame.onOpenExperiment.registerTargetHandler(new EodispDelegate(this, "onOpenExperiment"));
		SmMainFrame.onNewExperiment.registerTargetHandler(new EodispDelegate(this, "onNewExperiment"));
		SmMainFrame.onDeleteExperiment.registerTargetHandler(new EodispDelegate(this, "onDeleteExperiment"));
	}

	public void onSaveAll(ActionEvent e) {
		logger.debug("performing action: onSaveAll");
		try {

			ReposServiceProxy service = ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(SmAppModuleCore.ID))
					.getReposServiceProxy();
			if (service != null) {
				service.save();
			}

			super.saveAllChanges();

			super.updateAllModels();

		} catch (IOException ex) {
			logger.error("Could not save all data", ex);
			CommonMessageBoxes.showSaveError(null, ex.getMessage());
		}
		logger.debug("saveAll completed");
	}

	public void onExitApp(ActionEvent e) {
		logger.debug("performing action: onExitApp");
		super.handleExit();
		logger.debug("onExitApp completed");
	}

	public void onAbout(ActionEvent e) {
		logger.debug("performing action: onAbout");

		new AboutDialog().showDialog();

		logger.debug("onAbout completed");
	}

	public void onHelp(ActionEvent e) {
		logger.debug("performing action: onExportProjectPart");

		new HelpDialog().showDialog();

		logger.debug("onExportProjectPart completed");
	}

	public void onConnectRepos(ActionEvent e) {
		logger.debug("performing action: onConnectRepos");

		// first connect
		SmAppModuleCore appModule = (SmAppModuleCore) AppRegistry.getRootApp().getAppModule(SmAppModuleCore.ID);
		if (!SmAppUtils.isConnected()) {
			try {
				appModule.getSmCoreServiceProxy().connectToRepos();
			} catch (Exception ex) {
				logger.debug("Could not connect to repository.", ex);
				MessageBoxHelper.ErrorBoxL(getMainFrame(), "ReposConnectError.Msg", "ReposConnectError.Cap", ex
						.getMessage());
				return;
			}
		}

		try {
			appModule.getReposServiceProxy().load();
		} catch (IOException ex) {
			CommonMessageBoxes.showLoadError(getMainFrame(), ex.getMessage());
		}

		checkState();
		super.updateAllModels();

		logger.debug("onConnectRepos completed");
	}

	public void onReloadRepos(ActionEvent e) {
		logger.debug("performing action: onReloadRepos");

		if (!SmAppUtils.isConnected()) {
			logger
					.info("The data from the repository could not be reloaded. The repository is not connected. Please connect first.");
			CommonMessageBoxes.showReposNotConnectedError(getMainFrame());
			return;
		}

		if (super.hasAppChanges()) {
			int choice = MessageBoxHelper.YesNoCancelQuestionBoxL(getMainFrame(), "AskForSaveViews.Msg",
					"AskForSaveViews.Cap");
			if (choice == JOptionPane.YES_OPTION) {
				try {
					saveAllChanges();
				} catch (IOException ex) {
					CommonMessageBoxes.showSaveError(null, ex.getMessage());
					return;
				}
			}
		}

		SmAppModuleCore appModule = (SmAppModuleCore) AppRegistry.getRootApp().getAppModule(SmAppModuleCore.ID);

		appModule.getReposServiceProxy().setScheduledForReload(true);

		try {
			appModule.getReposServiceProxy().load();
		} catch (IOException ex) {
			CommonMessageBoxes.showLoadError(getMainFrame(), ex.getMessage());
		}

		checkState();
		super.updateAllModels();

		logger.debug("onReloadRepos completed");
	}

	public void onRegisterApp(ActionEvent e) {
		logger.debug("performing action: onRegisterApp");

		// test connection
		if (!SmAppUtils.isConnected()) {
			logger
					.debug("The simulation manager application is not connected to the repository and can therefore not be registered.");
			CommonMessageBoxes.showReposNotConnectedError(null);
			return;
		}

		String[] changes = super.getChangedViewNames();
		if (changes.length > 0) {
			int choice = CommonMessageBoxes.showInstructSave(null);
			if (choice == JOptionPane.YES_OPTION) {
				try {
					saveAllChanges();
				} catch (IOException ex) {
					CommonMessageBoxes.showSaveError(null, ex.getMessage());
				}
			} else {
				return;
			}
		}

		Configuration smConfig = AppRegistry.getRootApp().getConfiguration(SmConfiguration.ID);

		ReposServiceProxy service = ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(SmAppModuleCore.ID))
				.getReposServiceProxy();
		if (service != null) {
			try {
				SmAppUtils.registerApp(service.getRootObject(), smConfig);
			} catch (Exception ex) {
				MessageBoxHelper.ErrorBoxL(null, "Error.General.Msg", "Error.General.Cap", ex.getMessage());
			}

			checkState();
			super.updateAllViewStates();
		}

		logger.debug("onRegisterApp completed");
	}

	public void onUpdateRegistration(ActionEvent e) {
		logger.debug("performing action: onUpdateRegistration");

		if (!SmAppUtils.isConnected()) {
			logger
					.debug("The simulation manager application is not connected to the repository and can therefore not be registered.");
			CommonMessageBoxes.showReposNotConnectedError(null);
			return;
		}

		if (super.hasAppChanges()) {
			int choice = CommonMessageBoxes.showInstructSave(getMainFrame());
			if (choice == JOptionPane.YES_OPTION) {
				try {
					saveAllChanges();
				} catch (IOException ex) {
					CommonMessageBoxes.showSaveError(getMainFrame(), ex.getMessage());
					return;
				}
			} else {
				return;
			}
		}

		SmConfiguration smConfiguration = (SmConfiguration) AppRegistry.getRootApp().getConfiguration(
				SmConfiguration.ID);

		ReposServiceProxy service = ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(SmAppModuleCore.ID))
				.getReposServiceProxy();
		if (service != null) {
			SmAppUtils.updateRegistration(service.getRootObject(), smConfiguration);
		}

		logger.debug("onUpdateRegistration completed");
	}

	public void onUnregisterApp(ActionEvent e) {
		logger.debug("performing action: onUnregisterApp");

		if (!SmAppUtils.isConnected()) {
			logger
					.debug("The simulation manager application is not connected to the repository and can therefore not be registered.");
			CommonMessageBoxes.showReposNotConnectedError(null);
			return;
		}

		if (super.hasAppChanges()) {
			int choice = CommonMessageBoxes.showInstructSave(getMainFrame());
			if (choice == JOptionPane.YES_OPTION) {
				try {
					saveAllChanges();
				} catch (IOException ex) {
					CommonMessageBoxes.showSaveError(getMainFrame(), ex.getMessage());
					return;
				}
			} else {
				return;
			}
		}

		SmConfiguration smConfiguration = (SmConfiguration) AppRegistry.getRootApp().getConfiguration(
				SmConfiguration.ID);

		String id = smConfiguration.getEntry(SmConfiguration.APP_ID).getValue();

		ReposServiceProxy service = ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(SmAppModuleCore.ID))
				.getReposServiceProxy();
		if (service != null) {
			int choice = MessageBoxHelper.YesNoQuestionBoxL(null, "UnregisterApp.Msg", "UnregisterApp.Cap");
			if (choice == JOptionPane.YES_OPTION) {
				try {
					SmAppUtils.unregisterApp(service.getRootObject(), id);
				} catch (Exception ex) {
					MessageBoxHelper.ErrorBoxL(getMainFrame(), "Error.General.Msg", "Error.General.Cap", ex
							.getMessage());
				}
			}

		}

		checkState();

		logger.debug("onUnegisterApp completed");
	}

	public void onOpenExperiment(ActionEvent e) {
		logger.debug("performing action: onOpenExperiment");

		EDataObject experiment = ExperimentChooser.showExperimentDialog(getMainFrame(), false);

		if (experiment != null && !EcoreUtil.equals(this.currentExperiment, experiment)) {
			this.currentExperiment = experiment;

			updateAllModels();
		}

		logger.debug("onOpenExperiment completed");
	}

	public void onNewExperiment(ActionEvent e) {
		logger.debug("performing action: onNewExperiment");

		SmModelServiceProxy service = ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(SmAppModuleCore.ID))
				.getSmModelServiceProxy();
		String name = SmResources.getMessage("Experiment.New.TemplateName");

		EDataObject newExperiment = null;
		try {
			newExperiment = SmEmfHelper.addNewExperiment(service.getRootObject(), name);
		} catch (Exception ex) {
			final String message = "Could not add a new experiment" + "\n" + ex.getMessage();
			CommonMessageBoxes.showGeneralMessage(getMainFrame(), message);
			return;
		}

		this.currentExperiment = newExperiment;

		updateAllModels();

		logger.debug("onNewExperiment completed");
	}

	public void onDeleteExperiment(ActionEvent e) {
		logger.debug("performing action: onDeleteExperiment");

		if (CommonMessageBoxes.askForDelete(getMainFrame()) == JOptionPane.NO_OPTION) {
			return;
		}

		if (currentExperiment != null) {

			SmEmfHelper.removeExperimentChildren(currentExperiment);

			EmfUtil.delete(currentExperiment);

			currentExperiment = null;
			while (currentExperiment == null) {
				currentExperiment = ExperimentChooser.showExperimentDialog(getMainFrame());
			}

			updateAllModels();
		}

		logger.debug("onDeleteExperiment completed");
	}

	public void onPrefs(ActionEvent e) {
		logger.debug("performing action: onPrefs");
		final SmPrefs prefs = new SmPrefs();
		prefs.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent windowEvent) {
				if (prefs.canExit()) {
					prefs.dispose();
				}
			}
		});
		prefs.pack();
		prefs.setVisible(true);
		logger.debug("onPrefs completed");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void createControllers() {
		SMTreeController treeController = new SMTreeController();
		treeController.initialize();

		attachController(treeController);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected EodispMainFrame createMainFrame() {
		return new SmMainFrame();
	}

	/**
	 * 
	 * {@inheritDoc}
	 */
	protected void createInitialLayout() {
		logger.debug("Create fixed initial layout");
		rootWindow.setWindow(new SplitWindow(true, 0.4f, viewMap.getView(SmExpTreeView.ID), new SplitWindow(false,
				0.6f, viewMap.getView(SmExperimentInfoView.ID), new TabWindow(new DockingWindow[] {
						viewMap.getView(SMPropertySheetView.ID), viewMap.getView(SmErrorView.ID) }))));
	}

	/**
	 * <p>
	 * Sets the main title of the main frame according to the current state.
	 * There are the following states
	 * </p>
	 * 
	 * <pre>
	 * connected | registered | text on main frame
	 * -----------------------------------------------------
	 *     no    |     no     | not connected/not registered
	 *     yes   |     no     | connected/not registered
	 *     yes   |     yes    | connected/registered
	 * </pre>
	 * 
	 * <p>
	 * In addition, it updates the state of the actions.
	 */
	private void checkState() {
		if (SmAppUtils.isConnected()) {
			if (SmAppUtils.isAppRegistered()) {
				getMainFrame().updateTitle("connected", "registered");
			} else {
				getMainFrame().updateTitle("connected", "not registered");
			}
		} else {
			getMainFrame().updateTitle("not connected", "not registered");
		}

		super.updateAllActions();
	}

	/**
	 * @return Returns the currentExperiment.
	 */
	public EDataObject getCurrentExperiment() {
		return currentExperiment;
	}

	/**
	 * 
	 * {@inheritDoc}
	 */
	@Override
	protected boolean canExit() {

		ExperimentTaskManager taskMgr = ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(SmAppModuleCore.ID))
				.getExperimentTaskManager();
		
		if(taskMgr.hasRunningExperiments()) {
			int choice = MessageBoxHelper.YesNoCancelQuestionBoxL(getMainFrame(), "AskForKillExperiments.Msg",
			"AskForKillExperiments.Cap");
			
			if(choice == JOptionPane.CANCEL_OPTION) {
				return false;
			} else if(choice == JOptionPane.YES_OPTION) {
				taskMgr.cancelAll();
			}
		}

		return super.canExit();
	}
}
