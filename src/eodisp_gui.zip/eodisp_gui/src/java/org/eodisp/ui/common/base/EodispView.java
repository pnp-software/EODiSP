/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com
 *  mail: info@pnp-software.com
 */
package org.eodisp.ui.common.base;

import java.awt.Component;

import net.infonode.docking.View;

import org.apache.log4j.Logger;

/**
 * An <code>EodispView</code> is the component that is responsible for
 * visually showing the components to the user. An <code>EodispView</code> is
 * embedded an <code>EodispFrame</code>. A view can only be embedded in one
 * <code>EodispFrame</code>.
 * <p>
 * A view can be either active or not active. A non-active view does not have to
 * be disposed. It can just be deactivated by the frame and set to active
 * whenever it is needed. A view can be set active by either using the the
 * {@link #setActive()} method or by using the
 * {@link org.eodisp.ui.common.base.EodispFrame#setActiveView(EodispView)}
 * method in an <code>EodispFrame</code>.
 * <p>
 * Every view must provide a title. This title will be displayed in the frame to
 * show the content of the view. The title should be short and expressive.
 * <p>
 * According to the MVC (Mode-View-Controller) architecture, a view has a
 * reference to its model. This is implemented in this base class. Apart from
 * this, most of the methods are abstract and therefore left to concrete views
 * to be implemented.
 * <p>
 * This class must be sub-classed by each view in the EODiSP framework to
 * implement the abstract methods and to make use of the provided functionality.
 * 
 * @author eglimi
 * @version $Id: EodispView.java 3485 2006-09-08 14:25:49Z eglimi $
 * 
 */
public abstract class EodispView extends View {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(EodispView.class);

	/**
	 * Holds the model which belongs to this view. This is the model which will
	 * send updates to this view, according to the MVC Pattern. Apart from that,
	 * this view can ask the model for values, updates, etc.
	 */
	private EodispModel model = null;

	/**
	 * Default constructor.
	 * <p>
	 * Sets the frame to which this view is attached to <code>null</code>.
	 * This implies that the frame must be attached by either using the
	 * {@link #attachFrame(EodispFrame)} in this class or to use the
	 * {@link EodispFrame#attachView(EodispView, boolean)} in the frame, which
	 * will attach the view as well.
	 */
	protected EodispView() {
		super("", null, null);
	}

	/**
	 * Returns the String identifier for a view. This identifier must never
	 * change.
	 * 
	 * @return The static Id of the view
	 */
	public abstract int getId();

	/**
	 * Returns the component of this view. This can be used to set the component
	 * of the content panel.
	 * 
	 * @return The component which should be shown in the content panel.
	 */
	public abstract Component getInternalComponent();

	/**
	 * Constructs and initializes all components that are included in this view.
	 * Must be implemented by the specific view.
	 * 
	 */
	public abstract void initializeComponents();

	/**
	 * Sets the model for this view.
	 * 
	 * @param model
	 *            The <code>EodispModel</code>.
	 */
	public void setModel(EodispModel model) {
		if (this.model != model) {
			this.model = model;
		}
	}

	/**
	 * Returns the model for this view.
	 * 
	 * @return The model or <code>null</code>, if the model is not set.
	 */
	public EodispModel getModel() {
		return model;
	}

	/**
	 * Many views include components such as lists, tables, etc. Often, these
	 * components need to be updated if a state changes. This method can
	 * instruct the view to save update itself. The view itself has to know what
	 * to do.
	 * <p>
	 * The default implementation ignores the request.
	 * </p>
	 * <p>
	 * You do not need to call
	 * <code>super.updateViewState()<code> when overriding this method.
	 * </p>
	 *
	 */
	protected void updateViewState() {
		// default: ignore
	}
}
