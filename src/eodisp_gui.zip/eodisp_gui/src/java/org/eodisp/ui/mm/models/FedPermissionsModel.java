/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.mm.models;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.AbstractListModel;

import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.sdo.EChangeSummary;
import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eodisp.core.common.ReposServiceProxy;
import org.eodisp.core.gen.repository.impl.RepositoryPackageImpl;
import org.eodisp.core.mm.application.MmAppModuleCore;
import org.eodisp.core.mm.helper.MmEmfHelper;
import org.eodisp.core.mm.service.Federate;
import org.eodisp.core.mm.service.MmCoreServiceProxy;
import org.eodisp.ui.common.components.AbstractEodispModel;
import org.eodisp.util.AppRegistry;

import commonj.sdo.DataObject;

/**
 * @author eglimi
 * @version $Id:$
 */
public class FedPermissionsModel extends AbstractEodispModel {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(FedPermissionsModel.class);

	private final Federate curObj;

	private final SmListModel untrustedSmListModel = new SmListModel(false);

	private final SmListModel trustedSmListModel = new SmListModel(true);

	public FedPermissionsModel(Federate curObj) {
		this.curObj = curObj;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @throws IOException
	 */
	public void doSave() throws IOException {
		if (getReposService() != null) {
			getReposService().save();
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void doUpdate() {
		getUntrustedSmListModel().update();
		getTrustedSmListModel().update();
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean hasChanges() {
		if (getReposService() != null) {
			return getReposService().isDirty();
		}

		return false;
	}

	/**
	 * Undo all changes in the repository datagraph.
	 * </p>
	 * {@inheritDoc}
	 */
	@Override
	public void undo() {
		ReposServiceProxy service = getReposService();
		if (service != null) {
			EDataObject reposRoot = service.getRootObject();
			EChangeSummary cs = (EChangeSummary) reposRoot.getDataGraph().getChangeSummary();
			if (cs != null && cs.isLogging()) {
				cs.summarize();
			}
			cs.apply();
		}
	}

	public void trustSm(int[] indices) {
		ReposServiceProxy service = getReposService();
		if (service == null) {
			return;
		}

		DataObject reposFed = MmEmfHelper.findReposFederate(service.getRootObject(), curObj
				.getFederateId(), curObj.getFederateVersion());
		if (reposFed != null) {
			for (int i = 0; i < indices.length; i++) {
				DataObject obj = (DataObject) getUntrustedSmListModel().getElementAt(indices[i]);
				reposFed.getList(RepositoryPackageImpl.FEDERATE__TRUSTED_SIM_MANAGERS).add(obj);
			}
		}

		doUpdate();
	}

	public void distrustSm(int[] indices) {
		ReposServiceProxy service = getReposService();
		if (service == null) {
			return;
		}

		DataObject reposFed = MmEmfHelper.findReposFederate(service.getRootObject(), curObj
				.getFederateId(), curObj.getFederateVersion());
		if (reposFed != null) {
			for (int i = 0; i < indices.length; i++) {
				DataObject obj = (DataObject) getTrustedSmListModel().getElementAt(indices[i]);
				reposFed.getList(RepositoryPackageImpl.FEDERATE__TRUSTED_SIM_MANAGERS).remove(obj);
			}
		}

		doUpdate();
	}

	public SmListModel getUntrustedSmListModel() {
		return untrustedSmListModel;
	}

	public SmListModel getTrustedSmListModel() {
		return trustedSmListModel;
	}

	/**
	 * Returns the core service for the model manager. This is only a
	 * convenience method.
	 * 
	 * @return The repository service or null, if there is no connection.
	 */
	private MmCoreServiceProxy getCoreService() {
		return ((MmAppModuleCore) AppRegistry.getRootApp().getAppModule(MmAppModuleCore.ID))
				.getMmCoreServiceProxy();
	}

	/**
	 * Returns the repository service. This is only a convenience method.
	 * 
	 * @return The repository service or null, if there is no connection.
	 */
	private ReposServiceProxy getReposService() {
		if (isReposConntected()) {
			return ((MmAppModuleCore) AppRegistry.getRootApp().getAppModule(MmAppModuleCore.ID))
					.getReposServiceProxy();
		}

		return null;
	}

	public void registerTrustedSm() {
	}

	/**
	 * This is only a convenient method to test the connection to the repository
	 * 
	 * @return true, if there is a connection, otherwise false
	 */
	public boolean isReposConntected() {
		return getCoreService().isReposConnected();
	}

	@SuppressWarnings("serial")
	private final class SmListModel extends AbstractListModel {

		private final List<DataObject> delegate = new ArrayList<DataObject>();

		private boolean filter = false;

		public SmListModel(boolean filter) {
			this.filter = filter;
		}

		/**
		 * {@inheritDoc}
		 * <p>
		 * The implementation will directly return the element from the
		 * underlying model.
		 * </p>
		 */
		public Object getElementAt(int index) {
			if (delegate.size() - 1 >= index) {
				return delegate.get(index);
			}

			return null;
		}

		/**
		 * {@inheritDoc}
		 * <p>
		 * The implementation will directly check the underlying model for the
		 * number of elements.
		 * </p>
		 */
		public int getSize() {
			if (delegate.size() <= 0) {
				ReposServiceProxy service = getReposService();
				if (service != null) {
					List<DataObject> trustedSms = MmEmfHelper
							.findAllReposSimulationManagers(service.getRootObject());
					for (DataObject trustedSm : trustedSms) {

						int index = 0;
						if (passFilter(trustedSm)) {
							delegate.add(index, trustedSm);
							index++;
						}
					}
				}
			}
			return delegate.size();
		}

		private boolean passFilter(Object reposSm) {
			ReposServiceProxy service = getReposService();

			if (service != null) {
				List<DataObject> trustedSms = MmEmfHelper.findTrustedSmsForLocalFederate(service
						.getRootObject(), curObj);
				for (DataObject trustedSm : trustedSms) {
					if (trustedSm == reposSm) {
						return isFilter();
					}
				}
			}

			return !isFilter();
		}

		/**
		 * Returns how the filter should work in respect to trusted or untrusted
		 * simulation managers from the repository. True means, trusted
		 * simulation managers will pass the filter, false means, untrusted
		 * simulation managers will pass the filter.
		 * 
		 * @return Returns the filter value.
		 */
		public boolean isFilter() {
			return filter;
		}

		public void update() {
			delegate.clear();
			fireContentsChanged(this, 0, getSize() - 1);
		}
	}
}
