/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.mm.views;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.IOException;

import javax.swing.*;

import org.apache.log4j.Logger;
import org.eodisp.ui.common.base.ConfigPanel;
import org.eodisp.ui.common.base.EodispDialog;
import org.eodisp.ui.common.resources.CommonMessageBoxes;
import org.eodisp.ui.common.resources.CommonMessages;
import org.eodisp.ui.mm.models.MmAppConfigModel;
import org.eodisp.ui.mm.resources.MmResources;
import org.eodisp.ui.shared.models.JxtaConfigModel;
import org.eodisp.ui.shared.models.RemoteConfModel;
import org.eodisp.ui.shared.views.JxtaConfig;
import org.eodisp.ui.shared.views.RemoteConf;

import com.jgoodies.forms.factories.ButtonBarFactory;

/**
 * @author eglimi
 * @version $Id:$
 * 
 */
public class MmPrefs extends EodispDialog {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(MmPrefs.class);

	private final JScrollPane contentPaneSp = new JScrollPane();

	private final ConfigPanel generalConfig = new MmAppConfig(new MmAppConfigModel());

	private final ConfigPanel netConfig = new RemoteConf(new RemoteConfModel());

	private final ConfigPanel jxtaConfig = new JxtaConfig(new JxtaConfigModel());

	private ConfigPanel currentPanel = null;

	private JPanel mainPanel;

	private JPanel labelsPanel;

	private JPanel buttonsPanel;

	private JButton[] prefBtns;

	private JButton[] labelBtns;

	/**
	 * serial version id.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Default constructor.
	 * 
	 */
	public MmPrefs() {
		super();

		// redefine the preferred size for this dialog.
		setPreferredSize(new Dimension(800, 600));

		initializeComponents();
		buildLabelsPanel();
		buildContentPanel();
		buildButtonsPanel();
		layoutPanels();

		setContentPane(mainPanel);
	}

	/**
	 * Does all the initialization of the components.
	 * 
	 */
	private void initializeComponents() {
		labelBtns = new JButton[3];
		labelBtns[0] = new JButton(CommonMessages.getMessage("Prefs.Cat.General"), MmResources
				.getIcon("48x48/categories/preferences-desktop.png"));
		labelBtns[0].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showGeneralSetting();
			}
		});
		labelBtns[1] = new JButton(CommonMessages.getMessage("Prefs.Cat.Network"), MmResources
				.getIcon("48x48/categories/package_network.png"));
		labelBtns[1].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showNetworkSetting();
			}
		});
		labelBtns[2] = new JButton(CommonMessages.getMessage("Prefs.Cat.Jxta"), MmResources
				.getIcon("48x48/categories/package_network.png"));
		labelBtns[2].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showJxtaSetting();
			}
		});

		prefBtns = new JButton[3];
		prefBtns[0] = new JButton("Apply");
		prefBtns[0].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				saveCurrent();
			}
		});
		prefBtns[1] = new JButton("Save & Exit");
		prefBtns[1].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				saveAll();
				exitDialog();
			}
		});
		prefBtns[2] = new JButton("Cancel");
		prefBtns[2].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exitDialog();
			}
		});
	}

	/**
	 * Builds the panel with the buttons and labels. This Panel is used to
	 * choose among the actual config panels.
	 */
	private void buildLabelsPanel() {
		labelsPanel = ButtonBarFactory.buildLeftAlignedBar(labelBtns);
	}

	/**
	 * This panel will hold the actual config panel that is selected.
	 * 
	 */
	private void buildContentPanel() {
		showGeneralSetting();
	}

	/**
	 * Builds some buttons that are placed on the bottom of the dialog (i.e.
	 * apply, exit, and cancel)
	 * 
	 */
	private void buildButtonsPanel() {
		buttonsPanel = ButtonBarFactory.buildRightAlignedBar(prefBtns);

	}

	/**
	 * Creates a layout for the panels. Here, this means to lay out the panels
	 * in a border layout.
	 * 
	 */
	private void layoutPanels() {
		mainPanel = new JPanel(new BorderLayout());
		mainPanel.add(labelsPanel, BorderLayout.NORTH);
		mainPanel.add(contentPaneSp, BorderLayout.CENTER);
		mainPanel.add(buttonsPanel, BorderLayout.SOUTH);
	}

	/**
	 * Checks whether the dialog can close.
	 * 
	 * @return True, if the dialog can be closed, otherwise false;
	 */
	public boolean canExit() {
		boolean canExit = true;
		if (hasChanges()) {
			int choice = CommonMessageBoxes.askForSaveChanges(this);

			if (choice == JOptionPane.YES_OPTION) {
				saveAll();
			} else if (choice == JOptionPane.NO_OPTION) {
				undoAll();
			} else if (choice == JOptionPane.CANCEL_OPTION) {
				canExit = false;
			}
		}
		return canExit;
	}

	/**
	 * Returns whether any of the panels have unsaved changes.
	 * 
	 * @return True, if at least one of the panels have unsaved changes, false
	 *         otherwise.
	 */
	private boolean hasChanges() {
		boolean changes = false;
		changes |= generalConfig.getModel().hasChanges();
		changes |= netConfig.getModel().hasChanges();
		changes |= jxtaConfig.getModel().hasChanges();

		return changes;
	}

	/**
	 * Saves all changes in all panels.
	 * 
	 */
	private void saveAll() {
		try {
			generalConfig.getModel().doSave();
			netConfig.getModel().doSave();
			jxtaConfig.getModel().doSave();
		} catch (IOException ex) {
			CommonMessageBoxes.showSaveError(this, ex.getMessage());
		}
	}

	/**
	 * Undos all changes in all panels.
	 * 
	 */
	private void undoAll() {
		generalConfig.getModel().undo();
		netConfig.getModel().undo();
		jxtaConfig.getModel().undo();
	}

	/**
	 * Saves only the current (i.e. current active) panel.
	 * 
	 */
	private void saveCurrent() {
		if (currentPanel != null) {
			try {
				currentPanel.getModel().doSave();
			} catch (IOException ex) {
				CommonMessageBoxes.showSaveError(this, ex.getMessage());
			}
		}
	}

	/**
	 * Instructs the dialog to quit by sending the corresponding window event.
	 * This event should be handled by the component that started this dialog.
	 * 
	 */
	private void exitDialog() {
		dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
	}

	/**
	 * Shows the panel with the general settings.
	 * 
	 */
	private void showGeneralSetting() {
		switchContentPanel(generalConfig);

	}

	/**
	 * Shows the panel with the network settings.
	 * 
	 */
	private void showNetworkSetting() {
		switchContentPanel(netConfig);

	}

	/**
	 * Shows the panel with the JXTA settings.
	 * 
	 */
	private void showJxtaSetting() {
		switchContentPanel(jxtaConfig);

	}

	/**
	 * Shows another panel than the current one, if the given panel is not the
	 * same as the active panel.
	 * 
	 * @param configPanel
	 *            The panel to show.
	 */
	private void switchContentPanel(ConfigPanel configPanel) {
		if (configPanel == null) {
			return;
		}

		if (currentPanel == null || !currentPanel.equals(configPanel)) {

			currentPanel = configPanel;
			contentPaneSp.setViewportView(configPanel.getPanel());
		}
	}
}
