/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.mm.config;

import java.io.File;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.eodisp.ui.common.base.UiConfiguration;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.FileUtil;
import org.eodisp.util.configuration.ConfigurationImpl;

/**
 * @author eglimi
 * @version $Id:$
 * 
 */
public class MmGuiConfiguration extends ConfigurationImpl implements UiConfiguration {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(MmGuiConfiguration.class);

	/**
	 * The Id of this configuration.This id can be used to retrieve the
	 * configuration entries.
	 */
	public static final String ID = "org.eodisp.ui.mm.config.MmGuiConfiguration";

	/**
	 * The name of the configuration. This will be shown on the command line.
	 */
	public static final String NAME = "Model Manager GUI Configuration";

	/**
	 * Describes the configuration. This will be shown on the command line.
	 */
	public static final String DESCRIPTION = "Configuration of the GUI part for the model manager application.";

	private static final String LOCALE = "locale";

	private static final String LOCALE_DESC = "The language for the current application as two letter ISO (ISO-639) code";

	public static final String MM_VIEW_STATE_FILE = "mm-view-state";

	public static final String MM_VIEW_STATE_FILE_DESC = "This is a file used by the model manager GUI application to store the state of the window. This state will be read upon the next startup to preserve the user's view settings.";
	
	public static final String NO_GUI = "no-gui";
	
	public static final String NO_GUI_DESC = "GUI is not started if this flag is set. ";
	

	/**
	 * Constructor. Calls the super constructor with the parameters defined
	 * above.
	 * 
	 * @param file
	 *            The configuration file which will be used to store the
	 *            configuration entries.
	 */
	public MmGuiConfiguration(File file) {
		super(ID, NAME, DESCRIPTION, file);

		File mmViewStateFile = new File(AppRegistry.getRootApp().getDataDir(), "viewState.eui");
		String mmViewStateFileRelative;
		try {
			mmViewStateFileRelative = FileUtil.getRelativePath(file.getParentFile(), mmViewStateFile);
		} catch (IOException e) {
			// Happens on windows if data directory and configuration directory
			// are not on the same device (e.g. C: and D:).
			mmViewStateFileRelative = mmViewStateFile.getAbsolutePath();
		}

		logger.debug(String.format("Setting default location of viewState.eui file to %s", mmViewStateFileRelative));

		// create entry for locale
		createEntry(LOCALE, "en", LOCALE_DESC);

		// create entry for view state file
		createFileEntry(MM_VIEW_STATE_FILE, new File(mmViewStateFileRelative), MM_VIEW_STATE_FILE_DESC);
		
		createBooleanEntry(NO_GUI, false, NO_GUI_DESC);
	}

	public String getLocale() {
		return getEntry(LOCALE).getValue();
	}

	public void setLocale(String locale) {
		getEntry(LOCALE).setValue(locale);
	}

	/**
	 * 
	 * {@inheritDoc}
	 */
	public String getViewStateEntry() {
		return getEntry(MM_VIEW_STATE_FILE).getValue();
	}

	/**
	 * 
	 * {@inheritDoc}
	 */
	public void setViewStateEntry(String file) {
		getEntry(MM_VIEW_STATE_FILE).setValue(file);
	}
	
	public static void main(String[] args) {
		System.out.println(new MmGuiConfiguration(new File("/tmp/config")).getCode());
	}
	
	public boolean isNoGui() {
		 return getEntry(NO_GUI).getBoolean(); 
	}

	public void setNoGui(boolean noGui) {
		 getEntry(NO_GUI).setBoolean(noGui); 
	}

}
