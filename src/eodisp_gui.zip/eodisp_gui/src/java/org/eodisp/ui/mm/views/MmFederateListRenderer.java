/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.mm.views;

import java.awt.Color;
import java.awt.Component;

import javax.swing.DefaultListCellRenderer;
import javax.swing.JList;

import org.eodisp.core.common.ReposServiceProxy;
import org.eodisp.core.mm.application.MmAppModuleCore;
import org.eodisp.core.mm.helper.MmEmfHelper;
import org.eodisp.core.mm.service.MmFederateProcessManager;
import org.eodisp.ui.mm.models.FederateBean;
import org.eodisp.util.AppRegistry;

/**
 * @author eglimi
 * @version $Id:$
 */
public class MmFederateListRenderer extends DefaultListCellRenderer {

	MmFederateListRenderer() {
		// don't paint behind the component
		setOpaque(true);
	}

	@Override
	public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected,
			boolean cellHasFocus) {
		Component comp = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

		final String text;
		FederateBean federate = (FederateBean) value;

		setBackground(getBackgroundColor(federate, isSelected));

		if (isSelected) {
			setForeground(new Color(0xff, 0xff, 0xff));
		}

		ReposServiceProxy service = ((MmAppModuleCore) AppRegistry.getRootApp().getAppModule(MmAppModuleCore.ID))
				.getReposServiceProxy();
		if (service != null) {
			if (MmEmfHelper.findReposFederate(service.getRootObject(), federate.getFederateId(), federate
					.getFederateVersion()) != null) {
				text = federate + "  (registered)";
			} else {
				text = federate + "  (not registered)";
			}
		} else {
			text = federate + "  (not registered)";
		}
		setText(text);

		return comp;
	}

	private Color getBackgroundColor(FederateBean federate, boolean isSelected) {
		MmFederateProcessManager processManager = ((MmAppModuleCore) AppRegistry.getRootApp().getAppModule(
				MmAppModuleCore.ID)).getFederateProcessManager();

		if (processManager.isFederateRunning(federate.getFederateId(), federate.getFederateVersion())) {
			return new Color(0x8a, 0xe2, 0x34);
		} else if (isSelected) {
			return new Color(0x72, 0x9f, 0xcf);
		}

		return null;
	}
}
