/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com
 *  mail: info@pnp-software.com
 */
package org.eodisp.ui.common.actions;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import javax.swing.event.EventListenerList;

import org.apache.log4j.Logger;

/**
 * The EodispActionRegistry is used to register {@link javax.swing.Action}'s.
 * These actions can be used for menu bar, too bar, and context menu entries.
 * The purpose of this class is to have a central place where all actions are
 * registered and from where actions can be retrieved for further processing.
 * 
 * @author eglimi
 * @version $Id:EodispActionRegistry.java 2134 2006-05-16 08:43:27Z eglimi $
 */
public class EodispActionRegistry {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(EodispActionRegistry.class);

	/**
	 * Holds all actions defined for this application.
	 */
	private Vector<EodispAction> actionList = new Vector<EodispAction>();

	private EventListenerList listeners = new EventListenerList();

	/**
	 * Holds the only INSTANCE of this class.
	 */
	private static EodispActionRegistry INSTANCE = new EodispActionRegistry();

	/**
	 * Enforce {@link #getInstance()}
	 */
	private EodispActionRegistry() {
	}

	/**
	 * Return the only INSTANCE of this class (singleton).
	 * 
	 * @return The only INSTANCE of this class.
	 */
	public static EodispActionRegistry getInstance() {
		return INSTANCE;
	}

	/**
	 * Adds an action to the list of known actions for this application.
	 * 
	 * @param source
	 *            The action to be added to the list of actions for this
	 *            application.
	 */
	public void registerAction(EodispAction source) {
		registerAction(source, null);
	}

	/**
	 * Adds an action to the list of known actions for this application.
	 * 
	 * @param source
	 *            The action to be added to the list of actions for this
	 *            application.
	 * @param registrar
	 *            The class which is responsible for registering this event.
	 */
	public <T extends ActionSourceProvider> void registerAction(EodispAction source, Class<T> registrar) {
		Vector<EodispAction> v = new Vector<EodispAction>();
		v.add(source);
		registerActions(v, registrar);
	}

	/**
	 * This can be used to register a list of actions instead of only one. This
	 * might be useful to register dynamic actions.
	 * 
	 * @param actions
	 *            A list including of actions of type {@link EodispAction}.
	 */
	public void registerActions(List<EodispAction> actions) {
		registerActions(actions, null);
	}

	/**
	 * This can be used to register a list of actions instead of only one. This
	 * might be useful to register dynamic actions.
	 * 
	 * @param actions
	 *            A list including of actions of type {@link EodispAction}.
	 * @param registrar
	 *            The class which is responsible for registering this event.
	 */
	public <T extends ActionSourceProvider> void registerActions(List<EodispAction> actions, Class<T> registrar) {
		for (EodispAction action : actions) {
			if (actionList.contains(action)) {
				logger.debug(String.format(
						"The source %s you are trying to register has already been registered. Ignoring this action",
						action));
				return;
			}

			action.setActionSource(registrar);

			actionList.add(action);
		}
		fireActionsChanged(new ActionChangedEvent(ActionChangedEvent.ActionType.ACTION_ADDEDD));
	}

	/**
	 * This clears all actions registered by a specific view. This is useful if
	 * the view is disposed or if the view registers dynamic actions.
	 * 
	 * @param registrar
	 *            The class that registered the actions. If null is given, all
	 *            actions are removed.
	 * @param onlyDanamic
	 *            If set to true, only actions that are dynamic are removed from
	 *            the registry, otherwise all actions are removed from the
	 *            registry.
	 */
	public <T extends ActionSourceProvider> void clearActions(Class<T> registrar) {
		Iterator<EodispAction> it = actionList.iterator();
		while (it.hasNext()) {
			EodispAction a = it.next();
			if (a.getActionSource() == registrar || registrar == null) {
				it.remove();
			}
		}

		fireActionsChanged(new ActionChangedEvent(ActionChangedEvent.ActionType.ACTION_REMOVED));
	}

	/**
	 * Disables all actions which are not always visible.
	 */
	public <T extends ActionSourceProvider> void disableActions() {
		Iterator<EodispAction> it = actionList.iterator();
		while (it.hasNext()) {
			EodispAction a = it.next();
			if (!a.isAlwaysSelected()) {
				a.setEnabled(false);
			}
		}
	}

	/**
	 * Returns a list of all actions registered in this registry which should be
	 * displayed in a menu bar.
	 * 
	 * @return The list with all actions. If no actions are found, the list will
	 *         be empty.
	 */
	public List<EodispAction> getMenuBarActions() {
		Vector<EodispAction> menuBarList = new Vector<EodispAction>();
		for (EodispAction a : actionList) {
			if (a.isShowInMenuBar()) {
				menuBarList.add(a);
			}
		}

		return menuBarList;
	}

	/**
	 * Returns a list of all actions registered in this registry which should be
	 * displayed in a tool bar.
	 * 
	 * @return The list with all actions. If no actions are found, the list will
	 *         be empty.
	 */
	public List<EodispAction> getToolBarActions() {
		Vector<EodispAction> toolBarList = new Vector<EodispAction>();
		for (EodispAction a : actionList) {
			if (a.isShowInToolBar()) {
				toolBarList.add(a);
			}
		}

		return toolBarList;
	}

	/**
	 * Returns a list of all actions registered in this registry which should be
	 * displayed in a tool bar.
	 * 
	 * @param type
	 *            The type for which the context menu actions should be
	 *            returned. If this parameter is null, the context menu actions
	 *            for all types are returned.
	 * @return The list with all actions. If no actions are found, the list will
	 *         be empty.
	 */
	public <T extends ActionSourceProvider> List<EodispAction> getContextMenuActions(Class<T> type) {
		Vector<EodispAction> contextMenuList = new Vector<EodispAction>();
		for (EodispAction a : actionList) {
			if (a.isShowInContextMenu() && ((a.getActionSource() == type) || type == null)) {
				contextMenuList.add(a);
			}
		}

		return contextMenuList;
	}

	public void addActionChangedListener(EodispActionListener l) {
		listeners.add(EodispActionListener.class, l);
	}

	public void removeActionChangedListener(EodispActionListener l) {
		listeners.remove(EodispActionListener.class, l);
	}

	private EodispActionListener[] getEodispActionListener() {
		return listeners.getListeners(EodispActionListener.class);
	}

	private void fireActionsChanged(ActionChangedEvent evt) {
		for (EodispActionListener l : getEodispActionListener()) {
			l.actionChanged(evt);
		}
	}
}
