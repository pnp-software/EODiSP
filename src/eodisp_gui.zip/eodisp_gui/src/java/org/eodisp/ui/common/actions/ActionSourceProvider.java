/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.common.actions;

/**
 * This interface should be implemented by components which support the
 * registration of <code>EodispAction</code>s. Usually, components which
 * support this are of type <code>EodispView</code>.
 * 
 * @author eglimi
 * @version $Id:ActionSourceProvider.java 2134 2006-05-16 08:43:27Z eglimi $
 * 
 */
public interface ActionSourceProvider {

	/**
	 * Registers all actions defined by this component in the
	 * {@link EodispActionRegistry} for further usage.
	 * 
	 */
	public void registerActions();

	/**
	 * This is used to update the enable state of actions registered by the
	 * implementing component.
	 * <p>
	 * New components should not be added here, but always with the
	 * {@link #registerActions()} method.
	 * <p>
	 * For actions that should be added/removed to the menus at runtime,
	 * implement the {@link DynamicActionSourceProvider} interface.
	 * 
	 */
	public void updateRegistrations();
}
