/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.mm.models;

import java.io.IOException;
import java.util.*;

import javax.swing.AbstractListModel;

import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eodisp.core.common.ReposServiceProxy;
import org.eodisp.core.mm.application.MmAppModuleCore;
import org.eodisp.core.mm.helper.MmEmfHelper;
import org.eodisp.core.mm.service.Federate;
import org.eodisp.core.mm.service.MmFederateProcessManager;
import org.eodisp.ui.common.components.AbstractEodispModel;
import org.eodisp.ui.mm.application.MmAppUtils;
import org.eodisp.util.AppRegistry;

import commonj.sdo.DataObject;

/**
 * @author eglimi
 * @version $Id:$
 */
public class MmFederatesModel extends AbstractEodispModel {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(MmFederatesModel.class);

	// public static final String FED_DESCRIPTION = "federateDescription";

	public static final String BUNDLE_NAME = "federateName";

	public static final String BUNDLE_ID = "federateId";

	public static final String BUNDLE_VERSION = "federateVersion";

	public static final String BUNDLE_DESCRIPTION = "federateDescription";

	private final MmFederatesListModel fedListModel = new MmFederatesListModel();

	private final Map<Federate, DataObject[]> federatePermissions = new HashMap<Federate, DataObject[]>();

	public MmFederatesModel() {
	}

	/**
	 * {@inheritDoc}
	 */
	public void doSave() throws IOException {
		if (getReposService() != null && getReposService().isDirty()) {
			getReposService().save();
		}
	}

	@Override
	public void doUpdate() {
		fedListModel.update();
		fireModelChanged();
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean hasChanges() {
		if (getReposService() != null) {
			return getReposService().isDirty();
		}

		return false;
	}

	public MmFederatesListModel getFederatesListModel() {
		return fedListModel;
	}

	/**
	 * Checks if a Federate is already registered in the repository. This is
	 * just a convenient method for
	 * {@link MmEmfHelper#isFederateRegistered(Object, Object)}.
	 * 
	 * @param somId
	 *            The id of the SOM in question.
	 * @return True, if the federate is registered in the repository, otherwise
	 *         false.
	 */
	public boolean isFedRegistered(Federate localFederate) {
		ReposServiceProxy service = getReposService();
		if (service != null) {
			return MmEmfHelper.findReposFederate(service.getRootObject(), localFederate.getFederateId(), localFederate
					.getFederateVersion()) != null;
		}

		return false;
	}

	public String getFederateInfo(FederateBean federateBean) {

		Federate localFederate = federateBean.getFederate();
		EDataObject reposFederate = null;

		ReposServiceProxy service = getReposService();
		if (service != null) {
			reposFederate = MmEmfHelper.findReposFederate(service.getRootObject(), localFederate.getFederateId(),
					localFederate.getFederateVersion());
		}

		return MmEmfHelper.getFederatInfo(localFederate, reposFederate);
	}

	private ReposServiceProxy getReposService() {
		if (MmAppUtils.isConnected()) {
			return ((MmAppModuleCore) AppRegistry.getRootApp().getAppModule(MmAppModuleCore.ID)).getReposServiceProxy();
		}

		return null;
	}

	public void setTrustedSimManagers(Federate federate, DataObject[] trustedSimManagers) {
		federatePermissions.put(federate, trustedSimManagers);
	}

	/**
	 * The list model for the list of federates. This
	 * 
	 * @author eglimi
	 */
	public final class MmFederatesListModel extends AbstractListModel {

		private final List<FederateBean> delegate = new ArrayList<FederateBean>();

		private boolean isInitialized = false;

		/**
		 * {@inheritDoc}
		 */
		public Object getElementAt(int index) {
			ensureFederates();

			return delegate.get(index);
		}

		public void update() {
			isInitialized = false;
			delegate.clear();
			fireContentsChanged(fedListModel, 0, getSize());
		}

		/**
		 * {@inheritDoc}
		 */
		public int getSize() {
			ensureFederates();

			return delegate.size();
		}

		private void ensureFederates() {
			if (isInitialized) {
				return;
			}

			MmFederateProcessManager processManager = ((MmAppModuleCore) AppRegistry.getRootApp().getAppModule(
					MmAppModuleCore.ID)).getFederateProcessManager();

			ReposServiceProxy service = getReposService();

			for (Federate entry : processManager.getEntries()) {
				FederateBean newBeanEntry = new FederateBean(entry);
				delegate.add(newBeanEntry);
			}

			Collections.sort(delegate, new Comparator<FederateBean>() {
				public int compare(FederateBean o1, FederateBean o2) {
					return o1.getFederateName().compareTo(o2.getFederateName());
				}
			});

			isInitialized = true;
		}
	}
}
