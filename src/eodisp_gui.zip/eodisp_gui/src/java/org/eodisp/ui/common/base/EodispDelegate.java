/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com
 *  mail: info@pnp-software.com
 */
package org.eodisp.ui.common.base;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.apache.log4j.Logger;

/**
 * This is an implementation of a delegate. It is capable of delegating the
 * execution of a method to the registered method within the target class. It
 * can be used as a delegation mechanism for virtually anything where an
 * <code>ActionListener</code> is suitable.
 * <p>
 * For instance, it can be used by a controller to register itself as a handler
 * for an action. The example here assumes that you want to register the event
 * 'OnAppExit' in the application controller. The following has to be done:
 * <ul>
 * <li>Create an action class 'ExitAppAction'</li>
 * <li>Instantiate this action in the appropriate frame. In the case of the
 * application controller, this will be the main frame of the application. In
 * general, it is the frame which the controller is responsible for.</li>
 * <li>Register the controller as the action handler for the event.</li>
 * <li>Create a method 'OnAppExit' in the controller that handles the event.</li>
 * </ul>
 * The corresponding code in the controller would look like this:
 * 
 * <pre>
 * <code>
 *    		Frame.onAppExitAction.registerTargetHandler(new EodispDelegate(this, &quot;onAppExit&quot;));
 *    		public void OnAppExit(ActionEvent e) {
 *    			//implementation
 *    		}
 * </code>
 * </pre>
 * 
 * @author eglimi
 * @version $Id:EodispDelegate.java 2047 2006-05-09 12:20:54Z eglimi $
 * 
 */
public class EodispDelegate implements ActionListener {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(EodispDelegate.class);

	/**
	 * This is the target object of the delegate. It will handle the action
	 * (i.e. it will provide an implementation method);
	 */
	private Object target = null;

	/**
	 * This is the target class object.
	 */
	private Class targetClass = null;

	/**
	 * Holds the method in the target object that should be invoked when the
	 * action has been performed.
	 */
	private Method targetMethod = null;

	/**
	 * Default constructor. Finds the method on the target object to be called.
	 * 
	 * @param target
	 *            The target object that is responsible to act upon the action
	 *            performed event.
	 * @param methodString
	 *            The name of the method that should be invoked when by the
	 *            action performed event.
	 */
	public EodispDelegate(Object target, String methodString) {
		this.target = target;
		targetClass = target.getClass();
		try {
			targetMethod = targetClass.getMethod(methodString, new Class[] { java.awt.event.ActionEvent.class });
		} catch (NoSuchMethodException ex) {
			logger.error("The method with the name " + methodString + " could not be found. Verify the name of the method you have registered.", ex);
		}
	}

	/**
	 * Called when an action is performed. It invokes the specified method in
	 * the target object.
	 * 
	 * @param e
	 *            ActionEvent - the event object of the event
	 */
	public void actionPerformed(ActionEvent e) {

		if (targetMethod == null)
			return;

		try {
			targetMethod.invoke(target, new Object[] { e });
		} catch (InvocationTargetException ex) {
			logger.error("The target method could not be invoked: " + targetMethod.getName(), ex.getCause());
		} catch (IllegalAccessException ex) {
			logger.error("There was an access violation when trying to access the specified method: " + targetMethod.getName(), ex);
		}
	}
}