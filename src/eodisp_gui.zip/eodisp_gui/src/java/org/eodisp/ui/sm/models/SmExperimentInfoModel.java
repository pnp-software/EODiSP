/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.sm.models;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

import javax.swing.SwingUtilities;

import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eodisp.core.sm.application.SmAppModuleCore;
import org.eodisp.core.sm.helper.SmEmfHelper;
import org.eodisp.core.sm.service.ExperimentListener;
import org.eodisp.core.sm.service.ExperimentTaskManager;
import org.eodisp.core.sm.service.ExperimentTaskState;
import org.eodisp.core.sm.service.ExperimentTaskState.ControlFederateState;
import org.eodisp.core.sm.service.ExperimentTaskState.TaskState;
import org.eodisp.ui.common.base.UIApp;
import org.eodisp.ui.common.components.AbstractEodispModel;
import org.eodisp.ui.sm.controllers.SMAppController;
import org.eodisp.util.AppRegistry;
import org.eodisp.wrapper.hla.FederationState;

/**
 * @author eglimi
 * @version $Id:$
 */
public class SmExperimentInfoModel extends AbstractEodispModel {

	private final ExperimentObserver experimentObserver = new ExperimentObserver();

	private ExperimentTaskState experimentTaskState = null;

	public SmExperimentInfoModel() {
		ExperimentTaskManager taskMgr = ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(SmAppModuleCore.ID))
				.getExperimentTaskManager();

		taskMgr.addExperimentListener(experimentObserver);
	}

	/**
	 * {@inheritDoc}
	 * <p>
	 * This model does not save anything.
	 */
	public void doSave() throws IOException {
		// TODO Auto-generated method stub

	}
	
	@Override
	public void doUpdate() {
		updateExperiment();
	}

	/**
	 * @return Returns the controlFederateState.
	 */
	public synchronized ControlFederateState getControlFederateState() {
		if (experimentTaskState != null) {
			return experimentTaskState.getControlFederateState();
		}

		return null;
	}

	/**
	 * @return Returns the currentFederationExecution.
	 */
	public synchronized EDataObject getCurrentFederationExecution() {
		if (experimentTaskState != null) {
			return experimentTaskState.getCurrentFederationExecution();
		}

		return null;
	}

	/**
	 * @return Returns the federationState.
	 */
	public synchronized FederationState getFederationState() {
		if (experimentTaskState != null) {
			return experimentTaskState.getFederationState();
		}

		return null;
	}
	
	/**
	 * @return Returns the taskState.
	 */
	public synchronized TaskState getTaskState() {
		if (experimentTaskState != null) {
			return experimentTaskState.getTaskState();
		}

		return null;
	}

	public synchronized List<Throwable> getErrors() {
		if (experimentTaskState != null) {
			return experimentTaskState.getErrors();
		}

		return Collections.EMPTY_LIST;
	}

	public String getExperimentName() {
		return SmEmfHelper.getName(getCurrentExperiment());
	}

	public int nrOfFederates() {
		EDataObject currentExperiment = getCurrentExperiment();
		if (currentExperiment != null) {
			return SmEmfHelper.findAllFederationExecutionsForExperiment(currentExperiment).size();
		}

		return 0;
	}

	/**
	 * {@inheritDoc}
	 * <p>
	 * This model does not change.
	 */
	public boolean hasChanges() {
		return false;
	}

	/**
	 * @return Returns the currentExperiment.
	 */
	private synchronized EDataObject getCurrentExperiment() {
		return ((SMAppController) ((UIApp) AppRegistry.getRootApp()).getApplicationController()).getCurrentExperiment();
	}

	private void updateExperiment() {
		ExperimentTaskManager taskMgr = ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(SmAppModuleCore.ID))
				.getExperimentTaskManager();

		experimentTaskState = taskMgr.getState(getCurrentExperiment());
		fireModelChanged();
	}

	private class ExperimentObserver implements ExperimentListener {

		public void experimentChanged() {
			SwingUtilities.invokeLater(new Runnable() {

				public void run() {
					updateExperiment();
				}

			});
		}
	}
}
