/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.sm.application;

import java.io.File;

import javax.swing.SwingUtilities;

import org.apache.log4j.Logger;
import org.eodisp.ui.common.base.EodispApplicationController;
import org.eodisp.ui.common.base.UIUtil;
import org.eodisp.ui.sm.config.SmGuiConfiguration;
import org.eodisp.ui.sm.controllers.SMAppController;
import org.eodisp.util.AppModule;
import org.eodisp.util.RootApp;

/**
 * @author eglimi
 * @version $Id:$
 */
public class SmAppModuleGui implements AppModule {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(SmAppModuleGui.class);

	private EodispApplicationController appController;

	/**
	 * The Id of this Application Module.
	 */
	public static final String ID = "org.eodisp.ui.sm.application.SmAppModuleGui";

	private static final String CONFIG_FILE_GUI = "sm_gui.conf";

	/**
	 * {@inheritDoc}
	 */
	public String getId() {
		return ID;
	}

	/**
	 * {@inheritDoc}
	 */
	public void registerConfiguration(RootApp rootApp) throws Exception {
		// Gui Config
		File configFileGui = new File(rootApp.getConfigurationDir(), CONFIG_FILE_GUI);
		SmGuiConfiguration smGuiConfiguration = new SmGuiConfiguration(configFileGui);

		// register configurations
		rootApp.registerConfiguration(smGuiConfiguration);
	}

	/**
	 * <p>
	 * Configures some settings for the application before it is started.
	 * </p>
	 * {@inheritDoc}
	 */
	public void preStartup(RootApp rootApp) throws Exception {
	}

	/**
	 * {@inheritDoc}
	 */
	public void startup(RootApp rootApp) throws Exception {
		UIUtil.configureUI();

		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				appController = new SMAppController();
				appController.initialize();
			}
		});
	}

	/**
	 * {@inheritDoc}
	 */
	public void shutdown(RootApp rootApp) throws Exception {
		// dispose all windows before exiting
		if (getApplicationController() != null) {
			getApplicationController().getMainFrame().dispose();
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void postShutdown(RootApp rootApp) throws Exception {
		System.exit(0);
	}

	/**
	 * Returns the main application controller for this application. This can be
	 * handy in order to cleanly shutdown the application, get the main frame,
	 * etc.
	 * 
	 * @return The application controller of this application. See
	 *         {@link EodispApplicationController} for mor information.
	 */
	public EodispApplicationController getApplicationController() {
		return appController;
	}

}
