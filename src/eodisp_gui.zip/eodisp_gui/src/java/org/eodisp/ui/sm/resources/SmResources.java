/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.sm.resources;

import java.awt.Image;
import java.awt.Toolkit;
import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.swing.ImageIcon;

import org.apache.log4j.Logger;
import org.eodisp.ui.common.base.UIApp;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.configuration.Configuration.Entry;

/**
 * This class is to support resources needed in the GUI interface. Resources can
 * be of any type (e.g. strings, music, images, etc). This class will support
 * the load of such resources.
 * <p>
 * A special type of resources are the localized strings. These are kept in a
 * {@link ResourceBundle}. This can be used to return a localized string,
 * depending on the current user locale. The default language is English (ISO
 * Code 'en').
 * <p>
 * Currently, the following types of resources are supported:
 * <ul>
 * <li>Icons: Icons used in the simulation manager application (see
 * {@link #getIcon(String)}</li>
 * <li>UIMessageString: Strings displayed to an user of the graphical user
 * interface (see {@link #getMessage(String)})</li>
 * </ul>
 * 
 * @author eglimi
 */
public class SmResources {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(SmResources.class);

	/**
	 * Holds the value for the resource bundle that includes messages for the
	 * user interface.
	 */
	private static ResourceBundle messageBundle = null;

	/**
	 * The static method would not be necessary if the bundle was initialised in
	 * the method. Since we use always the same bundle (=same language), it is
	 * initialised here.
	 */
	static {
		String locale = "en";

		Entry userLocaleEntry = ((UIApp) AppRegistry.getRootApp()).getUiConfiguration().getEntry("locale");
		if (userLocaleEntry == null) {
			logger.warn("No entry for the locale of the application has been set."
					+ "Please specify one. For now, a default locale of 'en' will be used");
		} else {
			if (!userLocaleEntry.isSet()) {
				logger.debug("The GUI configuration of this application does not define an entry for the locale."
						+ "The default locale as specified by the application will be used."
						+ "Please add an entry in the configuration if you want to change this");
			}

			locale = userLocaleEntry.getValue();
		}

		Locale userLocale = new Locale(locale);
		messageBundle = ResourceBundle.getBundle("org.eodisp.ui.sm.resources.SmMessages", userLocale);
	}

	/**
	 * This returns the icon with the given name. It will only search for the
	 * icon in the 'icons' folder contained within this folder.
	 * 
	 * @param iconName
	 *            The name of the icon.
	 * @return The icon if found, otherwise null.
	 */
	public static ImageIcon getIcon(String path) {
		// check if there is a first '/'
		if (path.startsWith("/")) {
			path = path.substring(1);
		}

		URL resource = SmResources.class.getResource("/org/eodisp/ui/images/" + path);
		if (resource != null) {
			return new ImageIcon(resource);
		}
		return null;
	}

	public static Image getAppImage() {
		URL resource = Thread.currentThread().getContextClassLoader().getResource("org/eodisp/ui/images/AppLogo.png");
//		URL resource = SmResources.class.getResource("/org/eodisp/ui/images/AppLogo.png");
		if (resource == null) {
			logger.debug("Could not set the application logo because the resource could not be found.");
			return null;
		}
		return Toolkit.getDefaultToolkit().getImage(resource);
	}

	/**
	 * Returns the text found by the given key in the resource. Only Strings
	 * which are used in a EODiSP user interface are returned here.
	 * 
	 * @param key
	 *            The resource file is searched for this key.
	 * @return The text for the current language or a fallback language if no
	 *         string can be found.
	 */
	public static String getMessage(String key) {
		return messageBundle != null ? messageBundle.getString(key) : null;
	}
}
