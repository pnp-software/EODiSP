/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.rm.application;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.rmi.AccessException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.Registry;

import javax.swing.SwingUtilities;

import org.apache.log4j.Logger;
import org.eodisp.core.common.ReposModelService;
import org.eodisp.core.common.ReposServiceProxy;
import org.eodisp.core.gen.repository.impl.RepositoryPackageImpl;
import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.ui.common.base.EodispApplicationController;
import org.eodisp.ui.common.base.UIUtil;
import org.eodisp.ui.rm.config.RmGuiConfiguration;
import org.eodisp.ui.rm.controllers.RmAppController;
import org.eodisp.util.AppModule;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.RootApp;

/**
 * @author eglimi
 * @version $Id:$
 * 
 */
public class RmAppModuleGui implements AppModule {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(RmAppModuleGui.class);

	/**
	 * Holds the application controller. This is the main controller for the
	 * whole application. For each application, there is only one application
	 * controller.
	 */
	private EodispApplicationController appController = null;

	/**
	 * The Id of this Application Module.
	 */
	public static final String ID = "org.eodisp.ui.rm.application.RmAppModuleGui";

	/**
	 * The name of the GUI configuration file used in the repos manager
	 * application.
	 */
	private static final String CONFIG_FILE_GUI = "rm_gui.conf";

	private ReposModelService reposService = null;

	private ReposServiceProxy reposServiceProxy = null;

	// private ReposServiceProxy reposServiceProxy = null;

	/**
	 * {@inheritDoc}
	 */
	public String getId() {
		return ID;
	}

	/**
	 * {@inheritDoc}
	 */
	public void registerConfiguration(RootApp rootApp) throws Exception {
		// Gui Config
		File configFileGui = new File(rootApp.getConfigurationDir(), CONFIG_FILE_GUI);
		RmGuiConfiguration rmGuiConfiguration = new RmGuiConfiguration(configFileGui);

		// register configurations
		rootApp.registerConfiguration(rmGuiConfiguration);
	}

	/**
	 * <p>
	 * Configures some settings for the application before it is started.
	 * </p>
	 * {@inheritDoc}
	 */
	public void preStartup(RootApp rootApp) throws Exception {
		UIUtil.configureUI();
		// init emf for the repository service
		RepositoryPackageImpl.eINSTANCE.getName();
	}

	/**
	 * {@inheritDoc}
	 */
	public void startup(RootApp rootApp) throws Exception {
		appController = new RmAppController();
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				appController.initialize();
			}
		});
	}

	/**
	 * {@inheritDoc}
	 */
	public void shutdown(RootApp rootApp) throws Exception {
		// dispose all windows before exiting
		getApplicationController().getMainFrame().dispose();
	}

	/**
	 * {@inheritDoc}
	 */
	public void postShutdown(RootApp rootApp) throws Exception {
		System.exit(0);
	}

	public ReposServiceProxy getReposServiceProxy() {
		if (reposServiceProxy == null) {
			if (isReposConnected()) {
				reposServiceProxy = new ReposServiceProxy(reposService);
			}
		}

		return reposServiceProxy;
	}

	/**
	 * Returns the main application controller for this application. This can be
	 * handy in order to cleanly shutdown the application, get the main frame,
	 * etc.
	 * 
	 * @return The application controller of this application. See
	 *         {@link EodispApplicationController} for mor information.
	 */
	public EodispApplicationController getApplicationController() {
		return appController;
	}

	public void connectToRepos() throws URISyntaxException, AccessException, RemoteException, NotBoundException {
		if (!isReposConnected()) {
			URI reposUri;
			Registry registry;
			reposUri = ((RmGuiConfiguration) AppRegistry.getRootApp().getConfiguration(RmGuiConfiguration.ID))
					.getReposUri();
			RemoteAppModule remoteAppModule = (RemoteAppModule) AppRegistry.getRootApp().getAppModule(
					RemoteAppModule.ID);

			registry = remoteAppModule.getRegistry(reposUri);

			logger.debug(String.format("Created proxy for remote registry: %s", registry));

			// set the service in the app module for further reference
			reposService = (ReposModelService) registry.lookup(ReposModelService.REGISTRY_NAME);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isReposConnected() {
		return reposService != null ? true : false;
	}
}
