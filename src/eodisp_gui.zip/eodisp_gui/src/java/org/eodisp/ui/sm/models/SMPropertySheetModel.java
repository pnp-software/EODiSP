/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.sm.models;

import java.io.IOException;
import java.util.List;

import javax.swing.table.AbstractTableModel;

import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eodisp.ui.common.base.EodispModel;
import org.eodisp.ui.sm.resources.SmResources;

import commonj.sdo.Property;

/**
 * This is the model for the property sheet used in the simulation manager
 * application. It will display the properties of an object item in the
 * simulation manager project file.
 * <p>
 * This model can be used by a {@link javax.swing.JTable} to display the
 * properties.
 * <p>
 * This model is tightly coupled with the Emf framework. The model itself holds
 * no data, all data is directly retrieved from the Emf framework.
 * 
 * @author eglimi
 * @version $Id:SMPropertySheetModel.java 1941 2006-04-21 11:30:46Z eglimi $
 */
public class SMPropertySheetModel extends AbstractTableModel implements EodispModel {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(SMPropertySheetModel.class);

	private EDataObject source = null;

	/**
	 * Constructor.
	 */
	public SMPropertySheetModel() {
		super();
	}

	/**
	 * {@inheritDoc}
	 */
	public int getColumnCount() {
		return 2;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String getColumnName(int column) {

		// always show these headers, even if no property is displayed...
		switch (column) {
		case 0:
			return SmResources.getMessage("SmPropertySheet.Table.Header1");
		case 1:
			return SmResources.getMessage("SmPropertySheet.Table.Header2");
		default:
			return "";
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public int getRowCount() {
		if (source == null) {
			return 0;
		}
		List<Object> props = source.getInstanceProperties();

		int rowCount = 0;
		for (int i = 0; i < props.size(); i++) {
			if (source.isSet(i)) {
				Object obj = props.get(i);
				if (obj instanceof EAttribute) {
					EAttribute prop = (EAttribute) props.get(i);
					// ignore many properties
					if (!prop.isMany()) {
						rowCount++;
					}
				}
			}
		}

		return rowCount;
	}

	/**
	 * {@inheritDoc}
	 */
	public Object getValueAt(int rowIndex, int columnIndex) {

		int index = 0;

		List<Object> props = source.getInstanceProperties();

		for (int i = 0; i < props.size(); i++) {
			if (source.isSet(i)) {
				Object obj = props.get(i);
				if (obj instanceof EAttribute) {
					EAttribute prop = (EAttribute) props.get(i);
					// ignore many properties
					if (!prop.isMany()) {
						if (index == rowIndex) {
							switch (columnIndex) {
							case 0:
								return prop.getName();
							case 1:
								return source.get(i);
							}
						}
						index++;
					}
				}
			}
		}

		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		if (columnIndex == 0) {
			return false;
		}

		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {

		List<Property> props = source.getInstanceProperties();

		int index = 0;
		for (int i = 0; i < props.size(); i++) {
			if (source.isSet(i)) {
				Object obj = props.get(i);
				if (obj instanceof EAttribute) {
					EAttribute prop = (EAttribute) props.get(i);
					if (!prop.isMany()) {
						if (index == rowIndex) {
							source.set(i, aValue);
						}
						index++;
					}
				}
			}
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean hasChanges() {
		// done by the SMProjectTreeModel for this Emf resource
		return false;
	}

	/**
	 * {@inheritDoc}
	 */
	public void doSave() throws IOException {
		// ignoring request -> save is handled by the proper view that displays
		// this properties
	}

	/**
	 * {@inheritDoc}
	 */
	public void doUpdate() {
		// ignore request
	}

	/**
	 * {@inheritDoc}
	 */
	public void redo() {
		// ignoring request
	}

	/**
	 * {@inheritDoc}
	 */
	public void undo() {
		// ignoring request
	}

	/**
	 * Updates the source object for this model. The source object is an Emf
	 * model object. With this, the whole table will be constructed. It is the
	 * same as setting a new model for the table.
	 * <p>
	 * The {@link AbstractTableModel#fireTableDataChanged()} event will be fired
	 * to inform all listeners about the change.
	 * 
	 * @param sourceObject
	 *            The new source for the model.
	 */
	public void updateSource(EDataObject sourceObject) {
		if (sourceObject != null) {
			this.source = (EDataObject) sourceObject;
			fireTableDataChanged();
		}
	}
}