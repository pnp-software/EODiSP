/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.sm.views;

import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableColumn;

import org.eodisp.ui.common.actions.ActionSourceProvider;
import org.eodisp.ui.common.base.EodispView;
import org.eodisp.ui.sm.models.SmErrorModel;
import org.eodisp.ui.sm.resources.SmResources;

/**
 * This is the view for the simulation manager application that will display the
 * errors of a simulation manager application.
 * 
 * @author eglimi
 */
public class SmErrorView extends EodispView implements ActionSourceProvider {

	private static final String TITLE = SmResources.getMessage("SmErrorView.View.Title");

	public static final int ID = 21;

	private final JTable table = new JTable();

	private final JScrollPane scrollPane = new JScrollPane();

	private final SmErrorCellRenderer renderer = new SmErrorCellRenderer();

	/**
	 * Default constructor.
	 */
	public SmErrorView() {
		super();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void initializeComponents() {
		table.setModel(getErrorModel());
		TableColumn msgCol = table.getColumnModel().getColumn(0);
		msgCol.setCellRenderer(renderer);

		table.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseReleased(MouseEvent e) {
				if (e.isPopupTrigger()) {
					handlePopup(e);
				}
			}

			@Override
			public void mousePressed(MouseEvent e) {
				if (e.isPopupTrigger()) {
					handlePopup(e);
				}
			}

		});

		table.getModel().addTableModelListener(new TableModelListener() {

			public void tableChanged(TableModelEvent e) {
				updateTitle();
			}

		});

		scrollPane.setViewportView(table);

		setComponent(getInternalComponent());
	}

	private void updateTitle() {
		fireTitleChanged();
	}

	/**
	 * {@inheritDoc}
	 */
	public String getTitle() {
		return String.format("%s (%s)", TITLE, getErrorModel().getRowCount());
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getId() {
		return ID;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Component getInternalComponent() {
		return scrollPane;
	}

	/**
	 * {@inheritDoc}
	 */
	public void registerActions() {
	}

	private void handlePopup(MouseEvent e) {
		// no popups
	}

	public void updateRegistrations() {
		// TODO Auto-generated method stub
	}

	/**
	 * Returns the model of this view.
	 * 
	 * @return The currently set model of this view.
	 */
	private SmErrorModel getErrorModel() {
		return (SmErrorModel) super.getModel();
	}

}
