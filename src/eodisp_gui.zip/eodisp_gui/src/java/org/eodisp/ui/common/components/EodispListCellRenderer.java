/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.common.components;

import java.awt.Color;
import java.awt.Component;
import java.util.List;

import javax.swing.DefaultListCellRenderer;
import javax.swing.JList;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.sdo.EDataObject;

import commonj.sdo.DataObject;

/**
 * <p>
 * This renderer can be used for {@link JList}s that holds
 * <code>DataObject</code> as items. This renderer is capable of displaying
 * the name of the <code>DataObject</code>, if it has a name property
 * associated. Otherwise, it uses the <code>toString()</code> method of the
 * object itself, displaying whatever this produces.
 * </p>
 * <p>
 * In most cases, components that use a <code>JList</code> should implement
 * their own renderer class.
 * <p>
 * <p>
 * This class is not intended to be sub-classed. Create a dedicated renderer to
 * implement other bahaviour.
 * <p>
 * 
 * @author eglimi
 * @version $Id:$
 */
public final class EodispListCellRenderer extends DefaultListCellRenderer {

	public EodispListCellRenderer() {
		// don't paint behind the component.
		setOpaque(true);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected,
			boolean cellHasFocus) {
		Component comp = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

		if (value instanceof EDataObject) {
			String labelText = value.toString();
			List<Object> props = ((EDataObject) value).getInstanceProperties();
			for (int i = 0; i < props.size(); i++) {
				if (((DataObject) value).isSet(i)) {
					Object obj = props.get(i);
					if (obj instanceof EAttribute) {
						EAttribute prop = (EAttribute) props.get(i);
						if (prop.getName().equalsIgnoreCase("name")) {
							labelText = ((DataObject) value).getString(i);
						}
					}
				}
			}
			setText(labelText);
		}

		if (isSelected) {
			setBackground(new Color(0x72, 0x9f, 0xcf));
			setForeground(new Color(0xff, 0xff, 0xff));
		}

		return comp;
	}
}
