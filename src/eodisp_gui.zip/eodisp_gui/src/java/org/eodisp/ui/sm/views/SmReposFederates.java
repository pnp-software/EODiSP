/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.sm.views;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import org.apache.log4j.Logger;
import org.eodisp.core.sm.helper.SmEmfHelper;
import org.eodisp.ui.common.base.UIUtil;
import org.eodisp.ui.common.components.TableSorter;
import org.eodisp.ui.shared.views.SimpleDialog;
import org.eodisp.ui.sm.models.SmReposFederatesModel;
import org.eodisp.ui.sm.resources.SmResources;

import com.jgoodies.forms.factories.ButtonBarFactory;
import commonj.sdo.DataObject;

/**
 * @author eglimi
 * @version $Id:$
 */
public class SmReposFederates {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(SmReposFederates.class);

	private final SmReposFederatesModel model = new SmReposFederatesModel();

	private final JDialog dialog;

	private DataObject[] selectedFederates;

	/**
	 * This is the main panel that will hold all other components. It will be
	 * embedded in a scroll pane.
	 */
	private final JPanel mainPanel = new JPanel(new BorderLayout());

	// private final JList fedList = new JList();
	private final JTable fedTable = new JTable();

	private final JButton[] dialogButtons = new JButton[3];

	private final JFrame owner;

	private SmReposFederates(JFrame owner) {
		this.owner = owner;

		dialog = new JDialog(owner, true);

		initializeComponents();
		
		JScrollPane tablePanel = new JScrollPane(fedTable);
		fedTable.setPreferredScrollableViewportSize(new Dimension(fedTable.getPreferredSize().width, 400));

//		mainPanel.add(fedTable.getTableHeader(), BorderLayout.NORTH);
		mainPanel.add(tablePanel, BorderLayout.CENTER);
		mainPanel.add(ButtonBarFactory.buildRightAlignedBar(dialogButtons), BorderLayout.SOUTH);
		dialog.setContentPane(mainPanel);
	}

	private void initializeComponents() {
		
		TableSorter tableSorter = new TableSorter(getModel().getFederatesTableModel());
		fedTable.setModel(tableSorter);
		tableSorter.setTableHeader(fedTable.getTableHeader());
		fedTable.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		
		UIUtil.adjustColumnSize(fedTable);
		fedTable.revalidate();

		dialogButtons[0] = new JButton(SmResources.getMessage("SmReposFederates.Button0.Text"));
		dialogButtons[0].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int[] selectedRows = fedTable.getSelectedRows();
				if (selectedRows.length > 0) {
					selectedFederates = new DataObject[selectedRows.length];
					for (int i = 0; i < selectedRows.length; i++) {
						int modelIndex = ((TableSorter)fedTable.getModel()).modelIndex(selectedRows[i]);
						selectedFederates[i] = getModel().getFederatesTableModel().getRowObject(modelIndex);
					}
				}
				exitDialog();
			}
		});

		dialogButtons[1] = new JButton(SmResources.getMessage("SmReposFederates.Button1.Text"));
		dialogButtons[1].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exitDialog();
			}
		});

		dialogButtons[2] = new JButton(SmResources.getMessage("SmReposFederates.Button2.Text"));
		dialogButtons[2].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showInfo();
			}
		});
	}

	public static DataObject[] showSelectionDialog(JFrame owner) {
		SmReposFederates reposFederates = new SmReposFederates(owner);
		return reposFederates.showInternalSelectionDialog();
	}

	private DataObject[] showInternalSelectionDialog() {
		dialog.pack();
		dialog.setLocationRelativeTo(owner);
		dialog.setVisible(true);
		dialog.dispose();

		return selectedFederates;
	}

	private SmReposFederatesModel getModel() {
		return model;
	}

	/**
	 * Closes the dialog.
	 */
	private void exitDialog() {
		dialog.dispose();
	}

	private void showInfo() {
		int selectedRow = fedTable.getSelectedRow();
		if (selectedRow >= 0) {
			DataObject selectedObject = getModel().getFederatesTableModel().getRowObject(selectedRow);
			SimpleDialog.showHtml(owner, SmEmfHelper.getFederateInfo(selectedObject));
		}
	}

}
