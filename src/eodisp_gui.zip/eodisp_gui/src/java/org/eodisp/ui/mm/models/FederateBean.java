/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.mm.models;

import java.io.File;

import org.eodisp.core.mm.service.Federate;

import com.jgoodies.binding.beans.Model;

/**
 * @author eglimi
 * @version $Id:$
 */
public class FederateBean extends Model {
	private final Federate delegate;

	public FederateBean(Federate delegate) {
		this.delegate = delegate;
	}

	/**
	 * @return
	 * @see org.eodisp.core.mm.service.Federate#getBundlePath()
	 */
	public File getBundlePath() {
		return delegate.getBundlePath();
	}

	/**
	 * @return
	 * @see org.eodisp.core.mm.service.Federate#getFederateDescription()
	 */
	public String getFederateDescription() {
		return delegate.getFederateDescription();
	}

	/**
	 * @return
	 * @see org.eodisp.core.mm.service.Federate#getFederateId()
	 */
	public String getFederateName() {
		return delegate.getFederateName();
	}

	/**
	 * @return
	 * @see org.eodisp.core.mm.service.Federate#getFederateId()
	 */
	public String getFederateId() {
		return delegate.getFederateId();
	}

	/**
	 * @return
	 * @see org.eodisp.core.mm.service.Federate#getFederateVersion()
	 */
	public String getFederateVersion() {
		return delegate.getFederateVersion();
	}

	/**
	 * @return
	 * @see org.eodisp.core.mm.service.Federate#getSomId()
	 */
	public String getSomId() {
		return delegate.getSomId();
	}

	/**
	 * @return
	 * @see org.eodisp.core.mm.service.Federate#getSomVersion()
	 */
	public String getSomVersion() {
		return delegate.getSomVersion();
	}

	@Override
	public String toString() {
		return getFederateName();
	}

	/**
	 * @return Returns the federate.
	 */
	public Federate getFederate() {
		return delegate;
	}

}
