/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.sm.models;

import java.io.IOException;
import java.util.List;

import javax.swing.event.EventListenerList;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;

import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.change.impl.EObjectToChangesMapEntryImpl;
import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eodisp.core.common.ReposServiceProxy;
import org.eodisp.core.sm.application.SmAppModuleCore;
import org.eodisp.core.sm.service.SmModelServiceProxy;
import org.eodisp.ui.common.base.EodispModel;
import org.eodisp.ui.common.components.SdoTreeNode;
import org.eodisp.ui.sm.application.SmAppModuleGui;
import org.eodisp.ui.sm.application.SmAppUtils;
import org.eodisp.ui.sm.controllers.SMAppController;
import org.eodisp.ui.sm.views.ExperimentTreeModelListener;
import org.eodisp.util.AppRegistry;

import commonj.sdo.DataObject;

/**
 * @author eglimi
 * @version $Id:$
 */
public class SmExpTreeModel extends DefaultTreeModel implements EodispModel {

	/**
	 * Default serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(SmExpTreeModel.class);

	private EventListenerList listenerList = new EventListenerList();

	/**
	 * The filter used to show only the content we want
	 */
	public SmExpTreeModel() {
		super(null);
	}

	/**
	 * Handle the value change. This means that the string representation for
	 * the given node has changed. This in turn should set the name of the
	 * object.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void valueForPathChanged(TreePath path, Object newValue) {
		SdoTreeNode node = (SdoTreeNode) path.getLastPathComponent();

		Object userObj = node.getUserObject();
		if (userObj != null) {
			EDataObject userDataObject = (EDataObject) userObj;

			List<Object> props = userDataObject.getInstanceProperties();

			for (int i = 0; i < props.size(); i++) {
				if (userDataObject.isSet(i)) {
					Object obj = props.get(i);
					if (obj instanceof EAttribute) {
						EAttribute prop = (EAttribute) props.get(i);
						if (prop.getName().equalsIgnoreCase("name")) {
							userDataObject.set(i, newValue);
						}
					}
				}
			}
			nodeChanged(node);
		}
	}

	public void doSave() throws IOException {
		if (getModelService() != null) {
			getModelService().save();
		}
	}

	/**
	 * {@inheritDoc}
	 * <p>
	 * Note that updating the tree model is especially expensive, since the
	 * whole tree will be rebuilt.
	 */
	public void doUpdate() {
		fireTreeWillReload();
		root = null;
		reload((SdoTreeNode) getRoot());
		fireTreeReloaded();
	}

	/**
	 * 
	 */
	public boolean hasChanges() {
		if (getModelService() != null) {
			return getModelService().isDirty();
		}

		return false;
	}

	public void redo() {
		// not supported yet. We do nothing
	}

	public void undo() {
		// not supported yet. We do nothing
	}

	@SuppressWarnings("unchecked")
	@Override
	public Object getRoot() {
		if (root == null) {
			if (getModelService() != null) {
				SMAppController appController = (SMAppController) ((SmAppModuleGui) AppRegistry.getRootApp()
						.getAppModule(SmAppModuleGui.ID)).getApplicationController();
				DataObject experiment = appController.getCurrentExperiment();
				root = new SdoTreeNode(experiment);
			}
		}

		return root;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Object getChild(Object parent, int index) {
		Object child = ((SdoTreeNode) parent).getChildAt(index);
		return child;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getChildCount(Object parent) {
		int count = ((SdoTreeNode) parent).getChildCount();
		return count;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isLeaf(Object node) {
		boolean leaf = ((SdoTreeNode) node).isLeaf();
		return leaf;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getIndexOfChild(Object parent, Object child) {
		return ((SdoTreeNode) parent).getIndex((TreeNode) child);
	}

	private ReposServiceProxy getReposService() {
		if (SmAppUtils.isConnected()) {
			return ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(SmAppModuleCore.ID)).getReposServiceProxy();
		}

		return null;
	}

	private SmModelServiceProxy getModelService() {
		return ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(SmAppModuleCore.ID)).getSmModelServiceProxy();
	}

	/**
	 * Returns the tree node that has the given <code>value</code> associated
	 * with it. It searches the tree hierarchy, starting from the given node.
	 * 
	 * @param node
	 *            The node from which the children hierarchy should be searched.
	 *            It includes the given tree in the search.
	 * @param value
	 *            The value that is associated with the tree node that this
	 *            method is searching for.
	 * @param refreshModel
	 *            Indicating whether the Emf model data should be reloaded
	 *            before searching for the tree node.
	 * @return The tree node that has the given <code>value</code> associated
	 *         with it or null, if no tree node was found.
	 */
	private SdoTreeNode getNodeForData(SdoTreeNode node, Object value) {
		if (node != null) {
			if (value instanceof EObject) {
				return node.getNodeForData(value);
			} else if (value instanceof EObjectToChangesMapEntryImpl) {
				return node.getNodeForData(((EObjectToChangesMapEntryImpl) value).getKey());
			}
		}

		return null;
	}

	private void fireTreeWillReload() {
		for (ExperimentTreeModelListener listener : getExperimentTreeListener()) {
			listener.treeWillReload();
		}
	}

	private void fireTreeReloaded() {
		for (ExperimentTreeModelListener listener : getExperimentTreeListener()) {
			listener.treeReloaded();
		}
	}

	public void addExperimentTreeListenerListener(ExperimentTreeModelListener listener) {
		listenerList.add(ExperimentTreeModelListener.class, listener);
	}

	public void removeExperimentTreeListener(ExperimentTreeModelListener listener) {
		listenerList.remove(ExperimentTreeModelListener.class, listener);
	}

	public ExperimentTreeModelListener[] getExperimentTreeListener() {
		return listenerList.getListeners(ExperimentTreeModelListener.class);
	}
}
