/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.sm.views;

import java.awt.Color;
import java.awt.Component;

import javax.swing.JTree;
import javax.swing.tree.DefaultTreeCellRenderer;

import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eodisp.core.common.ReposServiceProxy;
import org.eodisp.core.sm.application.SmAppModuleCore;
import org.eodisp.core.sm.helper.SmEmfHelper;
import org.eodisp.core.sm.service.ExperimentTaskManager;
import org.eodisp.core.sm.service.ExperimentTaskState;
import org.eodisp.ui.common.components.SdoTreeNode;
import org.eodisp.ui.sm.resources.SmResources;
import org.eodisp.util.AppRegistry;

/**
 * This is the renderer for the <code>JTree</code> in the
 * {@link SmExpTreeView}. It is able to display the most important status
 * information of the currently active experiment.
 * 
 * @author eglimi
 * @version $Id:$
 */
public class SmSdoTreeCellRenderer extends DefaultTreeCellRenderer {

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded,
			boolean leaf, int row, boolean hasFocus) {
		Component comp = super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);

		if (value instanceof SdoTreeNode) {
			EDataObject userObject = (EDataObject) ((SdoTreeNode) value).getUserObject();

			setBackgroundNonSelectionColor(getUnselectedColor(userObject));
			setBackgroundSelectionColor(getSelectedColor(userObject));
			if (sel) {
				setForeground(new Color(0xff, 0xff, 0xff));
			}

			final String text;
			// set icons and text
			if (SmEmfHelper.isExperiment(userObject)) {
				setIcon(SmResources.getIcon("experiment.png"));
				// setBorder(getBorder(userObject));
				text = SmEmfHelper.getName(userObject);
			} else if (SmEmfHelper.isFederationExecution(userObject)) {
				setIcon(SmResources.getIcon("federation.png"));
				// setBorder(getBorder(userObject));
				text = SmEmfHelper.getName(userObject);
			} else if (SmEmfHelper.isLocalFederate(userObject)) {
				setIcon(SmResources.getIcon("federate.png"));
				// setBorder(getBorder(userObject));
				text = SmEmfHelper.getName(userObject) + getModelManagerName(userObject);
			} else if (SmEmfHelper.isInitData(userObject)) {
				setIcon(SmResources.getIcon("initData.png"));
				// setBorder(getBorder(userObject));
				text = SmEmfHelper.getName(userObject, "localPath");
			} else {
				text = "illegal object";
			}

			setText(text);
		}

		return comp;
	}

	/**
	 * Returns the color for nodes that are selected.
	 * 
	 * @param userObject
	 *            The user object representing the node.
	 * @return The color that should be used as the background color for the
	 *         node.
	 */
	private Color getSelectedColor(EDataObject userObject) {
		return getUnselectedColor(userObject) != null ? getUnselectedColor(userObject) : new Color(0x72, 0x9f, 0xcf);
	}

	/**
	 * Returns the color for nodes that are not selected.
	 * 
	 * @param userObject
	 *            The user object representing the node.
	 * @return The color that should be used as the background color for the
	 *         node.
	 */
	private Color getUnselectedColor(EDataObject userObject) {
		ExperimentTaskManager taskManager = ((SmAppModuleCore) AppRegistry.getRootApp()
				.getAppModule(SmAppModuleCore.ID)).getExperimentTaskManager();
		ExperimentTaskState state = taskManager.getState(userObject);

		if (state != null) {

			if (state.hasError()) {
				return new Color(0xcc, 0x00, 0x00);
			}

			switch (state.getFederationState()) {
			case INITIALIZING:
			case INITIALIZED:
				return new Color(0xfc, 0xe9, 0x4f);
			case STARTING:
			case STARTED:
				return new Color(0x8a, 0xe2, 0x34);
			case STEPPING:
			case PAUSING:
			case PAUSED:
				return new Color(0xfc, 0xaf, 0x3e);
			case STOPPED:
				return new Color(0xd3, 0xd7, 0xcf);
			case RESUMING:
			case NOT_INITIALIZED:
			default:
				return null;
			}
		}

		return null;
	}

	private String getModelManagerName(EDataObject userObject) {
		ReposServiceProxy service = ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(SmAppModuleCore.ID))
				.getReposServiceProxy();
		String mmName = "";
		if (service != null) {
			mmName = SmEmfHelper.getModelManagerNameForFederate(service.getRootObject(), userObject);
		}

		if (!mmName.equals("")) {
			mmName = "  ( " + mmName + " )";
		}
		return mmName;
	}
}
