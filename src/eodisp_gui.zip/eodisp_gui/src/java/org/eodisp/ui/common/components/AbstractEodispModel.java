/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.common.components;

import javax.swing.event.EventListenerList;

import org.eodisp.ui.common.base.EodispModel;
import org.eodisp.ui.common.base.ModelListener;

/**
 * A default implementation of the <code>EodispModel</code> interface. It
 * essentially hast empty methods for the functionality most models do not
 * provide.
 * 
 * @author eglimi
 * @version $Id:$
 */
public abstract class AbstractEodispModel implements EodispModel {

	private EventListenerList listenerList = new EventListenerList();

	/**
	 * {@inheritDoc}
	 */
	public void doUpdate() {
	}

	/**
	 * {@inheritDoc}
	 */
	public void redo() {
	}

	/**
	 * {@inheritDoc}
	 */
	public void undo() {
	}

	/**
	 * Adds a listener to this model
	 * 
	 * @param listener
	 *            The listener to add.
	 */
	public void addModelListener(ModelListener listener) {
		listenerList.add(ModelListener.class, listener);
	}

	/**
	 * Removes a listener from this model
	 * 
	 * @param listener
	 *            The listener to remove.
	 */
	public void removeModelListener(ModelListener listener) {
		listenerList.remove(ModelListener.class, listener);
	}

	/**
	 * Returns all currently subscribed listeners.
	 * 
	 * @return A list of subscribed listeners.
	 */
	protected ModelListener[] getModelListener() {
		return listenerList.getListeners(ModelListener.class);
	}

	/**
	 * Informs all subscribed listeners that the model has changed.
	 */
	protected void fireModelChanged() {
		for (ModelListener listener : getModelListener()) {
			listener.modelChanged();
		}
	}

}
