/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.rm.models;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.AbstractListModel;

import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.sdo.EChangeSummary;
import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eodisp.core.common.ReposServiceProxy;
import org.eodisp.core.gen.repository.impl.RepositoryPackageImpl;
import org.eodisp.ui.common.components.AbstractEodispModel;
import org.eodisp.ui.rm.application.RmAppModuleGui;
import org.eodisp.ui.rm.application.RmAppUtils;
import org.eodisp.ui.rm.application.RmEmfHelper;
import org.eodisp.util.AppRegistry;

import commonj.sdo.DataObject;

/**
 * @author eglimi
 * @version $Id:$
 */
public class SomCategoriesModel extends AbstractEodispModel {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(SomCategoriesModel.class);

	private final DataObject curObj;

	private final CatListModel catListModel = new CatListModel(false);

	private final CatListModel regCatListModel = new CatListModel(true);

	public SomCategoriesModel(DataObject curObj) {
		this.curObj = curObj;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @throws IOException
	 */
	public void doSave() throws IOException {
		if (getReposService() != null) {
			getReposService().save();
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void doUpdate() {
		getCatListModel().update();
		getRegCatListModel().update();
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean hasChanges() {
		if (getReposService() != null) {
			return getReposService().isDirty();
		}

		return false;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void undo() {
		ReposServiceProxy service = getReposService();
		if (service != null) {
			EDataObject reposRoot = service.getRootObject();
			EChangeSummary cs = (EChangeSummary) reposRoot.getDataGraph().getChangeSummary();
			if (cs != null && cs.isLogging()) {
				cs.summarize();
			}
			cs.apply();
		}
	}

	/**
	 * Adds a category (or multiple categories) from the list of registered
	 * categories.
	 * 
	 * @param indices
	 *            The selection indices.
	 */
	@SuppressWarnings("unchecked")
	public void registerCat(Object[] categories) {
		if (curObj != null) {
			for (Object category : categories) {
				curObj.getList(RepositoryPackageImpl.SOM__CATEGORIES).add(category);
			}

			doUpdate();
		}
	}

	/**
	 * Removes a category (or multiple categories) from the list of registered
	 * categories.
	 * 
	 * @param indices
	 *            The selection indices.
	 */
	public void unregisterCat(Object[] categories) {
		if (curObj != null) {
			for (Object category : categories) {
				curObj.getList(RepositoryPackageImpl.SOM__CATEGORIES).remove(category);
			}

			doUpdate();
		}
	}

	public CatListModel getCatListModel() {
		return catListModel;
	}

	public CatListModel getRegCatListModel() {
		return regCatListModel;
	}

	/**
	 * Returns the repository service. This is only a convenience method.
	 * 
	 * @return The repository service or null, if there is no connection.
	 */
	private ReposServiceProxy getReposService() {
		if (RmAppUtils.isConnected()) {
			return ((RmAppModuleGui) AppRegistry.getRootApp().getAppModule(RmAppModuleGui.ID)).getReposServiceProxy();
		}

		return null;
	}

	@SuppressWarnings("serial")
	public class CatListModel extends AbstractListModel {

		private final List<DataObject> delegate = new ArrayList<DataObject>();

		private final boolean filter;

		public CatListModel(boolean filter) {
			this.filter = filter;
		}

		/**
		 * {@inheritDoc}
		 * <p>
		 * The implementation will directly return the element from the
		 * underlying model.
		 * </p>
		 */
		public Object getElementAt(int index) {
			if (delegate.size() - 1 >= index) {
				return delegate.get(index);
			}

			return null;
		}

		/**
		 * {@inheritDoc}
		 * <p>
		 * The implementation will directly check the underlying model for the
		 * number of elements.
		 * </p>
		 */
		public int getSize() {
			if (delegate.size() <= 0) {
				ReposServiceProxy service = getReposService();
				if (service != null) {
					List<DataObject> categories = RmEmfHelper.findAllCategories(service.getRootObject());
					int index = 0;
					for (DataObject category : categories) {
						if (passFilter(category)) {
							delegate.add(index, category);
							index++;
						}
					}
				}
			}

			return delegate.size();
		}

		private boolean passFilter(Object reposCat) {
			boolean found = false;
			List<DataObject> soms = RmEmfHelper.findSomsForCategory((DataObject) reposCat);

			for (DataObject som : soms) {
				if (som.equals(curObj)) {
					found = true;
				}
			}

			return (isFilter() && found) || (!isFilter() && !found);
		}

		/**
		 * @return Returns the filter.
		 */
		public boolean isFilter() {
			return filter;
		}

		public void update() {
			delegate.clear();
			fireContentsChanged(this, 0, getSize() - 1);
		}
	}
}
