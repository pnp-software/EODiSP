/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 *  web:  http://www.pnp-software.com
 *  mail: info@pnp-software.com
 */
package org.eodisp.ui.common.base;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * The EodispController is the base class for all controllers (except the
 * application controller) for this application. All generic (i.e. not
 * application specific) behaviour of a controller should go here.
 * <p>
 * Every specific controller in the EODiSP framework should sub-class this
 * class.
 * 
 * @author eglimi
 * @version $Id: EodispController.java 3776 2006-10-02 18:51:47Z eglimi $
 */
public abstract class EodispController {

	/**
	 * Holds a list of all views created for this application.
	 */
	private List<EodispView> views = new ArrayList<EodispView>();

	/**
	 * Default constructor.
	 */
	public EodispController() {
	}

	/**
	 * Register this controller as a target handler for certain actions used
	 * within the EODiSP simulation manager application.
	 * <p>
	 * For the registration, the EODiSP delegation mechanism is used (see
	 * {@link EodispDelegate}. Such an instance can be registered in the action
	 * itself, causing the method to be called whenever the action is performed.
	 */
	protected abstract void registerActionHandler();

	/**
	 * Creates all static views which this controller handles. Static views are
	 * those that are created at application startup and destroyed at sthutdown.
	 */
	protected abstract void createStaticViews();

	/**
	 * Returns whether this controller is responsible for creating the view with
	 * the given ID.
	 * 
	 * @param id
	 *            The static ID of the view in question.
	 * @return True, if the controller is responsible for this view, otherwise
	 *         false.
	 */
	public abstract boolean isControllerForView(int id);

	/**
	 * The controllers that implements this method and is responsible for
	 * creating the View with the given ID should create and return it.
	 * <p>
	 * The view will be managed automatically after that.
	 * 
	 * @param id
	 *            The static Id of the view which should be created.
	 * @return The new view or null, if the view could not be created.
	 */
	public abstract EodispView createDynamicView(int id);

	/**
	 * Returns all views which are handled by this controller.
	 * 
	 * @return A collection with elements of type <code>EodispView</code>'s.
	 *         It returns an empty collection if no views are currently handled
	 *         by this controller.
	 *         <p>
	 *         An empty collection does not indicate that this controller does
	 *         not handle any views, since it might handle dynamically created
	 *         views.
	 */
	public Collection<? extends EodispView> getViews() {
		return new ArrayList<EodispView>(views);
	}

	/**
	 * Adds a newly created view to the list of views for this application.
	 * 
	 * @param frame
	 *            The frame that has been created for this application.
	 */
	public void attachView(EodispView view) {
		views.add(view);
	}

	/**
	 * Detaches one specific view from the application.
	 * 
	 * @param frame
	 *            The frame to remove from the list of attached frames.
	 */
	public void detachView(EodispView view) {
		views.remove(view);
	}

	/**
	 * Initializes the controller. This should created the model connected to
	 * this controller as well as all frames and views.
	 */
	protected void initialize() {
		registerActionHandler();
	}

	protected void updateOwnedViewStates() {
		for (EodispView view : views) {
			view.updateViewState();
		}
	}

	protected void updateOwnedModels() {
		for (EodispView view : views) {
			if (view != null) {
				EodispModel model = view.getModel();
				if (model != null) {
					model.doUpdate();
				}
			}
		}
	}
}