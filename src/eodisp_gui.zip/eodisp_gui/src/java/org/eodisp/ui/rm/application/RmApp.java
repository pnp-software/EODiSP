/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com
 *  mail: info@pnp-software.com
 */
package org.eodisp.ui.rm.application;

import java.io.File;

import org.apache.log4j.Logger;
import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.ui.common.base.*;
import org.eodisp.ui.rm.config.RmGuiConfiguration;
import org.eodisp.util.RootApp;

/**
 * This is the main application class for the repos manager application in the
 * EODiSP framework. It is used to set-up the application and to load
 * application specific settings.
 * 
 * @author eglimi
 * @version $Id: SmApp.java 2859 2006-07-24 14:05:36Z ibirrer $
 * 
 */
public class RmApp extends RootApp implements UIApp {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(RmApp.class);

	/**
	 * The name of the application. This is shown on the command line.
	 */
	private static final String APP_NAME = "Repository Manager";

	private static final String APP_DESCRIPTION = "A GUI the EODiSP model repository";

	/**
	 * The name of the default directory in the working directory.
	 */
	private static final File DEFAULT_WORKING_DIR = new File(".eodisp", "repos_manager");

	/**
	 * The complete path of the working directory for the current application
	 * (the repos manager application).
	 */
	private static final File WORKING_DIR = new File(System.getProperty("user.home"), DEFAULT_WORKING_DIR.getPath());

	/**
	 * The default port that is used by the TCP transport.
	 */
	private static final int DEFAULT_TCP_PORT = 14312;

	/**
	 * Default constructor.
	 * 
	 */
	public RmApp() {
		super(APP_NAME, APP_DESCRIPTION, WORKING_DIR, RmMain.class);

		RemoteAppModule remoteAppModule = new RemoteAppModule(DEFAULT_TCP_PORT);
		registerAppModule(remoteAppModule);

		RmAppModuleGui rmAppModuleGui = new RmAppModuleGui();
		registerAppModule(rmAppModuleGui);

	}

	/**
	 * 
	 * {@inheritDoc}
	 */
	public EodispApplicationController getApplicationController() {
		return ((RmAppModuleGui) super.getAppModule(RmAppModuleGui.ID)).getApplicationController();
	}

	/**
	 * 
	 * {@inheritDoc}
	 */
	public EodispMainFrame getMainFrame() {
		return ((RmAppModuleGui) super.getAppModule(RmAppModuleGui.ID)).getApplicationController().getMainFrame();
	}

	/**
	 * 
	 * {@inheritDoc}
	 */
	public UiConfiguration getUiConfiguration() {
		return (UiConfiguration) super.getConfiguration(RmGuiConfiguration.ID);
	}
}
