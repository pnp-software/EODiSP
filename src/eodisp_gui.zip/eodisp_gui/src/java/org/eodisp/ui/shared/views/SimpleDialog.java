/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.shared.views;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.StyleSheet;

import org.eodisp.ui.common.base.UIUtil;
import org.eodisp.ui.common.resources.CommonMessages;

/**
 * This is a simple modal dialog that can be used to display a component. For
 * each type of content, a dedicated static method should be provided. The
 * resulting component will be added to a <code>JPanel</code> and placed in
 * the main panel (the content pane of the dialog). In addition, an 'Ok' button
 * will be added to close the window.
 * 
 * @author eglimi
 * @version $Id:$
 * 
 */
public class SimpleDialog {

	private final JDialog dialog;

	private final JButton dialogBtn;

	private final JPanel mainPanel = new JPanel(new BorderLayout());

	private final JPanel contentPanel = new JPanel();

	private final JPanel buttonPanel = new JPanel();

	private final JFrame owner;

	private SimpleDialog(JFrame owner) {
		this.owner = owner;

		dialog = new JDialog(owner, true);

		dialogBtn = new JButton(CommonMessages.getMessage("Button.Ok"));
		dialogBtn.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				exit();
			}
		});

		buttonPanel.add(dialogBtn);
	}

	private void show(Container comp) {

		contentPanel.add(comp);

		mainPanel.add(contentPanel, BorderLayout.CENTER);
		mainPanel.add(buttonPanel, BorderLayout.PAGE_END);

		dialog.setContentPane(mainPanel);
		dialog.pack();
		dialog.setLocationRelativeTo(owner);

		dialog.setVisible(true);
	}

	private void exit() {
		dialog.dispose();
	}

	/**
	 * Show a HTML text in an editor pane. The text should be valid HTML.
	 * Formatting of the text will be done with the rules from
	 * {@link UIUtil#getCssRules()}.
	 * 
	 * @param owner
	 *            The owner of the resulting dialog.
	 * @param htmlText
	 *            The HTML text. This should be valid HTML, including all tags.
	 */
	public static void showHtml(JFrame owner, String htmlText) {
		SimpleDialog simpleDialog = new SimpleDialog(owner);

		JEditorPane editorPane = new JEditorPane();

		editorPane.setContentType("text/html");
		editorPane.setEditable(false);

		StyleSheet styleSheet = ((HTMLEditorKit) editorPane.getEditorKit()).getStyleSheet();
		for (String rule : UIUtil.getCssRules()) {
			styleSheet.addRule(rule);
		}

		editorPane.setText(htmlText);

		simpleDialog.show(editorPane);
	}
}
