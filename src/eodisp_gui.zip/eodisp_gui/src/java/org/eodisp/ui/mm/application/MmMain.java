/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com
 *  mail: info@pnp-software.com
 */
package org.eodisp.ui.mm.application;

import org.apache.log4j.Logger;

/**
 * The main class for the model manager application in the EODiSP framework. It
 * is used to run the application.
 * <p>
 * Beside starting the application, this class has no functions. It is merely
 * the entry point which creates an {@link MmApp} instance. This will handle all
 * following initialization to create a running application.
 * 
 * @author eglimi
 * @version $Id: SimulationManagerMain.java 1125 2006-01-22 16:00:18Z eglimi $
 * 
 */
public class MmMain {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(MmMain.class);

	/**
	 * The main entry point for the model manager application user interface.
	 * 
	 * @param args
	 *            A list of options given as Strings. Options given here are
	 *            ignored.
	 */
	public static void main(String[] args) {
		MmApp mmApp = new MmApp();
		try {
			mmApp.execute(args);
		} catch (Exception ex) {
			logger.debug(
					"An uncaught exception has occurred. This should not happen! Shutting down the application.",
					ex);
			mmApp.shutdown();
			logger.debug("Application exited");
		}
	}

}
