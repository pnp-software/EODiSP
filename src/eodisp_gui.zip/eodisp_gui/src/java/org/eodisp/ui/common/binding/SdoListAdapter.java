/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.common.binding;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.sdo.EDataObject;

import com.jgoodies.binding.value.AbstractValueModel;
import com.jgoodies.binding.value.ValueModel;

/**
 * @author eglimi
 * @version $Id:$
 */
public class SdoListAdapter extends AbstractValueModel {

	public static final String PROPERTYNAME_BEAN = "bean";

	public static final String PROPERTYNAME_BEFORE_BEAN = "beforeBean";

	public static final String PROPERTYNAME_AFTER_BEAN = "afterBean";

	public static final String PROPERTYNAME_CHANGED = "changed";

	private final ValueModel beanChannel;

	Object storedOldBean;

	private final Map<String, SdoListPropertyAdapter> propertyAdapters = new HashMap<String, SdoListPropertyAdapter>();

	private PropertyChangeHandler propertyChangeHandler;

	private boolean changed = false;

	public SdoListAdapter(ValueModel beanChannel) {
		this.beanChannel = beanChannel;

		this.beanChannel.addValueChangeListener(new BeanChangeHandler());
		
//		addChangeHandlerTo(getBean());
	}

	/**
	 * {@inheritDoc}
	 */
	public Object getValue() {
		return beanChannel.getValue();
	}

	/**
	 * {@inheritDoc}
	 */
	public void setValue(Object newValue) {
		beanChannel.setValue(newValue);
	}

	public Object getBean() {
		return beanChannel.getValue();
	}

	private void setBean0(Object oldBean, Object newBean) {
		firePropertyChange(PROPERTYNAME_BEFORE_BEAN, oldBean, newBean, true);
//		removeChangeHandlerFrom(oldBean);
		forwardAllAdaptedValuesChanged(oldBean, newBean);
		resetChanged();
//		addChangeHandlerTo(newBean);
		firePropertyChange(PROPERTYNAME_BEAN, oldBean, newBean, true);
		firePropertyChange(PROPERTYNAME_AFTER_BEAN, oldBean, newBean, true);
	}

	public ValueModel getValueModel(String propertyName) {
		SdoListPropertyAdapter propertyAdapter = getPropertyAdapter(propertyName);

		if (propertyAdapter == null) {
			propertyAdapter = new SdoListPropertyAdapter(propertyName);
			propertyAdapters.put(propertyName, propertyAdapter);
			propertyAdapter.addPropertyChangeListener(new PropertyChangeHandler());
		}

		return propertyAdapter;
	}

	SdoListPropertyAdapter getPropertyAdapter(String propertyName) {
		return (SdoListPropertyAdapter) propertyAdapters.get(propertyName);
	}

	private void forwardAllAdaptedValuesChanged(Object oldBean, Object newBean) {
		for(SdoListPropertyAdapter adapter : propertyAdapters.values()) {
			adapter.setBean0(oldBean, newBean);
		}
	}

	private void setChanged(boolean newValue) {
		boolean oldValue = isChanged();
		changed = newValue;
		firePropertyChange(PROPERTYNAME_CHANGED, oldValue, newValue);
	}

	public boolean isChanged() {
		return changed;
	}

	public void resetChanged() {
		setChanged(false);
	}

	/**
	 * @author eglimi
	 * @version $Id:$
	 */
	private class SdoListPropertyAdapter extends AbstractValueModel {

		private final String propertyName;
		
		private int propertyIndex = -1;

		public SdoListPropertyAdapter(String propertyName) {
			this.propertyName = propertyName;
		}

		/**
		 * {@inheritDoc}
		 */
		public Object getValue() {
			
			return getValue(getBean());
		}
		
		private Object getValue(Object bean) {
			if(bean != null && bean instanceof EDataObject) {
				EDataObject curObj = (EDataObject) bean;
				List<Object> props = curObj.getInstanceProperties();
				for (int i = 0; i < props.size(); i++) {
						Object obj = props.get(i);
						if (obj instanceof EAttribute) {
							EAttribute prop = (EAttribute) props.get(i);
							// ignore many properties
							if (!prop.isMany() && prop.getName().equalsIgnoreCase(propertyName)) {
								propertyIndex = i;
								return curObj.get(i);
							}
					}
				}
			}
			
			return null;
		}

		/**
		 * {@inheritDoc}
		 */
		public void setValue(Object newValue) {
			Object bean = getBean();
			
			Object oldValue = getValue();
			
			if(bean != null && bean instanceof EDataObject) {
				EDataObject curObj = (EDataObject) bean;
				curObj.set(propertyIndex, newValue);
			}
			
			firePropertyChange(propertyName, oldValue, newValue);
		}

		void setBean0(Object oldBean, Object newBean) {
			if (oldBean != null || newBean != null) {
				fireValueChange(getValue(oldBean), getValue(newBean), true);
			}
		}
	}

	private class PropertyChangeHandler implements PropertyChangeListener {

		/**
		 * A bean property has been changed. Sets the changed state to true.
		 * Checks whether the observed or multiple properties have changed. If
		 * so, notifies all registered listeners about the change.
		 * 
		 * @param evt
		 *            the property change event to be handled
		 */
		public void propertyChange(PropertyChangeEvent evt) {
			setChanged(true);
			String propertyName = evt.getPropertyName();
			if (propertyName == null) {
			} else {
				SdoListPropertyAdapter adapter = getPropertyAdapter(propertyName);
				if (adapter != null) {
					adapter.fireValueChange(evt.getOldValue(), evt.getNewValue(), true);
				}
			}
		}

		void setBean0(Object oldBean, Object newBean) {
			if (oldBean != null || newBean != null) {
				fireValueChange(oldBean, newBean, true);
			}
		}
	}

	private class BeanChangeHandler implements PropertyChangeListener {

		/**
		 * The bean has been changed. Uses the stored old bean instead of the
		 * event's old value, because the latter can be null. If the event's new
		 * value is null, the new bean is requested from the bean channel.
		 * 
		 * @param evt
		 *            the property change event to be handled
		 */
		public void propertyChange(PropertyChangeEvent evt) {
			Object newBean = evt.getNewValue() != null ? evt.getNewValue() : getBean();
			setBean0(storedOldBean, newBean);
			storedOldBean = newBean;
		}
	}
}
