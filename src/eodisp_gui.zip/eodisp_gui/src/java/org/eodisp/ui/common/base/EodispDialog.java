/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.common.base;

import java.awt.Dimension;

import javax.swing.JDialog;
import javax.swing.JFrame;

import org.eodisp.util.AppRegistry;

/**
 * <p>
 * This is the base class for all dialogs used in the EODiSP framework. A dialog
 * is a minimal root window similar to the {@link EodispMainFrame}. However, it
 * lacks some features such as a menu bar, or a tool bar.
 * </p>
 * <p>
 * An <code>EodispDialog</code> can, for instance, be used as a configuration
 * window.
 * </p>
 * <p>
 * Note that the close operation is set to do nothing by default. This means,
 * the application has to change this value or it has to handle the window
 * closing event:
 * <p>
 * 
 * <pre>
 * dialog.addWindowListener(new WindowAdapter() {
 *   @Override
 *   public void windowClosing(WindowEvent e) {
 *     handleExit...
 *   }
 * });
 * </pre>
 * 
 * <p>
 * Only applications that implement the {@link UIApp} interface are allowed to
 * use this class.
 * </p>
 * 
 * @author eglimi
 * @version $Id:$
 * 
 */
public class EodispDialog extends JDialog {

	/**
	 * Default constructor.
	 * 
	 */
	public EodispDialog() {
		super(((UIApp) AppRegistry.getRootApp()).getMainFrame());

		setBehaviour();
	}

	/**
	 * Sets behaviour specific to this component.
	 * 
	 */
	private void setBehaviour() {
		// preferred size for dialogs...
		setPreferredSize(new Dimension(700, 400));
		
		// we don't want to exit here, since it should be handled by the
		// application itself.
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
	}
}
