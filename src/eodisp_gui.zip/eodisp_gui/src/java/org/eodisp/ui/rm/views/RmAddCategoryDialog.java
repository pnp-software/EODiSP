/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.rm.views;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import org.apache.log4j.Logger;
import org.eodisp.core.common.ReposServiceProxy;
import org.eodisp.ui.common.resources.CommonMessages;
import org.eodisp.ui.common.resources.MessageBoxHelper;
import org.eodisp.ui.rm.application.RmAppModuleGui;
import org.eodisp.ui.rm.application.RmEmfHelper;
import org.eodisp.ui.rm.resources.RmResources;
import org.eodisp.util.AppRegistry;

import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.factories.ButtonBarFactory;
import com.jgoodies.forms.factories.FormFactory;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

/**
 * @author eglimi
 * @version $Id:$
 */
public class RmAddCategoryDialog {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(RmAddCategoryDialog.class);

	private static final String TITLE = RmResources.getMessage("RmAddCategoryDialog.Title");

	private final JDialog dialog;

	private final JFrame owner;

	private RmAddCategoryDialog(JFrame owner) {
		this.owner = owner;

		dialog = new JDialog(owner, TITLE, true);

		initializeComponents();
		buildPanels();
		dialog.setContentPane(scrollPane);
	}

	/**
	 * Displays this dialog.
	 */
	public static void showAddCategoryDialog(JFrame owner) {
		RmAddCategoryDialog addCategoryDialog = new RmAddCategoryDialog(owner);
		addCategoryDialog.internalShowAddCategoryDialog();
	}

	private void internalShowAddCategoryDialog() {
		dialog.pack();
		dialog.setLocationRelativeTo(owner);
		dialog.setVisible(true);
		dialog.dispose();
	}

	/**
	 * This is the main panel that will hold all other components. It will be
	 * embedded in a scroll pane.
	 */
	private JPanel mainPanel;

	/**
	 * This is the main scroll pane that will be shown as the view's component.
	 */
	private final JScrollPane scrollPane = new JScrollPane();

	private final JTextField categoryName = new JTextField();

	private final JTextArea categoryDescription = new JTextArea();

	private final JCheckBox categoryClosed = new JCheckBox();

	/**
	 * Buttons for the dialog (save, cancel, etc).
	 */
	private final JButton[] dialogButtons = new JButton[2];

	private void initializeComponents() {

		// set behaviour
		categoryDescription.setLineWrap(true);
		categoryDescription.setWrapStyleWord(true);

		dialogButtons[0] = new JButton(CommonMessages.getMessage("Button.SaveExit"));
		dialogButtons[0].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addCategory();
				exitDialog();
			}
		});
		dialogButtons[1] = new JButton(CommonMessages.getMessage("Button.Cancel"));
		dialogButtons[1].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exitDialog();
			}
		});

		categoryName.setText(RmResources.getMessage("Cat.New.Template.CatName"));
		categoryDescription.setText(RmResources.getMessage("Cat.New.Template.CatDescription"));
	}

	private void buildPanels() {
		// create the layout
		CellConstraints cc = new CellConstraints();
		FormLayout layout = new FormLayout("right:50dlu, 4dlu, 75dlu:grow, 4dlu",
				"p, 1dlu, p, 3dlu, p, 1dlu, 100dlu, 3dlu, p, 1dlu, p, 20dlu, p");
		PanelBuilder builder = new PanelBuilder(layout);
		builder.setDefaultDialogBorder();
		buildPanel(builder, cc, layout);

		// get and set the panel
		mainPanel = builder.getPanel();
		scrollPane.setViewportView(mainPanel);
	}

	private void buildPanel(PanelBuilder builder, CellConstraints cc, FormLayout layout) {
		int labelCol = 1;
		// cat name
		builder.addLabel(RmResources.getMessage("RmCategoriesView.Label1.Text"), cc.xyw(labelCol, builder.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.add(categoryName, cc.xyw(labelCol, builder.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		// cat description
		builder.addLabel(RmResources.getMessage("RmCategoriesView.Label2.Text"), cc.xyw(labelCol, builder.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.add(new JScrollPane(categoryDescription), cc.xyw(labelCol, builder.getRow(), 3, "fill, fill"));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		// cat description
		builder.addLabel(RmResources.getMessage("RmCategoriesView.Label3.Text"), cc.xyw(labelCol, builder.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.add(categoryClosed, cc.xyw(labelCol, builder.getRow(), 3));
		builder.nextRow();

		// buttons
		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		JPanel btnPanel = ButtonBarFactory.buildRightAlignedBar(dialogButtons);
		builder.add(btnPanel, cc.xyw(builder.getColumn(), builder.getRow(), 3));
	}

	private void addCategory() {

		ReposServiceProxy service = ((RmAppModuleGui) AppRegistry.getRootApp().getAppModule(RmAppModuleGui.ID))
				.getReposServiceProxy();

		if (service != null) {
			try {
				RmEmfHelper.createCategory(service.getRootObject(), categoryName.getText(), categoryDescription
						.getText(), categoryClosed.isSelected());
			} catch (Exception e) {
				MessageBoxHelper.ErrorBoxL(dialog, "Error.Transfer.Msg", "Error.Transfer.Cap", e.getMessage());
			}
		}
	}

	/**
	 * Closes the dialog.
	 */
	private void exitDialog() {
		dialog.dispose();
	}
}
