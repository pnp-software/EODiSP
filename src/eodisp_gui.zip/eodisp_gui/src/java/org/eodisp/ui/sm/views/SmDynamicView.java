/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.sm.views;

import java.awt.BorderLayout;
import java.awt.Component;

import javax.swing.JPanel;
import javax.swing.JTextArea;

import net.infonode.docking.RootWindow;
import net.infonode.docking.theme.ShapedGradientDockingTheme;
import net.infonode.docking.util.DockingUtil;
import net.infonode.docking.util.ViewMap;

import org.eodisp.ui.common.base.EodispView;

/**
 * @author eglimi
 * @version $Id:$
 * 
 */
public class SmDynamicView extends EodispView {

	/**
	 * default serial version id.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * This is a root window that can be used for dynamic views.
	 */
	protected RootWindow dynamicWindow;

	/**
	 * This is the initial view displayed in the root window in order to have
	 * something in place when the application starts.
	 */
	EodispView initialView;

	/**
	 * This is the component that will hold the whole panel.
	 */
	JPanel mainPane = null;

	JPanel initialPanel = null;

	/**
	 * The id of this view. This is used to identify the view within the
	 * application.
	 */
	public static final int ID = 1;

	@Override
	public int getId() {
		return ID;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Component getInternalComponent() {
		if (mainPane == null) {
			mainPane = new JPanel(new BorderLayout());
			mainPane.add(dynamicWindow, BorderLayout.CENTER);
		}
		
		return mainPane;
	}

	@Override
	public void initializeComponents() {
		// disable some view properties
		getViewProperties().setAlwaysShowTitle(false);
//		getViewProperties().getViewTitleBarProperties().setVisible(false);
//		getWindowProperties().setCloseEnabled(false);
//		getWindowProperties().setMaximizeEnabled(false);
//		getWindowProperties().setUndockEnabled(false);
		
		initialPanel = new JPanel();
		initialPanel.add(new JTextArea("Please select something on the left side."));

		ViewMap viewMap = new ViewMap();
		dynamicWindow = DockingUtil.createRootWindow(viewMap, false);
		
		dynamicWindow.getRootWindowProperties().addSuperObject(
				new ShapedGradientDockingTheme().getRootWindowProperties());
		
		setComponent(getInternalComponent());
	}

	public void addDynamicView(EodispView view) {
		DockingUtil.addWindow(view, dynamicWindow);
		view.restoreFocus();
	}
	
	public void removeDynamicView(EodispView view) {
		dynamicWindow.removeView(view);
	}
}
