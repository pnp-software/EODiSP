/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.common.resources;

import java.awt.Component;

import javax.swing.JOptionPane;

import org.eodisp.ui.common.base.UIApp;
import org.eodisp.util.AppRegistry;

/**
 * This class encapsulates the creation of message boxes. Every message box
 * should be created by using one of the static methods provided here, or, for
 * common message boxes, by using one of the methods provided by
 * {@link CommonMessages}}.
 * 
 * @author eglimi
 * @version $Id:$
 */
public final class MessageBoxHelper {

	/**
	 * A message box with fedListButtons as indicated by the name of the method.
	 * 
	 * @param parent
	 *            The parent component. If null is given, the main frame will be
	 *            chosen as the parent component.
	 * @param textLookup
	 *            The lookup string used to find the message text in the
	 *            resource file.
	 * @param captionLookup
	 *            The lookup string used to title text in the resource file.
	 * @param objs
	 *            An additional array of objects that will be appended to the
	 *            message. It just appends (on a new line) the message at the
	 *            end of the <code>textLookup</code> String. It will be used
	 *            for the text only, not for the caption.
	 * @return The value indicating which option the user has selected.
	 */
	public static int YesNoQuestionBoxL(Component parent, String textLookup, String captionLookup,
			Object... objs) {
		if (parent == null) {
			parent = ((UIApp) AppRegistry.getRootApp()).getMainFrame();
		}

		StringBuilder sb = new StringBuilder();
		sb.append(getMessageBoxText(textLookup));
		if (objs.length > 0) {
			sb.append("\n");
			sb.append(CommonMessages.getMessage("Dialog.Additional.Info"));
			for (Object obj : objs) {
				sb.append("\n");
				sb.append(obj);
			}
		}

		return JOptionPane.showConfirmDialog(parent, sb.toString(),
				getMessageBoxText(captionLookup), JOptionPane.YES_NO_OPTION);
	}

	/**
	 * A message box with fedListButtons as indicated by the name of the method.
	 * 
	 * @param parent
	 *            The parent component. If null is given, the main frame will be
	 *            chosen as the parent component.
	 * @param textLookup
	 *            The lookup string used to find the message text in the
	 *            resource file.
	 * @param captionLookup
	 *            The lookup string used to title text in the resource file. *
	 * @param objs
	 *            An additional array of objects that will be appended to the
	 *            message. It just appends (on a new line) the message at the
	 *            end of the <code>textLookup</code> String. It will be used
	 *            for the text only, not for the caption.
	 * @return The value indicating which option the user has selected.
	 */
	public static int YesNoCancelQuestionBoxL(Component parent, String textLookup,
			String captionLookup, Object... objs) {
		if (parent == null) {
			parent = ((UIApp) AppRegistry.getRootApp()).getMainFrame();
		}

		StringBuilder sb = new StringBuilder();
		sb.append(getMessageBoxText(textLookup));
		if (objs.length > 0) {
			sb.append("\n");
			sb.append(CommonMessages.getMessage("Dialog.Additional.Info"));
			for (Object obj : objs) {
				sb.append("\n");
				sb.append(obj);
			}
		}

		return JOptionPane.showConfirmDialog(parent, sb.toString(),
				getMessageBoxText(captionLookup), JOptionPane.YES_NO_CANCEL_OPTION);
	}

	/**
	 * An error box with a confirmation button to close the dialog. Nothing will
	 * be returned to the caller.
	 * 
	 * @param parent
	 *            The parent component. If null is given, the main frame will be
	 *            chosen as the parent component.
	 * @param textLookup
	 *            The lookup string used to find the message text in the
	 *            resource file. *
	 * @param objs
	 *            An additional array of objects that will be appended to the
	 *            message. It just appends (on a new line) the message at the
	 *            end of the <code>textLookup</code> String. It will be used
	 *            for the text only, not for the caption.
	 * @param captionLookup
	 */
	public static void ErrorBoxL(Component parent, String textLookup, String captionLookup,
			Object... objs) {
		if (parent == null) {
			parent = ((UIApp) AppRegistry.getRootApp()).getMainFrame();
		}

		StringBuilder sb = new StringBuilder();
		sb.append(getMessageBoxText(textLookup));
		if (objs.length > 0) {
			sb.append("\n");
			sb.append(CommonMessages.getMessage("Dialog.Additional.Info"));
			for (Object obj : objs) {
				sb.append("\n");
				sb.append(obj);
			}
		}

		JOptionPane.showMessageDialog(parent, sb.toString(), getMessageBoxText(captionLookup),
				JOptionPane.ERROR_MESSAGE);
	}

	/**
	 * Uses the provided lookup string to find a message in the appropriate
	 * resource file.
	 * 
	 * @param lookup
	 * @return
	 */
	private static String getMessageBoxText(String lookup) {
		return CommonMessages.getMessage(lookup);
	}
}
