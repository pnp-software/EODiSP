/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.sm.application;

import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eodisp.core.common.EmfUtil;
import org.eodisp.core.common.ReposServiceProxy;
import org.eodisp.core.gen.repository.impl.RepositoryPackageImpl;
import org.eodisp.core.mm.config.MmConfiguration;
import org.eodisp.core.sm.application.SmAppModuleCore;
import org.eodisp.core.sm.config.SmConfiguration;
import org.eodisp.core.sm.helper.SmEmfHelper;
import org.eodisp.core.sm.service.SmModelServiceProxy;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.configuration.Configuration;

import commonj.sdo.DataObject;

/**
 * @author eglimi
 * @version $Id:$
 */
public class SmAppUtils {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(SmAppUtils.class);

	public static boolean isConnected() {
		return ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(SmAppModuleCore.ID)).getSmCoreServiceProxy()
				.isReposConnected();
	}

	public static boolean isAppRegistered() {
		if (!isConnected()) {
			return false;
		}

		ReposServiceProxy service = ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(SmAppModuleCore.ID))
				.getReposServiceProxy();
		if (service == null) {
			return false;
		}

		String id = AppRegistry.getRootApp().getConfiguration(SmConfiguration.ID).getEntry(SmConfiguration.APP_ID)
				.getValue();
		if (id == null || id.equalsIgnoreCase("")) {
			return false;
		}

		DataObject reposRoot = service.getRootObject();
		if (reposRoot != null) {
			return reposRoot.getDataObject(String.format("simManagers[id=%s]", id)) != null ? true : false;
		}

		return false;
	}

	public static void registerApp(DataObject reposRoot, Configuration config) throws IllegalArgumentException,
			IllegalStateException {

		if (config == null) {
			final String message = "The provided root object must not be null and of type DataObject";
			logger.warn(message);
			throw new IllegalArgumentException(message);
		}

		String smId = ((SmConfiguration) config).getEntry(MmConfiguration.APP_ID).getValue();
		EDataObject smMgr = SmEmfHelper.findReposSimulationManager(reposRoot, smId);

		if (smMgr != null) {
			final String message = "The simulation manager is already registered in the repository. Ignoring request to register.";
			logger.debug(message);
			throw new IllegalStateException(message);
		}

		logger.debug("Register this application in the repository");

		// create the new entry
		smMgr = (EDataObject) reposRoot.createDataObject(RepositoryPackageImpl.REPOSITORY__SIM_MANAGERS);
		SmEmfHelper.copyApplicationData(smMgr, config);
	}

	public static void updateRegistration(DataObject reposRoot, Configuration config) throws IllegalArgumentException {

		if (config == null) {
			final String message = "The provided root object must not be null and of type DataObject";
			logger.warn(message);
			throw new IllegalArgumentException(message);
		}

		String smId = ((SmConfiguration) config).getEntry(MmConfiguration.APP_ID).getValue();
		EDataObject smMgr = SmEmfHelper.findReposSimulationManager(reposRoot, smId);

		if (smMgr == null) {
			final String message = "The simulation manager could not be found in the repository (possibly unregistered). Ignoring request to update registration.";
			logger.debug(message);
			throw new IllegalStateException(message);
		}

		SmEmfHelper.copyApplicationData(smMgr, config);
	}

	public static void unregisterApp(DataObject reposRoot, String smId) throws IllegalArgumentException,
			IllegalStateException {

		EDataObject smMgr = SmEmfHelper.findReposSimulationManager(reposRoot, smId);

		if (smMgr == null) {
			final String message = "The simulation manager could not be found in the repository (possibly unregistered). Ignoring request to unregister.";
			logger.debug(message);
			throw new IllegalStateException(message);
		}

		EmfUtil.delete(smMgr);
	}

	/**
	 * Returns the model service for the simulation manager. This is only a
	 * convenience method.
	 * 
	 * @return The model service or null, if there is no connection.
	 */
	public static SmModelServiceProxy getModelService() {
		return ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(SmAppModuleCore.ID)).getSmModelServiceProxy();
	}

	/**
	 * Returns the repository service for the simulation manager. This is only a
	 * convenience method.
	 * 
	 * @return The repository service or null, if there is no connection.
	 */
	public static ReposServiceProxy getReposService() {
		if (isConnected()) {
			return ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(SmAppModuleCore.ID)).getReposServiceProxy();
		}

		return null;
	}
}
