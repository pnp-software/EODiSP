/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.sm.models;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.SwingUtilities;
import javax.swing.table.AbstractTableModel;

import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eodisp.core.sm.application.SmAppModuleCore;
import org.eodisp.core.sm.service.ExperimentListener;
import org.eodisp.core.sm.service.ExperimentTaskManager;
import org.eodisp.core.sm.service.ExperimentTaskState;
import org.eodisp.ui.common.base.EodispModel;
import org.eodisp.ui.common.base.UIApp;
import org.eodisp.ui.sm.controllers.SMAppController;
import org.eodisp.ui.sm.resources.SmResources;
import org.eodisp.util.AppRegistry;

/**
 * This is the model for the property sheet used in the simulation manager
 * application. It will display the properties of an object item in the
 * simulation manager project file.
 * <p>
 * This model can be used by a {@link javax.swing.JTable} to display the
 * properties.
 * <p>
 * This model is tightly coupled with the Emf framework. The model itself holds
 * no data, all data is directly retrieved from the Emf framework.
 * 
 * @author eglimi
 * @version $Id:SMPropertySheetModel.java 1941 2006-04-21 11:30:46Z eglimi $
 */
@SuppressWarnings("serial")
public class SmErrorModel extends AbstractTableModel implements EodispModel {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(SmErrorModel.class);

	private final ExperimentObserver experimentObserver = new ExperimentObserver();

	private final List<Throwable> errors = new ArrayList<Throwable>();
	
	/**
	 * Constructor.
	 */
	public SmErrorModel() {
		super();

		ExperimentTaskManager taskMgr = ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(SmAppModuleCore.ID))
				.getExperimentTaskManager();

		taskMgr.addExperimentListener(experimentObserver);
	}

	/**
	 * {@inheritDoc}
	 */
	public int getColumnCount() {
		return 1;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String getColumnName(int column) {

		// always show these headers, even if no property is displayed...
		switch (column) {
		case 0:
			return SmResources.getMessage("SmErrorView.Table.Header1");
		case 1:
			return SmResources.getMessage("SmErrorView.Table.Header2");
		default:
			return "";
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public int getRowCount() {
		return errors.size();
	}

	/**
	 * {@inheritDoc}
	 */
	public Object getValueAt(int rowIndex, int columnIndex) {

		switch (columnIndex) {
		case 0:
			return errors.get(rowIndex).getMessage();
		case 1:
			StringBuilder sb = new StringBuilder();
			StackTraceElement[] elements = errors.get(rowIndex).getStackTrace();
			for (StackTraceElement element : elements) {
				sb.append(element);
			}
			return sb.toString();
		default:
			return null;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
		// not settable
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean hasChanges() {
		// done by the SMProjectTreeModel for this Emf resource
		return false;
	}

	/**
	 * {@inheritDoc}
	 */
	public void doSave() throws IOException {
		// ignoring request -> save is handled by the proper view that displays
		// this properties
	}

	/**
	 * {@inheritDoc}
	 */
	public void doUpdate() {
		// ignore
	}

	/**
	 * {@inheritDoc}
	 */
	public void redo() {
		// ignoring request
	}

	/**
	 * {@inheritDoc}
	 */
	public void undo() {
		// ignoring request
	}

	private void checkErrors() {

		ExperimentTaskManager taskMgr = ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(SmAppModuleCore.ID))
				.getExperimentTaskManager();

		ExperimentTaskState experimentTaskState = taskMgr.getState(getCurrentExperiment());
		errors.clear();
		if (experimentTaskState != null && experimentTaskState.hasError()) {

			for (Throwable error : experimentTaskState.getErrors()) {
				errors.add(error);
			}
		}

		fireTableDataChanged();
	}
	
	private EDataObject getCurrentExperiment() {
		return ((SMAppController) ((UIApp) AppRegistry.getRootApp()).getApplicationController()).getCurrentExperiment();
	}

	private class ExperimentObserver implements ExperimentListener {

		public void experimentChanged() {
			SwingUtilities.invokeLater(new Runnable() {

				public void run() {
					checkErrors();
				}

			});
		}
	}
}