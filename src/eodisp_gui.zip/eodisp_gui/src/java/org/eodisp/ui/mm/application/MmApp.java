/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com
 *  mail: info@pnp-software.com
 */
package org.eodisp.ui.mm.application;

import java.io.File;

import org.apache.log4j.Logger;
import org.eodisp.core.mm.application.MmAppModuleCore;
import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.remote.launcher.server.application.RootAppStartedCallbackAppModule;
import org.eodisp.ui.common.base.*;
import org.eodisp.ui.mm.config.MmGuiConfiguration;
import org.eodisp.util.RootApp;

/**
 * This is the main application class for the model manager application in the
 * EODiSP framework. It is used to set-up the application and to load
 * application specific settings.
 * 
 * @author eglimi
 * 
 */
public class MmApp extends RootApp implements UIApp {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(MmApp.class);

	/**
	 * The name of the application. This is shown on the command line.
	 */
	private static final String APP_NAME = "Model Manager";

	private static final String APP_DESCRIPTION = "The EODiSP Model Manager Application";

	/**
	 * The name of the default directory in the working directory.
	 */
	private static final File DEFAULT_WORKING_DIR = new File(".eodisp", "model_manager");

	/**
	 * The complete path of the working directory for the current application
	 * (the model repository application).
	 */
	private static final File WORKING_DIR = new File(System.getProperty("user.home"), DEFAULT_WORKING_DIR.getPath());

	/**
	 * The default port that is used by the TCP transport.
	 */
	private static final int DEFAULT_TCP_PORT = 14312;

	/**
	 * Default constructor.
	 * 
	 */
	public MmApp() {
		super(APP_NAME, APP_DESCRIPTION, WORKING_DIR, MmMain.class);

		RemoteAppModule remoteAppModule = new RemoteAppModule(DEFAULT_TCP_PORT);
		registerAppModule(remoteAppModule);

		MmAppModuleCore mmAppModuleCore = new MmAppModuleCore();
		registerAppModule(mmAppModuleCore);
		
		registerAppModule(new RootAppStartedCallbackAppModule());

		MmAppModuleGui smAppModuleGui = new MmAppModuleGui();
		registerAppModule(smAppModuleGui);

	}

	/**
	 * 
	 * {@inheritDoc}
	 */
	public EodispApplicationController getApplicationController() {
		return ((MmAppModuleGui) super.getAppModule(MmAppModuleGui.ID)).getApplicationController();
	}

	/**
	 * 
	 * {@inheritDoc}
	 */
	public EodispMainFrame getMainFrame() {
		return ((MmAppModuleGui) super.getAppModule(MmAppModuleGui.ID)).getApplicationController().getMainFrame();
	}

	/**
	 * 
	 * {@inheritDoc}
	 */
	public UiConfiguration getUiConfiguration() {
		return (UiConfiguration) super.getConfiguration(MmGuiConfiguration.ID);
	}
}
