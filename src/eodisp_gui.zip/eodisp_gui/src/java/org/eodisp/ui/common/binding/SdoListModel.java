/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.common.binding;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import com.jgoodies.binding.beans.BeanAdapter;
import com.jgoodies.binding.beans.BeanUtils;
import com.jgoodies.binding.beans.Model;
import com.jgoodies.binding.value.ValueModel;

/**
 * @author eglimi
 * @version $Id:$
 */
public class SdoListModel extends Model {

	public static final String PROPERTYNAME_BEAN = "bean";

	public static final String PROPERTYNAME_BEFORE_BEAN = "beforeBean";

	public static final String PROPERTYNAME_AFTER_BEAN = "afterBean";
	
	public static final String PROPERTYNAME_CHANGED = "changed";

	private final PropertyChangeListener changedUpdateHandler;

	private final ValueModel beanChannel;

	private final SdoListAdapter beanAdapter;

	private boolean changed = false;

	public SdoListModel(ValueModel beanChannel) {
		this.beanChannel = beanChannel;
		this.beanAdapter = new SdoListAdapter(beanChannel);
		this.changedUpdateHandler = new UpdateHandler();

		beanAdapter.addPropertyChangeListener(new BeanChangeHandler());

		// observe changes
		observeChanged(beanAdapter, PROPERTYNAME_CHANGED);
	}

	public void observeChanged(Object bean, String propertyName) {
		if (bean == null)
			throw new NullPointerException("The bean must not be null.");
		if (propertyName == null)
			throw new NullPointerException("The property name must not be null.");

		BeanUtils.addPropertyChangeListener(bean, propertyName, changedUpdateHandler);
	}

	public ValueModel getModel(String propertyName) {
		return beanAdapter.getValueModel(propertyName);
	}

	public Object getBean() {
		return beanChannel.getValue();
	}

	public void setBean(Object newBean) {
		beanChannel.setValue(newBean);
	}

	public void beforeBeanChange(Object oldBean, Object newBean) {
		firePropertyChange(PROPERTYNAME_BEFORE_BEAN, oldBean, newBean, true);
	}

	public void afterBeanChange(Object oldBean, Object newBean) {
		setChanged(false);
		firePropertyChange(PROPERTYNAME_AFTER_BEAN, oldBean, newBean, true);
	}

	protected void setChanged(boolean newValue) {
		boolean oldValue = isChanged();
		changed = newValue;
		firePropertyChange(PROPERTYNAME_CHANGED, oldValue, newValue);
	}

	public boolean isChanged() {
		return changed;
	}

	/**
	 * Listens to changes of the bean, invoked the before and after methods, and
	 * forwards the bean change events.
	 */
	private class BeanChangeHandler implements PropertyChangeListener {

		/**
		 * The target bean will change, changes, or has changed.
		 * 
		 * @param evt
		 *            the property change event to be handled
		 */
		public void propertyChange(PropertyChangeEvent evt) {
			Object oldBean = evt.getOldValue();
			Object newBean = evt.getNewValue();
			String propertyName = evt.getPropertyName();
			if (BeanAdapter.PROPERTYNAME_BEFORE_BEAN.equals(propertyName)) {
				beforeBeanChange(oldBean, newBean);
			} else if (BeanAdapter.PROPERTYNAME_BEAN.equals(propertyName)) {
				firePropertyChange(PROPERTYNAME_BEAN, oldBean, newBean, true);
			} else if (BeanAdapter.PROPERTYNAME_AFTER_BEAN.equals(propertyName)) {
				afterBeanChange(oldBean, newBean);
			}
		}
	}

	/**
	 * Listens to model changes and updates the changed state.
	 */
	private class UpdateHandler implements PropertyChangeListener {

		/**
		 * A registered ValueModel has changed. Updates the changed state. If
		 * the property that changed is 'changed' we assume that this is another
		 * changed state and forward only changes to true. For all other
		 * property names, we just update our changed state to true.
		 * 
		 * @param evt
		 *            the event that describes the property change
		 */
		public void propertyChange(PropertyChangeEvent evt) {
			String propertyName = evt.getPropertyName();
			if (!PROPERTYNAME_CHANGED.equals(propertyName)
					|| ((Boolean) evt.getNewValue()).booleanValue()) {
				setChanged(true);
			}
		}
	}
}
