/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.mm.application;

import java.io.File;

import javax.swing.SwingUtilities;

import org.apache.log4j.Logger;
import org.eodisp.ui.common.base.EodispApplicationController;
import org.eodisp.ui.common.base.UIUtil;
import org.eodisp.ui.mm.config.MmGuiConfiguration;
import org.eodisp.ui.mm.controllers.MmAppController;
import org.eodisp.util.AppModule;
import org.eodisp.util.RootApp;
import org.eodisp.util.configuration.CommandlineMapper;

/**
 * @author eglimi
 * @version $Id:$
 */
public class MmAppModuleGui implements AppModule {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(MmAppModuleGui.class);

	/**
	 * Holds the application controller. This is the main controller for the
	 * whole application. For each application, there is only one application
	 * controller.
	 */
	private EodispApplicationController appController = null;

	/**
	 * The Id of this Application Module.
	 */
	public static final String ID = "org.eodisp.ui.mm.application.MmAppModuleGui";

	/**
	 * The name of the GUI configuration file used in the model manager
	 * application.
	 */
	private static final String CONFIG_FILE_GUI = "mm_gui.conf";

		/**
	 * {@inheritDoc}
	 */
	public String getId() {
		return ID;
	}

	/**
	 * {@inheritDoc}
	 */
	public void registerConfiguration(RootApp rootApp) throws Exception {
		// Gui Config
		File configFileGui = new File(rootApp.getConfigurationDir(), CONFIG_FILE_GUI);
		MmGuiConfiguration mmGuiConfiguration = new MmGuiConfiguration(configFileGui);

		// register configurations
		rootApp.registerConfiguration(mmGuiConfiguration,
				CommandlineMapper.BASIC_COMMAND_LINE_MAPPER);
	}

	/**
	 * <p>
	 * Configures some settings for the application before it is started.
	 * </p>
	 * {@inheritDoc}
	 */
	public void preStartup(RootApp rootApp) throws Exception {
		if (!getConfig(rootApp).isNoGui()) {
			UIUtil.configureUI();
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void startup(RootApp rootApp) throws Exception {
		if (!getConfig(rootApp).isNoGui()) {
			appController = new MmAppController();
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					appController.initialize();
				}
			});
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void shutdown(RootApp rootApp) throws Exception {
		// dispose all windows before exiting
		if (!getConfig(rootApp).isNoGui()) {
			getApplicationController().getMainFrame().dispose();
		}
	}

	/**
	 * @param rootApp
	 * @return
	 */
	private MmGuiConfiguration getConfig(RootApp rootApp) {
		return (MmGuiConfiguration) rootApp.getConfiguration(MmGuiConfiguration.ID);
	}

	/**
	 * {@inheritDoc}
	 */
	public void postShutdown(RootApp rootApp) throws Exception {
		/*
		 * TODO: Other app modules' postShutdown method will not be run. Better
		 * move the System.exit() to the main().
		 */
		System.exit(0);
	}

	/**
	 * Returns the main application controller for this application. This can be
	 * handy in order to cleanly shutdown the application, get the main frame,
	 * etc.
	 * 
	 * @return The application controller of this application. See
	 *         {@link EodispApplicationController} for mor information.
	 */
	public EodispApplicationController getApplicationController() {
		return appController;
	}
}
