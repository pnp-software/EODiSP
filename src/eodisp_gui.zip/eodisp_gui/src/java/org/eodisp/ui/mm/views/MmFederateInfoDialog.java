/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.mm.views;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.*;

import org.apache.log4j.Logger;
import org.eodisp.core.mm.service.Federate;
import org.eodisp.ui.common.resources.CommonMessageBoxes;
import org.eodisp.ui.mm.models.MmFederateInfoModel;
import org.eodisp.ui.mm.resources.MmResources;

import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.factories.ButtonBarFactory;
import com.jgoodies.forms.factories.FormFactory;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

/**
 * This is a small dialog that display additional information for a federate.
 * <p>
 * 
 * In principle, all information needed to work with a federate is stored in the
 * federate bundle itself. However, it might be useful to store some additional
 * information such as the operation system, the java runtime environment used
 * on the machine, etc. This can then be used on the simulation manager
 * application in order to decide with federate is shall choose, if there are
 * several identical federates registered in the repository.
 * <p>
 * 
 * The implementation of this dialog is very simple and does not leverage the
 * usage of data binding or similar. It just reads the text from the model at
 * the beginning and sets the text whenever the user chooses to do so. The
 * reason is because this additional information is a bit special in regard to
 * the rest of the information from the federate. Because the model manager
 * retrieves all federate information from the bundle, it does not have its own
 * model to store additional data. Therefore, the additional information is only
 * stored on the repository. This is why it is handled separately in this
 * dialog.
 * 
 * <strong>Remember:</strong><br>
 * Since the data is only stored in the repository, additional information can
 * only be set for a registered federate and will be lost upon connecting to
 * another repository.
 * 
 * @author eglimi
 * @version $Id:$
 */
public class MmFederateInfoDialog {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(MmFederateInfoDialog.class);
	
	private static final String TITLE = MmResources.getMessage("MmFederateInfoDialog.Title");

	private final JDialog dialog;

	private JPanel mainPanel;

	private final JScrollPane scrollPane = new JScrollPane();

	private final JTextArea federateInfo = new JTextArea();

	private final JButton[] dialogButtons = new JButton[2];

	private final MmFederateInfoModel model;

	private final JFrame owner;

	private MmFederateInfoDialog(JFrame owner, Federate federate) {
		this.owner = owner;

		dialog = new JDialog(owner, TITLE, true);

		model = new MmFederateInfoModel(federate);

		initializeComponents();
		buildPanels();
		dialog.setContentPane(scrollPane);
	}

	/**
	 * Displays this dialog.
	 */
	public static void showInitDataDialog(JFrame owner, Federate federate) {
		MmFederateInfoDialog initiDataDialog = new MmFederateInfoDialog(owner, federate);
		initiDataDialog.showInernalInitDataDialog();
	}

	private void showInernalInitDataDialog() {
		dialog.pack();
		dialog.setLocationRelativeTo(owner);
		dialog.setVisible(true);
		dialog.dispose();
	}

	private void initializeComponents() {

		// set text
		federateInfo.setText(model.getInfoText());

		// set specific behaviour
		federateInfo.setLineWrap(true);
		federateInfo.setWrapStyleWord(true);

		dialogButtons[0] = new JButton(MmResources.getMessage("MmFederateInfoDialog.Button10.Text"));
		dialogButtons[0].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					save();
				} catch (IOException ex) {
					CommonMessageBoxes.showSaveError(dialog, ex.getMessage());
					return;
				}
				exitDialog();
			}
		});
		dialogButtons[1] = new JButton(MmResources.getMessage("MmFederateInfoDialog.Button11.Text"));
		dialogButtons[1].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exitDialog();
			}
		});
	}

	private void buildPanels() {
		// create the layout
		CellConstraints cc = new CellConstraints();
		FormLayout layout = new FormLayout("right:50dlu, 4dlu, 75dlu:grow", "p, 1dlu, 100dlu, 3dlu, p");
		PanelBuilder builder = new PanelBuilder(layout);
		builder.setDefaultDialogBorder();
		buildPanel(builder, cc, layout);

		// get and set the panel
		mainPanel = builder.getPanel();
		scrollPane.setViewportView(mainPanel);
	}

	private void buildPanel(PanelBuilder builder, CellConstraints cc, FormLayout layout) {
		int labelCol = 1;

		// federate description
		builder.addLabel(MmResources.getMessage("MmFederateInfoDialog.Label0.Text"), cc.xyw(labelCol, builder.getRow(),
				3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.add(new JScrollPane(federateInfo), cc.xyw(labelCol, builder.getRow(), 3, "fill, fill"));
		builder.nextRow();

		// buttons
		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		JPanel btnPanel = ButtonBarFactory.buildRightAlignedBar(dialogButtons);
		builder.add(btnPanel, cc.xyw(builder.getColumn(), builder.getRow(), 3));
	}

	/**
	 * Closes the dialog.
	 */
	private void exitDialog() {
		if (model.hasChanges()) {
			model.undo();
		}

		dialog.dispose();
	}

	private void save() throws IOException {
		model.setInfoText(federateInfo.getText());

		if (model.hasChanges()) {
			model.doSave();
		}
	}
}
