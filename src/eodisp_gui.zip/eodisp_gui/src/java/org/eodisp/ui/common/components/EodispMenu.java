/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com
 *  mail: info@pnp-software.com
 */
package org.eodisp.ui.common.components;

import javax.swing.JMenu;

/**
 * This class is just a wrapper for a <code>JMenu</code> to use in an EODiSP
 * application. If there is some specific behaviour for a <code>JMenu</code>,
 * it should go here.
 * <p>
 * A <code>EodispMenu</code> is a single entry in a <code>EodispMenuBar</code>.
 * It has usually no action associated, and is just a container for
 * <code>EodispMenuItem</code>s.
 * <p>
 * See {@link javax.swing.JMenu} for more informations.
 * 
 * @author eglimi
 * @version $Id:EodispMenu.java 2134 2006-05-16 08:43:27Z eglimi $
 * 
 */
public class EodispMenu extends JMenu {

	/**
	 * Constructor. Sets the name of the menu item to the specified string.
	 * 
	 * @param s
	 *            The display name of the menu item.
	 */
	public EodispMenu(String s) {
		super(s);
	}
}
