/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.rm.views;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.*;

import org.apache.log4j.Logger;
import org.eodisp.core.common.ReposServiceProxy;
import org.eodisp.ui.common.resources.CommonMessages;
import org.eodisp.ui.common.resources.MessageBoxHelper;
import org.eodisp.ui.rm.application.RmAppModuleGui;
import org.eodisp.ui.rm.application.RmEmfHelper;
import org.eodisp.ui.rm.resources.RmResources;
import org.eodisp.util.AppRegistry;

import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.factories.ButtonBarFactory;
import com.jgoodies.forms.factories.FormFactory;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

/**
 * @author eglimi
 * @version $Id:$
 */
public class RmRegisterSomDialog {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(RmRegisterSomDialog.class);
	
	private static final String TITLE = RmResources.getMessage("RmRegisterSomDialog.Title");

	private final JDialog dialog;

	private final JFrame owner;

	private RmRegisterSomDialog(JFrame owner) {
		this.owner = owner;

		dialog = new JDialog(owner, TITLE, true);

		initializeComponents();
		buildPanels();
		dialog.setContentPane(scrollPane);
	}

	/**
	 * Displays this dialog.
	 */
	public static void showRmRegisterSomDialog(JFrame owner) {
		RmRegisterSomDialog registerSomDialog = new RmRegisterSomDialog(owner);
		registerSomDialog.internalShowDialog();
	}

	public void internalShowDialog() {
		dialog.pack();
		dialog.setLocationRelativeTo(owner);
		dialog.setVisible(true);
		dialog.dispose();
	}

	/**
	 * This is the main panel that will hold all other components. It will be
	 * embedded in a scroll pane.
	 */
	private JPanel mainPanel;

	/**
	 * This is the main scroll pane that will be shown as the view's component.
	 */
	private final JScrollPane scrollPane = new JScrollPane();

	private final JTextField somPath = new JTextField();

	private final JTextField somName = new JTextField();

	private final JTextField somVersion = new JTextField();

	private final JTextArea somDescription = new JTextArea();

	private final JButton somBtn = new JButton("...");

	/**
	 * Buttons for the dialog (save, cancel, etc).
	 */
	private final JButton[] dialogButtons = new JButton[2];

	private File somFile;

	private void initializeComponents() {
		dialogButtons[0] = new JButton(CommonMessages.getMessage("Button.SaveExit"));
		dialogButtons[0].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (registerSom()) {
					exitDialog();
				}
			}
		});
		dialogButtons[1] = new JButton(CommonMessages.getMessage("Button.Cancel"));
		dialogButtons[1].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exitDialog();
			}
		});

		somBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showSomFileChooser();
			}
		});

		somName.setText(RmResources.getMessage("Som.New.Template.SomName"));
		somVersion.setText(RmResources.getMessage("Som.New.Template.SomVersion"));
		somDescription.setText(RmResources.getMessage("Som.New.Template.SomDescription"));
	}

	@SuppressWarnings("boxing")
	private void buildPanels() {
		// create the layout
		CellConstraints cc = new CellConstraints();
		FormLayout layout = new FormLayout("right:50dlu, 4dlu, 75dlu:grow, 4dlu, right:20dlu",
				"p, 1dlu, p, 3dlu, p, 1dlu, p, 3dlu, p, 1dlu, p, 3dlu, p, 1dlu, 100dlu, p:grow, 20dlu, p");
		PanelBuilder builder = new PanelBuilder(layout);
		builder.setDefaultDialogBorder();
		buildPanel(builder, cc, layout);

		logger.debug(String.format("added %d rows to the form.", builder.getRowCount()));

		// get and set the panel
		mainPanel = builder.getPanel();
		scrollPane.setViewportView(mainPanel);
	}

	private void buildPanel(PanelBuilder builder, CellConstraints cc, FormLayout layout) {
		int labelCol = 1;
		// som path
		builder.addLabel(RmResources.getMessage("RmSomsView.Label1.Text"), cc.xyw(labelCol, builder.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.add(somPath, cc.xyw(labelCol, builder.getRow(), 3));
		builder.add(somBtn, cc.xy(labelCol + 4, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		// som name
		builder.addLabel(RmResources.getMessage("RmSomsView.Label2.Text"), cc.xyw(labelCol, builder.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.add(somName, cc.xyw(labelCol, builder.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		// som version
		builder.addLabel(RmResources.getMessage("RmSomsView.Label3.Text"), cc.xyw(labelCol, builder.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.add(somVersion, cc.xyw(labelCol, builder.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		// som description
		builder.addLabel(RmResources.getMessage("RmSomsView.Label4.Text"), cc.xyw(labelCol, builder.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.add(somDescription, cc.xyw(labelCol, builder.getRow(), 3, "fill, fill"));
		builder.nextRow();

		// buttons
		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		JPanel btnPanel = ButtonBarFactory.buildRightAlignedBar(dialogButtons);
		builder.add(btnPanel, cc.xyw(builder.getColumn(), builder.getRow(), 5));
	}

	/**
	 * Register the SOM in the repository.
	 * 
	 * @return True, if the registration was successful, false otherwise.
	 */
	private boolean registerSom() {
		
		if(!somPath.getText().equals("")) {
			somFile = new File(somPath.getText());
		}

		ReposServiceProxy service = ((RmAppModuleGui) AppRegistry.getRootApp().getAppModule(RmAppModuleGui.ID))
				.getReposServiceProxy();
		try {
			String filePath = service
					.addSom(somName.getText(), somVersion.getText(), somDescription.getText(), somFile);

			RmEmfHelper.createSom(service.getRootObject(), somName.getText(), somVersion.getText(), somDescription
					.getText(), somFile.getName(), filePath);

		} catch (Exception e) {
			MessageBoxHelper.ErrorBoxL(dialog, "Error.Transfer.Msg", "Error.Transfer.Cap", e.getMessage());
			return false;
		}

		return true;
	}

	/**
	 * Closes the dialog.
	 */
	private void exitDialog() {
		dialog.dispose();
	}

	private void showSomFileChooser() {
		JFileChooser chooser = new JFileChooser();
		int returnVal = chooser.showOpenDialog(dialog);
		if (returnVal == JFileChooser.APPROVE_OPTION) {
			somPath.setText(chooser.getSelectedFile().getPath());
		} else {
			// no file has been chosen.
			return;
		}
	}
}
