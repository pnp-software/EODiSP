/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.common.actions;

import java.util.EventListener;


/**
 * This is a event listener interface for an EODiSP application. It can be used
 * to indication that an some registered actions have changed. Actions are used
 * to build the menu bar, the tool bar and the context menu. Whenever this event
 * occurs, it means that part of these menus must be updated. This can happen if
 * some component has registered a new item for the menu bar, removed one, etc.
 * <p>
 * The component which implements this interface will be informed about such a
 * change. There is no additional information about what has changed. It is the
 * responsibility of the component to ask for changes if it is appropriate.
 * 
 * @author eglimi
 * @version $Id:EodispActionListener.java 2049 2006-05-09 12:23:10Z eglimi $
 * 
 */
public interface EodispActionListener extends EventListener {

	/**
	 * Indicates that one or more actions registered in this application have
	 * changed.
	 * 
	 */
	public void actionChanged(ActionChangedEvent event);

}
