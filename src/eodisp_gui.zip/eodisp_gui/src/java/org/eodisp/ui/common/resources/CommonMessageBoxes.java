package org.eodisp.ui.common.resources;

import java.awt.Component;

/**
 * This class is capable of creating common message boxes that are used
 * throughout the application. The methods provided here a just convenient
 * methods for common message boxes.
 * 
 * @author eglimi
 * @version $Id:$
 */
public final class CommonMessageBoxes {

	/**
	 * This is currently only a delegation method for
	 * {@link #showGeneralMessage(Component, String)}, but could display a more
	 * fancy error dialog for an exception.
	 * 
	 * @param parent
	 *            the parent component
	 * @param info
	 *            additional information for the error
	 * @param throwable
	 *            the error.
	 */
	public static void showException(Component parent, String info, Throwable throwable) {
		showGeneralMessage(parent, info);
	}

	/**
	 * 
	 * @see #showException(Component, String, Throwable)
	 */
	public static void showException(Component parent, Throwable throwable) {
		showException(parent, null, throwable);
	}

	/**
	 * Shows a general error message, saying that an error has occurred. You
	 * must specify an additional message for this error.
	 * 
	 * @param parent
	 *            The parent component.
	 * @throws IllegalArgumentException
	 *             thrown if no additional message has been provided.
	 */
	public static void showGeneralMessage(Component parent, String errorMessage) throws IllegalArgumentException {

		if (errorMessage == null || errorMessage.equals("")) {
			throw new IllegalArgumentException("No error message has been provided.");
		}

		MessageBoxHelper.ErrorBoxL(parent, "Error.General.Msg", "Error.General.Cap", errorMessage);
	}

	/**
	 * A message box with a 'yes', 'no', and 'cancel' button and a text asking
	 * whether to save changes before leaving.
	 * 
	 * @param parent
	 *            The parent component.
	 * @return The value indicating which option the user has selected.
	 */
	public static int askForSaveChanges(Component parent) {
		return MessageBoxHelper.YesNoCancelQuestionBoxL(parent, "ExitAndSaveChanges.Msg", "ExitAndSaveChanges.Cap");
	}

	/**
	 * Shows An error saying that the operation requires to save the changes
	 * first.
	 * 
	 * @param parent
	 *            The parent component.
	 */
	public static int showInstructSave(Component parent) {
		return MessageBoxHelper.YesNoCancelQuestionBoxL(parent, "InstructSave.Msg", "InstructSave.Cap");
	}

	/**
	 * Shows An error saying that the save operation has failed. There is no
	 * choice for the user.
	 * 
	 * @param parent
	 *            The parent component.
	 */
	public static void showSaveError(Component parent, String errorMessage) {
		MessageBoxHelper.ErrorBoxL(parent, "SaveError.Msg", "SaveError.Cap", errorMessage);
	}

	/**
	 * Shows An error saying that the load operation of a resource (typically a
	 * file resource on the disk) has failed. There is no choice for the user.
	 * 
	 * @param parent
	 *            The parent component.
	 */
	public static void showLoadError(Component parent, String errorMessage) {
		MessageBoxHelper.ErrorBoxL(parent, "LoadError.Msg", "LoadError.Cap", errorMessage);
	}

	/**
	 * Shows a message box saying that the application is not connected to the
	 * repository.
	 * 
	 * @param parent
	 *            The parent component.
	 */
	public static void showReposNotConnectedError(Component parent) {
		MessageBoxHelper.ErrorBoxL(parent, "ReposNotConnError.Msg", "ReposNotConnError.Cap");
	}

	/**
	 * Shows a message box saying that the application is not registered in the
	 * repository.
	 * 
	 * @param parent
	 *            The parent component.
	 */
	public static void showReposNotRegisteredError(Component parent) {
		MessageBoxHelper.ErrorBoxL(parent, "ReposNotRegisteredError.Msg", "ReposNotRegisteredError.Cap");
	}

	/**
	 * Shows a message box asking the user to confirm before a deletion
	 * operation.
	 * 
	 * @param parent
	 *            The parent component.
	 * @return The value indicating which option the user has selected.
	 */
	public static int askForDelete(Component parent) {
		return MessageBoxHelper.YesNoQuestionBoxL(parent, "AskForDelete.Msg", "AskForDelete.Cap");
	}
}
