/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com
 *  mail: info@pnp-software.com
 */
package org.eodisp.ui.mm.controllers;

import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.net.URI;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import org.apache.log4j.Logger;
import org.eodisp.core.common.ReposServiceProxy;
import org.eodisp.core.mm.application.MmAppModuleCore;
import org.eodisp.core.mm.config.MmConfiguration;
import org.eodisp.core.mm.service.FederateListener;
import org.eodisp.core.mm.service.MmFederateProcessManager;
import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.remote.config.RemoteConfiguration.TransportType;
import org.eodisp.ui.common.base.*;
import org.eodisp.ui.common.resources.CommonMessageBoxes;
import org.eodisp.ui.common.resources.MessageBoxHelper;
import org.eodisp.ui.mm.application.MmAppUtils;
import org.eodisp.ui.mm.views.MmMainFrame;
import org.eodisp.ui.mm.views.MmPrefs;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.configuration.Configuration;

/**
 * This is the application controller for the EODiSP model manager application.
 * It is the main controller, which has control over the creation of other
 * controllers. It is therfore the controller of the application which must
 * exist in order to run the application.
 * <p>
 * Specific tasks which this controller is responsible for are:
 * <ul>
 * <li>Creation of other controllers used throughout this application.</li>
 * <li>Creation of the main frame used in this application. </li>
 * </ul>
 * <p>
 * The <code>MmAppController</code> extends the more generic
 * <code>EodispApplicationController</code> and is only useful to handle the
 * specific part for the model manager application. All generic tasks are
 * handled and documented in the <code>EodispApplicationController</code>
 * class.
 * 
 * @author eglimi
 */
public class MmAppController extends EodispApplicationController {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(MmAppController.class);

	private final FederateObserver federateObserver = new FederateObserver();

	/**
	 * Default constructor.
	 */
	public MmAppController() {
		registerActionHandler();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void initialize() {
		super.initialize();

		// for the main title
		checkState();

		MmFederateProcessManager processManager = ((MmAppModuleCore) AppRegistry.getRootApp().getAppModule(
				MmAppModuleCore.ID)).getFederateProcessManager();
		processManager.addFederateListener(federateObserver);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eodisp.ui.common.base.EodispApplicationController#registerActionHandler()
	 */
	@Override
	public void registerActionHandler() {
		MmMainFrame.onSaveAll.registerTargetHandler(new EodispDelegate(this, "onSaveAll"));
		MmMainFrame.onExitApp.registerTargetHandler(new EodispDelegate(this, "onExitApp"));

		MmMainFrame.onAbout.registerTargetHandler(new EodispDelegate(this, "onAbout"));
		MmMainFrame.onHelp.registerTargetHandler(new EodispDelegate(this, "onHelp"));

		MmMainFrame.onConnectRepos.registerTargetHandler(new EodispDelegate(this, "onConnectRepos"));
		MmMainFrame.onReloadRepos.registerTargetHandler(new EodispDelegate(this, "onReloadRepos"));
		MmMainFrame.onRegisterApp.registerTargetHandler(new EodispDelegate(this, "onRegisterApp"));
		MmMainFrame.onUnregisterApp.registerTargetHandler(new EodispDelegate(this, "onUnregisterApp"));
		MmMainFrame.onUpdateRegistration.registerTargetHandler(new EodispDelegate(this, "onUpdateRegistration"));
		MmMainFrame.onImportFederate.registerTargetHandler(new EodispDelegate(this, "onImportFederate"));
		MmMainFrame.onPrefs.registerTargetHandler(new EodispDelegate(this, "onPrefs"));
	}

	public void onSaveAll(ActionEvent e) {
		logger.debug("performing action: onSaveAll");

		try {
			super.saveAllChanges();
		} catch (IOException ex) {
			logger.error("Could not save all data", ex);
			CommonMessageBoxes.showSaveError(null, ex.getMessage());
		}

		logger.debug("saveAll completed");
	}

	public void onExitApp(ActionEvent e) {
		logger.debug("performing action: onExitApp");
		super.handleExit();
		logger.debug("onExitApp completed");
	}

	public void onAbout(ActionEvent e) {
		logger.debug("performing action: onAbout");
		logger.debug("onAbout completed");
		// TODO
	}

	public void onHelp(ActionEvent e) {
		logger.debug("performing action: onExportProjectPart");
		logger.debug("onExportProjectPart completed");
		// TODO
	}

	public void onConnectRepos(ActionEvent e) {
		logger.debug("performing action: onConnectRepos");

		// first connect
		MmAppModuleCore appModule = (MmAppModuleCore) AppRegistry.getRootApp().getAppModule(MmAppModuleCore.ID);
		if (!MmAppUtils.isConnected()) {
			try {
				appModule.getMmCoreServiceProxy().connectToRepos();
			} catch (Exception ex) {
				logger.debug("Could not connect to repository.", ex);
				MessageBoxHelper.ErrorBoxL(getMainFrame(), "ReposConnectError.Msg", "ReposConnectError.Cap", ex
						.getMessage());
				return;
			}
		}

		try {
			appModule.getReposServiceProxy().load();
		} catch (IOException ex) {
			CommonMessageBoxes.showLoadError(getMainFrame(), ex.getMessage());
		}

		checkState();
		super.updateAllModels();

		logger.debug("onConnectRepos completed");
	}

	public void onReloadRepos(ActionEvent e) {
		logger.debug("performing action: onReloadRepos");

		if (!MmAppUtils.isConnected()) {
			logger
					.info("The data from the repository could not be reloaded. The repository is not connected. Please connect first.");
			CommonMessageBoxes.showReposNotConnectedError(getMainFrame());
			return;
		}

		if (super.hasAppChanges()) {
			int choice = MessageBoxHelper.YesNoCancelQuestionBoxL(getMainFrame(), "AskForSaveViews.Msg",
					"AskForSaveViews.Cap");
			if (choice == JOptionPane.YES_OPTION) {
				try {
					saveAllChanges();
				} catch (IOException ex) {
					CommonMessageBoxes.showSaveError(null, ex.getMessage());
					return;
				}
			}
		}

		MmAppModuleCore appModule = (MmAppModuleCore) AppRegistry.getRootApp().getAppModule(MmAppModuleCore.ID);

		appModule.getReposServiceProxy().setScheduledForReload(true);

		try {
			appModule.getReposServiceProxy().load();
		} catch (IOException ex) {
			CommonMessageBoxes.showLoadError(getMainFrame(), ex.getMessage());
		}

		checkState();
		super.updateAllModels();

		logger.debug("onReloadRepos completed");
	}

	public void onRegisterApp(ActionEvent e) {
		logger.debug("performing action: onRegisterApp");

		// test connection
		if (!MmAppUtils.isConnected()) {
			logger
					.debug("The model manager application is not connected to the repository and can therefore not be registered.");
			CommonMessageBoxes.showReposNotConnectedError(null);
			return;
		}

		if (super.hasAppChanges()) {
			int choice = CommonMessageBoxes.showInstructSave(getMainFrame());
			if (choice == JOptionPane.YES_OPTION) {
				try {
					saveAllChanges();
				} catch (IOException ex) {
					CommonMessageBoxes.showSaveError(getMainFrame(), ex.getMessage());
					return;
				}
			} else {
				return;
			}
		}

		Configuration mmConfig = AppRegistry.getRootApp().getConfiguration(MmConfiguration.ID);

		RemoteAppModule remoteAppModule = (RemoteAppModule) AppRegistry.getRootApp().getAppModule(RemoteAppModule.ID);
		URI localUri = (remoteAppModule).getLocalUri(remoteAppModule.getFavoriteTransport());

		if (localUri == null) {
			final String message = "The local URI for this application could not be found.\nPlease ensure that the application has been started using the JXTA network protocol.";
			CommonMessageBoxes.showGeneralMessage(getMainFrame(), message);
		}

		ReposServiceProxy service = ((MmAppModuleCore) AppRegistry.getRootApp().getAppModule(MmAppModuleCore.ID))
				.getReposServiceProxy();
		if (service != null) {
			try {
				MmAppUtils.registerApp(service.getRootObject(), mmConfig, localUri);
			} catch (Exception ex) {
				MessageBoxHelper.ErrorBoxL(getMainFrame(), "Error.General.Msg", "Error.General.Cap", ex.getMessage());
			}

			checkState();
			super.updateAllViewStates();
		}

		logger.debug("onRegisterApp completed");
	}

	public void onUpdateRegistration(ActionEvent e) {
		logger.debug("performing action: onUpdateRegistration");
		// test connection
		if (!MmAppUtils.isConnected()) {
			logger
					.debug("The model manager application is not connected to the repository and can therefore not be registered.");
			CommonMessageBoxes.showReposNotConnectedError(null);
			return;
		}

		if (super.hasAppChanges()) {
			int choice = CommonMessageBoxes.showInstructSave(getMainFrame());
			if (choice == JOptionPane.YES_OPTION) {
				try {
					saveAllChanges();
				} catch (IOException ex) {
					CommonMessageBoxes.showSaveError(getMainFrame(), ex.getMessage());
					return;
				}
			} else {
				return;
			}
		}

		Configuration mmConfig = AppRegistry.getRootApp().getConfiguration(MmConfiguration.ID);

		final RemoteAppModule remoteAppModule = (RemoteAppModule) AppRegistry.getRootApp().getAppModule(
				RemoteAppModule.ID);
		URI localUri = remoteAppModule.getLocalUri(remoteAppModule.getFavoriteTransport());

		if (localUri == null) {
			final String message = "The local URI for this application could not be found.\nPlease ensure that the application has been started using the JXTA network protocol.";
			CommonMessageBoxes.showGeneralMessage(getMainFrame(), message);
		}

		ReposServiceProxy service = ((MmAppModuleCore) AppRegistry.getRootApp().getAppModule(MmAppModuleCore.ID))
				.getReposServiceProxy();
		if (service != null) {
			try {
				MmAppUtils.updateRegistration(service.getRootObject(), mmConfig, localUri);
			} catch (Exception ex) {
				MessageBoxHelper.ErrorBoxL(null, "Error.General.Msg", "Error.General.Cap", ex.getMessage());
			}
		}

		logger.debug("onUpdateRegistration completed");
	}

	public void onUnregisterApp(ActionEvent e) {
		logger.debug("performing action: onUnregisterApp");

		if (!MmAppUtils.isConnected()) {
			logger
					.debug("The model manager application is not connected to the repository and can therefore not be registered.");
			CommonMessageBoxes.showReposNotConnectedError(getMainFrame());
			return;
		}

		if (super.hasAppChanges()) {
			int choice = CommonMessageBoxes.showInstructSave(getMainFrame());
			if (choice == JOptionPane.YES_OPTION) {
				try {
					saveAllChanges();
				} catch (IOException ex) {
					CommonMessageBoxes.showSaveError(getMainFrame(), ex.getMessage());
					return;
				}
			} else {
				return;
			}
		}

		MmConfiguration mmConfiguration = (MmConfiguration) AppRegistry.getRootApp().getConfiguration(
				MmConfiguration.ID);
		String id = mmConfiguration.getEntry(MmConfiguration.APP_ID).getValue();

		ReposServiceProxy service = ((MmAppModuleCore) AppRegistry.getRootApp().getAppModule(MmAppModuleCore.ID))
				.getReposServiceProxy();
		if (service != null) {
			int choice = MessageBoxHelper.YesNoQuestionBoxL(null, "UnregisterApp.Msg", "UnregisterApp.Cap");
			if (choice == JOptionPane.YES_OPTION) {
				try {
					MmAppUtils.unregisterApp(service.getRootObject(), id);
				} catch (Exception ex) {
					MessageBoxHelper.ErrorBoxL(getMainFrame(), "Error.General.Msg", "Error.General.Cap", ex
							.getMessage());
				}
			}
		}

		checkState();

		logger.debug("onRegisterApp completed");
	}

	public void onImportFederate(ActionEvent e) {
		logger.debug("performing action: onImportFederate");

		JFrame owner = ((UIApp) AppRegistry.getRootApp()).getMainFrame();

		// TODO
		// MmImportDialog.showInitDataDialog(owner);

		logger.debug("onImportFederate completed");
	}

	public void onPrefs(ActionEvent e) {
		logger.debug("performing action: onPrefs");
		final MmPrefs prefs = new MmPrefs();
		prefs.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				if (prefs.canExit()) {
					prefs.dispose();
				}
			}
		});
		prefs.pack();
		prefs.setVisible(true);
		logger.debug("onPrefs completed");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void createControllers() {
		MmFederatesController federatesController = new MmFederatesController();
		federatesController.initialize();

		attachController(federatesController);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected EodispMainFrame createMainFrame() {
		return new MmMainFrame();
	}

	/**
	 * <p>
	 * Sets the main title of the main frame according to the current state.
	 * There are the following states
	 * </p>
	 * 
	 * <pre>
	 * connected | registered | text on main frame
	 * -----------------------------------------------------
	 *     no    |     no     | not connected/not registered
	 *     yes   |     no     | connected/not registered
	 *     yes   |     yes    | connected/registered
	 * </pre>
	 * 
	 * <p>
	 * In addition, it updates the state of the actions.
	 */
	private void checkState() {
		if (MmAppUtils.isConnected()) {
			if (MmAppUtils.isAppRegistered()) {
				getMainFrame().updateTitle("connected", "registered");
			} else {
				getMainFrame().updateTitle("connected", "not registered");
			}
		} else {
			getMainFrame().updateTitle("not connected", "not registered");
		}

		super.updateAllActions();
	}

	private class FederateObserver implements FederateListener {

		public void federateChanged() {
			SwingUtilities.invokeLater(new Runnable() {

				public void run() {
					updateAllViewStates();
				}

			});
		}

	}
}
