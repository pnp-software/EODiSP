/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.rm.views;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.*;

import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eodisp.ui.common.components.EodispListCellRenderer;
import org.eodisp.ui.common.resources.CommonMessageBoxes;
import org.eodisp.ui.common.resources.CommonMessages;
import org.eodisp.ui.rm.models.SomCategoriesModel;
import org.eodisp.ui.rm.resources.RmResources;

import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.factories.ButtonBarFactory;
import com.jgoodies.forms.factories.FormFactory;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

/**
 * @author eglimi
 * @version $Id:$
 */
public class RmSomCategories {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(RmSomCategories.class);
	
	private static final String TITLE = RmResources.getMessage("RmSomCategories.Title");

	private final SomCategoriesModel model;

	private final JFrame owner;

	private final JDialog dialog;

	/**
	 * This is the main panel that will hold all other components. It will be
	 * embedded in a scroll pane.
	 */
	private JPanel mainPanel;

	/**
	 * Shows a list of categories
	 */
	private final JList catList = new JList();

	/**
	 * Shows a list of categories the SOM is registered in.
	 */
	private final JList regCatList = new JList();

	/**
	 * Buttons used to move the categories
	 */
	private final JButton[] catButtons = new JButton[2];

	/**
	 * Buttons for the dialog (save, cancel, etc).
	 */
	private final JButton[] dialogButtons = new JButton[3];

	private RmSomCategories(JFrame owner, EDataObject curObj) {
		this.owner = owner;

		model = new SomCategoriesModel(curObj);

		dialog = new JDialog(owner, TITLE, true);

		initializeComponents();
		buildPanels();
		dialog.setContentPane(mainPanel);
	}

	/**
	 * Displays this dialog.
	 */
	public static void showSomCategoriesDialog(JFrame owner, EDataObject curObj) {
		RmSomCategories somCategories = new RmSomCategories(owner, curObj);
		somCategories.internalShowSomCategoriesDialog();
	}

	private void internalShowSomCategoriesDialog() {
		dialog.pack();
		dialog.setLocationRelativeTo(owner);
		dialog.setVisible(true);
		dialog.dispose();
	}

	private void initializeComponents() {
		
		// Preferred size
		dialog.setPreferredSize(new Dimension(800, 400));
		
		// The list with the available categories
		catList.setModel(getSomCategoriesModel().getCatListModel());
		catList.setCellRenderer(new EodispListCellRenderer());

		// The list with the registered categories
		regCatList.setModel(getSomCategoriesModel().getRegCatListModel());
		regCatList.setCellRenderer(new EodispListCellRenderer());

		catButtons[0] = new JButton(RmResources.getMessage("SomCategories.Button0.Text"));
		catButtons[0].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				registerCat();
			}
		});

		catButtons[1] = new JButton(RmResources.getMessage("SomCategories.Button1.Text"));
		catButtons[1].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				unregisterCat();
			}
		});

		dialogButtons[0] = new JButton(CommonMessages.getMessage("Button.Apply"));
		dialogButtons[0].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				saveDialog();
			}
		});
		dialogButtons[1] = new JButton(CommonMessages.getMessage("Button.SaveExit"));
		dialogButtons[1].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				saveDialog();
				exitDialog();
			}
		});
		dialogButtons[2] = new JButton(CommonMessages.getMessage("Button.Cancel"));
		dialogButtons[2].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				undoEdit();
				exitDialog();
			}
		});
	}

	@SuppressWarnings("boxing")
	private void buildPanels() {
		// create the layout
		CellConstraints cc = new CellConstraints();
		FormLayout layout = new FormLayout("75dlu:grow, 4dlu, 50dlu, 4dlu, 75dlu:grow",
				"p, 3dlu, p, 3dlu, p:grow, 10dlu, 20dlu, 10dlu, p:grow, 20dlu, p");
		PanelBuilder builder = new PanelBuilder(layout);
		builder.setDefaultDialogBorder();
		buildListPanel(builder, cc, layout);

		logger.debug(String.format("added %d rows to the form.", builder.getRowCount()));

		// get and set the panel
		mainPanel = builder.getPanel();
	}

	private void buildListPanel(PanelBuilder builder, CellConstraints cc, FormLayout layout) {
		int leftListCol = 1;
		int rightListCol = 5;
		int btnCol = 3;
		builder.setRow(1);

		// Categories
		builder.addSeparator(RmResources.getMessage("SomCategories.Prop.Header.Categories"), cc.xyw(leftListCol,
				builder.getRow(), 5));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.addSeparator(RmResources.getMessage("SomCategories.Label1.Text"), cc.xy(leftListCol, builder.getRow()));

		builder
				.addSeparator(RmResources.getMessage("SomCategories.Label2.Text"), cc
						.xy(rightListCol, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.add(new JScrollPane(catList), cc.xywh(leftListCol, builder.getRow(), 1, 5, "fill, fill"));

		builder.add(catButtons[0], cc.xy(btnCol, builder.getRow() + 2));
		builder.add(catButtons[1], cc.xy(btnCol, builder.getRow() + 4));

		builder.add(new JScrollPane(regCatList), cc.xywh(rightListCol, builder.getRow(), 1, 5, "fill, fill"));
		builder.nextRow(5);

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		JPanel btnPanel = ButtonBarFactory.buildRightAlignedBar(dialogButtons);
		builder.add(btnPanel, cc.xyw(builder.getColumn(), builder.getRow(), 5));
		builder.nextLine();
	}

	private SomCategoriesModel getSomCategoriesModel() {
		return model;
	}

	private void registerCat() {
		if (catList.getSelectedIndex() != -1) {
			getSomCategoriesModel().registerCat(catList.getSelectedValues());
		}
	}

	private void unregisterCat() {
		if (regCatList.getSelectedIndex() != -1) {
			getSomCategoriesModel().unregisterCat(regCatList.getSelectedValues());
		}
	}

	private void saveDialog() {
		try {
			getSomCategoriesModel().doSave();
		} catch (IOException ex) {
			CommonMessageBoxes.showSaveError(dialog, ex.getMessage());
		}
	}

	/**
	 * Undo modification since last save.
	 * 
	 */
	private void undoEdit() {
		getSomCategoriesModel().undo();
	}

	/**
	 * Closes the dialog.
	 */
	private void exitDialog() {
		dialog.dispose();
	}
}
