/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.rm.application;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eodisp.core.gen.repository.impl.RepositoryPackageImpl;

import commonj.sdo.DataObject;

/**
 * @author eglimi
 * @version $Id:$
 */
public class RmEmfHelper {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(RmEmfHelper.class);

	public static DataObject createCategory(DataObject reposRoot, String catName, String catDescription,
			boolean isClosed) {

		final DataObject category;

		if (reposRoot != null) {
			String catId = UUID.randomUUID().toString();

			category = reposRoot.createDataObject(RepositoryPackageImpl.REPOSITORY__CATEGORIES);
			category.setString(RepositoryPackageImpl.CATEGORY__NAME, catName);
			category.setString(RepositoryPackageImpl.CATEGORY__DESCRIPTION, catDescription);
			category.setString(RepositoryPackageImpl.CATEGORY__ID, catId);
			category.setBoolean(RepositoryPackageImpl.CATEGORY__CLOSED, isClosed);
		} else {
			category = null;
		}

		return category;
	}

	public static DataObject createSom(DataObject reposRoot, String somName, String somVersion, String somDescription,
			String fileName, String filePath) {

		final DataObject som;

		if (reposRoot != null) {
			som = reposRoot.createDataObject(RepositoryPackageImpl.REPOSITORY__SOMS);
			som.setString(RepositoryPackageImpl.SOM__NAME, somName);
			som.setString(RepositoryPackageImpl.SOM__VERSION, somVersion);
			som.setString(RepositoryPackageImpl.SOM__DESCRIPTION, somDescription);
			som.setString(RepositoryPackageImpl.SOM__FILE_NAME, fileName);
			som.setString(RepositoryPackageImpl.SOM__LOCAL_PATH, filePath);
		} else {
			som = null;
		}

		return som;
	}

	public static List<DataObject> findAllCategories(DataObject reposRoot) {
		if (reposRoot != null) {
			return reposRoot.getList(RepositoryPackageImpl.REPOSITORY__CATEGORIES);
		}

		return new ArrayList(0);
	}

	public static List<DataObject> findAllSimulationManagers(DataObject reposRoot) {
		if (reposRoot != null) {
			return reposRoot.getList(RepositoryPackageImpl.REPOSITORY__SIM_MANAGERS);
		}

		return new ArrayList(0);
	}

	public static List<DataObject> findAllModelManagers(DataObject reposRoot) {
		if (reposRoot != null) {
			return reposRoot.getList(RepositoryPackageImpl.REPOSITORY__MODEL_MANAGERS);
		}

		return new ArrayList(0);
	}

	public static List<DataObject> findAllSoms(DataObject reposRoot) {
		if (reposRoot != null) {
			return reposRoot.getList(RepositoryPackageImpl.REPOSITORY__SOMS);
		}

		return new ArrayList(0);
	}

	public static List<EDataObject> findAllFederatesForSom(DataObject som) {
		if (som != null) {
			return som.getList(RepositoryPackageImpl.SOM__FEDERATES);
		}

		return null;
	}

	public static List<DataObject> findSomsForCategory(DataObject category) {
		if (category == null) {
			logger.debug("The category som object null. Terminate search.");
			return null;
		}

		return category.getList(RepositoryPackageImpl.CATEGORY__SOMS);
	}
}
