/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com
 *  mail: info@pnp-software.com
 */
package org.eodisp.ui.common.components;

import javax.swing.JTree;
import javax.swing.tree.TreeSelectionModel;

/**
 * An <code>EodispTree</code> can be used to display data in form of a tree.
 * <p>
 * This class is just a wrapper for a <code>JTree</code> to use in an EODiSP
 * application.
 * <p>
 * See {@link javax.swing.JTree} for more informations.
 * 
 * @author eglimi
 * @version $Id:EodispTree.java 2134 2006-05-16 08:43:27Z eglimi $
 */
public class EodispTree extends JTree {

	/**
	 * default serial version ID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Default constructor.
	 */
	public EodispTree() {
		super(new Object[] {});
		setBehavior();
	}

	/**
	 * Set the basic behavior of a tree used to use in an EODiSP application.
	 */
	private void setBehavior() {
		setEditable(true);
		getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
		setRootVisible(true);
		setShowsRootHandles(true);
		setDragEnabled(false);
	}

	@Override
	public void updateUI() {
		super.updateUI();
	}
}
