/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com
 *  mail: info@pnp-software.com
 */
package org.eodisp.ui.common.base;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.JMenu;
import javax.swing.JOptionPane;

import net.infonode.docking.RootWindow;
import net.infonode.docking.theme.ShapedGradientDockingTheme;
import net.infonode.docking.util.DeveloperUtil;
import net.infonode.docking.util.DockingUtil;
import net.infonode.docking.util.ViewMap;

import org.apache.log4j.Logger;
import org.eodisp.ui.common.actions.ActionSourceProvider;
import org.eodisp.ui.common.actions.EodispMenuManager;
import org.eodisp.ui.common.actions.MenuSelectedListener;
import org.eodisp.ui.common.resources.CommonMessageBoxes;
import org.eodisp.ui.common.resources.MessageBoxHelper;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.RootApp;

/**
 * The EodispApplicationController is the main controller for this application.
 * It handles the creation of of other controllers for the application as well
 * as the creation and management of frames.
 * <p>
 * This class should be sub-classed by a specific application controller for
 * each application to provide an implementation of the abstract methods. The
 * sub-class should also handle the actions that belong to the main application.
 * That is, all actions that should always be available.
 * <p>
 * In the MVC (Model-View-Controller) pattern, the controller is responsible for
 * handling events. This is done by using the delegation mechanism which is
 * provided by {@link org.eodisp.ui.common.base.EodispDelegate} class. See the
 * documentation of this calls for more information.
 * 
 * @author eglimi
 * @version $Id: EodispApplicationController.java 1427 2006-01-04 07:57:54Z
 *          eglimi $
 */
public abstract class EodispApplicationController {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(EodispApplicationController.class);

	/**
	 * Holds the main frame of this application. The main frame embeds the menu
	 * bar, the tool bar, and the main panel.
	 */
	private EodispMainFrame mainFrame;

	/**
	 * Holds the root windows in which all views are embedded. This is the
	 * container which is added to the main frame.
	 */
	protected RootWindow rootWindow;

	/**
	 * Holds a list of all static views in the application.
	 */
	protected ViewMap viewMap;

	/**
	 * A list of controller that are created for this application. Controllers
	 * can be added and removed at runtime. Removing a controller causes all
	 * frames and views created by that controller to be disposed.
	 */
	private Vector<EodispController> controllerList = new Vector<EodispController>();

	/**
	 * Default constructor.
	 */
	protected EodispApplicationController() {
		registerActionHandler();
	}

	/**
	 * Register this class as a target handler for certain actions used within
	 * the EODiSP simulation manager application.
	 * <p>
	 * For the registration, the EODiSP delegation mechanism is used (see
	 * {@link EodispDelegate}. Such an instance can be registered in the action
	 * itself, causing the method to be called whenever the action is performed.
	 */
	protected abstract void registerActionHandler();

	/**
	 * Creates the main frame of the application. This method must be
	 * implemented by a concrete application controller for each application.
	 * 
	 * @return The main frame of this application.
	 */
	protected abstract EodispMainFrame createMainFrame();

	/**
	 * This constructs all frames included in the application. It must be
	 * implemented by the specific application main controller.
	 */
	protected abstract void createControllers();

	/**
	 * <p>
	 * Creates the initial layout of the application. The behavior depends on
	 * the application. An implementation might read the layout from a file or
	 * specify one in code.
	 * </p>
	 * <p>
	 * The default implementation is to read from a file as specified by the
	 * configuration of the application.
	 * </p>
	 */
	private void createLayout() {
		if (rootWindow != null) {
			rootWindow.getRootWindowProperties().addSuperObject(
					new ShapedGradientDockingTheme().getRootWindowProperties());

			RootApp rootApp = AppRegistry.getRootApp();
			String tmpFile = ((UIApp) rootApp).getUiConfiguration().getViewStateEntry();

			if (tmpFile == null) {
				logger.debug("There is no configuration entry with the name 'view_state."
						+ "State of the root window cannot be recovered.");
			}

			File viewStateFile = new File(rootApp.getConfigurationDir(), tmpFile);
			FileInputStream fis;

			if (!viewStateFile.exists()) {
				logger.debug("Could not recover state of the root window. No file exists.");
				createInitialLayout();
				return;
			}

			try {
				fis = new FileInputStream(viewStateFile);
				ObjectInputStream in = new ObjectInputStream(fis);
				rootWindow.read(in);
				in.close();
			} catch (Exception e) {
				logger.info(String.format("Could not restore the layout from the file %s", viewStateFile
						.getAbsoluteFile().toString()), e);

				createInitialLayout();
			}
		}
	}

	/**
	 * This method can be used by sub-classes to create an initial layout. It
	 * will be called only the first time when there is no ui state file, or if
	 * an error occurs when reading the ui state file.
	 * <p>
	 * You do not need to call <code>super()</code>.
	 * 
	 */
	protected void createInitialLayout() {

	}

	/**
	 * Save the layout, if this method is supported by the application. Behavior
	 * depends on the application. An implementation might save the layout to a
	 * file.
	 * <p>
	 * The default implementation saves the layout of the root window in a file
	 * specified by the {@link UiConfiguration} of this application. It only
	 * saves the layout, it does not save the views (and their states) itself.
	 * Also, it does not save the state of the tool bar.
	 * </p>
	 */
	protected void saveLayout() {
		RootApp rootApp = AppRegistry.getRootApp();
		String tmpFile = ((UIApp) rootApp).getUiConfiguration().getViewStateEntry();

		if (tmpFile == null) {
			logger.warn("There is no configuration entry for the view state file."
					+ "State of the root window is not stored");
		}

		File viewStateFile = new File(rootApp.getConfigurationDir(), tmpFile);
		FileOutputStream fos;
		try {
			if (!viewStateFile.exists()) {
				viewStateFile.createNewFile();
			}
			fos = new FileOutputStream(viewStateFile);
			ObjectOutputStream out = new ObjectOutputStream(fos);

			logger.debug(String.format("Writing state of the root window to file: %s", viewStateFile.getAbsoluteFile()
					.toString()));

			rootWindow.write(out);
			out.close();
		} catch (Exception e) {
			logger.warn(String.format("Could not store the layout to the file %s", viewStateFile.getAbsoluteFile()
					.toString()), e);
		}

	}

	/**
	 * Returns the main frame of this application.
	 * 
	 * @return The main frame.
	 * @throws IllegalStateException
	 *             Thrown if this method is called before the application
	 *             controller has been initialized.
	 */
	public EodispMainFrame getMainFrame() throws IllegalStateException {
		if (mainFrame == null) {
			throw new IllegalStateException("application controller is not initialized.");
		}
		return mainFrame;
	}

	/**
	 * Returns the root window. This is the main container that holds all views.
	 * It is content pane of the main frame.
	 * 
	 * @return
	 */
	public RootWindow getRootWindow() {
		return rootWindow;
	}

	/**
	 * Initialization of the application controller. This initialization
	 * sequence can be override by subclasses.
	 */
	public void initialize() {
		mainFrame = createMainFrame();
		createControllers();
		mainFrame.addMenuBar();
		mainFrame.addToolBar();
		rootWindow = createRootWindow();
		createLayout();
		mainFrame.addRootWindow(rootWindow);

		mainFrame.showMainFrame();

		// add common listeners
		mainFrame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				handleExit();
			}
		});

		// update actions if necessary
		EodispMenuManager.getInstance().addMenuSelectedListener(new MenuSelectedListener() {
			public void menuSelected(JMenu menu) {
				updateAllActions();
			}
		});
	}

	public void handleExit() {
		if (canExit()) {
			saveLayout();
			AppRegistry.getRootApp().shutdown();
		}
	}

	/**
	 * Saves all changes in all models. It catches possible errors and shows an
	 * error message to the user. Indication if the operation succeeded is given
	 * by the return value.
	 * 
	 * @return True, if the save was successful, otherwise false.
	 * @throws IOException
	 *             Rethrown if one of the models throws an exception during
	 *             save.
	 */
	public void saveAllChanges() throws IOException {
		for (EodispController c : controllerList) {
			for (EodispView view : c.getViews()) {
				if (view != null) {
					EodispModel model = view.getModel();
					if (model != null) {
						if (model.hasChanges()) {
							model.doSave();
						}
					}
				}
			}
		}
	}

	public boolean hasAppChanges() {
		return getChangedViewNames().length > 0;
	}

	protected void updateAllModels() {
		// update models
		for (EodispController c : controllerList) {
			c.updateOwnedModels();
		}
	}

	/**
	 * Update the state of all actions. This method can be called when something
	 * changed that really needs to update many actions. Otherwise, it is less
	 * overhead to update single actions as appropriate.
	 */
	protected void updateAllActions() {
		// test the main frame
		if (mainFrame != null) {
			((ActionSourceProvider) mainFrame).updateRegistrations();
		}

		// test all other views.
		for (EodispController c : controllerList) {
			for (EodispView view : c.getViews()) {
				if (view != null && view instanceof ActionSourceProvider) {
					((ActionSourceProvider) view).updateRegistrations();
				}
			}
		}
	}

	/**
	 * Updates the state on each view by calling the
	 * {@link EodispView#updateViewState()} method.
	 */
	protected void updateAllViewStates() {
		for (EodispController c : controllerList) {
			c.updateOwnedViewStates();
		}
	}

	/**
	 * Checks in all currently active frames if there is a model which has been
	 * changed and therefore needs to save before exiting.
	 * <p>
	 * The method checks if the view and a model exists.
	 * 
	 * @return True, if the application can exit, false otherwise.
	 */
	protected boolean canExit() {
		boolean canExit = true;

		// get the names of the changed views and create a string. One line per
		// view.
		String[] changes = getChangedViewNames();
		if (changes.length > 0) {
			int choice = MessageBoxHelper.YesNoCancelQuestionBoxL(getMainFrame(), "AskForSaveViews.Msg",
					"AskForSaveViews.Cap");

			if (choice == JOptionPane.YES_OPTION) {
				try {
					saveAllChanges();
				} catch (IOException ex) {
					CommonMessageBoxes.showSaveError(null, ex.getMessage());
					canExit = false;
				}
			} else if (choice == JOptionPane.CANCEL_OPTION) {
				canExit = false;
			}
		}
		return canExit;
	}

	/**
	 * Checks in all views if its model(s) have changes. Returns an array of
	 * strings with the name of all views whose model(s) have changes.
	 * 
	 * @return An array of names of views whose model(s) have changes. Returns
	 *         an empty array if no changes are found.
	 */
	public String[] getChangedViewNames() {
		List<String> viewNamesWithChanges = new ArrayList<String>();

		for (EodispController c : controllerList) {
			for (EodispView view : c.getViews()) {
				if (view != null) {
					EodispModel model = view.getModel();
					if (model != null) {
						if (model.hasChanges()) {
							viewNamesWithChanges.add(view.getTitle());
						}
					}
				}
			}
		}

		return viewNamesWithChanges.toArray(new String[viewNamesWithChanges.size()]);
	}

	/**
	 * Adds all frames created by controllers to the main frame. The main frame
	 * itself should take care of the layout.
	 */
	protected RootWindow createRootWindow() {
		viewMap = new ViewMap();

		for (EodispController c : controllerList) {
			if (c.getViews() != null) {
				for (EodispView view : c.getViews()) {
					if (view != null) {
						viewMap.addView(view.getId(), view);
					}
				}
			}
		}

		RootWindow root = DockingUtil.createRootWindow(viewMap, true);

		// TODO remove for production use
//		 DeveloperUtil.createWindowLayoutFrame("Layout of the application", root).setVisible(true);

		return root;
	}

	/**
	 * Adds the dynamic view identified by the given ID. A new view will be
	 * created if not yet done.
	 * 
	 * @param viewId
	 *            The Id of the view to be added.
	 */
	protected void showDynamicView(int viewId) {
		for (EodispController c : controllerList) {
			if (c.isControllerForView(viewId)) {
				for (EodispView view : c.getViews()) {
					if (view.getId() == viewId) {
						view.restoreFocus();
						view.restore();
						view.makeVisible();
						return;
					}
				}

				// let the controller create the view.
				EodispView dynView = c.createDynamicView(viewId);
				if (dynView != null) {
					mainFrame.addDynamicView(dynView);
				}
			}
		}
	}

	/**
	 * Attaches the given controller to the list of controllers for this
	 * application. If the controller is already registered in the list, the
	 * operation is ignored.
	 * 
	 * @param c
	 */
	protected void attachController(EodispController c) {
		if (!controllerList.contains(c)) {
			controllerList.add(c);
		}
	}

	/**
	 * Removes a controller from the list of controllers registered for this
	 * application. It should free all resources currently held by this
	 * controller and it should also dispose all underlying frames and views
	 * that are connected to the controller.
	 * 
	 * @param c
	 *            The controller to be removed from the list of registered
	 *            controllers.
	 */
	protected void detachController(@SuppressWarnings("unused")
	EodispController c) {
		throw new UnsupportedOperationException("method detachController is not yet implemented");
		// TODO
	}

	/**
	 * Removes all controllers from the list of controllers registered for this
	 * application. It should free all resources currently held by the
	 * controllers and should also dispose all underlying frames and views.
	 * <p>
	 * This should be called before exit the application. It ensures a proper
	 * sequence of the exit process.
	 */
	protected void detachAllControllers() {
		throw new UnsupportedOperationException("method detachAllControllers is not yet implemented");
		// TODO
	}
}
