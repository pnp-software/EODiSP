/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.shared.views;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.WindowAdapter;

import javax.swing.*;

/**
 * @author eglimi
 * @version $Id:$
 * 
 */
public class HelpDialog {

	private final JPanel mainPanel = new JPanel(new BorderLayout());

	private final JDialog dialog = new JDialog();

	private final JLabel about = new JLabel(aboutText);

	private final JButton closeBtn = new JButton("Ok");

	private static final String aboutText = "<html> <a href=\"http://pnp-software.com/eodisp\">Online Manual</html>";

	public HelpDialog() {
		dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		dialog.setPreferredSize(new Dimension(400, 200));

		mainPanel.add(about, BorderLayout.CENTER);
		mainPanel.add(closeBtn, BorderLayout.SOUTH);

		dialog.setContentPane(new JScrollPane(mainPanel));
	}

	public void showDialog() {
		dialog.pack();
		dialog.setVisible(true);
	}

	/**
	 * Adds the adapter to the dialog.
	 * 
	 * @param adapter
	 *            The adapter to be added.
	 */
	public void addWindowListener(WindowAdapter adapter) {
		dialog.addWindowListener(adapter);
	}

	/**
	 * Removes the adapter from the dialog.
	 * 
	 * @param adapter
	 *            The adapter to be removed.
	 */
	public void removeWindowListener(WindowAdapter adapter) {
		dialog.removeWindowListener(adapter);
	}
}
