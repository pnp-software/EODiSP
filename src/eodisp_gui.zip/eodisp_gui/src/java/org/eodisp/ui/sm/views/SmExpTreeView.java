/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.sm.views;

import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Vector;

import javax.swing.Action;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.TreePath;

import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eodisp.core.sm.application.SmAppModuleCore;
import org.eodisp.core.sm.helper.SmEmfHelper;
import org.eodisp.core.sm.service.ExperimentTaskManager;
import org.eodisp.core.sm.service.ExperimentTaskState;
import org.eodisp.core.sm.service.ExperimentTaskState.ControlFederateState;
import org.eodisp.core.sm.service.ExperimentTaskState.TaskState;
import org.eodisp.ui.common.actions.*;
import org.eodisp.ui.common.base.EodispView;
import org.eodisp.ui.common.base.UIApp;
import org.eodisp.ui.common.components.EodispTree;
import org.eodisp.ui.common.components.SdoTreeNode;
import org.eodisp.ui.sm.application.SmAppUtils;
import org.eodisp.ui.sm.controllers.SMAppController;
import org.eodisp.ui.sm.models.SmExpTreeModel;
import org.eodisp.ui.sm.resources.SmResources;
import org.eodisp.util.AppRegistry;
import org.eodisp.wrapper.hla.FederationState;

/**
 * @author eglimi
 * @version $Id:$
 */
@SuppressWarnings("serial")
public final class SmExpTreeView extends EodispView implements ActionSourceProvider {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(SmExpTreeView.class);

	private final String TITLE = SmResources.getMessage("SmExpTreeView.View.Title");

	private final JScrollPane scrollPane = new JScrollPane();

	private final EodispTree tree = new EodispTree();

	private Vector<Object> expandedNodes = null;

	private int[] selectedRows = null;

	public static final int ID = 10;

	public static final EodispAction onAddFederationExecution = new EodispAction() {
		{
			setShowInContextMenu(true);
			setShowInMenuBar(false);
			putValue(Action.NAME, SmResources.getMessage("FederationExecution.New.Name"));
			putValue(Action.SHORT_DESCRIPTION, SmResources.getMessage("FederationExecution.New.ShortDesc"));
			putValue(EodispAction.CTX_GROUP, "AddObject");
			setEnabled(false);
		}
	};

	public static final EodispAction onAddFederateExecution = new EodispAction() {
		{
			setShowInContextMenu(true);
			setShowInMenuBar(false);
			putValue(Action.NAME, SmResources.getMessage("FederateExecution.New.Name"));
			putValue(Action.SHORT_DESCRIPTION, SmResources.getMessage("FederateExecution.New.ShortDesc"));
			putValue(EodispAction.CTX_GROUP, "AddObject");
			setEnabled(true);
		}
	};

	public static final EodispAction onAddInitData = new EodispAction() {
		{
			setShowInContextMenu(true);
			setShowInMenuBar(false);
			putValue(Action.NAME, SmResources.getMessage("SmExpTreeView.AddInitData.Name"));
			putValue(Action.SHORT_DESCRIPTION, SmResources.getMessage("SmExpTreeView.AddInitData.ShortDesc"));
			putValue(EodispAction.CTX_GROUP, "AddObject");
			setEnabled(true);
		}
	};

	public static final EodispAction onDeleteSelection = new EodispAction() {
		{
			setShowInContextMenu(true);
			setShowInMenuBar(false);
			putValue(Action.NAME, SmResources.getMessage("TreeView.DelSelection.Name"));
			putValue(Action.SHORT_DESCRIPTION, SmResources.getMessage("TreeView.DelSelection.ShortDesc"));
			putValue(Action.SMALL_ICON, SmResources.getIcon("16x16/actions/delete.png"));
			putValue(EodispAction.CTX_GROUP, "DeleteObject");
			setEnabled(false);
		}
	};

	public static final EodispAction onShowInfo = new EodispAction() {
		{
			setShowInContextMenu(true);
			setShowInMenuBar(false);
			putValue(Action.NAME, SmResources.getMessage("TreeView.onShowInfo.Name"));
			putValue(Action.SHORT_DESCRIPTION, SmResources.getMessage("TreeView.onShowInfo.ShortDesc"));
			putValue(EodispAction.CTX_GROUP, "InfoObject");
			setEnabled(false);
		}
	};

	/**
	 * Starts the experiments.
	 */
	public static final EodispAction onExperimentPrepare = new EodispAction() {
		{
			setShowInContextMenu(true);
			setShowInMenuBar(false);
			putValue(Action.NAME, SmResources.getMessage("SmExpTreeView.Simulation.ExpPrepare.Name"));
			putValue(Action.SHORT_DESCRIPTION, SmResources.getMessage("SmExpTreeView.Simulation.ExpPrepare.ShortDesc"));
			putValue(Action.SMALL_ICON, SmResources.getIcon("16x16/actions/prepare.png"));
			putValue(EodispAction.CTX_GROUP_SUBMENU, SmResources.getMessage("Menu.Simulation.CtxName"));
			setEnabled(false);
		}
	};

	public static final EodispAction onExperimentStart = new EodispAction() {
		{
			setShowInContextMenu(true);
			setShowInMenuBar(false);
			putValue(Action.NAME, SmResources.getMessage("SmExpTreeView.Simulation.ExpStart.Name"));
			putValue(Action.SHORT_DESCRIPTION, SmResources.getMessage("SmExpTreeView.Simulation.ExpStart.ShortDesc"));
			// putValue(Action.ACCELERATOR_KEY,
			// KeyStroke.getKeyStroke(KeyEvent.VK_F11, ActionEvent.CTRL_MASK));
			putValue(Action.SMALL_ICON, SmResources.getIcon("16x16/actions/ok.png"));
			putValue(EodispAction.CTX_GROUP_SUBMENU, SmResources.getMessage("Menu.Simulation.CtxName"));
			setEnabled(false);
		}
	};

	public static final EodispAction onExperimentPause = new EodispAction() {
		{
			setShowInContextMenu(true);
			setShowInMenuBar(false);
			putValue(Action.NAME, SmResources.getMessage("SmExpTreeView.Simulation.ExpPause.Name"));
			putValue(Action.SHORT_DESCRIPTION, SmResources.getMessage("SmExpTreeView.Simulation.ExpPause.ShortDesc"));
			// putValue(Action.SMALL_ICON,
			// SmResources.getIcon("16x16/actions/pause.png"));
			putValue(EodispAction.CTX_GROUP_SUBMENU, SmResources.getMessage("Menu.Simulation.CtxName"));
			setEnabled(false);
		}
	};

	public static final EodispAction onExperimentResume = new EodispAction() {
		{
			setShowInContextMenu(true);
			setShowInMenuBar(false);
			putValue(Action.NAME, SmResources.getMessage("SmExpTreeView.Simulation.ExpResume.Name"));
			putValue(Action.SHORT_DESCRIPTION, SmResources.getMessage("SmExpTreeView.Simulation.ExpResume.ShortDesc"));
			putValue(EodispAction.CTX_GROUP_SUBMENU, SmResources.getMessage("Menu.Simulation.CtxName"));
			setEnabled(false);
		}
	};

	public static final EodispAction onNextStep = new EodispAction() {
		{
			setShowInContextMenu(true);
			setShowInMenuBar(false);
			putValue(Action.NAME, SmResources.getMessage("SmExpTreeView.Simulation.ExpNextStep.Name"));
			putValue(Action.SHORT_DESCRIPTION, SmResources.getMessage("SmExpTreeView.Simulation.ExpNextStep.ShortDesc"));
			// putValue(Action.SMALL_ICON,
			// SmResources.getIcon("16x16/actions/next.png"));
			putValue(EodispAction.CTX_GROUP_SUBMENU, SmResources.getMessage("Menu.Simulation.CtxName"));
			setEnabled(false);
		}
	};

	public static final EodispAction onExperimentKill = new EodispAction() {
		{
			setShowInContextMenu(true);
			setShowInMenuBar(false);
			putValue(Action.NAME, SmResources.getMessage("SmExpTreeView.Simulation.ExpKill.Name"));
			putValue(Action.SHORT_DESCRIPTION, SmResources.getMessage("SmExpTreeView.Simulation.ExpKill.ShortDesc"));
			putValue(Action.SMALL_ICON, SmResources.getIcon("16x16/actions/stop.png"));
			putValue(EodispAction.CTX_GROUP_SUBMENU, SmResources.getMessage("Menu.Simulation.CtxName"));
			setEnabled(false);
		}
	};

	public static final EodispAction onExperimentReset = new EodispAction() {
		{
			setShowInContextMenu(true);
			setShowInMenuBar(false);
			putValue(Action.NAME, SmResources.getMessage("SmExpTreeView.Simulation.ExpReset.Name"));
			putValue(Action.SHORT_DESCRIPTION, SmResources.getMessage("SmExpTreeView.Simulation.ExpReset.ShortDesc"));
			putValue(EodispAction.CTX_GROUP_SUBMENU, SmResources.getMessage("Menu.Simulation.CtxName"));
			setEnabled(false);
		}
	};

	/**
	 * Default constructor.
	 */
	public SmExpTreeView() {
		super();

		registerActions();
	}

	@Override
	public void initializeComponents() {

		tree.setModel(getTreeModel());
		// tree.setTransferHandler(new SdoTransferHandler());

		scrollPane.setViewportView(tree);

		setComponent(getInternalComponent());
		tree.setCellRenderer(new SmSdoTreeCellRenderer());

		// the listener for the mouse. This is used for the context menu.
		tree.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				if (e.isPopupTrigger()) {
					handlePopup(e);
				}
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				if (e.isPopupTrigger()) {
					handlePopup(e);
				}
			}
		});

		getSmExpTreeModel().addExperimentTreeListenerListener(new ExperimentTreeModelListener() {

			public void treeWillReload() {
				saveExpansionState();
			}

			public void treeReloaded() {
				restoreExpansionState();
			}

		});
	}

	@Override
	public Component getInternalComponent() {
		return scrollPane;
	}

	@Override
	public String getTitle() {
		return TITLE;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getId() {
		return ID;
	}

	public void registerActions() {
		EodispActionRegistry.getInstance().registerAction(onAddFederationExecution, this.getClass());
		EodispActionRegistry.getInstance().registerAction(onAddFederateExecution, this.getClass());
		EodispActionRegistry.getInstance().registerAction(onAddInitData, this.getClass());
		EodispActionRegistry.getInstance().registerAction(onDeleteSelection, this.getClass());
		EodispActionRegistry.getInstance().registerAction(onShowInfo, this.getClass());
		EodispActionRegistry.getInstance().registerAction(onExperimentPrepare, this.getClass());
		EodispActionRegistry.getInstance().registerAction(onExperimentStart, this.getClass());
		EodispActionRegistry.getInstance().registerAction(onExperimentPause, this.getClass());
		EodispActionRegistry.getInstance().registerAction(onExperimentResume, this.getClass());
		EodispActionRegistry.getInstance().registerAction(onNextStep, this.getClass());
		EodispActionRegistry.getInstance().registerAction(onExperimentKill, this.getClass());
		EodispActionRegistry.getInstance().registerAction(onExperimentReset, this.getClass());
	}

	protected SmExpTreeModel getTreeModel() {
		return (SmExpTreeModel) super.getModel();
	}

	private void saveExpansionState() {
		expandedNodes = new Vector<Object>();

		expandedNodes.setSize(tree.getRowCount());
		for (int i = 0; i < tree.getRowCount(); i++) {
			if (tree.isExpanded(i)) {
				Object nodeData = ((SdoTreeNode) tree.getPathForRow(i).getLastPathComponent()).getUserObject();
				expandedNodes.add(nodeData);
			}
		}

		if (tree.getSelectionRows() != null) {
			selectedRows = new int[tree.getSelectionCount()];
			System.arraycopy(tree.getSelectionRows(), 0, selectedRows, 0, tree.getSelectionCount());
		}
	}

	private void restoreExpansionState() {

		int rowIndex = 0;
		while (rowIndex < tree.getRowCount()) {
			TreePath curPath = tree.getPathForRow(rowIndex);
			Object nodeData = ((SdoTreeNode) curPath.getLastPathComponent()).getUserObject();
			boolean contained = expandedNodes.contains(nodeData);
			if (contained) {
				tree.expandRow(rowIndex);
			}
			rowIndex++;
		}

		if (selectedRows != null) {
			tree.setSelectionRows(selectedRows);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void updateViewState() {
		tree.repaint();
	}

	protected void handlePopup(MouseEvent e) {
		TreePath path = tree.getPathForLocation(e.getX(), e.getY());
		tree.getSelectionModel().setSelectionPath(path);

		handleActionRegistrations(path);

		JPopupMenu ctxMenu = EodispMenuManager.getInstance().getCtxMenu(this.getClass());
		// show it if something has been added
		if (ctxMenu.getComponents().length > 0) {
			ctxMenu.show(tree, e.getX(), e.getY());
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void updateRegistrations() {
		TreePath path = tree.getSelectionModel().getSelectionPath();
		handleActionRegistrations(path);
	}

	/**
	 * Handles the registration (enable/disable) of static (i.e. not dynamic)
	 * actions.
	 * 
	 * @param path
	 *            The path pointing to the current selection. This is
	 *            <code>null</code> if no node is selected.
	 */
	private void handleActionRegistrations(TreePath path) {
		SdoTreeNode node = null;
		// This sets the selection and gets the node, if possible
		if (path != null) {
			node = (SdoTreeNode) path.getLastPathComponent();
		}

		// clear all actions first
		onExperimentPrepare.setEnabled(false);
		onExperimentStart.setEnabled(false);
		onExperimentPause.setEnabled(false);
		onExperimentResume.setEnabled(false);
		onExperimentKill.setEnabled(false);
		onExperimentReset.setEnabled(false);
		onNextStep.setEnabled(false);

		onAddFederationExecution.setEnabled(false);
		onAddFederateExecution.setEnabled(false);
		onAddInitData.setEnabled(false);
		onDeleteSelection.setEnabled(false);
		onShowInfo.setEnabled(false);

		if (node == null) {

			// nothing yet

		} else {
			final EDataObject userObj = (EDataObject) node.getUserObject();

			onDeleteSelection.setEnabled(true);
			onDeleteSelection.putValue(EodispAction.USER_OBJECT, node.getUserObject());

			if (SmEmfHelper.isExperiment(userObj)) {
				onDeleteSelection.setEnabled(false);
				onAddFederationExecution.setEnabled(true);
				onAddFederationExecution.putValue(EodispAction.USER_OBJECT, userObj);

				if (SmAppUtils.isConnected()) {
					// enable menus
					ExperimentTaskManager taskMgr = ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(
							SmAppModuleCore.ID)).getExperimentTaskManager();
					EDataObject currentExperiment = ((SMAppController) ((UIApp) AppRegistry.getRootApp())
							.getApplicationController()).getCurrentExperiment();

					ExperimentTaskState state = taskMgr.getState(currentExperiment);
					if (state != null) {
						onExperimentReset.setEnabled(true);

						TaskState ts = state.getTaskState();
						ControlFederateState cs = state.getControlFederateState();
						FederationState fs = state.getFederationState();

						// re-enable whatever can be enabled
						if (ts != TaskState.CANCELLING) {

							if (!(ts == TaskState.END)) {
								onExperimentKill.setEnabled(true);
							}

							if (cs == ControlFederateState.STOPPED) {
								if (ts == TaskState.PREPARED) {
									onExperimentStart.setEnabled(true);
								}
							} else if (cs == ControlFederateState.STARTED && ts == TaskState.STARTED) {
								if (fs == FederationState.STARTED) {
									onExperimentPause.setEnabled(true);
								} else if (fs == FederationState.PAUSED) {
									onExperimentResume.setEnabled(true);
									onNextStep.setEnabled(true);
								}
							}
						}
					} else {
						onExperimentPrepare.setEnabled(true);
					}
				}

			} else if (SmEmfHelper.isFederationExecution(userObj)) {
				onAddFederateExecution.putValue(EodispAction.USER_OBJECT, userObj);
				onAddFederateExecution.setEnabled(true);

			} else if (SmEmfHelper.isLocalFederate(userObj)) {
				onAddInitData.putValue(EodispAction.USER_OBJECT, userObj);
				onAddInitData.setEnabled(true);
				onShowInfo.putValue(EodispAction.USER_OBJECT, userObj);
				onShowInfo.setEnabled(true);
			}
		}
	}

	public SdoTreeNode getSelectedNode() {
		return (SdoTreeNode) tree.getSelectionPath().getLastPathComponent();
	}

	private SmExpTreeModel getSmExpTreeModel() {
		return (SmExpTreeModel) super.getModel();
	}

	public void addTreeSelectionListener(TreeSelectionListener listener) {
		tree.addTreeSelectionListener(listener);
	}

	public void removeTreeSelectionListener(TreeSelectionListener listener) {
		tree.removeTreeSelectionListener(listener);
	}
}
