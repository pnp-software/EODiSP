package org.eodisp.ui.sm.views;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;

import org.eodisp.ui.common.components.SdoTreeNode;

/**
 * Currently not used in the framwork!
 * <p>
 * A <code>Transferable</code> object can be used to implement drag and drop.
 * This class could be used to transfer SDO objects (such as
 * <code>DataObject</code>s.
 * 
 * @author eglimi
 * @version $Id:$
 */
class SdoTransferable implements Transferable {

	private final SdoTreeNode node;

	private final DataFlavor[] supportedFlavors = new DataFlavor[] { sdoDataFlavor };

	public static final DataFlavor sdoDataFlavor = createConstant(SdoTreeNode.class, "SdoTreeNode Data Flavor");

	private SdoTransferable(SdoTreeNode node) {
		this.node = node;
	}

	public boolean isDataFlavorSupported(DataFlavor flavor) {
		return sdoDataFlavor.equals(flavor);
	}

	public DataFlavor[] getTransferDataFlavors() {
		return supportedFlavors;
	}

	public Object getTransferData(DataFlavor flavor) throws UnsupportedFlavorException, IOException {
		if (!isDataFlavorSupported(flavor)) {
			throw new UnsupportedFlavorException(flavor);
		}

		return node;
	}

	public static SdoTransferable createSdoTransferable(SdoTreeNode node) {
		return new SdoTransferable(node);
	}

	private static DataFlavor createConstant(Class cl, String rn) {
		return new DataFlavor(cl, rn);
	}

}
