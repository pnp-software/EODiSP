/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.mm.controllers;

import java.awt.event.ActionEvent;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eodisp.core.common.EmfUtil;
import org.eodisp.core.common.ReposServiceProxy;
import org.eodisp.core.mm.application.MmAppModuleCore;
import org.eodisp.core.mm.config.MmConfiguration;
import org.eodisp.core.mm.helper.MmEmfHelper;
import org.eodisp.core.mm.service.Federate;
import org.eodisp.ui.common.actions.EodispAction;
import org.eodisp.ui.common.base.*;
import org.eodisp.ui.common.resources.CommonMessageBoxes;
import org.eodisp.ui.common.resources.MessageBoxHelper;
import org.eodisp.ui.mm.application.MmAppUtils;
import org.eodisp.ui.mm.models.MmFederatesModel;
import org.eodisp.ui.mm.views.MmFedPermissionsDialog;
import org.eodisp.ui.mm.views.MmFederateInfoDialog;
import org.eodisp.ui.mm.views.MmFederatesView;
import org.eodisp.util.AppRegistry;

/**
 * @author eglimi
 * @version $Id:$
 */
public class MmFederatesController extends EodispController {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(MmFederatesController.class);

	private MmFederatesModel federatesModel;

	/**
	 * {@inheritDoc}
	 */
	@Override
	public EodispView createDynamicView(int id) {
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void createStaticViews() {
		// create a new FederatesView view
		if (federatesModel != null) {
			MmFederatesView federatesView = new MmFederatesView();
			federatesView.setModel(federatesModel);
			federatesView.initializeComponents();
			attachView(federatesView);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isControllerForView(int id) {
		switch (id) {
		case MmFederatesView.ID:
			return true;
		default:
			return false;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void registerActionHandler() {
		MmFederatesView.onRegisterFederate.registerTargetHandler(new EodispDelegate(this, "onRegisterFederate"));
		MmFederatesView.onDeregisterFederate.registerTargetHandler(new EodispDelegate(this, "onDeregisterFederate"));
		MmFederatesView.onManagePermissions.registerTargetHandler(new EodispDelegate(this, "onManagePermissions"));
		MmFederatesView.onAddInfo.registerTargetHandler(new EodispDelegate(this, "onAddInfo"));
	}

	public void onRegisterFederate(ActionEvent e) {
		logger.debug("performing action: onRegisterFederate");

		JFrame owner = ((UIApp) AppRegistry.getRootApp()).getMainFrame();

		if (!MmAppUtils.isAppRegistered()) {
			CommonMessageBoxes.showReposNotRegisteredError(owner);
			return;
		}

		EodispAction a = (EodispAction) ((JMenuItem) e.getSource()).getAction();
		Federate userObj = (Federate) a.getValue(EodispAction.USER_OBJECT);

		ReposServiceProxy service = ((MmAppModuleCore) AppRegistry.getRootApp().getAppModule(MmAppModuleCore.ID))
				.getReposServiceProxy();

		String appId = ((MmConfiguration) AppRegistry.getRootApp().getConfiguration(MmConfiguration.ID)).getEntry(
				MmConfiguration.APP_ID).getValue();
		try {
			MmEmfHelper.copyFederateData(service.getRootObject(), userObj, "", appId);
		} catch (Exception ex) {
			logger.error("Could not register the federation ", ex);
			MessageBoxHelper.ErrorBoxL(owner, "Error.Transfer.Msg", "Error.Transfer.Cap", ex.getMessage());
		}

		updateOwnedModels();

		logger.debug("onRegisterFederate completed");
	}

	public void onDeregisterFederate(ActionEvent e) {
		logger.debug("performing action: onDeregisterFederate");

		EodispAction a = (EodispAction) ((JMenuItem) e.getSource()).getAction();
		Federate userObj = (Federate) a.getValue(EodispAction.USER_OBJECT);

		ReposServiceProxy service = ((MmAppModuleCore) AppRegistry.getRootApp().getAppModule(MmAppModuleCore.ID))
				.getReposServiceProxy();

		EDataObject reposFederate = MmEmfHelper.findReposFederate(service.getRootObject(), userObj.getFederateId(),
				userObj.getFederateVersion());
		if (reposFederate != null) {
			EmfUtil.delete(reposFederate);
		}

		updateOwnedModels();

		logger.debug("onDeregisterFederate completed");
	}

	public void onManagePermissions(ActionEvent e) {
		logger.debug("performing action: onManagePermissions");

		JFrame owner = ((UIApp) AppRegistry.getRootApp()).getMainFrame();

		// check for changes first
		if (federatesModel.hasChanges()) {
			int choice = CommonMessageBoxes.showInstructSave(owner);
			if (choice == JOptionPane.YES_OPTION) {
				try {
					federatesModel.doSave();
				} catch (IOException ex) {
					CommonMessageBoxes.showSaveError(owner, ex.getMessage());
					return;
				}
			} else {
				return;
			}
		}

		EodispAction a = (EodispAction) ((JMenuItem) e.getSource()).getAction();
		Federate userObj = (Federate) a.getValue(EodispAction.USER_OBJECT);

		MmFedPermissionsDialog.showSelectionDialog(owner, userObj);

		updateOwnedViewStates();

		logger.debug("onManagePermissions completed");
	}

	public void onAddInfo(ActionEvent e) {
		logger.debug("performing action: onAddInfo");

		JFrame owner = ((UIApp) AppRegistry.getRootApp()).getMainFrame();

		// check for changes first
		if (federatesModel.hasChanges()) {
			int choice = CommonMessageBoxes.showInstructSave(owner);
			if (choice == JOptionPane.YES_OPTION) {
				try {
					federatesModel.doSave();
				} catch (IOException ex) {
					CommonMessageBoxes.showSaveError(owner, ex.getMessage());
					return;
				}
			} else {
				return;
			}
		}

		EodispAction a = (EodispAction) ((JMenuItem) e.getSource()).getAction();
		Federate userObj = (Federate) a.getValue(EodispAction.USER_OBJECT);

		MmFederateInfoDialog.showInitDataDialog(owner, userObj);

		updateOwnedViewStates();

		logger.debug("onAddInfo completed");
	}

	@Override
	protected void initialize() {
		super.initialize();

		federatesModel = new MmFederatesModel();

		// create the views for this controller.
		createStaticViews();
	}
}
