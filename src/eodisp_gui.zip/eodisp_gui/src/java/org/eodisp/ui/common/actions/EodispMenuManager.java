/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 *  web:  http://www.pnp-software.com
 *  mail: info@pnp-software.com
 */
package org.eodisp.ui.common.actions;

import java.awt.Component;
import java.util.*;

import javax.swing.*;
import javax.swing.event.EventListenerList;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;

import org.eodisp.ui.common.base.UIUtil;

/**
 * EodispMenuManager handles the items in the menu bar, the tool bar, and the
 * context menus for this application. It does this through the use of
 * {@link javax.swing.Action}s.
 * <p>
 * Items for all these types of bar's can be added or removed at runtime. The
 * EodispMenuManager can be used to update the UI as appropriate.
 * 
 * @author eglimi
 * @version $Id:EodispMenuManager.java 2134 2006-05-16 08:43:27Z eglimi $
 */
public class EodispMenuManager {

	private EventListenerList listeners = new EventListenerList();

	/**
	 * Holds the only INSTANCE of this class.
	 */
	private static EodispMenuManager INSTANCE = new EodispMenuManager();

	/**
	 * Holds the menu bar for this application. The menu bar should be
	 * constructed at startup. However, it can be changed later at runtime.
	 */
	private final JMenuBar menuBar = new JMenuBar();

	/**
	 * Holds the tool bar for this application. The tool bar should be
	 * constructed at startup. However, it can be changed later at runtime.
	 */
	private final JToolBar toolBar = new JToolBar(JToolBar.HORIZONTAL);

	/**
	 * Holds a list of menus that were created for the menu bar.
	 */
	private Vector<JMenu> createdMenus;

	/**
	 * Enforce {@link #getInstance()}.
	 */
	private EodispMenuManager() {
		toolBar.setOpaque(false);

		EodispActionRegistry.getInstance().addActionChangedListener(new EodispActionListener() {
			public void actionChanged(ActionChangedEvent evt) {
				switch (evt.getActionType()) {
				case ACTION_ADDEDD:
				case ACTION_REMOVED:
					constructMenuBar();
					constructToolBar();
				}
			}
		});
	}

	/**
	 * Returns the only INSTANCE of this class.
	 * 
	 * @return The only INSTANCE of this class.
	 */
	public static EodispMenuManager getInstance() {
		return INSTANCE;
	}

	/**
	 * Constructs the whole menu bar. This can be displayed in the main frame of
	 * the application.
	 * 
	 * @return The complete menu bar.
	 */
	public JMenuBar getMenuBar() {
		constructMenuBar();
		UIUtil.align(menuBar);

		return menuBar;
	}

	/**
	 * Constructs the whole tool bar. This can be displayed in the main frame of
	 * the application.
	 * 
	 * @return The complete tool bar.
	 */
	public JToolBar getToolBar() {
		constructToolBar();

		return toolBar;
	}

	/**
	 * This constructs a context menu. Entries can be hierarchical, depending on
	 * the top menu name of the action.
	 * <p>
	 * All dynamic entries are considered for inclusion into the context menu.
	 * The application have to take care of the entries in the
	 * {@link EodispActionRegistry}, before constructing this menu.
	 * 
	 * @return The context menu that can be displayed as a pop-up menu in the
	 *         application.
	 */
	public <T extends ActionSourceProvider> JPopupMenu getCtxMenu(Class<T> type) {
		JPopupMenu ctxMenu = constructCtxMenu(type);
		UIUtil.align(ctxMenu);
		return ctxMenu;

	}

	/**
	 * Constructs the menu bar to be displayed in the main frame. A new menu bar
	 * is created when calling this method.
	 * 
	 * @return The complete menu bar.
	 */
	private void constructMenuBar() {
		menuBar.removeAll();

		// Get all actions registered in the action registry.
		List<EodispAction> menuActionsList = EodispActionRegistry.getInstance().getMenuBarActions();

		createdMenus = new Vector<JMenu>();

		for (EodispAction a : menuActionsList) {
			JMenu parent = getParentMenu(createdMenus, a.getTopMenuItemName());
			if (a.isCheckBox()) {
				JCheckBoxMenuItem jb = new JCheckBoxMenuItem(a);
				jb.setSelected(a.isCheckBoxEnabled());
				parent.add(jb, a.getMenuIndex());
			} else {
				JMenuItem tmpItem = new JMenuItem(a);
				Icon disabledIcon = UIManager.getLookAndFeel().getDisabledIcon(tmpItem,
						(ImageIcon) a.getValue(Action.SMALL_ICON));
				tmpItem.setDisabledIcon(disabledIcon);
				parent.add(tmpItem, a.getMenuIndex());
			}

			a.setProcessed(true);
		}

		// Sort the well known entries in the top menu items. Its more efficient
		// if all entries are there from the beginning, but it works also if
		// entries are missing.
		short sorted = 0;
		short i = 0;
		short tries = 0;
		while ((sorted & 15) != 15 && tries <= 2) {
			if (createdMenus.get(i).getText().equalsIgnoreCase("File")) {
				if (i != 0) {
					createdMenus.set(0, createdMenus.set(i, createdMenus.get(0)));
				}
				sorted |= 1;
			} else if (createdMenus.get(i).getText().equalsIgnoreCase("Edit")) {
				if (i != 1) {
					createdMenus.set(1, createdMenus.set(i, createdMenus.get(1)));
				}
				sorted |= 2;
			} else if (createdMenus.get(i).getText().equalsIgnoreCase("Settings")) {
				if (i != 2) {
					createdMenus.set(2, createdMenus.set(i, createdMenus.get(2)));
				}
				sorted |= 4;
			} else if (createdMenus.get(i).getText().equalsIgnoreCase("Help")) {
				if (i != (createdMenus.size() - 1)) {
					createdMenus.set(createdMenus.size() - 1, createdMenus.set(i, createdMenus
							.get(createdMenus.size() - 1)));
				}
				sorted |= 8;
			}

			if (i >= createdMenus.size() - 1) {
				i = 0;
				tries++;
			} else {
				i++;
			}
		}

		for (JMenu m : createdMenus) {
			menuBar.add(m);
		}
	}

	/**
	 * Returns the parent (containment) menu for a menu. This method constructs
	 * the menu structure including sub-menus.
	 * 
	 * @param menus
	 *            A list of menus which are already defined.
	 * @param topMenuName
	 *            The name of the top menu. This can be split using "/" to
	 *            specify sub-menus.
	 * @return The menu which is the container for the item to be added.
	 * @throws IllegalArgumentException
	 *             Thrown if th top menu name is the empty String.
	 */
	private JMenu getParentMenu(Vector<JMenu> menus, String topMenuName) {
		if (topMenuName.equals("")) {
			throw new IllegalArgumentException(
					"The String for the menu entry cannot be the empty string. Set it to some sensible value");
		}

		int index = topMenuName.indexOf("/");
		String parentString = index != -1 ? topMenuName.substring(0, index) : topMenuName;

		JMenu parent = null;
		for (JMenu menu : menus) {
			if (!menu.getText().equalsIgnoreCase(parentString)) {
				continue;
			}
			parent = menu;
		}

		if (parent == null) {
			parent = new JMenu(parentString);
			// to be informed whenever the menu is opened.
			parent.getPopupMenu().addPopupMenuListener(new PopupMenuListener() {
				public void popupMenuWillBecomeVisible(PopupMenuEvent e) {
					fireMenuSelected((JMenu) ((JPopupMenu) e.getSource()).getParent());
				}

				public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {
				}

				public void popupMenuCanceled(PopupMenuEvent e) {
				}
			});
			menus.add(parent);
		}

		if (index != -1 && topMenuName.substring(index + 1).length() > 0) {
			parent = addChildren(parent, topMenuName.substring(index + 1));
		}

		return parent;
	}

	/**
	 * Adds a child menu to a parent menu. No items are added here, but only
	 * menus. It searches the parent to check if the menu in question had
	 * already been created. If it was, this menu will be returned. Otherwise, a
	 * new menu will be created and added to the parent menu.
	 * 
	 * @param parent
	 *            The parent menu to which a menu is added.
	 * @param menuName
	 *            The name of the (sub-)menu which is added to the parent menu.
	 * @return The child menu which has either been found or newly created.
	 */
	private JMenu addChildren(JMenu parent, String menuName) {

		int index = menuName.indexOf("/");

		String subMenuString = index != -1 ? menuName.substring(0, index) : menuName;

		if (index == -1 && subMenuString.length() <= 0) {
			return parent;
		}

		JMenu child = null;
		for (Object o : parent.getMenuComponents()) {
			if (o instanceof JMenu) {
				if (!((JMenu) o).getText().equalsIgnoreCase(subMenuString)) {
					continue;
				}
				child = (JMenu) o;
			}
		}

		if (child == null) {
			child = new JMenu(subMenuString);
			parent.add(child);
		}

		if (index != -1 && subMenuString.length() > 0) {
			JMenu menu = addChildren(child, menuName.substring(index + 1));
			if (menu != null) {
				return menu;
			}
		}

		return child;
	}

	/**
	 * Removes <b>all</b> dynamic actions from the given menu.
	 * 
	 * @param menu
	 *            The menu which should be checked for dynamic actions that are
	 *            due to delete.
	 */
	private void removeDynamicActionsFromMenu(JMenu menu) {
		Vector<JMenuItem> itemsToDelete = new Vector<JMenuItem>(4);

		if (menu.getMenuComponentCount() <= 0) {
			return;
		}

		for (Component comp : menu.getMenuComponents()) {
			if (comp instanceof JMenu) {
				removeDynamicActionsFromMenu((JMenu) comp);
				continue;
			}

			if (comp instanceof JMenuItem) {
				EodispAction action = (EodispAction) ((JMenuItem) comp).getAction();
				if (action != null) {
					itemsToDelete.add((JMenuItem) comp);
				}
			}
		}
		for (JMenuItem item : itemsToDelete) {
			menu.remove(item);
		}
	}

	/**
	 * Checks for empty menus in the given parent menu and deletes them from the
	 * container.
	 * 
	 * @param parent
	 *            The container to be checked for empty menus.
	 * @return The menu that is empty or null, if no empty menu can be found.
	 */
	private JMenu removeEmptyMenus(JMenu parent) {
		Vector<JMenu> itemToDelete = new Vector<JMenu>(2);

		if (parent.getMenuComponentCount() <= 0) {
			return parent;
		}

		for (Component comp : parent.getMenuComponents()) {
			if (comp instanceof JMenu) {
				JMenu menu = removeEmptyMenus((JMenu) comp);
				if (menu != null) {
					itemToDelete.add(menu);
				}
			}
		}

		for (JMenu menu : itemToDelete) {
			parent.remove(menu);
		}

		return null;
	}

	/**
	 * <p>
	 * Constructs a tool bar which can be displayed in the main frame of the
	 * application.
	 * </p>
	 * <p>
	 * It respects the index of the items and adds a separator whenever the
	 * index exceeds 100. For example, it adds a separator after 100, 200, 300,
	 * and so forth.
	 * </p>
	 * 
	 * @return The tool bar including all item to be displayed. If no items are
	 *         to be displayed, an empty tool bar is returned.
	 */
	private void constructToolBar() {
		// The tool bar which will hold the tool bar items.
		toolBar.removeAll();

		List<EodispAction> toolBarActionsList = EodispActionRegistry.getInstance().getToolBarActions();

		// sort the list depending on the toolbar index
		Collections.sort(toolBarActionsList, new Comparator<EodispAction>() {
			public int compare(EodispAction o1, EodispAction o2) {
				return o1.getToolBarIndex() - o2.getToolBarIndex();
			}
		});

		// Add the actions to the toolbar in the specified order.
		int lastIndex = 0;
		for (EodispAction a : toolBarActionsList) {
			if ((a.getToolBarIndex() / 100) > lastIndex) {
				toolBar.addSeparator();
				lastIndex = a.getToolBarIndex() / 100;
			}

			JButton tmpButton = new JButton(a);
			tmpButton.setIcon(a.getToolBarIcon());
			tmpButton.setText("");
			toolBar.add(tmpButton);
			a.setProcessed(true);
		}
	}

	/**
	 * Internally constructs the context menu.
	 * 
	 * @return The context menu that can be displayed as a pop-up window.
	 */
	private <T extends ActionSourceProvider> JPopupMenu constructCtxMenu(Class<T> type) {
		final JPopupMenu ctxMenu = new JPopupMenu();

		List<EodispAction> ctxActionList = EodispActionRegistry.getInstance().getContextMenuActions(type);

		// This list is used to keep track of all sub-menus already created.
		Map<String, JMenu> ctxGroupSubmenus = new Hashtable<String, JMenu>();
		Map<String, List<EodispAction>> ctxGroups = new Hashtable<String, List<EodispAction>>();

		// iterate through all and sort them into groups
		for (EodispAction a : ctxActionList) {
			String groupName = (String) a.getValue(EodispAction.CTX_GROUP);
			if (groupName == null) {
				groupName = "";
			}

			if (!ctxGroups.containsKey(groupName)) {
				ctxGroups.put(groupName, new ArrayList<EodispAction>());
			}

			List<EodispAction> groupActions = ctxGroups.get(groupName);
			groupActions.add(a);
		}

		// Add the actions to the appropriate menus in the specified order.
		for (String groupName : ctxGroups.keySet()) {

			List<EodispAction> tmpActions = ctxGroups.get(groupName);
			int count = tmpActions.size();
			for (int i = 0; i < count; i++) {
				String submenuName = (String) tmpActions.get(i).getValue(EodispAction.CTX_GROUP_SUBMENU);
				if (submenuName == null) {
					submenuName = "";
				}
				if (!submenuName.equals("")) {
					if (!ctxGroupSubmenus.keySet().contains(submenuName)) {
						JMenu subMenu = new JMenu(submenuName);
						subMenu.setName(submenuName);
						subMenu.setEnabled(false);
						ctxGroupSubmenus.put(submenuName, subMenu);
						ctxMenu.add(subMenu);
					}
				}

				if (ctxGroupSubmenus.get(submenuName) != null) {
					ctxGroupSubmenus.get(submenuName).add(tmpActions.get(i));
					if (i + 1 == count) {
						ctxGroupSubmenus.get(submenuName).add(new JSeparator());
					}
				} else {
					ctxMenu.add(tmpActions.get(i));
					if (i + 1 == count) {
						ctxMenu.add(new JSeparator());
					}
				}

			}
		}

		// handle enable/disable of parent-menus
		for (JMenu menu : ctxGroupSubmenus.values()) {
			boolean enabled = false;
			for (Component comp : menu.getMenuComponents()) {
				if (comp instanceof JMenuItem && comp.isEnabled()) {
					enabled = true;
				}
			}
			if (enabled) {
				menu.setEnabled(true);
			}
		}

		return ctxMenu;
	}

	public void addMenuSelectedListener(MenuSelectedListener l) {
		listeners.add(MenuSelectedListener.class, l);
	}

	public void removeMenuSelectedListener(MenuSelectedListener l) {
		listeners.remove(MenuSelectedListener.class, l);
	}

	private MenuSelectedListener[] getMenuSelectedListener() {
		return listeners.getListeners(MenuSelectedListener.class);
	}

	private void fireMenuSelected(JMenu menu) {
		for (MenuSelectedListener l : getMenuSelectedListener()) {
			l.menuSelected(menu);
		}
	}
}