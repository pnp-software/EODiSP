/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.sm.views;

import java.awt.Component;
import java.util.List;

import javax.swing.JEditorPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.StyleSheet;

import org.eodisp.core.sm.helper.SmEmfHelper;
import org.eodisp.ui.common.base.EodispView;
import org.eodisp.ui.common.base.ModelListener;
import org.eodisp.ui.common.base.UIUtil;
import org.eodisp.ui.sm.models.SmExperimentInfoModel;
import org.eodisp.ui.sm.resources.SmResources;

/**
 * @author eglimi
 * @version $Id:$
 */
public class SmExperimentInfoView extends EodispView {

	private final ModelObserver modelObserver = new ModelObserver();

	public static final int ID = 11;

	private static final String TITLE = SmResources.getMessage("SmExperimentInfoView.View.Title");

	private JPanel mainPanel;

	private final JScrollPane scrollPane = new JScrollPane();

	private final JEditorPane infoArea = new JEditorPane();

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getId() {
		return ID;
	}

	@Override
	public String getTitle() {
		return TITLE;
	}

	@Override
	protected void updateViewState() {
		updateInfoArea();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Component getInternalComponent() {
		return mainPanel;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void initializeComponents() {

		// add a general listener
		getSmExperimentInfoModel().addModelListener(modelObserver);

		// editor pane for html
		infoArea.setContentType("text/html");
		infoArea.setEditable(false);

		StyleSheet styleSheet = ((HTMLEditorKit) infoArea.getEditorKit()).getStyleSheet();
		for (String rule : UIUtil.getCssRules()) {
			styleSheet.addRule(rule);
		}

		updateViewState();

		setComponent(infoArea);
	}

	private SmExperimentInfoModel getSmExperimentInfoModel() {
		return (SmExperimentInfoModel) super.getModel();
	}

	private class ModelObserver implements ModelListener {

		public void modelChanged() {
			updateViewState();
		}
	}

	private void updateInfoArea() {
		infoArea.setText(buildHtml());
	}

	private String buildHtml() {
		SmExperimentInfoModel model = getSmExperimentInfoModel();
		StringBuilder sb = new StringBuilder();

		String experimentName = model.getExperimentName() != null ? model.getExperimentName() : "no information";
		String taskState = model.getTaskState() != null ? model.getTaskState().toString() : "no information";
		String controlFederateState = model.getControlFederateState() != null ? model.getControlFederateState()
				.toString() : "no information";
		String federationState = model.getFederationState() != null ? model.getFederationState().toString()
				: "no information";
		String federationExecution = model.getCurrentFederationExecution() != null ? SmEmfHelper.getName(model
				.getCurrentFederationExecution()) : "no information";

		List<Throwable> errors = model.getErrors();

		sb.append("<html>");
		sb.append("<head></head>");
		sb.append("<body>");

		// general info
//		sb.append("<div class='section'>");
		sb.append("<h1> Runtime Information </h1>");
		sb.append("<table>");
		addRow(sb, "Experiment Name:", experimentName);
		addRow(sb, "Experiment State:", taskState);
		addRow(sb, "Control Federate State:", controlFederateState);
		addRow(sb, "Federation State:", federationState);
		addRow(sb, "Federation Execution:", federationExecution);
		sb.append("</table>");
//		sb.append("</div>");

		sb.append("</body>");
		sb.append("</html>");

		return sb.toString();

	}
	
	public static void addRow(StringBuilder sb, String title, String value ) {
		sb.append("<tr>");
		sb.append("<td><strong>" + title + "</strong></td>");
		sb.append("<td style=\"padding-left: 10px\">" + value + "</td>");
		sb.append("</tr>");
	}
}
