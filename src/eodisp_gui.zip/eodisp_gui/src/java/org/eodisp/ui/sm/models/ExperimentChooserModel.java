/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.sm.models;

import java.util.ArrayList;
import java.util.List;

import javax.swing.AbstractListModel;

import org.apache.log4j.Logger;
import org.eodisp.core.sm.application.SmAppModuleCore;
import org.eodisp.core.sm.helper.SmEmfHelper;
import org.eodisp.core.sm.service.SmModelServiceProxy;
import org.eodisp.ui.common.components.AbstractEodispModel;
import org.eodisp.ui.sm.resources.SmResources;
import org.eodisp.util.AppRegistry;

import commonj.sdo.DataObject;

/**
 * @author eglimi
 * @version $Id:$
 */
public class ExperimentChooserModel extends AbstractEodispModel {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(ExperimentChooserModel.class);

	private final ExpListModel expList = new ExpListModel();

	/**
	 * Default constructor.
	 */
	public ExperimentChooserModel() {
		if (expList.getSize() == 0) {
			String name = SmResources.getMessage("Experiment.New.TemplateName");
			SmEmfHelper.addNewExperiment(getModelService().getRootObject(), name);
			doUpdate();
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void doSave() {
		// nothing to save here. It is only to choose.
	}

	@Override
	public void doUpdate() {
		expList.update();
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean hasChanges() {
		return false;
	}

	public ExpListModel getExpListModel() {
		return expList;
	}

	private SmModelServiceProxy getModelService() {
		return ((SmAppModuleCore) AppRegistry.getRootApp().getAppModule(SmAppModuleCore.ID)).getSmModelServiceProxy();
	}

	public class ExpListModel extends AbstractListModel {

		private List<DataObject> delegate = new ArrayList<DataObject>();

		/**
		 * {@inheritDoc}
		 * <p>
		 * The implementation will directly return the element from the
		 * underlying model.
		 * </p>
		 */
		public Object getElementAt(int index) {
			if (delegate.size() - 1 >= index) {
				return delegate.get(index);
			}

			return null;
		}

		/**
		 * {@inheritDoc}
		 * <p>
		 * The implementation will directly check the underlying model for the
		 * number of elements.
		 * </p>
		 */
		public int getSize() {
			if (delegate.size() <= 0) {
				SmModelServiceProxy service = getModelService();
				if (service != null) {
					List<DataObject> experiments = SmEmfHelper.findAllExperiments((DataObject) service.getRootObject());
					for (DataObject experiment : experiments) {
						delegate.add(experiment);
					}
				}
			}
			return delegate.size();
		}

		public void update() {
			delegate.clear();
			fireContentsChanged(this, 0, getSize() - 1);
		}
	}
}
