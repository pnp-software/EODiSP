/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.sm.models;

import java.io.IOException;

import org.eodisp.core.sm.config.SmConfiguration;
import org.eodisp.ui.common.components.AbstractEodispModel;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.configuration.Configuration;

/**
 * @author eglimi
 * @version $Id:$
 */
public class SmAppSettingsModel extends AbstractEodispModel {

	/**
	 * Serial version id
	 */
	private static final long serialVersionUID = 1L;

	private Configuration configuration;

	public SmAppSettingsModel() {
		createConfiguration();
	}

	/**
	 * {@inheritDoc}
	 */
	public void doSave() throws IOException {
		configuration.save();
	}

	/**
	 * {@inheritDoc}
	 */
	public void doUpdate() {
		// TODO Auto-generated method stub
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean hasChanges() {
		return configuration.needsSave();
	}

	/**
	 * {@inheritDoc}
	 */
	public void redo() {
		// This model does not support redo. Ignore request.
	}

	/**
	 * {@inheritDoc}
	 */
	public void undo() {
		// This model does not support undo. Ignore request.
	}

	/**
	 * Returns the configuration class that holds the entries.
	 * 
	 * @return The configuration class.
	 */
	public Configuration getConfiguration() {
		return configuration;
	}

	/**
	 * Gets the configuration class by querying the application registry.
	 */
	private void createConfiguration() {
		configuration = AppRegistry.getRootApp().getConfiguration(SmConfiguration.ID);
	}
}
