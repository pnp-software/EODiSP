/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.rm.views;

import java.awt.Component;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.*;

import org.apache.log4j.Logger;
import org.eodisp.ui.common.actions.*;
import org.eodisp.ui.common.base.EodispView;
import org.eodisp.ui.common.binding.SdoListModel;
import org.eodisp.ui.common.components.EodispListCellRenderer;
import org.eodisp.ui.rm.models.ReposModel;
import org.eodisp.ui.rm.resources.RmResources;

import com.jgoodies.binding.adapter.BasicComponentFactory;
import com.jgoodies.binding.list.SelectionInList;
import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.factories.FormFactory;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

/**
 * This is the configuration view for the simulation manager applications
 * currently available in the repository.
 * 
 * @author eglimi
 * @version $Id:$
 */
public class RmSimManagersView extends EodispView implements ActionSourceProvider {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(RmSimManagersView.class);

	/**
	 * default serial version id.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * The static id used to identify this view.
	 */
	public static final int ID = 11;

	private static final String TITLE = RmResources.getMessage("RmSimManagersView.View.Title");

	private SelectionInList selectionInList = null;

	public static final EodispAction onDeleteSm = new EodispAction() {
		{
			setShowInContextMenu(true);
			setShowInMenuBar(false);
			putValue(Action.NAME, RmResources.getMessage("RmSimManagersView.onDeleteSm.Name"));
			putValue(Action.SHORT_DESCRIPTION, RmResources.getMessage("RmSimManagersView.onDeleteSm.ShortDesc"));
			putValue(Action.SMALL_ICON, RmResources.getIcon("16x16/actions/delete.png"));
			setEnabled(true);
		}
	};

	private JPanel mainPanel;

	private final JScrollPane scrollPane = new JScrollPane();

	private JList smList;

	private JTextField smName;

	private JTextArea smDescription;

	private JTextField smId;

	private final JScrollPane smListSp = new JScrollPane();

	/**
	 * Default constructor.
	 */
	public RmSimManagersView() {
		super();

		registerActions();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getId() {
		return ID;
	}

	@Override
	public String getTitle() {
		return TITLE;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Component getInternalComponent() {
		return scrollPane;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void initializeComponents() {

		// the list with the sm apps
		selectionInList = new SelectionInList(getSmModel().getSmListModel());
		SdoListModel presentationModel = new SdoListModel(selectionInList.getSelectionHolder());

		presentationModel.addPropertyChangeListener(new ListDetailPropertyChangeHandler());

		smList = BasicComponentFactory.createList(selectionInList, new EodispListCellRenderer());
		smList.setModel(selectionInList);

		smList.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				if (e.isPopupTrigger()) {
					handlePopup(e);
				}
			}

			@Override
			public void mousePressed(MouseEvent e) {
				if (e.isPopupTrigger()) {
					handlePopup(e);
				}
			}
		});

		// create components
		smName = BasicComponentFactory.createTextField(presentationModel.getModel(ReposModel.SM_NAME));
		smDescription = BasicComponentFactory.createTextArea(presentationModel.getModel(ReposModel.SM_DESCRIPTION));
		smId = BasicComponentFactory.createTextField(presentationModel.getModel(ReposModel.SM_ID));

		smListSp.setViewportView(smList);

		// set specific behavior
		smName.setEditable(false);
		smDescription.setEditable(false);
		smId.setEditable(false);
		smDescription.setLineWrap(true);
		smDescription.setWrapStyleWord(true);

		// create the layout
		CellConstraints cc = new CellConstraints();
		FormLayout layout = new FormLayout(
				"right:50dlu, 4dlu, 75dlu:grow, 10dlu, right:50dlu, 4dlu, 75dlu:grow, 4dlu, right:20dlu",
				"p, 3dlu, p, 1dlu, p, 3dlu, p, 1dlu, 100dlu, 3dlu, p, 1dlu, p, 3dlu, p:grow,");
		PanelBuilder builder = new PanelBuilder(layout);
		builder.setDefaultDialogBorder();
		buildListPanel(builder, cc, layout);
		buildDetailsPanel(builder, cc, layout);

		logger.debug(String.format("added %d rows to the form.", new Integer(builder.getRowCount())));

		// get and set the panel
		mainPanel = builder.getPanel();
		scrollPane.setViewportView(mainPanel);
		setComponent(getInternalComponent());
	}

	private void handlePopup(MouseEvent e) {
		Object selectedObject = null;
		int selectionIndex = smList.locationToIndex(e.getPoint());
		Rectangle rect = smList.getCellBounds(selectionIndex, selectionIndex);
		if (rect != null && rect.contains(e.getPoint())) {
			selectedObject = getSmModel().getSmListModel().getElementAt(selectionIndex);
		}

		if (selectedObject != null) {
			smList.setSelectedValue(selectedObject, false);
		}

		handleActionRegistrations(selectedObject == null ? null : new Object[] { selectedObject });

		JPopupMenu ctxMenu = EodispMenuManager.getInstance().getCtxMenu(this.getClass());
		// show it if something has been added
		if (ctxMenu.getComponents().length > 0) {
			ctxMenu.show(smList, e.getX(), e.getY());
		}
	}

	private void buildListPanel(PanelBuilder builder, CellConstraints cc, FormLayout layout) {
		// Simulation Managers
		builder.addSeparator(RmResources.getMessage("RmSimManagersView.Prop.Header.Sm"), cc.xyw(builder.getColumn(),
				builder.getRow(), 3));
		builder.nextLine();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextLine();

		builder.add(smListSp, cc.xywh(builder.getColumn(), builder.getRow(), 3, 13, "fill, fill"));
		builder.nextLine(13);
	}

	private void buildDetailsPanel(PanelBuilder builder, CellConstraints cc, FormLayout layout) {
		int labelCol = 5;
		builder.setRow(1);

		// Simulation Managers Infos
		builder.addSeparator(RmResources.getMessage("RmSimManagersView.Prop.Header.SmDetail"), cc.xyw(labelCol, builder
				.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		// sm name
		builder
				.addLabel(RmResources.getMessage("RmSimManagersView.Label1.Text"), cc
						.xyw(labelCol, builder.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.add(smName, cc.xyw(labelCol, builder.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		// sm description
		builder
				.addLabel(RmResources.getMessage("RmSimManagersView.Label2.Text"), cc
						.xyw(labelCol, builder.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.add(new JScrollPane(smDescription), cc.xyw(labelCol, builder.getRow(), 3, "fill, fill"));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		// sm id
		builder
				.addLabel(RmResources.getMessage("RmSimManagersView.Label4.Text"), cc
						.xyw(labelCol, builder.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.add(smId, cc.xyw(labelCol, builder.getRow(), 3));
	}

	/**
	 * Returns the Model for this view.
	 * 
	 * @return The model for this view.
	 */
	private ReposModel getSmModel() {
		return (ReposModel) super.getModel();
	}

	/**
	 * {@inheritDoc}
	 */
	public void registerActions() {
		EodispActionRegistry.getInstance().registerAction(onDeleteSm, this.getClass());
	}

	/**
	 * {@inheritDoc}
	 */
	public void updateRegistrations() {
		handleActionRegistrations(smList.getSelectedValues());
	}

	private void handleActionRegistrations(Object[] selections) {
		if (selections != null && selections.length == 1) {
			onDeleteSm.setEnabled(true);
			onDeleteSm.putValue(EodispAction.USER_OBJECT, selections[0]);
		} else {
			onDeleteSm.setEnabled(false);
		}
	}

	private class ListDetailPropertyChangeHandler implements PropertyChangeListener {

		public ListDetailPropertyChangeHandler() {
		}

		public void propertyChange(PropertyChangeEvent evt) {

			if (evt.getPropertyName().equalsIgnoreCase(SdoListModel.PROPERTYNAME_CHANGED)) {
				// update the list when the property in question changes
				smList.updateUI();
			}

			// ignore otherwise
		}
	}

}
