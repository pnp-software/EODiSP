/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.sm.views;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.*;

import org.apache.log4j.Logger;
import org.eodisp.ui.sm.resources.SmResources;

import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.factories.ButtonBarFactory;
import com.jgoodies.forms.factories.FormFactory;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

/**
 * This is a small dialog to input init data used in an experiment.
 * 
 * @author eglimi
 * @version $Id:$
 */
public class SmInitiDataDialog {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(SmInitiDataDialog.class);

	private final JDialog dialog;

	private JPanel mainPanel;

	private final JScrollPane scrollPane = new JScrollPane();

	private final JTextField initDataPath = new JTextField();

	private final JTextArea initDataDescription = new JTextArea();

	private final JButton initDataPathBtn = new JButton("...");

	private final JButton[] dialogButtons = new JButton[2];

	private File initDataFile;

	private final JFrame owner;

	private SmInitiDataDialog(JFrame owner) {
		this.owner = owner;

		this.dialog = new JDialog(owner, true);

		initializeComponents();
		buildPanels();
		dialog.setContentPane(scrollPane);
	}

	/**
	 * Displays this dialog.
	 */
	public static SmInitData showInitDataDialog(JFrame owner) {
		SmInitiDataDialog initiDataDialog = new SmInitiDataDialog(owner);
		return initiDataDialog.showInernalInitDataDialog();
	}

	private SmInitData showInernalInitDataDialog() {
		dialog.pack();
		dialog.setLocationRelativeTo(owner);
		dialog.setVisible(true);
		dialog.dispose();

		return new SmInitData(initDataDescription.getText(), initDataFile);
	}

	private void initializeComponents() {
		dialogButtons[0] = new JButton(SmResources.getMessage("SmInitDataDialog.Button10.Text"));
		dialogButtons[0].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exitDialog();
			}
		});
		dialogButtons[1] = new JButton(SmResources.getMessage("SmInitDataDialog.Button11.Text"));
		dialogButtons[1].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				initDataFile = null;
				exitDialog();
			}
		});

		initDataPathBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showInitDataFileChooser();
			}
		});
	}

	@SuppressWarnings("boxing")
	private void buildPanels() {
		// create the layout
		CellConstraints cc = new CellConstraints();
		FormLayout layout = new FormLayout("right:50dlu, 4dlu, 75dlu:grow, 4dlu, right:20dlu",
				"p, 1dlu, p, 3dlu, p, 1dlu, 100dlu, 3dlu, p");
		PanelBuilder builder = new PanelBuilder(layout);
		builder.setDefaultDialogBorder();
		buildPanel(builder, cc, layout);

		logger.debug(String.format("added %d rows to the form.", builder.getRowCount()));

		// get and set the panel
		mainPanel = builder.getPanel();
		scrollPane.setViewportView(mainPanel);
	}

	private void buildPanel(PanelBuilder builder, CellConstraints cc, FormLayout layout) {
		int labelCol = 1;
		// som path
		builder.addLabel(SmResources.getMessage("SmInitDataDialog.Label0.Text"), cc.xyw(labelCol, builder.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.add(initDataPath, cc.xyw(labelCol, builder.getRow(), 3));
		builder.add(initDataPathBtn, cc.xy(labelCol + 4, builder.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		// som description
		builder.addLabel(SmResources.getMessage("SmInitDataDialog.Label1.Text"), cc.xyw(labelCol, builder.getRow(), 3));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.add(new JScrollPane(initDataDescription), cc.xyw(labelCol, builder.getRow(), 3, "fill, fill"));
		builder.nextRow();

		// buttons
		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		JPanel btnPanel = ButtonBarFactory.buildRightAlignedBar(dialogButtons);
		builder.add(btnPanel, cc.xyw(builder.getColumn(), builder.getRow(), 5));
	}

	/**
	 * Closes the dialog.
	 */
	private void exitDialog() {
		dialog.dispose();
	}

	private void showInitDataFileChooser() {
		JFileChooser chooser = new JFileChooser();
		int returnVal = chooser.showOpenDialog(dialog);
		if (returnVal == JFileChooser.APPROVE_OPTION) {
			initDataFile = chooser.getSelectedFile();
		} else {
			// no file has been chosen.
			return;
		}

		initDataPath.setText(initDataFile.getPath());
	}

	public static class SmInitData {
		private final String description;

		private final File selectedFile;

		/**
		 * @param description
		 * @param selectedFile
		 */
		public SmInitData(String description, File selectedFile) {
			this.description = description;
			this.selectedFile = selectedFile;
		}

		/**
		 * @return Returns the description.
		 */
		public String getDescription() {
			return description;
		}

		/**
		 * @return Returns the selectedFile.
		 */
		public File getSelectedFile() {
			return selectedFile;
		}
	}
}
