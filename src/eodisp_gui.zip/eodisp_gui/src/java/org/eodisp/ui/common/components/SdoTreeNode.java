/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.common.components;

import java.util.List;

import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeNode;

import org.eclipse.emf.common.util.TreeIterator;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.sdo.EDataObject;

/**
 * This is an implementation of a <code>MutableTreeNode</code> for a project
 * tree in an EODiSP application. More precisely, it works as a tree node for a
 * model that is served by SDO.
 * <p>
 * Whenever a tree with an SDO model behind is used, this tree node
 * implementation can be used as a link between the SDO objects and the Java
 * Swing tree. This ensures that the model data is only stored and managed by
 * SDO, and not twice by SDO and Swing. For this reason, this node always
 * queries the SDO model directly. It only stores the parent and children object
 * of the nodes for performance enhancements. Whenever the model has changed, it
 * will reload the data from the SDO model itself.
 * <p>
 * This tree node is in fact a kind of fake tree node, since all its data are
 * coming from the SDO framework. It is only here in order to have a node with
 * which the Java Swing Tree can work. The actual data is all coming from the
 * associated user object. Therefore, it is important that each tree node has
 * such an object. Otherwise, the tree node will not work as expected.
 * <p>
 * See {@link javax.swing.tree.MutableTreeNode} for more informations.
 * 
 * @author eglimi
 * @version $Id:SdoTreeNode.java 2134 2006-05-16 08:43:27Z eglimi $
 */
public class SdoTreeNode extends DefaultMutableTreeNode {

	/**
	 * default serial version id
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Default constructor. Sets the tree data to <code>null</code>. In order
	 * to get this tree node working properly, the data should be set using
	 * {@link #setUserObject(Object)} method.
	 */
	public SdoTreeNode() {
		this(null);
	}

	/**
	 * Constructor. Sets the user data of this tree node to the given data.
	 * 
	 * @param data
	 *            The data stored together with this tree node. This object
	 *            should be one that can be used to query an Emf item provider
	 *            for data.
	 */
	public SdoTreeNode(Object data) {
		setUserObject(data);

		ensureChildren();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.tree.TreeNode#getIndex(javax.swing.tree.TreeNode)
	 */
	@Override
	public int getIndex(TreeNode node) {
		// we need to check for the user object data
		int index = 0;
		for (Object child : children) {
			if (((SdoTreeNode) child).getUserObject().equals(((SdoTreeNode) node).getUserObject())) {
				return index;
			}
			index++;
		}
		return -1;
	}

	/**
	 * Always returns true. Since the tree nodes are directly linked by the Emf
	 * framework, this tree node does not need to track if children are allowed.
	 * If no children are allowed, the user will not get the choice to insert
	 * one, because the action to insert a child is created by querying the Emf
	 * model itself.
	 * 
	 * @return Always true.
	 */
	@Override
	public boolean getAllowsChildren() {
		return true;
	}

	/**
	 * Returns the string representation of this node. Usually, every node in a
	 * SDO data graph that can be used in a tree node should have a <it>name</it>
	 * attribute. If such an attribute exists, its value will be returned.
	 * Otherwise, the toString method of the object itself would be returned,
	 * which is pretty much useless in this context, but the only choice.
	 * 
	 * @return The string representation of this node. This can be used as the
	 *         name of this tree node.
	 */
	@Override
	public String toString() {

		String nodeString = "";

		EDataObject dataObject = getUserObject() instanceof EDataObject ? (EDataObject) getUserObject()
				: null;

		if (dataObject != null) {
			List<Object> props = dataObject.getInstanceProperties();
			for (int i = 0; i < props.size(); i++) {
				if (dataObject.isSet(i)) {
					Object obj = props.get(i);
					if (obj instanceof EAttribute) {
						EAttribute prop = (EAttribute) props.get(i);
						if (prop.getName().equalsIgnoreCase("name")) {
							nodeString = dataObject.getString(i);
						}
					}
				}
			}
		}

		// if nothing is found, return the string representation of the object
		// (this indicates an error).
		return (nodeString == null || nodeString.equals("")) ? getUserObject().toString()
				: nodeString;
	}

	/**
	 * Returns the tree node for a given user object data. This will recursively
	 * search this node and all children nodes to find the tree node.
	 * 
	 * @param value
	 *            The user object data associated with the tree node that is
	 *            being searched.
	 * @param refreshModel
	 *            Flag to indicate whether the model should be queried. If this
	 *            is true, the Emf framework will be queried to get the current
	 *            data. This will refresh the tree node data. This flag will be
	 *            promoted to all children that are searched.
	 * @return The tree node which has been found or <code>null</code> if no
	 *         tree node with the given user object data could be found.
	 */
	public SdoTreeNode getNodeForData(Object value) {
		if (getUserObject() == value) {
			return this;
		}

		// ensureChildren();
		if (children != null) {
			for (Object n : children) {
				SdoTreeNode node = ((SdoTreeNode) n).getNodeForData(value);
				if (node != null) {
					return node;
				}
			}
		}

		return null;
	}

	/**
	 * Ensures that the data in this tree node is current and is in sync with
	 * the data from the Emf framework for the associated user object.
	 * 
	 * @param refreshModel
	 */
	private void ensureChildren() {
		if (getUserObject() == null) {
			return;
		}

		// children = new Vector<SdoTreeNode>();

		int pos = 0;
		TreeIterator it = ((EObject) getUserObject()).eAllContents();
		while (it.hasNext()) {
			EObject userObj = (EObject) it.next();
			// only consider nodes that are not null and are direct children of
			// the data object
			if (userObj != null && userObj.eContainer().equals(getUserObject())) {
				insert(new SdoTreeNode(userObj), pos);
				pos++;
			}
		}

		// consider references as well
		List<EObject> references = ((EObject) getUserObject()).eCrossReferences();
		for (EObject reference : references) {
			insert(new SdoTreeNode(reference), pos);
			pos++;
		}
	}
}
