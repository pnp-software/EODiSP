/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.mm.views;

import java.awt.Component;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.StyleSheet;

import org.apache.log4j.Logger;
import org.eodisp.ui.common.actions.*;
import org.eodisp.ui.common.base.EodispView;
import org.eodisp.ui.common.base.ModelListener;
import org.eodisp.ui.common.base.UIUtil;
import org.eodisp.ui.mm.application.MmAppUtils;
import org.eodisp.ui.mm.models.FederateBean;
import org.eodisp.ui.mm.models.MmFederatesModel;
import org.eodisp.ui.mm.resources.MmResources;

import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.factories.FormFactory;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

/**
 * @author eglimi
 * @version $Id:$
 */
@SuppressWarnings("serial")
public class MmFederatesView extends EodispView implements ActionSourceProvider {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(MmFederatesView.class);

	/**
	 * default serial version id.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * The static id used to identify this view.
	 */
	public static final int ID = 10;

	/**
	 * The title for this view.
	 */
	private static final String TITLE = MmResources.getMessage("MmFederatesView.View.Title");

	public static final EodispAction onRegisterFederate = new EodispAction() {
		{
			setShowInContextMenu(true);
			setShowInMenuBar(false);
			putValue(Action.NAME, MmResources.getMessage("MmFederatesView.onRegisterFederate.Name"));
			putValue(Action.SHORT_DESCRIPTION, MmResources.getMessage("MmFederatesView.onRegisterFederate.ShortDesc"));
			setEnabled(true);
		}
	};

	public static final EodispAction onDeregisterFederate = new EodispAction() {
		{
			setShowInContextMenu(true);
			setShowInMenuBar(false);
			putValue(Action.NAME, MmResources.getMessage("MmFederatesView.onDeregisterFederate.Name"));
			putValue(Action.SHORT_DESCRIPTION, MmResources.getMessage("MmFederatesView.onDeregisterFederate.ShortDesc"));
			setEnabled(true);
		}
	};

	public static final EodispAction onManagePermissions = new EodispAction() {
		{
			setShowInContextMenu(true);
			setShowInMenuBar(false);
			putValue(Action.NAME, MmResources.getMessage("MmFederatesView.onManagePermissions.Name"));
			putValue(Action.SHORT_DESCRIPTION, MmResources.getMessage("MmFederatesView.onManagePermissions.ShortDesc"));
			setEnabled(true);
		}
	};

	public static final EodispAction onAddInfo = new EodispAction() {
		{
			setShowInContextMenu(true);
			setShowInMenuBar(false);
			putValue(Action.NAME, MmResources.getMessage("MmFederatesView.onAddInfo.Name"));
			putValue(Action.SHORT_DESCRIPTION, MmResources.getMessage("MmFederatesView.onAddInfo.ShortDesc"));
			setEnabled(true);
		}
	};

	/**
	 * This is the main panel that will hold all other components. It will be
	 * embedded in a scroll pane.
	 */
	private JPanel mainPanel;

	/**
	 * This is the main scroll pane that will be shown as the view's component.
	 */
	private final JScrollPane scrollPane = new JScrollPane();

	private final JList federatesList = new JList();

	private final JEditorPane federateInfo = new JEditorPane();

	private final ModelObserver modelObserver = new ModelObserver();

	/**
	 * Default constructor.
	 */
	public MmFederatesView() {
		super();

		registerActions();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getId() {
		return ID;
	}

	@Override
	public String getTitle() {
		return TITLE;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Component getInternalComponent() {
		return scrollPane;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void initializeComponents() {

		federatesList.setModel(getFederatesModel().getFederatesListModel());
		federatesList.setCellRenderer(new MmFederateListRenderer());

		federateInfo.setContentType("text/html");
		federateInfo.setEditable(false);

		getFederatesModel().addModelListener(modelObserver);

		StyleSheet styleSheet = ((HTMLEditorKit) federateInfo.getEditorKit()).getStyleSheet();
		for (String rule : UIUtil.getCssRules()) {
			styleSheet.addRule(rule);
		}

		federatesList.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				if (e.isPopupTrigger()) {
					handlePopup(e);
				}
			}

			@Override
			public void mousePressed(MouseEvent e) {
				if (e.isPopupTrigger()) {
					handlePopup(e);
				}
			}
		});

		federatesList.addListSelectionListener(new ListSelectionListener() {

			public void valueChanged(ListSelectionEvent e) {
				updateInfo();
			}

		});

		// create the layout
		CellConstraints cc = new CellConstraints();
		FormLayout layout = new FormLayout("80dlu:grow, 10dlu, 150dlu:grow", "p, 3dlu, p:grow, 3dlu, p");
		PanelBuilder builder = new PanelBuilder(layout);
		builder.setDefaultDialogBorder();
		buildListPanel(builder, cc, layout);
		buildDetailsPanel(builder, cc, layout);

		// set enable states
		updateRegistrations();

		// get and set the panel
		mainPanel = builder.getPanel();
		scrollPane.setViewportView(mainPanel);
		setComponent(getInternalComponent());
	}

	private void buildListPanel(PanelBuilder builder, CellConstraints cc, FormLayout layout) {
		int listCol = 1;
		// Federates
		builder.addSeparator(MmResources.getMessage("MmFederatesView.Prop.Header.Federates"), cc.xy(listCol, builder
				.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextLine();

		builder.add(federatesList, cc.xy(listCol, builder.getRow(), "fill, fill"));
	}

	private void buildDetailsPanel(PanelBuilder builder, CellConstraints cc, FormLayout layout) {
		int infoCol = 3;
		builder.setRow(1);

		// Federate Information
		builder.addSeparator(MmResources.getMessage("MmFederatesView.Prop.Header.FedDetail"), cc.xy(infoCol, builder
				.getRow()));
		builder.nextRow();

		layout.appendRow(FormFactory.LINE_GAP_ROWSPEC);
		builder.nextRow();

		builder.add(federateInfo, cc.xy(infoCol, builder.getRow(), "fill, fill"));
	}

	private void handlePopup(MouseEvent e) {
		Object selectedObject = null;
		int selectionIndex = federatesList.locationToIndex(e.getPoint());
		Rectangle rect = federatesList.getCellBounds(selectionIndex, selectionIndex);
		if (rect != null && rect.contains(e.getPoint())) {
			selectedObject = getFederatesModel().getFederatesListModel().getElementAt(selectionIndex);
		}

		if (selectedObject != null) {
			federatesList.setSelectedValue(selectedObject, false);
		}

		handleActionRegistrations(selectedObject == null ? null : new Object[] { selectedObject });

		JPopupMenu ctxMenu = EodispMenuManager.getInstance().getCtxMenu(this.getClass());
		// show it if something has been added
		if (ctxMenu.getComponents().length > 0) {
			ctxMenu.show(federatesList, e.getX(), e.getY());
		}
	}

	/**
	 * Returns the Model for this view.
	 * 
	 * @return The model for this view.
	 */
	private MmFederatesModel getFederatesModel() {
		return (MmFederatesModel) super.getModel();
	}

	/**
	 * {@inheritDoc}
	 */
	public void registerActions() {
		EodispActionRegistry.getInstance().registerAction(onRegisterFederate, this.getClass());
		EodispActionRegistry.getInstance().registerAction(onDeregisterFederate, this.getClass());
		EodispActionRegistry.getInstance().registerAction(onManagePermissions, this.getClass());
		EodispActionRegistry.getInstance().registerAction(onAddInfo, this.getClass());
	}

	/**
	 * {@inheritDoc}
	 */
	public void updateRegistrations() {
		handleActionRegistrations(federatesList.getSelectedValues());
	}

	private void handleActionRegistrations(Object[] selections) {

		onRegisterFederate.setEnabled(false);
		onDeregisterFederate.setEnabled(false);
		onManagePermissions.setEnabled(false);
		onAddInfo.setEnabled(false);

		if (selections != null && selections.length == 1 && MmAppUtils.isConnected()) {
			if (getFederatesModel().isFedRegistered(((FederateBean) selections[0]).getFederate())) {
				onDeregisterFederate.setEnabled(true);
				onDeregisterFederate.putValue(EodispAction.USER_OBJECT, ((FederateBean) selections[0]).getFederate());
				onManagePermissions.setEnabled(true);
				onManagePermissions.putValue(EodispAction.USER_OBJECT, ((FederateBean) selections[0]).getFederate());
				onAddInfo.setEnabled(true);
				onAddInfo.putValue(EodispAction.USER_OBJECT, ((FederateBean) selections[0]).getFederate());
			} else {
				onRegisterFederate.setEnabled(true);
				onRegisterFederate.putValue(EodispAction.USER_OBJECT, ((FederateBean) selections[0]).getFederate());
			}
		}
	}

	@Override
	protected void updateViewState() {
		federatesList.repaint();
	}

	private void updateInfo() {
		Object selectedValue = federatesList.getSelectedValue();
		if (selectedValue != null) {
			String info = getFederatesModel().getFederateInfo((FederateBean) selectedValue);
			federateInfo.setText(info);
		}
	}

	private class ModelObserver implements ModelListener {

		public void modelChanged() {
			updateInfo();
		}

	}
}
