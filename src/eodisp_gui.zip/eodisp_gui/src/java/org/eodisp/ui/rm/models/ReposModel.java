/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.rm.models;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.AbstractListModel;

import org.apache.log4j.Logger;
import org.eodisp.core.common.ReposServiceProxy;
import org.eodisp.ui.common.components.AbstractEodispModel;
import org.eodisp.ui.rm.application.RmAppModuleGui;
import org.eodisp.ui.rm.application.RmEmfHelper;
import org.eodisp.util.AppRegistry;

import commonj.sdo.DataObject;

/**
 * @author eglimi
 * @version $Id:$
 */
public class ReposModel extends AbstractEodispModel {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(ReposModel.class);

	// strings used for the binding
	public static final String CAT_NAME = "name";

	public static final String CAT_DESCRIPTION = "description";

	public static final String CAT_ID = "id";

	public static final String CAT_CLOSED = "closed";

	public static final String SM_NAME = "name";

	public static final String SM_DESCRIPTION = "description";

	public static final String SM_ID = "id";

	public static final String MM_NAME = "name";

	public static final String MM_DESCRIPTION = "description";

	public static final String MM_ID = "id";

	public static final String SOM_NAME = "name";

	public static final String SOM_VERSION = "version";

	public static final String SOM_DESCRIPTION = "description";

	public static final String SOM_FILE_NAME = "fileName";

	private final CatListModel catListModel = new CatListModel();

	private final SmListModel smListModel = new SmListModel();

	private final MmListModel mmListModel = new MmListModel();

	private final SomsListModel somsListModel = new SomsListModel();

	/**
	 * {@inheritDoc}
	 */
	public void doSave() throws IOException {
		if (getReposService() != null) {
			getReposService().save();
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void doUpdate() {
		getSmListModel().update();
		getMmListModel().update();
		getCatListModel().update();
		getSomsListModel().update();
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean hasChanges() {
		if (getReposService() != null) {
			return getReposService().isDirty();
		}

		return false;
	}

	public CatListModel getCatListModel() {
		return catListModel;
	}

	public SmListModel getSmListModel() {
		return smListModel;
	}

	public MmListModel getMmListModel() {
		return mmListModel;
	}

	public SomsListModel getSomsListModel() {
		return somsListModel;
	}

	/**
	 * Returns the repository service. This is only a convenience method.
	 * 
	 * @return The repository service or null, if there is no connection.
	 */
	private ReposServiceProxy getReposService() {
		if (isReposConntected()) {
			return ((RmAppModuleGui) AppRegistry.getRootApp().getAppModule(RmAppModuleGui.ID)).getReposServiceProxy();
		}

		return null;
	}

	/**
	 * This is only a convenient method to test the connection to the repository
	 * 
	 * @return true, if there is a connection, otherwise false
	 */
	public boolean isReposConntected() {
		return ((RmAppModuleGui) AppRegistry.getRootApp().getAppModule(RmAppModuleGui.ID)).isReposConnected();
	}

	@SuppressWarnings("serial")
	public class CatListModel extends AbstractListModel {

		private List<DataObject> delegate = new ArrayList<DataObject>();

		/**
		 * {@inheritDoc}
		 * <p>
		 * The implementation will directly return the element from the
		 * underlying model.
		 */
		public Object getElementAt(int index) {
			if (delegate.size() - 1 >= index) {
				return delegate.get(index);
			}

			return null;
		}

		/**
		 * {@inheritDoc}
		 */
		public int getSize() {
			if (delegate.size() <= 0) {
				ReposServiceProxy service = getReposService();
				if (service != null) {
					List<DataObject> categories = RmEmfHelper.findAllCategories(service.getRootObject());
					for (DataObject category : categories) {
						delegate.add(category);
					}
				}
			}
			return delegate.size();
		}

		public void update() {
			delegate.clear();
			fireContentsChanged(catListModel, 0, getSize());
		}
	}

	@SuppressWarnings("serial")
	public class SmListModel extends AbstractListModel {

		private List<DataObject> delegate = new ArrayList<DataObject>();

		/**
		 * {@inheritDoc}
		 * <p>
		 * The implementation will directly return the element from the
		 * underlying model.
		 */
		public Object getElementAt(int index) {
			if (delegate.size() - 1 >= index) {
				return delegate.get(index);
			}

			return null;
		}

		/**
		 * {@inheritDoc}
		 */
		public int getSize() {
			if (delegate.size() <= 0) {
				ReposServiceProxy service = getReposService();
				if (service != null) {
					List<DataObject> categories = RmEmfHelper.findAllSimulationManagers(service.getRootObject());
					for (DataObject category : categories) {
						delegate.add(category);
					}
				}
			}
			return delegate.size();
		}

		public void update() {
			delegate.clear();
			fireContentsChanged(smListModel, 0, getSize());
		}
	}

	@SuppressWarnings("serial")
	public class MmListModel extends AbstractListModel {

		private List<DataObject> delegate = new ArrayList<DataObject>();

		/**
		 * {@inheritDoc}
		 * <p>
		 * The implementation will directly return the element from the
		 * underlying model.
		 */
		public Object getElementAt(int index) {
			if (delegate.size() - 1 >= index) {
				return delegate.get(index);
			}

			return null;
		}

		/**
		 * {@inheritDoc}
		 */
		public int getSize() {
			if (delegate.size() <= 0) {
				ReposServiceProxy service = getReposService();
				if (service != null) {
					List<DataObject> categories = RmEmfHelper.findAllModelManagers(service.getRootObject());
					for (DataObject category : categories) {
						delegate.add(category);
					}
				}
			}
			return delegate.size();
		}

		public void update() {
			delegate.clear();
			fireContentsChanged(mmListModel, 0, getSize());
		}
	}

	@SuppressWarnings("serial")
	public class SomsListModel extends AbstractListModel {

		private List<DataObject> delegate = new ArrayList<DataObject>();

		/**
		 * {@inheritDoc}
		 * <p>
		 * The implementation will directly return the element from the
		 * underlying model.
		 */
		public Object getElementAt(int index) {
			if (delegate.size() - 1 >= index) {
				return delegate.get(index);
			}

			return null;
		}

		/**
		 * {@inheritDoc}
		 */
		public int getSize() {
			if (delegate.size() <= 0) {
				ReposServiceProxy service = getReposService();
				if (service != null) {
					List<DataObject> categories = RmEmfHelper.findAllSoms(service.getRootObject());
					for (DataObject category : categories) {
						delegate.add(category);
					}
				}
			}
			return delegate.size();
		}

		public void update() {
			delegate.clear();
			fireContentsChanged(somsListModel, 0, getSize());
		}
	}
}
