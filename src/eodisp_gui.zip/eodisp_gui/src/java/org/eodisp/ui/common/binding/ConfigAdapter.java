/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.common.binding;

import org.eodisp.util.configuration.Configuration;

import com.jgoodies.binding.value.AbstractValueModel;

/**
 * @author eglimi
 * @version $Id:$
 */
public class ConfigAdapter extends AbstractValueModel {

	/**
	 * serial version id
	 */
	private static final long serialVersionUID = 1L;

	private final Configuration configuration;

	private final String propertyName;

	private final Class type;

	public ConfigAdapter(Configuration configuration, String propertyName) {
		if (configuration == null) {
			throw new IllegalArgumentException(
					"The configuration object you have provided is null. This is not valid since we must be able to get and set configuration values on this object");
		}
		if (!configuration.containsEntry(propertyName)) {
			throw new IllegalArgumentException(
					String
							.format(
									"The property %s does not map to an entry in the configuration object. Try to use the static key names provided by the configuration to avoid this",
									propertyName));
		}
		this.configuration = configuration;
		this.propertyName = propertyName;
		this.type = configuration.getEntry(getPropertyName()).getType();

		if (this.type == Float.TYPE) {
			throw new IllegalArgumentException(
					"The primitive type 'float' is not supported by the configuration. Please add it or change the type");
		} else if (this.type == Double.TYPE) {
			throw new IllegalArgumentException(
					"The primitive type 'double' is not supported by the configuration. Please add it or change the type");
		}
	}

	/**
	 * Returns the name of the adapted Java Bean property.
	 * 
	 * @return the name of the adapted property
	 */
	public String getPropertyName() {
		return propertyName;
	}

	public Object getValue() {

		if (configuration == null) {
			return null;
		}

		if (type == Boolean.TYPE) {
			return configuration.getEntry(getPropertyName()).getBoolean();
		} else if (type == Integer.TYPE) {
			return configuration.getEntry(getPropertyName()).getInt();
		} else if (type == Long.TYPE) {
			return configuration.getEntry(getPropertyName()).getLong();
		} else {
			// support everything else that is a string
			return configuration.getEntry(getPropertyName()).getValue();
		}
	}

	public void setValue(Object newValue) {

		if (configuration == null) {
			return;
		}

		if (type == Boolean.TYPE) {
			configuration.getEntry(getPropertyName()).setBoolean(
					((Boolean) newValue).booleanValue());
		} else if (type == Integer.TYPE) {
			configuration.getEntry(getPropertyName()).setInt(((Integer) newValue).intValue());
		} else if (type == Long.TYPE) {
			configuration.getEntry(getPropertyName()).setLong(((Long) newValue).longValue());
		} else {
			// support everything else that is a string
			configuration.getEntry(getPropertyName()).setValue(newValue.toString());
		}

		Object oldValue = getValue();
		fireValueChange(oldValue, newValue, true);
	}
}
