/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.mm.application;

import java.net.URI;

import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eodisp.core.common.EmfUtil;
import org.eodisp.core.common.ReposServiceProxy;
import org.eodisp.core.gen.repository.impl.RepositoryPackageImpl;
import org.eodisp.core.mm.application.MmAppModuleCore;
import org.eodisp.core.mm.config.MmConfiguration;
import org.eodisp.core.mm.helper.MmEmfHelper;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.configuration.Configuration;

import commonj.sdo.DataObject;

/**
 * @author eglimi
 * @version $Id:$
 */
public class MmAppUtils {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(MmAppUtils.class);

	public static boolean isConnected() {
		return ((MmAppModuleCore) AppRegistry.getRootApp().getAppModule(MmAppModuleCore.ID))
				.getMmCoreServiceProxy().isReposConnected();
	}

	public static boolean isAppRegistered() {
		if (!isConnected()) {
			return false;
		}

		ReposServiceProxy service = ((MmAppModuleCore) AppRegistry.getRootApp().getAppModule(
				MmAppModuleCore.ID)).getReposServiceProxy();
		if (service == null) {
			return false;
		}

		String id = AppRegistry.getRootApp().getConfiguration(MmConfiguration.ID).getEntry(
				MmConfiguration.APP_ID).getValue();
		if (id == null || id.equalsIgnoreCase("")) {
			return false;
		}

		DataObject reposRoot = service.getRootObject();
		if (reposRoot != null) {
			return reposRoot.getDataObject(String.format("modelManagers[id=%s]", id)) != null ? true
					: false;
		}

		return false;
	}

	public static void registerApp(DataObject reposRoot, Configuration config, URI localUri)
			throws IllegalArgumentException, IllegalStateException {

		if (config == null) {
			final String message = "The provided root object must not be null and of type DataObject";
			logger.warn(message);
			throw new IllegalArgumentException(message);
		}

		String mmId = ((MmConfiguration) config).getEntry(MmConfiguration.APP_ID).getValue();
		EDataObject mmMgr = MmEmfHelper.findReposModelManager(reposRoot, mmId);

		if (mmMgr != null) {
			final String message = "The model manager is already registered in the repository. Ignoring request to register.";
			logger.debug(message);
			throw new IllegalStateException(message);
		}

		logger.debug("Register this application in the repository");

		// create the new entry
		mmMgr = (EDataObject) reposRoot
				.createDataObject(RepositoryPackageImpl.REPOSITORY__MODEL_MANAGERS);
		MmEmfHelper.copyApplicationData(mmMgr, config, localUri);
	}

	public static void updateRegistration(DataObject reposRoot, Configuration config, URI localUri)
			throws IllegalArgumentException {

		if (config == null) {
			final String message = "The provided root object must not be null and of type DataObject";
			logger.warn(message);
			throw new IllegalArgumentException(message);
		}

		String mmId = ((MmConfiguration) config).getEntry(MmConfiguration.APP_ID).getValue();
		EDataObject mmMgr = MmEmfHelper.findReposModelManager(reposRoot, mmId);

		if (mmMgr == null) {
			final String message = "The model manager could not be found in the repository (possibly unregistered). Ignoring request to update registration.";
			logger.debug(message);
			throw new IllegalStateException(message);
		}

		MmEmfHelper.copyApplicationData(mmMgr, config, localUri);
	}

	public static void unregisterApp(DataObject reposRoot, String mmId)
			throws IllegalStateException, IllegalArgumentException {

		EDataObject mmMgr = MmEmfHelper.findReposModelManager(reposRoot, mmId);

		if (mmMgr == null) {
			final String message = "The model manager could not be found in the repository (possibly unregistered). Ignoring request to unregister.";
			logger.debug(message);
			throw new IllegalStateException(message);
		}

		EmfUtil.delete(mmMgr);
	}
}
