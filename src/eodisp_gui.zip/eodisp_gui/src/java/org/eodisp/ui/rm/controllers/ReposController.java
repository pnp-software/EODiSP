/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.ui.rm.controllers;

import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.*;

import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.sdo.EDataObject;
import org.eodisp.core.common.EmfUtil;
import org.eodisp.core.common.ReposServiceProxy;
import org.eodisp.core.common.SomFile;
import org.eodisp.core.gen.repository.SOM;
import org.eodisp.core.gen.repository.impl.SOMImpl;
import org.eodisp.ui.common.actions.EodispAction;
import org.eodisp.ui.common.base.*;
import org.eodisp.ui.common.resources.CommonMessageBoxes;
import org.eodisp.ui.common.resources.MessageBoxHelper;
import org.eodisp.ui.rm.application.RmAppModuleGui;
import org.eodisp.ui.rm.application.RmAppUtils;
import org.eodisp.ui.rm.application.RmEmfHelper;
import org.eodisp.ui.rm.models.ReposModel;
import org.eodisp.ui.rm.views.*;
import org.eodisp.util.AppRegistry;

/**
 * @author eglimi
 * @version $Id:$
 */
public class ReposController extends EodispController {

	/**
	 * Log4J logger for this class
	 */
	static Logger logger = Logger.getLogger(ReposController.class);

	private ReposModel reposModel;

	/**
	 * {@inheritDoc}
	 */
	@Override
	public EodispView createDynamicView(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void createStaticViews() {
		// create a new FederatesView view
		if (reposModel != null) {
			RmSomsView somsView = new RmSomsView();
			somsView.setModel(reposModel);
			somsView.initializeComponents();
			attachView(somsView);

			RmCategoriesView catView = new RmCategoriesView();
			catView.setModel(reposModel);
			catView.initializeComponents();
			attachView(catView);
			
			RmSimManagersView smView = new RmSimManagersView();
			smView.setModel(reposModel);
			smView.initializeComponents();
			attachView(smView);

			RmModelManagersView mmView = new RmModelManagersView();
			mmView.setModel(reposModel);
			mmView.initializeComponents();
			attachView(mmView);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isControllerForView(int id) {
		switch (id) {
		case RmCategoriesView.ID:
		case RmSimManagersView.ID:
		case RmModelManagersView.ID:
		case RmSomsView.ID:
			return true;
		default:
			return false;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void registerActionHandler() {
		RmSomsView.onAddSom.registerTargetHandler(new EodispDelegate(this, "onAddSom"));
		RmSomsView.onHandleCategoriesSom.registerTargetHandler(new EodispDelegate(this, "onHandleCategoriesSom"));
		RmSomsView.onDeleteSom.registerTargetHandler(new EodispDelegate(this, "onDeleteSom"));
		RmSomsView.onDownloadSom.registerTargetHandler(new EodispDelegate(this, "onDownloadSom"));
		RmSimManagersView.onDeleteSm.registerTargetHandler(new EodispDelegate(this, "onDeleteSm"));
		RmModelManagersView.onDeleteMm.registerTargetHandler(new EodispDelegate(this, "onDeleteMm"));
		RmCategoriesView.onAddCategory.registerTargetHandler(new EodispDelegate(this, "onAddCategory"));
		RmCategoriesView.onDeleteCategory.registerTargetHandler(new EodispDelegate(this, "onDeleteCategory"));
	}

	public void onAddSom(ActionEvent e) {
		logger.debug("performing action: onAddSom");

		if (!RmAppUtils.isConnected()) {
			CommonMessageBoxes.showReposNotConnectedError(null);
			return;
		}

		JFrame owner = ((UIApp) AppRegistry.getRootApp()).getMainFrame();
		RmRegisterSomDialog.showRmRegisterSomDialog(owner);
		updateOwnedModels();

		logger.debug("onAddSom completed");
	}

	public void onHandleCategoriesSom(ActionEvent e) {
		logger.debug("performing action: onHandleCategoriesSom");

		if (!RmAppUtils.isConnected()) {
			CommonMessageBoxes.showReposNotConnectedError(null);
			return;
		}

		JFrame owner = ((UIApp) AppRegistry.getRootApp()).getMainFrame();
		EodispAction action = (EodispAction) ((JMenuItem) e.getSource()).getAction();
		EDataObject selectedValue = (EDataObject) action.getValue(EodispAction.USER_OBJECT);

		if (selectedValue != null) {
			RmSomCategories.showSomCategoriesDialog(owner, selectedValue);
			updateOwnedModels();
		}

		logger.debug("onHandleCategoriesSom completed");
	}

	public void onDeleteSom(ActionEvent e) {
		logger.debug("performing action: onDeleteSom");

		if (!RmAppUtils.isConnected()) {
			CommonMessageBoxes.showReposNotConnectedError(null);
			return;
		}

		int choice = MessageBoxHelper.YesNoQuestionBoxL(null, "AskDeleteSom.Msg", "AskDeleteSom.Cap");
		if (choice != JOptionPane.YES_OPTION) {
			return;
		}

		EodispAction action = (EodispAction) ((JMenuItem) e.getSource()).getAction();
		EDataObject selectedValue = (EDataObject) action.getValue(EodispAction.USER_OBJECT);

		if (selectedValue != null && selectedValue instanceof SOMImpl) {
			// first, delete all referenced federates
			List<EDataObject> scheduleForDeletion = new ArrayList<EDataObject>(RmEmfHelper
					.findAllFederatesForSom(selectedValue));
			for (EDataObject federate : scheduleForDeletion) {
				EmfUtil.delete(federate);
			}

			// and then, delete the SOM
			EmfUtil.delete(selectedValue);

			// and last, delete the physical file
			SOM som = (SOM) selectedValue;

			ReposServiceProxy service = ((RmAppModuleGui) AppRegistry.getRootApp().getAppModule(RmAppModuleGui.ID))
					.getReposServiceProxy();

			if (service != null) {
				try {
					service.deleteSom(som.getName(), som.getVersion());
				} catch (Exception ex) {
					final String message = "The SOM file could not be deleted on the repository";
					logger.warn(message, ex);
				}
			}
		}
		updateOwnedModels();

		logger.debug("onDeleteSom completed");
	}

	@SuppressWarnings("serial")
	public void onDownloadSom(ActionEvent e) {
		logger.debug("performing action: onDownloadSom");

		if (!RmAppUtils.isConnected()) {
			CommonMessageBoxes.showReposNotConnectedError(null);
			return;
		}

		EodispAction action = (EodispAction) ((JMenuItem) e.getSource()).getAction();
		Object selectedValue = action.getValue(EodispAction.USER_OBJECT);

		if (selectedValue != null && selectedValue instanceof SOMImpl) {
			SOM som = (SOM) selectedValue;

			final JFrame mainFrame = ((UIApp) AppRegistry.getRootApp()).getMainFrame();

			JFileChooser fileChooser = new JFileChooser() {

				@Override
				public void approveSelection() {
					// check for file
					if (getSelectedFile() != null && getSelectedFile().exists()) {
						int choice = MessageBoxHelper.YesNoQuestionBoxL(mainFrame, "Warning.File.Exists.Msg",
								"Warning.File.Exists.Cap");
						if (choice != JOptionPane.YES_OPTION) {
							return;
						}
					}

					super.approveSelection();
				}
			};

			int returnVal = fileChooser.showSaveDialog(mainFrame);

			if (returnVal == JFileChooser.APPROVE_OPTION) {
				File selectedFile = fileChooser.getSelectedFile();
				SomFile file = null;
				FileOutputStream out = null;

				try {

					if (!selectedFile.exists()) {
						selectedFile.createNewFile();
					}

					ReposServiceProxy service = ((RmAppModuleGui) AppRegistry.getRootApp().getAppModule(
							RmAppModuleGui.ID)).getReposServiceProxy();

					if (service != null) {
						file = service.getSom(som.getName(), som.getVersion());

						out = new FileOutputStream(selectedFile);
						out.write(file.getFileData());
					}
				} catch (Exception ex) {
					CommonMessageBoxes.showSaveError(mainFrame, ex.getMessage());
				} finally {
					if (out != null) {
						try {
							out.close();
						} catch (IOException ex) {
							CommonMessageBoxes.showSaveError(mainFrame, ex.getMessage());
						}
					}
				}
			} else {
				// do not save
				return;
			}
		}

		logger.debug("onDownloadSom completed");
	}

	public void onDeleteSm(ActionEvent e) {
		logger.debug("performing action: onDeleteSm");

		if (!RmAppUtils.isConnected()) {
			CommonMessageBoxes.showReposNotConnectedError(null);
			return;
		}

		int choice = MessageBoxHelper.YesNoQuestionBoxL(null, "AskDeleteSimManager.Msg", "AskDeleteSimManager.Cap");
		if (choice != JOptionPane.YES_OPTION) {
			return;
		}

		EodispAction action = (EodispAction) ((JMenuItem) e.getSource()).getAction();
		EDataObject selectedValue = (EDataObject) action.getValue(EodispAction.USER_OBJECT);

		if (selectedValue != null) {
			EmfUtil.delete(selectedValue);
		}
		updateOwnedModels();

		logger.debug("onDeleteSm completed");
	}

	public void onDeleteMm(ActionEvent e) {
		logger.debug("performing action: onDeleteMm");

		if (!RmAppUtils.isConnected()) {
			CommonMessageBoxes.showReposNotConnectedError(null);
			return;
		}

		int choice = MessageBoxHelper.YesNoQuestionBoxL(null, "AskDeleteModelManager.Msg", "AskDeleteModelManager.Cap");
		if (choice != JOptionPane.YES_OPTION) {
			return;
		}

		EodispAction action = (EodispAction) ((JMenuItem) e.getSource()).getAction();
		EDataObject selectedValue = (EDataObject) action.getValue(EodispAction.USER_OBJECT);

		if (selectedValue != null) {
			EmfUtil.delete(selectedValue);
		}
		updateOwnedModels();

		logger.debug("onDeleteMm completed");
	}

	public void onAddCategory(ActionEvent e) {
		logger.debug("performing action: onAddCategory");

		if (!RmAppUtils.isConnected()) {
			CommonMessageBoxes.showReposNotConnectedError(null);
			return;
		}

		JFrame owner = ((UIApp) AppRegistry.getRootApp()).getMainFrame();

		RmAddCategoryDialog.showAddCategoryDialog(owner);

		updateOwnedModels();

		logger.debug("onAddCategory completed");
	}

	public void onDeleteCategory(ActionEvent e) {
		logger.debug("performing action: onDeleteCategory");

		if (!RmAppUtils.isConnected()) {
			CommonMessageBoxes.showReposNotConnectedError(null);
			return;
		}

		int choice = MessageBoxHelper.YesNoQuestionBoxL(null, "AskDeleteCat.Msg", "AskDeleteCat.Cap");
		if (choice != JOptionPane.YES_OPTION) {
			return;
		}

		EodispAction action = (EodispAction) ((JMenuItem) e.getSource()).getAction();
		EDataObject selectedValue = (EDataObject) action.getValue(EodispAction.USER_OBJECT);

		if (selectedValue != null) {
			EmfUtil.delete(selectedValue);
		}
		updateOwnedModels();

		logger.debug("onDeleteCategory completed");
	}

	@Override
	protected void initialize() {
		super.initialize();

		reposModel = new ReposModel();

		createStaticViews();
	}
}
