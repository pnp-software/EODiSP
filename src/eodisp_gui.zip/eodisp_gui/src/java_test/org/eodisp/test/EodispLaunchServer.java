/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.test;

import java.io.File;

import org.eodisp.core.mm.MmProcessFactory;
import org.eodisp.core.repos.ReposProcessFactory;
import org.eodisp.hla.crc.launcher.CrcProcessFactoryRemote;
import org.eodisp.hla.crc.launcher.CrcProcessFactoryRemoteImpl;
import org.eodisp.remote.launcher.server.application.LaunchServerApplication;

/**
 * @author eglimi
 * @version $Id:$
 * 
 */
public class EodispLaunchServer {

	public static final File DEFAULT_WORKING_DIR = new File(new File(System
			.getProperty("user.home"), ".eodisp"), "eodisp-launch-server");

	public static void main(String[] args) throws InterruptedException {
		// Logger.getLogger("net.jini").setLevel(Level.ALL);
		// final ConsoleHandler consoleHandler = new ConsoleHandler();
		// consoleHandler.setLevel(Level.ALL);
		// Logger.getLogger("net.jini").addHandler(consoleHandler);
		LaunchServerApplication launchServerApplication = new LaunchServerApplication(
				"EODiSP Core Apps Launch Server",
				"Launch server that enables starting EODiSP core and gui applications from remote",
				DEFAULT_WORKING_DIR, EodispLaunchServer.class, 14355);
		launchServerApplication.registerProcessFactory(ReposProcessFactory.FACTORY_ID,
				ReposProcessFactory.class);
		launchServerApplication.registerProcessFactory(MmProcessFactory.FACTORY_ID,
				MmProcessFactory.class);
		launchServerApplication.registerProcessFactory(CrcProcessFactoryRemoteImpl.FACTORY_ID,
				CrcProcessFactoryRemoteImpl.class);

		launchServerApplication.execute(args);
		Thread.sleep(Long.MAX_VALUE);
	}
}
