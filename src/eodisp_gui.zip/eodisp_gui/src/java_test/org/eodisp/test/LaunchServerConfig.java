/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.test;

import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
final public class LaunchServerConfig {
	private LaunchServerConfig() {
	}
	
	public static URI[] getConfiguredLaunchServers() throws FileNotFoundException, IOException, URISyntaxException {
		File file = new File("test.properties");
		if( !file.exists() ) {
			file = new File( new File( System.getProperty("user.home"), ".eodisp" ), "test.properties"); 
		}
		if( !file.exists() ) {
			throw new FileNotFoundException("No test.properties file defined");
		}
		
		Properties properties = new Properties();
		properties.load(new FileInputStream( file ));
		List<URI> result = new ArrayList<URI>();
		result.add( new URI( properties.getProperty("launchserver0") ));
		result.add( new URI( properties.getProperty("launchserver1") ));
		result.add( new URI( properties.getProperty("launchserver2") ));
		result.add( new URI( properties.getProperty("launchserver3") ));
		result.add( new URI( properties.getProperty("launchserver4") ));
		return result.toArray(new URI[0]);
	}
}
