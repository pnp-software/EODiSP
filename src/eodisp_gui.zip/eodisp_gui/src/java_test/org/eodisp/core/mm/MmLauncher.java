/*
 * EODiSP - Earth Observation Distributed Platform
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.mm;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.rmi.NotBoundException;
import java.rmi.registry.Registry;
import java.util.EnumSet;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.eodisp.core.common.ModelManagerRemote;
import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.remote.config.RemoteConfiguration.TransportType;
import org.eodisp.remote.launcher.RootAppProcessFactoryRemote;
import org.eodisp.remote.launcher.RootAppProcessRemote;
import org.eodisp.remote.launcher.server.LaunchServerRemote;
import org.eodisp.remote.launcher.server.LaunchServerRemoteImpl;
import org.eodisp.remote.registry.JeriRegistry;

/**
 * @author ibirrer
 * @version $Id:$
 * 
 */
public class MmLauncher {
	private ModelManagerRemote mmRemote;

	private RootAppProcessRemote processRemote;

	private RemoteAppModule remoteAppModule;

	private TransportType transportType;

	private URI launchServerUri;

	/**
	 * @param remoteAppModule
	 * @param transportType
	 * @param launchServerUri
	 */
	public MmLauncher(RemoteAppModule remoteAppModule, TransportType transportType,
			URI launchServerUri) {
		this.remoteAppModule = remoteAppModule;
		this.transportType = transportType;
		this.launchServerUri = launchServerUri;
	}

	public ModelManagerRemote getMmRemote() {
		return mmRemote;
	}

	public RootAppProcessRemote getProcessRemote() {
		return processRemote;
	}

	public void launch(long timeout, TimeUnit unit) throws URISyntaxException, NotBoundException,
			InstantiationException, IllegalAccessException, IOException, InterruptedException,
			TimeoutException {
		Registry launchServerRegistry = remoteAppModule.getRegistry(launchServerUri);
		LaunchServerRemote launchServerRemote = (LaunchServerRemote) launchServerRegistry
				.lookup(LaunchServerRemoteImpl.REGISTRY_NAME);
		RootAppProcessFactoryRemote mmProcessFactory = (RootAppProcessFactoryRemote) launchServerRemote
				.newProcessFactory(MmProcessFactory.FACTORY_ID);

		mmProcessFactory.setTransports(EnumSet.of(transportType));

		processRemote = (RootAppProcessRemote) mmProcessFactory.newProcess();

		Map<TransportType, JeriRegistry> registries;
		if ((registries = processRemote.launchBlocking(timeout, unit)) == null) {
			processRemote.kill(0);
			throw new TimeoutException(String.format("Could not launch Model Manager at %s",
					launchServerUri));
		}

		JeriRegistry crcJeriRegistry = registries.get(transportType);
		mmRemote = (ModelManagerRemote) crcJeriRegistry.lookup(ModelManagerRemote.REGISTRY_NAME);
	}

}
