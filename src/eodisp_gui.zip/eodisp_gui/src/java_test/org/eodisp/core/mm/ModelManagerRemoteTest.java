/*
 * Copyright (C) 2005  P&P Software GmbH
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * web:  http://www.pnp-software.com
 * mail: info@pnp-software.com
 */
package org.eodisp.core.mm;

import static java.util.concurrent.TimeUnit.SECONDS;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.net.URI;
import java.net.URL;
import java.util.Properties;

import javax.swing.JOptionPane;

import org.eodisp.core.common.FederateProcessHandle;
import org.eodisp.core.common.FileInitData;
import org.eodisp.core.common.ModelManagerRemote;
import org.eodisp.core.sm.control.ControlFederateRemoteImpl;
import org.eodisp.hla.launcher.CrcLauncher;
import org.eodisp.remote.application.RemoteAppModule;
import org.eodisp.remote.config.RemoteConfiguration.TransportType;
import org.eodisp.test.LaunchServerConfig;
import org.eodisp.util.AppRegistry;
import org.eodisp.util.FileUtil;
import org.eodisp.util.RootApp;
import org.eodisp.util.junit.FixtureTestCase;

/**
 * @author ibirrer
 * @version $Id:$
 */
public class ModelManagerRemoteTest extends FixtureTestCase {
	private static final String TEST_FEDERATION_EXECUTION_NAME = "testFederationExecutionName";

	public static final File CONTROL_FEDERATE_WORKING_DIR = new File(new File(System.getProperty("user.home"),
			".eodisp"), "test-control-federate");

	private FederateProcessHandle simControllerProcessHandle;

	private FederateProcessHandle lidFilterProcessHandle;

	private FederateProcessHandle sceneCreatorProcessHandle;

	private static URL fdd;

	private static URI[] launchServerUris;

	private static RemoteAppModule remoteAppModule;

	private static TransportType transportType;

	private static ModelManagerRemote mm1;

	private static ModelManagerRemote mm2;

	private static ModelManagerRemote mm3;

	private static MmLauncher mmLauncher1;

	private static MmLauncher mmLauncher2;

	private static MmLauncher mmLauncher3;

	private static CrcLauncher crcLauncher;

	/**
	 * {@inheritDoc} Uses the following launch server configurations (MM = Model
	 * Manager):
	 * <ul>
	 * <li>launchserver0: CRC</li>
	 * <li>launchserver1: MM 1</li>
	 * <li>launchserver2: MM 2</li>
	 * <li>launchserver3: MM 3</li>
	 * The configuration is read from the <code>test.properties</code> file
	 * </ul>
	 */
	@Override
	protected void setUpFixture() throws Exception {
		transportType = TransportType.JXTA;
		System.setProperty("org.eodisp.working-dir", FileUtil.createTempDir("ReposTmp", "", null).getAbsolutePath());
		// System.setProperty("org.eodisp.log-level", "debug");
		System.setProperty("org.eodisp.remote.transport", transportType.toString());

		RootApp controlFederateApp = new RootApp("test control federate", "test control federate",
				CONTROL_FEDERATE_WORKING_DIR, null);
		controlFederateApp.registerAppModule(new RemoteAppModule(0));
		fdd = Thread.currentThread().getContextClassLoader().getResource("resources/earthcare.fdd");
		System.out.println(fdd);
		controlFederateApp.execute(new String[0]);

		remoteAppModule = (RemoteAppModule) AppRegistry.getRootApp().getAppModule(RemoteAppModule.ID);
		launchServerUris = LaunchServerConfig.getConfiguredLaunchServers();

		mmLauncher1 = new MmLauncher(remoteAppModule, transportType, launchServerUris[1]);
		mmLauncher1.launch(30, SECONDS);
		mm1 = mmLauncher1.getMmRemote();
		mmLauncher2 = mmLauncher1;
		if (!launchServerUris[2].equals(launchServerUris[1])) {
			mmLauncher2 = new MmLauncher(remoteAppModule, transportType, launchServerUris[2]);
			mmLauncher2.launch(30, SECONDS);
		}
		mm2 = mmLauncher2.getMmRemote();
		if (launchServerUris[3].equals(launchServerUris[1])) {
			mmLauncher3 = mmLauncher1;
		} else if (launchServerUris[3].equals(launchServerUris[2])) {
			mmLauncher3 = mmLauncher2;
		} else {
			mmLauncher3 = new MmLauncher(remoteAppModule, transportType, launchServerUris[3]);
			mmLauncher3.launch(30, SECONDS);
		}
		mm3 = mmLauncher3.getMmRemote();

		crcLauncher = new CrcLauncher(remoteAppModule, transportType, launchServerUris[0]);
		crcLauncher.launch(30, SECONDS);
		System.out.println(crcLauncher.getUri().toString());
		System.setProperty("org.eodisp.hla.lrc.crc-uri", crcLauncher.getUri().toString());
	}

	/**
	 * Runs the following federates on the given model manager:
	 * <p>
	 * <ul>
	 * <li>MM1: Scene Creator Federate (org.eodisp.earthcare.scene_creator)</li>
	 * <li>MM2: Lid Filter Federate (org.eodisp.earthcare.lid_filter)</li>
	 * <li>MM3: Simulation Controller Federate
	 * (org.eodisp.earthcare.sim_contoller)</li>
	 * </ul>
	 * See {@link #setUpFixture()} for the launch server configuration.
	 * 
	 * @throws Exception
	 */
	public void testDummy() throws Exception {
		final int nrOfParticipatingFederates = 3;
		ControlFederateRemoteImpl controlFederate = new ControlFederateRemoteImpl(TEST_FEDERATION_EXECUTION_NAME, fdd,
				nrOfParticipatingFederates, null);
		sceneCreatorProcessHandle = mm1.lockFederate("dummySimId", "dummyExperiment",
				"org.eodisp.earthcare.scene_creator", "0.0.1");

		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		Properties properties = new Properties();
		properties.setProperty("test", "true");
		properties.store(byteArrayOutputStream, "");
		FileInitData propertiesFileInitData = new FileInitData(byteArrayOutputStream.toByteArray(), "fed.properties");
		mm1.startFederate(sceneCreatorProcessHandle, crcLauncher.getUri(), TEST_FEDERATION_EXECUTION_NAME,
				new FileInitData[] { propertiesFileInitData });

		lidFilterProcessHandle = mm2.lockFederate("dummySimId", "dummyExperiment", "org.eodisp.earthcare.lid_filter",
				"0.0.1");

		mm2.startFederate(lidFilterProcessHandle, crcLauncher.getUri(), TEST_FEDERATION_EXECUTION_NAME,
				new FileInitData[] { propertiesFileInitData });
		simControllerProcessHandle = mm3.lockFederate("dummySimId", "dummyExperiment",
				"org.eodisp.earthcare.sim_controller_test", "0.0.1");
		mm3.startFederate(simControllerProcessHandle, crcLauncher.getUri(), TEST_FEDERATION_EXECUTION_NAME,
				new FileInitData[] { propertiesFileInitData });

		final Thread testThread = Thread.currentThread();
		Thread cancelThrad = new Thread() {
			@Override
			public void run() {
				JOptionPane.showConfirmDialog(null, "Cancel Test?", "Cancel Test?", JOptionPane.OK_OPTION);
				testThread.interrupt();
			}
		};
		cancelThrad.start();

		controlFederate.init(60, SECONDS);
		controlFederate.start(60, SECONDS);
		assertTrue(true);
	}

	@Override
	protected void tearDown() throws Exception {

		if (sceneCreatorProcessHandle != null) {
			boolean stopped = mm1.stopFederate(sceneCreatorProcessHandle);
			System.out.println("Stoppped scene_creator: " + stopped);
		}
		if (lidFilterProcessHandle != null) {
			boolean stopped = mm2.stopFederate(lidFilterProcessHandle);
			System.out.println("Stoppped lid_filter: " + stopped);
		}

		if (simControllerProcessHandle != null) {
			boolean stopped = mm3.stopFederate(simControllerProcessHandle);
			System.out.println("Stoppped sim_controller: " + stopped);
		}

	}

	@Override
	protected void tearDownFixture() throws Exception {
		if (crcLauncher != null) {
			crcLauncher.getProcessRemote().kill(1000);
		}
		if (mmLauncher1 != null) {
			mmLauncher1.getProcessRemote().kill(1000);
		}

		if (mmLauncher2 != mmLauncher1 && mmLauncher2 != null) {
			mmLauncher2.getProcessRemote().kill(1000);
		}

		if (mmLauncher3 != mmLauncher2 && mmLauncher3 != mmLauncher1 && mmLauncher3 != null) {
			mmLauncher3.getProcessRemote().kill(1000);
		}
	}
}
